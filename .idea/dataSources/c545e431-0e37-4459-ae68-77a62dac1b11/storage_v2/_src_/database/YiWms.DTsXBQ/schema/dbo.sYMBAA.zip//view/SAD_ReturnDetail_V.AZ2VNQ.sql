/*==============================================================*/
/* View: SAD_ReturnDetail_V                                     */
/*==============================================================*/
--creator：        Frank
--create time：  2016-03-15日整理 
--modify: 2016-07-25日 增加对应商品ID
--销售退货单明细视图
create view [dbo].[SAD_ReturnDetail_V] as
SELECT b.returnId,b.returnNo,a.billNo,a.returnDate,a.customerId,a.ioType,a.ioState,b.companyId,b.warehouseId,
      b.viewOrder,b.stockId,b.stockNo,b.stockBillNo,b.lotNo,bh.productDate,bh.batchNo,b.locationNo,b.eId,
      b.itemId,sku.itemNo,sku.itemCTitle,sku.itemETitle,sku.itemName,sku.sellingPoint,sku.itemSpec,sku.itemSpell, 
      sku.barcode,sku.brandId,sku.brandCName,sku.brandEName,sku.categoryId,sku.categoryNo,sku.categoryCName, 
      sku.categoryEName,sku.colorName,sku.sizeName,b.unitId,sku.unitName,sku.pkgUnit,sku.pkgRatio,sku.webPrice, 
      sku.marketPrice,sku.vipPrice,sku.retailPrice,sku.tradePrice,sku.salesPrice,sku.purPrice,sku.lastPurPrice, 
      sku.minPrice,sku.inventoryMode,sku.isSafety,sku.safetyMonth,sku.safetyDays,sku.isUnsalable,sku.isStop,
      sku.isVirtual,ISNULL(s.stockQty,0.0) - ISNULL(s.returnQty,0.0) + ISNULL(b.returnQty,0.0) AS residueQty,
      b.returnQty,b.pkgQty,b.bulkQty,b.befPrice,b.discount,b.discountFee,b.price,a.taxFlag,b.taxrate,b.fee,b.taxFee,
      b.totalFee,b.costPrice,b.rebate,b.invoiceQty,ISNULL(b.returnQty,0.0)-ISNULL(b.invoiceQty,0.0) AS invableQty,
      b.invoiceFee,ISNULL(b.totalFee,0.0)-ISNULL(b.invoiceFee,0.0) AS invableFee,b.payQty,b.payFee,b.toOrder, 
      b.isPromotion,b.groupId, b.salesId, b.handlerId, b.deptId, b.orderId, b.orderNo, b.orderBillNo, b.contractId, 
      b.contractNo,a.receiverAddress, a.receiverName, b.packageId,b.supplierId,t.putawayQty,
      sku.largeUrl,sku.middleUrl,sku.smallUrl,sku.littleUrl,sku.commodityId,sku.ownerId,b.remarks,b.isSelected,bw.warehouseNo,bw.warehouseName
FROM dbo.SAD_Return AS a 
      INNER JOIN dbo.SAD_ReturnDetail AS b ON a.returnNo = b.returnNo 
      INNER JOIN dbo.BAS_Item_V AS sku ON b.itemId = sku.itemId 
      LEFT JOIN dbo.IMS_Batch bh ON b.lotNo=bh.lotNo 
      LEFT JOIN dbo.SAD_StockDetail AS s ON b.stockId = s.stockId 
      LEFT JOIN BAS_Warehouse AS bw ON b.warehouseId=bw.warehouseId
      LEFT JOIN(
                SELECT n.stockId AS returnId,SUM(CASE n.unitLevel WHEN 'EA' THEN n.putQty ELSE n.putQty*n.pkgRatio END) AS putawayQty
                FROM dbo.WMS_Putaway m
                      INNER JOIN dbo.WMS_PutawayDetail n ON m.putawayNo=n.putawayNo
                WHERE n.ioState=30
                GROUP BY n.stockId) t ON b.returnId=t.returnId

go

