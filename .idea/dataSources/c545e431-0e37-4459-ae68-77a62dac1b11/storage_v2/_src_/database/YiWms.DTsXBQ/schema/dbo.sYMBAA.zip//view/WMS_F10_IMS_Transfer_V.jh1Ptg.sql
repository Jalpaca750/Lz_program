

/*==============================================================*/
/* View: WMS_F10_IMS_Transfer_V                                 */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_IMS_Transfer_V] as
SELECT a.transferNo,a.billNo,a.transferDate AS createDate,wo.deptNo,wo.warehouse AS warehouse_O,
	wi.warehouse AS warehouse_I,'20' AS billSts,0 AS pFlag,CONVERT(VARCHAR(10),a.auditTime,23) AS auditDate,
	u1.employeeID AS auditId,u2.employeeID AS creatorId,CONVERT(VARCHAR(20),a.createTime,120) AS ShelvesTime,
	u2.employeeID AS ShelvesId,a.memo AS remarks
FROM dbo.IMS_Transfer a
	INNER JOIN F10BMS.dbo.WMS_F10_Warehouse_V wo ON a.outputId=wo.warehouseId
	INNER JOIN F10BMS.dbo.WMS_F10_Warehouse_V wi ON a.inputId=wi.warehouseId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u1 ON a.auditorId=u1.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u2 ON a.creatorId=u2.userId
WHERE (a.ioState=2)
	AND (a.thirdSyncFlag=0)
	AND (a.inputId!=a.outputId)
go

