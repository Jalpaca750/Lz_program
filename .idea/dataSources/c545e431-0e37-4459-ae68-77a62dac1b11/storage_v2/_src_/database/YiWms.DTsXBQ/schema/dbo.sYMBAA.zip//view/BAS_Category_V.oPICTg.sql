
/*==============================================================*/
/* View: BAS_Category_V                                         */
/*==============================================================*/
--creator：Frank
--create time：2016-06-01
--modify：Frank 2016-09-20日整理增加锁定时间
create view BAS_Category_V as
SELECT cat.categoryId,cat.companyId,cat.categoryNo,cat.categoryCName,cat.categoryEName,cat.parentId, 
      p.categoryNo AS parentNo,ISNULL(cat.parentCName,ISNULL(p.categoryCName,'')) AS parentCName,p.categoryEName AS parentEName,
      CASE cat.parentId WHEN '0' THEN p.categoryCName ELSE ISNULL(cat.parentCName,ISNULL(p.categoryCName,''))+'>'+cat.categoryCName END AS fullName,
      cat.pictureUrl,cat.usage, CASE cat.usage WHEN 1 THEN '内部平台' WHEN 2 THEN '电商平台' ELSE '所有平台' END AS usageName, 
      cat.isHot, CASE ISNULL(cat.isHot,0) WHEN 0 THEN '否' ELSE '是' END AS isHotName,cat.viewOrder, 
      cat.isDisable, CASE ISNULL(cat.isDisable,0) WHEN 0 THEN '否' ELSE '是' END AS isDisableName, 
      cat.isLocked, cat.lockerId, u1.userNick AS lockerName,CONVERT(VARCHAR(20),cat.lockedTime,120) AS lockedTime,
      cat.createTime, cat.creatorId, u2.userNick AS creatorName, cat.editTime, cat.editorId, 
      u3.userNick AS editorName, cat.isSelected
FROM dbo.BAS_Category AS cat LEFT JOIN
      dbo.BAS_Category AS p ON cat.parentId = p.categoryId LEFT JOIN
      dbo.SAM_User u1 ON cat.lockerId=u1.userId LEFT JOIN
      dbo.SAM_User u2 ON cat.creatorId=u2.userId LEFT JOIN
      dbo.SAM_User u3 ON cat.editorId=u3.userId
go

