Create Proc  proc_Picking_GetBoxItems
(
  @boxCode varchar(32),   --周转箱或者整件的箱码或者散件的箱码
  @companyId varchar(32)  --公司ID
)
AS
DECLARE  @pickId varchar(32)='', --wms_pickingorder 表主键
         @boxid   varchar(32)=''  --周转箱主键
BEGIN
    ---如果是周转箱箱号
    IF EXISTS(SELECT boxId FROM  WMS_Box  WHERE boxCode=@boxCode)
    BEGIN
    --找到箱子
        SELECT @boxid=boxId FROM  WMS_Box  WHERE boxCode=@boxCode
    --找到关联的任务
        select @pickId=pickId from WMS_PickingOrder where companyId=@companyId and  taskState<3 and boxId=@boxid 
    END
    ELSE  IF ISNUMERIC(@boxCode)=1   --如果是数字类型那么看看 是否是系统单号
    BEGIN
          select  @pickId=pickId 
          FROM  WMS_PickingOrder WHERE boxBillNum=CAST(@boxCode AS decimal(10,0))
    END 
    --返回系统要的值
    SELECT * FROM WMS_PickingDetail_V  WHERE pickId=@pickId
END
go

