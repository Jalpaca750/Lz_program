-- =============================================
-- Author:		<Author:Frank.He>
-- Create date: <Create Date:2016-12-14>
-- Description:	<Description:盘点批次的盈亏分析表>
-- =============================================

CREATE FUNCTION [dbo].[uf_GetPhysicalCount] 
(
	@pointId VARCHAR(32)
)
RETURNS TABLE
RETURN(
      SELECT cs.stockId,cs.companyId,cs.pointId,cp.pointNo,w.warehouseId,w.warehouseNo,w.warehouseName,cs.lotNo,cs.locationNo,
            sku.itemNo,sku.itemName,sku.itemCTitle,sku.itemETitle,sku.sellingPoint,sku.itemSpell,sku.itemSpec,sku.packageId,
            sku.barcode,sku.brandId,sku.brandNo,sku.brandCName,sku.categoryId,sku.categoryNo,sku.categoryCName,sku.colorName,
            sku.sizeName,sku.unitName,sku.pkgUnit,sku.pkgRatio,sku.pkgBarcode,cs.onhandQty,
            CASE ISNULL(t.pcFlag,0) WHEN 0 THEN CASE cp.inventory WHEN 0 THEN cs.onhandQty WHEN 1 THEN 0.0 END 
									ELSE t.actQty END AS actQty, 
            CASE ISNULL(t.pcFlag,0) WHEN 0 THEN CASE cp.inventory WHEN 0 THEN 0.0 WHEN 1 THEN -ISNULL(cs.onhandQty,0.0) END 
									ELSE ISNULL(t.actQty,0.0)-ISNULL(cs.onhandQty,0.0) END AS difQty,
            CASE ISNULL(t.pcFlag,0) WHEN 0 THEN '未盘点' ELSE '已盘点' END pcDesc,
            ISNULL(t.pcFlag,0) pcFlag,bh.inputDate,bh.productDate,bh.expiryDate,bh.batchNo,ct.locationWay,ct.checkerName
      FROM dbo.IMS_CheckStock cs
            LEFT JOIN(SELECT a.pointId,a.companyId,a.warehouseId,b.lotNo,b.locationNo,b.itemId,SUM(b.actQty) AS actQty,1 AS pcFlag
                      FROM dbo.IMS_Check a
                            INNER JOIN dbo.IMS_CheckDetail b ON a.checkNo=b.checkNo
                      WHERE (a.billState=20 OR a.billState=30) AND a.pointId=@pointId
                      GROUP BY a.pointId,a.companyId,a.warehouseId,b.lotNo,b.locationNo,b.itemId
                     ) t ON cs.pointId=t.pointId AND cs.warehouseId=t.warehouseId AND ISNULL(cs.lotNo,'')=ISNULL(t.lotNo,'') AND ISNULL(cs.locationNo,'')=ISNULL(t.locationNo,'') AND cs.itemId=t.itemId
            INNER JOIN dbo.IMS_CheckPoint cp ON cs.pointId=cp.pointId
            INNER JOIN BAS_Item_V sku ON cs.itemId=sku.itemId
            INNER JOIN BAS_Warehouse w ON cs.warehouseId=w.warehouseId
            INNER JOIN (
						SELECT x.companyId,x.warehouseId,x.regionId,x.locationWay,y.userNick AS checkerName 
						FROM  dbo.IMS_CheckTask x 
							LEFT JOIN dbo.SAM_User y ON x.checkerId=y.userId  
						WHERE pointId=@pointId
						) ct ON ct.companyId=ct.companyId AND cs.warehouseId=ct.warehouseId AND cs.regionId=ct.regionId AND cs.locationWay=ct.locationWay
            LEFT JOIN IMS_Batch bh ON cs.companyId=bh.companyId AND cs.lotNo=bh.lotNo
      WHERE cs.pointId=@pointId  
)


go

