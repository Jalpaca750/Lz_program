--6.修改其他出库单同步视图（其他出库、调拨出库、赠品出库等）
/*==============================================================*/
/* View: WMS_F10_QTC_Stock_V                                    */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_QTC_Stock_V] as
SELECT a.stockNo AS wmsStock,a.billNo AS wmsBillNo,a.billNo AS allotNo,CONVERT(VARCHAR(10),a.createTime,23) AS createDate,
	c.deptId AS DeptNo_I,d.CodeID AS DeptNo,w.warehouseNo AS warehouse,a.orderType,'10' AS billSts,
	CONVERT(VARCHAR(10),a.auditTime,23) AS auditDate,u2.employeeID AS auditId,u1.employeeID AS creatorId,
	u3.employeeID AS printerId,a.printNum,a.mergeNo,'WMS系统出库单：' + a.billNo AS memo,a.postFee,
	a.logisticsId, a.memo AS remarks
FROM dbo.SAD_Stock a 
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	LEFT JOIN F10BMS.dbo.WMS_F10_DBCustomer_V c ON a.customerId=c.customerId
	LEFT JOIN F10BMS.dbo.WMS_F10_Department_V d ON a.deptId=d.deptId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u1 ON a.creatorId=u1.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u2 ON a.auditorId=u2.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u3 ON a.printId=u3.userId
WHERE (a.taskState>=60)									                        --复核过后
	AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2)		                        --待同步和同步出错的
	AND (a.orderType=20 OR a.orderType=32 OR a.orderType=40 OR a.orderType=50)	--调拨出库，其他出库等

go

