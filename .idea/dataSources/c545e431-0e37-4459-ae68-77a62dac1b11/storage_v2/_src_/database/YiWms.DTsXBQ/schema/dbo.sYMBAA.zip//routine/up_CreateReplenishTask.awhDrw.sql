-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2016-30-10>
-- Description:	<Description:手动生成主动补货任务V1.0>
-- Modify:      <Frank.He 2018-04-22 修正在途与已分配量Bug  V1.2.1>
-- 依赖：
--      分配策略
--      上架策略
--      补货策略
--      库存数量
--      销售出库单
--      补货表
--      对应函数(uf_GetPickLocation)
--      对应函数(uf_GetPutawayLocation)
--      目标库位在途增加，源库位已分配量增加
--      同时目标库位库位预分配记录增加
-- =============================================

CREATE PROCEDURE [dbo].[up_CreateReplenishTask] 
(
    @companyId VARCHAR(32),					--公司Id
	@creatorId VARCHAR(32)					--操作员
)
AS
BEGIN
	DECLARE @ownerId VARCHAR(32),			--业主
			@warehouseId VARCHAR(32),		--仓库
			@categoryNo VARCHAR(32),		--分类
			@brandId VARCHAR(32),			--品牌
			@calcMode INT,					--1-补充到固定值（商品最大库存）2-动态补充（最近销量为参考）
			@calcTime INT,					--参考天数
			@replenishRate DECIMAL(6,2)		--补货系数
	DECLARE @replenishId VARCHAR(32),		--补货任务Id
			@replenishNo VARCHAR(32),		--补货单编号	
			@eId VARCHAR(32),				--主商品Id		
			@itemId VARCHAR(32),			--产品Id
			@itemNo VARCHAR(32),			--产品编码
			@pkgRatio INT,					--整箱与散件的转换系数
			@sourceRegId VARCHAR(32),		--源库区
			@sourceLocNo VARCHAR(32),		--源库位
			@targetRegId VARCHAR(32),		--目的库区
			@targetLocNo VARCHAR(32),		--目的库位
			@lotNo VARCHAR(32),				--补货批次
			@pickQty DECIMAL(20,6),			--数量
			@pkgQty DECIMAL(20,6),			--件数
			@needQty DECIMAL(20,6),			--需要的数量
			@billNo VARCHAR(32),			--单据编号		
			@totalCount INT,				--序号
			@count INT,						--临时变量
			@boxCount INT
	DECLARE @startTime DATETIME,			--统计销售数据的起始日期
			@endTime DATETIME,				--统计销售数据的截止日期
			@tmpLocNo VARCHAR(32),			--临时库位变量
			@createTime DATETIME			--当前时间	
	DECLARE @pickingNo VARCHAR(32),			--分拣任务No
			@pickBillNo VARCHAR(32),		--分拣任务编号
			@pickId VARCHAR(32)				--分拣任务订单Id
			
	SET @createTime=GETDATE();
	--临时表存储
	DECLARE @tmpNeed Table (viewOrder INT IDENTITY(1,1),ownerId VARCHAR(32),warehouseId VARCHAR(32),eId VARCHAR(32),itemId VARCHAR(32),needQty DECIMAL(20,6),targetLocNo VARCHAR(32),pkgRatio INT)
	DECLARE @tmpSales TABLE(ownerId VARCHAR(32),warehouseId VARCHAR(32),eId VARCHAR(32),itemId VARCHAR(32),totalQty DECIMAL(20,6),pkgRatio INT);
	--补货下架数据
	DECLARE @tmpReplenish TABLE(warehouseId VARCHAR(32),sourceRegId VARCHAR(32),sourceLocNo varchar(32),lotNo VARCHAR(32),itemId VARCHAR(32),targetLocNo varchar(32),pickQty DECIMAL(20,6),pkgQty INT);
	--删除执行错误日志
	DELETE FROM SAM_Error WHERE companyId=@companyId AND creatorId=@creatorId AND funCode='up_CreateReplenishTask';
	--检查补货策略是否设置
	IF NOT EXISTS(SELECT 1 FROM WMS_ReplenishPolicy WHERE companyId=@companyId AND isDisable=0)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateReplenishTask','YI_REPLENISH_TASK_NON_POLICY','请您先维护补货策略！','','');
		RETURN;
	END
	--粗略检查是否设置件/箱分配策略
	IF NOT EXISTS(SELECT 1 FROM WMS_PickingPolicy WHERE companyId=@companyId AND isDisable=0 AND (unitLevel='CS')) 
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateReplenishTask','YI_REPLENISH_TASK_NON_PICKING_POLICY','请您先维护配货策略！','','');
		RETURN;
	END	
	--补货临时表
	DECLARE @replenish TABLE(warehouseId VARCHAR(32),sourceRegId VARCHAR(32),sourceLocNo varchar(32),lotNo VARCHAR(32),itemId VARCHAR(32),pickQty DECIMAL(20,6),targetRegId VARCHAR(32),targetLocNo varchar(32),pkgQty INT);
	BEGIN TRY
		BEGIN TRANSACTION
		--1.计算需要补货的产品和数量
		DECLARE myPolicy CURSOR
		FOR 	
			SELECT rp.ownerId,rp.warehouseId,ISNULL(cat.categoryNo,''),ISNULL(rp.brandId,''),rp.calcMode,rp.calcTime,rp.replenishRate
			FROM dbo.WMS_ReplenishPolicy rp
				LEFT JOIN dbo.BAS_Category cat ON rp.categoryId=cat.categoryId 
			WHERE rp.companyId=@companyId AND rp.isDisable=0
			ORDER BY rp.viewOrder
		OPEN myPolicy
		FETCH NEXT FROM myPolicy INTO @ownerId,@warehouseId,@categoryNo,@brandId,@calcMode,@calcTime,@replenishRate
		WHILE @@FETCH_STATUS=0
		BEGIN
			--2-动态补充（最近销量为参考）
			IF (@calcMode=2)
			BEGIN
				--截止时间与起始时间
				SET @endTime=CONVERT(VARCHAR(10),GETDATE(),23) + ' 00:00:00'
				SET @startTime=DATEADD(d,-@calcTime,@endTime)
				--删除临时表数据
				DELETE FROM @tmpSales;
				--统计最近几天销售数据的平均值的补货倍数						
				INSERT INTO @tmpSales(ownerId,warehouseId,eId,itemId,pkgRatio,totalQty)
				SELECT ownerId,warehouseId,eId,itemId,pkgRatio,CEILING(totalQty/@calcTime*@replenishRate)
				FROM (
						SELECT bi.ownerId,a.warehouseId,bi.eId,b.itemId,bi.pkgRatio,SUM(b.stockQty) AS totalQty 
						FROM dbo.WMS_Picking a 
							INNER JOIN dbo.WMS_PickingDetail b ON a.pickingNo=b.pickingNo  
							INNER JOIN dbo.BAS_Item_V bi ON b.itemId=bi.itemId
						WHERE (a.companyId=@companyId)	
							AND (a.warehouseId=@warehouseId)
							AND (bi.ownerId=@ownerId)
							AND (ISNULL(bi.brandId,'') LIKE @brandId + '%')
							AND (ISNULL(bi.categoryNo,'') LIKE @categoryNo + '%') 
							AND (a.taskType=0)											--散件销售
							AND (a.createTime BETWEEN @startTime AND @endTime)
						GROUP BY bi.ownerId,a.warehouseId,bi.eId,b.itemId,bi.pkgRatio
					) t
				--统计需求数量=计划补货数量-可用量
				INSERT INTO @tmpNeed(ownerId,warehouseId,eId,itemId,needQty,pkgRatio)					
				SELECT @ownerId,@warehouseId,a.eId,a.itemId,ISNULL(a.totalQty,0.0)-ISNULL(t.availQty,0.0) AS needQty,a.pkgRatio
				FROM @tmpSales a
					INNER JOIN ( --当前库存+在途库存=预计可用库存
								SELECT a.itemId,SUM(ISNULL(a.onhandQty,0.0)+ISNULL(a.onWayQty,0.0)) AS availQty 
								FROM dbo.IMS_Stock a	
									INNER JOIN BAS_Region r ON a.regionId=r.regionId								
								WHERE (a.companyId=@companyId) 
									AND (a.warehouseId=@warehouseId) 
									AND (r.isReplenished=0)
								GROUP BY a.itemId
								) t ON a.itemId=t.itemId
					INNER JOIN (
								SELECT itemId,SUM(ISNULL(onhandQty,0.0)-ISNULL(a.allocQty,0.0)) AS sourceQty
								FROM dbo.IMS_Stock a 
									INNER JOIN dbo.BAS_Region r ON a.regionId=r.regionId
								WHERE (a.companyId=@companyId) 
									AND (a.warehouseId=@warehouseId)
									AND (r.isReplenished=1)
								GROUP BY a.itemId
								HAVING SUM(onhandQty)>0.0
							   ) s ON a.itemId=s.itemId
				WHERE ISNULL(a.totalQty,0.0)-ISNULL(t.availQty,0.0)>0.0
			END
			
			FETCH NEXT FROM myPolicy INTO @ownerId,@warehouseId,@categoryNo,@brandId,@calcMode,@calcTime,@replenishRate
		END
		CLOSE myPolicy
		DEALLOCATE myPolicy
		--清除临时销售表
		DELETE FROM @tmpSales;
		--如果没有需要补货的记录
		IF NOT EXISTS(SELECT 1 FROM @tmpNeed)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateReplenishTask','YI_REPLENISH_TASK_NON_NEED','没有需要补货的数据！','','');
			COMMIT;
			RETURN;
		END
		--检查补货数据基础资料是否齐全
		IF EXISTS(SELECT 1 FROM BAS_Item WHERE itemId=ANY(SELECT itemId FROM @tmpNeed) AND pkgRatio=0)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateReplenishTask','YI_REPLENISH_TASK_NON_RATIO','补货商品包装数量未设置！','','');
			COMMIT;
			RETURN;
		END
		--2.写入补货任务表，并生成补货
		--补货任务编号
		EXEC up_CreateCode @companyId,'IMS_Replenish',@creatorId,@replenishNo OUTPUT;
		DECLARE myTask CURSOR
		FOR 	
			SELECT ownerId,warehouseId,eId,itemId,needQty,pkgRatio
			FROM @tmpNeed
			ORDER BY viewOrder
		OPEN myTask
		FETCH NEXT FROM myTask INTO @ownerId,@warehouseId,@eId,@itemId,@needQty,@pkgRatio
		WHILE @@FETCH_STATUS=0
		BEGIN			
			--补货量
			SET @pickQty=CEILING(@needQty/@pkgRatio)*@pkgRatio;
			--补货数据下架数据
			DELETE FROM @tmpReplenish;
			INSERT INTO @tmpReplenish(warehouseId,sourceRegId,sourceLocNo,lotNo,itemId,pickQty,pkgQty)
			SELECT warehouseId,regionId,locationNo,lotNo,itemId,pickQty,pickQty/@pkgRatio
			FROM dbo.uf_GetPickLocation(@companyId,@warehouseId,@ownerId,@itemId,@pickQty,'CS',0)						
			--如果没有补货数据产生,则跳过补货产品
			IF NOT EXISTS(SELECT 1 FROM @tmpReplenish) 
			BEGIN
				INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
				VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateReplenishTask','YI_REPLENISH_TASK_NON_QTY','商品[ ' + @itemNo + ' ]整箱库存不足！','','');
				FETCH NEXT FROM myTask INTO @ownerId,@warehouseId,@eId,@itemId,@needQty,@pkgRatio
				CONTINUE;
			END
			--循环补货列表
			DECLARE myReplenish CURSOR
			FOR 	
				SELECT sourceRegId,sourceLocNo,lotNo,pickQty,pkgQty
				FROM @tmpReplenish
			OPEN myReplenish
			FETCH NEXT FROM myReplenish INTO @sourceRegId,@sourceLocNo,@lotNo,@pickQty,@pkgQty
			WHILE @@FETCH_STATUS=0
			BEGIN	
				--目标库位
				SELECT @tmpLocNo=dbo.uf_GetPutawayLocation(@companyId,@ownerId,@warehouseId,@itemId,'',@pickQty,@lotNo,0,'EA');
				--目标库区
				SELECT @targetRegId=regionId 
				FROM BAS_Location 
				WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@tmpLocNo;
				--补货任务Id
				SET @replenishId=REPLACE(NEWID(),'-','');
				--写入补货任务表
				INSERT INTO IMS_Replenish(replenishId,companyId,replenishDate,billNo,replenishType,sourceWhId,sourceRegId,
					sourceLocNo,lotNo,targetWhId,targetRegId,targetLocNo,itemId,replenishQty,pkgQty,ioState,createTime,creatorId)
				VALUES(@replenishId,@companyId,@createTime,@replenishNo,1,@warehouseId,@sourceRegId,@sourceLocNo,
					@lotNo,@warehouseId,@targetRegId,@tmpLocNo,@itemId,@pickQty,@pkgQty,10,GETDATE(),@creatorId);
				--写入预分配表
				INSERT INTO IMS_Allocate(allocId,stockId,stockNo,companyId,warehouseId,regionId,locationNo,lotNo,itemId,allocQty,unitLevel,ioFlag)
				VALUES(@replenishId,@replenishId,@replenishId,@companyId,@warehouseId,@targetRegId,@tmpLocNo,@lotNo,@itemId,@pickQty,'EA','+');
				FETCH NEXT FROM myReplenish INTO @sourceRegId,@sourceLocNo,@lotNo,@pickQty,@pkgQty
			END
			CLOSE myReplenish
			DEALLOCATE myReplenish		
			FETCH NEXT FROM myTask INTO @ownerId,@warehouseId,@eId,@itemId,@needQty,@pkgRatio
		END
		CLOSE myTask
		DEALLOCATE myTask

		--写入补货下架任务表
		--3.分拣订单,每个单品一个任务	
		IF EXISTS(SELECT 1 FROM IMS_Replenish WHERE companyId=@companyId AND billNo=@replenishNo)
		BEGIN
			DECLARE myTask CURSOR 
			FOR 
				SELECT a.replenishId,a.sourceWhId,a.sourceRegId,a.sourceLocNo,a.itemId,a.lotNo,a.pkgQty,a.replenishQty,b.pkgRatio
				FROM IMS_Replenish a INNER JOIN BAS_Item b ON a.itemId=b.itemId
				WHERE a.companyId=@companyId AND a.billNo=@replenishNo
			OPEN myTask
			FETCH NEXT FROM myTask INTO @replenishId,@warehouseId,@sourceRegId,@sourceLocNo,@itemId,@lotNo,@pkgQty,@pickQty,@pkgRatio
			WHILE @@FETCH_STATUS=0
			BEGIN
				SET @pickingNo=REPLACE(NEWID(),'-','');
				--创建任务单据编号
				EXEC up_CreateCode @companyId,'WMS_Picking',@creatorId,@billNo OUTPUT;
				--写入分拣任务taskType:0-散件;1-整箱;2-补货
				INSERT INTO WMS_Picking(pickingNo,companyId,billNo,waveNo,waveBillNo,warehouseId,regionId,taskType,sizeId,boxNumber,taskState,createTime,editTime,creatorId,editorId)  
				VALUES(@pickingNo,@companyId,@billNo,'','',@warehouseId,@sourceRegId,2,'-1',0,0,@createTime,@createTime,@creatorId,@creatorId);
				--需要下架的数量
				WHILE @pickQty>0.0
				BEGIN
					SET @pickId=REPLACE(NEWID(),'-','');
					INSERT INTO WMS_PickingOrder(pickId,pickingNo,companyId,stockNo,stockBillNo,stockBox,boxId,boxOrder,isPackage,pkgQty,lclQty,pickerId,taskState)
					VALUES(@pickId,@pickingNo,@companyId,@replenishId,@replenishNo,@boxCount,'',@boxCount,1,@pkgQty,0.0,'',0);
					--写入分拣任务订单明细表(WMS_PickingDetail)
					--如果补货数量不足一个包装	
					IF (@pickQty-@pkgRatio>0.0)				
						INSERT INTO WMS_PickingDetail(pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,itemId,
							isPackage,pickState,stockQty,pickQty,realQty,actualQty,boxId,boxOrder,stockId,stockNo,stockBillNo)					
						VALUES(REPLACE(NEWID(),'-',''),@pickId,@pickingNo,@companyId,@warehouseId,@sourceRegId,@lotNo,@sourceLocNo,@itemId,
							1,0,1.0,1.0,@pkgRatio,0.0,'',@boxCount,@replenishId,@replenishId,@replenishNo) 
					ELSE
						INSERT INTO WMS_PickingDetail(pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,itemId,
							isPackage,pickState,stockQty,pickQty,realQty,actualQty,boxId,boxOrder,stockId,stockNo,stockBillNo)					
						VALUES(REPLACE(NEWID(),'-',''),@pickId,@pickingNo,@companyId,@warehouseId,@sourceRegId,@lotNo,@sourceLocNo,@itemId,
							1,0,1.0,1.0,@pickQty,0.0,'',@boxCount,@replenishId,@replenishId,@replenishNo)   
					--累加计数器
					SET @pickQty=@pickQty-@pkgRatio
				END
				FETCH NEXT FROM myTask INTO @replenishId,@warehouseId,@sourceRegId,@sourceLocNo,@itemId,@lotNo,@pkgQty,@pickQty,@pkgRatio
			END 
			CLOSE myTask
			DEALLOCATE myTask			
		END

		--更新目标库位在途量
        UPDATE a SET a.onWayQty=ISNULL(a.onWayQty,0.0)+ISNULL(b.replenishQty,0.0)
        FROM dbo.IMS_Stock a 
            INNER JOIN (SELECT targetWhId,ISNULL(lotNo,'') AS lotNo,ISNULL(targetLocNo,'') AS targetLocNo,itemId,SUM(replenishQty) AS replenishQty
                        FROM dbo.IMS_Replenish
                        WHERE companyId=@companyId AND billNo=@replenishNo
                        GROUP BY targetWhId,lotNo,targetLocNo,itemId
                        ) b ON a.companyId=@companyId AND a.warehouseId=b.targetWhId AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.targetLocNo,'') AND a.itemId=b.itemId;
		--目标库位记录不存在，则增加一条记录（在途）
		INSERT INTO IMS_Stock(stockId,companyId,warehouseId,regionId,locationNo,lotNo,eId,itemId,onhandQty,allocQty,onWayQty)
		SELECT REPLACE(NEWID(),'-',''),companyId,targetWhId,targetRegId,targetLocNo,lotNo,eId,itemId,0.0,0.0,replenishQty
		FROM (
		    SELECT companyId,targetWhId,targetRegId,ISNULL(lotNo,'') AS lotNo,ISNULL(targetLocNo,'') AS targetLocNo,eId,itemId,SUM(replenishQty) AS replenishQty
            FROM dbo.IMS_Replenish
            WHERE companyId=@companyId AND billNo=@replenishNo
            GROUP BY companyId,targetWhId,targetRegId,lotNo,targetLocNo,eId,itemId
            ) b 
		WHERE NOT EXISTS(SELECT 1 FROM IMS_Stock a WHERE a.companyId=b.companyId AND a.warehouseId=b.targetWhId AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.targetLocNo,'') AND a.itemId=b.itemId);
			
		--更新源库位已分配量
		UPDATE a SET a.allocQty=ISNULL(a.allocQty,0.0)+ISNULL(b.replenishQty,0.0)
        FROM dbo.IMS_Stock a 
            INNER JOIN (SELECT companyId,sourceWhId,ISNULL(lotNo,'') AS lotNo, ISNULL(sourceLocNo,'') AS sourceLocNo,itemId,SUM(replenishQty) AS replenishQty
                        FROM dbo.IMS_Replenish
                        WHERE companyId=@companyId AND billNo=@replenishNo
                        GROUP BY companyId,sourceWhId,lotNo,sourceLocNo,itemId
                        ) b ON a.companyId=b.companyId AND a.warehouseId=b.sourceWhId AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.sourceLocNo,'') AND a.itemId=b.itemId;
		
		COMMIT
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END CATCH
END

go

