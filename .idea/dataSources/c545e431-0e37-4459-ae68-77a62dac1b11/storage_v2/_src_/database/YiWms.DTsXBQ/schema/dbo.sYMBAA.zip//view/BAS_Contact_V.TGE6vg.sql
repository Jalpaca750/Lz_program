
/*==============================================================*/
/* View: BAS_Contact_V                                          */
/*==============================================================*/
--creator：        Frank
--create time：  2016-11-10
--客商联系人视图
create view BAS_Contact_V as
SELECT c.contactId,c.companyId,c.partnerId,p.partnerNo,p.partnerName,p.shortName,p.partnerSpell,
      c.contactName,c.sex,c.contactTitle,c.officeTel,c.mobileNo,c.email,c.education,c.interest,
      c.ages,c.partnerType,c.isDefault,CASE c.isDefault WHEN 1 THEN '是' ELSE '否' END AS defaultFlag,
      c.isDisable,CASE c.isDisable WHEN 1 THEN '是' ELSE '否' END AS disableName,c.isLocked,c.lockerId,
      u1.userNick AS lockerName,CONVERT(VARCHAR(10),c.lockedTime,23) AS lockedTime,c.createTime,
      c.creatorId,u2.userNick AS creatorName,c.editTime,c.editorId,u3.userNick AS editorName,c.isSelected
FROM dbo.BAS_Contact c INNER JOIN 
      dbo.BAS_Partner p ON c.partnerId=p.partnerId LEFT JOIN
      dbo.SAM_User u1 ON c.lockerId=u1.userId LEFT JOIN
      dbo.SAM_User u2 ON c.creatorId=u2.userId LEFT JOIN
      dbo.SAM_User u3 ON c.editorId=u3.userId
go

