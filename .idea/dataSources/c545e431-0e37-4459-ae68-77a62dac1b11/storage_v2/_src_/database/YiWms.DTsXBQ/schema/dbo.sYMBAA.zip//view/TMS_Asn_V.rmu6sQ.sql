/*==============================================================*/
/* View: TMS_Asn_V                                              */
/*==============================================================*/
CREATE view [dbo].[TMS_Asn_V] as
--WMS能装的单据85-未发货
SELECT a.companyId,a.stockNo,a.billNo,a.taskState,a.aFlag,ISNULL(a.aStockNo,'') AS aStockNo,
    orderType AS billType,a.logisticsId,a.receiverAddress,b.partnerName AS CustomerName 
FROM dbo.SAD_Stock a 
    INNER JOIN dbo.BAS_Partner b ON a.customerId=b.partnerId
WHERE (a.taskState=70 OR a.taskState=80 OR a.taskState=96)
UNION ALL
--销售退货单
SELECT '4CBF34539DF1496D8DB283B49B2DE1D5',a.ReturnNo,a.ReturnNo,70 AS taskState,0,'',60,'',
    a.SendAddr,b.CustName 
FROM F10BMS.dbo.SMS_Return a
    INNER JOIN F10BMS.dbo.BDM_Customer b ON a.CustID=b.CustID
WHERE (a.DeptNo='1235')
	AND (ISNULL(a.CarNumberSts,'')='')
UNION ALL
--销售发票
SELECT '4CBF34539DF1496D8DB283B49B2DE1D5',CAST(a.InvoiceID AS VARCHAR(32)) AS billNo,a.InvoiceNo,70 AS taskState,0,'',70,'',
    a.SendAddr,b.CustName
FROM F10BMS.dbo.SMS_Invoice a
    INNER JOIN F10BMS.dbo.BDM_Customer b ON a.CustID=b.CustID
WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30')
	AND (ISNULL(a.CarNumberSts,'')='') 
UNION ALL
--项目单
SELECT '4CBF34539DF1496D8DB283B49B2DE1D5',CAST(a.BillID AS VARCHAR(32)) AS billNo,a.BillNo,70 taskState,0,'',90,'',
   a.SendAddr,b.CustName
FROM F10BMS.dbo.PRJ_Order a
    INNER JOIN F10BMS.dbo.BDM_Customer b ON a.CustID=b.CustID
WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30')
	AND (ISNULL(a.CarNumberSts,'')='')
UNION ALL
--南大出库单
SELECT '4CBF34539DF1496D8DB283B49B2DE1D5',a.StockNo,a.StockNo,70 taskState,0,'',80,a.logisticsId,
    a.SendAddr,b.CustName
FROM F10BMS.dbo.SMS_Stock a
    INNER JOIN F10BMS.dbo.BDM_Customer b ON a.CustID=b.CustID
WHERE (a.DeptNo='1573')
	AND (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30')
	AND (ISNULL(a.CarNumberSts,'')='')
UNION ALL
--佰仗
SELECT '4CBF34539DF1496D8DB283B49B2DE1D5',a.StockNo,a.StockNo,70 taskState,0,'',80,a.logisticsId,
    a.SendAddr,b.CustName
FROM F10BMS.dbo.SMS_Stock a
    INNER JOIN F10BMS.dbo.BDM_Customer b ON a.CustID=b.CustID
WHERE (a.DeptNo='1363')
	AND (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30')
	AND (ISNULL(a.CarNumberSts,'')='')
go

