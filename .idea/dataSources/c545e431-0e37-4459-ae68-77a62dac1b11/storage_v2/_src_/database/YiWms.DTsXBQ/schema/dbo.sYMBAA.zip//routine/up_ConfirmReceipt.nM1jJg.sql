-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-08-04>
-- Description:	<Description:回单确认>
-- Parameter:
--		@companyId:公司Id
--		@siteId: 网点Id
--      @stockNo:出库单Id
--      @billNo: 出库单编号
--      @operatorId:操作员Id
-- =============================================
CREATE PROCEDURE [dbo].[up_ConfirmReceipt] 
(
	@companyId VARCHAR(32),			--公司Id
	@siteId VARCHAR(32),			--网点Id
    @stockNo VARCHAR(32),			--出单Id
	@billNo VARCHAR(32),			--出库单编号
	@operatorId VARCHAR(32)			--操作员Id
)
AS
BEGIN
	DECLARE @curTime DATETIME,@hasTms INT,@waybillId VARCHAR(32),@deliveryId VARCHAR(32),@withF10 VARCHAR(200),@errors BIGINT,@sql VARCHAR(1000);
	--和F10对接
	SELECT @withF10=ISNULL(configValue,'0') 
	FROM SAM_Config 
	WHERE companyId=@companyId AND configCode='WITH_F10_INTERFACE_START';	
	SET @curTime=GETDATE();
	--是否有获得Tms产品授权
	IF EXISTS(SELECT 1 FROM SAM_CompanyProduct WHERE companyId=@companyId AND productCode='YFP0006') 
		SET @hasTms=1;
	ELSE
		SET @hasTms=0;
	DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='up_ConfirmReceipt' AND billId=@stockNo;
	BEGIN TRY
		BEGIN TRANSACTION
		--排队等待解锁
		WHILE EXISTS(SELECT * FROM SAM_Schedule WHERE jobCode='tm_back_job' AND isLocked=1)
		BEGIN
		    SET @errors=0;
		END
		--锁定
		UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='up_ConfirmReceipt' WHERE jobCode='tm_back_job';
        IF (@hasTms=1 AND ISNULL(@siteId,'')='')
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_ConfirmReceipt','YI_CONFIRM_RETURN_BILL_ERROR','当前登陆用户未设置配送站点',@stockNo,@billNo);		
			--解锁
			UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='tm_back_job';
			COMMIT;
			RETURN;
		END	
		IF EXISTS(SELECT 1 FROM dbo.SAD_Stock WHERE stockNo=@stockNo)
		BEGIN
			IF EXISTS(SELECT 1 FROM dbo.SAD_Stock WHERE stockNo=@stockNo AND taskState<90)
			BEGIN
				INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
				VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_ConfirmReceipt','YI_CONFIRM_RETURN_BILL_ERROR','单据[' + @billNo + ']尚未发货，操作无效',@stockNo,@billNo);		
				--解锁
			    UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='tm_back_job';
				COMMIT;
				RETURN;
			END			
			--更新出库单
			UPDATE dbo.SAD_Stock SET taskState=99,isReceipt=1,backerId=@operatorId,receiptTime=@curTime,editTime=@curTime,editorId=@operatorId 
			WHERE stockNo=@stockNo AND isReceipt=0; 
			IF(@@ROWCOUNT>0 AND ISNULL(@withF10,'0')='1')
			BEGIN				
				--更新F10出库单状态
				SET @sql='UPDATE F10BMS.dbo.SMS_Stock SET BackDate=''' + CONVERT(VARCHAR(20),@curTime,120) + ''' WHERE StockNo=''' + @billNo + '''';
				EXEC (@sql)
				--UPDATE F10BMS.dbo.SMS_Stock SET BackDate=CONVERT(VARCHAR(20),@curTime,120) WHERE StockNo=@billNo; 
			END	
		END
		ELSE
		BEGIN
		    IF (ISNULL(@withF10,'0')='1')
		    BEGIN
		        SET @sql='UPDATE F10BMS.dbo.PRJ_Order SET BackDate=''' + CONVERT(VARCHAR(20),@curTime,120) + ''' WHERE BillNo=''' + @billNo + ''';';
				EXEC (@sql)
				SET @sql='UPDATE F10BMS.dbo.SMS_Invoice SET BackDate=''' + CONVERT(VARCHAR(20),@curTime,120) + ''' WHERE InvoiceNo=''' + @billNo + ''';';
				EXEC (@sql)
			END
		END	
		--TMS部分操作
		IF (@hasTms=1)
		BEGIN
			SELECT @deliveryId=deliveryId FROM SAD_Stock WHERE stockNo=@stockNo;
			--更新运单为
			UPDATE dbo.TMS_WayBill SET billState=99 WHERE companyId=@companyId AND waybillNo=@billNo AND wmsStockNo=@stockNo;
			IF(@@ROWCOUNT>0)
			BEGIN
				--查找当前单据对应的运单
				SELECT @waybillId=waybillId
				FROM dbo.TMS_WayBill
				WHERE companyId=@companyId AND waybillNo=@billNo AND wmsStockNo=@stockNo;
				--写入站点状态表
				--wayState:10-揽件;20-发件;30-收件;40-派件;80-留仓;90-妥投;99-回单
				INSERT INTO TMS_WaySite(wayId,waybillId,companyId,siteId,wayState,wayUserId,typeId,reasonId,nextSite,
					isLocked,lockerId,lockedTime,createTime,creatorId,editTime,editorId)
				SELECT LOWER(REPLACE(NEWID(),'-','')),@waybillId,@companyId,@siteId,99,@deliveryId,'','','-1',0,'',NULL,
					GETDATE(),@operatorId,GETDATE(),@operatorId
				WHERE NOT EXISTS(SELECT 1 FROM dbo.TMS_WaySite WHERE waybillId=@waybillId AND wayState=99);
			END
		END
		--解锁
        UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='tm_back_job';
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_ConfirmReceipt','YI_CONFIRM_RETURN_BILL_ERROR',LEFT(@ErrMsg,2000),@stockNo,@billNo);		
		UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='tm_back_job';
		SELECT -1;			
	END CATCH
END
go

