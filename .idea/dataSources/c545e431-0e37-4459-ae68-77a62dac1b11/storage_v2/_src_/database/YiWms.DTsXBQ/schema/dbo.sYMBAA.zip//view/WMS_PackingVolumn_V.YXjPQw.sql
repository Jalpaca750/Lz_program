CREATE view [dbo].[WMS_PackingVolumn_V] as
SELECT packNo,SUM(ISNULL(a.packQty,0.0)*ISNULL(b.itemVolume,0.0)) AS lclVolumn,
	SUM(ISNULL(a.packQty,0.0)*ISNULL(b.itemWeight,0.0)) AS lclWeight
FROM dbo.WMS_PackingDetail a
	INNER JOIN dbo.BAS_Item b ON a.itemId=b.itemId
GROUP BY packNo
go

