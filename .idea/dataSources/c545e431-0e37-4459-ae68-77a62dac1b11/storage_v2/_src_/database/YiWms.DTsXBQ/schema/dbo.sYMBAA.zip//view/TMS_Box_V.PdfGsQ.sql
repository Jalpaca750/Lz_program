/*==============================================================*/
/* View: TMS_Box_V                                              */
/* 2019-06-27 Frank 修正部分装车Bug                             */
/*==============================================================*/
CREATE view [dbo].[TMS_Box_V] as
SELECT LOWER(REPLACE(NEWID(),'-','')) AS boxId,stockNo,stockBillNo,CAST(boxBillNum AS VARCHAR(32)) boxBillNum,isPackage
FROM WMS_PickingOrder
WHERE isPackage=1 AND (shipState=0 OR shipState=10 OR shipState=20)
UNION ALL
SELECT LOWER(REPLACE(NEWID(),'-','')) AS boxId,stockNo,stockBillNo,boxBillNum,0 AS isPackage
FROM WMS_Packing
WHERE packState=10 OR packState=45 OR packState=50
go

