

CREATE FUNCTION [dbo].[uf_GetInvFrequency]
(
    @companyId VARCHAR(32),				        --公司Id
	@startTime DATETIME,						--起始日期
	@endTime DATETIME							--截至日期
)
RETURNS @uTable TABLE
(
	ownerId VARCHAR(32),
	ownerNo VARCHAR(32),
	ownerName VARCHAR(200),
	ownerShortName VARCHAR(200),
	itemId VARCHAR(32),
	itemNo VARCHAR(32),
	itemCTitle VARCHAR(200),
	itemETitle VARCHAR(200),
	itemName VARCHAR(200),
	itemSpec VARCHAR(100),
	itemSpell VARCHAR(200),
	sellingPoint VARCHAR(200),
	barcode VARCHAR(100),
	midBarcode VARCHAR(100),
	bigBarcode VARCHAR(100),
	pkgBarcode VARCHAR(100),
	brandId VARCHAR(32),
	brandNo VARCHAR(32),
	brandCName VARCHAR(200),	
	categoryId VARCHAR(32),
	categoryNo VARCHAR(32),
	categoryCName VARCHAR(200),
	colorName VARCHAR(100),
	sizeName VARCHAR(100),
	packageId VARCHAR(32) ,
	unitName VARCHAR(100),
	itemWeight DECIMAL(10,4),
	itemVolume DECIMAL(20,3),
	pkgUnit VARCHAR(100),
	pkgRatio INT,
	billCount INT,
	totalQty DECIMAL(20,6),
	bulkQty DECIMAL(20,6),
	pkgQty DECIMAL(20,6),
	dayCount INT,
	bulkCount INT,
	pkgCount INT,
	dayAvgQty DECIMAL(20,6),			--平均每天销量
	billAvgQty  DECIMAL(20,6),			--平均每单销量
	avgDayCount  DECIMAL(20,6),			--平均每天单数
	bulkAvgDayQty DECIMAL(20,6),		--平均每天散件数量
	bulkAvgDayCount DECIMAL(20,6),		--平均每天散件次数
	bulkAvgQty DECIMAL(20,6),			--平均每次散件数
	pkgAvgDayQty DECIMAL(20,6),			--平均每天整件数量
	pkgAvgDayCount DECIMAL(20,6),		--平均每天整件次数
	pkgAvgQty DECIMAL(20,6),			--平均每次整件数量
	itemState INT
)
AS 
BEGIN
	DECLARE @days INT;
	DECLARE @sales TABLE(stockId VARCHAR(32),ownerId VARCHAR(32),stockNo VARCHAR(32),createDate VARCHAR(10),itemId VARCHAR(32),stockQty DECIMAL(20,6) PRIMARY KEY(stockId));
	DECLARE @item TABLE(ownerId VARCHAR(32),itemId VARCHAR(32),billCount INT,totalQty DECIMAL(20,6),bulkQty DECIMAL(20,6),pkgQty DECIMAL(20,6),dayCount INT,bulkCount INT,pkgCount INT PRIMARY KEY(itemId));
	SET @days=DATEDIFF(d,@startTime,@endTime) + 1;
	--待复核的销售数据
	INSERT INTO @sales(stockId,ownerId,stockNo,createDate,itemId,stockQty)
	SELECT b.stockId,a.ownerId,a.stockNo,CONVERT(VARCHAR(10),a.createTime,23),b.itemId,b.stockQty
	FROM dbo.SAD_Stock a
		INNER JOIN dbo.SAD_StockDetail b ON a.stockNo=b.stockNo
	WHERE (a.companyId=@companyId)
		AND (a.createTime BETWEEN @startTime AND @endTime)  
		AND (a.taskState>40);
	--计算商品总销售量、散件出货量、整件出货量、订单数，天数、散件分拣次数，整件分拣次数
	INSERT INTO @item(ownerId,itemId,totalQty,bulkQty,pkgQty,billCount,dayCount,bulkCount,pkgCount)
	SELECT a.ownerId,a.itemId,SUM(a.stockQty) AS orderQty,SUM(CASE b.isPackage WHEN 0 THEN b.pickQty ELSE 0.0 END) AS bulkQty,
		SUM(CASE b.isPackage WHEN 1 THEN b.pickQty*b.pkgRatio ELSE 0.0 END) AS pkgQty,COUNT(DISTINCT a.stockNo) AS skuCount,
		COUNT(DISTINCT createDate) AS dayCount,SUM(CASE b.isPackage WHEN 0 THEN 1 ELSE 0 END) AS bulkCount,
		SUM(CASE b.isPackage WHEN 1 THEN 1 ELSE 0 END) AS pkgCount
	FROM @sales a 
		INNER JOIN dbo.WMS_PickingDetail b ON a.stockId=b.stockId
	GROUP BY a.ownerId,a.itemId; 
	--计算billAvgQty-平均每单数量;dayAvgQty-平均每天销量；
	INSERT INTO @uTable(itemId,itemNo,itemCTitle,itemETitle,itemName,itemSpec,itemSpell,sellingPoint,barcode,
		midBarcode,bigBarcode,pkgBarcode,brandId,brandNo,brandCName,categoryId,categoryNo,categoryCName,
		colorName,sizeName,unitName,packageId,pkgRatio,pkgUnit,itemVolume,itemWeight,itemState,ownerId,
		ownerNo,ownerName,ownerShortName,billCount,totalQty,dayCount,bulkQty,bulkCount,pkgQty,pkgCount,
		dayAvgQty,billAvgQty,avgDayCount,bulkAvgDayQty,bulkAvgDayCount,bulkAvgQty,pkgAvgDayQty,pkgAvgDayCount,
		pkgAvgQty)
	SELECT a.itemId,bi.itemNo,bi.itemCTitle,bi.itemETitle,bi.itemName,bi.itemSpec,bi.itemSpell,bi.sellingPoint,
		bi.barcode,bi.midBarcode,bi.bigBarcode,bi.pkgBarcode,bi.brandId,bi.brandNo,bi.brandCName,bi.categoryId,
		bi.categoryNo,bi.categoryCName,bi.colorName,bi.sizeName,bi.unitName,bi.packageId,bi.pkgRatio,bi.pkgUnit,
		bi.itemVolume,bi.itemWeight,bi.itemState,a.ownerId,o.partnerNo AS ownerNo,o.partnerName AS ownerName,
		o.shortName AS ownerShortName,a.billCount,a.totalQty,a.dayCount,a.bulkQty,a.bulkCount,a.pkgQty,a.pkgCount,
		a.totalQty/@days AS dayAvgQty,																--平均每天销量
		a.totalQty/a.billCount AS billAvgQty,														--平均每单销量
		a.billCount/@days AS avgDayCount,															--平均每天单数
		a.bulkQty/@days AS bulkAvgDayQty,															--平均每天散件数量
		a.bulkCount/(@days+0.0) AS bulkAvgDayCount,														--平均每天散件次数
		CASE ISNULL(a.bulkCount,0) WHEN 0 THEN 0.0 ELSE a.bulkQty/a.bulkCount END AS bulkAvgQty,	--平均每次散件数
		a.pkgQty/@days AS pkgAvgDayQty,																--平均每天整件数量
		a.pkgCount/(@days+0.0) AS pkgAvgDayCount,															--平均每天整件次数
		CASE ISNULL(a.pkgCount,0) WHEN 0 THEN 0.0 ELSE a.pkgQty/a.pkgCount END AS pkgAvgQty			--平均每次整件数量
	FROM @item a 
		INNER JOIN dbo.BAS_Goods_V bi ON a.itemId=bi.itemId
		INNER JOIN dbo.BAS_Partner o ON a.ownerId=o.partnerId;
	RETURN;
END
go

