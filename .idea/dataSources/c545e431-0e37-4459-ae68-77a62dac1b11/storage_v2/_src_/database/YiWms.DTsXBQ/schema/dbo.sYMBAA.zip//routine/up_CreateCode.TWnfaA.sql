-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2016-12-06>
-- Description:	<Description:根据编码策略生成系统编号>
-- 编码策略：目前支持以下编码策略
--		1 -公司编码 + 前缀 + 日期 + 5位流水
--		2 -公司编码 + 前缀 + 日期 + 4位流水 
--		3 -公司编码 + 前缀 + 起始编号 + 流水
--		8 -公司编码 + 起始编号 + 流水
--		9 -公司编码 + 前缀 + 8位流水
--		10-公司编码 + 前缀 + 7位流水
--		11-公司编码 + 前缀 + 6位流水
--		4 -前缀 + 起始编号 + 流水
--		5 -前缀 + 日期 + 5位流水
--		6 -前缀 + 日期 + 4位流水	
--		7 -起始编号 + 流水
-- =============================================
CREATE PROCEDURE [dbo].[up_CreateCode] 
(
    @companyId VARCHAR(32),
	@billCode VARCHAR(32),
	@creatorId VARCHAR(32),
	@billNo VARCHAR(32) OUT
)
AS
BEGIN
	BEGIN TRY
		BEGIN TRAN
		WHILE EXISTS(SELECT 1 FROM dbo.SAM_BillType WHERE companyId=@companyId AND billCode=@billCode AND isLocked=0)
		BEGIN
			UPDATE dbo.SAM_BillType SET isLocked=1 WHERE companyId=@companyId AND billCode=@billCode;
		END
		DECLARE @companyNo VARCHAR(32),@codeRule INT,@prefix VARCHAR(40),@link VARCHAR(1),@startNum INT
		DECLARE @tmpPrefix VARCHAR(40),@flowId VARCHAR(32),@flowNum INT
		SET @flowId=REPLACE(NEWID(),'-','');
		--取得公司编码
		SELECT @companyNo=companyNo FROM SAM_Company WHERE companyId=@companyId
		--取得编码规则
		SELECT @codeRule=codeRule,@prefix=prefix,@link=link,@startNum=startNum
		FROM SAM_BillType
		WHERE companyId=@companyId AND billCode=@billCode
		--1 -公司编码 + 前缀 + 日期 + 5位流水
		--2 -公司编码 + 前缀 + 日期 + 4位流水 
		--3 -公司编码 + 前缀 + 起始编号 + 流水
		--8 -公司编码 + 起始编号 + 流水
		--9 -公司编码 + 前缀 + 8位流水
		--10-公司编码 + 前缀 + 7位流水
		--11-公司编码 + 前缀 + 6位流水
		--4 -前缀 + 起始编号 + 流水
		--5 -前缀 + 日期 + 5位流水
		--6 -前缀 + 日期 + 4位流水
		--7 -起始编号 + 流水
		IF ISNULL(@codeRule,1)=1 OR ISNULL(@codeRule,1)=2
			SET @tmpPrefix=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+ISNULL(@link,'')+CONVERT(VARCHAR(6),GETDATE(),12)+ISNULL(@link,'')      
		IF ISNULL(@codeRule,1)=3
			SET @tmpPrefix=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+ISNULL(@link,'')+CAST(@startNum AS VARCHAR)+ISNULL(@link,'')
		IF ISNULL(@codeRule,1)=4
			SET @tmpPrefix=ISNULL(@prefix,'')+ISNULL(@link,'')+CAST(@startNum AS VARCHAR)+ISNULL(@link,'')
		IF ISNULL(@codeRule,1)=5 OR ISNULL(@codeRule,1)=6
			SET @tmpPrefix=ISNULL(@prefix,'')+ISNULL(@link,'')+CONVERT(VARCHAR(6),GETDATE(),12)+ISNULL(@link,'')
		IF ISNULL(@codeRule,1)=7
			SET @tmpPrefix=CAST(@startNum AS VARCHAR)+ISNULL(@link,'')
		IF ISNULL(@codeRule,1)=8
			SET @tmpPrefix=ISNULL(@companyNo,'')+ISNULL(@link,'')+CAST(@startNum AS VARCHAR)+ISNULL(@link,'')
		IF ISNULL(@codeRule,1)=9 OR ISNULL(@codeRule,1)=10 OR ISNULL(@codeRule,1)=11
			SET @tmpPrefix=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+ISNULL(@link,'')
		--生成新编号
		INSERT INTO SAM_Coding(flowId,prefix,flowNum,companyId,billCode,creatorId,createTime)
		SELECT @flowId,@tmpPrefix,ISNULL(MAX(flowNum),0) + 1,@companyId,@billCode,@creatorId,GETDATE()
		FROM SAM_Coding
		WHERE companyId=@companyId AND billCode=@billCode AND prefix=@tmpPrefix
		--获取流水号
		SELECT @flowNum=flowNum FROM SAM_Coding WHERE flowId=@flowId
		--生产新的编号
		--1 -公司编码 + 前缀 + 日期 + 5位流水
		--2 -公司编码 + 前缀 + 日期 + 4位流水 
		--3 -公司编码 + 前缀 + 起始编号 + 流水
		--8 -公司编码 + 起始编号 + 流水
		--9 -公司编码 + 前缀 + 8位流水
		--10-公司编码 + 前缀 + 7位流水
		--11-公司编码 + 前缀 + 6位流水
		--4 -前缀 + 起始编号 + 流水
		--5 -前缀 + 日期 + 5位流水
		--6 -前缀 + 日期 + 4位流水
		--7 -起始编号 + 流水
		IF ISNULL(@codeRule,1)=1 
			SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+ISNULL(@link,'')+CONVERT(VARCHAR(6),GETDATE(),12)+ISNULL(@link,'')+RIGHT('00000' + CAST(@flowNum AS VARCHAR),5)      
		IF ISNULL(@codeRule,1)=2
			SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+ISNULL(@link,'')+CONVERT(VARCHAR(6),GETDATE(),12)+ISNULL(@link,'')+RIGHT('0000' + CAST(@flowNum AS VARCHAR),4)      
		IF ISNULL(@codeRule,1)=3
			SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+ISNULL(@link,'')+CAST((@startNum + @flowNum) AS VARCHAR) 
		IF ISNULL(@codeRule,1)=4
			SET @billNo=ISNULL(@prefix,'')+ISNULL(@link,'')+CAST((@startNum + @flowNum) AS VARCHAR) 
		IF ISNULL(@codeRule,1)=5
			SET @billNo=ISNULL(@prefix,'')+ISNULL(@link,'')+CONVERT(VARCHAR(6),GETDATE(),12)+ISNULL(@link,'')+RIGHT('00000' + CAST(@flowNum AS VARCHAR),5)
		IF ISNULL(@codeRule,1)=6
			SET @billNo=ISNULL(@prefix,'')+ISNULL(@link,'')+CONVERT(VARCHAR(6),GETDATE(),12)+ISNULL(@link,'')+RIGHT('0000' + CAST(@flowNum AS VARCHAR),4)
		IF ISNULL(@codeRule,1)=7
			SET @billNo=CAST((@startNum + @flowNum) AS VARCHAR) 
		IF ISNULL(@codeRule,1)=8
			SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+CAST((@startNum + @flowNum) AS VARCHAR) 
		IF ISNULL(@codeRule,1)=9 
			SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+ISNULL(@link,'')+RIGHT('00000000' + CAST(@flowNum AS VARCHAR),8)      
		IF ISNULL(@codeRule,1)=10
			SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+ISNULL(@link,'')+RIGHT('0000000' + CAST(@flowNum AS VARCHAR),7)      
		IF ISNULL(@codeRule,1)=11
			SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+ISNULL(@link,'')+RIGHT('000000' + CAST(@flowNum AS VARCHAR),6)  
		UPDATE dbo.SAM_BillType SET isLocked=0 WHERE companyId=@companyId AND billCode=@billCode; 
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT>0
			ROLLBACK;
		SET @billNo=''
	END CATCH  
END
go

