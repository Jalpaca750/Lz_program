CREATE view [dbo].[WMS_PickingOrder_V] as
SELECT a.pickId,a.pickingNo,b.billNo AS pickBillNo,b.waveNo,b.waveBillNo,a.companyId,b.warehouseId,b.regionId,
	a.boxBillNum,a.stockNo,a.stockBillNo,c.mergeNo,c.customerId,c.customerNo,c.customerName,c.customerSpell,
	c.shortName,a.boxId,d.boxCode,a.stockBox,a.boxOrder,CASE a.isPackage WHEN 1 THEN CAST(dtl.boxes AS INT) ELSE 1 END AS boxes,
	a.isPackage,CASE a.isPackage WHEN 1 THEN '整箱' ELSE '散件' END As isPackageDesc,a.taskState,
	CASE a.taskState WHEN 0 THEN '待领取'
                     WHEN 1 THEN '待拣货'
                     WHEN 2 THEN '待复核'
                     WHEN 3 THEN '待打包'
                     WHEN 4 THEN '待装车'
                     WHEN 5 THEN '待发货'
                     WHEN 6 THEN (CASE b.taskState WHEN 2 THEN '已上架' ELSE '已发货' END) END AS stateName,
	a.pkgQty,a.lclQty,ISNULL(a.skuQty,0) AS skuQty,a.pickerId,u1.userNick AS pickerName,CONVERT(VARCHAR(20),b.getTime,120) AS getTime,
	CONVERT(VARCHAR(20),a.pickTime,120) AS pickTime,a.checkerId,u2.userNick AS checkerName,
	CONVERT(VARCHAR(20),a.checkTime,120) AS checkTime,a.packingId,u3.userNick AS packingName,
	CONVERT(VARCHAR(20),a.packingTime,120) AS packingTime,a.loadingId,u4.userNick AS loadingName,
	CONVERT(VARCHAR(20),a.loadingTime,120) AS loadingTime,c.aFlag,a.shipNo,a.cargoArea,
	ISNULL(r.regionNo,a.cargoArea) AS regionNo,ISNULL(r.regionDesc,a.cargoArea) AS regionDesc,l.lineCode,l.lineName,
	a.lineId,c.collectOrder AS lineOrder,a.printNum,a.printId,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,
	a.materialFlag,CASE a.materialFlag WHEN 10 THEN '标准纸板箱' 
	                                   WHEN 20 THEN '标准周转箱'
	                                   WHEN 30 THEN '回收纸板箱'
	                                   WHEN 40 THEN '塑料袋'
	                                   WHEN 50 THEN '原箱' END AS materialDesc,a.cartonId,bs.sizeNo AS cartonNo,
	bs.sizeName AS cartonName,a.plasticId,a.plasticNum,c.memo,c.buyerMessage,c.ordField1,c.ordField2,c.ordField3,
	c.ordField4,c.ordField5,a.shipState,CASE a.shipState WHEN 10 THEN '待排车' 
	                                                     WHEN 20 THEN '已排车' 
	                                                     WHEN 30 THEN '已装车'
	                                                     WHEN 40 THEN '已发货'
	                                                     WHEN 45 THEN '未发货'
	                                                     WHEN 50 THEN '未送达'
	                                                     WHEN 90 THEN '已妥投' END AS shipStateDesc
FROM dbo.WMS_PickingOrder a 
	INNER JOIN dbo.WMS_Picking b ON a.pickingNo=b.pickingNo 
	INNER JOIN (SELECT pickId,SUM(CASE isPackage WHEN 1 THEN stockQty ELSE 0 END) AS boxes 
				FROM dbo.WMS_PickingDetail 
				GROUP BY pickId) dtl ON a.pickId=dtl.pickId
	LEFT JOIN (SELECT m.stockNO,m.customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,
					p.shortName,p.partnerSpell AS customerSpell,m.mergeNo,m.collectOrder,m.memo,m.buyerMessage,
					CASE m.aFlag WHEN 0 THEN '' WHEN 1 THEN '有A单' WHEN 2 THEN 'A单' END AS aFlag,
					m.ordField1,m.ordField2,m.ordField3,m.ordField4,m.ordField5
				FROM dbo.SAD_Stock m 
					INNER JOIN dbo.BAS_Partner p ON m.customerId=p.partnerId) c ON a.stockNo=c.stockNo 
	LEFT JOIN dbo.WMS_Box d ON a.boxId=d.boxId 
	LEFT JOIN dbo.WMS_BoxSize bs ON a.cartonId=bs.sizeId
	LEFT JOIN dbo.BAS_AddressLine l ON a.lineId=l.lineId
	LEFT JOIN dbo.BAS_Region r ON a.cargoArea=r.regionId
	LEFT JOIN dbo.SAM_User u1 ON a.pickerId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON a.checkerId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON a.packingId=u3.userId 
	LEFT JOIN dbo.SAM_User u4 ON a.loadingId=u4.userId
go

