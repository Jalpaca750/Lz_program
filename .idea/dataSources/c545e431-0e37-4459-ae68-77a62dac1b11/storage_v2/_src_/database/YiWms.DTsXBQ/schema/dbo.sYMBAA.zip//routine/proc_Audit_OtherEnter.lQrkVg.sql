
CREATE PROC  [dbo].[proc_Audit_OtherEnter]
(
   @otherNo  VARCHAR(32),
   @operatorId VARCHAR(32)
)
AS 
BEGIN TRAN
DECLARE @billNo VARCHAR(32),
@itemId VARCHAR(32),@ioQty INT,
@price DECIMAL(20,10),@taxrate  DECIMAL(6,2),@objId  VARCHAR(32),
@taxFlag INT,@warehouseId VARCHAR(32),@totalFee DECIMAL(20,10),@otherId VARCHAR(32),@companyId VARCHAR(32)
DECLARE @errorSun int =0,@viewOrder INT=0
-----------赋值------------
SELECT @objId=[objId],@companyId=companyId  from IMS_Other where otherNo=@otherNo
DECLARE cursor1 cursor FOR 
SELECT billNo,itemId,IoQty,price,taxrate, 1 taxFlag,totalFee,otherId,warehouseId
FROM IMS_OtherDetail_V  where otherNo=@otherNo and ioState=10
OPEN cursor1
FETCH next from cursor1 into @billNo,@itemId,@ioQty,@price,@taxrate,@taxFlag,@totalFee,@otherId,@warehouseId
WHILE @@fetch_status=0 
BEGIN
SET @viewOrder=@viewOrder+1
----写入流水账开始-----
INSERT INTO IMS_Book(
[bookId],[ioType],[companyId],[billId],[billNo],[billCode],[objectId],[warehouseId],
[lotNo],[locationNo],[eId],[itemId],[befQty],[befFee],[befTotalFee],[taxFlag],
[taxrate],[befPrice],[discount],[discountFee],[ioQty],[price],[fee],[taxFee],[totalFee],[afterQty],[afterFee],[afterTotalFee],[handlerId],[deptId],[createTime],
[creatorId],[auditorId],[auditTime],[memo],[costFee],[costTotalFee])
select  REPLACE(NEWID(),'-','') bookId,[ioType],a.companyId,a.otherId AS billId,a.otherNo AS billNo,a.billNo AS billCode,[objId] as objectId,a.warehouseId,
isnull(a.lotNo,''),ISNULL(a.locationNo,''),a.eId,a.itemId,isnull(b.onhandQty,0.0) AS befQty,isnull(b.fee,0.0) AS fee,ISNULL(b.totalFee,0.0) as totalFee,1 taxFlag,
a.taxrate,a.taxPrice,100 discount,0.0 discountFee,a.ioQty,a.taxPrice,a.fee,a.taxFee,a.totalFee,Isnull(a.ioQty,0.0)+isnull(b.onhandQty,0.0) AS afterQty,Isnull(a.fee,0.0)+isnull(b.fee,0.0) AS afterFee,isnull(a.totalFee,0.0)+isnull(b.totalFee,0.0) AS afterTotalFee,a.handlerId,a.deptId,a.createTime,
@operatorId AS creatorId,@operatorId AS auditorId, GETDATE() as auditTime,'' as memo ,isnull(a.fee,0.0) AS costfee,ISNULL(a.totalFee,0.0) as costtotalfee from IMS_OtherDetail_V a
LEFT JOIN IMS_Stock b ON a.warehouseId=b.warehouseId and a.itemId=b.itemId AND isnull(a.locationNo,'')=isnull(b.locationNo,'') AND isnull(a.lotNo,'')=isnull(b.lotNo,'')
where a.otherId=@otherId;
set @errorSun=@errorSun+@@ERROR
----写入流水账结束-----

----库房总帐-----
UPDATE a SET a.onhandQty=ISNULL(a.onhandQty,0.0)+ISNULL(b.ioQty,0.0),
             a.taxPrice=CASE WHEN isnull(a.onhandQty,0)+ISNULL(b.ioQty,0.0)=0 THEN a.taxPrice ELSE (ISNULL(a.totalFee,0.0)+ISNULL(b.totalFee,0.0))/((isnull(a.onhandQty,0)+ISNULL(b.ioQty,0.0))) END,
             a.totalFee=ISNULL(a.totalFee,0.0)+ISNULL(b.totalFee,0.0),
             a.price=CASE WHEN isnull(a.onhandQty,0)+ISNULL(b.ioQty,0.0)=0 THEN a.price ELSE (ISNULL(a.Fee,0.0)+ISNULL(b.Fee,0.0))/((isnull(a.onhandQty,0)+ISNULL(b.ioQty,0.0))) END,
             a.fee =ISNULL(a.fee,0.0) + ISNULL(b.fee,0.0),
             a.lastITime=GETDATE(),
             a.lastITaxPrice=CASE ISNULL(@taxFlag,1) WHEN 1 THEN b.Price ELSE ISNULL(a.price,0.0)*(1+(b.taxrate/100)) END,
             a.lastIPrice=CASE ISNULL(@taxFlag,1) WHEN 1 THEN b.price/(1+(b.taxrate/100)) ELSE b.price END
FROM IMS_Ledger a 
INNER JOIN IMS_OtherDetail b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId
WHERE b.otherId=@otherId
set @errorSun=@errorSun+@@ERROR
-------不存在则插入-------
INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,price,taxrate,taxPrice,fee,totalFee,maxDays,minDays,maxQty,minQty,stabilityRate,lastITime,lastIPrice,lastITaxPrice)
SELECT replace(NEWID(),'-','') ,a.companyId,a.warehouseId,a.eId,a.itemId,a.ioQty,0,
       a.price,a.taxrate,
       a.taxPrice,
       a.fee,a.totalFee,0,0,0,0,0,GETDATE(),
       a.price,
       a.taxPrice
FROM IMS_OtherDetail a WHERE a.otherId=@otherId AND NOT EXISTS(SELECT 1 FROM IMS_Ledger b WHERE a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId)
set @errorSun=@errorSun+@@ERROR
--------库房总帐结束-----
------------------------------------------------------------------------------------

------库房分帐开始-----
UPDATE a SET a.onhandQty=a.onhandQty+b.ioQty,taxPrice=(SELECT taxPrice FROM IMS_Ledger WHERE companyId=@companyId AND itemId=@itemId AND warehouseId=@warehouseId),a.fee=a.fee+b.fee,a.totalFee=a.totalFee+b.totalFee
,price =(SELECT price FROM IMS_Ledger WHERE companyId=@companyId AND itemId=@itemId AND warehouseId=@warehouseId)
FROM IMS_Stock a 
INNER JOIN IMS_OtherDetail b ON  a.companyId=b.companyId AND a.itemId=b.itemId AND a.warehouseId=b.warehouseId AND isnull(a.locationNo,'')=isnull(b.locationNo,'') AND isnull(a.lotNo,'')=isnull(b.lotNo,'')
WHERE b.otherId=@otherId
set @errorSun=@errorSun+@@ERROR
------不存在插入-----
INSERT INTO IMS_Stock(onhandQty, stockId, companyId,warehouseId,    lotNo,  locationNo,eId,        itemId,price                         ,taxrate   ,taxPrice,fee  ,totalFee  ,lastITime,lastIPrice                    ,lastITaxPrice)
SELECT a.ioQty,REPLACE(NEWID(),'-',''),a.companyId,a.warehouseId,isnull(a.lotNo,''),isnull(a.locationNo,''),a.eId,a.itemId,a.price,a.taxrate,a.taxprice ,a.fee,a.totalFee,GETDATE(),a.price,a.taxprice
FROM IMS_OtherDetail_V a
LEFT JOIN IMS_Stock b ON a.companyId=b.companyId AND a.itemId=b.itemId AND a.warehouseId=b.warehouseId AND isnull(a.locationNo,'')=isnull(b.locationNo,'') AND isnull(a.lotNo,'')=isnull(b.lotNo,'')
WHERE a.otherId=@otherId AND b.itemId IS NULL
----库房分帐结束-----

----历史进价结束-----
FETCH next from cursor1 into @billNo,@itemId,@ioQty,@price,@taxrate,@taxFlag,@totalFee,@otherId,@warehouseId
END
CLOSE  cursor1
DEALLOCATE  cursor1
-------更新基础库存-------------
UPDATE a SET a.onhandQty=a.onhandQty+b.Qty FROM BAS_Item a INNER JOIN(SELECT itemid,companyId,isnull(sum(ioQty),0)AS Qty  FROM IMS_OtherDetail WHERE otherNo=@otherNo GROUP BY companyId,itemId)b ON a.itemId=b.itemid AND a.companyId=b.companyId
set @errorSun=@errorSun+@@ERROR
-----更新基础库存结束-------------
UPDATE IMS_Other set ioState=20,auditTime=GETDATE(),auditorId=@operatorId where otherNo=@otherNo
set @errorSun=@errorSun+@@ERROR

----报错回滚----
IF @errorSun<>0
 ROLLBACK TRAN;
ELSE   
 COMMIT TRAN;




go

