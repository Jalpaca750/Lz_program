

/*==============================================================*/
/* View: WMS_Picking_V                                          */
/*==============================================================*/
--creator：Frank
--create time：2016-02-18 
--拣货任务主视图，增加打印次数与打印人
--2017-09-12 增加超过N箱后只产生一个任务模式后修改视图
CREATE view [dbo].[WMS_Picking_V] as
SELECT a.pickingNo,a.companyId,a.billNo,a.waveNo,a.waveBillNo,a.warehouseId,h.warehouseNo,h.warehouseName,
      a.regionId,r.regionNo,r.regionDesc,a.sizeId,s.sizeName,a.boxNumber,ISNULL(t.pkgQty,0.0) + ISNULL(b.lclQty,0.0) AS boxCount,
      t.pkgQty,b.lclQty,t.skuCount,t.locCount,a.pickerId,u1.userNick AS pickerName,a.flag, a.taskState,
      CASE a.taskState WHEN 0 THEN '待领取' WHEN 1 THEN '待拣货' WHEN 2 THEN '待复核' WHEN 9 THEN '已完成' END AS stateName,
      a.taskType,CASE a.taskType WHEN 0 THEN '散件' 
                                 WHEN 1 THEN CASE ISNULL(p.pclQty,0) WHEN 0 THEN '整箱' ELSE '整托' END 
                                 WHEN 2 THEN '补货' END AS isPackageDesc,ISNULL(p.pclQty,0) AS pclQty,
      CONVERT(VARCHAR(20),a.getTime,120) AS getTime, a.createTime,a.creatorId,u2.userNick AS creatorName,
      a.printNum,a.printId,u4.userNick AS printMan,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,a.editTime,
      a.editorId,u3.userNick AS editorName,a.isSelected,ISNULL(_wave.islocked,0) waveIslocked,
      ISNULL(_wave.waveFlag,'') waveFlag
FROM dbo.WMS_Picking a 
	INNER JOIN (SELECT pickingNo,SUM(CASE isPackage WHEN 0 THEN 1 ELSE 0 END) AS lclQty 
				FROM dbo.WMS_PickingOrder
				GROUP BY pickingNo) b ON a.pickingNo=b.pickingNo 
	INNER JOIN (SELECT pickingNo,COUNT(itemId) AS skuCount,COUNT(DISTINCT locationNo) AS locCount,
					SUM(CASE isPackage WHEN 1 THEN stockQty ELSE 0 END) AS pkgQty	
				FROM WMS_PickingDetail
				GROUP BY pickingNo) t ON a.pickingNo=t.pickingNo 
	INNER JOIN dbo.BAS_Warehouse h ON a.warehouseId=h.warehouseId 
	LEFT JOIN dbo.WMS_PickingPallet_V p ON a.pickingNo=p.pickingNo
	LEFT JOIN dbo.BAS_Region r ON a.regionId=r.regionId 
	LEFT JOIN dbo.WMS_BoxSize s ON a.sizeId=s.sizeId 
	LEFT JOIN dbo.SAM_User u1 ON a.pickerId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId 
	LEFT JOIN dbo.SAM_User u4 ON a.printId=u4.userId
    LEFT JOIN  WMS_Wave  _wave WITH(NOLOCK) ON A.waveNo=_wave.waveNo
go

