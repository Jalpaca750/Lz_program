Create View   WillShelves_v
as
select c.regionid,c.regionDesc,
c.regionNo,a.flag ,a.WarehouseId,a.WarehouseName,a.CompanyId,a.StockNo,a.BillNo,
a.CreateTime,a.IoState,a.StateName,a.isLocked,a.lockerName from (
select 1 flag ,WarehouseId,WarehouseName,CompanyId,StockNo,BillNo,
CreateTime,IoState,StateName,isLocked,lockerName
from  PMS_Stock_V where ioState in (20,25) 
union 
select 2 flag,warehouseId,warehouseName,companyId,returnNo,billNo,
createtime,ioState,ioStateName,isLocked,lockerName
from SAD_Return_V where ioState in (20,25)
) A  inner join   
WMS_Putaway B on  a.stockNo=b.stockNo
inner join BAS_Region  c 
on b.regionid=c.regionid
go

