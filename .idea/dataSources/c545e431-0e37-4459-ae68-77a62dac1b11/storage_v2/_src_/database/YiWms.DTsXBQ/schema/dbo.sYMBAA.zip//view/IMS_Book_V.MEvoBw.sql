
/*==============================================================*/
/* View: IMS_Book_V                                             */
/*==============================================================*/
--creator：        Frank
--create time：  2016-12-16日整理 
--modify:		 2017-11-03 增加商品业主Id
--流水账视图
CREATE view [dbo].[IMS_Book_V] as
SELECT a.bookId,a.ioType,CASE a.ioType WHEN 'S100' THEN '销售出库单' 
                                       WHEN 'S200' THEN '销售退货单'
                                       WHEN 'P100' THEN '采购入库单'
                                       WHEN 'P200' THEN '采购退货单'
                                       WHEN 'B100' THEN '补货上架单'  
                                       WHEN 'B200' THEN '补货下架单'                                    
                                       WHEN 'D100' THEN '调拨入库单' 
                                       WHEN 'D200' THEN '调拨出库单'
                                       WHEN 'G100' THEN '赠品入库单'
                                       WHEN 'G200' THEN '赠品出库单'
                                       WHEN 'L100' THEN '领用出库单'
                                       WHEN 'I100' THEN '库存初始化'
                                       WHEN 'O100' THEN '其他入库单'
                                       WHEN 'O200' THEN '其他出库单'
                                       WHEN 'Y100' THEN '移仓单移入'
                                       WHEN 'Y200' THEN '移仓单移出' 
                                       WHEN 'T100' THEN '库存调整单' END AS ioTypeDesc,
      a.companyId,a.billId,a.billNo,a.billCode,a.viewOrder,a.objectId,a.warehouseId,w.warehouseNo,w.warehouseName,
      a.lotNo,a.locationNo,a.eId,a.itemId,bi.itemNo,bi.itemName,bi.itemCTitle,bi.itemETitle,bi.sellingPoint,bi.itemSpec,
      bi.itemSpell,bi.barcode,bi.midBarcode,bi.bigBarcode,bi.pkgBarcode,bi.packageId,bi.brandId,bi.brandNo,bi.brandCName,
      bi.categoryId,bi.categoryNo,bi.categoryCName,bi.colorName,bi.sizeName,bi.unitName,bi.pkgUnit,bi.pkgRatio,
      bi.inventoryMode,bi.isSafety,bi.safetyMonth,bi.safetyDays,a.befQty,a.befFee,a.befTotalFee,a.taxFlag,a.taxrate,
      a.befPrice,a.discount,a.discountFee,a.ioQty,a.price,a.fee,a.taxFee,a.totalFee,a.costPrice,a.costFee,a.costTaxPrice,
      a.costTotalFee,a.afterQty,a.afterFee,a.afterTotalFee,a.handlerId,a.deptId,a.createTime,a.creatorId,
      u1.userNick AS creatorName,a.auditTime,a.auditorId,u2.userNick AS auditorName,bi.ownerId,a.memo
FROM dbo.IMS_Book a 
      INNER JOIN dbo.BAS_Goods_V bi ON a.itemId=bi.itemId
      INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
      LEFT JOIN SAM_User u1 ON a.creatorId=u1.userId
      LEFT JOIN SAM_User u2 ON a.auditorId=u2.userId

go

