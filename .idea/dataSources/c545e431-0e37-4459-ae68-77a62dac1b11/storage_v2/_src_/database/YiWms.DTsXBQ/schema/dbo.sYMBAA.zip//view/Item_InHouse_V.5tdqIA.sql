/*==============================================================*/
/* View: Item_InHouse                                             */
/*==============================================================*/
--creator：        WJ
--create time：  2017-07-10
--商品存在位位
create view [dbo].[Item_InHouse_V] as
SELECT distinct b.itemNo,c.warehouseNo FROM IMS_Stock a
INNER JOIN BAS_Item b ON a.itemId=b.itemId
INNER JOIN BAS_Warehouse c ON a.warehouseId=c.warehouseId

go

