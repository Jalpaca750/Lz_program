CREATE Proc [dbo].[up_RebuildIndex]
As
BEGIN

    DBCC DBREINDEX(BAS_Item);
    DBCC DBREINDEX(BAS_ItemImage);
    DBCC DBREINDEX(BAS_ItemVer);
    
    DBCC DBREINDEX(BAS_Category);
    DBCC DBREINDEX(BAS_Location);
    DBCC DBREINDEX(BAS_Partner);
    DBCC DBREINDEX(BAS_ReceiveAddress);
    
    DBCC DBREINDEX(SAD_Order);
    DBCC DBREINDEX(SAD_OrderDetail);
    DBCC DBREINDEX(SAD_OrderAction);
    
    DBCC DBREINDEX(SAD_Return);
    DBCC DBREINDEX(SAD_ReturnDetail);

    DBCC DBREINDEX(SAD_Stock);
    DBCC DBREINDEX(SAD_StockDetail);
    
    DBCC DBREINDEX(PMS_Order);
    DBCC DBREINDEX(PMS_OrderDetail);
    DBCC DBREINDEX(PMS_Stock);
    DBCC DBREINDEX(PMS_StockDetail);    
    DBCC DBREINDEX(PMS_Return);
    DBCC DBREINDEX(PMS_ReturnDetail);
    DBCC DBREINDEX(PMS_Order);
    DBCC DBREINDEX(PMS_OrderDetail);
    
    
    DBCC DBREINDEX(IMS_Ledger);
    DBCC DBREINDEX(IMS_Stock);    
    DBCC DBREINDEX(IMS_Book);
    DBCC DBREINDEX(IMS_Batch);
    DBCC DBREINDEX(IMS_CheckPoint);
    DBCC DBREINDEX(IMS_CheckStock);
    DBCC DBREINDEX(IMS_CheckTask);
    DBCC DBREINDEX(IMS_Check);
    DBCC DBREINDEX(IMS_CheckDetail);
    DBCC DBREINDEX(IMS_Adjust);
    DBCC DBREINDEX(IMS_AdjustDetail);
    
    DBCC DBREINDEX(WMS_Wave);
    DBCC DBREINDEX(WMS_WaveDetail);
    DBCC DBREINDEX(WMS_Picking);
    DBCC DBREINDEX(WMS_PickingOrder);
    DBCC DBREINDEX(WMS_PickingDetail);
    DBCC DBREINDEX(WMS_PickingError);
    
    DBCC DBREINDEX(WMS_Packing);
    DBCC DBREINDEX(WMS_PackingDetail);
    
    DBCC DBREINDEX(WMS_Putaway);
    DBCC DBREINDEX(WMS_PutawayDetail);    
    DBCC DBREINDEX(WMS_Replenish);
    
    DBCC DBREINDEX(WMS_Ship);
    DBCC DBREINDEX(WMS_ShipDetail);
    
    DBCC DBREINDEX(TMS_WayBill);
    DBCC DBREINDEX(TMS_WaySite);
END
go

