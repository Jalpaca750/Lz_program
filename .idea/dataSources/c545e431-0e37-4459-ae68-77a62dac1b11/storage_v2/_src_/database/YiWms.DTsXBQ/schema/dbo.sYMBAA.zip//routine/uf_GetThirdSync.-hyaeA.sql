-- =============================================
-- Author:		<Author: Wang_Jun>
-- Create date: <Create Date:2017-05-10>
-- Description:	<Description:同步状态 V1>
-- 包含：
-- =============================================
CREATE FUNCTION [dbo].[uf_GetThirdSync]
(
    @companyId VARCHAR(32),				        --公司Id
    @startTime DATETIME,						--起始时间
    @endTime DATETIME							--截止时间
)
RETURNS TABLE
RETURN(
	SELECT t.*,CASE t.thirdSyncFlag WHEN -1 THEN '不同步' WHEN 0 THEN '未同步' WHEN 1 THEN '已同步' WHEN 2 THEN '同步错' END AS thirdSyncFlagName FROM
	(
		SELECT ioTypeName AS BillType,billNo,taskStateDesc AS BillState,thirdSyncFlag,createTime,creatorName,creatorId,companyId  FROM SAD_Stock_V WHERE companyId=@companyId AND ioState>0 AND (createTime BETWEEN @startTime AND @endTime)
		UNION ALL
		SELECT ISNULL(orderTypeName,ioTypeDesc) AS BillType,billNo,ioStateName AS BillState,thirdSyncFlag,createTime,creatorName,creatorId,companyId  FROM SAD_Return_V WHERE companyId=@companyId AND ioState>0 AND (createTime BETWEEN @startTime AND @endTime)
		UNION ALL
		SELECT ioTypeDesc  AS BillType,billNo,stateName AS BillState,thirdSyncFlag,createTime,creatorName,creatorId,companyId  FROM PMS_Stock_V WHERE companyId=@companyId AND ioState>0 AND (createTime BETWEEN @startTime AND @endTime)
		UNION ALL
		SELECT ioTypeDesc  AS BillType,billNo,ioStateName AS BillState,thirdSyncFlag,createTime,creatorName,creatorId,companyId  FROM PMS_Return_V WHERE companyId=@companyId AND ioState>0 AND (createTime BETWEEN @startTime AND @endTime)
		UNION ALL
		SELECT '库存调亏' AS BillType,a.billNo,a.ioStateName AS BillState,a.thirdSyncFlag,createTime,creatorName,creatorId,companyId FROM IMS_Adjust_V a WHERE a.ioState>0 and companyId=@companyId AND (createTime BETWEEN @startTime AND @endTime) And EXISTS(SELECT 1 FROM IMS_AdjustDetail b WHERE ioQty<0.0 AND a.adjustNo=b.adjustNo)
		UNION ALL
		SELECT '库存调盈' AS BillType,a.billNo,a.ioStateName AS BillState,a.by_thirdSyncFlag as thirdSyncFlag,createTime,creatorName,creatorId,companyId FROM IMS_Adjust_V a WHERE a.ioState>0 and companyId=@companyId AND (createTime BETWEEN @startTime AND @endTime) And EXISTS(SELECT 1 FROM IMS_AdjustDetail b WHERE ioQty>0.0 AND a.adjustNo=b.adjustNo)
	)t
)


go

