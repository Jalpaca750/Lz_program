-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-11-27>
-- Description:	<Description:审核采购退货单>
-- =============================================
CREATE PROCEDURE [dbo].[up_Audit_PurReturn]
(
    @returnNo VARCHAR(32),		--退货单号
	@operatorId VARCHAR(32)		--操作员
)
AS
BEGIN
	DECLARE @companyId VARCHAR(32),		--公司Id
			@billNo VARCHAR(32),		--退货单号
			@warehouseId VARCHAR(32),	--仓库Id
			@regionId VARCHAR(32),		--区域Id
			@supplierId VARCHAR(32),	--供应商Id
			@createTime DATETIME,		--制单时间
			@creatorId VARCHAR(32),		--制单人Id
			@handlerId VARCHAR(32),		--经办人Id
			@deptId VARCHAR(32),		--经办部门Id
			@memo VARCHAR(2000),		--主表备注
			@ioType VARCHAR(32),		--入出库类型（P200-销售退货单）
			@taxFlag INT,				--是否含税（默认含税）
			@returnId VARCHAR(32),		--明细Id
			@eId VARCHAR(32),			--主商品Id
			@itemId VARCHAR(32),		--SkuId			
			@returnQty DECIMAL(20,6),	--退货数量
			@befPrice DECIMAL(20,10),	--折前价
			@discount DECIMAL(6,2),		--折扣
			@discountFee DECIMAL(6,2),	--折扣金额
			@price DECIMAL(20,10),		--单价（折扣后）
			@taxrate DECIMAL(6,2),		--税率
			@fee DECIMAL(20,10),		--金额（不含税）
			@taxFee DECIMAL(20,10),		--税额
			@totalFee DECIMAL(20,10),	--金额（含税）
			@lotNo VARCHAR(32),			--批次号
			@locationNo VARCHAR(32)		--库位			
	--此处可用于计算成本
	DECLARE @befQty DECIMAL(20,6),			--出入库前数量
			@befFee DECIMAL(20,10),			--出入库前金额（不含税）
			@befTotalFee DECIMAL(20,10),	--出入库前金额（含税）	
			@befCPrice DECIMAL(20,10),		--出入库前单价（不含税）
			@befCTaxPrice DECIMAL(20,10),	--出入库前单价（含税）
			@auditTime DATETIME				--审核时间
	--审核时间
	SET @auditTime=GETDATE();
	--获取操作员所在的公司Id
	SELECT @companyId=companyId FROM dbo.SAM_User WHERE userId=@operatorId; 
	--删除操作员当前操作的错误信息
	DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='up_Audit_PurReturn' AND creatorId=@operatorId;
	BEGIN TRY
		BEGIN TRANSACTION
		--单据被删除，则直接退出
		IF NOT EXISTS(SELECT 1 FROM dbo.PMS_Return WHERE returnNo=@returnNo)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_Audit_PurReturn','YI_PMS_RETURN_WAS_DELETED','采购退货单被他人删除，操作无效！',@returnNo,@returnNo);
			COMMIT;
			RETURN;
		END
		--主表信息		
		SELECT @billNo=billNo,@companyId=companyId,@warehouseId=warehouseId,@supplierId=supplierId,@ioType=ioType,
			@taxFlag=taxFlag,@createTime=createTime,@creatorId=creatorId,@handlerId=handlerId,@deptId=deptId,@memo=memo
		FROM dbo.PMS_Return 
		WHERE returnNo=@returnNo;
		--库位编码错误则返回提醒
		IF EXISTS(SELECT 1 FROM dbo.PMS_ReturnDetail a WHERE a.returnNo=@returnNo AND NOT EXISTS(SELECT 1 FROM dbo.BAS_Location b WHERE a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo))
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_Audit_PurReturn','YI_PMS_RETURN_LOCATION_ERROR','库位编码输入错误，请重新输入！',@returnNo,@billNo);
			COMMIT;
			RETURN;
		END
		--判断库存是否足够
		IF EXISTS(SELECT 1 
				  FROM PMS_ReturnDetail a 
						INNER JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.locationNo,'') AND a.itemId=b.itemId
				  WHERE a.returnNo=@returnNo AND ISNULL(b.onhandQty,0.0)-ISNULL(a.returnQty,0.0)<0.0)
		BEGIN		  
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_Audit_PurReturn','YI_PMS_RETURN_STOCK_LESS_THAN_RETURN','库位库存不足退货数量，请重新输入！',@returnNo,@billNo);
			COMMIT;
			RETURN;
		END
		--判断单据是否已经作废
		IF EXISTS(SELECT 1 FROM dbo.PMS_Return WHERE returnNo=@returnNo AND ioState=0)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_Audit_PurReturn','YI_PMS_RETURN_WAS_CLOSED','采购退货单已作废，操作无效！',@returnNo,@billNo);
			COMMIT;
			RETURN;
		END
		--判断单据是否已经审核
		IF EXISTS(SELECT 1 FROM dbo.PMS_Return WHERE returnNo=@returnNo AND ioState=20)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_Audit_PurReturn','YI_PMS_RETURN_WAS_AUDITED','采购退货单已审核，操作无效！',@returnNo,@billNo);
			COMMIT;
			RETURN;
		END
		--更新状态
		UPDATE dbo.PMS_Return SET ioState=20,auditTime=@auditTime,auditorId=@operatorId,editTime=@auditTime,editorId=@operatorId WHERE returnNo=@returnNo AND ioState=10;
		IF (@@ROWCOUNT>0)
		BEGIN
			DECLARE myCursor CURSOR
			FOR SELECT returnId,eId,itemId,lotNo,locationNo,-returnQty,befPrice,price,taxrate,discount,discountFee,-fee,-taxFee,-totalFee
				FROM dbo.PMS_ReturnDetail
				WHERE returnNo=@returnNo
				ORDER BY viewOrder
			FOR READ ONLY;		 
			OPEN myCursor;
			FETCH NEXT FROM myCursor INTO @returnId,@eId,@itemId,@lotNo,@locationNo,@returnQty,@befPrice,@price,@taxrate,@discount,@discountFee,@fee,@taxFee,@totalFee;
			WHILE @@FETCH_STATUS=0
			BEGIN	
				--处理商品库存
				UPDATE BAS_Item SET onhandQty=ISNULL(onhandQty,0.0)+ISNULL(@returnQty,0.0) WHERE itemId=@itemId;
				--仓库总账	
				IF EXISTS(SELECT 1 FROM IMS_Ledger WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId)
					UPDATE IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)+@returnQty
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
				ELSE
					--如果表中没有数据，则新增一条记录
					INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastOTime)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@eId,@itemId,@returnQty,0.0,@auditTime);
				--库位批次明细帐
				--取得库区
				SELECT @regionId=ISNULL(regionId,'') 
				FROM dbo.BAS_Location  
				WHERE warehouseId=@warehouseId AND locationNo=@locationNo;
				IF EXISTS(SELECT 1 FROM IMS_Stock WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId)
				BEGIN
					--入出库(调整)前库存
					SELECT @befQty=onhandQty
					FROM dbo.IMS_Stock
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId;
					UPDATE dbo.IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)+@returnQty,lastOTime=@auditTime
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId;
				END
				ELSE
				BEGIN
					---如果库里面没有 进行插入
					SELECT @befQty=0.0;
					INSERT INTO dbo.IMS_Stock(stockId,companyId,warehouseId,regionId,lotNo,locationNo,eId,itemId,onhandQty,allocQty,lastOTime)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@regionId,@lotNo,@locationNo,@eId,@itemId,@returnQty,0.0,@auditTime);
				END	
				--处理IMS_Book表
				INSERT INTO IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,
					eId,itemId,befQty,ioQty,afterQty,handlerId,deptId,createTime,creatorId,auditTime,auditorId,memo)
				VALUES(REPLACE(NEWID(),'-',''),'P200',@companyId,@returnId,@returnNo,@billNo,@supplierId,@warehouseId,ISNULL(@lotNo,''),
					ISNULL(@locationNo,''),@eId,@itemId,@befQty,@returnQty,ISNULL(@befQty,0.0)+ISNULL(@returnQty,0.0),@handlerId,
					@deptId,@createTime,@creatorId,@auditTime,@operatorId,@memo);
				FETCH NEXT FROM myCursor INTO @returnId,@eId,@itemId,@lotNo,@locationNo,@returnQty,@befPrice,@price,@taxrate,@discount,@discountFee,@fee,@taxFee,@totalFee
			END
			CLOSE myCursor
			DEALLOCATE myCursor		
		END
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_Audit_PurReturn','YI_PMS_RETURN_ERROR',LEFT(@ErrMsg,2000),@returnNo,@billNo);
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END CATCH
END

go

