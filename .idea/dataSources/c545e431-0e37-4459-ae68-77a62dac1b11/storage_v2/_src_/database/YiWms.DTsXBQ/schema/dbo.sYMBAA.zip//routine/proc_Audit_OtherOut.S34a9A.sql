

CREATE Proc  [dbo].[proc_Audit_OtherOut]
(
   @otherNo  varchar(32),  --其他出库单号 唯一的ID
   @operatorId varchar(32)  ---审核人
)
as 
begin tran
---定义游标
declare   FMyCursor CURSOR for SELECT 
       a.[otherId]
      ,a.[viewOrder]
      ,a.[companyId]
      ,a.[warehouseId]
      ,a.[lotNo]
      ,a.[locationNo]
      ,a.[eId]
      ,a.[itemId]
      ,a.[ioQty]
      ,a.[pkgQty]
      ,a.[bulkQty]
      ,a.[price]
      ,a.[taxrate]
      ,a.[taxPrice]
      ,a.[fee]
      ,a.[taxFee]
      ,a.[totalFee]
      ,a.[remarks]
      ,[isSelected]
      ,isnull(is1.onhandQty,0) onhandQty,ioType,billNo,objId,0 stockprice,0 stocktaxprice,0 befFee, 0 befTotalFee,
      handlerid,deptid,a.createTime
  FROM [IMS_OtherDetail_v] a  
  LEFT JOIN IMS_Stock AS is1 ON is1.companyId=a.companyId AND a.itemId=is1.itemId AND isnull(a.lotNo,'')=isnull(is1.lotNo,'') 
	        and isnull(a.locationNo,'')=isnull(is1.locationNo,'')
  where OtherNo=@otherNo 
  order by itemid,locationNo for Read only
  
  
  
  ------
  

 -----------邮编变量
    declare  @otherId varchar(32)
	declare @viewOrder int 
	declare @companyId varchar(32)
	declare @warehouseId varchar(32)
	declare @lotNo varchar(32)
	declare @locationNo varchar(32)
	declare @eId varchar(32)
	declare @itemId varchar(32)
	--declare @unitId varchar(32)
	declare @ioQty decimal(20, 10)
	declare @pkgQty decimal(20, 6)
	declare @bulkQty decimal(20, 6)
	declare @price decimal(20, 10)
	declare @taxrate decimal(6, 2)
	declare @taxPrice decimal(20, 10)
	declare @fee decimal(20, 10)
	declare @taxFee decimal(20, 10)
	declare @totalFee decimal(20, 10)
	declare @remarks varchar(200)
	declare @isSelected bit
	declare @onhandQty  decimal(20,6)
	declare @ioType varchar(32)
	declare @billNo varchar(50)
	declare @objId varchar(32)
	declare @stockprice decimal(20,10)  --库存金额
	declare @stocktaxprice decimal(20,10) --库存金额 含税
	declare @befFee decimal(20,10)
	declare @befTotalFee decimal(20,10)
	declare @taxFlag int =1
	declare @handlerid varchar(32)
	declare @deptid varchar(32)
	declare @time datetime =GETDATE()
	DECLARE @createTime datetime
	
	
	
	-----临时变量
	
	declare @befqty  decimal(20,6)  --出库前金额
	declare @befprice decimal(20,10) --出库前金额
	declare @befItemId varchar(32)=''  ---临时变量
	declare @befLocationNo varchar(100)='' --临时变量
	
	------算法变量 
	
	declare  @_befQty decimal(20,6)=0,
	         @_befFee decimal(20,6)=0,@_befTotalFee decimal(20,6)=0
	
 -----定义一些变量
	declare @errorSum int =0
	
	if not exists(select  otherNo  from IMS_Other where otherNo=@otherNo and  ioState=10 )
	begin
	----如果状态不符合条件 不更新
	set @errorSum=1
	end
	else  begin
	--- 更新主表 
	  update    IMS_Other set  ioState=20 , auditTime=@time, auditorId=@operatorId
	  where otherNo=@otherNo
	  set @errorSum=@errorSum+@@ERROR
	  ----打开游标进行循环  
	  open  FMyCursor   
		Fetch  NEXT   FROM FMyCursor  into     
		@otherId,@viewOrder,@companyId,@warehouseId,@lotNo,@locationNo,@eId,@itemId
		,@ioQty,@pkgQty,@bulkQty,@price,@taxrate,@taxPrice,@fee,@taxFee,@totalFee,@remarks,
		@isSelected,@onhandQty,@ioType,@billNo,@objId,@stockprice,@stocktaxprice,@befFee,@befTotalFee,
		@handlerid,@deptid,@createTime
	     While(@@Fetch_Status = 0)
	     begin
	     
	        if not exists(select * from IMS_Stock where  companyId=@companyId and warehouseId=@warehouseId and  itemId=@itemId and isnull(lotNo,'')=isnull(@lotNo,'') and isnull(locationNo,'')=isnull(@locationNo,''))
	        begin

	            ---如果库里面没有 进行插入
				insert into  IMS_Stock(stockId,companyId,warehouseId,lotNo,locationNo,eId,itemId,onhandQty,
				allocQty,price,taxrate,taxPrice,fee,totalFee,lastITime,lastIPrice,
				lastITaxPrice,lastOTime,lastOPrice,lastOTaxPrice)
				values
				(
				   REPLACE(NEWID(),'-',''),@companyId,@warehouseId,@lotNo,@locationNo,@eId,@itemId,
				   0,0,0,17,0,0,0,null,0,0,GETDATE(),0,0
				)
				 set @errorSum=@errorSum+@@ERROR
		    end 
		    ----如果主表里面没有的
		    if not exists(select * from IMS_Ledger where companyId=@companyId and warehouseId=@warehouseId and  itemId=@itemId)
		    begin 
				insert into IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,price,taxrate,taxPrice,
				fee,totalFee,maxDays,minDays,maxQty,
				minQty,stabilityRate,lastITime,lastIPrice,lastITaxPrice,lastOTime,lastOPrice,lastOTaxPrice)
				select replace(NEWID(),'-',''),companyId,warehouseId,eId,itemId,onhandQty,allocQty,price,taxrate,taxPrice,
				fee,totalFee,0,0,0,0,0,GETDATE(),lastIPrice,lastITaxPrice,lastOTime,lastOPrice,lastOTaxPrice
				from IMS_Stock  where  companyId=@companyId  and warehouseId=@warehouseId 
				 set @errorSum=@errorSum+@@ERROR
		    end 

				
	        if  (@itemId=@befItemId and @locationNo=@befLocationNo)
	        begin
	        set @_befQty=isnull((@_befQty-@ioQty),0)  --减去后的数量
	        print '第一个'+cast(@_befQty as varchar(32))
				insert into IMS_Book
				(
					[bookId],[ioType],[companyId],[billId],[billNo],
					[objectId],[warehouseId],[lotNo],[locationNo],[eId],[itemId],[befQty],
					[befFee],[befTotalFee],[taxFlag],
					[taxrate],[befPrice],[discount],[discountFee],[ioQty],
					[price],[fee],[taxFee],[totalFee],
					[afterQty],
					[afterFee],
					[afterTotalFee],
					[handlerId],
					[deptId],
					[createTime],
					[creatorId],[auditorId],[auditTime],[memo],costFee,costTotalFee,billcode)
					values(replace(NEWID(),'-',''),@ioType,@companyId,@otherId,@otherNo,@objId,@warehouseId,
					@lotNo,@locationNo,@eId,@itemId,@onhandQty,@befFee,@befTotalFee,@taxFlag,@taxrate,(@taxPrice),
					100,0,-(@ioQty),@taxPrice,-(@fee),-(@taxFee),-(@totalFee),
					 @_befQty,   --出库后数量
					 @_befQty*@stockprice,--不含税
					 @_befQty*@stocktaxprice,--含税
					 @handlerid,@deptid,GETDATE(),@operatorId,@operatorId,GETDATE(),'',-(@ioQty*@stockprice),-(@ioQty*@stocktaxprice),@billNo)
				     set @errorSum=@errorSum+@@ERROR
	        end
	        else 
	        begin 
	          insert into IMS_Book
				(
					[bookId],[ioType],[companyId],[billId],[billNo],
					[objectId],[warehouseId],[lotNo],[locationNo],[eId],[itemId],[befQty],
					[befFee],[befTotalFee],[taxFlag],
					[taxrate],[befPrice],[discount],[discountFee],[ioQty],
					[price],[fee],[taxFee],[totalFee],
					[afterQty],
					[afterFee],
					[afterTotalFee],
					[handlerId],
					[deptId],
					[createTime],
					[creatorId],[auditorId],[auditTime],[memo],costFee,costTotalFee,billcode)
					values(replace(NEWID(),'-',''),@ioType,@companyId,@otherId,@otherNo,@objId,@warehouseId,
					@lotNo,@locationNo,@eId,@itemId,@onhandQty,@befFee,@befTotalFee,@taxFlag,@taxrate,(@taxPrice),
					100,0,-(@ioQty),@taxPrice,-(@fee),-(@taxFee),-(@totalFee),
					(@onhandQty-@ioQty),   --出库后数量
					(@onhandQty-@ioQty)*@stockprice,--不含税
					(@onhandQty-@ioQty)*@stocktaxprice,--含税
					 @handlerid,@deptid,@createTime,@operatorId,@operatorId,GETDATE(),'',-(@ioQty*@stockprice),-(@ioQty*@stocktaxprice),@billNo
				)
				 set @errorSum=@errorSum+@@ERROR
				 set @_befQty=isnull((@onhandQty-@ioQty),0)  --减去后的数量
				   print '第二个'+cast(@_befQty as varchar(32))+'-'+cast(@ioQty as varchar(32))
	        end  
	       
	        set @befItemId=@itemId
	        set @befLocationNo=@locationNo
	        update  IMS_Stock set 
	        onhandQty=onhandQty-@ioQty,
	        totalFee=@_befQty*@stocktaxprice,
	        fee=@_befQty*@stockprice,
	        lastOTime=GETDATE(),lastOPrice=@price,lastOTaxPrice=@taxPrice 
	        where   companyId=@companyId and warehouseId=@warehouseId 
	        and itemId=@itemId  and 
	        isnull(lotNo,'')=isnull(@lotNo,'') 
	        and isnull(locationNo,'')=isnull(@locationNo,'')
	        
	          set @errorSum=@errorSum+@@ERROR
	        update  IMS_Ledger set 
	        onhandQty=onhandQty-@ioQty,
	        fee=(onhandQty-@ioQty)*price,
	        totalFee=(onhandQty-@ioQty)*taxPrice,
	        lastOTime=GETDATE(),lastOPrice=@price,lastOTaxPrice=@taxPrice
	        where   companyId=@companyId and warehouseId=@warehouseId and itemId=@itemId
	         set @errorSum=@errorSum+@@ERROR
			Fetch  NEXT   FROM FMyCursor  into     
		@otherId,@viewOrder,@companyId,@warehouseId,@lotNo,@locationNo,@eId,@itemId
		,@ioQty,@pkgQty,@bulkQty,@price,@taxrate,@taxPrice,@fee,@taxFee,@totalFee,@remarks,
		@isSelected,@onhandQty,@ioType,@billNo,@objId,@stockprice,@stocktaxprice,@befFee,@befTotalFee,
		@handlerid,@deptid,@createTime
			
	     END
	    CLOSE FMyCursor
	  Deallocate FMyCursor
	end
	---更新商品库存
	UPDATE BAS_Item SET onhandQty=ISNULL(onhandQty,0)-(SELECT ISNULL(SUM(ioqty),0) FROM IMS_OtherDetail WHERE otherNo=@otherNo and itemId=BAS_Item.itemId)
	WHERE itemId in (SELECT DISTINCT itemId FROM IMS_OtherDetail WHERE otherNo=@otherNo )
	set @errorSum=@errorSum+@@ERROR
IF @errorSum<>0 ROLLBACK TRAN;
ELSE COMMIT TRAN;



go

