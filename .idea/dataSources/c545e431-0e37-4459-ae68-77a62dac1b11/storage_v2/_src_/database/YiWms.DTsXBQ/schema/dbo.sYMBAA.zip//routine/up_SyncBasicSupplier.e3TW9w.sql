

-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-01-15>
-- Description:	<Description:通过数据库方式同步供应商>
-- 依赖：
--      无
-- 关联：
--		主要联系人
-- =============================================

CREATE PROCEDURE [dbo].[up_SyncBasicSupplier] 
(
	@companyId VARCHAR(32),		--公司Id,如果前台调用，需传值，为空时，手动修改这个值
	@ownerId VARCHAR(32),		--业主Id
	@creatorId VARCHAR(32),		--操作员，前天调用的当前用户，后台执行时，可赋值
	@encrypt INT,				--是否对重要数据进行加密1-是;0-否
	@startTime DATETIME,		--同步供应商的开始时间（修改时间）
	@endTime DATETIME			--同步供应商的截至时间（修改时间）
)
AS
BEGIN
	--定义临时表变量，存储没有同步过的客户
	DECLARE @Customer TABLE(
		partnerId VARCHAR(32),			--客商（客户、供应商）ID
		partnerType INT,				--客商类型
		companyId VARCHAR(32),			--公司Id
		partnerNo VARCHAR(32),			--客商（客户、供应商）编码
		partnerName VARCHAR(200),		--客商（客户、供应商）名称
		shortName VARCHAR(100),			--客商（客户、供应商）简称
		partnerSpell VARCHAR(100),		--客商（客户、供应商）简称
		
		companyState VARCHAR(40),		--默地址（省/市）
		companyCity VARCHAR(40),		--默认地址（市/区）
		companyDistrict VARCHAR(40),	--默认地址（区/县）
		companyAddress VARCHAR(100),		--默认地址
		zip VARCHAR(40),				--默认地址（邮编）
		logisticsId VARCHAR(32),		--默认物流公司
		lineId VARCHAR(32),				--默认送货线路
		lineOrder INT,					--默认送货顺序
		contactName varchar(40),		--客商主要联系人名称
		sex varchar(10),				--联系人性别
		contactTitle NVARCHAR(1000),	--联系人职务（可加密）
		officeTel NVARCHAR(1000),		--联系人座机（可加密）
		mobileNo NVARCHAR(1000),		--联系人手机（可加密）
		email NVARCHAR(1000),			--联系人邮件地址(可加密）
		remarks VARCHAR(1000),			--备注
		frozenFor int,                  --是否冻结
		printName  varchar(100)         --客户打印标题
	)
	
	declare @flag int =0  --成功的标识
	
---------------------------------直接过滤掉不符合条件的---------------------------------------------------------	
	  declare  @existTab table(cardcode varchar(100),flag int)
	  /*------①  没有客户编码的  ------------*/
	    insert into  @existTab(cardcode,flag)
	    select ISNULL(cardcode,pinyinma) ,1 from  DBVIP.WMSSystem.dbo.sap_card 
	   where zt=0 and cardtype='供应商'  and ((cardcode is null) or (cardcode=''))
	  /*------②  没有客户名称    -----------*/
	  insert into  @existTab(cardcode,flag)
	  select ISNULL(cardcode,pinyinma),2 from  DBVIP.WMSSystem.dbo.sap_card    
	  where zt=0 and cardtype='供应商'  and ( (cardname is null) or (cardname=''))
	  ---更新
	  update  DBVIP.WMSSystem.dbo.sap_card  set zt=-1
	  where zt=0 and cardtype='供应商' and cardcode in (select distinct cardcode  from @existTab)
	  
	  /*----------写日志-------------------------*/
	  insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
      select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncBasicSupplier',cardcode,'供应商-缺少编码',GETDATE()  
      from    @existTab where flag=1
      
       insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
      select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncBasicSupplier',cardcode,'供应商-缺少名称',GETDATE()  
      from    @existTab where flag=2
----------------------------------------------------------------------------------------------	
	---修改状态
	update  DBVIP.WMSSystem.dbo.sap_card set zt=3 where zt=0 and cardtype='供应商'
	----------------------------------------------------------------------------
	BEGIN TRY
        BEGIN TRANSACTION
		--当前时间段内创建或者修改过的数据
	 insert into @Customer(partnerId,partnerType,companyId,partnerNo,partnerName,shortName,
		                       partnerSpell,companyState,companyCity,companyDistrict,companyAddress,
		                       zip,logisticsId,lineId,lineOrder,
		                       contactName,sex,contactTitle,officeTel,
		                       mobileNo,email,remarks,frozenFor,printName)
	 select distinct  REPLACE(NEWID(),'-',''),2,@companyId,cardcode,cardname,jcname,pinyinma,
	 a.areaId stateid,
	 c.areaId cityid,
     d.areaId countyid,
     address,
     zipcode,
     null,null,null,
     cntctprsn,gender,position,phone1,cellular,
     e_mail,'',(case frozenfor when 'Y' then 0 when 'N' then 1 else null end),printName
     from DBVIP.WMSSystem.dbo.sap_card b
     left join BAS_Area a 
     on a.areaType=2 and a.areaname=b.state
     left join BAS_Area c on c.areaType=3 
     and c.areaname=b.city
     left join BAS_Area d on d.areaType=4 and   d.areaname=b.county
	 where  b.zt=3 and cardtype='供应商'  
	 
		--同步客户数据
		--更新(公司、客户编码相同的客户最基本数据）
		UPDATE p SET p.partnerName=c.partnerName,p.shortName=c.shortName,p.partnerSpell=c.partnerSpell,
			p.remarks=c.remarks,editTime=GETDATE(),
			editorId=@creatorId,p.partnerState=c.frozenFor,p.reportTitle=c.printName
		FROM BAS_Partner p INNER JOIN @customer c 
		ON p.companyId=c.companyId AND p.partnerNo=c.partnerNo
		--写入不存在的客户
		INSERT INTO BAS_Partner(partnerId,partnerType,ownerId, companyId,partnerNo,partnerName,shortName,partnerSpell,remarks,isLocked,
			lockerId,lockedTime,createTime,creatorId,editTime,editorId,reportTitle)
		SELECT partnerId,partnerType,@ownerId,companyId,partnerNo,partnerName,shortName,partnerSpell,remarks,0,'',NULL,GETDATE(),
			@creatorId,GETDATE(),@creatorId,printName
		FROM @customer c 
		WHERE NOT EXISTS(SELECT 1 FROM BAS_Partner p WHERE p.companyId=c.companyId AND p.partnerNo=c.partnerNo)		
		
		--同步主要联系人
		--修改主要联系人（已经存在的
		UPDATE ct SET ct.contactName=t.contactName,ct.sex=t.sex,ct.contactTitle=t.contactTitle,
			ct.officeTel=t.officeTel,ct.mobileNo=t.mobileNo,ct.email=t.email
		FROM dbo.BAS_Contact ct INNER JOIN
			(
			 SELECT p.companyId,p.partnerId,c.contactName,c.sex,c.contactTitle,c.officeTel,c.mobileNo,c.email
			 FROM dbo.BAS_Partner p INNER JOIN 
				@Customer c ON p.companyId=c.companyId AND p.partnerNo=c.partnerNo
			 WHERE ISNULL(c.contactName,'')!='' 
				AND (ISNULL(c.officeTel,'')!='' OR ISNULL(c.mobileNo,'')!='') 
			) t ON ct.companyId=t.companyId AND ct.partnerId=t.partnerId 
		WHERE ct.isDisable=1		
			
		--写入客户主要联系人没有的（且联系人和联系电话不为空的）
		INSERT INTO BAS_Contact(contactId,companyId,partnerId,contactName,sex,contactTitle,officeTel,mobileNo,email,
			partnerType,isDefault,isDisable,isLocked,lockerId,lockedTime,createTime,creatorId,editTime,editorId)
		SELECT REPLACE(NEWID(),'-',''),p.companyId,p.partnerId,c.contactName,c.sex,c.contactTitle,c.officeTel,c.mobileNo,c.email,
			c.partnerType,1,0,0,'',NULL,GETDATE(),@creatorId,GETDATE(),@creatorId
		FROM BAS_Partner p INNER JOIN @Customer c 
		ON p.partnerType=1 and p.companyId=c.companyId AND p.partnerNo=c.partnerNo
		WHERE NOT EXISTS(SELECT 1 FROM BAS_Contact ct WHERE p.companyId=ct.companyId AND p.partnerId=ct.partnerId AND ct.isDefault=1)
			AND (ISNULL(c.contactName,'')!='') 
			AND (ISNULL(c.officeTel,'')!='' OR ISNULL(c.mobileNo,'')!='')
		--默认送货地址处理
		
		---完成后把同步状态更改为已完成
		set @flag=1
		COMMIT
	END TRY
	BEGIN CATCH
		--错误处理，抛出错误
		IF @@TRANCOUNT > 0
		ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END CATCH
	if @flag=1
	begin
	    update  DBVIP.WMSSystem.dbo.sap_card   
	    set zt=1 where zt=3  and cardtype='供应商'
     end
     else 
     begin
      update  DBVIP.WMSSystem.dbo.sap_card   
	    set zt=0 where zt=3  and cardtype='供应商'
     end 
END




go

