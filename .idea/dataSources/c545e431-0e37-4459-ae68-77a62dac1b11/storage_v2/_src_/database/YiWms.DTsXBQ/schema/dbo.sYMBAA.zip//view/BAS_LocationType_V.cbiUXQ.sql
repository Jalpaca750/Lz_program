
/*==============================================================*/
/* View: BAS_LocationType_V                                     */
/*==============================================================*/
create view BAS_LocationType_V as
SELECT a.loctypeId,a.loctypeNo,a.loctypeDesc,a.companyId,a.isStandard,
    CASE a.isStandard WHEN 1 THEN '是' ELSE '否' END AS standardLoc,a.locLong,
    a.locWidth,a.locHeight,a.locVolume,a.locWeight,a.useRate,a.useVolume,
    a.locRatio,a.isDisable,CASE a.isDisable WHEN 0 THEN '否' ELSE '是' END disableFlag,
    a.isLocked,a.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
    a.createTime,a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,
    u3.userNick AS editorName,a.isSelected
FROM BAS_LocationType a
    LEFT JOIN SAM_User u1 ON a.lockerId=u1.userId
    LEFT JOIN SAM_User u2 ON a.creatorId=u2.userId
    LEFT JOIN SAM_User u3 ON a.editorId=u3.userId
go

