
/*==============================================================*/
/* View: IMS_Transfer_V                                         */
/*==============================================================*/
--creator： Frank
--create time：  2016-03-10
--移仓单主表视图
create view IMS_Transfer_V as
SELECT t.transferNo,t.billNo,t.transferDate,t.companyId,c.companyName,t.outputId,wo.warehouseName AS outputName, 
	t.inputId,wi.warehouseName AS inputName,t.deptOutId,d1.deptNo AS deptOutNo,d1.deptName AS deptOutName, 
	t.deptInId,d2.deptNo AS deptInNo,d2.deptName AS deptInName,t.handlerId, e.employeeName AS handlerName, 
	t.ioState,CASE t.ioState WHEN 0 THEN '已作废' WHEN 1 THEN '待审核' WHEN 2 THEN '已审核' END AS ioStateName, 
	t.printNum,t.printId,u4.userNick AS printMan,CONVERT(VARCHAR(20),t.printTime,120) AS printTime,t.memo, 
	t.auditorId,u2.userNick AS auditorName,CONVERT(VARCHAR(20),t.auditTime,120) AS auditTime,t.isLocked,
	t.lockerId,u5.userNick AS lockerName,CONVERT(VARCHAR(20),t.lockedTime,120) AS lockedTime,t.creatorId,
	t.createTime,u1.userNick AS creatorName,t.editTime,t.editorId,u3.userNick AS editorName,t.isSelected
FROM dbo.IMS_Transfer AS t 
	INNER JOIN dbo.SAM_Company AS c ON t.companyId = c.companyId 
	INNER JOIN dbo.BAS_Warehouse AS wi ON t.inputId = wi.warehouseId 
	LEFT JOIN dbo.BAS_Warehouse AS wo ON t.outputId = wo.warehouseId 
	LEFT JOIN dbo.BAS_Department AS d1 ON t.deptOutId = d1.deptId 
	LEFT JOIN dbo.BAS_Department AS d2 ON t.deptInId = d2.deptId 
	LEFT JOIN dbo.BAS_Employee AS e ON t.handlerId = e.employeeId 
	LEFT JOIN dbo.SAM_User AS u2 ON t.auditorId = u2.userId 
	LEFT JOIN dbo.SAM_User AS u1 ON t.creatorId = u1.userId 
	LEFT JOIN dbo.SAM_User AS u3 ON t.editorId = u3.userId 
	LEFT JOIN dbo.SAM_User AS u4 ON t.printId=u4.userId
    LEFT JOIN dbo.SAM_User AS u5 ON t.lockerId=u5.userId
go

