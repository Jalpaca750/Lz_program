
/*
   SAM_UserSupplier 视图
*/
Create View SAM_UserSupplier_V
as
SELECT  a.userId,a.supplierId,a.companyId,_user.userNick,_user.userNo,_user.userState,
_sp.supplierName,_sp.supplierNo 
FROM   SAM_UserSupplier a inner join SAM_User _user
On  a.userId=_user.userId
INNER  JOIN  BAS_Supplier_V _sp On a.supplierId=_sp.supplierId 
go

