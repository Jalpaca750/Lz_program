
-- =============================================
-- Author:		<Frank.He>
-- Create date: <2017-07-02>
-- Description:	<获取出库复核明细 V1.0>
-- =============================================

CREATE FUNCTION [dbo].[uf_GetTackCheckDetail] 
(
	@companyId VARCHAR(32)
)
RETURNS TABLE
RETURN(
	SELECT a.pickingNo,a.companyId,a.billNo,a.waveBillNo,b.stockBillNo,a.getTime,a.createTime,
		b.itemId,bi.itemNo,bi.itemName,bi.itemCTitle,bi.itemETitle,bi.itemSpec,bi.itemSpell,
        bi.packageId,bi.barcode,bi.pkgBarcode,bi.colorName,bi.sizeName,bi.unitName,b.realQty,
        b.pickQty,b.stockQty,b.actualQty,c.checkerId,u.userNick AS checkerName,c.checkTime,
        bi.brandId,bi.brandCName,bi.categoryId,bi.categoryNo,bi.categoryCName
	FROM dbo.WMS_Picking a 
		INNER JOIN dbo.WMS_PickingDetail b ON a.pickingNo=b.pickingNo
		INNER JOIN dbo.WMS_PickingOrder c ON b.pickId=c.pickId
		INNER JOIN dbo.BAS_Item_V bi ON b.itemId=bi.itemId 
		LEFT JOIN SAM_User u ON c.checkerId=u.userId
	WHERE a.companyId=@companyId AND a.taskType=0 AND pickQty >0.0
)
go

