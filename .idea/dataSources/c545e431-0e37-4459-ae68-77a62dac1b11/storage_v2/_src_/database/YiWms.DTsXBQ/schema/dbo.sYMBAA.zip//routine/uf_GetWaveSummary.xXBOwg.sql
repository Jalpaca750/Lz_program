

CREATE FUNCTION [dbo].[uf_GetWaveSummary] 
(
    @companyId VARCHAR(32),         --公司Id
    @waveNo VARCHAR(32),			--波次No
    @isPackage INT					--0,散件;1-整件;9-所有的
)
RETURNS TABLE
RETURN(
    SELECT t.waveNo,w.billNo AS waveBillNo,w.companyId,t.itemId,sku.itemNo,sku.itemName,
        sku.itemSpec,sku.itemSpell,sku.barcode,sku.midBarcode,sku.bigBarcode,sku.pkgBarcode,
        sku.colorName,sku.sizeName,sku.packageId,sku.unitName,t.pickQty,wi.realQty,
        ISNULL(wi.checkState,20) AS checkState,
        CASE ISNULL(wi.checkState,20) WHEN 20 THEN '待复核' WHEN 30 THEN '已复核' END AS checkStateDesc 
    FROM (
            SELECT a.waveNo,b.itemId,SUM(b.pickQty*b.pkgRatio) AS pickQty 
            FROM WMS_Picking a
                INNER JOIN WMS_PickingDetail b ON a.pickingNo=b.pickingNo
            WHERE a.companyId=@companyId 
                AND a.waveNo=@waveNo 
                AND (b.isPackage=@isPackage OR (@isPackage=9 AND isPackage IN(0,1)))
            GROUP BY a.waveNo,b.itemId
        ) t INNER JOIN BAS_Item sku ON t.itemId=sku.itemId
        INNER JOIN WMS_Wave w ON t.waveNo=w.waveNo
        LEFT JOIN WMS_WaveItem wi ON t.waveNo=wi.waveNo AND t.itemId=wi.itemId
)
go

