
--creator：      Frank.He
--create time：  2017-04-06
--销售出库单等打印数据
--文之选发货单专用
--2019-05-09 增加订货人，件数（数量/整箱数量）
CREATE FUNCTION [dbo].[uf_GetDeliveryList] 
(
	@stockNo VARCHAR(32)
)
RETURNS TABLE
RETURN(
	SELECT a.stockNo,CASE ISNULL(p.reportTitle,'') WHEN '' THEN c.companyName ELSE p.reportTitle END AS reportTitle,
		a.groupId,a.ioType,a.orderType,CASE a.orderType WHEN 10 THEN '销售出库单' 
														WHEN 20 THEN '调拨出库单' 
														WHEN 30 THEN '经营领用单' 
														WHEN 31 THEN '管理领用单' 
														WHEN 32 THEN '其他出库单'
														WHEN 40 THEN '赠品出库单' 
														WHEN 50 THEN '报损报废单' END AS subTitle,a.billNo,a.collectOrder,
		w.warehouseNo,w.warehouseName,p.partnerNo AS customerNo,p.partnerName AS customerName,ISNULL(a1.areaName,a.receiverState) AS stateName,
		ISNULL(a2.areaName,a.receiverCity) AS cityName,ISNULL(a3.areaName,a.receiverDistrict) AS districtName,a.receiverAddress,
		ISNULL(a1.areaName,a.receiverState)+ISNULL(a2.areaName,a.receiverCity)+ISNULL(a3.areaName,a.receiverDistrict)+ISNULL(a.receiverAddress,'') AS fullAddress,
		ln.lineCode,ISNULL(ln.lineName,'') + '  ' + CAST(a.collectOrder AS VARCHAR(4)) AS lineName,a.receiverName,a.receiverMobile,a.receiverTel,
		LTRIM(ISNULL(a.receiverMobile,'') + ' ' + ISNULL(a.receiverTel,'')) AS fullTel,'' AS aBillFlag,
		a.settlementId,ISNULL(s.settlementName,a.settlementId) AS settlementName,a.auditTime,u2.userNick AS auditorName,a.shipDate,a.shipTime,
		a.salesId,ISNULL(e1.employeeName,a.salesId) AS salesName,a.deptId,ISNULL(d.deptName,a.deptId) AS deptName, a.expressNo,lg.logisticsCode,
		ISNULL(lg.logisticsName,a.logisticsId) AS logisticsName,a.mergeNo,ISNULL(a.printNum,0) + 1 AS printNum,a.memo,u3.userNick AS reviewerName,
		'订单:' + ISNULL(a.mergeNo,'') + ';' + ISNULL(a.memo,'') AS orderMemo,ROW_NUMBER() OVER (ORDER BY b.viewOrder) AS viewOrder,sku.itemNo,
		sku.itemName,sku.itemSpec,sku.packageId,sku.barcode,sku.midBarcode,sku.bigBarcode,sku.pkgBarcode,sku.colorName,sku.sizeName,sku.unitName,
		b.stockQty,ISNULL(pk.actQty,0.0) AS actQty,b.befPrice,b.price,b.discount,ISNULL(b.discountFee,0.0) AS discountFee,
		ROUND(ISNULL(pk.actQty,0.0)/sku.pkgRatio,4) AS pkgQty,
		dbo.uf_GetUpper((SELECT SUM(ee.price*ee.stockQty) AS totalFee FROM SAD_StockDetail ee WHERE ee.stockNo=b.stockNo)) AS upperRMB,
		CAST(pk.actQty*b.price AS DECIMAL(20,2)) AS totalFee,b.remarks,u1.userNick AS creatorName,a.organizeId,a.BuyerID,
		a.lclCount AS lclQty,a.fclCount AS fclQty,ISNULL(a.lclCount,0)+ISNULL(a.fclCount,0) AS totalQty,a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5,
		CASE ISNULL(pk.zFlag,0.0) WHEN 0.0 THEN '' ELSE 'Z ' END + ISNULL(STUFF((SELECT ',' + CAST(boxNum AS VARCHAR(10)) FROM WMS_PackingBox_V WHERE stockId=b.stockId FOR XML PATH('')),1,1,''),'') AS boxNums,
		LTRIM(CASE ISNULL(a.fclCount,0) WHEN 0 THEN '' ELSE '整箱  ' + CAST(CAST(a.fclCount AS INT) AS VARCHAR(40)) END + CASE ISNULL(a.lclCount,0) WHEN 0 THEN '' ELSE '  拼箱  ' + CAST(CAST(a.lclCount AS INT) AS VARCHAR(40)) END) + ' 共 ' + CAST(CAST(ISNULL(a.lclCount,0)+ISNULL(a.fclCount,0) AS INT) AS VARCHAR(40)) + ' 箱' AS packageDesc,a.poNo
	FROM dbo.SAD_StockDetail AS b 
		INNER JOIN dbo.SAD_Stock AS a ON b.stockNo = a.stockNo 
		INNER JOIN dbo.BAS_Item AS sku ON b.itemId = sku.itemId 
		INNER JOIN dbo.BAS_Partner p ON a.customerId=p.partnerId
		INNER JOIN dbo.SAM_Company c ON a.companyId=c.companyId      
		INNER JOIN dbo.BAS_Warehouse AS w ON a.warehouseId=w.warehouseId
		INNER JOIN (SELECT stockNo,COUNT(1) as totalQty,SUM(CASE isPackage WHEN 1 THEN 0 ELSE 1 END) AS lclCount			
                    FROM dbo.WMS_PickingOrder
                    WHERE stockNo=@stockNo
                    GROUP BY stockNo) pkg ON a.stockNo=pkg.stockNo                    
		LEFT JOIN dbo.BAS_Department d ON a.deptId=d.deptId
		LEFT JOIN dbo.BAS_Area a1 ON a.receiverState=a1.areaId 
		LEFT JOIN dbo.BAS_Area a2 ON a.receiverCity=a2.areaId 
		LEFT JOIN dbo.BAS_Area a3 ON a.receiverDistrict=a3.areaId 
		LEFT JOIN dbo.BAS_AddressLine ln ON a.lineId=ln.lineId 
		LEFT JOIN dbo.BAS_Settlement s ON a.settlementId=s.settlementId  
		LEFT JOIN dbo.BAS_Logistics lg ON a.logisticsId=lg.logisticsId 
		LEFT JOIN dbo.SAM_User u1 ON a.creatorId=u1.userId
		LEFT JOIN dbo.SAM_User u2 ON a.auditorId=u2.userId
		LEFT JOIN dbo.SAM_User u3 ON a.reviewerId=u3.userId
		LEFT JOIN dbo.BAS_Employee e1 ON a.salesId=e1.employeeId      
		LEFT JOIN (SELECT stockId,SUM(CASE isPackage WHEN 0 THEN pickQty WHEN 1 THEN pickQty * pkgRatio END) AS actQty,
						SUM(CASE isPackage WHEN 0 THEN 0 WHEN 1 THEN pickQty END) AS zFlag,
						SUM(CASE isPackage WHEN 1 THEN pickQty ELSE 0 END) AS fclCount
				   FROM WMS_PickingDetail
				   WHERE stockNo=@stockNo
				   GROUP By stockId) pk ON b.stockId=pk.stockId
	WHERE a.stockNo=@stockNo AND ISNULL(b.pickQty,0.0)>0.0
)




go

