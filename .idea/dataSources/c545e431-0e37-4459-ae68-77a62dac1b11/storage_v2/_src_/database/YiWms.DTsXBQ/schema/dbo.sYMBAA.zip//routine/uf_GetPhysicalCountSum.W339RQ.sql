CREATE FUNCTION [dbo].[uf_GetPhysicalCountSum]
(
    @companyId VARCHAR(32),
    @startTime VARCHAR(32),
    @endTime VARCHAR(32)
)    
RETURNS @result TABLE
(
	pointId VARCHAR(32),
	pointNo VARCHAR(32),
	pointDate DATE,
	warehouseId VARCHAR(32),
	warehouseNo VARCHAR(32),
	warehouseName VARCHAR(200),
	lotNo VARCHAR(32),
	locationNo VARCHAR(32),
	itemId VARCHAR(32),
	itemNo VARCHAR(32),
	itemName VARCHAR(200),
	itemSpec VARCHAR(200),
	itemSpell VARCHAR(200),
	barcode VARCHAR(100),	
	midBarcode VARCHAR(100),
	bigBarcode VARCHAR(100),
	pkgBarcode VARCHAR(100),
	brandId VARCHAR(32),
	brandCName VARCHAR(200),
	categoryId VARCHAR(32),
	categoryNo VARCHAR(32),
	categoryCName VARCHAR(200),
	realQty DECIMAL(20,6),
	onhandQty DECIMAL(20,6),
	diffQty DECIMAL(20,6)
)
AS
BEGIN
    DECLARE @tmpCheck TABLE(pointId VARCHAR(32),pointNo VARCHAR(32),warehouseId VARCHAR(32),lotNo VARCHAR(32),locationNo VARCHAR(32),itemId VARCHAR(32),realQty DECIMAL(20,6),onhandQty DECIMAL(20,6));
    DECLARE @tmpDiff TABLE(pointId VARCHAR(32),warehouseId VARCHAR(32),lotNo VARCHAR(32),locationNo VARCHAR(32),itemId VARCHAR(32),ioQty DECIMAL(20,6));    
    --录入的盘点与盘点库存默认无差异    
    INSERT INTO @tmpCheck(pointId,pointNo,warehouseId,lotNo,locationNo,itemId,onhandQty,realQty)    
    SELECT cs.pointId,t.pointNo,cs.warehouseId,ISNULL(cs.lotNo,'') AS lotNo,ISNULL(cs.locationNo,'') AS locationNo,cs.itemId,cs.onhandQty,cs.onhandQty
    FROM dbo.IMS_CheckStock cs
        INNER JOIN (SELECT c.pointId,c.pointNo,a.companyId,a.warehouseId,b.lotNo,b.locationNo,b.itemId,SUM(b.actQty) AS realQty
                    FROM dbo.IMS_Check a
                        INNER JOIN dbo.IMS_CheckDetail b ON a.checkNo=b.checkNo
                        INNER JOIN dbo.IMS_CheckPoint c ON a.pointId=c.pointId
                    WHERE (c.companyId=@companyId) 
                        AND (a.createTime BETWEEN @startTime AND @endTime)
                        AND (c.checkState=30)
                        AND (c.parentId='-1')  
                    GROUP BY c.pointId,c.pointNo,a.companyId,a.warehouseId,b.lotNo,b.locationNo,b.itemId
                    ) t ON cs.pointId=t.pointId AND cs.warehouseId=t.warehouseId AND ISNULL(cs.lotNo,'')=ISNULL(t.lotNo,'') AND ISNULL(cs.locationNo,'')=ISNULL(t.locationNo,'') AND cs.itemId=t.itemId       
    --统计对应盘点设置中差异数据
    INSERT INTO @tmpDiff(pointId,warehouseId,lotNo,locationNo,itemId,ioQty)
    SELECT CASE c.parentId WHEN '-1' THEN c.pointId ELSE c.parentId END AS pointId,b.warehouseId,ISNULL(b.lotNo,'') AS lotNo,ISNULL(b.locationNo,'') AS locationNo,b.itemId,b.ioQty
    FROM dbo.IMS_Adjust a
        INNER JOIN dbo.IMS_AdjustDetail b ON a.adjustNo=b.adjustNo
        INNER JOIN dbo.IMS_CheckPoint c ON a.pointId=c.pointId
    WHERE (c.companyId=@companyId) 
        AND (a.createTime BETWEEN @startTime AND @endTime)
        AND (a.ioState=20);    
    --更新差异数据
    UPDATE a SET a.realQty=ISNULL(a.realQty,0.0)+t.ioQty
    FROM @tmpCheck a
        INNER JOIN @tmpDiff t ON a.pointId=t.pointId AND a.warehouseId=t.warehouseId AND a.lotNo=t.lotNo AND a.locationNo=t.locationNo AND a.itemId=t.itemId;     
    --手工盘点数据
    INSERT INTO @tmpCheck(pointId,pointNo,warehouseId,lotNo,locationNo,itemId,onhandQty,realQty)              
    SELECT a.adjustNo,a.billNo,b.warehouseId,b.lotNo,b.locationNo,b.itemId,ISNULL(b.afterQty,0.0)-ISNULL(b.ioQty,0.0) AS onhandQty,b.afterQty
    FROM dbo.IMS_Adjust a
        INNER JOIN dbo.IMS_AdjustDetail b ON a.adjustNo=b.adjustNo
    WHERE (a.companyId=@companyId) 
        AND (a.createTime BETWEEN @startTime AND @endTime)
        AND (a.ioState=20)
        AND ISNULL(a.pointId,'')='';
    --写入报表
    INSERT INTO @result(pointId,pointNo,pointDate,warehouseId,warehouseNo,warehouseName,lotNo,
	    locationNo,itemId,itemNo,itemName,itemSpec,itemSpell,barcode,midBarcode,bigBarcode,pkgBarcode,
	    brandId,brandCName,categoryId,categoryNo,categoryCName,realQty,onhandQty,diffQty)
	SELECT a.pointId,a.pointNo,cp.pointDate,a.warehouseId,w.warehouseNo,w.warehouseName,a.lotNo,
	    a.locationNo,a.itemId,b.itemNo,b.itemName,b.itemSpec,b.itemSpell,b.barcode,b.midBarcode,
	    b.bigBarcode,b.pkgBarcode,b.brandId,b.brandCName,b.categoryId,b.categoryNo,b.categoryCName,
	    a.realQty,a.onhandQty,ISNULL(a.realQty,0.0)-ISNULL(a.onhandQty,0.0) AS diffQty
	FROM @tmpCheck a 
	    INNER JOIN dbo.BAS_Goods_V b ON a.itemId=b.itemId
	    INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	    INNER JOIN dbo.IMS_CheckPoint cp ON a.pointId=cp.pointId;
    RETURN
END
go

