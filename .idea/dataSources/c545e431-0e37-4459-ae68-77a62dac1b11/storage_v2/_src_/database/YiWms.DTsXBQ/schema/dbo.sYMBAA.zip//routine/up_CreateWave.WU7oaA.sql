-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2016-30-10>
-- Description:	<Description:手动生成波茨分拣计划（摘果法） V1.2.11>
-- 依赖：
--      分配策略
--      上架策略
--      周转箱规格
--      库存数量
--      销售出库单
--      补货表
--      分配策略取得产品对应的仓库、库区、批次等数据
--      对应函数(uf_GetPickLocation)
--               uf_GetPutawayLocation
-- Modify:
--      Frank.He 2017-08-15 修改库位分配算法与拼箱算法； 
--		Frank.He 2017-09-01 增加波次中订单的序号  
--		Frank.He 2017-09-07 增加分拣任务明细表中单品体积与单品重量的存储 
--		Frank.He 2017-09-17 增加整件标签打印方式（每件一个标签/N件只生成一个标签）   
--		Frank.He 2017-09-20 去掉前面一个参数控制，增加整件托盘拣货和整件单品超过一定数量只生成一张标签的控制  
--		Frank.He 2017-09-26 重新处理IMS_Ledger表可用量 
--		Frank.He 2017-10-16 散件分拣任务生成模式改为按单顺序生成 V1.2.8（第6部分）
--		Frank.He 2017-12-19 修正订单库存不符时，没有分拣到任何商品的订单的占用量的Bug V1.2.9
--		Frank.He 2018-01-02 修正按单品生成整件任务的Bug V1.2.10(第6部分)
--		Frank.He 2018-02-08 第2部分末尾，把库存异常或者库位异常的数据移除波次计划 V1.2.11
-- =============================================
CREATE PROCEDURE [dbo].[up_CreateWave] 
(
    @stocks Filter_Type READONLY,	--charId对应StockNo字段
    @companyId VARCHAR(32),			--公司Id
    @creatorId VARCHAR(32)			--操作员
)
AS
BEGIN
    DECLARE @stockId VARCHAR(32),				--出库单明细Id
			@stockNo VARCHAR(32),				--出库单No
			@stockBillNo VARCHAR(32),			--出库单编号
			@viewOrder INT,						--序号
			@warehouseId VARCHAR(32),			--仓库Id
			@ownerId VARCHAR(32),				--业主Id
			@itemId VARCHAR(32),				--产品Id
			@itemNo VARCHAR(32),				--商品编码
			@stockQty DECIMAL(20,6),			--出库单（订单）数量
			@orderQty DECIMAL(20,6),			--订单数量
			@pkgRatio INT,						--包装数量
			@itemVolume DECIMAL(20,3),			--散件体积
			@itemWeight DECIMAL(10,4),			--散件重量
			@allowSplit INT,					--允许单条拆单	0,不拼箱;1,拼箱;2,自拼箱	
			@splitRatio INT						--自拼箱数量		
	DECLARE	@availQty DECIMAL(20,6),			--库存可用量
			@bulkQty DECIMAL(20,6),				--散件数量	
			@pkgQty DECIMAL(20,6),				--整箱数量			
			@totalQty DECIMAL(20,6),			--临时总数量
			@pickQty DECIMAL(20,6),				--临时分拣数量
			@needQty DECIMAL(20,6),				--实际需要的补货数量
			@bhQty DECIMAL(20,6),				--补货数量
			@skuQty DECIMAL(20,6)				--单品分拣件数
	DECLARE	@shipNo VARCHAR(32)					--装车单No
	DECLARE @plVolumn DECIMAL(20,3),			--托盘体积
			@plId VARCHAR(32),					--托盘Id
			@maxVolumn DECIMAL(20,3),			--最大箱体积
			@maxWeight DECIMAL(10,4),			--单箱最大重量(大小箱一致）
			@maxSizeId VARCHAR(32),				--最大周转箱规格Id			
			@bulkVolumn DECIMAL(20,3),			--散件体积（小计）
			@bulkWeight DECIMAL(10,4),			--散件重量（小计）
			@sizeId VARCHAR(32),				--周转箱规格Id
			@itemBoxes INT,						--单品装箱数（单品拆箱）
			@itemCount INT,						--单品数量（单品拆箱）
			@sumVolumn DECIMAL(20,3),			--散件体积累计
			@sumWeight DECIMAL(10,4),			--散件重量累计
			@boxCount INT,						--临时变量
			@detailId INT						--明细id
	DECLARE @policyId VARCHAR(32),				--策略Id
			@lineId VARCHAR(32),				--线路Id
			@cargoArea VARCHAR(32),				--集货区
			@logisticsId VARCHAR(32),			--物流公司Id
			@orderType VARCHAR(32),				--订单类型
			@minRows INT,						--订单Sku条目数（最小）
			@maxRows INT,						--订单Sku条目数（最大）
			@minOrders INT,						--最小订单数
			@maxOrders INT,						--最大订单数
			@limitedVolumn DECIMAL(20,3),		--最大体积
			@limitedWeight DECIMAL(10,4),		--最大总量
			@unitLevel VARCHAR(10),				--EA-散件;CS-整箱
			@waveCount INT,						--波茨策略存在最大订单数时的波茨数
			@waveIndex INT,						--波茨索引
			@waveNo VARCHAR(32),				--波茨No
			@waveBillNo VARCHAR(32),			--波茨编号
			@pickingNo VARCHAR(32),				--分拣任务No
			@pickBillNo VARCHAR(32),			--分拣任务编号
			@pickId VARCHAR(32),				--任务订单Id	
			@boxIndex INT,						--临时变量		
			@maxBoxes INT,						--单张出库单最大拼箱数
			@lclQty INT,					    --拼箱数(最大拼箱数或者总拼箱数）
			@fclQty INT							--整箱数
	DECLARE	@replenishId VARCHAR(32),
			@replenishBillNo VARCHAR(32),		--补货单编号
			@regionId VARCHAR(32),				--库区Id
			@lotNo VARCHAR(32),					--批次编号
			@locationNo VARCHAR(32),			--库位编号
			@fromLocation VARCHAR(32),			--补货下架库位编号
			@fromRegion	VARCHAR(32),			--补货下架库区
			@errorMsg VARCHAR(2000),			--错误消息
			@pickOrder INT,						--临时表@tmpPick主键Id
			@replenishQty DECIMAL(20,6),		--补货数量
			@caseTaskMode VARCHAR(200),			--整件任务模式：1-按商品生成整件任务;0-按单生成整件任务
			@replenishTaskMode VARCHAR(200),	--补货任务模式；1-按单条商品生成补货任务;0-按波茨生成补货任务	
			@afteroonTime VARCHAR(100),			--下午波次排序截至时间（过这个时间即为第二天送货订单）
			@fclMaxCount INT,					--单个产品件数超过N时，生成一个标签
			@shipDate DATE,						--送货日期	
			@shipTime VARCHAR(10)				--下午;上午	
	DECLARE @createTime DATETIME				--当前时间		
	SET @createTime=GETDATE();		
	--存储需要生成波茨的出库单
	DECLARE @tmpHead TABLE(viewOrder INT,stockNo VARCHAR(32),billNo VARCHAR(32),ownerId VARCHAR(32),lineId VARCHAR(32),logisticsId VARCHAR(32),orderType INT,skuCount INT,lclVolumn DECIMAL(20,6),maxBoxes INT,flag INT);
	DECLARE @tmpDetail TABLE(stockId VARCHAR(32),stockNo VARCHAR(32),billNo VARCHAR(32),viewOrder INT,ownerId VARCHAR(32),warehouseId VARCHAR(32),itemId VARCHAR(32),itemNo VARCHAR(32),stockQty DECIMAL(20,6),bulkQty DECIMAL(20,6),pkgQty DECIMAL(20,6),itemVolume DECIMAL(20,3),itemWeight DECIMAL(10,4), pkgRatio INT,boxNum INT DEFAULT 1,sizeId VARCHAR(32),shipNo VARCHAR(32),allowSplit INT,printNum INT,splitRatio INT,lineId VARCHAR(32));
	--临时分拣库位表
	DECLARE @tmpLocation TABLE(viewOrder INT,warehouseId VARCHAR(32),regionId VARCHAR(32),lotNo VARCHAR(32),locationNo varchar(32),itemId VARCHAR(32),pickQty DECIMAL(20,6),needReplenish INT);
	--临时分配表
	DECLARE @tmpAllocate TABLE(detailId INT IDENTITY(1,1),stockId VARCHAR(32),stockNo VARCHAR(32),billNo VARCHAR(32),warehouseId VARCHAR(32),ownerId VARCHAR(32),regionId VARCHAR(32),lotNo VARCHAR(32),locationNo VARCHAR(32),itemId VARCHAR(32),unitLevel VARCHAR(10),pickQty DECIMAL(20,6),realQty DECIMAL(20,6),pkgRatio INT,itemVolume DECIMAL(20,3),itemWeight DECIMAL(10,4), boxNum INT DEFAULT 1,sizeId VARCHAR(32),shipNo VARCHAR(32),allowSplit INT,splitRatio INT,lineId VARCHAR(32));
	--补货下架数据
	DECLARE @tmpReplenish TABLE(replenishId VARCHAR(32),stockId VARCHAR(32),stockNo VARCHAR(32),viewOrder INT,warehouseId VARCHAR(32),regionId VARCHAR(32),lotNo VARCHAR(32),locationNo varchar(32),itemId VARCHAR(32),pickQty DECIMAL(20,6),toRegionId VARCHAR(32),toLocationNo varchar(32),needReplenish INT,pkgQty INT,pkgRatio INT);
	--临时分拣表
	DECLARE @tmpPick TABLE(pickOrder INT IDENTITY(1,1),stockId VARCHAR(32),stockNo VARCHAR(32),stockBillNo VARCHAR(32),ownerId VARCHAR(32),warehouseId VARCHAR(32),regionId VARCHAR(32),itemId VARCHAR(32),batchNo VARCHAR(32),locationNo VARCHAR(32),pickQty DECIMAL(20,6),isPackage INT,itemVolume DECIMAL(20,3),itemWeight DECIMAL(10,4),pkgRatio INT,boxNum INT,sizeId VARCHAR(32),shipNo VARCHAR(32),lineId VARCHAR(32));
	--临时表
	DECLARE @sales TABLE(policyId VARCHAR(32),stockNo VARCHAR(32),viewOrder INT,stockId VARCHAR(32),bulkVolumn DECIMAL(20,6),bulkWeight DECIMAL(10,4),pickQty DECIMAL(20,6),itemVolume DECIMAL(20,6),itemWeight DECIMAL(10,4),allowSplit INT,splitRatio INT,lineId VARCHAR(32),boxOrder INT,stockBillNo VARCHAR(32),sizeId VARCHAR(32));
	--清除错误日志
	DELETE FROM SAM_Error WHERE companyId=@companyId AND funCode='up_CreateWaveTask' AND creatorId=@creatorId;	
	--1.获取初始设置与必要设置检查
	--@caseTaskMode 整件任务模式：1-按商品生成整件任务;0-按单生成整件任务;2-按托盘拼整件任务
	SELECT @caseTaskMode=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='WAVE_TASK_CASE_MODE';
	SET @caseTaskMode = ISNULL(@caseTaskMode,'1');
	--补货任务模式；1-按单条商品生成补货任务;0-按波茨生成补货任务
	SELECT @replenishTaskMode=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='WAVE_TASK_REPLENISH_MODE';
	SET @replenishTaskMode = ISNULL(@replenishTaskMode,'1');
	--下午波次排序截至时间（过这个时间即为第二天送货订单）
	SELECT @afteroonTime=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='WAVE_AFTEROON_TIME'; 
	SET @afteroonTime=ISNULL(@afteroonTime,'00:00:00')
	--单个产品件数超过N时，生成一个标签
	SELECT @fclMaxCount=CAST(configValue AS INT) FROM SAM_Config WHERE companyId=@companyId AND configCode='ITEM_CASE_MAX_COUNT'; 
	SET @fclMaxCount=ISNULL(@fclMaxCount,0);
	IF (@fclMaxCount<1)
		SET @fclMaxCount=1;
	IF (DATEDIFF(SS,GETDATE(),CONVERT(VARCHAR(10),GETDATE(),23) + ' ' + @afteroonTime)>=0)
	BEGIN
		--当前下午送
		SET @shipDate=GETDATE();
		SET @shipTime='下午';
	END
	ELSE
	BEGIN
		--第二天上午送
		SET @shipDate=DATEADD(d,1,GETDATE());
		SET @shipTime='上午';
	END
	--最大周转箱体积
	SELECT @maxVolumn=MAX(boxVolume) FROM WMS_BoxSize WHERE companyId=@companyId AND boxType=1;
	--最大周转箱规格Id,承载
	SELECT TOP 1 @maxSizeId=sizeId,@maxWeight=boxBearing FROM WMS_BoxSize WHERE companyId=@companyId AND boxType=1 AND boxVolume=@maxVolumn;
	--托盘体积
	SELECT TOP 1 @plId=sizeId,@plVolumn=boxVolume FROM WMS_BoxSize WHERE companyId=@companyId AND boxType=3;
	--1.1摘出当前需要编制计划的单据
	--订单数据（出库单30-已排车的数据——30可能改为已排线）
	--统计出库单，仓库、业主、线路、物流公司、单据类型、每单SKU数、总体积、总重量等
	IF NOT EXISTS(SELECT 1 FROM @stocks)
		INSERT INTO @tmpHead(viewOrder,stockNo,billNo,ownerId,lineId,logisticsId,orderType,skuCount,flag)
		SELECT ROW_NUMBER() OVER (ORDER BY a.billNo),a.stockNo,a.billNo,a.ownerId,a.lineId,a.logisticsId,
			a.orderType,b.skuCount,a.flag
		FROM dbo.SAD_Stock a INNER JOIN
			(SELECT stockNo,COUNT(1) AS skuCount
			 FROM SAD_StockDetail
			 GROUP BY stockNo) b ON a.stockNo=b.stockNo
		WHERE (a.companyId=@companyId)			--公司Id
			AND (a.isLocked=1)					--签出状态
			AND (a.lockerId=@creatorId)			--操作员签出的数据 
			AND (a.taskState=30)				--10-待审核；20-已审核；30-已排车；40-待配货；50-已配货(待复核)；60-待发货； 70-已发货
			AND (a.aFlag=0 OR a.aFlag=1)		--aFlag:0-普通订单;1-有A单的订单;2-A单（A单不配货）  F10A单专用用数据，请不要删除
	ELSE
		INSERT INTO @tmpHead(viewOrder,stockNo,billNo,ownerId,lineId,logisticsId,orderType,skuCount,flag)
		SELECT ROW_NUMBER() OVER (ORDER BY a.billNo),a.stockNo,a.billNo,a.ownerId,a.lineId,a.logisticsId,
			a.orderType,b.skuCount,a.flag
		FROM dbo.SAD_Stock a INNER JOIN
			(SELECT stockNo,COUNT(1) AS skuCount
			 FROM SAD_StockDetail
			 GROUP BY stockNo) b ON a.stockNo=b.stockNo
		WHERE (a.companyId=@companyId)			--公司Id
			AND (EXISTS(SELECT 1 FROM @stocks c WHERE a.stockNo=c.charId))			--选中的单据
			AND (a.isLocked=1)					--签出状态
			AND (a.lockerId=@creatorId)			--操作员签出的数据
			AND (a.taskState=30)				--10-待审核；20-已审核；30-已排车；40-待配货；50-已配货(待复核)；60-待发货； 70-已发货
			AND (a.aFlag=0 OR a.aFlag=1)		--aFlag:0-普通订单;1-有A单的订单;2-A单（A单不配货）  F10A单专用用数据，请不要删除
	--装车改在最后一步完成，ShipNo作废
	INSERT INTO @tmpDetail(stockId,stockNo,billNo,viewOrder,ownerId,warehouseId,itemId,itemNo,stockQty,bulkQty,pkgQty,
		itemVolume,itemWeight,pkgRatio,allowSplit,printNum,splitRatio,lineId)
	SELECT a.stockId,a.stockNo,b.billNo,a.viewOrder,b.ownerId,a.warehouseId,a.itemId,bi.itemNo,a.stockQty,0.0,0.0,
		bi.itemVolume,CASE ISNULL(bi.itemWeight,0.0) WHEN 0.0 THEN 0.0001 ELSE bi.itemWeight END,bi.pkgRatio,
		ISNULL(bi.allowSplit,1),CASE ISNULL(bi.printControl,0) WHEN 1 THEN -1 ELSE 0 END,ISNULL(bi.splitRatio,0),b.lineId
	FROM SAD_StockDetail a 
		INNER JOIN @tmpHead b ON a.stockNo=b.stockNo
		INNER JOIN BAS_Item bi ON a.itemId=bi.itemId
	WHERE a.isVirtual=0 
	ORDER BY b.billNo,a.viewOrder;		
	--1.2必要设置检查
	--如果没有维护周转箱规格，则直接退出（写错误日志）
	IF (ISNULL(@maxVolumn,0.0)=0.0)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_NON_BOXSIZE','请您先维护周转箱规格！','','');
		RETURN;
	END
	--粗略检查是否设置件/箱分配策略
	IF NOT EXISTS(SELECT 1 FROM WMS_PickingPolicy WHERE companyId=@companyId AND isDisable=0 AND (unitLevel='EA' OR unitLevel='CS')) 
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_NON_PICKING_POLICY','请您先维护配货策略！','','');
		RETURN;
	END
	--粗略检查是否设置件上架策略
	IF NOT EXISTS(SELECT 1 FROM WMS_PutawayPolicy WHERE companyId=@companyId AND isDisable=0 AND (unitLevel='EA')) 
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_NON_PUTAWAY_POLICY','请您先维护上架策略！','','');
		RETURN;
	END
	--如果没有需要生成计划的单据
	IF NOT EXISTS(SELECT 1 FROM @tmpHead)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_NO_DATA','没有需要生成波茨计划的数据！','','');
		RETURN;
	END			
	--判断商品资料是否齐全(整箱数量为0)
	IF EXISTS(SELECT 1 FROM @tmpDetail WHERE pkgRatio=0 OR itemVolume=0.0)
	BEGIN
		SET @errorMsg='';
		SELECT @errorMsg='[' + itemNo + '],' + @errorMsg
		FROM @tmpDetail 
		WHERE pkgRatio=0 OR itemVolume=0.0;
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_ITEM_ERROR','商品' + @errorMsg + '整箱数量为0，请先设置好再试！','','');
		RETURN;
	END	
	BEGIN TRY
		BEGIN TRANSACTION
		--2.对发货数据进行预分配
		--循环需要分拣的单据和产品
		DECLARE myCursor CURSOR
		FOR SELECT stockId,stockNo,billNo,warehouseId,ownerId,itemId,itemNo,stockQty,pkgRatio,itemVolume,itemWeight,allowSplit,splitRatio,lineId
			FROM @tmpDetail
			ORDER BY billNo,viewOrder 
		OPEN myCursor
		FETCH NEXT FROM myCursor INTO @stockId,@stockNo,@stockBillNo,@warehouseId,@ownerId,@itemId,@itemNo,@stockQty,@pkgRatio,@itemVolume,@itemWeight,@allowSplit,@splitRatio,@lineId
		WHILE @@FETCH_STATUS=0
		BEGIN
			SET @orderQty=@stockQty;
			--判断可用量是否足够整仓
			SELECT @availQty=SUM(ISNULL(onhandQty,0.0)-ISNULL(allocQty,0.0)+ISNULL(onwayQty,0.0))
			FROM IMS_Stock
			WHERE warehouseId=@warehouseId AND itemId=@itemId 
				AND ISNULL(onhandQty,0.0)-ISNULL(allocQty,0.0)+ISNULL(onwayQty,0.0)>0;
			--如果可用量不够发货数量，则可用量为发货数量(有多少，发多少)
			IF (ISNULL(@stockQty,0.0)-ISNULL(@availQty,0.0)>0.0)
				SET @stockQty=@availQty;
			--需要分拣的商品，进行分拣处理				
			IF (ISNULL(@stockQty,0.0)>0.0)
			BEGIN
				--2.1对分拣数量进行整散重新计算（预防小数情况）
				SET @bulkQty=@stockQty % @pkgRatio;
				SET @pkgQty=FLOOR(@stockQty / @pkgRatio);
				--2.2 整箱分拣
				IF (ISNULL(@pkgQty,0.0)>0.0)
				BEGIN
					SET @totalQty=0.0;
					--分拣数量(订单上的实际数量)
					SET @pickQty=@pkgQty*@pkgRatio;										
					DELETE FROM @tmpLocation;
					--取得整箱分拣库位，分拣数量
					INSERT INTO @tmpLocation(viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)
					SELECT viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,FLOOR(pickQty/@pkgRatio),needReplenish
					FROM dbo.uf_GetPickLocation(@companyId,@warehouseId,@ownerId,@itemId,@pickQty,'CS',0)	
					WHERE FLOOR(pickQty/@pkgRatio)>0				
					--没有分配到足够整件的数量
					IF (NOT EXISTS(SELECT 1 FROM @tmpLocation)) 
					BEGIN
						SET @pkgQty=0.0;
						--转入拆零分拣
						SET @bulkQty=ISNULL(@bulkQty,0.0)+ISNULL(@pickQty,0.0);
						--更新出库单明细件分拣数量
						UPDATE @tmpDetail SET pkgQty=0.0 WHERE stockId=@stockId;						
					END
					ELSE
					BEGIN
						--已分拣数量
						SELECT @totalQty=SUM(pickQty*@pkgRatio) FROM @tmpLocation											
						--写入临时分配表
						INSERT INTO @tmpAllocate(stockId,stockNo,billNo,warehouseId,ownerId,regionId,lotNo,locationNo,itemId,pickQty,realQty,unitLevel,itemVolume,itemWeight,pkgRatio,allowSplit,splitRatio,lineId)
						SELECT @stockId,@stockNo,@stockBillNo,@warehouseId,@ownerId,regionId,lotNo,locationNo,itemId,pickQty,pickQty*@pkgRatio,'CS',@itemVolume,@itemWeight,@pkgRatio,@allowSplit,@splitRatio,@lineId
						FROM @tmpLocation;					
						--更新IMS_Stock表已分配量
						UPDATE a SET allocQty=ISNULL(a.allocQty,0.0)+ b.pickQty*@pkgRatio
						FROM IMS_Stock a INNER JOIN 
							@tmpLocation b ON a.companyId=@companyId AND a.warehouseId=b.warehouseId AND a.lotNo=b.lotNo AND a.locationNo=b.locationNo AND a.itemId=b.itemId;
						--分拣件数（整箱数量）					
						SET @pkgQty=@totalQty/@pkgRatio;
						--更新出库单明细件分拣数量
						UPDATE @tmpDetail SET pkgQty=@pkgQty WHERE stockId=@stockId;	
						--如果存在整货区分拣数量不够，则转入拆零
						IF (ISNULL(@totalQty,0.0)-ISNULL(@pickQty,0.0)<0.0)
							SET @bulkQty=ISNULL(@bulkQty,0.0)+ISNULL(@pickQty,0.0)-ISNULL(@totalQty,0.0);
					END 
				END 
				--2.3件分拣
				IF (ISNULL(@bulkQty,0.0)>0.0)
				BEGIN	
					SET @totalQty=0.0;
					DELETE FROM @tmpLocation;
					--取得散件分拣库位，分拣数量
					INSERT INTO @tmpLocation(viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)
					SELECT viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish
					FROM dbo.uf_GetPickLocation(@companyId,@warehouseId,@ownerId,@itemId,@bulkQty,'EA',0)
					--2.3.1如果没分配到直接0
					IF NOT EXISTS(SELECT 1 FROM @tmpLocation)
					BEGIN
						--如果没有分配到数量
						UPDATE @tmpDetail SET bulkQty=0.0 WHERE stockId=@stockId;
						INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
						VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_NO_LOCATION','商品[' + @itemNo + ']没有找到拣货库位！','','');
					END
					ELSE
					BEGIN	
						--2.3.2如果需要补货
						IF (EXISTS(SELECT 1 FROM @tmpLocation WHERE needReplenish=1))
						BEGIN
							--从整件区进行补货处理
							--因为是汇总散件，所以所缺库存需要转换成整件库存(只按照整包装进行补货）
							SELECT @bhQty=CEILING(pickQty/@pkgRatio)*@pkgRatio,@needQty=pickQty
							FROM @tmpLocation
							WHERE needReplenish=1;                            
							--2.3.2.1补货下架库位
							INSERT INTO @tmpReplenish(replenishId,stockId,stockNo,viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish,pkgQty,pkgRatio)
							SELECT REPLACE(NEWID(),'-',''),@stockId,@stockNo,viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish,pickQty/@pkgRatio,@pkgRatio
							FROM dbo.uf_GetPickLocation(@companyId,@warehouseId,@ownerId,@itemId,@bhQty,'CS',0)
							WHERE needReplenish=0;							
							--2.3.2.2删除需要补货的记录，重新分拣
							DELETE FROM @tmpLocation WHERE needReplenish=1;							
							--如果没有补货记录
							IF (EXISTS(SELECT 1 FROM @tmpReplenish WHERE stockId=@stockId))
							BEGIN		
								DECLARE myPutaway CURSOR
								FOR SELECT replenishId,viewOrder,pickQty,lotNo,regionId,locationNo
									FROM @tmpReplenish
									WHERE stockId=@stockId
								OPEN myPutaway
								FETCH NEXT FROM myPutaway INTO @replenishId,@viewOrder,@pickQty,@lotNo,@fromRegion,@fromLocation
								WHILE @@FETCH_STATUS=0
								BEGIN
									SELECT @locationNo=dbo.uf_GetPutawayLocation(@companyId,@ownerId,@warehouseId,@itemId,'',@pickQty,@lotNo,0,'EA');
									--上架库区
									SELECT @regionId=regionId 
									FROM BAS_Location
									WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@locationNo
									--更新上架库位、库区
									UPDATE @tmpReplenish SET toLocationNo=@locationNo,toRegionId=@regionId WHERE replenishId=@replenishId;
									--写入预分配表，防止重复补货到同一库位(
									INSERT INTO IMS_Allocate(allocId,stockId,stockNo,companyId,warehouseId,regionId,locationNo,lotNo,itemId,allocQty,unitLevel,ioFlag)
									VALUES(@replenishId,@stockId,@stockNo,@companyId,@warehouseId,@regionId,@locationNo,@lotNo,@itemId,@pickQty,'EA','+');
									
									--更新上架库位在途库存
									IF EXISTS(SELECT 1 FROM IMS_Stock WHERE companyId=@companyId AND warehouseId=@warehouseId AND regionId=@regionId AND lotNo=@lotNo AND locationNo=@locationNo AND itemId=@itemId)
										UPDATE IMS_Stock SET onWayQty=ISNULL(onWayQty,0.0)+ISNULL(@pickQty,0.0) 
										WHERE companyId=@companyId AND warehouseId=@warehouseId AND regionId=@regionId AND lotNo=@lotNo AND locationNo=@locationNo AND itemId=@itemId;			
									ELSE
										INSERT INTO IMS_Stock(stockId,companyId,warehouseId,regionId,locationNo,lotNo,itemId,onhandQty,allocQty,onWayQty)
										VALUES(REPLACE(NEWID(),'-',''),@companyId,@warehouseId,@regionId,@locationNo,@lotNo,@itemId,0.0,0.0,@pickQty);
									--更新下架库位已分配库存
									UPDATE IMS_Stock SET allocQty=ISNULL(allocQty,0.0)+ISNULL(@pickQty,0.0) 
									WHERE companyId=@companyId AND warehouseId=@warehouseId AND regionId=@fromRegion AND lotNo=@lotNo AND locationNo=@fromLocation AND itemId=@itemId;
									--根据补货数据重新安排分拣位
									IF (@needQty>0.0)
									BEGIN
										IF (ISNULL(@needQty,0.0)-ISNULL(@pickQty,0.0)>0.0)
											INSERT INTO @tmpLocation(viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)
											VALUES(@viewOrder,@warehouseId,@regionId,@lotNo,@locationNo,@itemId,@pickQty,1)
										ELSE
											INSERT INTO @tmpLocation(viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)
											VALUES(@viewOrder,@warehouseId,@regionId,@lotNo,@locationNo,@itemId,@needQty,1)
										SET @needQty=@needQty-@pickQty;
									END
									FETCH NEXT FROM myPutaway INTO @replenishId,@viewOrder,@pickQty,@lotNo,@fromRegion,@fromLocation
								END
								CLOSE myPutaway
								DEALLOCATE myPutaway							
							END
						END
						--写入临时分配表
						INSERT INTO @tmpAllocate(stockId,stockNo,billNo,warehouseId,ownerId,regionId,lotNo,locationNo,itemId,pickQty,realQty,unitLevel,itemVolume,itemWeight,pkgRatio,allowSplit,splitRatio,lineId)
						SELECT @stockId,@stockNo,@stockBillNo,@warehouseId,@ownerId,regionId,lotNo,locationNo,itemId,SUM(pickQty),SUM(pickQty),'EA',@itemVolume,@itemWeight,@pkgRatio,@allowSplit,@splitRatio,@lineId
						FROM @tmpLocation
						WHERE ISNULL(pickQty,0.0)>0.0
						GROUP BY regionId,lotNo,locationNo,itemId												
						--散件分拣总数量
						SELECT @totalQty=SUM(pickQty) FROM @tmpLocation	
						--更新出库单明细件分拣数量
						UPDATE @tmpDetail SET bulkQty=@totalQty WHERE stockId=@stockId;		
						--更新IMS_Stock表已分配量
						UPDATE a SET allocQty=ISNULL(a.allocQty,0.0)+ ISNULL(b.pickQty,0.0)
						FROM IMS_Stock a INNER JOIN 
							(SELECT warehouseId,regionId,ISNULL(lotNo,'') AS lotNo,locationNo,itemId,SUM(pickQty) AS pickQty
							 FROM @tmpLocation
							 WHERE ISNULL(pickQty,0.0)>0.0
							 GROUP BY warehouseId,regionId,lotNo,locationNo,itemId
							) b ON a.companyId=@companyId AND a.warehouseId=b.warehouseId AND a.regionId=b.regionId AND a.lotNo=b.lotNo AND a.locationNo=b.locationNo AND a.itemId=b.itemId			
					END
				END
			END
			--获取当前出库单分配的库位库存
			SET @totalQty=0.0;
			SELECT @totalQty=SUM(realQty) FROM @tmpAllocate WHERE stockId=@stockId;
			--重新处理商品可用量
			UPDATE dbo.IMS_Ledger SET allocQty=ISNULL(allocQty,0.0)-ISNULL(@orderQty,0.0)+ISNULL(@totalQty,0.0) WHERE warehouseId=@warehouseId AND itemId=@itemId;
			FETCH NEXT FROM myCursor INTO @stockId,@stockNo,@stockBillNo,@warehouseId,@ownerId,@itemId,@itemNo,@stockQty,@pkgRatio,@itemVolume,@itemWeight,@allowSplit,@splitRatio,@lineId
		END
		CLOSE myCursor
		DEALLOCATE myCursor
		--只要有一个单品没有获取到库位或者数量不足的单据(库存异常)
		DELETE FROM @sales;
		INSERT INTO @sales(stockNo,stockBillNo,viewOrder)
		SELECT stockNo,billNo,viewOrder
		FROM @tmpHead
		WHERE stockNo IN(SELECT stockNo
						 FROM @tmpDetail a 
								LEFT JOIN(SELECT  stockId,SUM(realQty) AS stockQty
										  FROM @tmpAllocate
										  GROUP BY stockId) b ON a.stockId=b.stockId
						WHERE ISNULL(a.stockQty,0.0)-ISNULL(b.stockQty,0.0)>0.0);
		--循环处理库存异常或者没有分配到库位的单据
		WHILE EXISTS(SELECT 1 FROM @sales)
		BEGIN
			SELECT TOP 1 @stockNo=stockNo,@stockBillNo=stockBillNo FROM @sales ORDER BY viewOrder;
			--写入错误日志
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_NO_QTY','订单[' + @stockBillNo + ']没有分配到库存或者没分配到库位',@stockNo,@stockBillNo);
			--已分配量继续占用
			UPDATE a SET a.allocQty=ISNULL(a.allocQty,0.0)+ISNULL(b.allocQty,0.0)
			FROM dbo.IMS_Ledger a 
				INNER JOIN (SELECT warehouseId,itemId,SUM(stockQty) AS allocQty
				            FROM @tmpDetail
				            WHERE stockNo=@stockNo
				            GROUP BY warehouseId,itemId) b ON a.warehouseId=b.warehouseId AND a.itemId=b.itemId;
			DELETE FROM @sales WHERE stockNo=@stockNo;	
		END
		--3.重新拼箱处理
		--@caseTaskMode  整件任务模式：1-按商品生成整件任务;0-按单生成整件任务;2-按托盘拼整件任务
		IF (@caseTaskMode=1)
		BEGIN
			--1-按商品生成整件任务(boxNum)
			INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,itemWeight,pkgRatio,boxNum,sizeId,lineId)
			SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,1,itemVolume,itemWeight,pkgRatio,ROW_NUMBER() OVER(PARTITION BY warehouseId,regionId ORDER BY detailId),'-1',lineId
			FROM @tmpAllocate a
			WHERE unitLevel='CS' AND pickQty>0.0
		END
		ELSE IF (@caseTaskMode=0)
		BEGIN
			--0-按单生成整件任务(boxNum)
			INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,itemWeight,pkgRatio,boxNum,sizeId,lineId)
			SELECT a.stockId,a.stockNo,a.billNo,a.ownerId,a.warehouseId,a.regionId,a.lotNo,a.locationNo,a.itemId,a.pickQty,1,a.itemVolume,a.itemWeight,a.pkgRatio,b.boxNum,'-1',a.lineId
			FROM @tmpAllocate a 
				INNER JOIN(SELECT stockNo,warehouseId,regionId,ROW_NUMBER() OVER(PARTITION BY warehouseId,regionId ORDER BY billNo) AS boxNum
						   FROM (SELECT stockNo,billNo,warehouseId,regionId,COUNT(1) AS skuCount
						         FROM @tmpAllocate
						         WHERE unitLevel='CS' AND pickQty>0.0
						         GROUP BY stockNo,billNo,warehouseId,regionId) t
						   ) b ON a.stockNo=b.stockNo AND a.warehouseId=b.warehouseId AND a.regionId=b.regionId
			WHERE a.unitLevel='CS' AND a.pickQty>0.0
		END
		ELSE IF(@caseTaskMode=2)
		BEGIN
			DECLARE myOrder CURSOR 
			FOR 
				SELECT warehouseId,regionId 
				FROM @tmpAllocate 
				WHERE unitLevel='CS' AND pickQty>0.0 
				GROUP BY warehouseId,regionId
			OPEN myOrder
			FETCH NEXT FROM myOrder INTO @warehouseId,@regionId
			WHILE @@FETCH_STATUS=0
			BEGIN	
				--2-按托盘拼整件任务
				--循环生成任务(boxNum)、按订单顺序（方便出单）
				SET @boxCount=1;				
				--detailId,N箱体积，整件体积,
				INSERT INTO @sales(viewOrder,pickQty,bulkVolumn,itemVolume,lineId) 
				SELECT detailId,pickQty,pickQty*pkgRatio*itemVolume,pkgRatio*itemVolume,lineId
				FROM @tmpAllocate a
				WHERE a.unitLevel='CS' AND a.pickQty>0.0 AND warehouseId=@warehouseId AND regionId=@regionId
				ORDER BY a.detailId;
				--单箱体积超托盘的，直接上托盘
				WHILE (EXISTS(SELECT 1 FROM @sales WHERE itemVolume>=@plVolumn))
				BEGIN
					SELECT TOP 1 @detailId=viewOrder,@pkgQty=pickQty,@lineId=lineId
					FROM @sales 
					ORDER BY viewOrder;
					WHILE(@pkgQty>0)
					BEGIN
						SET @pickQty=1;
						--放入当前托盘
						INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,itemWeight,pkgRatio,boxNum,sizeId,lineId)
						SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,1,itemVolume,itemWeight,pkgRatio,@boxCount,@plId,@lineId
						FROM @tmpAllocate
						WHERE detailId=@detailId;
						SET @boxCount=@boxCount+1
						SET @pkgQty=@pkgQty-@pickQty;
					END
					--清除已经上托盘的数据
					DELETE FROM @sales WHERE viewOrder=@detailId;
				END
				--单条产品超托盘的
				WHILE (EXISTS(SELECT 1 FROM @sales WHERE itemVolume*pickQty>=@plVolumn))
				BEGIN
					SELECT TOP 1 @detailId=viewOrder,@pkgQty=pickQty,@itemVolume=itemVolume,@lineId=lineId
					FROM @sales 
					ORDER BY viewOrder;
					--单托盘能放单品数量
					SET @pickQty=FLOOR(@plVolumn/@itemVolume);
					WHILE(@pkgQty>=@pickQty)
					BEGIN
						--放入当前托盘
						INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,itemWeight,pkgRatio,boxNum,sizeId,lineId)
						SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,1,itemVolume,itemWeight,pkgRatio,@boxCount,@plId,@lineId
						FROM @tmpAllocate
						WHERE detailId=@detailId;
						SET @boxCount=@boxCount+1
						SET @pkgQty=@pkgQty-@pickQty;
					END
					--清除已经上托盘的数据
					IF (@pkgQty=0.0)
						DELETE FROM @sales WHERE viewOrder=@detailId;
					ELSE
						UPDATE @sales SET pickQty=@pkgQty WHERE viewOrder=@detailId;
				END
				SET @sumVolumn=0.0;
				--拼托盘
				WHILE (EXISTS(SELECT 1 FROM @sales))
				BEGIN
					SELECT TOP 1 @detailId=viewOrder,@pkgQty=pickQty,@itemVolume=itemVolume,@lineId=lineId
					FROM @sales 
					ORDER BY viewOrder;	
					--获取当前单品体积
					SELECT @bulkVolumn=@pkgQty*@itemVolume;							 
					--如果当前单品体积超过托盘剩余可用体积
					IF (@plVolumn-@sumVolumn-@bulkVolumn<0.0)
					BEGIN
						--计算当前托盘剩余体积可放箱数
						SET @pickQty=FLOOR((@plVolumn-@sumVolumn)/@itemVolume);
						--至少可以拼1箱
						IF (ISNULL(@pickQty,0)>0)
						BEGIN
							INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,itemWeight,pkgRatio,boxNum,sizeId,lineId)
							SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,1,itemVolume,itemWeight,pkgRatio,@boxCount,@plId,@lineId
							FROM @tmpAllocate
							WHERE detailId=@detailId;
							SET @boxCount=@boxCount+1
							SET @sumVolumn=0.0;
							SET @pkgQty=@pkgQty-@pickQty;
							--处理临时表
							IF ISNULL(@pkgQty,0.0)=0.0
								DELETE FROM @sales WHERE viewOrder=@detailId;
							ELSE
								UPDATE @sales SET pickQty=@pkgQty WHERE viewOrder=@detailId; 
						END
						ELSE
						BEGIN
							--如果一箱都放不下，为了避免同一订单步长过大，另开一个托盘
							SET @boxCount=@boxCount+1
							SET @sumVolumn=0.0;
						END
					END
					ELSE
					BEGIN
						SET @pickQty=@pkgQty;
						--放入当前托盘
						INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,itemWeight,pkgRatio,boxNum,sizeId,lineId)
						SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,1,itemVolume,itemWeight,pkgRatio,@boxCount,@plId,@lineId
						FROM @tmpAllocate
						WHERE detailId=@detailId;
						SET @sumVolumn=@sumVolumn+@bulkVolumn;
						DELETE FROM @sales WHERE viewOrder=@detailId;						
					END
				END	
				FETCH NEXT FROM myOrder INTO @warehouseId,@regionId
			END
			CLOSE myOrder
			DEALLOCATE myOrder
		END
		--重新拼箱(散件）
		DECLARE myOrder CURSOR 
		FOR 
			SELECT stockNo
			FROM (SELECT stockNo,billNo,COUNT(1) AS skuCount FROM @tmpAllocate WHERE unitLevel='EA' AND pickQty>0.0 GROUP BY stockNo,billNo) t
			ORDER BY billNo
		OPEN myOrder
		FETCH NEXT FROM myOrder INTO @stockNo
		WHILE @@FETCH_STATUS=0
		BEGIN
			--箱号
			SET @boxCount=1;
			--开始拼箱			
			--allowSplit:0,不拼箱;1,拼箱;2,自拼箱			
			--3.1.取出自拼箱产品和单个产品体积或者重量超标得商品进行拼箱处理
			INSERT INTO @sales(viewOrder,bulkVolumn,bulkWeight,pickQty,itemVolume,itemWeight,allowSplit,splitRatio,lineId)
			SELECT detailId,ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0),ISNULL(pickQty,0.0)*ISNULL(itemWeight,0.0),
				pickQty,itemVolume,itemWeight,allowSplit,splitRatio,lineId
			FROM @tmpAllocate
			WHERE (stockNo=@stockNo) AND (unitLevel='EA') AND (pickQty>0.0) AND (allowSplit=2)
			UNION ALL		--单个体积或者重量超过最大周转箱体积或者重量的
			SELECT detailId,ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0),ISNULL(pickQty,0.0)*ISNULL(itemWeight,0.0),
				pickQty,itemVolume,itemWeight,allowSplit,1 AS splitRatio,lineId
			FROM @tmpAllocate
			WHERE (stockNo=@stockNo) AND (unitLevel='EA') AND (pickQty>0.0) 
				AND (allowSplit=1 OR allowSplit=0) 
				AND (itemVolume>=@maxVolumn OR itemWeight>=@maxWeight)
			WHILE (EXISTS(SELECT 1 FROM @sales))
			BEGIN
				--单条体积，数量，单个体积，是否允许拆分
				SELECT TOP 1 @detailId=viewOrder,@bulkQty=pickQty,@splitRatio=splitRatio,@lineId=lineId
				FROM @sales 
				ORDER BY viewOrder;				
				--开始拼箱
				WHILE (@bulkQty>0)
				BEGIN
					IF (ISNULL(@bulkQty,0.0)-ISNULL(@splitRatio,0.0)>0)
						SET @pickQty=@splitRatio;
					ELSE
						SET @pickQty=@bulkQty;
					--取得当前订单周转箱规格Id
					SELECT @sizeId=dbo.uf_GetContainer(@companyId,@pickQty*@itemVolume);	
					INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,itemWeight,pkgRatio,boxNum,sizeId,lineId)
					SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,0,itemVolume,itemWeight,pkgRatio,@boxCount,@sizeId,@lineId
					FROM @tmpAllocate a
					WHERE detailId=@detailId;
					SET @boxCount=@boxCount+1;					
					SET @bulkQty=@bulkQty-@pickQty;
				END
				--删除临时数据
				DELETE FROM @sales WHERE viewOrder=@detailId
			END
			--3.2 非自拼箱商品，且单个产品小于最大周转箱体积和重量的商品进行拼箱处理
			INSERT INTO @sales(viewOrder,bulkVolumn,bulkWeight,pickQty,itemVolume,itemWeight,allowSplit,splitRatio,lineId)
			SELECT detailId,ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0),ISNULL(pickQty,0.0)*ISNULL(itemWeight,0.0),
				pickQty,itemVolume,itemWeight,allowSplit,splitRatio,lineId
			FROM @tmpAllocate
			WHERE (stockNo=@stockNo) AND (unitLevel='EA') AND (pickQty>0.0)
				AND (allowSplit=1 OR allowSplit=0) 
				AND (itemVolume<@maxVolumn AND itemWeight<@maxWeight)
			ORDER BY detailId;
			--3.2.1单条商品体积或者重量大于最大周转箱的商品进行拼箱
			WHILE EXISTS(SELECT 1 FROM @sales WHERE ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0)-@maxVolumn>=0.0 OR ISNULL(pickQty,0.0)*ISNULL(itemWeight,0.0)-@maxWeight>=0.0)
			BEGIN
				--单条体积，数量，单个体积，是否允许拆分
				SELECT TOP 1 @detailId=viewOrder,@bulkQty=pickQty,@itemVolume=itemVolume,@itemWeight=itemWeight,
					@bulkVolumn=ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0),@allowSplit=allowSplit,@splitRatio=splitRatio,
					@lineId=lineId
				FROM @sales
				WHERE ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0)-@maxVolumn>=0.0 
					OR ISNULL(pickQty,0.0)*ISNULL(itemWeight,0.0)-@maxWeight>=0.0
				ORDER BY viewOrder; 		
				--如果不允许单条拆零和其他产品拼箱（改为根据splitRatio值处理，拆成splitRate的倍数）
				IF ((@allowSplit=0) AND (@splitRatio=0))
				BEGIN
					SET @SizeId=dbo.uf_GetContainer(@companyId,@bulkVolumn);
					INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,itemWeight,pkgRatio,boxNum,sizeId,lineId)
					SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,0,itemVolume,itemWeight,pkgRatio,@boxCount,@SizeId,@lineId
					FROM @tmpAllocate a
					WHERE detailId=@detailId;
					SET @boxCount=@boxCount+1
					--删除临时表中数据
					DELETE FROM @sales WHERE viewOrder=@detailId;
				END
				ELSE
				BEGIN
					--单个产品周转箱分配数量
					IF (@allowSplit=0 AND (@splitRatio>0))
						SET @pickQty=@splitRatio;
					ELSE
					BEGIN
						--最大体积或者最大重量能装的数量，以最小数量作为分箱标准
						IF (FLOOR(@maxVolumn/@itemVolume)-FLOOR(@maxWeight/@itemWeight)>0)
							SET @pickQty=FLOOR(@maxWeight/@itemWeight);
						ELSE
							SET @pickQty=FLOOR(@maxVolumn/@itemVolume);
					END						
					--最大周转箱
					SET @SizeId=dbo.uf_GetContainer(@companyId,@pickQty*@itemVolume);
					WHILE @bulkQty>=@pickQty
					BEGIN
						INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,itemWeight,pkgRatio,boxNum,sizeId,lineId)
						SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,0,itemVolume,itemWeight,pkgRatio,@boxCount,@sizeId,@lineId
						FROM @tmpAllocate a
						WHERE detailId=@detailId;						
						SET @boxCount=@boxCount+1
						SET @bulkQty=@bulkQty-@pickQty;
					END
					--如果还有剩余部分，则和其他产品拼箱
					IF (@bulkQty>0)
						UPDATE @sales SET pickQty=@bulkQty WHERE viewOrder=@detailId;
					ELSE
						DELETE FROM @sales WHERE viewOrder=@detailId;
				END	
			END
			--3.2.2 非自拼箱，且单个产品小于最大周转箱体积和重量的商品进行拼箱处理
			SET @sumVolumn=0.0;
			SET @sumWeight=0.0;
			WHILE EXISTS (SELECT 1 FROM @sales)
			BEGIN
				--如果当前体积和重量可以拼在第N箱
				IF EXISTS(SELECT 1 FROM @sales WHERE (@maxVolumn-@sumVolumn-ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0)>=0.0) AND (@maxWeight-@sumWeight-ISNULL(pickQty,0.0)*ISNULL(itemWeight,0.0)>=0.0))			
				BEGIN
					--单条体积，数量，单个体积，是否允许拆分
					SELECT TOP 1 @detailId=viewOrder,@bulkVolumn=ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0),
						@bulkWeight=ISNULL(pickQty,0.0)*ISNULL(itemWeight,0.0),@bulkQty=pickQty,
						@itemVolume=itemVolume,@itemWeight=itemWeight,@allowSplit=allowSplit,@splitRatio=splitRatio,
						@lineId=lineId
					FROM @sales
					WHERE (@maxVolumn-@sumVolumn-ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0)>=0.0)				--体积能拼箱的
						AND (@maxWeight-@sumWeight-ISNULL(pickQty,0.0)*ISNULL(itemWeight,0.0)>=0.0)				--重量能拼箱的  
					ORDER BY allowSplit,viewOrder;	
					INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,itemWeight,pkgRatio,boxNum,sizeId,lineId)
					SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@bulkQty,0,itemVolume,itemWeight,pkgRatio,@boxCount,'',lineId
					FROM @tmpAllocate
					WHERE detailId=@detailId;
					--累计
					SET @sumVolumn=@sumVolumn+@bulkVolumn;	
					SET @sumWeight=@sumWeight+@bulkWeight;
					--清除临时数据
					DELETE FROM @sales WHERE viewOrder=@detailId;
				END
				ELSE
				BEGIN
					--允许拆分，且能放进至少一个单品的
					IF (EXISTS(SELECT 1 FROM @sales WHERE allowSplit=1 AND (@maxVolumn-@sumVolumn-ISNULL(itemVolume,0.0)>0.0) AND (@maxWeight-@sumWeight-ISNULL(itemWeight,0.0)>0.0)))
					BEGIN
						--单条体积，数量，单个体积，是否允许拆分
						SELECT TOP 1 @detailId=viewOrder,@bulkQty=pickQty,@itemVolume=itemVolume,@itemWeight=itemWeight,
							@allowSplit=allowSplit,@splitRatio=splitRatio,@lineId=lineId
						FROM @sales
						WHERE allowSplit=1 AND (@maxVolumn-@sumVolumn-ISNULL(itemVolume,0.0)>0.0) AND (@maxWeight-@sumWeight-ISNULL(itemWeight,0.0)>0.0)
						ORDER BY viewOrder;	
						--当条商品拆开拼箱,剩余空间能存放的
						IF FLOOR((@maxVolumn-@sumVolumn)/@itemVolume)-FLOOR((@maxWeight-@sumWeight)/@itemWeight)>0
							SET @pickQty=FLOOR((@maxWeight-@sumWeight)/@itemWeight)
						ELSE
							SET @pickQty=FLOOR((@maxVolumn-@sumVolumn)/@itemVolume)						
						INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,itemWeight,pkgRatio,boxNum,sizeId,lineId)
						SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,0,itemVolume,itemWeight,pkgRatio,@boxCount,'',@lineId
						FROM @tmpAllocate
						WHERE detailId=@detailId;
						--累计
						SET @sumVolumn=0.0;	
						SET @sumWeight=0.0;
						SET @boxCount=@boxCount+1;
						--拼箱后剩余
						IF (@bulkQty-@pickQty=0.0)
							DELETE FROM @sales WHERE viewOrder=@detailId; 
						ELSE
							UPDATE @sales SET pickQty=@bulkQty-@pickQty WHERE viewOrder=@detailId;
					END
					ELSE
					BEGIN
						--不允许拆和一个都放不下了，则开新的周转箱
						SET @sumVolumn=0.0;	
						SET @sumWeight=0.0;
						SET @boxCount=@boxCount+1;
					END
				END
			END
			FETCH NEXT FROM myOrder INTO @stockNo
		END
		CLOSE myOrder
		DEALLOCATE myOrder
		--最后拼箱的，更新其拼箱规格
		UPDATE a SET a.sizeId=dbo.uf_GetContainer(@companyId,b.lclVolumn)
		FROM @tmpPick a INNER JOIN
			(SELECT boxNum,stockNo,SUM(ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0)) AS lclVolumn
			 FROM @tmpPick
			 WHERE ISNULL(sizeId,'')=''
			 GROUP BY boxNum,stockNo) b ON a.stockNo=b.stockNo AND a.boxNum=b.boxNum
		WHERE ISNULL(a.sizeId,'')='';
		--4.根据波茨策略生成波茨计划
		--波茨计划:定义单据游标,分波茨任务，并写入临时表(根据波茨策略)		
		DECLARE @wave TABLE(waveNo VARCHAR(32),createTime DATETIME,creatorId VARCHAR(32));
		DECLARE @waveDtl TABLE(waveId VARCHAR(32),waveNo VARCHAR(32),stockNo VARCHAR(32),lineId VARCHAR(32),shipDate DATE,shipTime VARCHAR(100),viewOrder INT IDENTITY(1,1));
		DECLARE myPolicy CURSOR
		FOR
			SELECT policyId,ownerId,lineId,logisticsId,orderType,minRows,maxRows,minOrders,maxOrders,limitedVolumn,limitedWeight
			FROM dbo.WMS_WavePolicy
			WHERE companyId=@companyId AND isDisable=0
			ORDER BY viewOrder
		OPEN myPolicy
		FETCH NEXT FROM myPolicy INTO @policyId,@ownerId,@lineId,@logisticsId,@orderType,@minRows,@maxRows,@minOrders,@maxOrders,@limitedVolumn,@limitedWeight
		WHILE @@FETCH_STATUS=0
		BEGIN	
			IF (ISNULL(@maxRows,0)=0)
				SET @maxRows=9999
			--根据策略对订单进行分组（临时订单表）
			INSERT INTO @sales(policyId,stockNo,viewOrder,lineId)
			SELECT @policyId,stockNo,ROW_NUMBER() OVER (ORDER BY viewOrder),lineId
			FROM @tmpHead a
			WHERE ownerId=@ownerId															--业主
				  AND (ISNULL(lineId,'')=@lineId OR ISNULL(@lineId,'')='')					--线路
				  AND (ISNULL(logisticsId,'')=@logisticsId OR ISNULL(@logisticsId,'')='')	--物流
				  AND (ISNULL(orderType,0)=@orderType OR ISNULL(@orderType,0)=0)			--订单类型
				  AND (skuCount BETWEEN @minRows AND @maxRows)								--Sku数量
				  AND EXISTS(SELECT 1 FROM @tmpPick b WHERE a.stockNo=b.stockNo)
			ORDER BY viewOrder;			
			--如果当前策略没有对应的数据
			IF EXISTS(SELECT 1 FROM @sales WHERE policyId=@policyId)
			BEGIN
				--订单数量超过波茨最大订单数量时，需要分波茨
				IF ISNULL(@maxOrders,0)>0
				BEGIN
					SELECT @waveIndex=1,@waveCount=COUNT(1)/@maxOrders + 1 
					FROM @sales 
					WHERE policyId=@policyId;
					WHILE (@waveIndex<=@waveCount)
					BEGIN
						SET @waveNo=LOWER(REPLACE(NEWID(),'-',''))
						--写入波茨数据(主表)
						INSERT INTO @wave(waveNo,createTime,creatorId)
						VALUES(@waveNo,@createTime,@creatorId);		
						--写入波茨数据明细表
						INSERT INTO @waveDtl(waveId,waveNo,stockNo,lineId,shipDate,shipTime)
						SELECT LOWER(REPLACE(NEWID(),'-','')),@waveNo,stockNo,lineId,@shipDate,@shipTime
						FROM @sales
						WHERE viewOrder BETWEEN (@waveIndex-1)*@maxOrders+1 AND @waveIndex*@maxOrders
						ORDER BY viewOrder; 	
						SET @waveIndex=@waveIndex+1;				
					END
				END
				ELSE
				BEGIN
					SET @waveNo=LOWER(REPLACE(NEWID(),'-',''))
					--写入波茨数据(主表)
					INSERT INTO @wave(waveNo,createTime,creatorId)
					VALUES(@waveNo,@createTime,@creatorId);					
					--写入波茨数据明细表
					INSERT INTO @waveDtl(waveId,waveNo,stockNo,lineId,shipDate,shipTime)
					SELECT REPLACE(NEWID(),'-',''),@waveNo,stockNo,lineId,@shipDate,@shipTime
					FROM @sales 
					WHERE policyId=@policyId
					ORDER BY viewOrder;			
				END
			END
			--释放@sales
			DELETE FROM @sales;
			FETCH NEXT FROM myPolicy INTO @policyId,@ownerId,@lineId,@logisticsId,@orderType,@minRows,@maxRows,@minOrders,@maxOrders,@limitedVolumn,@limitedWeight
		END
		CLOSE myPolicy
		DEALLOCATE myPolicy	
		--6.生成波茨分拣任务
		DECLARE myWave CURSOR
		FOR SELECT waveNo FROM @wave
		OPEN myWave
		FETCH NEXT FROM myWave INTO @waveNo
		WHILE @@FETCH_STATUS=0
		BEGIN
			--生产波茨计划单
			EXEC up_CreateCode @companyId,'WMS_Wave',@creatorId,@waveBillNo OUTPUT;
			INSERT INTO WMS_Wave(waveNo,billNo,companyId,autoFlag,createTime,creatorId)
			VALUES(@waveNo,@waveBillNo,@companyId,1,@createTime,@creatorId);
			--波次明细(并生成波次单据顺序)
			DECLARE myDetail CURSOR
			FOR SELECT stockNo,lineId FROM @waveDtl WHERE waveNo=@waveNo
			OPEN myDetail
			FETCH NEXT FROM myDetail INTO @stockNo,@lineId
			WHILE @@FETCH_STATUS=0
			BEGIN
				SELECT @viewOrder=MAX(viewOrder) FROM WMS_WaveDetail WHERE lineId=@lineId AND shipDate=@shipDate AND shipTime=@shipTime;
				SET @viewOrder=ISNULL(@viewOrder,0)+1;
				INSERT INTO WMS_WaveDetail(waveId,waveNo,companyId,stockNo,lineId,viewOrder,createTime,shipDate,shipTime)
				SELECT REPLACE(NEWID(),'-',''),@waveNo,@companyId,stockNo,lineId,@viewOrder,GETDATE(),@shipDate,@shipTime
				FROM @waveDtl
				WHERE waveNo=@waveNo AND stockNo=@stockNo AND lineId=@lineId;
				FETCH NEXT FROM myDetail INTO @stockNo,@lineId
			END
			CLOSE myDetail
			DEALLOCATE myDetail			
			--6.1波茨下的箱拣货任务(每个仓库、库区为一个分拣任务——排分拣任务)
			--2017-09-20 前面已经分好任务，只需要写入即可			
			DECLARE myTask CURSOR
			FOR SELECT warehouseId,regionId,boxNum,sizeId
				FROM @tmpPick a
				WHERE EXISTS(SELECT 1 FROM @waveDtl b WHERE b.waveNo=@waveNo AND a.stockNo=b.stockNo)
					  AND isPackage=1
				GROUP BY warehouseId,regionId,boxNum,sizeId
			OPEN myTask
			FETCH NEXT FROM myTask INTO @warehouseId,@regionId,@viewOrder,@sizeId
			WHILE @@FETCH_STATUS=0
			BEGIN
				--一个订单一个库区一个任务
				SET @pickingNo=LOWER(REPLACE(NEWID(),'-',''));
				--创建任务单据编号
				EXEC up_CreateCode @companyId,'WMS_Picking',@creatorId,@pickBillNo OUTPUT;
				--写入分拣任务主表taskType:0-散件;1-整箱;2-补货
				INSERT INTO WMS_Picking(pickingNo,companyId,billNo,waveNo,waveBillNo,warehouseId,regionId,taskType,sizeId,boxNumber,taskState,createTime,editTime,creatorId,editorId)  
				VALUES(@pickingNo,@companyId,@pickBillNo,@waveNo,@waveBillNo,@warehouseId,@regionId,1,@sizeId,1,0,@createTime,@createTime,@creatorId,@creatorId);					
				DECLARE myOrder CURSOR
				FOR SELECT pickOrder,stockNo,stockBillNo,itemId,pickQty,lineId
					FROM @tmpPick a
					WHERE EXISTS(SELECT 1 FROM @waveDtl b WHERE b.waveNo=@waveNo AND a.stockNo=b.stockNo)
						  AND isPackage=1
						  AND warehouseId=@warehouseId 
						  AND regionId=@regionId
						  AND sizeId=@sizeId
						  AND boxNum=@viewOrder
					ORDER BY pickOrder 
				OPEN myOrder
				FETCH NEXT FROM myOrder INTO @pickOrder,@stockNo,@stockBillNo,@itemId,@pkgQty,@lineId
				WHILE @@FETCH_STATUS=0
				BEGIN
					--获取集货区Id
					SELECT TOP 1 @cargoArea=regionId FROM dbo.BAS_LineRegion WHERE lineId=@lineId;
					--任务总箱数
					SELECT @fclQty=SUM(pickQty)
					FROM @tmpPick a
					WHERE EXISTS(SELECT 1 FROM @waveDtl b WHERE b.waveNo=@waveNo AND a.stockNo=b.stockNo)
						  AND isPackage=1
						  AND stockNo=@stockNo;
					SELECT @skuQty=SUM(pickQty)
					FROM @tmpPick a
					WHERE EXISTS(SELECT 1 FROM @waveDtl b WHERE b.waveNo=@waveNo AND a.stockNo=b.stockNo)
						  AND isPackage=1
						  AND stockNo=@stockNo
						  AND itemId=@itemId;
					SET @boxCount=1;															  
					--一箱一个标签
					IF (@pkgQty-@fclMaxCount<=0)
					BEGIN
						SET @pickQty=1.0;
						WHILE (@pkgQty>0)
						BEGIN
							SET @pickId=LOWER(REPLACE(NEWID(),'-',''));
							INSERT INTO WMS_PickingOrder(pickId,pickingNo,companyId,stockNo,stockBillNo,stockBox,boxId,boxOrder,isPackage,skuQty,pkgQty,lclQty,pickerId,taskState,lineId,cargoArea)
							VALUES(@pickId,@pickingNo,@companyId,@stockNo,@stockBillNo,@boxCount,'',@boxCount,1,@skuQty,@fclQty,0.0,'',0,@lineId,@cargoArea);
							--写入分拣任务订单明细表(WMS_PickingDetail)
							INSERT INTO WMS_PickingDetail(pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,itemId,
								isPackage,pickState,stockQty,pickQty,actualQty,realQty,boxId,boxOrder,stockId,stockNo,stockBillNo,itemVolume,itemWeight,pkgRatio)
							SELECT LOWER(REPLACE(NEWID(),'-','')),@pickId,@pickingNo,@companyId,@warehouseId,@regionId,batchNo,locationNo,@itemId,
								1,0,@pickQty,@pickQty,0.0,pkgRatio,'',@boxCount,stockId,stockNo,stockBillNo,itemVolume,itemWeight,pkgRatio 
							FROM @tmpPick 
							WHERE pickOrder=@pickOrder;
							--累加计数器
							SET @boxCount=@boxCount+1;
							SET @pkgQty=@pkgQty-1;
						END
				    END
				    ELSE
				    BEGIN
						--超过一定箱数后只打印一个标签
						SET @pickId=LOWER(REPLACE(NEWID(),'-',''));
						INSERT INTO WMS_PickingOrder(pickId,pickingNo,companyId,stockNo,stockBillNo,stockBox,boxId,boxOrder,isPackage,skuQty,pkgQty,lclQty,pickerId,taskState,lineId,cargoArea)
						VALUES(@pickId,@pickingNo,@companyId,@stockNo,@stockBillNo,@boxCount,'',@boxCount,1,@skuQty,@fclQty,0.0,'',0,@lineId,@cargoArea);
						--写入分拣任务订单明细表(WMS_PickingDetail)
						INSERT INTO WMS_PickingDetail(pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,itemId,
							isPackage,pickState,stockQty,pickQty,actualQty,realQty,boxId,boxOrder,stockId,stockNo,stockBillNo,itemVolume,itemWeight,pkgRatio)
						SELECT LOWER(REPLACE(NEWID(),'-','')),@pickId,@pickingNo,@companyId,@warehouseId,@regionId,batchNo,locationNo,@itemId,
							1,0,@pkgQty,@pkgQty,0.0,@pkgQty*pkgRatio,'',@boxCount,stockId,stockNo,stockBillNo,itemVolume,itemWeight,pkgRatio
						FROM @tmpPick 
						WHERE pickOrder=@pickOrder;
						--累加计数器
						SET @boxCount=@boxCount+1;
				    END				
					FETCH NEXT FROM myOrder INTO @pickOrder,@stockNo,@stockBillNo,@itemId,@pkgQty,@lineId
				END	
				CLOSE myOrder
				DEALLOCATE myOrder				
				FETCH NEXT FROM myTask INTO @warehouseId,@regionId,@viewOrder,@sizeId
			END
			CLOSE myTask
			DEALLOCATE myTask			
			--6.2 波茨下的件拣货任务
			--获取件拣货数据				
			DECLARE myTask CURSOR 
			FOR SELECT warehouseId,regionId
				FROM (SELECT warehouseId,regionId,COUNT(1) As boxCount
					  FROM @tmpPick a
					  WHERE EXISTS(SELECT 1 FROM @waveDtl b WHERE b.waveNo=@waveNo AND a.stockNo=b.stockNo) AND a.isPackage=0
					  GROUP BY warehouseId,regionId
					 ) t
			OPEN myTask
			FETCH NEXT FROM myTask INTO @warehouseId,@regionId
			WHILE @@FETCH_STATUS=0
			BEGIN			
				--按仓库，作业区域取订单分拣任务
				INSERT INTO @sales(stockNo,stockBillNo,sizeId,boxOrder)
				SELECT stockNo,stockBillNo,sizeId,boxNum
				FROM (SELECT stockNo,stockBillNo,sizeId,boxNum
					  FROM @tmpPick a
					  WHERE warehouseId=@warehouseId AND regionId=@regionId
						  AND EXISTS(SELECT 1 FROM @waveDtl b WHERE b.waveNo=@waveNo AND a.stockNo=b.stockNo)
						  AND isPackage=0
					  GROUP BY stockNo,stockBillNo,sizeId,boxNum) t
				ORDER BY stockBillNo;
				--初始化周转箱规格,计数器，任务号
				SET @sizeId='';	
				SET @boxCount=1;
				SET @pickingNo=LOWER(REPLACE(NEWID(),'-',''));			
				WHILE EXISTS(SELECT 1 FROM @sales)
				BEGIN	
					IF (@sizeId='')
					BEGIN
						SELECT TOP 1 @stockNo=stockNo,@stockBillNo=stockBillNo,@boxIndex=boxOrder,@sizeId=sizeId FROM @sales ORDER BY stockBillNo,boxOrder;	
						--周转箱规格组合数
						SELECT @maxBoxes=boxNumber FROM WMS_BoxSize WHERE sizeId=@sizeId;						
					END
					ELSE
					BEGIN
						IF EXISTS(SELECT 1 FROM @sales WHERE @sizeId=sizeId)
							SELECT TOP 1 @stockNo=stockNo,@stockBillNo=stockBillNo,@boxIndex=boxOrder FROM @sales WHERE @sizeId=sizeId ORDER BY stockBillNo,boxOrder;
						ELSE
							SET @stockNo='';
					END
					--如果没有对应相应周转箱规格对应的数据，则找下一个规格
					IF (ISNULL(@stockNo,'')='')
					BEGIN
						SET @sizeId='';
						SET @boxCount=1;
						SET @pickingNo=LOWER(REPLACE(NEWID(),'-',''));
					END
					ELSE
					BEGIN
						--获取出库单对应的线路与集货区
						SELECT TOP 1 @lineId=lineId FROM @tmpPick WHERE stockNo=@stockNo;
						--获取集货区Id
						SELECT TOP 1 @cargoArea=regionId FROM dbo.BAS_LineRegion WHERE lineId=@lineId;
						--散件最大拼箱数（总拼箱数）
						SELECT @lclQty=MAX(boxNum) FROM @tmpPick WHERE stockNo=@stockNo;
						--写入任务表
						IF NOT EXISTS(SELECT 1 FROM WMS_Picking WHERE pickingNo=@pickingNo)
						BEGIN
							--生成任务单编号
							EXEC up_CreateCode @companyId,'WMS_Picking',@creatorId,@pickBillNo OUTPUT;
							--taskType:0-散件;1-整箱;2-补货
							INSERT INTO WMS_Picking(pickingNo,companyId,billNo,waveNo,waveBillNo,warehouseId,regionId,taskType,sizeId,boxNumber,taskState,createTime,editTime,creatorId,editorId)  
							VALUES(@pickingNo,@companyId,@pickBillNo,@waveNo,@waveBillNo,@warehouseId,@regionId,0,@sizeId,@maxBoxes,0,GETDATE(),GETDATE(),@creatorId,@creatorId)
						END					 
						--写入分拣任务订单表
						SET @pickId=LOWER(REPLACE(NEWID(),'-',''));
						INSERT INTO WMS_PickingOrder(pickId,pickingNo,companyId,stockNo,stockBillNo,stockBox,boxId,boxOrder,isPackage,pkgQty,lclQty,pickerId,taskState,lineId,cargoArea)
						VALUES(@pickId,@pickingNo,@companyId,@stockNo,@stockBillNo,@boxIndex,'',@boxCount,0,0.0,@lclQty,'',0,@lineId,@cargoArea);    
						--写入分拣任务明细
						INSERT INTO WMS_PickingDetail(pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,itemId,
							isPackage,pickState,stockQty,pickQty,actualQty,realQty,boxId,boxOrder,stockId,stockNo,stockBillNo,itemVolume,itemWeight,pkgRatio)
						SELECT LOWER(REPLACE(NEWID(),'-','')),@pickId,@pickingNo,@companyId,@warehouseId,@regionId,batchNo,locationNo,itemId,
							0,0,pickQty,pickQty,0.0,pickQty,'',@boxCount,stockId,stockNo,stockBillNo,itemVolume,itemWeight,pkgRatio   
						FROM @tmpPick 
						WHERE stockNo=@stockNo AND warehouseId=@warehouseId AND regionId=@regionId AND sizeId=@sizeId AND boxNum=@boxIndex AND isPackage=0;
						SET @boxCount=@boxCount+1;
						DELETE FROM @sales WHERE stockNo=@stockNo AND stockBillNo=@stockBillNo AND boxOrder=@boxIndex AND sizeId=@sizeId;
						--装箱超过最大箱后重新分箱
						IF (@boxCount-@maxBoxes>0)
						BEGIN
							SET @boxCount=1;
							SET @sizeId='';
							SET @pickingNo=LOWER(REPLACE(NEWID(),'-','')); 
						END
					END
				END		
				FETCH NEXT FROM myTask INTO @warehouseId,@regionId
			END
			CLOSE myTask
			DEALLOCATE myTask
			--6.3波茨补货(散件分拣）
			IF EXISTS(SELECT 1 FROM @tmpReplenish)
			BEGIN
				--6.3.1 生成波茨补货计划
				EXEC up_CreateCode @companyId,'IMS_Replenish',@creatorId,@replenishBillNo OUTPUT;
				INSERT INTO IMS_Replenish(replenishId,companyId,replenishDate,billNo,replenishType,waveNo,waveBillNo,sourceWhId,sourceRegId,sourceLocNo,lotNo,targetWhId,targetRegId,targetLocNo,eId,itemId,replenishQty,pkgQty,ioState,printNum,isLocked,lockerId,lockedTime,createTime,creatorId,stockId,stockNo,pkgRatio)
				SELECT replenishId,@companyId,@createTime,@replenishBillNo,2,@waveNo,@waveBillNo,warehouseId,regionId,locationNo,lotNo,warehouseId,toRegionId,toLocationNo,'',itemId,pickQty,pkgQty,10,0,0,'',NULL,@createTime,@creatorId,stockId,stockNo,pkgRatio
				FROM @tmpReplenish 
				WHERE stockId=ANY(SELECT a.stockId 
								  FROM @tmpPick a INNER JOIN @waveDtl b ON a.stockNo=b.stockNo
								  WHERE a.isPackage=0 AND b.waveNo=@waveNo)								
				--清除已经生成补货任务的数据
				DELETE FROM @tmpReplenish 
				WHERE stockId=ANY(SELECT a.stockId 
								  FROM @tmpPick a INNER JOIN @waveDtl b ON a.stockNo=b.stockNo
								  WHERE a.isPackage=0 AND b.waveNo=@waveNo)
				--6.3.2 生成波茨补货分拣任务
				DECLARE myTask CURSOR 
				FOR 
					SELECT sourceWhId,sourceRegId,COUNT(1)
					FROM IMS_Replenish 
					WHERE companyId=@companyId AND billNo=@replenishBillNo
					GROUP BY sourceWhId,sourceRegId
				OPEN myTask
				FETCH NEXT FROM myTask INTO @warehouseId,@regionId,@boxCount
				WHILE @@FETCH_STATUS=0
				BEGIN
					--补货任务模式；1-按单条商品生成补货任务;0-按波茨生成补货任务
					IF (@replenishTaskMode='0')
					BEGIN
						SET @pickingNo=REPLACE(NEWID(),'-','');
						--创建任务单据编号
						EXEC up_CreateCode @companyId,'WMS_Picking',@creatorId,@pickBillNo OUTPUT;
						--写入分拣任务taskType:0-散件;1-整箱;2-补货
						INSERT INTO WMS_Picking(pickingNo,companyId,billNo,waveNo,waveBillNo,warehouseId,regionId,taskType,sizeId,boxNumber,taskState,createTime,editTime,creatorId,editorId)  
						VALUES(@pickingNo,@companyId,@pickBillNo,@waveNo,@waveBillNo,@warehouseId,@regionId,2,'-1',0,0,@createTime,@createTime,@creatorId,@creatorId);
					END
					--生成补货分拣任务
					DECLARE myOrder CURSOR
					FOR
						SELECT replenishId,itemId,lotNo,sourceLocNo,replenishQty,pkgQty,pkgRatio
						FROM IMS_Replenish 
						WHERE companyId=@companyId AND billNo=@replenishBillNo AND sourceWhId=@warehouseId AND sourceRegId=@regionId
					OPEN myOrder
					FETCH NEXT FROM myOrder INTO @replenishId,@itemId,@lotNo,@locationNo,@replenishQty,@pickQty,@pkgRatio
					WHILE @@FETCH_STATUS=0
					BEGIN
						--补货任务模式；1-按单条商品生成补货任务;0-按波茨生成补货任务
						IF (@replenishTaskMode='1')
						BEGIN
							SET @pickingNo=LOWER(REPLACE(NEWID(),'-',''));
							--创建任务单据编号
							EXEC up_CreateCode @companyId,'WMS_Picking',@creatorId,@pickBillNo OUTPUT;
							--写入分拣任务taskType:0-散件;1-整箱;2-补货
							INSERT INTO WMS_Picking(pickingNo,companyId,billNo,waveNo,waveBillNo,warehouseId,regionId,taskType,sizeId,boxNumber,taskState,createTime,editTime,creatorId,editorId)  
							VALUES(@pickingNo,@companyId,@pickBillNo,@waveNo,@waveBillNo,@warehouseId,@regionId,2,'-1',0,0,@createTime,@createTime,@creatorId,@creatorId);
						END
						IF (@pickQty>0)
						BEGIN
							SET @boxCount=1;
							WHILE @boxCount<=@pickQty
							BEGIN
								SET @pickId=LOWER(REPLACE(NEWID(),'-',''));
								INSERT INTO WMS_PickingOrder(pickId,pickingNo,companyId,stockNo,stockBillNo,stockBox,boxId,boxOrder,isPackage,pkgQty,lclQty,pickerId,taskState)
								VALUES(@pickId,@pickingNo,@companyId,@replenishId,@replenishBillNo,@boxCount,'',@boxCount,1,@pickQty,0.0,'',0);
								--写入分拣任务订单明细表(WMS_PickingDetail)
								INSERT INTO WMS_PickingDetail(pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,itemId,
									isPackage,pickState,stockQty,pickQty,actualQty,realQty,boxId,boxOrder,stockId,stockNo,stockBillNo,pkgRatio)					
								VALUES(REPLACE(NEWID(),'-',''),@pickId,@pickingNo,@companyId,@warehouseId,@regionId,@lotNo,@locationNo,@itemId,
									1,0,1.0,1.0,0.0,@pkgRatio,'',@boxCount,@replenishId,@replenishId,@replenishBillNo,@pkgRatio)    
								--累加计数器
								SET @boxCount=@boxCount+1
							END
						END
						ELSE
						BEGIN
							SET @pickId=LOWER(REPLACE(NEWID(),'-',''));
							INSERT INTO WMS_PickingOrder(pickId,pickingNo,companyId,stockNo,stockBillNo,stockBox,boxId,boxOrder,isPackage,pkgQty,lclQty,pickerId,taskState)
							VALUES(@pickId,@pickingNo,@companyId,@replenishId,@replenishBillNo,@boxCount,'',@boxCount,1,1,0.0,'',0);
							--写入分拣任务订单明细表(WMS_PickingDetail)
							INSERT INTO WMS_PickingDetail(pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,itemId,
								isPackage,pickState,stockQty,pickQty,actualQty,realQty,boxId,boxOrder,stockId,stockNo,stockBillNo,pkgRatio)					
							VALUES(LOWER(REPLACE(NEWID(),'-','')),@pickId,@pickingNo,@companyId,@warehouseId,@regionId,@lotNo,@locationNo,@itemId,
								1,0,1.0,1.0,0.0,@replenishQty,'',@boxCount,@replenishId,@replenishId,@replenishBillNo,@replenishQty) 							
						END
						FETCH NEXT FROM myOrder INTO @replenishId,@itemId,@lotNo,@locationNo,@replenishQty,@pickQty,@pkgRatio
					END
					CLOSE myOrder
					DEALLOCATE myOrder
					FETCH NEXT FROM myTask INTO @warehouseId,@regionId,@boxCount
				END 
				CLOSE myTask
				DEALLOCATE myTask				
			END
			--更新SAD_Stock顺序
			UPDATE a SET a.collectOrder=b.viewOrder
			FROM dbo.SAD_Stock a INNER JOIN dbo.WMS_WaveDetail b ON a.stockNo=b.stockNo
			WHERE b.waveNo=@waveNo;
			--重新生成波次下整件任务序号
			DELETE FROM @sales;
			INSERT INTO @sales(policyId,viewOrder,boxOrder)  
			SELECT a.pickId,ROW_NUMBER() OVER (PARTITION BY a.stockNo ORDER BY a.boxBillNum) AS stockBox,
				ROW_NUMBER() OVER (PARTITION BY a.stockNo,c.itemId ORDER BY a.boxBillNum) AS boxOrder			
			FROM dbo.WMS_PickingOrder a 
				INNER JOIN dbo.WMS_Picking b ON a.pickingNo=b.pickingNo
				INNER JOIN (SELECT pickId,itemId,COUNT(1) AS skuCount 
				            FROM dbo.WMS_PickingDetail
				            GROUP BY pickId,itemId) c ON a.pickId=c.pickId
			WHERE b.waveNo=@waveNo AND b.taskType=1;
			UPDATE a SET a.stockBox=b.viewOrder,a.boxOrder=b.boxOrder
			FROM dbo.WMS_PickingOrder a 
				INNER JOIN @sales b ON a.pickId=policyId 
			--波次计划结束
			FETCH NEXT FROM myWave INTO @waveNo
		END
		CLOSE myWave
		DEALLOCATE myWave
		--更新任务等级
		UPDATE a SET flag=5
		FROM WMS_Picking a
		WHERE pickingNo=ANY(SELECT x.pickingNo FROM dbo.WMS_PickingOrder x INNER JOIN @tmpHead y ON x.stockNo=y.stockNo WHERE y.flag=5);
		--更新出库单状态
		UPDATE SAD_Stock SET taskState=40 WHERE stockNo=ANY(SELECT stockNo FROM @tmpPick WHERE pickQty>0.0);		
		--清除各种表变量数据
		DELETE FROM @sales;
		DELETE FROM @tmpHead;
		DELETE FROM @tmpDetail;
		DELETE FROM @tmpAllocate;
		DELETE FROM @tmpLocation;
		DELETE FROM @tmpPick;
		DELETE FROM @tmpReplenish;
		DELETE FROM @wave;
		DELETE FROM @waveDtl;
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_ERROR',LEFT(@ErrMsg,2000),'','');
		RAISERROR(@ErrMsg, @ErrSeverity, 1)					
	END CATCH
END

go

