
/*==============================================================*/
/* View: IMS_TransferForPrint_V                                 */
/*==============================================================*/
create view IMS_TransferForPrint_V as
SELECT a.transferNo,a.billNo,a.transferDate,a.companyId,c.companyName,w1.warehouseName AS outputName,
	w2.warehouseName AS inputName,d1.deptNo AS deptOutNo,d1.deptName AS deptOutName,d2.deptNo AS deptInNo,
	d2.deptName AS deptInName,e1.employeeName AS handlerName,u1.userNick AS creatorName,u2.userNick AS auditorName,
	a.createTime,a.auditTime,ISNULL(printNum,0)+1 AS printNum,b.viewOrder,bi.itemNo,bi.itemName,
	bi.itemSpec,bi.colorName,bi.sizeName,bi.unitName,b.inputNo,b.outputNo,b.lotNo,b.ioQty,b.price,
	b.taxrate,b.taxPrice,b.fee,b.taxFee,b.totalFee,b.remarks,a.memo
FROM dbo.IMS_Transfer a
	INNER JOIN dbo.IMS_TransferDetail b ON a.transferNo=b.transferNo
	INNER JOIN dbo.SAM_Company c ON a.companyId=c.companyId
	INNER JOIN dbo.BAS_Warehouse w1 ON a.outputId=w1.warehouseId
	INNER JOIN dbo.BAS_Warehouse w2 ON a.inputId=w2.warehouseId
	INNER JOIN dbo.BAS_Item bi ON b.itemId=bi.itemId
	LEFT JOIN dbo.BAS_Department d1 ON a.deptOutId=d1.deptId
	LEFT JOIN dbo.BAS_Department d2 ON a.deptInId=d2.deptId
	LEFT JOIN dbo.BAS_Employee e1 ON a.handlerId=e1.employeeId
	LEFT JOIN dbo.SAM_User u1 ON a.creatorId=u1.userId
	LEFT JOIN dbo.SAM_User u2 ON a.auditorId=u2.userId
go

