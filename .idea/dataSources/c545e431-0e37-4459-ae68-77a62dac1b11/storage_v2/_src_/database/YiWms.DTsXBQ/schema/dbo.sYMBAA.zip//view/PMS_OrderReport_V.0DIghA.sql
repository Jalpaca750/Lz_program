/*==============================================================*/
/* View: PMS_OrderReport_V                                      */
/*==============================================================*/
CREATE view [dbo].[PMS_OrderReport_V] as
SELECT a.orderNo,a.billNo,a.orderDate,c.companyName,o.ownerNo,o.ownerName,s.partnerNo AS supplierNo,s.partnerName AS supplierName,
      s.shortName,CONVERT(VARCHAR(10),a.requireDate,23) AS requireDate,a.requireTime,d.deptNo,d.deptName,e1.employeeName AS handlerName,
      w.warehouseName,ISNULL(e2.employeeName,a.buyerId) AS buyerName,CASE a.orderSource WHEN 11 THEN '普通订单' 
                                                                                        WHEN 12 THEN '应急订单' 
                                                                                        WHEN 13 THEN '零星采购' 
                                                                                        WHEN 14 THEN '转场订单' 
                                                                                        WHEN 21 THEN '调拨申请单' 
                                                                                        WHEN 31 THEN '赠品入库单'
                                                                                        WHEN 41 THEN '其他入库单' END AS orderSourceDesc,
      dbo.uf_GetUpper(CAST(a.totalFee AS DECIMAL(18,2))) AS upperRMB,CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,
      u1.userNick AS auditorName,a.poNo,a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5,ISNULL(a.printNum,0) + 1 AS printNum,
      u5.userNick AS printMan,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,a.memo,a.createTime,u3.userNick AS creatorName,a.editTime,
      u4.userNick AS editorName,t.viewOrder,t.itemNo,t.itemName,t.itemSpec,t.barcode,t.colorName,t.sizeName,t.unitName,t.pkgLong,t.pkgHeight,t.pkgWidth,t.pkgRatio,t.pkgUnit,
      t.orderQty,t.befPrice,t.discount,t.discountFee,t.price,t.fee,t.taxFee,t.totalFee,t.lotNo,t.rebate,t.pkgQty,t.bulkQty,t.packageId,t.remarks
FROM dbo.PMS_Order a 
      INNER JOIN dbo.SAM_Company c ON a.companyId=c.companyId 
      INNER JOIN (SELECT dtl.orderNo,dtl.viewOrder AS viewOrder,bi.itemNo,bi.pkgLong,bi.pkgWidth,bi.pkgHeight,bi.itemName,bi.itemSpec,bi.barcode,bi.colorName,bi.sizeName,
                        bi.unitName,bi.pkgRatio,bi.pkgUnit,dtl.orderQty,dtl.befPrice,dtl.discount,dtl.discountFee,dtl.price,dtl.fee,
                        dtl.taxFee,dtl.totalFee,dtl.lotNo,dtl.rebate,dtl.pkgQty,dtl.bulkQty,bi.packageId,dtl.remarks
				  FROM dbo.PMS_OrderDetail dtl 
				        INNER JOIN dbo.BAS_Item bi ON dtl.itemId=bi.itemId
				  WHERE ISNULL(dtl.orderQty,0.0)-ISNULL(dtl.receiveQty,0.0)>0.0) t ON a.orderNo=t.orderNo 
	  LEFT JOIN dbo.BAS_Owner_V o ON a.ownerId=o.ownerId 
	  LEFT JOIN dbo.BAS_Partner s ON a.supplierId=s.partnerId 
	  LEFT JOIN dbo.BAS_Department d ON a.deptId=d.deptId 
	  LEFT JOIN dbo.BAS_Employee e1 ON a.handlerId=e1.employeeId 
	  LEFT JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId 
	  LEFT JOIN dbo.BAS_Employee e2 ON a.buyerId=e2.employeeId 
	  LEFT JOIN dbo.SAM_User u1 ON a.auditorId=u1.userId 
	  LEFT JOIN dbo.SAM_User u2 ON a.lockerId=u2.userId 
	  LEFT JOIN dbo.SAM_User u3 ON a.creatorId=u3.userId 
	  LEFT JOIN dbo.SAM_User u4 ON a.editorId=u4.userId 
	  LEFT JOIN dbo.SAM_User u5 ON a.printId=u5.userId
go

