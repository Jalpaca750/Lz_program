/*==============================================================*/
/* View: BAS_Location_V                                         */
/*==============================================================*/
--creator：        Frank
--create time：  2016-02-22
--modify:2016-09-22 frank 增加WMS相关货位数据
--       2017-03-01 frank 修改表结构，pickingOrder与putawayOrder为INT类型
--                        并增加isDisable字段，并对视图做出相应调整
--       2018-05-14 frank 增加最低库存 minQty字段，并调整视图
--       2018-12-11 frank 删除locationArea字段，增加zoneId等字段，并调整相关视图
--       2019-10-15 frank 增加储位类型字段与高频标识字段
--货位资料视图
CREATE view [dbo].[BAS_Location_V] as
SELECT a.locationId,a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,a.locationNo,a.pickingOrder,
	a.putawayOrder,a.locationDesc,a.zoneId,wa.zoneNo,wa.zoneDesc,a.regionId,r.regionNo,r.regionDesc,
	a.loctypeId,t.loctypeDesc,a.isFrequently,
	a.layerId,a.locationWay,a.locationRow,a.locationCol,a.locationLayer,l.layerLong,l.layerWidth,l.layerHeight,
	l.stdVolume,l.maxVolume AS useVolume,a.isFixed,CASE a.isFixed WHEN 1 THEN '是' ELSE '否' END AS fixedDesc,
	a.isPackage,CASE a.isPackage WHEN 10 THEN '件拣货库位' 
											WHEN 20 THEN '箱拣货库位' 
											WHEN 30 THEN '混合拣库位' 
											WHEN 40 THEN '储货位库位' 
											WHEN 50 THEN '过渡库位' END AS packageDesc,a.maxQty,a.minQty,a.maxWeight,
	a.maxVolume,a.locationLong,a.locationWidth,a.locationHeight,CASE a.multItem WHEN 1 THEN '是' ELSE '否' END AS multItemName,
	a.multItem,a.multBatch, CASE a.multBatch WHEN 1 THEN '是' ELSE '否' END AS multBatchName,a.itemId,
	b.itemNo,b.itemName,b.itemCTitle,b.itemETitle,b.itemSpec,b.itemSpell,b.barcode,b.midBarcode,b.bigBarcode,
	b.pkgBarcode,b.colorName,b.sizeName,b.unitName,a.isDisable,CASE a.isDisable WHEN 1 THEN '是' ELSE '否' END AS isDisableName,
    b.ownerId,b.ownerNo,b.ownerName,b.ownerShortName,'' AS locationArea,a.isLocked,a.lockerId,u3.userNick AS lockerName,
    CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,a.creatorId,u1.userNick AS creatorName,
    a.editTime,a.editorId,u2.userNick AS editorName,a.isSelected
FROM dbo.BAS_Location a 
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId	
	LEFT JOIN dbo.BAS_Region r ON a.regionId=r.regionId 
	LEFT JOIN dbo.BAS_Zone wa ON a.zoneId=wa.zoneId
	LEFT JOIN dbo.BAS_Layer l ON a.layerId=l.layerId
	LEFT JOIN dbo.BAS_LocationType t ON a.loctypeId=t.loctypeId
	LEFT JOIN (SELECT x.itemId,x.itemNo,x.itemName,x.itemCTitle,x.itemETitle,x.itemSpec,x.itemSpell,
					x.barcode,x.midBarcode,x.bigBarcode,x.pkgBarcode,x.colorName,x.sizeName,x.unitName,
					x.ownerId,y.partnerNo AS ownerNo,y.partnerName AS ownerName,y.shortName AS ownerShortName
				FROM dbo.BAS_Item x 
					INNER JOIN dbo.BAS_Partner y ON x.ownerId=y.partnerId
				) b ON a.itemId=b.itemId
	LEFT JOIN dbo.SAM_User u1 ON a.creatorId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON a.editorId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON a.lockerId=u3.userId
go

