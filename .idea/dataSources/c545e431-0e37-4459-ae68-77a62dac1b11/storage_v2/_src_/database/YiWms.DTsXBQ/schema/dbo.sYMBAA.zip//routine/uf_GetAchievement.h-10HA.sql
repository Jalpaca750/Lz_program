-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2016-12-09>
-- Description:	<Description:业绩报表 V1>
-- 包含：
--      散件分拣条目
--      整件分拣箱数
--      散件复核条目
--      打包条目数
--      打包箱数等
--      盘点、调整
--      补货上架
--      补货下架
--      收货
--      采购上架    
-- =============================================
CREATE FUNCTION [dbo].[uf_GetAchievement]
(
    @companyId VARCHAR(32),				        --公司Id
    @startTime DATETIME,						--起始时间
    @endTime DATETIME							--截止时间
)
RETURNS @result TABLE
(
	userId VARCHAR(32),					--用户Id
	userNo VARCHAR(100),				--用户账号
	userNick VARCHAR(100),				--用户名称
	pickCount INT DEFAULT 0,			--分拣条目
	pickErrCount INT DEFAULT 0,			--分拣出错条目
	pickErrRate DECIMAL(6,2),			--分拣错误率
	pickFCLBoxes INT DEFAULT 0,			--分拣整箱数
	pickPCLBoxes INT DEFAULT 0,			--分拣整拖数				
	checkCount INT DEFAULT 0,			--复核条目
	checkFclCount INT DEFAULT 0,		--复核整件数		
	packCount INT DEFAULT 0,			--打包条目
	packBoxes INT DEFAULT 0,			--打包箱数		
	physicalCount INT DEFAULT 0,		--盘点条目
	replenishCount INT DEFAULT 0,		--补货下架条目
	putawayCount INT DEFAULT 0,			--补货上架条目
	receiveCount INT DEFAULT 0,			--采购收货条目
	purchaseCount INT DEFAULT 0,		--采购上架条目
	returnCount INT DEFAULT 0,          --退货上架
	assemblyQty DECIMAL(20,6) DEFAULT 0.0           --安装数量
)
AS
BEGIN
    DECLARE @tmpCount TABLE
	(
		userId VARCHAR(32),					--用户Id
		pickCount INT DEFAULT 0,			--分拣条目
		pickErrCount INT DEFAULT 0,			--分拣出错条目
		pickErrRate DECIMAL(6,2),			--分拣错误率
		pickFCLBoxes INT DEFAULT 0,			--分拣整箱数	
		pickPCLBoxes INT DEFAULT 0,			--分拣整拖数	
		checkCount INT DEFAULT 0,			--复核条目
		checkFclCount INT DEFAULT 0,		--复核整件数		
		packCount INT DEFAULT 0,			--打包条目
		packBoxes INT DEFAULT 0,			--打包箱数		
		physicalCount INT DEFAULT 0,		--盘点条目
		replenishCount INT DEFAULT 0,		--补货条目数
		putawayCount INT DEFAULT 0,			--补货上架条目
		ReceiveCount INT DEFAULT 0,			--采购收货条目	
		PurchaseCount INT DEFAULT 0,		--采购上架条目			
		ReturnCount INT DEFAULT 0,          --退货上架
		assemblyQty DECIMAL(20,6) DEFAULT 0.0         --安装数量
	);	
	--整件作业统计数据
	DECLARE @tmpPick TABLE(pickerId VARCHAR(32),pickingNo VARCHAR(32),locationNo VARCHAR(32),itemId VARCHAR(32),pickFCLBoxes INT,pkgRatio INT);
	
	--散件拣货业绩（作业人员Id,分拣条目，分拣商品数,拼箱数）
	INSERT INTO @tmpCount(userId,pickCount)
	SELECT a.pickerId,COUNT(1) AS pickCount
	FROM dbo.WMS_Picking a 
		INNER JOIN dbo.WMS_PickingOrder b ON a.pickingNo=b.pickingNo
		INNER JOIN dbo.WMS_PickingDetail c ON b.pickId=c.pickId
	WHERE (a.companyId=@companyId)							--公司Id
		AND (a.taskType=0)									--0-散件;1-整箱;2-补货
		AND (a.getTime BETWEEN @startTime AND @endTime)		--分拣时间（任务领取时间）
		AND (c.pickState>1)									--0-待领取；1-待拣货；2-待复核；3-待打包；4--待装车
		AND (c.pickQty>0.0)									--过滤掉时间分拣数量为0的
	GROUP BY a.pickerId;
	
	--整件拣货业绩（作业人员Id,任务，库位，商品，整箱数）
	INSERT INTO @tmpPick(pickerId,pickingNo,locationNo,itemId,pkgRatio,pickFCLBoxes)
	SELECT a.pickerId,a.pickingNo,c.locationNo,c.itemId,c.pkgRatio,SUM(c.pickQty) AS pickFCLBoxes
	FROM dbo.WMS_Picking a 
		INNER JOIN dbo.WMS_PickingOrder b ON a.pickingNo=b.pickingNo
		INNER JOIN dbo.WMS_PickingDetail c ON b.pickId=c.pickId
	WHERE (a.companyId=@companyId)							--公司Id
		AND (a.taskType=1)									--0-散件;1-整箱;2-补货
		AND (a.getTime BETWEEN @startTime AND @endTime)		--分拣时间（任务领取时间）
		AND (c.pickState>1)									--0-待领取；1-待拣货；2-待复核；3-待打包；4--待装车；
		AND (c.pickQty>0.0)									--过滤掉时间分拣数量为0的
	GROUP BY a.pickerId,a.pickingNo,c.locationNo,c.itemId,c.pkgRatio;	
	
	--整件拣货业绩（作业人员Id,整箱数，整托盘数）
	INSERT INTO @tmpCount(userId,pickFCLBoxes,pickPCLBoxes)
	SELECT a.pickerId,SUM(CASE ISNULL(b.palletRatio,0) WHEN 0 THEN a.pickFCLBoxes ELSE ((a.pickFCLBoxes*a.pkgRatio)%b.palletRatio)/a.pkgRatio END) AS pickFCLBoxes,
	    SUM(CASE ISNULL(b.palletRatio,0) WHEN 0 THEN 0 ELSE FLOOR(a.pickFCLBoxes*a.pkgRatio/b.palletRatio) END) AS pickFCLBoxes
	FROM @tmpPick a 
		INNER JOIN dbo.BAS_Item b ON a.itemId=b.itemId
	GROUP BY a.pickerId;
		
	--分拣出错登记
	INSERT INTO @tmpCount(userId,pickErrCount)
	SELECT pickerId,COUNT(1) AS pickErrCount
	FROM WMS_PickingError
	WHERE companyId=@companyId								--公司Id
		AND (pickTime BETWEEN @startTime AND @endTime)		--分拣时间（任务领取时间）
	GROUP BY pickerId;
	
	--统计散件复核业绩
	INSERT INTO @tmpCount(userId,checkCount)
	SELECT b.checkerId,COUNT(1) AS checkCount
	FROM dbo.WMS_Picking a 
		INNER JOIN dbo.WMS_PickingOrder b ON a.pickingNo=b.pickingNo
		INNER JOIN dbo.WMS_PickingDetail c ON b.pickId=c.pickId
	WHERE (a.companyId=@companyId)									--公司Id
		AND (a.taskType=0)											--0-散件;1-整箱;2-补货
		AND (b.checkTime BETWEEN @startTime AND @endTime)			--复核时间
		AND (b.taskState>2)											--0-待领取；1-待拣货；2-待复核；3-待打包；4--待装车；5-已装车-6已发货		
		AND (c.pickQty>0.0)
	GROUP BY b.checkerId;
	
	--统计整件复核件数
	INSERT INTO @tmpCount(userId,checkFclCount)
	SELECT t.checkerId,COUNT(1) AS checkFclCount
	FROM dbo.WMS_Picking a
		INNER JOIN (SELECT x.checkerId,x.pickingNo,y.itemId,SUM(y.pickQty) AS pickQty
					FROM WMS_PickingOrder x
						INNER JOIN dbo.WMS_PickingDetail y ON x.pickId=y.pickId
					WHERE x.companyId=@companyId
						AND x.isPackage=1 
						AND (x.taskState>2)	
						AND (ISNULL(y.pickQty,0.0)>0.0)
						AND (x.checkTime BETWEEN @startTime AND @endTime)
					GROUP BY x.checkerId,x.pickingNo,y.itemId
					) t ON a.pickingNo=t.pickingNo
	WHERE (a.companyId=@companyId)														--公司Id
		AND (a.taskType=1)
	GROUP BY t.checkerId
	
	
	--统计散件打包业绩（文之选）
	INSERT INTO @tmpCount(userId,packCount,packBoxes)
	SELECT a.packingId,COUNT(1) AS packCount,COUNT(DISTINCT a.packNo) AS packBoxes
	FROM dbo.WMS_Packing a 
		INNER JOIN dbo.WMS_PackingDetail b ON a.packNo=b.packNo
	WHERE (a.companyId=@companyId)										--公司Id
		AND (a.packingTime BETWEEN @startTime AND @endTime)				--复核时间
	GROUP BY a.packingId;
    
    --统计安装数量（文之选）
    INSERT INTO @tmpCount(userId,assemblyQty)
    SELECT a.packingId,SUM(b.packQty)
    FROM dbo.WMS_Packing a
        INNER JOIN dbo.WMS_PackingDetail b ON a.packNo=b.packNo
        INNER JOIN dbo.SAD_StockDetail c ON b.stockId=c.stockId
    WHERE (a.companyId=@companyId)	
        AND (a.packingTime BETWEEN @startTime AND @endTime)				--复核时间
        AND (c.needAssemble=1)
    GROUP BY a.packingId;   
	
	--统计盘点数据
	INSERT INTO @tmpCount(userId,physicalCount)
	SELECT a.creatorId,COUNT(1) AS physicalCount
	FROM dbo.IMS_Check a INNER JOIN dbo.IMS_CheckDetail b ON a.checkNo=b.checkNo
	WHERE (a.companyId=@companyId) 
		AND (a.billState=20 OR a.billState=30)
		AND (a.createTime BETWEEN @startTime AND @endTime)
	GROUP BY a.creatorId
	UNION ALL--抽查调整数据
	SELECT a.creatorId,COUNT(1) AS physicalCount
	FROM dbo.IMS_Adjust a INNER JOIN dbo.IMS_AdjustDetail b ON a.adjustNo=b.adjustNo
	WHERE (a.companyId=@companyId) 
		AND (a.ioState=20)
		AND (a.adjustDate BETWEEN @startTime AND @endTime)
		AND (ISNULL(a.pointId,'')='')
	GROUP BY a.creatorId
	
	
	
	--统计补货业绩（下架）
	INSERT INTO @tmpCount(userId,replenishCount)
	SELECT a.pickerId,COUNT(1) 
	FROM dbo.WMS_Picking a 
		INNER JOIN dbo.WMS_PickingOrder b ON a.pickingNo=b.pickingNo
		INNER JOIN dbo.WMS_PickingDetail c ON b.pickId=c.pickId
	WHERE (a.companyId=@companyId)									--公司Id
		AND (a.taskType=2)											--0-散件;1-整箱;2-补货		
		AND (a.getTime BETWEEN @startTime AND @endTime)				--分拣时间（任务领取时间）
		AND (b.taskState>1)											--0-待领取；1-待拣货；2-待复核；3-待打包；4--待装车；5-已装车-6已发货
		AND (c.pickQty>0.0)											--过滤掉时间分拣数量为0的
	GROUP BY a.pickerId	
	--统计补货业绩（上架）
	INSERT INTO @tmpCount(userId,putawayCount)
	SELECT b.loadingId,COUNT(1)
	FROM dbo.WMS_Picking a 
		INNER JOIN dbo.WMS_PickingOrder b ON a.pickingNo=b.pickingNo
		INNER JOIN dbo.WMS_PickingDetail c ON b.pickId=c.pickId
	WHERE (a.companyId=@companyId)									--公司Id
		AND (a.taskType=2)											--0-散件;1-整箱;2-补货		
		AND (b.loadingTime BETWEEN @startTime AND @endTime)			--分拣时间（任务领取时间）
		AND (b.taskState=6)											--0-待领取；1-待拣货；2-待复核；3-待打包；4--待装车；5-已装车-6已发货
		AND (c.pickQty>0.0)											--过滤掉时间分拣数量为0的
	GROUP BY b.loadingId
	
	--采购收货条目数
	INSERT INTO @tmpCount(userId,ReceiveCount)
	SELECT a.receiverId,COUNT(1)
	FROM dbo.PMS_Stock a INNER JOIN
		dbo.PMS_StockDetail b ON a.stockNo=b.stockNo
	WHERE (a.companyId=@companyId)									--公司Id
		AND (a.ioState=20 OR a.ioState=25 OR a.ioState=30)			--待上架，部分上架以及全部上级的入库单
		AND (a.receiveDate BETWEEN @startTime AND @endTime)			--收货日期（任务领取时间）
	GROUP BY a.receiverId
	--采购上架
	INSERT INTO @tmpCount(userId,PurchaseCount)
	SELECT c.putawayId,COUNT(1)
	FROM dbo.PMS_Stock a INNER JOIN
		dbo.PMS_StockDetail b ON a.stockNo=b.stockNo INNER JOIN
		dbo.WMS_PutawayDetail c ON b.stockId=c.stockId
	WHERE (a.companyId=@companyId)									--公司Id
		AND (a.ioState=20 OR a.ioState=25 OR a.ioState=30)			--待上架，部分上架以及全部上级的入库单
		AND (c.putawayTime BETWEEN @startTime AND @endTime)			--收货日期（任务领取时间）
	GROUP BY c.putawayId
	---销退上架
	INSERT INTO @tmpCount(userId,ReturnCount)
	SELECT c.putawayId,COUNT(1)
	FROM dbo.SAD_Return AS a INNER JOIN
		 dbo.SAD_ReturnDetail AS b ON a.returnNo=b.returnNo INNER JOIN
		 dbo.WMS_PutawayDetail c ON b.returnId=c.stockId
	WHERE (a.companyId=@companyId)									--公司Id
		AND (a.ioState=20 OR a.ioState=25 OR a.ioState=30)			--待上架，部分上架以及全部上级的入库单
		AND (c.putawayTime BETWEEN @startTime AND @endTime)			--退货货日期（任务领取时间）
	GROUP BY c.putawayId
	
	INSERT INTO @result(userId,userNo,userNick,pickCount,pickErrCount,
		pickFCLBoxes,pickPCLBoxes,checkCount,checkFclCount,packCount,packBoxes,
		physicalCount,replenishCount,putawayCount,
		ReceiveCount,PurchaseCount,ReturnCount,assemblyQty)		
	SELECT a.userId,b.userNo,b.userNick,SUM(a.pickCount),SUM(a.pickErrCount),
		SUM(a.pickFCLBoxes),SUM(a.pickPCLBoxes),SUM(a.checkCount),SUM(a.checkFclCount),SUM(a.packCount),
		SUM(a.packBoxes),SUM(a.physicalCount),SUM(a.replenishCount),SUM(a.putawayCount),
		SUM(a.ReceiveCount),SUM(a.PurchaseCount),SUM(a.ReturnCount),SUM(a.assemblyQty)
	FROM @tmpCount a INNER JOIN dbo.SAM_User b ON a.userId=b.userId
	GROUP BY a.userId,b.userNo,b.userNick
	--更新错误率
	UPDATE @result SET pickErrRate=CASE ISNULL(pickCount,0.0) WHEN 0.0 THEN 0.0 ELSE CAST(ISNULL(pickErrCount,0.0)/pickCount AS DECIMAL(6,2)) END;
	RETURN
END
go

