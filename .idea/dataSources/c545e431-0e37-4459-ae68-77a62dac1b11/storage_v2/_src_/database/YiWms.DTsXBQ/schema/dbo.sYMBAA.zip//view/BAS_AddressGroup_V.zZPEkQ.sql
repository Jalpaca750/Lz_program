
/*==============================================================*/
/* View: BAS_AddressGroup_V                                     */
/*==============================================================*/
create view BAS_AddressGroup_V as
--2016-09-18 地址分组视图统一修正
SELECT a.groupId,a.groupNo,a.groupName,a.companyId,a.isLocked,a.lockerId,u1.userNick AS lockerName,
      CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,u2.userNick AS creatorName,
      a.creatorId,a.editTime,u3.userNick AS editorName,a.editorId,a.isSelected  
FROM dbo.BAS_AddressGroup a LEFT JOIN
      dbo.SAM_User u1 ON a.lockerId=u1.userId LEFT JOIN
      dbo.SAM_User u2 ON a.creatorId=u2.userId LEFT JOIN
      dbo.SAM_User u3 ON a.editorId=u3.userId
go

