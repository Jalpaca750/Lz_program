

CREATE FUNCTION [dbo].[fn_GetF10BillPkgQty]
(
	@billNo VARCHAR(32),
	@BillType INT
)
RETURNS INT
AS
BEGIN
    DECLARE @PkgQty INT;
    IF (@BillType<60)
        SELECT @PkgQty=fclQty FROM WMS_ShipBill_V WHERE billNo=@billNo;
    ELSE IF (@BillType=60)
        SELECT @PkgQty=fclQty FROM WMS_ShipReturn_V WHERE billNo=@billNo;
    ELSE IF (@BillType=70)
        SELECT @PkgQty=1;
    ELSE IF (@BillType=80)
        SELECT @PkgQty=lclQty FROM WMS_ShipStock_V WHERE billNo=@billNo;
    ELSE IF (@BillType=90)
        SELECT @PkgQty=ISNULL(lclQty,0)+ISNULL(fileQty,0) FROM WMS_ShipProject_V WHERE billNo=@billNo;
    ELSE
        SET @PkgQty=1;
    RETURN ISNULL(@PkgQty,1);
END
go

