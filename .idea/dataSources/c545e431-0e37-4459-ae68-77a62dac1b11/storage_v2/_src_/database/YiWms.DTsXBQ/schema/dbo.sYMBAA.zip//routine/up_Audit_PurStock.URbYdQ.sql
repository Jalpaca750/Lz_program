-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-02-06>
-- Description:	<Description:采购入库单上架 V2.0>
--  PC端上架，在库位更改后执行该操作                         
--  操作影响商品库存(BAS_Item表onhandQty)
--          仓库库存(IMS_Ledger表的onhandQty)，成本处理忽略不计
--          库位库存(IMS_Stock表) 
--          入出库流水帐(IMS_Book)
--          zdy 修正采购收货上架PC端操作Bug;上架整件转换与新增上架任务表状态问题
-- =============================================
CREATE PROCEDURE [dbo].[up_Audit_PurStock]
(
    @stockNo VARCHAR(32),		--入库单号
	@operatorId VARCHAR(32)		--操作员
)
AS
BEGIN	
	DECLARE @companyId VARCHAR(32),		--公司Id
			@billNo VARCHAR(32),		--入库单号
			@warehouseId VARCHAR(32),	--仓库Id
			@supplierId VARCHAR(32),	--供应商Id
			@createTime DATETIME,		--制单时间
			@creatorId VARCHAR(32),		--制单人Id
			@handlerId VARCHAR(32),		--经办人Id
			@deptId VARCHAR(32),		--经办部门Id
			@memo VARCHAR(2000),		--主表备注
			@ioType VARCHAR(32),		--入出库类型（P100-采购入库单）
			@taxFlag INT,				--是否含税（默认含税）
			@stockId VARCHAR(32),		--明细Id
			@eId VARCHAR(32),			--主商品Id
			@itemId VARCHAR(32),		--SkuId			
			@receiveQty DECIMAL(20,6),	--数量
			@lotNo VARCHAR(32),			--批次号
			@regionId VARCHAR(32),		--库区
			@locationNo VARCHAR(32),	--库位	
			@putawayNo VARCHAR(32),		--上架任务No
			@putawayId VARCHAR(32)		--上架人
	--此处可用于计算成本
	DECLARE @befQty DECIMAL(20,6),			--出入库前数量
			@flowId VARCHAR(32),			--预分配Id
			@auditTime DATETIME				--审核时间
			
	--审核时间
	SET @auditTime=GETDATE();
	--如果入库单已经部分或者全部上架则直接退出（包括还没有审核，已经作废等）
	IF EXISTS(SELECT 1 FROM PMS_Stock WHERE stockNo=@stockNo AND ioState!=20)
		RETURN;
	BEGIN TRY
		BEGIN TRANSACTION
		--主表信息		
		SELECT @billNo=billNo,@companyId=companyId,@warehouseId=warehouseId,@supplierId=supplierId,@ioType=ioType,
			@taxFlag=taxFlag,@createTime=createTime,@creatorId=creatorId,@handlerId=handlerId,@deptId=deptId,@memo=memo
		FROM PMS_Stock 
		WHERE stockNo=@stockNo;
		--处理明细数据
		DECLARE myCursor CURSOR
		FOR SELECT b.putawayNo,a.stockId,a.eId,a.itemId,b.putawayId,ISNULL(b.lotNo,''),ISNULL(b.locationNo,''),CASE b.unitLevel WHEN 'EA' THEN b.putQty WHEN 'CS' THEN b.putQty*b.pkgRatio END,b.flowId
			FROM PMS_StockDetail a INNER JOIN 
				WMS_PutawayDetail b ON a.stockId=b.stockId
			WHERE a.stockNo=@stockNo
			ORDER BY a.viewOrder
		OPEN myCursor
		FETCH NEXT FROM myCursor INTO @putawayNo,@stockId,@eId,@itemId,@putawayId,@lotNo,@locationNo,@receiveQty,@flowId
		WHILE @@FETCH_STATUS=0
		BEGIN
			--库区
			SELECT @regionId=regionId 
			FROM dbo.BAS_Location 
			WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@locationNo;	
			--处理商品库存
			UPDATE BAS_Item SET onhandQty=ISNULL(onhandQty,0.0)+@receiveQty WHERE itemId=@itemId;						
			--处理IMS_Ledger表,如果表中没有数据，则新增一条记录
			IF EXISTS(SELECT 1 FROM IMS_Ledger WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId)
				UPDATE IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)+@receiveQty,lastITime=@auditTime
				WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
			ELSE
				INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastITime)
				VALUES(REPLACE(NEWID(),'-',''),@companyId,@warehouseId,@eId,@itemId,@receiveQty,0.0,@auditTime);
			--处理IMS_Stock表(如果表中没有数据，则直接新增一条)
			IF EXISTS(SELECT 1 FROM IMS_Stock WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId)
			BEGIN
				--入库前数量（用于流水帐）
				SELECT @befQty=ISNULL(onhandQty,0.0)
				FROM IMS_Stock
				WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId;
				--更新数量
				UPDATE IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)+@receiveQty,lastITime=@auditTime
				WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId;
			END
			ELSE
			BEGIN
				SET @befQty=0.0;
				INSERT INTO IMS_Stock(stockId,companyId,warehouseId,regionId,locationNo,lotNo,eId,itemId,onhandQty,allocQty,lastITime)
				VALUES(REPLACE(NEWID(),'-',''),@companyId,@warehouseId,@regionId,@locationNo,@lotNo,@eId,@itemId,@receiveQty,0.0,@auditTime);
			END
			--处理IMS_Book表
			INSERT INTO IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,
				eId,itemId,befQty,ioQty,afterQty,handlerId,deptId,createTime,creatorId,auditTime,auditorId,memo)
			VALUES(REPLACE(NEWID(),'-',''),@ioType,@companyId,@stockId,@stockNo,@billNo,@supplierId,@warehouseId,ISNULL(@lotNo,''),ISNULL(@locationNo,''),
			    @eId,@itemId,@befQty,@receiveQty,ISNULL(@befQty,0.0)+ISNULL(@receiveQty,0.0),@handlerId,@deptId,@createTime,
			    @creatorId,@auditTime,@operatorId,@memo);
			--上架完成  上架单状态更改
			UPDATE WMS_PutawayDetail SET ioState=30,putawayId=@putawayId,putawayTime=@auditTime WHERE flowId=@flowId;
			--更新上架单主单
			UPDATE WMS_Putaway set putawayId=@putawayId,putawayTime=@auditTime,ioState=30 WHERE putawayNo=@putawayNo AND ioState=20;
			--更新入库明细(最后一个上架数据）
			UPDATE PMS_StockDetail SET ioState=30,putawayId=@putawayId,putawayTime=@auditTime,locationNo=@locationNo WHERE stockId=@stockId;
			--处理预分配表数据
			DELETE FROM IMS_Allocate WHERE allocId=@flowId;
			FETCH NEXT FROM myCursor INTO @putawayNo,@stockId,@eId,@itemId,@putawayId,@lotNo,@locationNo,@receiveQty,@flowId
		END
		CLOSE myCursor
		DEALLOCATE myCursor
		--更新入库单状态
		UPDATE PMS_Stock SET ioState=30,editTime=@auditTime,editorId=@operatorId,auditTime=@auditTime WHERE stockNo=@stockNo;
		COMMIT
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END CATCH
END
go

