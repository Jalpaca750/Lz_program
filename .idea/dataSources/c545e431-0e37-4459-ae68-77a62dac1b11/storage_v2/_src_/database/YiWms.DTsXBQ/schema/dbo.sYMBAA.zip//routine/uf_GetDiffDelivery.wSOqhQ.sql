
CREATE FUNCTION [dbo].[uf_GetDiffDelivery] 
(
	@companyId VARCHAR(32),
	@startTime DATETIME,
	@endTime DATETIME
)
RETURNS TABLE
RETURN
(
	SELECT a.orderId,a.orderNo,b.billNo,b.customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,
		p.partnerSpell AS customerSpell,p.shortName,b.receiverAddress,b.receiverName,b.receiverTel,b.receiverMobile,
		b.orderDate,b.shipDate,b.orderType,a.itemId,bi.itemNo,bi.itemName,bi.itemCTitle,bi.itemETitle,bi.sellingPoint,
		bi.itemSpec,bi.itemSpell,bi.barcode,bi.pkgBarcode,bi.colorName,bi.sizeName,bi.unitName,bi.pkgUnit,bi.packageId,
		bi.pkgRatio,bi.brandId,bi.brandNo,bi.brandCName,bi.categoryId,bi.categoryNo,bi.categoryCName,a.orderQty,
		ISNULL(t.realQty,0.0) AS actQty,CASE b.orderType WHEN 10 THEN '普通订单' 
														 WHEN 20 THEN '调拨申请' 
														 WHEN 30 THEN '经营领用' 
														 WHEN 31 THEN '管理领用' 
														 WHEN 40 THEN '赠品出库' 
														 WHEN 50 THEN '报损报废' END AS orderTypeName,
		CASE b.sdState WHEN 0 THEN 0 WHEN 10 THEN 10 ELSE t.taskState END AS state,
		CASE b.sdState WHEN 0 THEN '已关闭'  
					   WHEN 10 THEN '待审核' 
					   ELSE (CASE t.taskState WHEN 10 THEN '待审核'
											  WHEN 20 THEN '已审核'
											  WHEN 30 THEN '已排车'
											  WHEN 40 THEN '待配货'
											  WHEN 50 THEN '已配货'
											  WHEN 60 THEN '已复核'
											  WHEN 70 THEN '已打包'
											  WHEN 80 THEN '已装车'
											  WHEN 90 THEN '已发货' END) 
					   END AS stateName,b.lineId
	FROM dbo.SAD_OrderDetail a 
		INNER JOIN dbo.SAD_Order b ON a.orderNo=b.orderNo
		INNER JOIN dbo.BAS_Item_V bi ON a.itemId=bi.itemId
		INNER JOIN dbo.BAS_Partner p ON b.customerId=p.partnerId
		LEFT JOIN (
					SELECT s.billNo,sd.orderId,pk.realQty,s.taskState
					FROM dbo.SAD_Stock s
						INNER JOIN dbo.SAD_StockDetail sd ON s.stockNo=sd.stockNo
						LEFT JOIN (
									SELECT n.stockId,n.itemId,SUM(CASE n.isPackage WHEN 0 THEN n.pickQty ELSE n.pickQty*n.realQty END) AS realQty
									FROM dbo.WMS_PickingOrder m 
										INNER JOIN dbo.WMS_PickingDetail n ON m.pickId=n.pickId
									WHERE m.companyId=@companyId AND m.taskState>2
									GROUP BY n.stockId,n.itemId
			 					  ) pk ON sd.stockId=pk.stockId
			 		WHERE s.companyId=@companyId
				   ) t ON a.orderId=t.orderId
	WHERE (a.companyId=@companyId)
		AND (b.createTime BETWEEN @startTime AND @endTime)
)


go

