/*==============================================================*/
/* View: WMS_F10_PMS_ReturnDtl_V                                */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_PMS_ReturnDtl_V] as
SELECT b.billNo AS returnNo,NULL AS stockId,stockBillNo AS stockNo,w.warehouseNo AS warehouse,c.f10Id AS itemId,
	a.locationNo,0 AS pkgQty,a.returnQty,a.price,a.totalFee AS amt,0 AS taxFlag,0 AS isSpecial,
	a.remarks,returnId AS wmsReturnId,stockId AS wmsStockId,b.returnNo AS wmsOrder,a.viewOrder
FROM dbo.PMS_ReturnDetail a
	INNER JOIN dbo.PMS_Return b ON a.returnNo=b.returnNo
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	INNER JOIN F10BMS.dbo.WMS_F10_Item_V c ON a.itemId=c.itemId
WHERE b.ioState=20
	AND (b.thirdSyncFlag=0 OR b.thirdSyncFlag=2)
go

