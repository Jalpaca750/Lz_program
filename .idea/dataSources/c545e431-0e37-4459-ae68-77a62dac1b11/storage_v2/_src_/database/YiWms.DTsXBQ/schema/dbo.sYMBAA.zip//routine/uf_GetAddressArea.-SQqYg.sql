

-- =============================================
-- Author:		<Author: Wang_Jun>
-- Create date: <Create Date:2019-11-06>
-- Description:	<Description:得到地址对应省市区>
-- 包含：
-- =============================================
CREATE FUNCTION [dbo].[uf_GetAddressArea]
(
    @receiverAddress VARCHAR(2000)				      
)
RETURNS @result TABLE(areaId VARCHAR(32),areaName VARCHAR(32),areaType int,parentId VARCHAR(32),zip VARCHAR(32))
BEGIN
		DECLARE @SData TABLE(areaId VARCHAR(32),areaName VARCHAR(32),areaType int,parentId VARCHAR(32),zip VARCHAR(32))
		
		INSERT INTO @SData(areaId, areaName, areaType, parentId, zip)
		SELECT areaId, areaName, areaType, parentId, zip FROM dbo.BAS_Area
		
		DECLARE @areaId VARCHAR(32),                --目的省市Id
                @tmpAreaId VARCHAR(32)             --中间过渡区域Id
        --取得物流始发地址对应省市
        SELECT TOP 1 @tmpAreaId=areaId
        FROM @SData
        WHERE (CHARINDEX(areaName,@receiverAddress)>0  AND areaType=3) OR (CHARINDEX(areaName,@receiverAddress)>0  AND areaType=4)
         ORDER BY areaType;        --如果找到目的地址对应的省市
        IF (ISNULL(@tmpAreaId,'')!='')
        BEGIN    
            WITH cte 
            AS
            (
                SELECT areaId,parentId,areaType 
                FROM @SData
                WHERE areaId=@tmpAreaId
                UNION ALL
                SELECT a.areaId,a.parentId,a.areaType
                FROM @SData a INNER JOIN cte ON a.areaId=cte.parentId
            )
            SELECT TOP 1 @areaId=areaId FROM cte WHERE areaType=2;
        END
        INSERT INTO @result(areaId, areaName, areaType, parentId, zip)
        SELECT areaId,areaName,areaType,parentId,zip FROM @SData WHERE (areaId=@areaId OR areaId=@tmpAreaId)
        UNION ALL
        SELECT  areaId,areaName,areaType,parentId,zip FROM @SData 
        WHERE CHARINDEX(areaName,@receiverAddress)>0  AND parentId = @tmpAreaId;
        
        IF NOT EXISTS (SELECT 1 FROM @result WHERE areaType=3)
        BEGIN
   	        INSERT INTO @result(areaId, areaName, areaType, parentId, zip)
   					SELECT TOP 1 areaId, areaName, areaType, parentId, zip FROM @SData WHERE areaId=ANY(SELECT TOP 1 parentId FROM @result WHERE areaType=4)
        END
        
        IF NOT EXISTS (SELECT 1 FROM @result WHERE areaType=4)
        BEGIN
   	        INSERT INTO @result(areaId, areaName, areaType, parentId, zip)
   					SELECT TOP 1 areaId, areaName, areaType, parentId, zip FROM @SData 
   					WHERE CHARINDEX(areaName,@receiverAddress)>0 AND areaType=4 AND parentId=(SELECT areaId FROM @result WHERE areaType=3)
        END
        
        RETURN
END
		









go

