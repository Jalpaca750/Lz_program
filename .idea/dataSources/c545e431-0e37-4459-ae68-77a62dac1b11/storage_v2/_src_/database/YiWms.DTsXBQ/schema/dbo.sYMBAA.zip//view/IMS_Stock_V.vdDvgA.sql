
/*==============================================================*/
/* View: IMS_Stock_V                                            */
/*==============================================================*/
--creator：        Frank
--create time：  2016-12-16日整理 
--仓库货物库存视图
--              2017-05-02优化索引和视图 Frank
create view IMS_Stock_V as
SELECT a.stockId,a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,a.regionId,r.regionNo,r.regionDesc, 
      a.locationNo,a.lotNo,sku.eId,a.itemId,sku.itemNo,sku.itemCTitle,sku.itemETitle,sku.sellingPoint,sku.itemName,
      sku.itemSpec,sku.itemSpell,sku.barcode,sku.midBarcode,sku.bigBarcode,sku.pkgBarcode,sku.brandId,sku.brandNo,
      sku.brandCName,sku.brandEName,sku.categoryId,sku.categoryNo,sku.categoryCName,sku.categoryEName,sku.colorName,
      sku.sizeName,sku.unitName,sku.packageId,sku.isIrregular,sku.isSafety,sku.safetyMonth,sku.safetyDays,a.onhandQty,
      CASE ISNULL(sku.pkgRatio,0) WHEN 0 THEN 0.0 ELSE FLOOR(ISNULL(a.onhandQty,0.0)/sku.pkgRatio) END AS pkgQty,
      CASE ISNULL(sku.pkgRatio,0) WHEN 0 THEN 0.0 ELSE ISNULL(a.onhandQty,0.0) % sku.pkgRatio END AS bulkQty,
      a.allocQty,a.onWayQty,a.price,a.taxrate,a.taxPrice,a.fee,a.totalFee,a.lastITime,a.lastIPrice,a.lastITaxPrice,
      a.lastOTime,a.lastOPrice,a.lastOTaxPrice,sku.largeUrl,sku.middleUrl,sku.smallUrl,sku.littleUrl,sku.pkgUnit,
      sku.pkgRatio,sku.itemState,sku.isUnsalable,sku.isStop,sku.isVirtual,sku.inventoryMode,b.inputDate,b.productDate,
      b.expiryDate,b.batchNo,b.attribute01,b.attribute02,b.attribute03,b.attribute04,b.attribute05,sku.ownerId,
      o.partnerNo AS ownerNo,o.partnerName AS ownerName,o.shortName AS ownerShortName,sku.remarks
FROM dbo.IMS_Stock AS a 
      INNER JOIN dbo.BAS_Warehouse AS w ON a.warehouseId = w.warehouseId 
      INNER JOIN dbo.BAS_Goods_V AS sku ON a.itemId = sku.itemId 
      INNER JOIN dbo.BAS_Partner o ON sku.ownerId=o.partnerId
      LEFT JOIN dbo.BAS_Region AS r ON a.regionId = r.regionId 
      LEFT JOIN dbo.IMS_Batch b ON a.companyId=b.companyId AND a.lotNo=b.lotNo
go

