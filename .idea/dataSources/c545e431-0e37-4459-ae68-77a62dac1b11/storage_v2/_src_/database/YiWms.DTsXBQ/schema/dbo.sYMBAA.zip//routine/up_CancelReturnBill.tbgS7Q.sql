
-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2018-02-01>
-- Description:	<Description:取消误操作回单状态，返回到派件中>
-- Parameter:
--		@companyId:公司Id
--      @waybillId:出库单Id
--      @waybillNo: 出库单编号
--      @operatorId:操作员Id
-- =============================================

CREATE PROCEDURE [dbo].[up_CancelReturnBill] 
(
	@companyId VARCHAR(32),			--公司Id
    @waybillId VARCHAR(32),			--运单Id
    @waybillNo VARCHAR(32),			--运单号
	@operatorId VARCHAR(32)			--操作员Id
)
AS
BEGIN
	DECLARE @stockNo VARCHAR(32);
	BEGIN TRY
		BEGIN TRANSACTION
		--运单回单状态返回到派件中状态
		UPDATE dbo.TMS_WayBill SET billState=30 WHERE waybillId=@waybillId AND billState=99;
		IF (@@ROWCOUNT>0)
		BEGIN
			--查出库单No
			SELECT @stockNo=wmsStockNo FROM dbo.TMS_WayBill WHERE waybillId=@waybillId;
			--反馈出库单状态到已发货状态
			UPDATE dbo.SAD_Stock SET taskState=90 WHERE stockNo=@stockNo;
			--删除运单日志已回单记录
			DELETE FROM dbo.TMS_WaySite WHERE waybillId=@waybillId AND wayState=99;
		END
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        RAISERROR(@ErrMsg, @ErrSeverity, 1);			
	END CATCH
END
go

