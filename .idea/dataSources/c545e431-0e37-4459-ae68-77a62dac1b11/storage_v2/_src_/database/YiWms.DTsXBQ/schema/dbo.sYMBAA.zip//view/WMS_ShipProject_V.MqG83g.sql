

/*==============================================================*/
/* View: WMS_ShipProject_V                                      */
/*==============================================================*/
--90 项目单ShipType:0,不装车;1,货品;2,单据
CREATE view [dbo].[WMS_ShipProject_V] as
SELECT a.BillID AS billNo,a.BillNo AS stockBillNo,c.customerId,'' AS receiverState,
	'' AS receiverCity,'' AS receiverDistrict,a.SendAddr AS receiverAddress,ISNULL(a.LinkMan,c.LinkMan) AS receiverName,
	ISNULL(a.Phone,c.Phone) AS receiverTel,'' AS receiverMobile,0 AS pkgQty,0.0 AS fclQty,0.0 AS pkgVolumn,
	CASE a.ProjectXZID WHEN '1707' THEN 0 WHEN '1708' THEN 0 WHEN '1709' THEN 0 ELSE a.PartQty END AS lclQty,0.0 AS lclVolumn, 
	CASE a.ProjectXZID WHEN '1707' THEN 1 WHEN '1708' THEN 1 WHEN '1709' THEN 1 ELSE 0 END AS fileQty,a.CreateDate,0.0 AS netWeight,
	0.0 AS grossWeight,a.ProjectAmt AS TotalFee,a.BillNo AS mergeNo,90 AS billType,0 AS isInvalid,a.remarks,
    d.EmployeeName AS ServiceName,addr.viewOrder AS lineOrder 
FROM F10BMS.dbo.PRJ_Order a
	LEFT JOIN F10BMS.dbo.BDM_SendAddress addr ON a.CustID=addr.CustID AND a.SendAddr=addr.SendAddr AND a.LinkMan=addr.LinkMan
	INNER JOIN F10BMS.dbo.WMS_F10_Customer_V c ON a.CustID=c.CustID
	LEFT  JOIN F10BMS.dbo.BDM_Employee d ON a.CreatorID=d.EmployeeID
WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30')
	AND (ISNULL(a.CarNumberSts,'')='')
go

