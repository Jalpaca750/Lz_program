/*==============================================================*/
/* View: WMS_PickingQty_V                                       */
/*==============================================================*/
create view [dbo].[WMS_PickingQty_V] as
SELECT a.stockId,CASE a.isPackage WHEN 0 THEN a.pickQty WHEN 1 THEN a.realQty END AS actQty,
	CASE a.isPackage WHEN 0 THEN b.stockBox ELSE NULL END AS stockBox 
FROM dbo.WMS_PickingDetail a
    INNER JOIN dbo.WMS_PickingOrder b ON a.pickId=b.pickId
go

