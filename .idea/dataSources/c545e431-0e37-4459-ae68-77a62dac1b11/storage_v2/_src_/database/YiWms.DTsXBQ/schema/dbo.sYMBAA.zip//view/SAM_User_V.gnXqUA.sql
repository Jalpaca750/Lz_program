
/*==============================================================*/
/* View: SAM_User_V                                             */
/*==============================================================*/
--creator：     Frank
--create time:  2016-02-02整理
--modify: Frank 2016-09-23日整理
create view SAM_User_V as
SELECT u.userId,u.userNo,u.userNick,u.userPwd,u.userMail,u.userMobile,u.officeTel,u.userState,u.userType, 
	CASE u.userType WHEN 0 THEN '线下账号' WHEN 10 THEN '主账号' WHEN 11 THEN '子帐号' END AS userTypeName, 
	CASE u.userState WHEN 0 THEN '无效' WHEN 1 THEN '有效' END AS userStateName, u.companyId, c.companyNo, 
	c.companyName,u.isOnline,CASE u.isOnline WHEN 1 THEN '在线' ELSE '离线' END AS online,u.regionId,
	(SELECT r2.regionDesc + ';' FROM SAM_UserRegion r1 INNER JOIN BAS_Region r2 ON r1.regionId=r2.regionId WHERE r1.userId=u.userId FOR XML PATH('')) AS regionDesc,
	(SELECT r.roleName + ';' FROM SAM_UserRole ur INNER JOIN SAM_Role r ON ur.roleId=r.roleId WHERE ur.userId=u.userId FOR XML PATH('')) AS roles,
	u.isLocked,u.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),u.lockedTime,120) AS lockedTime,
	u.createTime,u.creatorId,u2.userNick AS creatorName,u.editTime,u.editorId,u3.userNick AS editorName,
	u.isSelected
FROM dbo.SAM_User AS u 
	INNER JOIN dbo.SAM_Company c ON u.companyId=c.companyId 
	LEFT JOIN dbo.SAM_User u1 ON u.lockerId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON u.creatorId =u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON u.editorId=u3.userId
go

