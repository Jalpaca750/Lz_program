
/*==============================================================*/
/* View: IMS_AdjustForPrint_V                                   */
/*==============================================================*/
create view IMS_AdjustForPrint_V as
SELECT a.adjustNo,a.adjustDate,c.companyNo,c.companyName,w.warehouseNo,w.warehouseName,a.billNo,a.createTime,
	d.deptNo,d.deptName,e.employeeName AS handlerName,tmp.ownerNo,tmp.ownerName,tmp.viewOrder,tmp.lotNo,
	tmp.locationNo,tmp.itemNo,tmp.itemName,tmp.itemSpec,tmp.barcode,tmp.midBarcode,tmp.bigBarcode,tmp.pkgBarcode,
	tmp.colorName,tmp.sizeName,tmp.unitName,tmp.ioQty,tmp.afterQty,tmp.onhandQty,tmp.pkgQty,tmp.bulkQty,
	tmp.inputDate,tmp.productDate,tmp.expiryDate,tmp.remarks,u1.userNick AS creatorName,ISNULL(a.printNum,0)+1 AS printNum,
	u2.userNick AS auditorName,a.auditTime,a.adjustReason,a.memo
FROM dbo.IMS_Adjust a 
	INNER JOIN dbo.SAM_Company c ON a.companyId=c.companyId
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	INNER JOIN(SELECT m.adjustNo,o.ownerNo,o.ownerName,m.viewOrder,m.lotNo,m.locationNo,n.itemNo,n.itemName,
					n.itemSpec,n.barcode,n.midBarcode,n.bigBarcode,n.pkgBarcode,n.colorName,n.sizeName,n.unitName,
					m.ioQty,m.pkgQty,m.bulkQty,m.afterQty,ISNULL(m.afterQty,0.0)-ISNULL(m.ioQty,0.0) AS onhandQty,
					m.remarks,p.inputDate,p.productDate,p.expiryDate
			   FROM dbo.IMS_AdjustDetail m 
					INNER JOIN dbo.BAS_Item n ON m.itemId=n.itemId 
					INNER JOIN dbo.BAS_Owner_V o ON m.ownerId=o.ownerId 
					LEFT JOIN dbo.IMS_Batch p ON m.companyId=p.companyId AND ISNULL(m.lotNo,'')=p.lotNo
			   ) tmp ON a.adjustNo=tmp.adjustNo 
	LEFT JOIN dbo.BAS_Department d ON a.deptId=d.deptId 
	LEFT JOIN dbo.BAS_Employee e ON a.handlerId=e.employeeId
	LEFT JOIN dbo.SAM_User u1 ON a.creatorId=u1.userId
	LEFT JOIN dbo.SAM_User u2 ON a.auditorId=u2.userId
go

