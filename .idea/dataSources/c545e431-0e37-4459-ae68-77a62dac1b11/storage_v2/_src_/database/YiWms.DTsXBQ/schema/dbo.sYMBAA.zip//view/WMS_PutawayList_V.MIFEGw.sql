
/*==============================================================*/
/* View: WMS_PutawayList_V                                      */
/*==============================================================*/
--creator：        Frank.He
--create time：    2016-11-30
--description:     建议上架清单打印报表
create view WMS_PutawayList_V as
SELECT t.flowId,t.stockId,a.stockNo,a.billNo,a.receiveDate,c.companyName,o.ownerNo,o.ownerName,
      o.shortName AS ownerShortName,s.partnerNo AS supplierNo,s.partnerName AS supplierName,s.shortName,
      w.warehouseNo,w.warehouseName,a.ioType,CASE a.ioType WHEN 'P100' THEN '采购入库单' 
                                                           WHEN 'D100' THEN '调拨入库单' 
                                                           WHEN 'G100' THEN '赠品入库单'
                                                           WHEN 'O200' THEN '其他入库单' END AS ioTypeDesc,
      dbo.uf_GetUpper(a.totalFee) AS upperRMB,a.postFee,a.deliveryNo,e1.employeeName AS buyerName,
      e2.employeeName AS handlerName,d.deptNo,d.deptName,e3.userNick AS receiverName,t.putawayName, 
      t.putawayTime,u1.userNick AS auditorName,CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,a.memo, 
      a.mergeNo,a.printNum,u5.userNick AS printMan,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,
      a.createTime,u2.userNick AS creatorName,t.itemNo,t.itemName,t.itemSpec,t.packageId,t.packageDesc,
      t.barcode,t.colorName,t.sizeName,t.unitName,t.pkgUnit,t.pkgRatio,t.putQty,t.realQty,t.regionNo,
      t.regionDesc,t.locationNo,t.lotNo,t.inputDate,t.putawayOrder,t.locationWay,t.locationRow,t.locationCol,
      t.locationLayer,t.unitLevel,ROW_NUMBER() OVER(PARTITION BY a.billNo,t.regionDesc ORDER BY a.billNo,t.putawayOrder) AS viewOrder
FROM dbo.PMS_Stock AS a 
      INNER JOIN dbo.SAM_Company AS c ON a.companyId = c.companyId 
      INNER JOIN dbo.BAS_Warehouse AS w ON a.warehouseId = w.warehouseId
      INNER JOIN dbo.BAS_Partner AS s ON a.supplierId = s.partnerId
      INNER JOIN (SELECT a.flowId,a.stockId,a.stockNo,loc.regionNo,loc.regionDesc,a.viewOrder,a.lotNo,a.locationNo,loc.locationWay,
                        loc.locationRow,loc.locationCol,loc.locationLayer,loc.putawayOrder,a.eId,a.itemId,bi.itemNo,bi.itemName,
                        bi.itemSpec,bi.itemSpell,bi.packageId,bi.colorName,bi.sizeName,bi.unitName,bi.pkgRatio,bi.pkgUnit,a.unitLevel,
                        a.putQty,CASE a.unitLevel WHEN 'CS' THEN a.putQty*a.pkgRatio WHEN 'EA' THEN a.putQty END AS realQty,
                        a.ioState,u1.userNick AS putawayName,CONVERT(VARCHAR(20),a.putawayTime,120) AS putawayTime,a.createTime,
                        b.inputDate,b.productDate,b.expiryDate,b.batchNo,b.attribute01,b.attribute02,b.attribute03,b.attribute04,
                        b.attribute05,CASE a.unitLevel WHEN 'CS' THEN '整箱' WHEN 'EA' THEN '散件' END AS packageDesc,bi.barcode
                  FROM dbo.WMS_PutawayDetail a 
                        INNER JOIN dbo.BAS_Item bi ON a.itemId=bi.itemId 
                        LEFT JOIN (SELECT x.companyId,x.warehouseId,x.locationWay,x.locationRow,x.locationLayer,x.putawayOrder,
                                         x.locationCol,x.locationNo,y.regionNo,y.regionDesc 
				                   FROM dbo.BAS_Location x LEFT JOIN
				                         dbo.BAS_Region y ON x.regionId=y.regionId
				                  ) loc ON a.companyId=loc.companyId AND a.warehouseId=loc.warehouseId AND a.locationNo=loc.locationNo
                        LEFT JOIN dbo.IMS_Batch b ON a.companyId=b.companyId AND a.lotNo=b.lotNo
                        LEFT JOIN dbo.SAM_User u1 ON a.putawayId=u1.userId
                  ) t ON a.stockNo=t.stockNo
      LEFT JOIN dbo.BAS_Owner_V AS o ON a.ownerId=o.ownerId
      LEFT JOIN dbo.BAS_Employee AS e1 ON a.buyerId = e1.employeeId
      LEFT JOIN dbo.BAS_Employee AS e2 ON a.handlerId = e2.employeeId 
      LEFT JOIN dbo.BAS_Department AS d ON a.deptId = d.deptId 
      LEFT JOIN dbo.SAM_User AS e3 ON a.receiverId = e3.userId 
      LEFT JOIN dbo.SAM_User AS u1 ON a.auditorId = u1.userId 
      LEFT JOIN dbo.SAM_User AS u2 ON a.creatorId = u2.userId 
      LEFT JOIN dbo.SAM_User AS u3 ON a.editorId = u3.userId 
      LEFT JOIN dbo.SAM_User AS u4 ON a.lockerId=u4.userId 
      LEFT JOIN dbo.SAM_User AS u5 ON a.printId=u5.userId
go

