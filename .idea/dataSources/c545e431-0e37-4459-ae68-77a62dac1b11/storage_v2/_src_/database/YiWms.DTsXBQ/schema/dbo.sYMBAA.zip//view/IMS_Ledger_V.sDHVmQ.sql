/*==============================================================*/
/* View: IMS_Ledger_V                                           */
/*==============================================================*/
--creator：        Frank
--create time：  2016-12-16日整理 
--modify: 2017-11-02 frank.He 重新整理
--仓库货物库存视图
create view IMS_Ledger_V as
SELECT a.ledgerId,a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,a.eId,a.itemId,sku.itemNo,sku.itemName,
      sku.itemCTitle,sku.itemETitle,sku.sellingPoint,sku.itemSpell,sku.itemSpec,sku.barcode,sku.midBarcode,
      sku.bigBarcode,sku.pkgBarcode,sku.categoryId,sku.categoryNo,sku.categoryCName,sku.brandId,sku.brandNo,
      sku.brandCName,sku.colorName,sku.sizeName,sku.unitName,sku.packageId,sku.pkgUnit,sku.pkgRatio,sku.eaMaxQty,
      sku.eaMinQty,sku.inventoryMode,sku.isIrregular,sku.isSafety,sku.safetyMonth,sku.safetyDays,a.onhandQty,
      a.allocQty,CASE ISNULL(sku.pkgRatio,0) WHEN 0 THEN 0.0 ELSE FLOOR(ISNULL(a.onhandQty,0.0)/sku.pkgRatio) END pkgQty,
      CASE ISNULL(sku.pkgRatio,0) WHEN 0 THEN ISNULL(a.onhandQty,0.0) ELSE ISNULL(a.onhandQty,0.0) % sku.pkgRatio END bulkQty,
      sku.ownerId,o.partnerNo AS ownerNo,o.partnerName AS ownerName,o.shortName AS ownerShortName,a.price,a.taxrate,a.taxPrice,
      a.fee,a.totalFee,a.maxDays,a.minDays,a.maxQty,a.minQty,a.stabilityRate,CONVERT(VARCHAR(20),a.lastITime,120) AS lastITime,
      a.lastIPrice,a.lastITaxPrice,CONVERT(VARCHAR(20),a.lastOTime,120) AS lastOTime,a.lastOPrice,a.lastOTaxPrice,
      sku.itemState,CASE sku.itemState WHEN 0 THEN '失效' WHEN 1 THEN '有效' END AS itemStateDesc  
FROM dbo.IMS_Ledger a
      INNER JOIN dbo.BAS_Goods_V sku ON a.itemId=sku.itemId
      INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
      INNER JOIN dbo.BAS_Partner o ON sku.ownerId=o.partnerId
go

