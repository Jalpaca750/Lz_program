



-- =============================================
-- Author:		<zdy>
-- Create date: <2017-04-18 13:15>
-- Description:	<描述>
-- =============================================
CREATE PROCEDURE [dbo].[Pda_Proc_PkgPickingItem](@pickingNo varchar(32),@operatorId varchar(32))
AS
declare @eid varchar(32)=''
declare @stockid  varchar(32)='' --库存ID
declare @pickingbillno varchar(100)=''--拣货单号
declare @companyId varchar(32)=''
declare @warehouseId varchar(32)='' ---仓库
declare @itemId  varchar(32)=''     --商品的ID
declare @regionid varchar(32)=''    --区域
declare @stockQty decimal(20,6)=0   --库存的数量
declare @locationNo varchar(40)=''  --货位
declare @lotNo varchar(40)=''       --批次
declare @errorCount int=0 ---错误计数器
declare @sad_stockNo  varchar(32)='' --出库单号
declare @result_code int 
declare @isPackage int=0 --是否是整包装
declare @pickingId varchar(32)=''
declare @qty decimal(20,6)  --散件数量
declare @FCL_CHECK varchar(100)='0'
declare @bef_qty decimal(20,6)
declare @stock_qty decimal(20,6)
BEGIN TRAN  --开始事务

--=========================定义游标


DECLARE @book_StockNo varchar(32)
DECLARE @book_BillNo varchar(32)
DECLARE @book_StockId varchar(32),@_TYPE varchar(32)='S100',@taskType int=1
---如果是补货
IF EXISTS(SELECT PICKINGNO FROM WMS_PICKING WHERE PICKINGNO=@pickingNo AND TASKTYPE=2)
		BEGIN
		    SET @_TYPE='B200'
		    SET @taskType=2 --补货任务
		END

IF EXISTS(SELECT  pickingNo FROM  WMS_Picking  WHERE pickingNo=@pickingNo AND taskState>1)
BEGIN
         SET @errorCount=1
END
ELSE
BEGIN
  
    
--取pickingno
select @pickingbillno=billNo,@companyId=companyId 
from WMS_Picking where pickingNo=@pickingNo
---是否开启整箱验货功能   1 开启  0 关闭
select @FCL_CHECK=configValue from  SAM_Config 
where companyId=@companyId and configCode='FCL_CHECK'
--
--
--
DECLARE   SMyCursor  cursor  FOR
SELECT pickingId,companyId,warehouseId,itemId,isnull(regionId,'') regionId,
realQty,
stockQty,stockNo,isPackage,isnull(locationNo,'') locationNo, 
isnull(batchNo,'') lotNo
FROM  WMS_PICKINGDETAIL 
where pickingNo=@pickingNo and pickstate=1
for read only
--
--
--
OPEN  SMyCursor ---打开游标
Fetch  NEXT  FROM SMyCursor  into @pickingId,  
@companyId,@warehouseId,@itemId,@regionid,@qty,@stockQty,
@sad_stockNo,@isPackage,@locationNo,@lotNo
WHILE @@fetch_status=0 
BEGIN  
/**************************************************************************************************/
					select 					
					@book_BillNo=stockBillNo,@book_StockId=stockId,@book_StockNo=stockNo
					from  WMS_PickingDetail_V where pickingId=@pickingId
					--实际库存
					select  @eid=eId , @stockid=stockid, @stockQty=isnull(onhandQty,0) from IMS_Stock 
					where companyId=@companyId and
					warehouseId=@warehouseId and isnull(regionId,'')=@regionid 
					and  itemId=@itemId and locationNo=@locationNo and lotNo=@lotNo
					--==================================================================================================
					--开始库存数量的计算
					--==================================================================================================
					--修改拣货的状态
					Update   WMS_PickingDetail  set pickState=2 where pickingId=@pickingId  and  pickState<2
					if @@ROWCOUNT=0 
					begin
					  set @errorCount=1
					    CLOSE SMyCursor
						Deallocate SMyCursor
					  rollback 
					  return
					end
					set @errorCount+=@@ERROR
					--修改库存 
					print '数量'+cast(@qty as varchar(32))
					update  IMS_Stock set 
					onhandQty=onhandQty-@qty,
					allocQty=(allocQty-@qty) ,--占用量不能被扣为负数
					lastOTime=GETDATE() 
					where stockId=@stockid
					set @errorCount+=@@ERROR
					--修改总库存
					
					IF @taskType=2 
					BEGIN
						update  IMS_Ledger set onhandQty=onhandQty-@qty
						,lastOTime=GETDATE() 
						where companyId=@companyId and warehouseId=@warehouseId and itemId=@itemId
						set @errorCount+=@@ERROR
					END ELSE BEGIN
					    update  IMS_Ledger set onhandQty=onhandQty-@qty,
						allocQty=(allocQty-@qty)
						,lastOTime=GETDATE() 
						where companyId=@companyId and warehouseId=@warehouseId and itemId=@itemId
						set @errorCount+=@@ERROR
					END
					
					---累加出库单拣货数量
					select @bef_qty=ISNULL(pickQty,0.0),@stock_qty=ISNULL(stockQty,0.0) from SAD_StockDetail 
					where stockId=@book_StockId;
					 UPDATE  SAD_StockDetail SET pickQty=ISNULL(pickQty,0)+@qty WHERE stockId=@book_StockId
					set @errorCount+=@@ERROR
					
					---写入流水账
					INSERT INTO IMS_Book(
					[bookId],[ioType],[companyId],[billId],[billNo],[billCode],[objectId],[warehouseId],
					[lotNo],[locationNo],[eId],[itemId],[befQty],[taxFlag],
					[discount],[discountFee],[ioQty],[price],[fee],[taxFee],
					[afterQty],[handlerId],[deptId],[createTime],
					[creatorId],[auditorId],[auditTime],[memo])
					values(REPLACE(NEWID(),'-',''),@_TYPE,@companyId,@book_StockId,@book_StockNo,@book_BillNo,@book_StockId,@warehouseId,
					@lotNo,@locationNo,@eid,@itemId,@stockQty,null,null,null,-@qty,null,null,null,
					(@stockQty-@qty),null,null,GETDATE(),@operatorId,'',GETDATE(),'')
					set @errorCount+=@@ERROR

					------更新出库单审核状态
					declare @_st_Count int=0;
					declare @_st_had_Count int=-1;
					--======================================================================================
					--出库单、库存计算
					--=======================================================================================
					---计算出出库单的拣货任务
					select @_st_Count=COUNT(1) from WMS_PickingDetail 
					where  stockNo=@sad_stockNo and stockQty>0  and len(locationNo)>0
					---拣过的 
					select @_st_had_Count=COUNT(1) from WMS_PickingDetail
					where stockNo=@sad_stockNo  and stockQty>0 and pickState<2 and len(locationNo)>0
					----判断是不是拣货完成了
					--if @_st_had_Count=0
					--begin
					
					
					--end
					Fetch  NEXT  FROM SMyCursor  into @pickingId,  
@companyId,@warehouseId,@itemId,@regionid,@qty,@stockQty,
@sad_stockNo,@isPackage,@locationNo,@lotNo
END

/**************************************************************************************************/

CLOSE SMyCursor
Deallocate SMyCursor
--================================================================
-- 给参数赋值

--================================================================
--========================如果拣货全部完成了=========================================================
declare @IS_ALL int=0
select @IS_ALL=COUNT(1) from  WMS_PickingDetail 
where pickingNo=@pickingNo and pickState<2  and stockQty>0 and len(locationNo)>0
if @IS_ALL=0
begin
		UPDATE  WMS_Picking  set taskState=2 WHERE   pickingNo=@pickingNo;
		set @errorCount+=@@ERROR
		---修改拣货箱子的单号的状态为完成
		UPDATE  WMS_PickingOrder SET taskState=2,pickTime=GETDATE() WHERE pickingNo=@pickingNo;
		set @errorCount+=@@ERROR
		----修改详细状态
		UPDATE  WMS_PickingDetail SET pickState=2 WHERE  pickingNo=@pickingNo and  pickState<2;
		set @errorCount+=@@ERROR
		---把那些整箱的直接搞成完成把
		IF EXISTS(SELECT pickingNo FROM WMS_Picking WHERE pickingNo=@pickingNo AND taskType=1) 
		BEGIN  --如果没有开启整箱验货功能 或者有免打印的
		    IF ISNULL(@FCL_CHECK,'0')='0' OR  EXISTS(SELECT pickingId FROM WMS_PickingDetail WHERE pickingNo=@pickingNo AND printNum=-1)
		    BEGIN 
				UPDATE  WMS_PickingOrder SET taskState=4 WHERE pickingNo=@pickingNo;
				set @errorCount+=@@ERROR
				UPDATE WMS_Picking SET taskState=9 where pickingNo=@pickingNo;
				set @errorCount+=@@ERROR
			END
		END 
		----如果是补货任务的货 完成后更新补货计划的数据
		IF EXISTS(SELECT PICKINGNO FROM WMS_PICKING WHERE PICKINGNO=@PICKINGNO AND TASKTYPE=2)
		BEGIN
		UPDATE  WMS_PickingOrder SET taskState=4 WHERE pickingNo=@pickingNo;
		set @errorCount+=@@ERROR
		UPDATE  IMS_REPLENISH  SET   IOSTATE=20,pickerId=@operatorId,pickingTime=GETDATE(),putawayId=@operatorId,putawayTime=GETDATE() 
		WHERE REPLENISHID IN (SELECT STOCKNO FROM WMS_PICKINGORDER WHERE PICKINGNO=@PICKINGNO)   
		END
end

if not exists(select 1 from WMS_PickingOrder where  stockNo=@sad_stockNo  and taskState<4)
begin
	---更新出库单的状态 审核人--直接更新成60
	update  SAD_Stock set  taskState=70,auditorId=@operatorId,auditTime=GETDATE()
	where stockNo=@sad_stockNo
	set @errorCount+=@@ERROR
end
--===================================================================================================
 --------------------------
END

if @errorCount<>0
begin
 print  '返回'
 select -1 resultcode
 rollback;
end
else  begin
select 1 resultcode
commit;
end 









go

