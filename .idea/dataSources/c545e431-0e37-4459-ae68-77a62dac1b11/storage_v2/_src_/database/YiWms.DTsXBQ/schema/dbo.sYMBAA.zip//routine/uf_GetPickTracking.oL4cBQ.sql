-- =============================================
-- Author:		<Frank.He>
-- Create date: <2017-04-17>
-- Description:	<分拣任务跟踪分析>
-- =============================================
CREATE FUNCTION [dbo].[uf_GetPickTracking] 
(
	@companyId VARCHAR(32)
)
RETURNS TABLE
RETURN(
	SELECT a.pickId,a.pickingNo,b.billNo AS pickBillNo,b.warehouseId,w.warehouseNo,w.warehouseName,b.regionId,
		r.regionNo,r.regionDesc,a.boxBillNum,a.stockNo,a.stockBillNo,c.mergeNo,a.companyId,b.waveNo,b.waveBillNo,
		c.customerId,c.customerNo,c.customerName,c.customerSpell,c.shortName,a.boxId,d.boxCode,a.stockBox,
		a.boxOrder,1 AS boxes,t2.totalVolume,t2.totalWeight,
		a.isPackage,CASE a.isPackage WHEN 1 THEN '整箱' ELSE '散件' END As isPackageDesc,
		a.taskState,CASE a.taskState WHEN 0 THEN '待领取'
									WHEN 1 THEN '待拣货'
									WHEN 2 THEN CASE b.taskType WHEN 2 THEN '待上架' ELSE '待复核' END
									WHEN 3 THEN '待打包'
									WHEN 4 THEN '待装车'
									WHEN 5 THEN '待发货'
									WHEN 6 THEN CASE b.taskType WHEN 2 THEN '已上架' ELSE '已发货' END END AS stateName,
		a.pkgQty,a.lclQty,CONVERT(VARCHAR(20),b.getTime,120) AS getTime,a.lineId,b.taskType,
		CASE b.taskType WHEN 0 THEN '散件' WHEN 1 THEN '整箱' WHEN 2 THEN '补货' END AS taskTypeDesc,   
		a.pickerId,u1.userNick AS pickerName,CONVERT(VARCHAR(20),a.pickTime,120) AS pickTime,
		a.checkerId,u2.userNick AS checkerName,CONVERT(VARCHAR(20),a.checkTime,120) AS checkTime,
		a.packingId,u3.userNick AS packingName,CONVERT(VARCHAR(20),a.packingTime,120) AS packingTime,
		a.loadingId,u4.userNick AS loadingName,CONVERT(VARCHAR(20),a.loadingTime,120) AS loadingTime,
		b.createTime,c.organizeId,t1.skuCount,t1.itemCount,t1.locCount
	FROM dbo.WMS_PickingOrder a 
		INNER JOIN dbo.WMS_Picking b ON a.pickingNo=b.pickingNo 
		INNER JOIN (SELECT pickingNo,COUNT(1) AS skuCount,COUNT(DISTINCT itemId) AS itemCount,COUNT(DISTINCT locationNo) AS locCount
					FROM dbo.WMS_PickingDetail 
					GROUP BY pickingNo) t1 ON b.pickingNo=t1.pickingNo
		INNER JOIN (SELECT a1.pickId,SUM(CASE a1.isPackage WHEN 0 THEN a1.pickQty*a2.itemWeight ELSE a1.pickQty*a2.pkgWeight END) AS totalWeight,
		                SUM(CASE a1.isPackage WHEN 0 THEN a1.pickQty*a2.itemVolume ELSE a1.pickQty*a2.pkgVolume END) AS totalVolume
					FROM dbo.WMS_PickingDetail a1
					    INNER JOIN dbo.BAS_Item a2 ON a1.itemId=a2.itemId
					GROUP BY a1.pickId) t2 ON a.pickId=t2.pickId
		INNER JOIN dbo.BAS_Warehouse w ON b.warehouseId=w.warehouseId 
		INNER JOIN dbo.BAS_Region r ON b.regionId=r.regionId 
		LEFT  JOIN (
					SELECT m.stockNO,m.customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,
						p.shortName,p.partnerSpell AS customerSpell,m.mergeNo,m.organizeId
					FROM dbo.SAD_Stock m 
						INNER JOIN dbo.BAS_Partner p ON m.customerId=p.partnerId
					) c ON a.stockNo=c.stockNo
    	LEFT JOIN dbo.WMS_Box d ON a.boxId=d.boxId 
    	LEFT JOIN dbo.SAM_User u1 ON a.pickerId=u1.userId 
    	LEFT JOIN dbo.SAM_User u2 ON a.checkerId=u2.userId 
    	LEFT JOIN dbo.SAM_User u3 ON a.packingId=u3.userId 
    	LEFT JOIN dbo.SAM_User u4 ON a.loadingId=u4.userId
	WHERE a.companyId=@companyId    
)

go

