


-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-02-06>
-- Description:	<Description:库存调整单审核>                         
--  操作影响商品库存(BAS_Item表onhandQty)
--          仓库库存(IMS_Ledger表的onhandQty)，成本处理忽略不计
--          库位库存(IMS_Stock表) 
--          入出库流水帐(IMS_Book)
-- review ------------V1.2------------
-- Frank 2017-11-08 增加单据类型后修改审核过程
-- =============================================
CREATE PROCEDURE [dbo].[up_Audit_InvAdjust]
(
    @adjustNo VARCHAR(32),		--调整单单号
	@operatorId VARCHAR(32)		--操作员
)
AS
BEGIN	
	DECLARE @companyId VARCHAR(32),			--公司Id
			@warehouseId VARCHAR(32),		--仓库Id
			@ownerId VARCHAR(32),			--业主Id
			@billType INT,					--单据类型:10-盘亏调整单;11-盘盈调整单;20-手工调亏单;21-手工调盈单
			@billCode VARCHAR(100),			--编码
			@handlerId VARCHAR(32),			--经办人
			@deptId VARCHAR(32),			--部门
			@auditTime DATETIME=GETDATE(),  --审核时间
			@creatorId VARCHAR(32),			--操作员Id
			@createTime DATETIME,			--创建时间
			@memo VARCHAR(2000)				--主表备注			
	DECLARE @befQty DECIMAL(20,6)			--调整前库存
	DECLARE  @adjustId VARCHAR(32),		 
			 @lotNo   VARCHAR(32),
			 @locationNo VARCHAR(32),
			 @eId   VARCHAR(32),
			 @itemId  VARCHAR(32),
			 @ioQty   DECIMAL(20,6),
			 @pkgQty  DECIMAL(20,6),
			 @bulkQty  DECIMAL(20,6),
			 @fee      DECIMAL(20,10),
			 @totalFee DECIMAL(20,10),
			 @remarks  VARCHAR(200),
			 @regionId VARCHAR(32)
	--定义游标
	DECLARE myCursor CURSOR 
	FOR SELECT adjustId,ownerId,lotNo,locationNo,eId,itemId,ioQty,pkgQty,bulkQty,remarks
		FROM dbo.IMS_AdjustDetail 
		WHERE adjustNo=@adjustNo 
		ORDER BY viewOrder 
	FOR READ ONLY;		
	--获取操作员所在的公司Id
	SELECT @companyId=companyId FROM dbo.SAM_User WHERE userId=@operatorId; 
	--删除操作员当前操作的错误信息
	DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='up_Audit_InvAdjust' AND creatorId=@operatorId;
	BEGIN TRY
		--事务开始
		BEGIN TRANSACTION	
		--单据被删除，则直接退出
		IF NOT EXISTS(SELECT 1 FROM dbo.IMS_Adjust WHERE adjustNo=@adjustNo)
		BEGIN
			--库位编码错误则返回提醒
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_Audit_InvAdjust','YI_INV_ADJUST_WAS_DELETED','库存调整单被他人删除，操作无效！',@adjustNo,@adjustNo);
			COMMIT;
			RETURN;
		END
		--取得主表字段
		SELECT @billCode=billNo,@companyId=companyId,@warehouseId=warehouseId,@handlerId=handlerId,
			@creatorId=creatorId,@createTime=createTime,@billType=billType,@memo=memo
		FROM dbo.IMS_Adjust
		WHERE adjustNo=@adjustNo;	
		--单据被他人审核或者作废：0-已作废；10-待审核;20-已审核
		IF EXISTS(SELECT 1 FROM dbo.IMS_Adjust WHERE adjustNo=@adjustNo AND ioState=20)
		BEGIN
			--库位编码错误则返回提醒
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_Audit_InvAdjust','YI_INV_ADJUST_WAS_AUDITED','库存调整单已审核，操作无效！',@adjustNo,@billCode);
			COMMIT;
			RETURN;
		END
		--单据被他人审核或者作废
		IF EXISTS(SELECT 1 FROM dbo.IMS_Adjust WHERE adjustNo=@adjustNo AND ioState=0)
		BEGIN
			--库位编码错误则返回提醒
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_Audit_InvAdjust','YI_INV_ADJUST_WAS_CLOSED','库存调整单已作废，操作无效！',@adjustNo,@billCode);
			COMMIT;
			RETURN;
		END
		--库位编码错误则返回提醒
		IF EXISTS(SELECT 1 FROM dbo.IMS_AdjustDetail a WHERE a.adjustNo=@adjustNo AND NOT EXISTS(SELECT 1 FROM dbo.BAS_Location b WHERE a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo))
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_Audit_InvAdjust','YI_INV_ADJUST_LOCATION_ERROR','库位编码输入错误，请重新输入！',@adjustNo,@billCode);
			COMMIT;
			RETURN;
		END
		--更新状态
		UPDATE IMS_Adjust SET ioState=20,auditTime=@auditTime,auditorId=@operatorId,editTime=@auditTime,editorId=@operatorId WHERE adjustNo=@adjustNo;
		--打开游标
        OPEN myCursor 
		FETCH NEXT FROM myCursor INTO @adjustId,@ownerId,@lotNo,@locationNo,@eId,@itemId,@ioQty,@pkgQty,@bulkQty,@remarks
		WHILE @@fetch_status=0 
		BEGIN  
			--更新库存总量
			UPDATE BAS_Item SET onhandQty=ISNULL(onhandQty,0.0)+ISNULL(@ioQty,0.0) WHERE itemId=@itemId;
			--仓库总账	
			IF EXISTS(SELECT 1 FROM IMS_Ledger WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId)
			BEGIN
				IF (@billType=10 OR @billType=20)
					UPDATE IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty,lastOTime=@auditTime
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
				ELSE
					UPDATE IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty,lastITime=@auditTime
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
			END
			ELSE
			BEGIN
				IF (@billType=10 OR @billType=20)
					INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastOTime)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@eId,@itemId,@ioQty,0.0,@auditTime);
				ELSE
					INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastITime)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@eId,@itemId,@ioQty,0.0,@auditTime);
			END
			--库位批次明细帐
			--取得库区
			SELECT @regionId=ISNULL(regionId,'') 
			FROM dbo.BAS_Location  
			WHERE warehouseId=@warehouseId AND locationNo=@locationNo;			
			IF EXISTS(SELECT 1 FROM IMS_Stock WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId)
			BEGIN
				--入出库(调整)前库存
				SELECT @befQty=onhandQty
				FROM dbo.IMS_Stock
				WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId;
				IF (@billType=10 OR @billType=20)
					UPDATE dbo.IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty,lastOTime=@auditTime
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId;
				ELSE
					UPDATE dbo.IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty,lastITime=@auditTime
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId;
			END
			ELSE
			BEGIN
				---如果库里面没有 进行插入
				SELECT @befQty=0.0;
				IF (@billType=10 OR @billType=20)
					INSERT INTO dbo.IMS_Stock(stockId,companyId,warehouseId,regionId,lotNo,locationNo,eId,itemId,onhandQty,allocQty,lastOTime)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@regionId,@lotNo,@locationNo,@eId,@itemId,@ioQty,0.0,@auditTime);
				ELSE
					INSERT INTO dbo.IMS_Stock(stockId,companyId,warehouseId,regionId,lotNo,locationNo,eId,itemId,onhandQty,allocQty,lastITime)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@regionId,@lotNo,@locationNo,@eId,@itemId,@ioQty,0.0,@auditTime);
			END
			--处理IMS_Book表
			INSERT INTO IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,
				eId,itemId,befQty,ioQty,afterQty,handlerId,deptId,createTime,creatorId,auditTime,auditorId,memo)
			VALUES(REPLACE(NEWID(),'-',''),'T100',@companyId,@adjustId,@adjustNo,@billCode,'',@warehouseId,ISNULL(@lotNo,''),
				ISNULL(@locationNo,''),@eId,@itemId,@befQty,@ioQty,ISNULL(@befQty,0.0)+ISNULL(@ioQty,0.0),@handlerId,
				@deptId,@createTime,@creatorId,@auditTime,@operatorId,@memo);
			FETCH NEXT FROM myCursor INTO @adjustId,@ownerId,@lotNo,@locationNo,@eId,@itemId,@ioQty,@pkgQty,@bulkQty,@remarks
		END   
		CLOSE myCursor
		Deallocate myCursor
		COMMIT
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_Audit_InvAdjust','YI_INV_ADJUST_ERROR',LEFT(@ErrMsg,2000),@adjustNo,@billCode);
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END CATCH
END
go

