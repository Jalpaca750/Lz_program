
--creator：        Frank
--create time：  2016-09-18
--大写转换（网）

CREATE FUNCTION dbo.uf_GetUpper
(
	@lowerMoney DECIMAL(20,10)
)  
RETURNS VARCHAR(200)   
AS      
BEGIN      
	DECLARE @lowerStr varchar(200)      
	DECLARE @UpperStr varchar(200)      
	DECLARE @UpperPart varchar(200)     --长度      
	DECLARE @i int       
        
	SET @lowerStr=LTRIM(RTRIM(CONVERT(DECIMAL(18,2),ROUND(@LowerMoney,2))))      
	SET @i=1      
	SET @UpperStr=''      
        
	WHILE(@i<=len(@lowerStr))      
	BEGIN      
		SELECT @UpperPart=
			CASE SUBSTRING(@lowerStr,LEN(@lowerStr)-@i+1,1)--取最后一位数  
				WHEN  '.' THEN '元'      
				WHEN  '0' THEN '零'      
				WHEN  '1' THEN '壹'      
				WHEN  '2' THEN '贰'      
				WHEN  '3' THEN '叁'      
				WHEN  '4' THEN '肆'      
				WHEN  '5' THEN '伍'      
				WHEN  '6' THEN '陆'      
				WHEN  '7' THEN '柒'      
				WHEN  '8' THEN '捌'      
				WHEN  '9' THEN '玖'      
			END      
        +      
			CASE @i       
				WHEN 1 THEN  '分'      
				WHEN 2 THEN  '角'      
				WHEN 3 THEN  ''      
				WHEN 4 THEN  ''      
				WHEN 5 THEN  '拾'      
				WHEN 6 THEN  '佰'      
				WHEN 7 THEN  '仟'      
				WHEN 8 THEN  '万'      
				WHEN 9 THEN  '拾'      
				WHEN 10 THEN '佰'      
				WHEN 11 THEN '仟'      
				WHEN 12 THEN '亿'      
				WHEN 13 THEN '拾'      
				WHEN 14 THEN '佰'      
				WHEN 15 THEN '仟'      
				WHEN 16 THEN '万'      
				ELSE ''      
			END      
			SET @UpperStr=@UpperPart + @UpperStr      
			SET @i=@i + 1      
	END       
	SET @UpperStr = REPLACE(@UpperStr,'零拾','零')       
	SET @UpperStr = REPLACE(@UpperStr,'零佰','零')       
	SET @UpperStr = REPLACE(@UpperStr,'零仟零佰零拾','零')       
	SET @UpperStr  = REPLACE(@UpperStr,'零仟','零')      
	SET @UpperStr = REPLACE(@UpperStr,'零零零','零')      
	SET @UpperStr = REPLACE(@UpperStr,'零零','零')      
	SET @UpperStr = REPLACE(@UpperStr,'零角零分','')      
	SET @UpperStr = REPLACE(@UpperStr,'零分','')      
	SET @UpperStr = REPLACE(@UpperStr,'零角','零')      
	SET @UpperStr = REPLACE(@UpperStr,'零亿零万零元','亿元')      
	SET @UpperStr = REPLACE(@UpperStr,'亿零万零元','亿元')      
	SET @UpperStr = REPLACE(@UpperStr,'零亿零万','亿')      
	SET @UpperStr = REPLACE(@UpperStr,'零万零元','万元')      
	SET @UpperStr = REPLACE(@UpperStr,'万零元','万元')      
    SET @UpperStr = REPLACE(@UpperStr,'零亿','亿')      
    SET @UpperStr = REPLACE(@UpperStr,'零万','万')      
    SET @UpperStr = REPLACE(@UpperStr,'零元','元')      
    SET @UpperStr = REPLACE(@UpperStr,'零零','零')      
    IF LEFT(@UpperStr,1)='元'      
        SET @UpperStr = REPLACE(@UpperStr,'元','零元')      
  
	RETURN @UpperStr + '整'      
END  
go

