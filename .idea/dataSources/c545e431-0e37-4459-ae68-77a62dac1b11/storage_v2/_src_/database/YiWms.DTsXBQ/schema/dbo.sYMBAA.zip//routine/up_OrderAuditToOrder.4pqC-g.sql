-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-08-20>
-- Description:	<Description:审核订单，并生成库位数量预分配与补货临时表（预分配算法）>
-- 依赖：
--      分配策略对应函数(uf_GetPickLocation)
--      上架策略对应函数(uf_GetPutawayLocation)
--      临时分配表WMS_Allocate     
--      临时补货表WMS_Allocate
--      预分配完毕后通过预分配表生成出库表数据   
--      Frank.He 2017-12-01 取消了预分配算法，并处理厂商直送订单(自动扣库) review V1.2.1    
--      Frank.He 2017-12-14 对送货线路的判断增加了自动处理限制，并同意officemate版本 review V1.2.2 
-- =============================================
CREATE PROCEDURE [dbo].[up_OrderAuditToOrder]
(
	@orderNo VARCHAR(32),
	@companyId VARCHAR(32),			--公司Id
	@creatorId VARCHAR(32)			--操作员
)
AS
BEGIN
	DECLARE @orderId VARCHAR(32),				--订单明细Id
			@orderBillNo VARCHAR(32),			--订单编号
			@viewOrder INT,						--序号
			@warehouseId VARCHAR(32),			--仓库Id
			@ownerId VARCHAR(32),				--业主Id
			@lineId VARCHAR(32),				--送货线路
			@eId VARCHAR(32),					--主商品Id
			@itemId VARCHAR(32),				--产品Id
			@itemNo VARCHAR(32),				--商品编码
			@stockQty DECIMAL(20,6),			--出库单（订单）数量
			@befQty DECIMAL(20,6),				--出库前数量
			@pkgRatio INT,						--包装数量
			@itemVolume DECIMAL(20,3),			--散件体积
			@itemWeight DECIMAL(10,4),			--散件重量
			@allowSplit INT,					--允许单条拆单	0,不拼箱;1,拼箱;2,自拼箱	
			@splitRatio INT,					--自拼箱数量	
			@printNum INT,						--打印控制
			@handleId VARCHAR(32),				--经手人Id
			@deptId VARCHAR(32),				--部门Id
			@memo VARCHAR(2000);				--备注				
	DECLARE	@createTime DATETIME,				--创建时间
			@availQty DECIMAL(20,6),			--库存可用量
			@bulkQty DECIMAL(20,6),				--散件数量	
			@pkgQty DECIMAL(20,6),				--整箱数量			
			@totalQty DECIMAL(20,6),			--临时总数量
			@pickQty DECIMAL(20,6),				--临时分拣数量
			@needQty DECIMAL(20,6),				--实际需要的补货数量
			@bhQty DECIMAL(20,6);				--补货数量
	DECLARE	@replenishId VARCHAR(32),
			@replenishBillNo VARCHAR(32),		--补货单编号
			@regionId VARCHAR(32),				--库区Id
			@lotNo VARCHAR(32),					--批次编号
			@locationNo VARCHAR(32),			--库位编号
			@fromLocation VARCHAR(32),			--补货下架库位编号
			@fromRegion	VARCHAR(32),			--补货下架库区
			@errorMsg VARCHAR(2000),			--错误消息
			@pickOrder INT,						--临时表@tmpPick主键Id
			@replenishQty DECIMAL(20,6);		--补货数量
	DECLARE @stockId VARCHAR(32),				--出库单明细Id
			@stockNo VARCHAR(32),				--出库单编号
			@stockBillNo VARCHAR(32),			--出库单号
			@ioType VARCHAR(32),				--入出库类型
			@aFlag INT,							--A单标识:
			@sdState INT,						--订单状态:0-关闭交易;10-待审核;15,部分审核;20,已审核;25-部分下达;30-已下达
			@taskState INT,						--任务状态：20-审核，30-已排车（已排线）；70-已打包
			@isTogether INT;					--发货方式：1-货齐一起送;0-有货先送						
	DECLARE @preAllocate VARCHAR(100),			--1-启动预分配算法，0，正常生成出库单
			@orderDealMode VARCHAR(100),		--0,提示用户自行处理;1,按实际库存红冲下单	
			@orderShipTime VARCHAR(100),		--1,波次计划前装车;2-打包完成后装车		
			@orderAutoCheck VARCHAR(100),		--1,自动审核；0-手工审核
			@tmplocation VARCHAR(32);			--直送订单临时库位（直送订单对应F10需要扣减库存）
	SET @createTime=GETDATE();				
	--清除错误日志
	DELETE FROM SAM_Error WHERE companyId=@companyId AND funCode='up_OrderAuditToOrder' AND creatorId=@creatorId;
	--获取系统参数
	SELECT @preAllocate=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='ORDER_AUDIT_PRE_ALLOCATE';
	--装车时机：1,波次计划前装车;2-打包完成后装车
	SELECT @orderShipTime=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='ORDER_SHIP_TIME';
	--订单处理模式（库存不足）0,提示用户自行处理;1,按实际库存红冲下单
	SELECT @orderDealMode=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='ORDER_AUDIT_DEAL_WITH_MODE';
	--直送订单临时库位（直送订单对应F10需要扣减库存）
	SELECT @tmplocation=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='FACTORY_DELIVERY_ORDER_LOCATION';
	--开启订单自动审核功能1,开启自动审核；0-手工审核
	SELECT @orderAutoCheck=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='SALES_ORDER_AUTO_CHECK';
	SET @preAllocate=ISNULL(@preAllocate,'0');
	SET @orderDealMode=ISNULL(@orderDealMode,'0');
	SET @orderShipTime=ISNULL(@orderShipTime,'1');
	SET @tmplocation=ISNULL(@tmplocation,'');
	SET @orderAutoCheck=ISNULL(@orderAutoCheck,0);
	BEGIN TRY
		BEGIN TRANSACTION
		--订单不存在
		IF NOT EXISTS(SELECT 1 FROM dbo.SAD_Order WHERE orderNo=@orderNo)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_NOT_EXISTS','订单已取消，操作无效!',@orderNo,@orderNo);
			COMMIT;
			RETURN;
		END
		--订单编号
		--orderType:10-销售订单;20调拨订单 对应 S100-销售出库单;D200-调拨出库单;L100-领用出库单;G200-赠品出库单;B200-报损报废;O100-其他出库单
		SELECT @orderBillNo=billNo,@ioType=CASE orderType WHEN 10 THEN 'S100' 
														  WHEN 20 THEN 'D200' 
														  WHEN 30 THEN 'L100' 
														  WHEN 31 THEN 'L100' 
														  WHEN 32 THEN 'O100' 
														  WHEN 40 THEN 'G200' 
														  WHEN 50 THEN 'B200' END,
			--波次计划前装车，任务状态为20-待装车；打包完装车则有送货线路的直接30已装车，没有则20-待装车
			@taskState=CASE @orderShipTime WHEN '1' THEN 20 ELSE CASE ISNULL(lineId,'') WHEN '' THEN 20 ELSE 30 END END,			--主要用于不排车直接配货完装车
			@sdState=sdState,@isTogether=isTogether,@aFlag=ISNULL(aFlag,0),@lineId=lineId,@handleId=handlerId,@deptId=deptId,@memo=memo
		FROM dbo.SAD_Order 
		WHERE orderNo=@orderNo;	
		--订单已被关闭
		IF (@sdState=0)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_IS_CANCEL','订单已关闭，操作无效!',@orderNo,@orderBillNo);
			COMMIT;
			RETURN;
		END
		--订单已终止
		IF (@sdState=15)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_IS_STOP','订单已终止，操作无效!',@orderNo,@orderBillNo);
			COMMIT;
			RETURN;
		END		
		--订单已审核
		IF (@sdState=20)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_IS_AUDITED','订单已审核，操作无效!',@orderNo,@orderBillNo);
			COMMIT;
			RETURN;
		END
		--订单已下达
		IF (@sdState=30)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_IS_COMPLETED','订单已审核，操作无效!',@orderNo,@orderBillNo);
			COMMIT;
			RETURN;
		END
		--自动审核未分配送货线路
		IF (@orderAutoCheck='1') AND ISNULL(@lineId,'')=''
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_LINE_IS_NULL','订单尚未设置配送线路，操作无效!',@orderNo,@orderBillNo);
			COMMIT;
			RETURN;
		END
		--非当前用户锁定数据不能进行预分配处理，避免重复
		IF NOT EXISTS(SELECT 1 FROM dbo.SAD_Order WHERE orderNo=@orderNo AND isLocked=1 AND lockerId=@creatorId)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_IS_LOCKED','订单被其他人锁定，操作无效!',@orderNo,@orderBillNo);
			COMMIT;
			RETURN;
		END
		--检查是否有明细数据
		IF NOT EXISTS(SELECT 1 FROM dbo.SAD_OrderDetail WHERE (orderNo=@orderNo) AND (ISNULL(orderQty,0.0)-ISNULL(shipQty,0.0)>0.0))
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_NON_DETAIL','没有需要配货的明细商品，操作无效!',@orderNo,@orderBillNo);
			COMMIT;
			RETURN;
		END
		--原单必须检查库存
		IF (ISNULL(@aFlag,0)=1 OR ISNULL(@aFlag,0)=0 OR ISNULL(@aFlag,0)=3)
		BEGIN
			--提示用户处理或者货齐一起送的，订单必须全部满足库存
			IF (@orderDealMode='0' OR @isTogether=1) AND EXISTS(SELECT 1 FROM dbo.SAD_OrderDetail_V WHERE (orderNo=@orderNo) AND (ISNULL(restQty,0.0)-ISNULL(availQty,0.0)>0.0))
			BEGIN
				INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
				VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_AVAIL_QTY_NOT_ENOUGH','订单明细商品库存不足，操作无效!',@orderNo,@orderBillNo);
				COMMIT;
				RETURN;
			END	
		END
		--直送订单的临时库位不能为空
		IF (ISNULL(@aFlag,0)=3 AND ISNULL(@tmplocation,'')='')	
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_LOCATION_IS_NULL','厂商送货临时库位未设置，操作无效!',@orderNo,@orderBillNo);
			COMMIT;
			RETURN;
		END
		--有A单的A单没审核不允许审核
		IF (ISNULL(@aFlag,0)=1)
		BEGIN
			--查询A单是否已经审核
			IF NOT EXISTS(SELECT 1 FROM SAD_Order WHERE aFlag=2 AND aOrderNo=@orderBillNo AND sdState=30)
			BEGIN
				INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
				VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_SOURCE_NOT_AUDIT','有A单的订单对应A单未审核，操作无效!',@orderNo,@orderBillNo);
				COMMIT;
				RETURN;
			END
		END
		--定制品没有库存不予许审核
		--IF EXISTS(SELECT 1
		--		  FROM dbo.SAD_OrderDetail a
		--			  LEFT JOIN dbo.PMS_PurToOrder_V b ON a.contractId=b.sdOrderId
		--		  WHERE a.orderNo=@orderNo
		--			  AND ISNULL(a.toOrder,0)=1
		--			  AND ISNULL(a.orderQty,0.0)-ISNULL(b.orderQty,0.0)>0.0)
		--BEGIN
		--	INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		--	VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_TO_ORDER_NON_QTY','定制品没有足够的库存，操作无效!',@orderNo,@orderBillNo);
		--	COMMIT;
		--	RETURN;	
		--END
		
		--检查商品单个体积与重量
		IF (ISNULL(@aFlag,0)=0 OR ISNULL(@aFlag,0)=1) AND EXISTS(SELECT 1 FROM dbo.BAS_Item WHERE itemId=ANY(SELECT itemId FROM dbo.SAD_OrderDetail WHERE orderNo=@orderNo) AND (ISNULL(itemVolume,0.0)=0.0 OR ISNULL(pkgRatio,0)=0)) 
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_BASIC_ERROR','订单商品包装数和体积设置不全，操作无效!',@orderNo,@orderBillNo);
			COMMIT;
			RETURN;
		END		
		--出库单No
		SET @stockNo=LOWER(REPLACE(NEWID(),'-',''));
		--出库单编号
		EXEC up_CreateCode @companyId,'SAD_Stock',@creatorId,@stockBillNo OUTPUT;
		--检查商品单个体积与重量
		IF ISNULL(@stockBillNo,'')=''
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_SYSTEM_BUSY','系统繁忙，生成单号失败，操作无效!',@orderNo,@orderBillNo);
			COMMIT;
			RETURN;
		END		
		--A单、厂家直送单
		IF (@aFlag=2 OR @aFlag=3)
		BEGIN			
			--生成出库单主表(A单，直接生成为已打包状态方便打印，不需要配货）
			INSERT INTO dbo.SAD_Stock(stockNo,companyId,ownerId,billNo,createTime,warehouseId,ioType,customerId,
				addressId,receiverState,receiverCity,receiverDistrict,receiverAddress,lineId,groupId,receiverName,
				receiverTel,receiverMobile,orderType,payMode,settlementId,shipDate,shipTime,currencyId,exchangeRate,
				taxFlag,ioState,taskState,arState,totalFee,totalDiscount,discount,serviceFee,postFee,payFee,orderSource,
				buyerId,organizeId,poNo,salesId,handlerId,deptId,flag,expressNo,logisticsId,logisticsFee,buyerMessage,
				aFlag,aStockNo,memo,mergeNo,ordField1,ordField2,ordField3,ordField4,ordField5,creatorId,isLocked,
				lockerId,lockedTime,editTime,editorId)
			SELECT @stockNo,@companyId,ownerId,@stockBillNo,@createTime,warehouseId,@ioType,customerId,addressId,
				receiverState,receiverCity,receiverDistrict,receiverAddress,lineId,groupId,receiverName,receiverTel,
				receiverMobile,orderType,payMode,settlementId,shipDate,shipTime,currencyId,exchangeRate,taxFlag,
				10 AS ioState,70,arState,totalFee,totalDiscount,discount,serviceFee,postFee,payFee,orderSource,
				buyerId,organizeId,poNo,salesId,handlerId,deptId,flag,expressNo,logisticsId,logisticsFee,buyerMessage,
				aFlag,aOrderNo,memo,billNo,ordField1,ordField2,ordField3,ordField4,ordField5,@creatorId,0 AS isLocked,
				'' AS lockerId,NULL AS lockedTime,@createTime,@creatorId
			FROM dbo.SAD_Order
			WHERE orderNo=@orderNo;
			INSERT INTO dbo.SAD_StockDetail(stockId,stockNo,orderId,orderNo,orderBillNo,companyId,warehouseId,
				viewOrder,lotNo,locationNo,eId,itemId,stockQty,pkgQty,bulkQty,pkgVolumn,bulkVolumn,pkgWeight,
				bulkWeight,befPrice,discount,discountFee,price,taxrate,fee,taxFee,totalFee,toOrder,updPrice,
				isPromotion,isGift,isVirtual,needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
				contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,pickQty,remarks)
			SELECT stockId,@stockNo AS stockNo,orderId,orderNo,billNo AS orderBillNo,companyId,warehouseId,
				viewOrder,lotNo,locationNo,eId,itemId,stockQty,pkgQty,bulkQty,pkgQty*pkgVolume AS pkgVolumn,
				bulkQty*itemVolume AS bulkVolumn,pkgWeight*pkgQty AS pkgWeight,bulkQty*itemWeight AS bulkWeight,
				befPrice,discount,discountFee,price,taxrate,fee,totalFee-fee AS taxFee,totalFee,toOrder,updPrice,
				isPromotion,isGift,ISNULL(isVirtual,0),needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
				contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,stockQty,remarks
			FROM (SELECT LOWER(REPLACE(NEWID(),'-','')) AS stockId,orderId,orderNo,billNo,companyId,warehouseId,
						ROW_NUMBER() OVER (ORDER BY viewOrder) AS viewOrder,'' AS lotNo,
						CASE @aFlag WHEN 3 THEN @locationNo ELSE '' END AS locationNo,eId,itemId,
						restQty AS stockQty,FLOOR(restQty/pkgRatio) AS pkgQty,(restQty%pkgRatio) AS bulkQty,
						befPrice,discount,discountFee,price,taxRate,
						CAST(restQty*price/(1+taxrate/100.0) AS DECIMAL(20,2)) AS fee,
						CAST(restQty*price AS DECIMAL(20,2)) AS totalFee,rebate,toOrder,updPrice,isPromotion,isGift,
						needAssemble,groupId,contractId,contractNo,salesId,handlerId,deptId,isVirtual,itemVolume,
						itemWeight,pkgWeight,pkgVolume,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,
						remarks
				  FROM dbo.SAD_OrderDetail_V
				  WHERE orderNo=@orderNo AND restQty>0.0) t;
			--回写订单已发货数据（预分配）	  
			UPDATE a SET a.shipQty=ISNULL(a.shipQty,0.0)+ISNULL(b.shipQty,0.0)
			FROM dbo.SAD_OrderDetail a 
				LEFT JOIN (SELECT orderId,SUM(stockQty) AS shipQty
						   FROM dbo.SAD_StockDetail
						   WHERE stockNo=@stockNo
						   GROUP BY orderId) b ON a.orderId=b.orderId
			WHERE a.orderNo=@orderNo; 
			--更新出库单总金额
			UPDATE a SET a.totalFee=b.totalFee
			FROM dbo.SAD_Stock a 
				INNER JOIN (SELECT stockNo,SUM(totalFee) AS totalFee 
							FROM dbo.SAD_StockDetail 
							WHERE stockNo=@stockNo
							GROUP BY stockNo) b ON a.stockNo=b.stockNo
			WHERE a.stockNo=@stockNo;
			--如果是厂家直送订单，则需要扣减库存
			IF (@aFlag=3)
			BEGIN
				--打开游标
				DECLARE myCursor CURSOR
				FOR SELECT stockId,eId,itemId,stockQty
				    FROM SAD_StockDetail
				    WHERE stockNo=@stockNo
				    ORDER BY viewOrder;
				OPEN myCursor 
				FETCH NEXT FROM myCursor INTO @stockId,@eId,@itemId,@stockQty
				WHILE @@fetch_status=0 
				BEGIN  
					--更新库存总量
					UPDATE BAS_Item SET onhandQty=ISNULL(onhandQty,0.0)-ISNULL(@stockQty,0.0) WHERE itemId=@itemId;
					--库位批次明细帐
					--取得库区
					SELECT @regionId=ISNULL(regionId,''),@warehouseId=warehouseId
					FROM dbo.BAS_Location  
					WHERE locationNo=@tmplocation;
					--仓库总账	
					IF EXISTS(SELECT 1 FROM IMS_Ledger WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId)
					BEGIN
						UPDATE IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)-@stockQty,lastOTime=@createTime
						WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
					END
					ELSE
					BEGIN
						INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastOTime)
						VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@eId,@itemId,@stockQty,0.0,@createTime);
					END								
					IF EXISTS(SELECT 1 FROM IMS_Stock WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@tmplocation,'') AND itemId=@itemId)
					BEGIN
						--入出库(调整)前库存
						SELECT @befQty=onhandQty
						FROM dbo.IMS_Stock
						WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@tmplocation,'') AND itemId=@itemId;
						UPDATE dbo.IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)-@stockQty,lastOTime=@createTime
						WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@tmplocation,'') AND itemId=@itemId;
					END
					ELSE
					BEGIN
						---如果库里面没有 进行插入
						SELECT @befQty=0.0;
						INSERT INTO dbo.IMS_Stock(stockId,companyId,warehouseId,regionId,lotNo,locationNo,eId,itemId,onhandQty,allocQty,lastOTime)
						VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@regionId,@lotNo,@tmplocation,@eId,@itemId,-@stockQty,0.0,@createTime);
					END
					--处理IMS_Book表
					INSERT INTO IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,
						eId,itemId,befQty,ioQty,afterQty,handlerId,deptId,createTime,creatorId,auditTime,auditorId,memo)
					VALUES(REPLACE(NEWID(),'-',''),'S100',@companyId,@stockId,@stockNo,@stockBillNo,'',@warehouseId,ISNULL(@lotNo,''),
						ISNULL(@tmplocation,''),@eId,@itemId,@befQty,-@stockQty,ISNULL(@befQty,0.0)-ISNULL(@stockQty,0.0),@handleId,
						@deptId,@createTime,@creatorId,@createTime,@creatorId,@memo);
					FETCH NEXT FROM myCursor INTO @stockId,@eId,@itemId,@stockQty
				END   
				CLOSE myCursor
				Deallocate myCursor
			END
		END
		ELSE
		BEGIN
			--生成出库单主表
			INSERT INTO dbo.SAD_Stock(stockNo,companyId,ownerId,billNo,createTime,warehouseId,ioType,customerId,
				addressId,receiverState,receiverCity,receiverDistrict,receiverAddress,lineId,groupId,receiverName,
				receiverTel,receiverMobile,orderType,payMode,settlementId,shipDate,shipTime,currencyId,exchangeRate,
				taxFlag,ioState,taskState,arState,totalFee,totalDiscount,discount,serviceFee,postFee,payFee,orderSource,
				buyerId,organizeId,poNo,salesId,handlerId,deptId,flag,expressNo,logisticsId,logisticsFee,buyerMessage,
				aFlag,aStockNo,memo,mergeNo,ordField1,ordField2,ordField3,ordField4,ordField5,creatorId,isLocked,
				lockerId,lockedTime,editTime,editorId)
			SELECT @stockNo,@companyId,ownerId,@stockBillNo,@createTime,warehouseId,@ioType,customerId,addressId,
				receiverState,receiverCity,receiverDistrict,receiverAddress,lineId,groupId,receiverName,receiverTel,
				receiverMobile,orderType,payMode,settlementId,shipDate,shipTime,currencyId,exchangeRate,taxFlag,
				10 AS ioState,@taskState,arState,totalFee,totalDiscount,discount,serviceFee,postFee,payFee,orderSource,
				buyerId,organizeId,poNo,salesId,handlerId,deptId,flag,expressNo,logisticsId,logisticsFee,buyerMessage,
				aFlag,aOrderNo,memo,billNo,ordField1,ordField2,ordField3,ordField4,ordField5,@creatorId,0 AS isLocked,
				'' AS lockerId,NULL AS lockedTime,@createTime,@creatorId
			FROM dbo.SAD_Order
			WHERE orderNo=@orderNo; 
			--orderDealMode:0,提示用户后处理(全部满足库存)
			IF (@orderDealMode='0')
			BEGIN
				INSERT INTO dbo.SAD_StockDetail(stockId,stockNo,orderId,orderNo,orderBillNo,companyId,warehouseId,
					viewOrder,lotNo,locationNo,eId,itemId,stockQty,pickQty,pkgQty,bulkQty,pkgVolumn,bulkVolumn,pkgWeight,
					bulkWeight,befPrice,discount,discountFee,price,taxrate,fee,taxFee,totalFee,toOrder,updPrice,
					isPromotion,isGift,isVirtual,needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
					contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,remarks)
				SELECT stockId,@stockNo AS stockNo,orderId,orderNo,billNo AS orderBillNo,companyId,warehouseId,
					viewOrder,lotNo,locationNo,eId,itemId,stockQty,0 AS pickQty,pkgQty,bulkQty,pkgQty*pkgVolume AS pkgVolumn,
					bulkQty*itemVolume AS bulkVolumn,pkgWeight*pkgQty AS pkgWeight,bulkQty*itemWeight AS bulkWeight,
					befPrice,discount,discountFee,price,taxrate,fee,totalFee-fee AS taxFee,totalFee,toOrder,updPrice,
					isPromotion,isGift,ISNULL(isVirtual,0),needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
					contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,remarks
				FROM (SELECT LOWER(REPLACE(NEWID(),'-','')) AS stockId,orderId,orderNo,billNo,companyId,warehouseId,
							ROW_NUMBER() OVER (ORDER BY viewOrder) AS viewOrder,'' AS lotNo,'' AS locationNo,eId,itemId,
							restQty AS stockQty,FLOOR(restQty/pkgRatio) AS pkgQty,(restQty%pkgRatio) AS bulkQty,
							befPrice,discount,discountFee,price,taxRate,
							CAST(restQty*price/(1+taxrate/100.0) AS DECIMAL(20,2)) AS fee,
							CAST(restQty*price AS DECIMAL(20,2)) AS totalFee,rebate,toOrder,updPrice,isPromotion,isGift,
							needAssemble,groupId,contractId,contractNo,boneOrdId,salesId,handlerId,deptId,isVirtual,
							itemVolume,itemWeight,pkgWeight,pkgVolume,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,
							remarks
					  FROM dbo.SAD_OrderDetail_V
					  WHERE orderNo=@orderNo AND restQty>0.0) t;
				--回写订单已发货数据（预分配）	  
				UPDATE a SET a.shipQty=ISNULL(a.shipQty,0.0)+ISNULL(b.shipQty,0.0)
				FROM dbo.SAD_OrderDetail a 
					LEFT JOIN (SELECT orderId,SUM(stockQty) AS shipQty
							   FROM dbo.SAD_StockDetail
							   WHERE stockNo=@stockNo
							   GROUP BY orderId) b ON a.orderId=b.orderId
				WHERE a.orderNo=@orderNo;
			END
			--1,按实际库存红冲下单;
			IF (@orderDealMode='1')
			BEGIN
				--把订单按库存和订单数量对比写入出库单明细（库存小于订单数量时，按库存数量写入——虚拟商品除外）
				INSERT INTO dbo.SAD_StockDetail(stockId,stockNo,orderId,orderNo,orderBillNo,companyId,warehouseId,
					viewOrder,lotNo,locationNo,eId,itemId,stockQty,pickQty,pkgQty,bulkQty,pkgVolumn,bulkVolumn,pkgWeight,
					bulkWeight,befPrice,discount,discountFee,price,taxrate,fee,taxFee,totalFee,toOrder,updPrice,
					isPromotion,isGift,isVirtual,needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
					contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,remarks)
				SELECT stockId,@stockNo AS stockNo,orderId,orderNo,billNo AS orderBillNo,companyId,warehouseId,
					viewOrder,lotNo,locationNo,eId,itemId,stockQty,0 AS pickQty, FLOOR(stockQty/pkgRatio) AS pkgQty,
					(stockQty%pkgRatio) AS bulkQty,FLOOR(stockQty/pkgRatio)*pkgVolume AS pkgVolumn,
					(stockQty%pkgRatio)*itemVolume AS bulkVolumn,FLOOR(stockQty/pkgRatio)*pkgWeight AS pkgWeight,
					(stockQty%pkgRatio)*itemWeight AS bulkWeight,befPrice,discount,discountFee,price,taxrate,
					CAST(stockQty*price/(1+taxrate/100.0) AS DECIMAL(20,2)) AS fee,
					CAST(stockQty*price AS DECIMAL(20,2))-CAST(stockQty*price/(1+taxrate/100.0) AS DECIMAL(20,2)) AS taxFee,
					CAST(stockQty*price AS DECIMAL(20,2)) AS totalFee,toOrder,updPrice,isPromotion,isGift,ISNULL(isVirtual,0),
					needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,contractNo,boneOrdId,ordDtlEx01,
					ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,remarks					
				FROM (SELECT LOWER(REPLACE(NEWID(),'-','')) AS stockId,orderId,orderNo,billNo,companyId,warehouseId,
							ROW_NUMBER() OVER (ORDER BY viewOrder) AS viewOrder,'' AS lotNo,'' AS locationNo,eId,itemId,
							CASE ISNULL(isVirtual,0) WHEN 0 THEN (CASE WHEN ISNULL(restQty,0.0)-ISNULL(availQty,0.0)>0.0 THEN availQty ELSE restQty END) 
							                         ELSE ISNULL(restQty,0.0) END AS stockQty,
							befPrice,discount,discountFee,price,taxRate,rebate,toOrder,updPrice,isPromotion,isGift,needAssemble,
							groupId,contractId,contractNo,boneOrdId,salesId,handlerId,deptId,isVirtual,itemVolume,itemWeight,
							pkgWeight,pkgVolume,pkgRatio,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,remarks
					  FROM dbo.SAD_OrderDetail_V
					  WHERE orderNo=@orderNo AND restQty>0.0) t;
				--更新已预分配发货数量
				UPDATE a SET a.shipQty=ISNULL(a.shipQty,0.0)+ISNULL(b.shipQty,0.0)
				FROM dbo.SAD_OrderDetail a 
					LEFT JOIN (SELECT orderId,SUM(stockQty) AS shipQty
							   FROM dbo.SAD_StockDetail
							   WHERE stockNo=@stockNo
							   GROUP BY orderId) b ON a.orderId=b.orderId
				WHERE a.orderNo=@orderNo;
				--如果有未分配发货数量的数据，则冲红
				UPDATE dbo.SAD_OrderDetail SET orderQty=ISNULL(shipQty,0.0),isRed=1 WHERE orderNo=@orderNo AND ISNULL(stockQty,0.0)-ISNULL(shipQty,0.0)>0.0; 
			END
			--更新出库单总金额
			UPDATE a SET a.totalFee=b.totalFee
			FROM dbo.SAD_Stock a 
				INNER JOIN (SELECT stockNo,SUM(totalFee) AS totalFee 
							FROM dbo.SAD_StockDetail 
							WHERE stockNo=@stockNo
							GROUP BY stockNo) b ON a.stockNo=b.stockNo
			WHERE a.stockNo=@stockNo;
			--更新IMS_Ledger表已分配量
			UPDATE a SET a.allocQty=ISNULL(a.allocQty,0.0)+ISNULL(b.allocQty,0.0)
			FROM dbo.IMS_Ledger a
				INNER JOIN (SELECT companyId,warehouseId,itemId,SUM(stockQty) AS allocQty
							FROM dbo.SAD_StockDetail
							WHERE stockNo=@stockNo AND isVirtual=0
							GROUP BY companyId,warehouseId,itemId
							) b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId
			INSERT INTO dbo.IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty)
			SELECT LOWER(REPLACE(NEWID(),'-','')),companyId,warehouseId,eId,itemId,0.0 AS onhandQty,allocQty
			FROM (SELECT companyId,warehouseId,eId,itemId,SUM(stockQty) AS allocQty
				  FROM dbo.SAD_StockDetail
				  WHERE stockNo=@stockNo AND isVirtual=0
				  GROUP BY companyId,warehouseId,eId,itemId
				 ) a 
			WHERE NOT EXISTS(SELECT 1 FROM dbo.IMS_Ledger b WHERE a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId);
		END
		--修改订单状态
		--订单全部进入待配货表
		IF NOT EXISTS(SELECT 1 FROM dbo.SAD_OrderDetail WHERE orderNo=@orderNo AND ISNULL(orderQty,0.0)-ISNULL(shipQty,0.0)>0.0)
		BEGIN
			UPDATE dbo.SAD_Order SET msgText='',isLocked=0,lockerId='',sdState=30,taskState=20,editTime=@createTime,editorId=@creatorId WHERE orderNo=@orderNo;
			UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='已下达' WHERE OrderNo=@orderBillNo;
		END
		ELSE
		BEGIN
			UPDATE dbo.SAD_Order SET msgText='',isLocked=0,lockerId='',sdState=25,taskState=15,editTime=@createTime,editorId=@creatorId WHERE orderNo=@orderNo;
			UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='部分下达' WHERE OrderNo=@orderBillNo;
		END
		COMMIT;		
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@creatorId,'up_OrderAuditToOrder','YI_SALES_ORDER_AUDIT_ERROR',LEFT(@ErrMsg,2000),@orderNo,@orderBillNo);		
		RAISERROR(@ErrMsg, @ErrSeverity, 1)			
	END CATCH
END

go

