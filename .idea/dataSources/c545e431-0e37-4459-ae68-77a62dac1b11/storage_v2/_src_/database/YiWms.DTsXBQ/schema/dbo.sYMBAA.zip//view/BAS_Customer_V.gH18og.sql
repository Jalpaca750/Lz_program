
/*==============================================================*/
/* View: BAS_Customer_V                                         */
/*==============================================================*/
--creator：        Frank
--create time：  2016-02-17日整理 
--modify:    2016-06-23 增加供应商Logo和首页推荐字段
--modify:    2016-11-02 增加ico，返点等
--客户视图
create view BAS_Customer_V as
SELECT p.partnerId AS customerId,p.companyId,p.ownerId,p.partnerNo AS customerNo,p.partnerName AS customerName, 
      p.shortName, p.partnerSpell AS customerSpell, p.companyState, a1.areaName AS stateName, p.companyCity, 
      a2.areaName AS cityName,p.companyDistrict, a3.areaName AS districtName, p.companyAddress, p.zip, 
      p.parentId, p.tradeId, t.tradeCName, p.natureId, n.natureCName, p.typeId, pt.typeCName,p.staffSizeId, 
      s.staffSizeName, f.invoiceDay, f.affterDelivery, f.payTermLimited, f.payTerm, f.creditLimited, f.creditFee,
      f.priceLimited, f.rebate1, f.rebate2, f.rebate3, f.defPrice, f.befPrice, f.salesId, f.salesName, f.taxFlag,
      f.isTogether, f.currencyId, f.arFee, f.preFee, f.integral, f.assistantId, f.outerId, p.icoUrl, p.logoUrl, 
      p.isRecommend, c.contactName,c.contactTitle,c.officeTel,c.mobileNo,c.email, p.partnerState, p.reportTitle,
      p.reportCode,p.remarks, p.isSelected
FROM dbo.BAS_Partner AS p LEFT OUTER JOIN
      dbo.BAS_PartnerFinancial_V f ON p.partnerId=f.partnerId LEFT OUTER JOIN
      dbo.BAS_Area AS a1 ON p.companyState = a1.areaId LEFT OUTER JOIN
      dbo.BAS_Area AS a2 ON p.companyCity = a2.areaId LEFT OUTER JOIN
      dbo.BAS_Area AS a3 ON p.companyDistrict = a3.areaId LEFT OUTER JOIN
      dbo.BAS_Trade AS t ON p.tradeId=t.tradeId LEFT OUTER JOIN
      dbo.BAS_Nature AS n ON p.natureId=n.natureId LEFT OUTER JOIN
      dbo.BAS_PartnerType pt on p.typeId = pt.typeId LEFT OUTER JOIN
      dbo.BAS_StaffSize s ON p.staffSizeId=s.staffSizeId LEFT JOIN
      (SELECT companyId,partnerId,contactName,contactTitle,officeTel,mobileNo,email,sex
       FROM BAS_Contact 
       WHERE isDefault=1) c ON p.partnerId=c.partnerId
WHERE (p.partnerType = 1) OR (p.partnerType = 9)
go

