-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER Trig_BAS_Item_Update
   ON BAS_Item
   AFTER UPDATE
AS 
BEGIN
	SELECT 1

END
go

