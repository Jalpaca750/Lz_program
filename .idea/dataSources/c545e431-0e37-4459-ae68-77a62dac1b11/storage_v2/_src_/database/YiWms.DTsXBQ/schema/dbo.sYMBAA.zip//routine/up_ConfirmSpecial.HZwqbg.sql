-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-08-04>
-- Description:	<Description:特殊回单确认>
-- Parameter:
--		@companyId:公司Id
--		@siteId: 网点Id
--      @stockNo:出库单Id
--      @billNo: 出库单编号
--      @operatorId:操作员Id
-- =============================================

CREATE PROCEDURE [dbo].[up_ConfirmSpecial] 
(
	@companyId VARCHAR(32),			--公司Id
	@siteId VARCHAR(32),			--网点Id
    @stockNo VARCHAR(32),			--出单Id
	@billNo VARCHAR(32),			--出库单编号
	@operatorId VARCHAR(32)			--操作员Id
)
AS
BEGIN
	DECLARE @curTime DATETIME,@hasTms INT,@waybillId VARCHAR(32),@deliveryId VARCHAR(32);
	SET @curTime=GETDATE();
	DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='up_ConfirmSpecial' AND billId=@stockNo;
	BEGIN TRY
		BEGIN TRANSACTION
		--送货员
		SELECT @deliveryId=userId FROM SAM_User WHERE companyId=@companyId AND userNo='Admin';
		SET @deliveryId=ISNULL(@deliveryId,@operatorId);
		IF EXISTS(SELECT 1 FROM dbo.SAD_Stock WHERE stockNo=@stockNo)
		BEGIN
			IF EXISTS(SELECT 1 FROM dbo.SAD_Stock WHERE stockNo=@stockNo AND taskState<70)
			BEGIN
				INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
				VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_ConfirmSpecial','YI_CONFIRM_RETURN_BILL_ERROR','单据[' + @billNo + ']尚未完成，操作无效',@stockNo,@billNo);		
				COMMIT;
				RETURN;
			END	
            IF EXISTS(SELECT 1 FROM dbo.SAD_Stock WHERE stockNo=@stockNo AND taskState>70)
			BEGIN
				INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
				VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_ConfirmSpecial','YI_CONFIRM_RETURN_BILL_ERROR','单据[' + @billNo + ']正常流转，操作无效',@stockNo,@billNo);		
				COMMIT;
				RETURN;
			END		
			--更新出库单
			UPDATE dbo.SAD_Stock SET taskState=99,isReceipt=1,backerId=@operatorId,receiptTime=@curTime,
				deliveryId=@deliveryId,deliveryTime=@curTime,editTime=@curTime,editorId=@operatorId 
			WHERE stockNo=@stockNo AND isReceipt=0 AND taskState=70; 
			IF(@@ROWCOUNT>0)
			BEGIN
				--更新F10出库单状态
				UPDATE F10BMS.dbo.SMS_Stock SET BackDate=CONVERT(VARCHAR(20),@curTime,120) WHERE StockNo=@billNo; 
			END	
		END
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_ConfirmSpecial','YI_CONFIRM_RETURN_BILL_ERROR',LEFT(@ErrMsg,2000),@stockNo,@billNo);		
		RAISERROR(@ErrMsg, @ErrSeverity, 1);			
	END CATCH
END
go

