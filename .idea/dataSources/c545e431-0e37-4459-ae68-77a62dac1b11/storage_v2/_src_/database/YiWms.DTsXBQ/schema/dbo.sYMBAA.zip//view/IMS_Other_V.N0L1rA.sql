/*==============================================================*/
/* View: IMS_Other_V                                            */
/*==============================================================*/
--creator：        Frank
--create time：  2016-03-10
--修改时间   2016-08-02 
--修改人     张东彦
--其他入出库单明细视图
create view [dbo].[IMS_Other_V] as
SELECT a.otherNo,a.billNo,a.ioDate,a.companyId,c.companyName,a.ownerId,o.ownerNo,
      o.ownerName,a.warehouseId,w.warehouseNo,w.warehouseName,a.ioType,
      CASE a.ioType WHEN 'D100' THEN '调拨入库单' 
                    WHEN 'D200' THEN '调拨出库单'
                    WHEN 'G100' THEN '赠品入库单'
                    WHEN 'G200' THEN '赠品出库单'
                    WHEN 'L200' THEN '领用出库单'
                    WHEN 'I100' THEN '库存初始化'
                    WHEN 'O100' THEN '其他入库单'
                    WHEN 'O200' THEN '其他出库单' END AS ioTypeDesc,
      a.ioObj,CASE a.ioObj WHEN 1 THEN '客户' 
                           WHEN 2 THEN '供应商' 
                           WHEN 3 THEN '员工' 
                           WHEN 4 THEN '部门'
                           WHEN 9 THEN '其他' END AS ioObjType,a.[objId],a.ioState,
      CASE a.ioState WHEN 0 THEN '已作废' WHEN 10 THEN '待审核' WHEN 20 THEN '已审核' END AS stateName,
      a.thirdSyncFlag,CONVERT(VARCHAR(20),a.thirdSyncTime,120) AS thirdSyncTime,
      a.handlerId,e.employeeName AS handlerName,a.deptId,d.deptNo,d.deptName,a.useDesc,a.auditorId, 
      u1.userNick AS auditorName,CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,a.isLocked,
      a.lockerId,u4.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
      a.createTime,a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName,
      a.memo,a.isSelected
FROM dbo.IMS_Other AS a INNER JOIN
      dbo.SAM_Company AS c ON a.companyId = c.companyId INNER JOIN
      dbo.BAS_Warehouse AS w ON a.warehouseId = w.warehouseId LEFT JOIN
      dbo.BAS_Owner_V AS o ON a.ownerId=o.ownerId LEFT JOIN      
      dbo.BAS_Department AS d ON a.deptId = d.deptId LEFT JOIN
      dbo.BAS_Employee AS e ON a.handlerId = e.employeeId LEFT JOIN
      dbo.SAM_User AS u1 ON a.auditorId = u1.userId LEFT JOIN
      dbo.SAM_User AS u2 ON a.creatorId = u2.userId LEFT JOIN
      dbo.SAM_User AS u3 ON a.editorId = u3.userId LEFT JOIN
      dbo.SAM_User AS u4 ON a.lockerId=u4.userId

go

