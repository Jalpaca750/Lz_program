
/*==============================================================*/
/* View: BAS_Department_V                                       */
/*==============================================================*/
--creator：        Frank
--create time：  2016-02-18 
--modify: Frank 2016-09-22 日调整
--部门资料视图
create view BAS_Department_V as
SELECT d.deptId,d.companyId,d.deptNo,d.deptName,d.parentId,ISNULL(p.deptNo,'') AS parentNo,
	ISNULL(d.parentName,ISNULL(p.deptName,'')) AS parentName,
	CASE d.parentId WHEN '0' THEN d.deptName 
					ELSE ISNULL(d.parentName,ISNULL(p.deptName,''))+'>' + d.deptName END AS fullName,
	d.isStore,CASE d.isStore WHEN 0 THEN '部门' ELSE '门店/公司' END deptType,
	d.viewOrder,d.isDisable,CASE d.isDisable WHEN 1 THEN '是' ELSE '否' END disableName,
	d.isLocked,d.lockerId,u3.userNick AS lockerName,CONVERT(VARCHAR(20),d.lockedTime,120) AS lockedTime, 
	d.createTime,d.creatorId,u1.userNick AS creatorName,d.editTime,d.editorId,u2.userNick AS editorName, 
	d.isSelected
FROM dbo.BAS_Department AS d 
	LEFT JOIN dbo.BAS_Department AS p ON d.parentId=p.deptId 
	LEFT JOIN dbo.SAM_User AS u1 ON d.creatorId = u1.userId 
	LEFT JOIN dbo.SAM_User AS u2 ON d.editorId = u2.userId 
	LEFT JOIN dbo.SAM_User AS u3 ON d.lockerId = u3.userId
go

