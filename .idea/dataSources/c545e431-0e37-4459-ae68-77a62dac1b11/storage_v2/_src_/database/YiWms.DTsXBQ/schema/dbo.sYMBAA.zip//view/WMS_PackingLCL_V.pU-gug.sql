
/*==============================================================*/
/* View: WMS_PackingLCL_V                                       */
/*==============================================================*/
CREATE view [dbo].[WMS_PackingLCL_V] as
SELECT a.pickId,a.packNo,a.companyId,a.stockNo,a.stockBillNo,a.lclCount AS lclQty,a.fclCount AS pkgQty,
	a.boxNum AS stockBox,a.boxBillNum,a.customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,
	p.partnerName + ISNULL(b.organizeId,'') AS customerDepart,p.shortName,l.lineName,r.regionDesc,
	b.mergeNo,b.collectOrder AS lineOrder,ISNULL(a.lclCount,0)+ISNULL(a.fclCount,0) AS totalQty,
	b.receiverAddress AS fullAddress,b.receiverName,b.collectOrder,b.receiverTel,b.receiverMobile,
	b.receiverTel AS fullTel,b.buyerId,b.groupId,b.organizeId,a.packState,b.taskState,a.printNum,a.printTime,
	--'第'+CAST(a.boxNum AS VARCHAR(4))+'件 共'+ CAST(a.lclCount AS VARCHAR(4))+'件' AS labDesc,
	b.ordField3,'第'+CAST(a.boxNum AS VARCHAR(4))+'件' AS labDesc,
	'总计:'+CAST(ISNULL(a.lclCount,0)/*+ISNULL(a.fclCount,0)*/ AS varchar(4))+'件' labTotalDesc,b.memo,
	ISNULL(r.regionDesc,'DFQ') AS tmpRegion,u1.userNick AS packingName,u1.userNick AS checkerName
FROM dbo.WMS_Packing a
	INNER JOIN dbo.BAS_Partner p ON a.customerId=p.partnerId
	INNER JOIN dbo.SAD_Stock b ON a.stockNo=b.stockNo
	LEFT JOIN dbo.BAS_AddressLine l ON a.lineId=l.lineId
	LEFT JOIN dbo.BAS_Region r ON a.regionId=r.regionId
	LEFT JOIN dbo.SAM_User u1 ON a.packingId=u1.userId




go

