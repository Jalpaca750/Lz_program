/*==============================================================*/
/* View: SAM_Company_V                                          */
/*==============================================================*/
--creator：        Frank
--create time：    2016-02-01
--modify:          2017-11-22日整理V1.2
--                 2019-03-14日增加SQL版本控制
CREATE view [dbo].[SAM_Company_V] as
SELECT corp.companyId,corp.companyNo,corp.companyName,corp.companyOwner,corp.companyTel,corp.companyMobile, 
	corp.companyEmail,corp.companyState,a1.areaName AS stateName,corp.companyCity,a2.areaName AS cityName, 
	corp.companyDistrict,a3.areaName AS districtName,corp.companyAddress,corp.zip,corp.hotLine,corp.storeNum, 
	corp.userNum,CONVERT(VARCHAR(10),corp.startDate,23) AS startDate,CONVERT(VARCHAR(10),corp.endDate,23) AS endDate,
	corp.logoUrl,corp.icpNo,corp.copyRight,corp.isDisable,corp.splitPolicy,corp.pusPolicy,corp.verSQL,
	corp.isLocked,corp.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),corp.lockedTime,120) AS lockedTime, 
	corp.createTime,corp.creatorId,u2.userNick AS creatorName,corp.editTime,corp.editorId,u3.userNick AS editorName, 
	corp.isSelected
FROM dbo.SAM_Company AS corp 
	LEFT JOIN dbo.BAS_Area AS a1 ON corp.companyState = a1.areaId 
	LEFT JOIN dbo.BAS_Area AS a3 ON corp.companyDistrict = a3.areaId 
	LEFT JOIN dbo.BAS_Area AS a2 ON corp.companyCity = a2.areaId 
	LEFT JOIN dbo.SAM_User AS u1 ON corp.lockerId=u1.userId 
	LEFT JOIN dbo.SAM_User AS u2 ON corp.creatorId=u2.userId 
	LEFT JOIN dbo.SAM_User AS u3 ON corp.editorId=u3.userId
go

