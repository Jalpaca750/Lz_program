--修改商品主视图
CREATE VIEW [dbo].[BAS_Item_V]
AS
SELECT sku.eId,bi.itemId,bi.companyId,bi.itemNo,bi.itemCTitle,bi.itemETitle,bi.itemName,bi.itemSpec,bi.itemSpell,
      bi.sellingPoint,bi.barcode,bi.brandId,b.brandNo,b.brandCName,b.brandEName,bi.categoryId,cat.categoryNo,
      cat.categoryCName,cat.categoryEName,sku.colorId,bi.colorName,sku.sizeId,bi.sizeName,bi.packageId,
      ISNULL(pkg.packageName,bi.packageId) AS packageName,sku.unitId,bi.unitName,bi.itemLong,bi.itemWidth,
      bi.itemHeight,bi.itemWeight,bi.itemVolume,bi.middleUnit,bi.middleVolume,bi.middleWeight,bi.middleRatio,
      bi.midBarcode,bi.bigUnit,bi.bigVolume,bi.bigWeight,bi.bigRatio,bi.bigBarcode,bi.pkgUnit,bi.pkgRatio,
      bi.pkgBarcode,bi.netWeight,bi.pkgLong,bi.pkgWidth,bi.pkgHeight,bi.pkgWeight,bi.pkgVolume,bi.palletRatio,bi.allowExcess,
      bi.excessRate,bi.putRegion,bi.eachGroup,bi.putLocation,bi.csPutRegion,bi.caseGroup,bi.csPutLocation,bi.pickRegion,
      bi.eachLocation,bi.csPickRegion,bi.caseLocation,bi.mixLocation,bi.replenishMode,bi.eaMaxQty,bi.eaMinQty,bi.csMaxQty,
      bi.csMinQty,bi.mixMaxQty,bi.mixMinQty,bi.taxFlag,bi.taxRate,bi.webPrice,bi.marketPrice,bi.vipPrice,bi.retailPrice,
      bi.tradePrice,bi.salesPrice,bi.autoIncrease,bi.webIncrease,bi.vipIncrease,bi.retailIncrease,bi.tradeIncrease,
      bi.salesIncrease,bi.purPrice,bi.lastPurPrice,bi.minPrice,bi.maxPrice,bi.purLeadTime,bi.itemPara,itemDescription,
      bi.inventoryMode,bi.isSafety,bi.safetyMonth,bi.isIrregular,bi.pickingMode,bi.safetyDays,bi.onhandQty,bi.allocQty,
      ISNULL(bi.onhandQty,0.0)-ISNULL(bi.allocQty,0.0) AS availQty,bi.serviceMode,bi.isUnsalable,bi.isStop,bi.isVirtual,
      CASE bi.isVirtual WHEN 0 THEN '实物' WHEN 1 THEN '服务' WHEN 2 THEN '虚拟' END AS virtualFlag,
      bi.allowSplit,CASE bi.allowSplit WHEN 0 THEN '不拼箱' WHEN 1 THEN '拼箱' WHEN 2 THEN '自拼箱' END AS splitMode,
      bi.splitRatio,bi.printControl,bi.allowDiscount,bi.usage,CASE bi.usage WHEN 0 THEN '全部' 
                                                                            WHEN 1 THEN '内部ERP' 
                                                                            WHEN 2 THEN '电商平台' 
                                                                            WHEN 3 THEN '特供产品' 
                                                                            WHEN 4 THEN '内购网'
                                                                            WHEN 5 THEN '制服' 
                                                                            WHEN 6 THEN '名片' END AS usageName,
      img.largeUrl, img.middleUrl, img.smallUrl, img.littleUrl,bi.putZone,bi.csPutZone,bi.pickZone,bi.csPickZone,
      bi.calcByCase,bi.itemState,CASE bi.itemState WHEN 0 THEN '失效' ELSE '有效' END AS stateName,bi.commodityId,
      bi.ownerId,o.partnerNo AS ownerNo,o.partnerName AS ownerName,o.shortName AS ownerShortName,bi.shopUrl,bi.supplierId,
      bi.remarks,bi.isLocked,bi.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),bi.lockedTime,120) AS lockedTime,
      bi.createTime,bi.creatorId,u2.userNick AS creatorName,bi.editTime,bi.editorId,u3.userNick AS editorName,bi.isSelected 
FROM dbo.BAS_Item bi 
	INNER JOIN dbo.ECM_ItemSku sku ON bi.itemId=sku.itemId 
	LEFT JOIN dbo.BAS_Brand b ON bi.brandId=b.brandId 
	LEFT JOIN BAS_Partner o on bi.ownerid=o.partnerId  
	LEFT JOIN dbo.BAS_Category cat ON bi.categoryId=cat.categoryId 
	LEFT JOIN dbo.BAS_Package pkg ON bi.packageId=pkg.packageId 
	LEFT JOIN dbo.SAM_User u1 ON bi.lockerId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON bi.creatorId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON bi.editorId=u3.userId 
	LEFT JOIN (SELECT eId,itemId,imageType,largeUrl,middleUrl,smallUrl,littleUrl
			   FROM dbo.BAS_ItemImage
			   WHERE (imageType = 1)
			   ) AS img ON bi.itemId = img.itemId
go

