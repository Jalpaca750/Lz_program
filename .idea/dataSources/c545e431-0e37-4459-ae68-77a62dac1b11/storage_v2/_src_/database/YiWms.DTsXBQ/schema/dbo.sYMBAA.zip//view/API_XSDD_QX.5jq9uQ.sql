
/*------------------------------------------------------------------------------------------------------
--*   销售订单取消视图  @creator:zdy   @at:2020-07-10 
--   2020-11-16  @editor zdy  discription: 销售订单取消，终止都在该表返回
--*----------------------------------------------------------------------------------------------------*/
CREATE VIEW  [dbo].[API_XSDD_QX]
AS
SELECT a.orderNo AS PKID,a.companyId,a.ownerId,a.warehouseId,o.partnerNo AS YEZ_ID,o.partnerName AS YEZ_Name,
a.billNo AS DANJ_NO,a.billNo AS SHANGJ_DANJ_NO,c.partnerNo AS CARDCODE,
	CONVERT(VARCHAR(10),a.editTime,23) AS docdate,
	A.totalFee AS totalFee,a.buyerMessage AS ShutdownExplain,u.userNo AS U_opcode,
	u.userNick AS U_OPNAME,0 AS discprcnt,w.warehouseNo AS whNo,
	a.orderType AS orderTypeId,
	a.orderType,a.sdstate,
	CASE a.orderType WHEN 10 THEN '普通订单' 
                     WHEN 20 THEN '调拨申请' 
                     WHEN 30 THEN '经营领用' 
                     WHEN 31 THEN '管理领用' 
                     WHEN 32 THEN '其他出库' 
                     WHEN 32 THEN '其他出库'
                     WHEN 40 THEN '赠品出库' 
                     WHEN 50 THEN '报损报废' END AS YEW_TYPE,a.thirdSyncFlag AS SC_FLG,
					 a.editTime FLG_TIME,
					 a.ordField2 docType,
					 a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5
FROM dbo.SAD_Order a INNER JOIN
      dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId 
      INNER JOIN dbo.BAS_Partner c ON a.customerId=c.partnerId LEFT JOIN
      BAS_Partner o ON a.ownerId=o.partnerId AND o.partnerType=3 LEFT JOIN 
      dbo.SAM_User u ON a.creatorId=u.userId
WHERE (a.sdState=0 or a.sdState=15) AND a.thirdSyncFlag in (0,2) 


go

