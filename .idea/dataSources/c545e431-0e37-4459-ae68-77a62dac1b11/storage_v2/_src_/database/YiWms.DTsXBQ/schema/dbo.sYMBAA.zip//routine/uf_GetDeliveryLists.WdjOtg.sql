--creator：        WJ
--create time：  2017-04-06
--销售出库单等打印数据

CREATE FUNCTION [dbo].[uf_GetDeliveryLists] 
(
	@stockNos AS Filter_Type READONLY
)
RETURNS TABLE
RETURN(
      SELECT a.stockNo,CASE ISNULL(b.reportTitle,'') WHEN '' THEN c.companyName ELSE b.reportTitle END AS reportTitle,
            a.ioType,CASE orderType WHEN 10 THEN '销售交货单' WHEN 20 THEN '调拨出库单' WHEN 30 THEN '经营领用单' WHEN 31 THEN '管理领用单' WHEN 40 THEN '赠品出库单' WHEN 50 THEN '报损报废单' END AS subTitle,a.billNo,
            w.warehouseNo,w.warehouseName,b.partnerNo AS customerNo,b.partnerName AS customerName,
            ISNULL(a1.areaName,a.receiverState) AS stateName,ISNULL(a2.areaName,a.receiverCity) AS cityName,
            ISNULL(a3.areaName,a.receiverDistrict) AS districtName,a.receiverAddress,
            ISNULL(a1.areaName,a.receiverState)+ISNULL(a2.areaName,a.receiverCity)+ISNULL(a3.areaName,a.receiverDistrict)+ISNULL(a.receiverAddress,'') AS fullAddress,
            ln.lineCode,ln.lineName,a.receiverName,a.receiverMobile,a.receiverTel,
            RTRIM(ISNULL(a.receiverMobile,'') + ' ' + ISNULL(a.receiverTel,'')) AS fullTel,a.settlementId,a.shipDate,
            a.shipTime,a.salesId,a.deptId,a.expressNo,lg.logisticsCode,lg.logisticsName,a.mergeNo,a.printNum,a.memo,'订单:' + a.mergeNo + ';' + a.memo AS orderMemo,
            d.viewOrder,d.itemNo,d.itemName,d.itemSpec,d.packageId,d.barcode,d.pkgBarcode,d.colorName,d.sizeName,d.unitName,
            d.stockQty,d.actQty,d.befPrice,d.price,d.discount,d.discountFee,d.fee,ISNULL(d.totalFee,0.0)-ISNULL(d.fee,0.0) AS taxFee,
            d.totalFee,d.remarks,dbo.uf_GetUpper(a.totalFee) AS upperRMB,d.stockBox,u1.userNick AS creatorName,a.organizeId,a.poNo
      FROM dbo.SAD_Stock a INNER JOIN
            (SELECT x.stockNo,x.orderBillNo,ROW_NUMBER() OVER (ORDER BY x.viewOrder) AS viewOrder,y.itemNo,y.itemName,y.itemSpec,y.packageId,
                   y.barcode,y.pkgBarcode,y.colorName,y.sizeName,y.unitName,x.stockQty,z.actQty,x.befPrice,x.price,x.discount,x.discountFee,
                   CAST(z.actQty*x.price/(1+x.taxrate/100.0) AS DECIMAL(20,2)) AS fee,
                   CAST(z.actQty*x.price AS DECIMAL(20,2)) AS totalFee,
                   x.remarks,dbo.uf_GetStockBoxes(x.stockId) AS stockBox
             FROM dbo.SAD_StockDetail x INNER JOIN
                   dbo.BAS_Item y ON x.itemId=y.itemId INNER JOIN
                   (SELECT stockId,SUM(CASE isPackage WHEN 0 THEN pickQty WHEN 1 THEN pickQty * realQty END) AS actQty
					FROM WMS_PickingDetail
					WHERE EXISTS(SELECT 1 FROM @stockNos b WHERE b.charId=stockNo) AND pickQty>0.0
					GROUP BY stockId) z ON x.stockId=z.stockId
             WHERE EXISTS(SELECT 1 FROM @stockNos b WHERE b.charId= x.stockNo)) d ON a.stockNo=d.stockNo INNER JOIN
            dbo.BAS_Partner b ON a.customerId=b.partnerId INNER JOIN
            dbo.SAM_Company c ON a.companyId=c.companyId INNER JOIN
            dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId LEFT JOIN
            dbo.BAS_Area a1 ON a.receiverState=a1.areaId LEFT JOIN
            dbo.BAS_Area a2 ON a.receiverCity=a2.areaId LEFT JOIN
            dbo.BAS_Area a3 ON a.receiverDistrict=a3.areaId LEFT JOIN
            dbo.BAS_AddressLine ln ON a.lineId=ln.lineId LEFT JOIN
            dbo.BAS_Logistics lg ON a.logisticsId=lg.logisticsId LEFT JOIN
            dbo.SAM_User u1 ON a.creatorId=u1.userId
      WHERE EXISTS(SELECT 1 FROM @stockNos b WHERE b.charId=a.stockNo)
)




go

