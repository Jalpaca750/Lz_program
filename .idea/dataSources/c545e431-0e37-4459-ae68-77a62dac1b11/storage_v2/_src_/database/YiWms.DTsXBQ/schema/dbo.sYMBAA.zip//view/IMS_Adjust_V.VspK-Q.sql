
/*==============================================================*/
/* View: IMS_Adjust_V                                           */
/*==============================================================*/
--creator： Frank
--create time：  2016-12-29
--调整单主表视图
create view IMS_Adjust_V as
SELECT a.adjustNo,a.billNo,a.companyId,c.companyNo,c.companyName,a.adjustDate,a.warehouseId,
	w.warehouseNo,w.warehouseName,a.billType,CASE a.billType WHEN 10 THEN '盘亏调整单'
                                                             WHEN 11 THEN '盘盈调整单'
                                                             WHEN 20 THEN '手工调亏单'
                                                             WHEN 21 THEN '手工调盈单' END AS billTypeDesc,
	a.pointId,cp.pointNo,a.adjustReason,a.ioState,CASE a.ioState WHEN 0 THEN '已作废' 
                                                                 WHEN 10 THEN '待审核' 
                                                                 WHEN 20 THEN '已审核' END ioStateName,
	a.deptId,d.deptNo,d.deptName,a.handlerId,e.employeeName AS handlerName,a.printNum,a.printId,
	u5.userNick AS printMan,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,a.memo,a.auditorId,
	u1.userNick AS auditorName,CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,a.isLocked,
	a.lockerId,u2.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
	a.createTime,a.creatorId,u3.userNick AS creatorName,a.editTime,a.editorId,u4.userNick AS editorName,
	CONVERT(VARCHAR(20),a.thirdSyncTime,120) AS thirdSyncTime,a.thirdSyncFlag,a.isSelected
FROM dbo.IMS_Adjust a 
	INNER JOIN dbo.SAM_Company c ON a.companyId=c.companyId 
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId 
	LEFT JOIN dbo.IMS_CheckPoint cp ON a.pointId=cp.pointId 
	LEFT JOIN dbo.BAS_Department d ON a.deptId=d.deptId 
	LEFT JOIN dbo.BAS_Employee e ON a.handlerId=e.employeeId 
	LEFT JOIN dbo.SAM_User u1 ON a.auditorId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON a.lockerId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON a.creatorId=u3.userId 
	LEFT JOIN dbo.SAM_User u4 ON a.editorId=u4.userId
	LEFT JOIN dbo.SAM_User u5 ON a.printId=u5.userId
go

