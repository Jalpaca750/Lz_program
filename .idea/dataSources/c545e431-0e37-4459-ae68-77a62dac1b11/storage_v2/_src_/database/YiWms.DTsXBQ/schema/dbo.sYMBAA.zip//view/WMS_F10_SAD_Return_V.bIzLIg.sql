




--5.修改销售退货同步视图，增加仓库字段
/*==============================================================*/
/* View: WMS_F10_SAD_Return_V                                   */

/*==============================================================*/
CREATE view [dbo].[WMS_F10_SAD_Return_V] as
SELECT a.returnNo AS wmsOrder,a.billNo AS wmsBillNo,a.billNo AS returnNo,
    b.employeeID AS auditorId,CONVERT(VARCHAR(10),a.auditTime,23) AS auditTime,
    w.warehouseNo AS warehouse
FROM dbo.SAD_Return a 
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V b ON a.auditorId=b.userId
	LEFT JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
WHERE (ioState=30)                                      --已上架
    AND (thirdSyncFlag=0 OR thirdSyncFlag=2)            --待同步与同步错误的数据
go

