
/*==============================================================*/
/* View: SAM_CompanyTempletSort_V                               */
/*==============================================================*/
create view SAM_CompanyTempletSort_V as
SELECT a.sortId,a.companyId,a.templetCode,b.templetName,a.formName,a.viewOrder,a.fieldCode,
    a.fieldName,a.sortMode,a.sorted,a.isLocked,a.lockerId,u1.userNick AS lockerName,
    CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,a.creatorId,
    u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName
FROM dbo.SAM_CompanyTempletSort a
    INNER JOIN dbo.SAM_Templet b ON a.templetCode=b.templetCode
    LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId
    LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId
    LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId
go

