-- =============================================
-- Author:		<W.J>
-- Create date: <2016-12-15>
-- Description:	<得到移仓数据>
-- =============================================
CREATE FUNCTION [dbo].[uf_GetTransferItem]
(
	@companyId VARCHAR(32),
	@outputId VARCHAR(32),
	@inputId VARCHAR(32)
)
RETURNS TABLE 
AS
RETURN
(
	SELECT @outputId AS outputId, @inputId AS inputId,c.categoryNo,c.categoryId,c.brandId,c.brandNo,isnull(a.lotNo,'')AS outlotNo,isnull(a.locationNo,'') AS outlocationNo,isnull(b.locationNo,'') AS inputlocationNo,c.itemId,c.itemNo,c.itemCTitle,c.itemETitle,c.itemName,c.unitName,c.barcode,c.itemSpec,c.itemSpell,c.remarks,
	c.sizeName,c.colorName,isnull(a.onhandQty,0.0) AS outonhandQty,ISNULL(b.onhandQty,0.0)AS inputonhandQty,
    c.pkgRatio,0 AS ioQty
	FROM IMS_Stock a
	LEFT JOIN IMS_Stock b ON b.companyId=a.companyId AND a.itemId=b.itemId AND b.warehouseId=@inputId
	LEFT JOIN BAS_ItemSku_V AS c ON a.companyId=c.companyId AND a.itemId=c.itemId
	WHERE a.warehouseId=@outputId AND a.companyId=@companyId
)



go

