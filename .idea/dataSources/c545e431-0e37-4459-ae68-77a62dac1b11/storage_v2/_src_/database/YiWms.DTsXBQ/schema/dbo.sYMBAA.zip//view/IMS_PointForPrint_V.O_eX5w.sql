
/*==============================================================*/
/* View: IMS_PointForPrint_V                                    */
/*==============================================================*/
create view IMS_PointForPrint_V as
SELECT b.stockId,b.pointId,a.pointNo,b.companyId,corp.companyName,b.warehouseId,w.warehouseNo,
	w.warehouseName,b.regionId,r.regionNo,r.regionDesc,b.lotNo,b.locationWay,b.locationNo,b.eId,
	b.itemId,c.itemNo,c.itemName,c.itemSpec,c.colorName,c.sizeName,c.unitName,c.packageId,c.barcode,
	c.midBarcode,c.bigBarcode,c.pkgBarcode,
	CASE ISNULL(t.showQty,0) WHEN 1 THEN b.onhandQty ELSE NULL END AS onhandQty,b.realQty,
	u1.userNick AS creatorName,a.createTime,l.pickingOrder,l.putawayOrder
FROM dbo.IMS_CheckPoint a 
	INNER JOIN dbo.IMS_CheckStock b ON a.pointId=b.pointId
	INNER JOIN dbo.BAS_Goods_V c ON b.itemId=c.itemId
	INNER JOIN dbo.SAM_Company corp ON b.companyId=corp.companyId
	INNER JOIN dbo.BAS_Warehouse w ON b.warehouseId=w.warehouseId
	INNER JOIN dbo.BAS_Region r ON b.regionId=r.regionId
	INNER JOIN dbo.BAS_Location l ON b.companyId=l.companyId AND b.warehouseId=l.warehouseId AND b.locationNo=l.locationNo
	LEFT JOIN dbo.SAM_User u1 ON a.creatorId=u1.userId
	LEFT JOIN (SELECT companyId,COUNT(1) AS showQty
				FROM SAM_Config
				WHERE configCode='PHYSICAL_COUNT_SHOW_QTY' AND configValue='1'
				GROUP BY companyId) t ON b.companyId=t.companyId
go

