
CREATE Proc [dbo].[proc_Check_Wrok]
AS
BEGIN
    declare @pointid varchar(32)=''
declare @locationNo varchar(32)=''
DECLARE @rows INT
Select top 1 @pointid=pointId FROM IMS_CheckPoint WHERE checkState=20 order by createTime desc
SELECT @rows= count(1) FROM IMS_Stock a
LEFT JOIN IMS_CheckStock b ON a.warehouseId=b.warehouseId AND a.itemId=b.itemId AND a.locationNo=b.locationNo AND b.pointId=@pointid
WHERE b.locationNo IS NULL

if(@rows>0 AND EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@pointid))
BEGIN
declare my_cursor cursor for     
SELECT a.locationNo FROM IMS_Stock a
LEFT JOIN IMS_CheckStock b ON a.warehouseId=b.warehouseId AND a.itemId=b.itemId AND a.locationNo=b.locationNo and b.pointId=@pointid 
WHERE  b.locationNo IS NULL 
open my_cursor                  
fetch next from my_cursor into @locationNo
while @@FETCH_STATUS=0 
BEGIN 
	
	--PRINT @locationNo
	INSERT INTO IMS_CheckStock(stockId,pointId,companyId,warehouseId,regionId,lotNo,locationNo,eId,itemId,onhandQty,realQty,locationWay)
	SELECT REPLACE(NEWID(),'-',''),@pointid,a.companyId,a.warehouseId,a.regionId,'',a.locationNo,eId,a.itemId,0,0,b.locationWay
	FROM IMS_Stock_V  a  inner join  BAS_Location b on a.locationNo=b.locationNo
	WHERE a.locationNo=@locationNo
	and not exists( select stockId from IMS_CheckStock 
	where  pointId=@pointid and itemId=a.itemId and locationNo=a.locationNo)
	
fetch next from my_cursor into @locationNo
END 
close my_cursor
deallocate my_cursor
END
end



go

