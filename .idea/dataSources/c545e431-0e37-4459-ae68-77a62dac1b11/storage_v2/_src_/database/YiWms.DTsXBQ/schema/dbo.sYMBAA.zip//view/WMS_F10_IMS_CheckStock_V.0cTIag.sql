/*==============================================================*/
/* View: WMS_F10_IMS_CheckStock_V                               */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_IMS_CheckStock_V] as
SELECT a.pointId,w.warehouseNo AS warehouseID, a.eId,b.f10Id AS ItemID,SUM(a.onhandQty) AS onhandQty
FROM dbo.IMS_CheckStock a
    LEFT JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
    LEFT JOIN F10BMS.dbo.WMS_F10_Item_V b ON a.itemId=b.itemId
GROUP BY a.pointId,w.warehouseNo,a.eId,b.f10Id
go

