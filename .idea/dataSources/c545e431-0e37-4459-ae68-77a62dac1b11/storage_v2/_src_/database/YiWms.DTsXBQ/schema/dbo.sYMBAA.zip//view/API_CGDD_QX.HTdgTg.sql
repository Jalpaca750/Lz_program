
/*==============================================================*/
-- View: API_CGDD_QX        
--   @create:  张东彦  @at:2020-07-08 14:13
--   @content: 新增视图       API_CGDD_QX                          
/*==============================================================*/
CREATE   VIEW [dbo].[API_CGDD_QX] as
SELECT a.orderNo PKID,a.companyId,a.billNo DANJ_NO,a.thirdSyncFlag,a.thirdSyncTime,
w.warehouseNo  WHNO,c.ownerNo yez_id,c.ownerName yez_name,
poState qx_flag,--0 关闭 3 终止
a.ownerId,
a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5,a.ShutdownExplain 
FROM PMS_Order a inner join BAS_Warehouse w on a.warehouseId=w.warehouseId
inner  join  BAS_Owner_V c on a.ownerid=c.ownerId
WHERE (poState=0 OR poState=-3) AND (thirdSyncFlag=0 OR thirdSyncFlag=2)


go

