CREATE PROCEDURE [dbo].[up_ShipBillUpdated]
(
	@shipId VARCHAR(32),
    @lclQty DECIMAL(20,10),
    @pkgQty DECIMAL(20,10),
    @fileQty DECIMAL(20,10),
    @fclQty DECIMAL(20,10),
    @lclVolumn DECIMAL(20,10),
    @pkgVolumn DECIMAL(20,10),
    @boxBillNums VARCHAR(40),
    @postFee DECIMAL(20,10),
    @operatorId VARCHAR(32)
)
AS
BEGIN
    --当前装车单据（运单）对应
    DECLARE @companyId VARCHAR(32),@billType INT,@billNo VARCHAR(32),@stockBillNo VARCHAR(32),@sumWeight DECIMAL(10,4),@sumCount INT;
    --临时数据，存储重量用于分摊运费
    DECLARE @tmpSales TABLE(stockId VARCHAR(32),stockQty DECIMAL(20,6),subWeight DECIMAL(10,4),postPrice DECIMAL(20,10));
    --获取装车单数据
    SELECT @companyId=companyId,@billType=billType,@billNo=billNo,@stockBillNo=stockBillNo
    FROM dbo.WMS_ShipDetail 
    WHERE shipId=@shipId;
    BEGIN TRY
        BEGIN TRANSACTION
        --修改装车单明细数据
        UPDATE dbo.WMS_ShipDetail SET lclQty=@lclQty,pkgQty=@pkgQty,fileQty=@fileQty,fclQty=@fclQty,
            lclVolumn=@lclVolumn,pkgVolumn=@pkgVolumn,boxBillNums=@boxBillNums,postFee=@postFee
        WHERE shipId=@shipId;
        --修改对应运单数据
        UPDATE a SET a.boxCount=ISNULL(b.lclQty,0.0)+ISNULL(b.pkgQty,0.0)+ISNULL(b.fileQty,0.0),
                               a.settleCount=ISNULL(b.fclQty,0.0)+ISNULL(b.fileQty,0.0),postFee=@postFee
        FROM dbo.TMS_WayBill a
              INNER JOIN dbo.WMS_ShipDetail b ON a.shipId=b.shipId
        WHERE b.shipId=@shipId
        --如果出库类单据，则更新对应运费
        IF (@billType<60 AND ISNULL(@postFee,0.0)>0.0)
        BEGIN
            UPDATE dbo.SAD_Stock SET postFee=@postFee WHERE stockNo=@billNo;
            --调拨出库单
            IF (@billType=20)
            BEGIN
                --重量写入临时表
                INSERT INTO @tmpSales(stockId,stockQty,subWeight,postPrice)
                SELECT a.stockId,a.stockQty,a.stockQty*b.itemWeight,0.0
                FROM dbo.SAD_StockDetail a
                    INNER JOIN dbo.BAS_Item b ON a.itemId=b.itemId
                WHERE a.stockNo=@billNo;
                --获取总重量与总条目数
                SELECT @sumWeight=SUM(subWeight),@sumCount=COUNT(*) FROM @tmpSales;
                --如果没有重量，则平均分摊
                IF (ISNULL(@sumWeight,0.0)=0.0)
                    UPDATE @tmpSales SET postPrice=ROUND(@postFee/@sumCount/stockQty,4);
                ELSE
                    UPDATE @tmpSales SET postPrice=ROUND(@postFee*subWeight/@sumWeight/stockQty,4);
                --同步到F10
    
                IF EXISTS(SELECT * FROM F10BMS.dbo.IMS_AllotDtl WHERE AllotNo=@stockBillNo)
                BEGIN
                    UPDATE a SET a.Price=ISNULL(a.befPrice,ISNULL(a.Price,0.0))+ISNULL(b.postPrice,0.0),
                                 a.Amt=ISNULL(a.SQty,0.0)*(ISNULL(a.befPrice,ISNULL(a.Price,0.0))+ISNULL(b.postPrice,0.0))
                    FROM F10BMS.dbo.IMS_AllotDtl a 
                        INNER JOIN @tmpSales b ON a.wmsStockId=b.stockId  
                    WHERE a.AllotNo=@stockBillNo;
                    UPDATE F10BMS.dbo.IMS_Allot SET postFee=@postFee WHERE AllotNo=@stockBillNo;
                END
   
            END
        END
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
			 ROLLBACK;
		--写入错误日志
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_ShipBillUpdated','YI_UPDATED_SHIP_ERROR',LEFT(@ErrMsg,2000),@shipId,@stockBillNo);
		RAISERROR(@ErrMsg, @ErrSeverity, 1)		            
    END CATCH
END    


go

