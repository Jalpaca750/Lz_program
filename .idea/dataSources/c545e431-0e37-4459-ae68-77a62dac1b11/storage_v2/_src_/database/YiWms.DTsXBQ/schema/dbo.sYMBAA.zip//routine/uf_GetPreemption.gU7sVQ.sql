--Frank.He
--2019-12-02
--获取商品预占数据
CREATE FUNCTION [dbo].[uf_GetPreemption] 
(
	@orderNo VARCHAR(32)			
)
RETURNS TABLE
RETURN(
    SELECT a.advanceId,a.companyId,a.viewOrder,a.orderNo,a.orderBillNo,a.orderId,
        a.customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,p.shortName,
        a.warehouseId,w.warehouseNo,w.warehouseName,a.locationNo,a.itemId,bi.itemNo,
        bi.itemName,bi.itemSpec,bi.colorName,bi.sizeName,bi.unitName,a.advQty,b.onhandQty,
        a.advType,a.creatorId,u1.userNick AS creatorName,a.createTime,a.fieldEx01, 
        a.fieldEx02,a.fieldEx03,a.fieldEx04,a.fieldEx05
    FROM IMS_Advance a
        INNER JOIN IMS_Ledger b ON a.warehouseId=b.warehouseId AND a.itemId=b.itemId
        INNER JOIN BAS_Partner p ON a.customerId=p.partnerId
        INNER JOIN BAS_Item bi ON a.itemId=bi.itemId
        INNER JOIN BAS_Warehouse w ON a.warehouseId=w.warehouseId
        LEFT  JOIN SAM_User u1 ON a.creatorId=u1.userId
    WHERE a.orderNo!=@orderNo
        AND EXISTS(SELECT * FROM SAD_OrderDetail d WHERE d.orderNo=@orderNo AND a.warehouseId=d.warehouseId AND a.itemId=d.itemId)
)
go

