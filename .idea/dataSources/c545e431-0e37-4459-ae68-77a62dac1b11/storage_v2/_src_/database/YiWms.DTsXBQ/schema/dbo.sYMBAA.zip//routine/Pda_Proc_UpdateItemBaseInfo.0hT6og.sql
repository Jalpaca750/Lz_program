/*
   PDA 修改商品资料存储过程
*/
CREATE  PROC  [dbo].[Pda_Proc_UpdateItemBaseInfo]
(
   @itemId varchar(32),  ---商品ID
   @itemWeight decimal(10,4), --单个商品重量
   @itemVolume decimal(20,3), --单个商品体积
   @pkgUnit    varchar(100),--包装单位
   @pkgRatio   int,         --包装转换系数
   @pkgLong    decimal(10,2), --整包长度
   @pkgWidth   decimal(10,2), --整包宽度
   @pkgHeight  decimal(10,2), --整包高度
   @pkgWeight  decimal(10,4), --整包重量
   @pkgVolume  decimal(20,3), --整包装体积
   @editorId   varchar(32)    --修改人
)
AS
DECLARE  @editTime datetime=getdate()
UPDATE BAS_Item  
SET itemWeight=@itemWeight,
    itemVolume=@itemVolume,
    pkgUnit=@pkgUnit,
    pkgRatio=@pkgRatio,
    pkgLong=@pkgLong,
    pkgWidth=@pkgWidth,
    pkgHeight=@pkgHeight,
    pkgWeight=@pkgWeight,
    pkgVolume=@pkgVolume,
    editorId=@editorId,
    editTime=@editTime
WHERE  itemId=@itemId;
--写入修改日志
INSERT INTO BAS_ItemVer(verId,itemId,companyId,itemVolume,itemWeight,pkgLong,pkgWidth,pkgHeight,pkgVolume,pkgWeight,pkgRatio,pkgUnit,editorId,editTime)
SELECT LOWER(REPLACE(NEWID(),'-','')),itemId,companyId,itemVolume,itemWeight,pkgLong,pkgWidth,pkgHeight,pkgVolume,pkgWeight,pkgRatio,pkgUnit,editorId,editTime
FROM BAS_Item
WHERE itemId=@itemId;
go

