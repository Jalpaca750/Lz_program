/*==============================================================*/
/* View: WMS_SalesReturnPutawayDetail_V                         */
/*==============================================================*/
CREATE view [dbo].[WMS_SalesReturnPutawayDetail_V] as
SELECT a.flowId,a.stockId,a.stockNo,ps.billNo,a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,
      loc.regionNo,loc.regionDesc,a.viewOrder,a.lotNo,a.locationNo,loc.locationWay,loc.locationRow,
      loc.locationCol,loc.locationLayer,loc.putawayOrder,a.eId,a.itemId,bi.itemNo,bi.itemName,bi.itemCTitle,
      bi.itemETitle,bi.sellingPoint,bi.itemSpec,bi.itemSpell,bi.packageId,bi.colorName,bi.sizeName,bi.unitName,
      bi.pkgRatio,bi.pkgUnit,a.unitLevel,a.putQty,a.ioState,
      CASE a.unitLevel WHEN 'CS' THEN ISNULL(a.putQty,0.0)*ISNULL(a.pkgRatio,0.0) ELSE a.putQty END AS realQty,
      a.putawayId,u1.userNick AS putawayName,CONVERT(VARCHAR(20),a.putawayTime,120) AS putawayTime,a.createTime,
      a.creatorId,u2.userNick AS creatorName,b.inputDate,b.productDate,b.expiryDate,b.batchNo,b.attribute01,
      b.attribute02,b.attribute03,b.attribute04,b.attribute05,sc.companyNo,sc.companyName,bp.partnerNo AS SupplierNo,
      bp.partnerId AS SupplierId,bp.partnerName AS SupplierName,ps.reason,ps.returnDate
FROM dbo.WMS_PutawayDetail a 
      INNER JOIN dbo.BAS_Item bi ON a.itemId=bi.itemId 
      LEFT JOIN dbo.SAD_Return AS ps ON a.stockNo=ps.returnNo
      LEFT JOIN dbo.BAS_Partner AS bp ON ps.customerId=bp.partnerId AND bp.partnerType=1
      LEFT JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
      LEFT JOIN (SELECT x.companyId,x.warehouseId,x.locationWay,x.locationRow,x.locationLayer,x.putawayOrder,
                       x.locationCol,x.locationNo,y.regionNo,y.regionDesc 
				 FROM dbo.BAS_Location x LEFT JOIN
				       dbo.BAS_Region y ON x.regionId=y.regionId
				) loc ON a.companyId=loc.companyId AND a.warehouseId=loc.warehouseId AND a.locationNo=loc.locationNo
      LEFT JOIN dbo.IMS_Batch b ON a.companyId=b.companyId AND a.lotNo=b.lotNo
      LEFT JOIN dbo.SAM_User u1 ON a.putawayId=u1.userId
      LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId
      LEFT JOIN SAM_Company AS sc ON a.companyId=sc.companyId

go

