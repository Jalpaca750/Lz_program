/*==============================================================*/
/* View: SAD_Stock_V                                            */
/*==============================================================*/
--creator：        WANG_Jun
--create time：  2016-11-06
--modify: Frank.He 2016-12-21日整理
--        Frank.He 2017-03-28 增加打印次数与打印人（最后一次）
--        Frank.He 2017-05-11 增加整单折扣等和对应视图
--		  Frank.He 2017-08-15 增加A单，拍照签收图片路径等字段（F10)
--		  Frank.He 2017-10-09 整合版本，增加自定义字段(苏州版用到客户资料TradeId字段，增加整单折扣率字段，其余为文之选版本增加（A单处理）和自定义字段）
--销售出库单列表
CREATE view [dbo].[SAD_Stock_V] as
SELECT a.stockNo,a.companyId,a.ownerId,o.ownerNo,o.ownerName,o.shortName AS ownerShortName,a.billNo,a.createTime,a.warehouseId,
      w.warehouseNo,w.warehouseName,a.ioType,CASE a.ioType WHEN 'S100' THEN '销售出库单' 
														   WHEN 'D200' THEN '调拨出库单' 
														   WHEN 'L100' THEN '领用出库单'
														   WHEN 'G200' THEN '赠品出库单'
														   WHEN 'B200' THEN '报损出库单'
													       WHEN 'O100' THEN '其他出库单'
														   END AS ioTypeName, 
      a.customerId,c.customerNo,c.customerName,c.shortName,c.customerSpell,c.tradeId,a.receiverState,
      a1.areaName AS receiverStateName,a.receiverCity, a2.areaName AS receiverCityName,a.receiverDistrict,
      a3.areaName AS receiverDistrictName,a.receiverAddress,a.receiverName,a.receiverTel,a.receiverMobile,
      ISNULL(a1.areaName,'')+ISNULL(a2.areaName,'')+ISNULL(a3.areaName,'') + ISNULL(a.receiverAddress,'') AS fullAddress,
      LTRIM(ISNULL(a.receiverMobile,'') + ' ' + ISNULL(a.receiverTel,'')) AS fullTel,a.lineId,l.lineCode,l.lineName,
      a.collectOrder,a.groupId,g.groupName,a.orderType,CASE a.orderType WHEN 10 THEN '普通订单' 
                                                                        WHEN 20 THEN '调拨申请' 
                                                                        WHEN 30 THEN '经营领用' 
                                                                        WHEN 31 THEN '管理领用' 
                                                                        WHEN 32 THEN '其他出库'
                                                                        WHEN 40 THEN '赠品出库' 
                                                                        WHEN 50 THEN '报损报废' END AS orderTypeName,
      a.payMode,a.settlementId,ISNULL(s.settlementName,a.settlementId) AS settlementName,
      CONVERT(VARCHAR(10),a.shipDate,23) AS shipDate,a.shipTime,a.currencyId, 
      a.exchangeRate,a.taxFlag,a.ioState,a.taskState,CASE a.taskState WHEN 10 THEN '已关闭'
																	  WHEN 20 THEN '已审核'
																	  WHEN 30 THEN '已排车'
																	  WHEN 40 THEN '待拣货'
																	  WHEN 50 THEN '待复核'
																	  WHEN 60 THEN '待打包'
																	  WHEN 70 THEN '待装车'
																	  WHEN 80 THEN '已装车'
																	  WHEN 90 THEN '已发货'
																	  WHEN 95 THEN '已妥投'
																	  WHEN 96 THEN '未送达'
																	  WHEN 99 THEN '已回单' END AS taskStateDesc,
      a.arState,a.totalFee,a.totalDiscount,a.discount,a.postFee,a.serviceFee,
      ISNULL(a.totalFee,0.0)+ISNULL(a.postFee,0.0)+ISNULL(a.serviceFee,0.0)-ISNULL(a.totalDiscount,0.0) AS arFee,a.payFee,
      b.stockQty,b.pkgQty,b.bulkQty,dbo.uf_GetMaximalBoxes(a.companyId,b.bulkVolumn) AS lclQty,b.pkgVolumn,b.bulkVolumn,
      dbo.uf_GetBulkVolumn(a.companyId,b.bulkVolumn) AS lclVolumn,b.bulkWeight,b.pkgWeight,a.orderSource,a.aFlag,a.aStockNo,
      a.buyerId,a.organizeId,a.poNo,a.salesId,ISNULL(e1.employeeName,a.salesId) AS salesName,a.handlerId,a.deptId,a.pickingId,
      CONVERT(VARCHAR(20),a.pickingTime,120) AS pickingTime,a.reviewerId,CONVERT(VARCHAR(20),a.reviewTime,120) AS reviewTime,
      a.deliveryId,u.userNick AS deliveryName,CONVERT(VARCHAR(20),a.deliveryTime,120) AS deliveryTime,a.signName,CONVERT(VARCHAR(20),a.signTime,120) AS signTime,
      a.signFile,a.undelivered,a.flag,a.expressNo,a.logisticsId,ISNULL(lgs.logisticsName,a.logisticsId) AS logisticsName,
      a.logisticsFee,a.buyerMessage,a.memo,a.isReceipt,CASE a.isReceipt WHEN 1 THEN '是' WHEN 0 THEN '否' END AS isReceiptDesc, 
      CONVERT(VARCHAR(20),a.receiptTime,120) AS receiptTime,a.backerId,u5.userNick AS backerName,a.mergeNo,
      a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5,a.lclCount,a.fclCount,b.skuCount,
      CONVERT(VARCHAR(20),a.thirdSyncTime,120) AS thirdSyncTime,a.thirdSyncFlag,a.printNum,a.printId,u4.userNick AS printMan,
      CONVERT(VARCHAR(20),a.printTime,120) AS printTime,a.creatorId,u1.userNick AS creatorName,a.auditorId,
      CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,a.isLocked,a.lockerId,u2.userNick AS lockerName,
      CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.editTime,a.editorId,u3.userNick AS editorName,a.isSelected
FROM dbo.SAD_Stock AS a 
      INNER JOIN (SELECT stockNo,SUM(stockQty) AS stockQty,SUM(pkgQty) AS pkgQty,SUM(bulkQty) AS bulkQty,SUM(pkgVolumn) AS pkgVolumn,
						SUM(bulkVolumn) AS bulkVolumn,SUM(bulkWeight) AS bulkWeight,SUM(pkgWeight) AS pkgWeight,COUNT(1) AS skuCount
                  FROM SAD_StockDetail
                  GROUP BY stockNo) b ON a.stockNo=b.stockNo 
      INNER JOIN dbo.BAS_Customer_V AS c ON a.customerId = c.customerId 
      INNER JOIN dbo.BAS_Owner_V o ON a.ownerId=o.ownerId
      LEFT JOIN dbo.BAS_Warehouse AS w ON a.warehouseId = w.warehouseId 
      LEFT JOIN dbo.BAS_Area AS a1 ON a.receiverState=a1.areaId 
      LEFT JOIN dbo.BAS_Area AS a2 ON a.receiverDistrict=a2.areaId 
      LEFT JOIN dbo.BAS_Area AS a3 ON a.receiverCity=a3.areaId 
      LEFT JOIN dbo.BAS_AddressLine AS l ON a.lineId = l.lineId 
      LEFT JOIN dbo.BAS_AddressGroup AS g ON a.groupId = g.groupId 
      LEFT JOIN dbo.BAS_Logistics AS lgs ON a.logisticsId = lgs.logisticsId 
      LEFT JOIN dbo.BAS_Settlement s ON a.settlementId=s.settlementId
      LEFT JOIN dbo.BAS_Employee e1 ON a.salesId=e1.employeeId
      LEFT JOIN dbo.SAM_User AS u ON a.deliveryId=u.userId
      LEFT JOIN dbo.SAM_User AS u1 ON a.creatorId = u1.userId 
      LEFT JOIN dbo.SAM_User AS u2 ON a.lockerId = u2.userId 
      LEFT JOIN dbo.SAM_User AS u3 ON a.editorId = u3.userId 
      LEFT JOIN dbo.SAM_User AS u4 ON a.printId=u4.userId 
      LEFT JOIN dbo.SAM_User AS u5 ON a.backerId=u5.userId

go

