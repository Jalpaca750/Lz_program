
/*==============================================================*/
/* View: SAD_OrderDetail_V                                      */
/*==============================================================*/
--creator：WANG_Jun
--create time：2016-11-06
--Modify：Frank 2016-12-21
--        Frank 2017-03-13 增加分拣模式pickingMode 0-自动;1-拆零;2-整件(提升前期实施准确性）
--		  Frank 2017-09-30 review数据库，去掉编码匹配等字段，增加自定义字段
--        Frank 2018-12-14 新增预占库存
--        Frank 2019-11-26 新增扩展字段06-09
--        Frank 2019-11-29 预占库存调整
--订单池明细视图
create view SAD_OrderDetail_V as
SELECT dtl.orderId,dtl.orderNo,dtl.companyId,dtl.viewOrder,ord.createTime,ord.billNo,ord.customerId,
	ord.ownerId,CONVERT(VARCHAR(10), ord.shipDate, 23) AS shipDate,dtl.warehouseId,bw.warehouseNo,bw.warehouseName,
	dtl.locationNo,dtl.eId,dtl.itemId,sku.itemNo,sku.itemName,sku.itemCTitle,sku.itemETitle,sku.sellingPoint,
	sku.itemSpell,sku.itemSpec,sku.barcode,sku.brandId,sku.brandNo,sku.brandCName,sku.categoryId,sku.categoryNo, 
	sku.categoryCName,sku.colorName,sku.sizeName,sku.unitName,sku.pkgUnit,sku.pkgRatio,dtl.orderQty,dtl.pkgQty, 
	dtl.bulkQty,dtl.befPrice,dtl.discount,dtl.discountFee,dtl.price,dtl.taxRate,dtl.fee,dtl.taxFee,dtl.totalFee,dtl.shipQty,
	ISNULL(dtl.orderQty, 0.0) - ISNULL(dtl.shipQty, 0.0) AS restQty,dtl.pkgQty*ISNULL(sku.pkgVolume,0.0) AS pkgVolumn,
	dtl.bulkQty*ISNULL(sku.itemVolume,0.0) AS bulkVolumn,ISNULL(inv.onhandQty,0.0)-ISNULL(inv.allocQty,0.0) AS availQty,
	ISNULL(inv.onhandQty,0.0)-ISNULL(inv.allocQty,0.0)-(ISNULL(dtl.orderQty, 0.0) - ISNULL(dtl.shipQty, 0.0)) AS ableQty,
	(SELECT SUM(AdvQty) FROM IMS_Advance WHERE dtl.warehouseId=warehouseId AND dtl.itemId=itemId AND dtl.orderId!=orderId) AS advQty,
	dtl.rebate,dtl.toOrder,dtl.updPrice,dtl.isPromotion,dtl.isGift,dtl.isVirtual,dtl.groupId,dtl.needAssemble,dtl.isRed,
	CASE dtl.isRed WHEN 1 THEN '红冲' ELSE '正常' end as isRedName,dtl.stockQty,(dtl.stockQty-dtl.orderQty) AS redQty,
	dtl.contractId,dtl.contractNo,dtl.salesId,dtl.handlerId,dtl.deptId,sku.webPrice,sku.marketPrice,sku.vipPrice,
	sku.retailPrice,sku.tradePrice,sku.salesPrice,sku.minPrice,sku.purPrice,sku.lastPurPrice,sku.isUnsalable,sku.isStop,
	sku.pickingMode,sku.itemState,sku.commodityId,sku.itemVolume,sku.itemWeight,sku.pkgWeight,sku.pkgVolume,
	sku.inventoryMode,sku.pkgBarcode,sku.packageId,dtl.imageUrl,dtl.boneOrdId,dtl.ordDtlEx01,dtl.ordDtlEx02,
	dtl.ordDtlEx03,dtl.ordDtlEx04,dtl.ordDtlEx05,dtl.ordDtlEx06,dtl.ordDtlEx07,dtl.ordDtlEx08,dtl.ordDtlEx09,
	CASE ISNULL(adv.advanceId,'') WHEN '' THEN 0 ELSE 1 END AS advFlag,ISNULL(adv.purQty,0.0)+ISNULL(adv.realQty,0.0) AS preQty,
	ISNULL(dl.onhandQty,0.0)-isnull(dl.allocQty,0.0) vcanuseqty,dtl.remarks,dtl.isSelected
FROM dbo.SAD_OrderDetail AS dtl 
	INNER JOIN dbo.SAD_Order AS ord ON dtl.orderNo = ord.orderNo 
	INNER JOIN dbo.BAS_Goods_V AS sku ON dtl.itemId = sku.itemId	
	LEFT JOIN dbo.IMS_Ledger inv ON dtl.warehouseId=inv.warehouseId AND dtl.itemId=inv.itemId
	LEFT JOIN dbo.IMS_DeptLedger dl ON dtl.deptId=dl.deptId AND dtl.itemId=dl.itemId
	LEFT JOIN BAS_Warehouse bw ON dtl.warehouseId=bw.warehouseId
	LEFT JOIN dbo.IMS_Advance adv ON dtl.orderId=adv.orderId
go

