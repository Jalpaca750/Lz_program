CREATE PROCEDURE [dbo].[up_OrderSplit]
(
	@orderNo VARCHAR(32),						--拆单单号
	@details Type_SAD_OrderDetail READONLY,		--拆单明细
	@companyId VARCHAR(32),						--公司Id
	@operatorId VARCHAR(32),					--操作员
	@errMsg VARCHAR(2000) OUTPUT                --错误消息	
)
AS
BEGIN
	DECLARE @orderId VARCHAR(32);				--订单明细Id
    DECLARE @orderBillNo VARCHAR(32);			--订单编号
    DECLARE @warehouseId VARCHAR(32);           --发货仓库
    DECLARE @stockId VARCHAR(32);				--出库单明细Id
    DECLARE @stockNo VARCHAR(32);				--出库单编号
    DECLARE @stockBillNo VARCHAR(32);			--出库单号
    DECLARE @mergeNo VARCHAR(1000);				--合并出库单号
    DECLARE @lineId VARCHAR(32);				--送货线路
    DECLARE @ioType VARCHAR(32);				--入出库类型
    DECLARE @aFlag INT;							--A单标识:
    DECLARE @sdState INT;						--订单状态:0-关闭交易;10-待审核;15,部分审核;20,已审核;25-部分下达;30-已下达
    DECLARE @taskState INT;						--任务状态：20-审核，30-已排车（已排线）；70-已打包
    DECLARE @isTogether INT;					--发货方式：1-货齐一起送;0-有货先送	
    DECLARE @handleId VARCHAR(32);				--经手人Id
    DECLARE @deptId VARCHAR(32);				--部门Id
    DECLARE @createTime DATETIME;				--制单时间
    DECLARE @memo VARCHAR(2000);				--备注	
	DECLARE @orderShipTime VARCHAR(100);		--1,波次计划前装车;2-打包完成后装车
    DECLARE @ownerId VARCHAR(32);
    DECLARE @tmpNo VARCHAR(32);
    DECLARE @tmpBillNo VARCHAR(32);
    DECLARE @tmpBoneNo VARCHAR(32);
    DECLARE @virtualStore VARCHAR(100);         --1,启动虚拟化仓库功能;0-不启动;
    DECLARE @start2F10 VARCHAR(100);            --1，对接F10接口开启;0-无F10接口   
    DECLARE @errors BIGINT;                     --错误代码
	--临时表
	DECLARE @tmpAble TABLE(orderNo VARCHAR(32),warehouseId VARCHAR(32),itemId VARCHAR(32),itemNo VARCHAR(32),restQty DECIMAL(20,6),availQty DECIMAL(20,6));
	DECLARE @tmpPre TABLE(orderNo VARCHAR(32),warehouseId VARCHAR(32),itemId VARCHAR(32),itemNo VARCHAR(32),restQty DECIMAL(20,6),advQty DECIMAL(20,6),availQty DECIMAL(20,6));
	DECLARE @tmpVirtual TABLE(companyId VARCHAR(32),deptId VARCHAR(32),itemId VARCHAR(32),itemNo VARCHAR(32),restQty DECIMAL(20,6),advQty DECIMAL(20,6),availQty DECIMAL(20,6));
	SET @createTime=GETDATE();	
	SET @errMsg='';
	SET @errors=0;	
	--清除错误日志
	DELETE FROM SAM_Error WHERE companyId=@companyId AND funCode='up_OrderSplit' AND creatorId=@operatorId;
	--是否开启和WMS的接口
	SELECT @start2F10=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='WITH_F10_INTERFACE_START';
	--1-启动虚拟化仓库功能;0不启动
	SELECT @virtualStore=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='VIRTUALIZATION_WAREHOUSE';
	--装车时机：1,波次计划前装车;2-打包完成后装车
	SELECT @orderShipTime=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='ORDER_SHIP_TIME';
	SET @orderShipTime=ISNULL(@orderShipTime,'1');
	SET @virtualStore=ISNULL(@virtualStore,'0')
	SET @start2F10=ISNULL(@start2F10,'0');
	BEGIN TRY
		BEGIN TRANSACTION
		--排队等待
        WHILE EXISTS(SELECT * FROM dbo.SAM_Schedule WHERE jobCode='so_audit_job' AND IsLocked=1)
        BEGIN
            SET @errors=0;
        END
        UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='up_OrderSplit',lockedTime=@createTime,lockerID=@operatorId WHERE jobCode='so_audit_job';
		--订单不存在
		IF NOT EXISTS(SELECT * FROM dbo.SAD_Order WHERE orderNo=@orderNo)
		BEGIN
			ROLLBACK;
		    SET @errMsg='订单已取消或者被拦截，操作无效!';
			RETURN;
		END		
		--非当前用户锁定数据不能进行预分配处理，避免重复
		IF NOT EXISTS(SELECT * FROM dbo.SAD_Order WHERE orderNo=@orderNo AND isLocked=1 AND lockerId=@operatorId)
		BEGIN
			ROLLBACK;
		    SET @errMsg='订单被其他人锁定，操作无效!';
			RETURN;
		END
		--订单编号
		--orderType:10-销售订单;20调拨订单 对应 S100-销售出库单;D200-调拨出库单;L100-领用出库单;G200-赠品出库单;B200-报损报废;O100-其他出库单
		SELECT @orderBillNo=billNo,@ioType=CASE orderType WHEN 10 THEN 'S100'
														  WHEN 20 THEN 'D200'
														  WHEN 30 THEN 'L100' 
														  WHEN 31 THEN 'L100' 
														  WHEN 32 THEN 'O100' 
														  WHEN 33 THEN 'SP100'      --上房项目
														  WHEN 34 THEN 'SW100'      --上房项目
														  WHEN 35 THEN 'SX100'      --上房项目
														  WHEN 36 THEN 'SH100'      --上房项目
														  WHEN 37 THEN 'SZ100'      --上房项目
														  WHEN 40 THEN 'G200'
														  WHEN 50 THEN 'B200' END,@warehouseId=warehouseId,
			--波次计划前装车，任务状态为20-待装车；打包完装车则有送货线路的直接30已装车，没有则20-待装车
			--主要用于不排车直接配货完装车
			@taskState=CASE ISNULL(@orderShipTime,'1') WHEN '1' THEN 20 ELSE CASE ISNULL(lineId,'') WHEN '' THEN 20 ELSE 30 END END,
			@sdState=sdState,@isTogether=isTogether,@aFlag=ISNULL(aFlag,0),@lineId=lineId,@handleId=handlerId,@deptId=deptId,@memo=memo
		FROM dbo.SAD_Order
		WHERE orderNo=@orderNo;
		--可用量
	    INSERT INTO @tmpAble(orderNo,warehouseId,itemId,itemNo,restQty,availQty)
	    SELECT dtl.orderNo,dtl.warehouseId,dtl.itemId,dtl.itemNo,dtl.restQty,
	        ISNULL(inv.onhandQty,0.0)-ISNULL(inv.allocQty,0.0) AS availQty
        FROM (SELECT a.orderNo,a.warehouseId,a.itemId,c.itemNo,SUM(a.orderQty) AS restQty
              FROM @details a
                  INNER JOIN BAS_Item c ON a.itemId=c.itemId
              WHERE (a.orderNo=@orderNo)
                  AND (ISNULL(c.isVirtual,0)=0)
                  AND (ISNULL(a.orderQty, 0.0)>0.0)
              GROUP BY a.orderNo,a.warehouseId,a.itemId,c.itemNo) dtl
            LEFT JOIN dbo.IMS_Ledger inv ON dtl.warehouseId=inv.warehouseId AND dtl.itemId=inv.itemId;
        --可用量(带预占)
	    INSERT INTO @tmpPre(orderNo,warehouseId,itemId,itemNo,restQty,availQty,advQty)
	    SELECT dtl.orderNo,dtl.warehouseId,dtl.itemId,dtl.itemNo,dtl.restQty,
            ISNULL(inv.onhandQty,0.0)-ISNULL(inv.allocQty,0.0) AS availQty,
            (SELECT SUM(realQty) FROM IMS_Advance WHERE warehouseId=dtl.warehouseId AND itemId=dtl.itemId AND orderNo!=@orderNo) AS advQty
        FROM (SELECT a.orderNo,a.warehouseId,a.itemId,c.itemNo,SUM(a.orderQty) AS restQty
              FROM @details a
                  INNER JOIN BAS_Item c ON a.itemId=c.itemId
              WHERE (a.orderNo=@orderNo)
                  AND (ISNULL(c.isVirtual,0)=0)
                  AND (ISNULL(a.orderQty, 0.0)>0.0)
                  AND (a.orderId NOT IN(SELECT orderId FROM IMS_Advance WHERE orderNo=@orderNo))
              GROUP BY a.orderNo,a.warehouseId,a.itemId,c.itemNo) dtl
            LEFT JOIN dbo.IMS_Ledger inv ON dtl.warehouseId=inv.warehouseId AND dtl.itemId=inv.itemId;
        --订单已被关闭
		IF (@sdState=0)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单已关闭，操作无效!';
			RETURN;
		END
		--订单已终止
		IF (@sdState=15)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单已终止，操作无效!';
			RETURN;
		END		
		--订单已审核
		IF (@sdState=20)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单已审核，操作无效!';
			RETURN;
		END
		--订单已下达
		IF (@sdState=30)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单已审核，操作无效!';
			RETURN;
		END
		--未分配送货线路
		IF ISNULL(@lineId,'')=''
		BEGIN
			ROLLBACK;
		    SET @errMsg='订单尚未设置配送线路，操作无效!';	    
			RETURN;
		END
		IF (ISNULL(@aFlag,0)=2)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='A单不允许拆单发货，操作无效!';	    
			RETURN;
		END
		IF (ISNULL(@aFlag,0)=3)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='直送订单不允许拆单发货，操作无效!';	    
			RETURN;
		END
		--和F10对接则不允许其他出库单，赠品出库单等拆单(L100-领用出库单;G200-赠品出库单;B200-报损报废;O100-其他出库单)
		IF (@start2F10='1')
	    BEGIN
	        IF (@ioType='L100' OR @ioType='G200' OR @ioType='B200' OR @ioType='O100')
	        BEGIN
	            ROLLBACK;
		        SET @errMsg='其他出库单(赠品/领用/报损/其他)不允许拆单发货，操作无效!';
			    RETURN;
	        END
	    END
		--检查是否有明细数据
		IF NOT EXISTS(SELECT * FROM @tmpAble)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='没有需要配货的明细商品，操作无效!';
			RETURN;
		END
		--检查商品单个体积与重量
	    IF EXISTS(SELECT * FROM BAS_Item WHERE itemId=ANY(SELECT itemId FROM @tmpAble) AND (ISNULL(itemVolume,0.0)=0.0 OR ISNULL(pkgRatio,0)=0 OR ISNULL(itemWeight,0.0)=0.0) AND ISNULL(isVirtual,0)=0) 
	    BEGIN
	        ROLLBACK;
	        SELECT TOP 1 @errMsg='商品['+itemNo+']整箱数量、单位体积或者重量设置不全，操作无效!' 
	        FROM BAS_Item 
	        WHERE itemId=ANY(SELECT itemId FROM @tmpAble) AND (ISNULL(itemVolume,0.0)=0.0 OR ISNULL(pkgRatio,0)=0 OR ISNULL(itemWeight,0.0)=0.0) AND ISNULL(isVirtual,0)=0
            RETURN;
	    END
	    --提示自拆分商品未设置拆分数量
	    IF EXISTS(SELECT * FROM BAS_Item WHERE itemId IN(SELECT itemId FROM @tmpAble) AND allowSplit=2 AND splitRatio=0 AND ISNULL(isVirtual,0)=0)
	    BEGIN
	        ROLLBACK;
	        SELECT TOP 1 @errMsg='商品['+itemNo+']自拆分参数设置错误，操作无效!'
	        FROM BAS_Item
	        WHERE itemId IN(SELECT itemId FROM @tmpAble) AND allowSplit=2 AND splitRatio=0 AND ISNULL(isVirtual,0)=0;
	        RETURN;
		END  
	    --库存可用量不够
	    IF EXISTS(SELECT * FROM @tmpAble WHERE ISNULL(availQty,0.0)-ISNULL(restQty,0.0)<0)
	    BEGIN
	        ROLLBACK;
	        SELECT TOP 1 @errMsg='商品['+bi.itemNo+']库存可用量不满足订单发货数量，操作无效!'
	        FROM @tmpAble a
	            INNER JOIN BAS_Item bi ON a.itemId=bi.itemId
	        WHERE a.orderNo=@orderNo AND ISNULL(a.availQty,0.0)-ISNULL(a.restQty,0.0)<0.0;
		    RETURN;
	    END	    
	    --有预占库存的，则库存占用+采购占用-订单发货量必须>0
	    IF EXISTS(SELECT * FROM IMS_Advance a INNER JOIN @details b ON a.orderId=b.orderId WHERE ISNULL(a.purQty,0.0)+ISNULL(a.realQty,0.0)-ISNULL(b.orderQty,0.0)<0.0)
        BEGIN
            ROLLBACK;
            SELECT TOP 1 @errMsg='商品['+bi.itemNo+']预占库存尚未采购入库，操作无效!'
            FROM IMS_Advance a 
                INNER JOIN @details b ON a.orderId=b.orderId
                INNER JOIN BAS_Item bi ON a.itemId=bi.itemId
            WHERE a.orderNo=@orderNo AND ISNULL(a.purQty,0.0)+ISNULL(a.realQty,0.0)-ISNULL(b.orderQty,0.0)<0.0;
	        RETURN;
        END
        --无预占库存的，则需要判断是否被别的订单占用
        IF EXISTS(SELECT * FROM @tmpPre WHERE ISNULL(availQty,0.0)-ISNULL(advQty,0.0)-ISNULL(restQty,0.0)<0)
        BEGIN
            ROLLBACK;
            SELECT TOP 1 @errMsg='商品['+bi.itemNo+']被其他订单预占，不满足订单发货数量，操作无效!'
            FROM @tmpAble a
                INNER JOIN BAS_Item bi ON a.itemId=bi.itemId
            WHERE a.orderNo=@orderNo AND ISNULL(a.availQty,0.0)-ISNULL(a.restQty,0.0)<0.0;
            RETURN;
        END
        --定制品没有库存不予许审核
		IF EXISTS(SELECT * FROM dbo.SAD_OrderDetail a INNER JOIN @details c ON a.orderId=c.orderId LEFT JOIN dbo.PMS_PurToOrder_V b ON a.contractId=b.sdOrderId WHERE a.orderNo=@orderNo AND ISNULL(a.toOrder,0)=1 AND ISNULL(c.orderQty,0.0)-ISNULL(b.orderQty,0.0)>0.0)
		BEGIN
		    ROLLBACK;
	        SET @errMsg='定制品没有足够的库存，操作无效!';
	        UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
		    RETURN;
		END
        
	    --虚拟仓库可用量不够（启动虚拟仓库与虚拟仓库配置)
	    IF (ISNULL(@virtualStore,'0')='1' AND EXISTS(SELECT * FROM  IMS_DeptLedger_MAP WHERE companyId=@companyId AND warehouseId=@warehouseId AND IsDisable=0))
	    BEGIN
	        INSERT INTO @tmpVirtual(companyId,deptId,itemId,itemNo,restQty,availQty)
            SELECT dtl.companyId,dtl.deptId,dtl.itemId,dtl.itemNo,dtl.restQty,
                ISNULL(inv.onhandQty,0.0)-ISNULL(inv.allocQty,0.0) AS availQty            
            FROM (SELECT b.companyId,b.orderNo,b.deptId,a.itemId,c.itemNo,SUM(ISNULL(a.orderQty,0.0)) AS restQty
                  FROM @details a
                      INNER JOIN SAD_Order b ON a.orderNo=b.orderNo
                      INNER JOIN BAS_Item c ON a.itemId=c.itemId
                  WHERE (ISNULL(c.isVirtual,0)=0)
                      AND (ISNULL(a.orderQty, 0.0)>0.0)
                  GROUP BY b.companyId,b.orderNo,b.deptId,a.itemId,c.itemNo) dtl
                LEFT JOIN dbo.IMS_DeptLedger inv ON dtl.companyId=inv.companyId AND dtl.deptId=inv.deptId AND dtl.itemId=inv.itemId;
            --判断虚拟仓可用量是否足够
            IF EXISTS(SELECT * FROM @tmpVirtual WHERE ISNULL(availQty,0.0)-ISNULL(restQty,0.0)<0.0)
            BEGIN
                ROLLBACK;
                SELECT TOP 1 @errMsg='商品['+itemNo+']虚拟库存可用量不足，操作无效!'
                FROM @tmpVirtual 
                WHERE ISNULL(availQty,0.0)-ISNULL(restQty,0.0)<0.0;
	            RETURN;
            END	    
	    END
        --生成销售出库单
		--出库单No
		SET @stockNo=LOWER(REPLACE(NEWID(),'-',''));
		--出库单编号(调拨出库单、销售出库单、其他出库单、赠品出库单、报损出库单）
		IF (@ioType='D200')
			EXEC up_CreateCode @companyId,'IMS_Allot',@operatorId,@stockBillNo OUTPUT;
		ELSE IF(@ioType='L100' OR @ioType='B200' OR @ioType='G200' OR @ioType='O100')
			SET @stockBillNo=@orderBillNo;
		ELSE
			EXEC up_CreateCode @companyId,'SAD_Stock',@operatorId,@stockBillNo OUTPUT;
		--检查商品单个体积与重量
		IF ISNULL(@stockBillNo,'')=''
		BEGIN
			ROLLBACK;
	        SET @errMsg='系统繁忙，生成单号失败，操作无效!';
		    RETURN;
		END
		--主表
		INSERT INTO dbo.SAD_Stock(stockNo,companyId,ownerId,billNo,createTime,warehouseId,ioType,customerId,
			  addressId,receiverState,receiverCity,receiverDistrict,receiverAddress,lineId,groupId,receiverName,
			  receiverTel,receiverMobile,orderType,payMode,settlementId,shipDate,shipTime,currencyId,exchangeRate,
			  taxFlag,ioState,taskState,arState,totalFee,totalDiscount,serviceFee,postFee,payFee,orderSource,
			  buyerId,organizeId,poNo,salesId,handlerId,deptId,flag,expressNo,logisticsId,logisticsFee,buyerMessage,
			  memo,mergeNo,collectOrder,aFlag,aStockNo,ordField1,ordField2,ordField3,ordField4,ordField5,
			  creatorId,isLocked,lockerId,lockedTime,editTime,editorId)
		SELECT @stockNo,@companyId,ownerId,@stockBillNo,GETDATE(),warehouseId,@ioType,customerId,
			  addressId,receiverState,receiverCity,receiverDistrict,receiverAddress,lineId,groupId,receiverName,
			  receiverTel,receiverMobile,orderType,payMode,settlementId,shipDate,shipTime,currencyId,exchangeRate,
			  taxFlag,10 AS ioState,@taskState,arState,totalFee,totalDiscount,serviceFee,postFee,payFee,orderSource,
			  buyerId,organizeId,poNo,salesId,handlerId,deptId,flag,expressNo,logisticsId,logisticsFee,buyerMessage,
			  memo,billNo AS mergeNo,1 AS collectOrder,aFlag,aOrderNo,ordField1,ordField2,ordField3,ordField4,ordField5,
			  @operatorId,0 AS isLocked,'' AS lockerId,NULL AS lockedTime,GETDATE(),@operatorId
		FROM dbo.SAD_Order
		WHERE orderNo=@orderNo;
		--明细表
		INSERT INTO dbo.SAD_StockDetail(stockId,stockNo,orderId,orderNo,orderBillNo,companyId,warehouseId,
			  viewOrder,lotNo,locationNo,eId,itemId,stockQty,pkgQty,bulkQty,pkgVolumn,bulkVolumn,pkgWeight,
			  bulkWeight,befPrice,discount,discountFee,price,taxrate,fee,taxFee,totalFee,toOrder,updPrice,
			  isPromotion,isGift,isVirtual,needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
			  contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,pickQty,remarks)
		SELECT stockId,@stockNo AS stockNo,orderId,orderNo,orderBillNo,companyId,warehouseId,viewOrder,
			  lotNo,locationNo,eId,itemId,stockQty,pkgQty,bulkQty,pkgQty*pkgVolume AS pkgVolumn,
			  bulkQty*itemVolume AS bulkVolumn,pkgWeight*pkgQty AS pkgWeight,bulkQty*itemWeight AS bulkWeight,
			  befPrice,discount,discountFee,price,taxrate,fee,totalFee-fee AS taxFee,totalFee,toOrder,updPrice,
			  isPromotion,isGift,isVirtual,needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
			  contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,0,remarks
		FROM (
			  SELECT LOWER(REPLACE(NEWID(),'-','')) AS stockId,a.orderId,a.orderNo,h.billNo AS orderBillNo,a.companyId,
					a.warehouseId,ROW_NUMBER() OVER (ORDER BY a.viewOrder) AS viewOrder,'' AS lotNo,a.locationNo,a.eId,
					a.itemId,b.orderQty AS stockQty,FLOOR(b.orderQty/c.pkgRatio) AS pkgQty,(b.orderQty%c.pkgRatio) AS bulkQty,
					a.befPrice,a.discount,a.discountFee,a.price,a.taxRate,CAST(b.orderQty*a.price/(1+a.taxrate/100.0) AS DECIMAL(20,2)) AS fee,
					CAST(b.orderQty*a.price AS DECIMAL(20,2)) AS totalFee,a.rebate,a.toOrder,a.updPrice,a.isPromotion,a.isGift,
					a.needAssemble,a.groupId,a.contractId,a.contractNo,a.salesId,a.handlerId,a.deptId,a.isVirtual,c.itemVolume,
					c.itemWeight,c.pkgWeight,c.pkgVolume,a.boneOrdId,a.ordDtlEx01,a.ordDtlEx02,a.ordDtlEx03,a.ordDtlEx04,a.ordDtlEx05,
					a.remarks
			  FROM dbo.SAD_OrderDetail a
					INNER JOIN @details b ON a.orderId=b.orderId
					INNER JOIN dbo.BAS_Item c ON a.itemId=c.itemId
					INNER JOIN dbo.SAD_Order h ON a.orderNo=h.orderNo
			  WHERE ISNULL(b.orderQty,0.0)>0.0
			  ) t;
		--回写订单已发货数据（预分配）	  
		UPDATE a SET a.shipQty=ISNULL(a.shipQty,0.0)+ISNULL(b.shipQty,0.0)
		FROM dbo.SAD_OrderDetail a 
			INNER JOIN (SELECT orderId,SUM(stockQty) AS shipQty
					    FROM dbo.SAD_StockDetail
					    WHERE stockNo=@stockNo
					    GROUP BY orderId) b ON a.orderId=b.orderId;
		--如果写入发货单后，订单分配数量大于了订单应该的分配数量，则返回提示
		IF EXISTS(SELECT * FROM dbo.SAD_OrderDetail WHERE orderNo=@orderNo AND ISNULL(shipQty,0.0)-ISNULL(orderQty,0.0)>0.0)
		BEGIN
		    ROLLBACK;
	        SET @errMsg='订单发货数量大于订单数量，操作无效!';
		    RETURN;		
		END
		--更新出库单总金额
		UPDATE a SET a.totalFee=b.totalFee
		FROM dbo.SAD_Stock a 
			INNER JOIN (SELECT stockNo,SUM(totalFee) AS totalFee 
						FROM dbo.SAD_StockDetail 
						WHERE stockNo=@stockNo
						GROUP BY stockNo) b ON a.stockNo=b.stockNo
		WHERE a.stockNo=@stockNo;
		--更新IMS_Ledger表已分配量
		UPDATE a SET a.allocQty=ISNULL(a.allocQty,0.0)+ISNULL(b.allocQty,0.0)
		FROM dbo.IMS_Ledger a
			INNER JOIN (SELECT companyId,warehouseId,itemId,SUM(stockQty) AS allocQty
						FROM dbo.SAD_StockDetail
						WHERE stockNo=@stockNo AND isVirtual=0
						GROUP BY companyId,warehouseId,itemId
						) b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId
		INSERT INTO dbo.IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty)
		SELECT LOWER(REPLACE(NEWID(),'-','')),companyId,warehouseId,eId,itemId,0.0 AS onhandQty,allocQty
		FROM (SELECT companyId,warehouseId,eId,itemId,SUM(stockQty) AS allocQty
			  FROM dbo.SAD_StockDetail
			  WHERE stockNo=@stockNo AND isVirtual=0
			  GROUP BY companyId,warehouseId,eId,itemId
			 ) a 
		WHERE NOT EXISTS(SELECT * FROM dbo.IMS_Ledger b WHERE a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId);
        --虚拟库存表
	    IF (ISNULL(@virtualStore,'0')='1' AND EXISTS(SELECT * FROM  IMS_DeptLedger_MAP WHERE companyId=@companyId AND warehouseId=@warehouseId AND IsDisable=0))
	    BEGIN
		    UPDATE a SET a.allocQty=ISNULL(a.allocQty,0.0)+ISNULL(b.allocQty,0.0)
		    FROM dbo.IMS_DeptLedger a
			    INNER JOIN (SELECT x.companyId,x.deptId,y.itemId,SUM(y.stockQty) AS allocQty
						    FROM dbo.SAD_Stock x 
						        INNER JOIN dbo.SAD_StockDetail y ON x.stockNo=y.stockNo
						    WHERE x.stockNo=@stockNo AND y.isVirtual=0
						    GROUP BY x.companyId,x.deptId,y.itemId
						    ) b ON a.companyId=b.companyId AND a.deptId=b.deptId AND a.itemId=b.itemId
		    INSERT INTO IMS_DeptLedger(ledgerId,companyId,deptId,eId,itemId,onhandQty,allocQty)
		    SELECT LOWER(REPLACE(NEWID(),'-','')),companyId,deptId,eId,itemId,0.0 AS onhandQty,allocQty
		    FROM (SELECT x.companyId,x.warehouseId,x.deptId,y.eid,y.itemId,SUM(y.stockQty) AS allocQty
			      FROM dbo.SAD_Stock x 
			          INNER JOIN dbo.SAD_StockDetail y ON x.stockNo=y.stockNo
			      WHERE x.stockNo=@stockNo AND y.isVirtual=0
			      GROUP BY x.companyId,x.warehouseId,x.deptId,y.eid,y.itemId
			     ) a 
		    WHERE NOT EXISTS(SELECT * FROM dbo.IMS_DeptLedger b WHERE a.companyId=b.companyId AND b.deptId=b.deptId AND a.itemId=b.itemId);
		END
        --修改订单状态
		--订单全部进入待配货表
		IF NOT EXISTS(SELECT 1 FROM dbo.SAD_OrderDetail WHERE orderNo=@orderNo AND ISNULL(orderQty,0.0)-ISNULL(shipQty,0.0)>0.0)
		BEGIN
			UPDATE dbo.SAD_Order SET msgText='',isLocked=0,lockerId='',sdState=30,taskState=20,editTime=@createTime,editorId=@operatorId WHERE orderNo=@orderNo;
			IF (@start2F10='1')
			    EXEC (N'UPDATE F10BMS.dbo.SMS_Order SET WmsFlag=''已下达'' WHERE OrderNo=''' + @orderBillNo + ''';')
		END
		ELSE
		BEGIN
			UPDATE dbo.SAD_Order SET msgText='',isLocked=0,lockerId='',sdState=25,taskState=15,editTime=@createTime,editorId=@operatorId WHERE orderNo=@orderNo;
			IF (@start2F10='1')
			    EXEC (N'UPDATE F10BMS.dbo.SMS_Order SET WmsFlag=''部分下达'' WHERE OrderNo=''' + @orderBillNo + ''';')
		END
		--释放订单预占库存
		UPDATE a SET a.advQty =ISNULL(a.advQty,0.0)-ISNULL(b.stockQty,0),
		             a.realQty=ISNULL(a.realQty,0.0)-ISNULL(b.stockQty,0)
		FROM dbo.IMS_Advance a
		    INNER JOIN dbo.SAD_StockDetail b ON a.orderId=b.orderId
		WHERE b.stockNo=@stockNo;
		DELETE FROM dbo.IMS_Advance WHERE orderNo=@OrderNo AND ISNULL(advQty,0.0)<=0.0;
		--写入订单配送节点表(和Bone平台表对应）
		INSERT INTO SAD_OrderAction(stepId,orderNo,orderBillNo,stockNo,wmsStockNo,stockBillNo,[action],actionDesc,actionTime,companyId,ownerId,thirdSyncFlag)
		SELECT LOWER(REPLACE(NEWID(),'-','')),ordField2,billNo,orderNo,@stockNo,@stockBillNo,3,'您的订单已通过仓库审核，等待分拣',GETDATE(),companyId,ownerId,0
		FROM dbo.SAD_Order a
		WHERE orderNo=@orderNo
			AND NOT EXISTS(SELECT * FROM dbo.SAD_OrderAction b WHERE b.stockNo=@orderNo AND b.wmsStockNo=@stockNo AND b.action=3);
		--释放锁
		UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='so_audit_job';
		COMMIT;		
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		SELECT @errMsg = ERROR_MESSAGE();		
        UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;		
	    RETURN -1;				
	END CATCH
END
go

