

/*==============================================================*/
/* View: API_CGRK_MX   @zdy create at:2020-07-08     采购回传明细表  
-- 2020年11月2日 新增 befPrice 字段                         */
/*==============================================================*/
CREATE VIEW  [dbo].[API_CGRK_MX]
AS
SELECT A.stockNo PKID,y.ownerNo AS YEZ_ID,x.billNo AS DANJ_NO,x.mergeNo AS SHANGJ_DANJ_NO,a.viewOrder AS linenum,
      bi.itemNo AS itemcode,a.receiveQty AS quantity,a.price,a.befPrice,a.totalFee AS linetotal,od.viewOrder AS HANGHAO,
      w.warehouseNo as WHNO,a.remarks lineNote,a.ordDtlEx01,a.ordDtlEx02,a.ordDtlEx03,a.ordDtlEx04,a.ordDtlEx05
FROM dbo.PMS_StockDetail a INNER JOIN  dbo.PMS_Stock x ON  a.stockNo=x.stockNo
     INNER JOIN  BAS_Owner_V y ON x.ownerId=y.ownerId
     INNER JOIN dbo.PMS_OrderDetail od ON a.orderId=od.orderId 
     INNER JOIN  dbo.BAS_Item bi ON a.itemId=bi.itemId
     INNER JOIN BAS_Warehouse W on a.warehouseId=W.warehouseId
 WHERE  (x.ioState=30) AND (x.thirdSyncFlag=0 OR x.thirdSyncFlag=2)


go

