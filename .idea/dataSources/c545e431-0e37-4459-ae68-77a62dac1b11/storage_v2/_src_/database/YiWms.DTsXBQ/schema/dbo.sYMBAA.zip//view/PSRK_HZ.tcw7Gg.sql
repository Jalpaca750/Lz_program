/*==============================================================*/
/* View: PSRK_HZ                                                */
/*==============================================================*/
CREATE view [dbo].[PSRK_HZ] as
SELECT o.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,CONVERT(VARCHAR(10),a.auditTime,23) AS docdate,a.memo AS comments,
      u.userNo AS U_opcode,u.userNick AS U_OPNAME,'调拨入库单' AS YEW_TYPE,a.thirdSyncFlag AS SC_FLG,
      w.warehouseNo AS whNo,a.mergeNo
FROM dbo.PMS_Stock a INNER JOIN
      dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId 
      LEFT JOIN
      dbo.BAS_Owner_V o ON a.ownerId=o.ownerId LEFT JOIN 
      dbo.SAM_User u ON a.creatorId=u.userId
WHERE (a.ioType='D100') AND (a.ioState=30) AND (a.thirdSyncFlag=0 or a.thirdSyncFlag=2)
go

