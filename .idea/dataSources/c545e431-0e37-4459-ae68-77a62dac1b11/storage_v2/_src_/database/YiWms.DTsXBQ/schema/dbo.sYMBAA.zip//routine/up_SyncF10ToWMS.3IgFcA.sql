

CREATE PROCEDURE [dbo].[up_SyncF10ToWMS]
AS
BEGIN
	DECLARE @companyId VARCHAR(32),			--公司Id
			@ownerId VARCHAR(32),			--业主Id
			@warehouseId VARCHAR(32),		--仓库Id
			@creatorId VARCHAR(32),			--操作员Id	
			@curTime DATETIME;				--操作时间 
	--固定公司Id,业主Id,仓库Id和当前时间
	SELECT @companyId=companyId,@ownerId=ownerId FROM dbo.SAM_Store WHERE appUrl='up_SyncF10ToWMS';
	SELECT @creatorId=userId FROM dbo.SAM_User WHERE userNo='SYNC01';						
	SET @curTime=GETDATE();
	--同步基础数据
	EXEC up_SyncF10Basic; 
	--同步出库数据到WMS
	EXEC up_SyncF10SalesOrder @companyId,@ownerId,@creatorId,@curTime,@curTime;
	--同步入库数据到WMS
	EXEC up_SyncF10ReceivedOrder @companyId,@ownerId,@creatorId,@curTime,@curTime;
END



go

