

/*
  审核调整单据
*/
CREATE Proc  [dbo].[proc_Audit_Adjust]
(
   @adjustNo  varchar(32),--调整单单号
   @operatorId varchar(32)--操作人
)
as begin  tran
--------------------------------------------------------------------------定义游标---------------------------
declare    FMyCursor  cursor   FOR 
select adjustId,viewOrder,warehouseId,lotNo,locationNo,eId,itemId,
unitId,ioQty,pkgQty,bulkQty,fee,totalFee,remarks
FROM IMS_AdjustDetail where adjustNo=@adjustNo order by viewOrder for Read only
-------------------------------------------------------------------------------------------------------------
DECLARE @compayId varchar(32)  
DECLARE @errorSum int =0
Declare @stockId  varchar(32)
DECLARE @billCode varchar(100),@hadlerId varchar(32),@deptId varchar(32),@adtime datetime=getdate(),@createid varchar(32)
DeCLARE @tempQty decimal(20,6)  --临时的库存参数
DECLARE @cyqty   decimal(20,6)-- 差异数量
/* 游标参数  */
DECLARE  @adjustId varchar(32),
         @viewOrder int ,
         @warehouseId varchar(32),
         @lotNo   varchar(32),
         @locationNo varchar(32),
         @eId   varchar(32),
         @itemId  varchar(32),
         @unitId  varchar(32),
         @ioQty   decimal(20,6),
         @pkgQty  decimal(20,6),
         @bulkQty  decimal(20,6),
         @fee      decimal(20,6),
         @totalFee decimal(20,6),
         @remarks  varchar(200),
         @regionId varchar(100)
IF not exists(select  adjustNo  from IMS_Adjust where adjustNo=@adjustNo and  ioState=1 )
begin
----如果状态不符合条件 不更新
   set @errorSum=1
end
else  
begin
      ---更新状态
      UPDATE   IMS_Adjust SET  ioState=2,auditTime=@adtime,auditorId=@operatorId WHERE adjustNo=@adjustNo
      set @errorSum=@errorSum+@@ERROR
      select  @billCode=billNo,@createid=@createid, @compayId=companyId,@hadlerId=handlerId,@deptId=deptId  from  IMS_Adjust WHERE adjustNo=@adjustNo
/*-------------------------游标事件-------------------------------------------------------------------*/
        OPEN  FMyCursor ---打开游标
		Fetch  NEXT   FROM FMyCursor  into   
		@adjustId,@viewOrder,@warehouseId,@lotNo,@locationNo,@eId,@itemId,
        @unitId,@ioQty,@pkgQty,@bulkQty,@fee,@totalFee,@remarks
	WHILE @@fetch_status=0 
	BEGIN  
	    select @regionId=isnull(regionId,'') from BAS_Location  
	    where warehouseId=@warehouseId and locationNo=@locationNo
	    
			if not exists(select * from IMS_Stock where  companyId=@compayId and warehouseId=@warehouseId and  itemId=@itemId and isnull(lotNo,'')=isnull(@lotNo,'') and isnull(locationNo,'')=isnull(@locationNo,''))
			begin
				---如果库里面没有 进行插入
				insert into  IMS_Stock(stockId,companyId,warehouseId,lotNo,locationNo,eId,itemId,onhandQty,
				allocQty,price,taxrate,taxPrice,fee,totalFee,lastITime,lastIPrice,
				lastITaxPrice,lastOTime,lastOPrice,lastOTaxPrice,regionId)
				values
				(
				   REPLACE(NEWID(),'-',''),@compayId,@warehouseId,@lotNo,@locationNo,@eId,@itemId,
				   0,0,0,17,0,0,0,GETDATE(),0,0,null,0,0,@regionId
				)
				 set @errorSum=@errorSum+@@ERROR
			end 
		    ----如果主表里面没有的
		    if not exists(select * from IMS_Ledger where companyId=@compayId and warehouseId=@warehouseId and  itemId=@itemId)
		    begin 
				insert into IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,
				allocQty,price,taxrate,taxPrice,
				fee,totalFee,maxDays,minDays,maxQty,
				minQty,stabilityRate,lastITime,lastIPrice,lastITaxPrice,lastOTime,lastOPrice,lastOTaxPrice)
				values(replace(NEWID(),'-',''),@compayId,@warehouseId,@eId,@itemId,0,0,0,17,0,
				0,0,0,0,0,0,0,GETDATE(),0,0,null,0,0)
				 set @errorSum=@errorSum+@@ERROR
		    end 
	    -----------------------------------------查询原始库存
         select @tempQty=onhandQty,@stockId=stockId  from  IMS_Stock 
         where companyId=@compayId and warehouseId=@warehouseId and lotNo=@lotNo 
               and locationNo=@locationNo and itemId=@itemId
               set   @cyqty=(@ioQty+@tempQty)  --计算出差异数量 
         /*------------------------------写入流水账------------------------------------*/
		INSERT INTO IMS_Book(
		[bookId],[ioType],[companyId],[billId],[billNo],[billCode],[objectId],[warehouseId],
		[lotNo],[locationNo],[eId],[itemId],[befQty],[taxFlag],
		[discount],[discountFee],[ioQty],[price],[fee],[taxFee],[afterQty],[handlerId],[deptId],[createTime],
		[creatorId],[auditorId],[auditTime],[memo])
		values(REPLACE(NEWID(),'-',''),'I100',@compayId,@adjustId,@adjustNo,@billCode,@adjustId,
		@warehouseId,@lotNo,@locationNo,@eId,@itemId,@tempQty,null,null,null,@ioQty,null,null,null,@cyqty,@hadlerId,
		@deptId,GETDATE(),@createid,@operatorId,@adtime,@remarks)
        set @errorSum=@errorSum+@@ERROR
        /****************************************更新库存*****************************/
        update  IMS_Stock set  onhandQty=@cyqty,lastOTime=GETDATE(),lastITime=GETDATE()
	    where  stockId=@stockId
        set @errorSum=@errorSum+@@ERROR
        
        update  IMS_Ledger set  onhandQty=onhandQty+@ioQty,lastOTime=GETDATE(),lastITime=GETDATE()
	    where   companyId=@compayId and warehouseId=@warehouseId and itemId=@itemId
	    set @errorSum=@errorSum+@@ERROR
	    -----取游标
	    Fetch  NEXT   FROM FMyCursor  into   
		@adjustId,@viewOrder,@warehouseId,@lotNo,@locationNo,@eId,@itemId,
        @unitId,@ioQty,@pkgQty,@bulkQty,@fee,@totalFee,@remarks
    END   
    CLOSE FMyCursor
	Deallocate FMyCursor
end
	---更新商品库存
	UPDATE BAS_Item SET onhandQty=(select SUM(onhandQty) from IMS_Ledger b 
	                               where b.companyId=@compayId and  b.itemId=a.itemId) 
	                               from BAS_Item a
	where a.companyId=@compayId  
	and  a.itemId  in (select distinct itemId from IMS_AdjustDetail where  adjustNo=@adjustId )
	set @errorSum=@errorSum+@@ERROR
    IF @errorSum<>0 ROLLBACK TRAN;
    ELSE COMMIT TRAN;


go

