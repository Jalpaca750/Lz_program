
CREATE View  [dbo].[WMS_HadReplenish_V]
as
select distinct a.pickingNo,a.companyId,a.warehouseId from WMS_Picking a inner join WMS_PickingDetail b
on  a.pickingNo=b.pickingNo  
where a.taskState=0 and taskType=0
and exists( 
select itemId
from IMS_Replenish
WHERE replenishType=2 and ioState in (10,20) and itemId=b.itemId)
go

