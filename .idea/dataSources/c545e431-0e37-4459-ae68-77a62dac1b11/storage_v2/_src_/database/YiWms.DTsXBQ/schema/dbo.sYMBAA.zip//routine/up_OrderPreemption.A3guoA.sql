CREATE PROCEDURE up_OrderPreemption
(
    @preFlag INT,                                   --预占类型(预占订单处理模式,前台控制:0-只允许预占有库存的商品;1-预占有库存的商品，并为没有库存的商品分配临时储位)
    @orderNo VARCHAR(32),				            --订单单号
	@details Type_SAD_OrderDetail READONLY,		    --订单明细(预占)
    @companyId VARCHAR(32),						    --公司Id
	@operatorId VARCHAR(32),					    --操作员
	@errMsg VARCHAR(2000) OUTPUT                    --错误消息
)
AS
BEGIN	
    DECLARE @orderId VARCHAR(32);                   --订单明细Id
	DECLARE @warehouseId VARCHAR(32);               --仓库Id
	DECLARE @itemId VARCHAR(32);                    --商品Id
	DECLARE @locationNo VARCHAR(32);                --预分配库位
	DECLARE @restQty DECIMAL(20,6);                 --未发货数量
	DECLARE @advQty DECIMAL(20,6);                  --已经预占的库存
	DECLARE @ableQty DECIMAL(20,6);                 --已经预占的库存
	DECLARE @realQty DECIMAL(20,6);                 --实际预占库存
	DECLARE @purQty DECIMAL(20,6);                  --需要采购的量       
	DECLARE @errors BIGINT;                         --错误代码  
	DECLARE @tmpLocation TABLE(warehouseId VARCHAR(32),locationNo VARCHAR(32));
	DECLARE @tmpAble TABLE(orderNo VARCHAR(32),warehouseId VARCHAR(32),itemId VARCHAR(32),restQty DECIMAL(20,6),advQty DECIMAL(20,6),availQty DECIMAL(20,6));
    DECLARE @tmpDetail TABLE(orderId VARCHAR(32),orderNo VARCHAR(32),viewOrder BIGINT,warehouseId VARCHAR(32),itemId VARCHAR(32),restQty DECIMAL(20,6));             
	--初始化变量	
	SET @errors=0;
	SET @errMsg='';	
    SET @locationNo='';
    --删除订单错误日志    
	DELETE FROM SAM_Error WHERE companyId=@companyId AND funCode='up_OrderPreemption' AND billId=@orderNo;
	BEGIN TRY
		BEGIN TRANSACTION
		--排队等待
	    WHILE EXISTS(SELECT * FROM dbo.SAM_Schedule WHERE jobCode='so_audit_job' AND IsLocked=1)
	    BEGIN
            SET @errors=0;
	    END
        UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='up_OrderPreemption',lockerID=@operatorId,lockedTime=GETDATE() WHERE jobCode='so_audit_job'; 
	    --订单不存在
		IF NOT EXISTS(SELECT * FROM dbo.SAD_Order WHERE orderNo=@orderNo)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单已取消，操作无效!';
			RETURN;
		END		
		--非当前用户锁定数据不能进行预分配处理，避免重复
		IF NOT EXISTS(SELECT * FROM dbo.SAD_Order WHERE orderNo=@orderNo AND isLocked=1 AND lockerId=@operatorId)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单被其他人锁定，操作无效!';
			RETURN;
		END
		--订单不存在
		IF NOT EXISTS(SELECT * FROM dbo.SAD_Order WHERE orderNo=@orderNo AND sdState=10)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单状态已经发生改变，不允许预占!';
			RETURN;
		END
		--写入临时订单明细表
		IF EXISTS(SELECT * FROM @details)
		    INSERT INTO @tmpDetail(orderId,orderNo,viewOrder,warehouseId,itemId,restQty)
            SELECT a.orderId,a.orderNo,a.viewOrder,a.warehouseId,a.itemId,ISNULL(a.orderQty, 0.0) - ISNULL(a.shipQty, 0.0)
            FROM SAD_OrderDetail a
                INNER JOIN SAD_Order b ON a.orderNo=b.orderNo
                INNER JOIN BAS_Item bi ON a.itemId=bi.itemId
            WHERE (a.orderNo=@orderNo)
                AND (b.sdState=10)
                AND (ISNULL(a.isVirtual,0)=0)
                AND (ISNULL(a.orderQty, 0.0) - ISNULL(a.shipQty, 0.0)>0.0)
                AND (NOT EXISTS(SELECT * FROM IMS_Advance c WHERE a.orderId=c.orderId))
                AND (a.orderId IN(SELECT orderId FROM @details));
        ELSE
            INSERT INTO @tmpDetail(orderId,orderNo,viewOrder,warehouseId,itemId,restQty)
            SELECT a.orderId,a.orderNo,a.viewOrder,a.warehouseId,a.itemId,ISNULL(a.orderQty, 0.0) - ISNULL(a.shipQty, 0.0)
            FROM SAD_OrderDetail a
                INNER JOIN SAD_Order b ON a.orderNo=b.orderNo
                INNER JOIN BAS_Item bi ON a.itemId=bi.itemId
            WHERE (a.orderNo=@orderNo)
                AND (b.sdState=10)
                AND (ISNULL(a.isVirtual,0)=0)
                AND (ISNULL(a.orderQty, 0.0) - ISNULL(a.shipQty, 0.0)>0.0)
                AND (NOT EXISTS(SELECT * FROM IMS_Advance c WHERE a.orderId=c.orderId));
		--无数据
		IF NOT EXISTS(SELECT * FROM @tmpDetail)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单没有需要被预占的数据，操作无效!';
			RETURN;
		END
		IF(@preFlag=0)
		BEGIN
		    --获取当前订单商品库存，占用等数据
	        INSERT INTO @tmpAble(orderNo,warehouseId,itemId,restQty,advQty,availQty)
	        SELECT dtl.orderNo,dtl.warehouseId,dtl.itemId,dtl.restQty,
                (SELECT SUM(realQty) FROM IMS_Advance WHERE warehouseId=dtl.warehouseId AND itemId=dtl.itemId AND orderNo!=@orderNo) AS advQty,
                ISNULL(inv.onhandQty,0.0)-ISNULL(inv.allocQty,0.0) AS availQty            
            FROM (SELECT orderNo,warehouseId,itemId,SUM(restQty) AS restQty
                  FROM @tmpDetail
                  GROUP BY orderNo,warehouseId,itemId
                  ) dtl LEFT JOIN dbo.IMS_Ledger inv ON dtl.warehouseId=inv.warehouseId AND dtl.itemId=inv.itemId;         
		    --可用库存-预占库存-订单未发货量
            IF EXISTS(SELECT * FROM @tmpAble WHERE ISNULL(availQty,0.0)-ISNULL(advQty,0.0)-ISNULL(restQty,0.0)<0.0)
            BEGIN
                ROLLBACK;
	            SET @errMsg='商品无库存可预占，操作无效！';
		        RETURN;
		    END
            INSERT INTO IMS_Advance(advanceId,companyId,orderId,orderBillNo,orderNo,deptId,warehouseId,locationNo,itemId,advQty,realQty,purQty,advType,customerId,creatorId,createTime)
            SELECT REPLACE(NEWID(),'-',''),a.companyId,b.orderId,a.billNo,a.orderNo,a.deptId,b.warehouseId,@locationNo,b.itemId,
                restQty,restQty,0.0,'WMS' AS advType,a.customerId,@operatorId,GETDATE()
            FROM dbo.SAD_Order a
                INNER JOIN @tmpDetail b ON a.orderNo=b.orderNo
        END
	    ELSE IF (@preFlag=1)
	    BEGIN
	        --待审核的订单
	        --如果已经预占过，则直接给出相同的库位
	        IF EXISTS(SELECT * FROM SAD_OrderDetail WHERE orderNo=@orderNo AND ISNULL(locationNo,'')!='')
	        BEGIN
	            SELECT TOP 1 @locationNo=locationNo FROM SAD_OrderDetail WHERE orderNo=@orderNo AND ISNULL(locationNo,'')!='';
	        END
	        ELSE
	        BEGIN
	            INSERT INTO @tmpLocation(warehouseId,locationNo)
	            SELECT b.warehouseId,b.locationNo
	            FROM dbo.SAD_Order a
	                INNER JOIN dbo.SAD_OrderDetail b ON a.orderNo=b.orderNo
	            WHERE (a.companyId=@companyId)
	                AND (a.sdState=10)
	                AND (ISNULL(b.locationNo,'')!='');
	            --获取订单未分配的临时库位
	            SELECT TOP 1 @locationNo=a.locationNo
	            FROM BAS_Location a
	                LEFT JOIN (SELECT warehouseId,locationNo,SUM(ISNULL(OnhandQty,0.0)+ISNULL(onWayQty,0.0)) AS advQty
	                           FROM IMS_Stock 
	                           GROUP BY warehouseId,locationNo) t ON a.warehouseId=t.warehouseId AND a.locationNo=t.locationNo
	            WHERE (a.companyId=@companyId)
	                AND (a.warehouseId=(SELECT TOP 1 warehouseId FROM SAD_Order WHERE orderNo=@orderNo))
	                AND (a.IsPackage=50)
	                AND (a.isDisable=0)
	                AND (NOT EXISTS(SELECT * FROM @tmpLocation WHERE a.warehouseId=warehouseId AND a.locationNo=locationNo))
	                AND (ISNULL(t.advQty,0.0)=0.0)
	            ORDER BY pickingOrder;
	        END	        
	        IF (ISNULL(@locationNo,'')='')
	        BEGIN
	            ROLLBACK;
		        SET @errMsg='无临时库位可调配，操作无效！';
			    RETURN;
	        END
            WHILE EXISTS(SELECT * FROM @tmpDetail)
            BEGIN
                SELECT TOP 1 @orderId=orderId,@warehouseId=warehouseId,@itemId=itemId,@restQty=restQty FROM @tmpDetail ORDER BY viewOrder;
                --当前商品已预占库存量
                SELECT @advQty=SUM(realQty) FROM IMS_Advance WHERE warehouseId=@warehouseId AND itemId=@itemId AND orderId!=@orderId;
                --可预占的库存                
                SELECT @ableQty=ISNULL(onhandQty,0.0)-ISNULL(allocQty,0.0)-ISNULL(@advQty,0.0) FROM IMS_Ledger WHERE warehouseId=@warehouseId AND itemId=@itemId
                --允许按数量预占
                IF (ISNULL(@ableQty,0.0)-ISNULL(@restQty,0.0)>=0)
                BEGIN
                    INSERT INTO IMS_Advance(advanceId,companyId,orderId,orderBillNo,orderNo,deptId,warehouseId,locationNo,itemId,advQty,realQty,purQty,advType,customerId,creatorId,createTime)
                    SELECT REPLACE(NEWID(),'-',''),a.companyId,b.orderId,a.billNo,a.orderNo,a.deptId,b.warehouseId,'',b.itemId,
                        restQty,restQty,0.0,'WMS' AS advType,a.customerId,@operatorId,GETDATE()
                    FROM dbo.SAD_Order a
                        INNER JOIN @tmpDetail b ON a.orderNo=b.orderNo
                    WHERE b.orderId=@orderId;
                END
                ELSE
                BEGIN
                    IF (ISNULL(@ableQty,0.0)>0)
                        INSERT INTO IMS_Advance(advanceId,companyId,orderId,orderBillNo,orderNo,deptId,warehouseId,locationNo,itemId,advQty,realQty,purQty,advType,customerId,creatorId,createTime)
                        SELECT REPLACE(NEWID(),'-',''),a.companyId,b.orderId,a.billNo,a.orderNo,a.deptId,b.warehouseId,@locationNo,b.itemId,
                            restQty,ISNULL(@ableQty,0.0),0.0,'WMS' AS advType,a.customerId,@operatorId,GETDATE()
                        FROM dbo.SAD_Order a
                            INNER JOIN @tmpDetail b ON a.orderNo=b.orderNo
                        WHERE b.orderId=@orderId;
                    ELSE
                        INSERT INTO IMS_Advance(advanceId,companyId,orderId,orderBillNo,orderNo,deptId,warehouseId,locationNo,itemId,advQty,realQty,purQty,advType,customerId,creatorId,createTime)
                        SELECT REPLACE(NEWID(),'-',''),a.companyId,b.orderId,a.billNo,a.orderNo,a.deptId,b.warehouseId,@locationNo,b.itemId,
                            restQty,0.0,0.0,'WMS' AS advType,a.customerId,@operatorId,GETDATE()
                        FROM dbo.SAD_Order a
                            INNER JOIN @tmpDetail b ON a.orderNo=b.orderNo
                        WHERE b.orderId=@orderId;
                    --更新订单库位
                    UPDATE dbo.SAD_OrderDetail SET locationNo=@locationNo WHERE orderId=@orderId;
                END
                DELETE FROM @tmpDetail WHERE orderId=@orderId;
            END
	    END	    
	    --释放独占标识
	    UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='so_audit_job'; 
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
		     ROLLBACK
		SELECT @errMsg = ERROR_MESSAGE() 
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_OrderPreemption','YI_SALES_ORDER_PREEMPTION_ERROR',@errMsg,@orderNo,@orderNo);		
        RETURN -1;
    END CATCH
END
go

