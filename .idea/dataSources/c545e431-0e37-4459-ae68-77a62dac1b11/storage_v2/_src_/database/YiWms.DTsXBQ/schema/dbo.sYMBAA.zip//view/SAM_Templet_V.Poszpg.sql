/*==============================================================*/
/* View: SAM_Templet_V                                          */
/*==============================================================*/
CREATE view [dbo].[SAM_Templet_V] as
SELECT a.templetCode,a.templetName,a.templetType,a.memo,a.isLocked,a.lockerId,u1.userNick AS lockerName,
    CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,a.creatorId,u2.userNick AS creatorName,
    a.editTime,a.editorId,u3.userNick AS editorName,a.isSelected
FROM dbo.SAM_Templet a
    LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId
    LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId 
    LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId

go

