

/*==============================================================*/
/* View: PSRK_MX     @edit:张东彦 2017-07-07 新加仓库编码       */
/*==============================================================*/
create view [dbo].[PSRK_MX] as
SELECT b.ownerNo AS YEZ_ID,b.billNo AS DANJ_NO,a.viewOrder AS linenum,
bi.itemNo AS itemcode,
a.receiveQty AS quantity,
W.warehouseNo AS WHNO
FROM dbo.PMS_StockDetail a INNER JOIN 
      (SELECT x.stockNo,y.ownerNo,x.billNo,x.mergeNo
       FROM dbo.PMS_Stock x LEFT JOIN 
             dbo.BAS_Owner_V y ON x.ownerId=y.ownerId
       WHERE (x.ioType='D100') AND (x.ioState=30) AND (x.thirdSyncFlag=0)) b ON a.stockNo=b.stockNo INNER JOIN
      dbo.BAS_Item bi ON a.itemId=bi.itemId
      INNER JOIN BAS_Warehouse W on a.warehouseId=W.warehouseId

go

