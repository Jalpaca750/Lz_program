-- =============================================
-- Author:		<Author: WJ>
-- Create date: <Create Date:2017-04-17>
-- Description:	<Description:拦截订单 V1.0>
--  删除排车单，出库单，更新订单                  
-- =============================================

CREATE PROCEDURE [dbo].[up_InterceptOrder]
(
    @companyId VARCHAR(32),		--公司编码
	@orderNo VARCHAR(32),		--订单号
	@operatorId VARCHAR(32)     ---操作员
)
AS
BEGIN	
DECLARE  
		@shipNo VARCHAR(32)='',
		@mergeNo VARCHAR(32)='',
		@orderCount INT=0,
		@orderBillNo VARCHAR(50)='',
		@delStock INT =0
		
----判断是否正在下波次
IF NOT EXISTS(SELECT 1 FROM SAD_Stock WHERE stockNo IN(SELECT stockNo FROM SAD_StockDetail WHERE orderNo=@orderNo) AND isLocked=1)
BEGIN
	
	SELECT @orderBillNo = billNo FROM SAD_Order WHERE @orderNo=@orderNo AND companyId=@companyId
	IF(EXISTS(SELECT 1 FROM SAD_Order WHERE sdState = 10 AND orderNo=@orderNo AND companyId=@companyId))
		BEGIN
			PRINT '直接更新状态'
			UPDATE SAD_Order SET sdState = 0,editTime = GETDATE(),editorId = @operatorId WHERE orderNo=@orderNo AND companyId=@companyId
			--写入日志-----
			INSERT INTO SAM_Log(logId,companyId,operatorId,createTime,functionName,[description],sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,GETDATE(),'','关闭订单，更新状态。单号:'+@orderBillNo,'UPDATE SAD_Order SET sdState = 0 WHERE orderNo=@orderNo AND companyId=@companyId')
			
		END
	ELSE IF NOT EXISTS (SELECT 1 FROM WMS_PickingDetail  WHERE stockId IN(SELECT stockId FROM SAD_StockDetail WHERE orderNo=@orderNo And companyId=@companyId))
		BEGIN
		DECLARE @stockNo VARCHAR(32)
		----释放出库占用-----
		UPDATE a SET a.allocQty=a.allocQty-ISNULL(t.stockQty,0.0) FROM IMS_Ledger a 
		INNER JOIN(SELECT a.itemId,SUM(b.stockQty) AS stockQty FROM SAD_OrderDetail a
		   INNER JOIN SAD_StockDetail b ON a.orderId=b.orderId
		   WHERE a.companyId=@companyId And a.orderNo=@orderNo GROUP BY a.itemId)t ON t.itemId=a.itemId
		----释放出库占用-----
		DECLARE  FMyCursor CURSOR for 
		SELECT DISTINCT stockNo FROM SAD_StockDetail_V WHERE orderNo=@orderNo
		 OPEN FMyCursor Fetch  NEXT FROM FMyCursor  into @stockNo
				 While(@@Fetch_Status = 0)
				 BEGIN
				   SET @delStock = 0
     			   -----处理出库单------
     			   SELECT @orderCount=COUNT(1) FROM SAD_StockDetail WHERE stockNo=@stockNo AND orderNo!=@orderNo GROUP BY orderNo
     			   IF(@orderCount>0)
     				 BEGIN
     		 			PRINT '删除出库单数据'
       	 				DELETE FROM SAD_StockDetail WHERE stockNo=@stockNo AND orderNo=@orderNo AND companyId=@companyId
     	 				SELECT @mergeNo=@mergeNo+t.orderBillNo+',' FROM(SELECT orderBillNo FROM SAD_StockDetail WHERE stockNo=@stockNo AND companyId=@companyId GROUP BY orderBillNo)t 
     	 				SET @mergeNo=LEFT(@mergeNo,LEN(@mergeNo)-1)
       					Update SAD_Stock SET mergeNo =@mergeNo,editTime = GETDATE(),editorId = @operatorId  WHERE stockNo=@stockNo AND companyId=@companyId
	       				
       					----写入日志-----
	       				INSERT INTO SAM_Log(logId,companyId,operatorId,createTime,functionName,[description],sqlText)
						VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,GETDATE(),'','关闭订单，删除出库单数据,更新合并订单号。出库单号:'+@stockNo,'DELETE FROM SAD_StockDetail WHERE stockNo=@stockNo AND orderNo=@orderNo AND companyId=@companyId;Update SAD_Stock SET mergeNo =@mergeNo  WHERE stockNo=@stockNo AND companyId=@companyId;')

     				 END
     			  ELSE
     			  BEGIN
     	  				PRINT '删除出库单'
     	  				SET @delStock=1
     	  				DELETE FROM SAD_StockDetail WHERE stockNo=@stockNo AND companyId=@companyId
       					DELETE FROM SAD_Stock WHERE stockNo=@stockNo AND companyId=@companyId
       					----写入日志-----
	       				INSERT INTO SAM_Log(logId,companyId,operatorId,createTime,functionName,[description],sqlText)
						VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,GETDATE(),'','关闭订单，删除出库单。出库单号:'+@stockNo,'DELETE FROM SAD_StockDetail WHERE stockNo=@stockNo AND companyId=@companyId;DELETE FROM SAD_Stock WHERE stockNo=@stockNo AND companyId=@companyId;')

     			  END
				  -----处理出库单结束-------
					
				   -----处理装车单-------
				   SELECT TOP 1 @shipNo=shipNo FROM WMS_ShipDetail WHERE billNo=@stockNo
				   IF @delStock=1 AND EXISTS(SELECT 1 FROM(SELECT COUNT(1) AS rowscount FROM WMS_ShipDetail_V WHERE shipNo=@shipNo And billNo!=@stockNo)t WHERE t.rowscount>0)
				   BEGIN
       				  PRINT '删除装车数据'
					  DELETE FROM WMS_ShipDetail WHERE billNo=@stockNo AND shipNo=@shipNo
					  ----写入日志-----
					  INSERT INTO SAM_Log(logId,companyId,operatorId,createTime,functionName,[description],sqlText)
					  VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,GETDATE(),'','关闭订单，删除装车数据。出库单号:'+@stockNo+',装车单号'+@shipNo,'DELETE FROM WMS_ShipDetail WHERE billNo=@stockNo AND shipNo=@shipNo')

				   END
				   ELSE IF @delStock=1
				   BEGIN
	       				PRINT '删除装车单'
	       				DELETE FROM WMS_ShipDetail WHERE billNo=@stockNo AND shipNo=@shipNo AND companyId=@companyId
	       				DELETE FROM WMS_Ship WHERE shipNo=@shipNo AND companyId=@companyId
	       				----写入日志-----
	       				INSERT INTO SAM_Log(logId,companyId,operatorId,createTime,functionName,[description],sqlText)
						VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,GETDATE(),'','关闭订单，删除装车单。出库单号:'+@stockNo+',装车单号'+@shipNo,'DELETE FROM WMS_ShipDetail WHERE billNo=@stockNo AND shipNo=@shipNo AND companyId=@companyId;DELETE FROM WMS_Ship WHERE shipNo=@shipNo AND companyId=@companyId;')

				   END
				   -----处理装车单结束-------
	     			Fetch  NEXT   FROM FMyCursor INTO @stockNo 
				 END
				CLOSE FMyCursor
			  Deallocate FMyCursor
			UPDATE SAD_Order SET sdState = 0 WHERE companyId=@companyId AND orderNo=@orderNo
			----写入日志-----
			INSERT INTO SAM_Log(logId,companyId,operatorId,createTime,functionName,[description],sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,GETDATE(),'','关闭订单，更新订单状态。单号:'+@stockNo,'UPDATE SAD_Order SET sdState = 0 WHERE orderNo=@orderNo AND companyId=@companyId')
		END
  END

END

go

