/*****************************2018-03-20 和panny讨论后修改*****************************/
/*  1.只显示待装车和未送达数据                                                        */
/*  2.只显示销售出库单、赠品出库单、带审核的销售退货单（未装车）                      */
/*  3.查询一个时间段内的数据                                                          */
/*  4.去掉A单(原单不送货)                                                             */
/*****************************2018-03-20 和panny讨论后修改*****************************/
CREATE FUNCTION [dbo].[uf_GetUnshippedOrder]
(
    @companyId VARCHAR(32),					--公司Id
	@startTime DATETIME,					--制单时间开始
	@endTime DATETIME                    --制单时间截至
)
RETURNS TABLE
RETURN(
    SELECT a.stockNo,a.billNo AS stockBillNo,a.createTime,a.mergeNo,p.partnerNo AS customerNo,
        p.partnerName AS customerName,p.shortName,a.ordField3,a.lineId,l.lineName,a.receiverAddress,
        a.receiverName,a.receiverTel,a.ioType,CASE a.ioType WHEN 'S100' THEN '销售出库单' 
                                                            WHEN 'D200' THEN '调拨出库单' 
                                                            WHEN 'L100' THEN '领用出库单'
                                                            WHEN 'G200' THEN '赠品出库单'
                                                            WHEN 'B200' THEN '报损出库单'
                                                            WHEN 'O100' THEN '其他出库单'
                                                            END AS ioTypeName,
        a.shipDate,a.shipTime,a.taskState, CASE a.taskState WHEN 10 THEN '已关闭'
                                                            WHEN 20 THEN '已审核'
                                                            WHEN 30 THEN '已排车'
                                                            WHEN 40 THEN '待拣货'
                                                            WHEN 50 THEN '待复核'
                                                            WHEN 60 THEN '待打包'
                                                            WHEN 70 THEN '待装车'
                                                            WHEN 80 THEN '已装车'
                                                            WHEN 90 THEN '已发货'
                                                            WHEN 95 THEN '已妥投'
                                                            WHEN 96 THEN '未送达'
                                                            WHEN 99 THEN '已回单' END AS taskStateDesc,
        a.memo                                            
    FROM dbo.SAD_Stock a
        INNER JOIN dbo.BAS_Partner p ON a.customerId=p.partnerId
        INNER JOIN dbo.BAS_AddressLine l ON a.lineId=l.lineId
    WHERE (a.companyId=@companyId)
        AND (a.createTime BETWEEN @startTime AND @endTime)
        AND (a.taskState IN(70,96))
        AND (a.ioType IN('S100','G200'))
        AND (a.aFlag IN(0,1,3))
    UNION ALL   
    SELECT a.ReturnNo AS stockNo,a.ReturnNo AS stockBillNo,a.editTime,'' AS mergeNo,c.custNo AS customerNo,
        c.custName AS customerName,c.NameSpell AS shortName,  
        (SELECT TOP 1 a1.PopedomName FROM WZX2015.dbo.BDM_SendAddress_V a1 WHERE a.CustID=a1.CustID AND a.SendAddr=a1.SendAddr) AS ordField3, 
	    a.lineId,b.CHName AS lineName,a.SendAddr AS receiverAddress,a.LinkMan AS receiverName,a.Phone AS receiverTel,
	    'S200' AS ioType,'销售退货单' AS ioTypeName,a.CreateDate AS shipDate,'不限' AS shipTime,70 AS taskState,'待装车' AS taskStateDesc,
	    a.remarks
    FROM WZX2015.dbo.SMS_Return a
	    INNER JOIN WZX2015.dbo.BDM_Customer c ON a.CustID=c.CustID
	    INNER JOIN WZX2015.dbo.BDM_Code b ON a.lineId=b.CodeID
    WHERE (a.DeptNo='1055')
        AND (a.BillSts='10')
        AND (a.editTime BETWEEN @startTime AND @endTime)
	    AND (ISNULL(a.CarNumberSts,'')='')
)   
go

