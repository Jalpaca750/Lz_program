CREATE FUNCTION [dbo].[uf_GetDeliverAchievement]
(
    @companyId VARCHAR(32),
    @startDate DATE,
    @endDate DATE    
)
RETURNS TABLE
RETURN
(
	SELECT a.deliveryId,u1.userNick AS deliveryName,a.driverId,u2.userNick AS driverName,
		COUNT(1) AS billCount,COUNT(DISTINCT b.customerId) AS custCount,SUM(ISNULL(pkgQty,0.0)) AS pkgQty,
		SUM(ISNULL(lclQty,0.0)) AS lclQty,SUM(ISNULL(pkgQty,0.0)+ISNULL(lclQty,0.0)) AS totalQty,
		SUM(ISNULL(fclQty,0.0)) AS achieveQty,SUM(ISNULL(fileQty,0.0)) AS fileQty
	FROM dbo.WMS_Ship a 
		INNER JOIN dbo.WMS_ShipDetail b ON a.shipNo=b.shipNo
		INNER JOIN dbo.BAS_Car c ON a.carId=c.carId
		INNER JOIN dbo.SAM_User u1 ON a.deliveryId=u1.userId
		INNER JOIN dbo.SAM_User u2 ON a.driverId=u2.userId
	WHERE (a.companyId=@companyId)
		AND (a.shipDate BETWEEN @startDate AND @endDate)
		AND (c.thirdFlag!=1)
		AND (b.isInvalid=0)
	GROUP BY a.deliveryId,u1.userNick,a.driverId,u2.userNick
)
go

