CREATE PROCEDURE  [dbo].[proc_Audit_Transfer]
(
   @transferNo  varchar(32),--移仓单号
   @operatorId varchar(32)  ---审核人
)
AS
BEGIN
	DECLARE @transferId varchar(32),		--移仓单明细
			@billNo varchar(32),			--移仓单编号
			@companyId varchar(32),			--公司Id
			@outputId varchar(32),			--移出仓库
			@inputId varchar(32),			--移入仓库
			@deptOutId VARCHAR(32),			--移出部门
			@deptInId VARCHAR(32),			--移入部门
			@handlerId VARCHAR(32),			--经办人Id
			@creatorId VARCHAR(32),			--操作员Id
			@createTime DATETIME,			--创建时间			
			@lotNo varchar(32),				--批次
			@inputNo varchar(32),			--移入库位
			@outputNo VARCHAR(32),			--移出库位
			@eId VARCHAR(32),				--主商品Id
			@itemId varchar(32),			--商品Id
			@ioQty DECIMAL(20,6),			--移库数量
			@pkgQty DECIMAL(20,6),
			@bulkQty DECIMAL(20,6),
			@price DECIMAL(20,10),			--单价(不含税)
			@taxrate DECIMAL(6,2),			--税率
			@taxPrice DECIMAL(20,10),		--单价(含税)
			@fee DECIMAL(20,10),			--金额
			@totalfee DECIMAL(20,10),		--金额
			@auditTime DATETIME,			--审核时间
			@remarks VARCHAR(200),			--明细备注
			@memo varchar(2000)				--备注
	DECLARE @regionIn VARCHAR(32),			--移入库区
			@regionOut VARCHAR(32),			--移出库区
			@befQty1 DECIMAL(20,6),			--入库前库存
			@befQty2 DECIMAL(20,6)			--出库前库存
	SET @auditTime=GETDATE();
	--获取操作员所在的公司Id
	SELECT @companyId=companyId FROM dbo.SAM_User WHERE userId=@operatorId;
	--删除操作员当前操作的错误信息
	DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='proc_Audit_Transfer' AND creatorId=@operatorId;
	BEGIN TRY
		--事务开始
		BEGIN TRANSACTION
		--单据被删除，则直接退出
		IF NOT EXISTS(SELECT 1 FROM dbo.IMS_Transfer WHERE transferNo=@transferNo)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'proc_Audit_Transfer','YI_INV_TRANSFER_WAS_DELETED','库存移仓单被他人删除，操作无效！',@transferNo,@transferNo);
			COMMIT;
			RETURN;
		END
		--获取移仓单主表资料
		SELECT @billNo=billNo,@companyId=companyId,@outputId=outputId,@inputId=inputId,@deptOutId=deptOutId,@deptInId=deptInId,@handlerId=handlerId,@creatorId=creatorId,@createTime=createTime,@memo=memo
		FROM dbo.IMS_Transfer
		WHERE transferNo=@transferNo;
		--单据被他人审核或者作废：0-已作废；1-待审核;2-已审核
		IF EXISTS(SELECT 1 FROM dbo.IMS_Transfer WHERE transferNo=@transferNo AND ioState=2)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'proc_Audit_Transfer','YI_INV_TRANSFER_WAS_AUDITED','库存移仓单已审核，操作无效！',@transferNo,@billNo);
			COMMIT;
			RETURN;
		END
		--单据被他人审核或者作废
		IF EXISTS(SELECT 1 FROM dbo.IMS_Transfer WHERE transferNo=@transferNo AND ioState=0)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'proc_Audit_Transfer','YI_INV_TRANSFER_WAS_CLOSED','库存移仓单已作废，操作无效！',@transferNo,@billNo);
			COMMIT;
			RETURN;
		END
		--库位编码错误则返回提醒
		IF EXISTS(SELECT 1 FROM dbo.IMS_TransferDetail a WHERE a.transferNo=@transferNo AND NOT EXISTS(SELECT 1 FROM dbo.BAS_Location b WHERE a.outputId=b.warehouseId AND a.outputNo=b.locationNo))
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'proc_Audit_Transfer','YI_INV_TRANSFER_LOCATION_ERROR','库位编码输入错误，请重新输入！',@transferNo,@billNo);
			COMMIT;
			RETURN;
		END
		IF EXISTS(SELECT 1 FROM dbo.IMS_TransferDetail a WHERE a.transferNo=@transferNo AND NOT EXISTS(SELECT 1 FROM dbo.BAS_Location b WHERE a.inputId=b.warehouseId AND a.inputNo=b.locationNo))
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@createTime,@creatorId,'proc_Audit_Transfer','YI_INV_TRANSFER_LOCATION_ERROR','库位编码输入错误，请重新输入！',@transferNo,@billNo);
			COMMIT;
			RETURN;
		END
		--更新
		UPDATE dbo.IMS_Transfer SET ioState=2,auditTime=@auditTime,auditorId=@operatorId,editTime=@auditTime,editorId=@operatorId WHERE transferNo=@transferNo AND ioState=1;
		IF (@@ROWCOUNT>0)
		BEGIN
			--定义游标
			DECLARE myCursor CURSOR 
			FOR SELECT transferId,ISNULL(lotNo,''),inputNo,outputNo,eId,itemId,ioQty,pkgQty,bulkQty,remarks
				FROM dbo.IMS_TransferDetail 
				WHERE transferNo=@transferNo
				ORDER BY viewOrder 
			FOR READ ONLY;
			--打开游标
			OPEN myCursor 
			FETCH NEXT FROM myCursor INTO @transferId,@lotNo,@inputNo,@outputNo,@eId,@itemId,@ioQty,@pkgQty,@bulkQty,@remarks
			WHILE @@fetch_status=0 
			BEGIN
				--移出
				--仓库总账
				IF EXISTS(SELECT 1 FROM IMS_Ledger WHERE companyId=@companyId AND warehouseId=@outputId AND itemId=@itemId)
					UPDATE IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)-@ioQty,lastOTime=@auditTime
					WHERE companyId=@companyId AND warehouseId=@outputId AND itemId=@itemId;
				ELSE
					INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastOTime)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@outputId,@eId,@itemId,-@ioQty,0.0,@auditTime);
				--移出库区
				SELECT @regionOut=ISNULL(regionId,'') 
				FROM dbo.BAS_Location  
				WHERE warehouseId=@outputId AND locationNo=@outputNo;	
				--如果库位库存存在
				IF EXISTS(SELECT 1 FROM IMS_Stock WHERE companyId=@companyId AND warehouseId=@outputId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@outputNo,'') AND itemId=@itemId)
				BEGIN
					--出库前库存
					SELECT @befQty2=onhandQty
					FROM dbo.IMS_Stock
					WHERE companyId=@companyId AND warehouseId=@outputId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@outputNo,'') AND itemId=@itemId;
					--出库库存减少
					UPDATE dbo.IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)-@ioQty,lastOTime=@auditTime
					WHERE companyId=@companyId AND warehouseId=@outputId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@outputNo,'') AND itemId=@itemId;
				END
				ELSE
				BEGIN
					---如果库里面没有 进行插入
					SELECT @befQty2=0.0;
					--写入库位库存
					INSERT INTO dbo.IMS_Stock(stockId,companyId,warehouseId,regionId,lotNo,locationNo,eId,itemId,onhandQty,allocQty,lastOTime)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@outputId,@regionIn,@lotNo,@outputNo,@eId,@itemId,-@ioQty,0.0,@auditTime);
				END
				--处理IMS_Book表
				INSERT INTO IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,
					eId,itemId,befQty,ioQty,afterQty,handlerId,deptId,createTime,creatorId,auditTime,auditorId,memo)
				VALUES(REPLACE(NEWID(),'-',''),'Y200',@companyId,@transferId,@transferNo,@billNo,'',@outputId,ISNULL(@lotNo,''),
					ISNULL(@outputNo,''),@eId,@itemId,@befQty2,-@ioQty,ISNULL(@befQty2,0.0)-ISNULL(@ioQty,0.0),@handlerId,
					@deptOutId,@createTime,@creatorId,@auditTime,@operatorId,@memo);			
				
				--移入
				--仓库总账	
				IF EXISTS(SELECT 1 FROM IMS_Ledger WHERE companyId=@companyId AND warehouseId=@inputId AND itemId=@itemId)
					UPDATE IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty,lastITime=@auditTime
					WHERE companyId=@companyId AND warehouseId=@inputId AND itemId=@itemId;
				ELSE
					INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastITime)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@inputId,@eId,@itemId,@ioQty,0.0,@auditTime);				
				--移入库区
				SELECT @regionIn=ISNULL(regionId,'') 
				FROM dbo.BAS_Location  
				WHERE warehouseId=@inputId AND locationNo=@inputNo;							
				--如果库位库存存在
				IF EXISTS(SELECT 1 FROM IMS_Stock WHERE companyId=@companyId AND warehouseId=@inputId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@inputNo,'') AND itemId=@itemId)
				BEGIN
					--入出库(调整)前库存
					SELECT @befQty1=onhandQty
					FROM dbo.IMS_Stock
					WHERE companyId=@companyId AND warehouseId=@inputId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@inputNo,'') AND itemId=@itemId;
					--入库库存增加
					UPDATE dbo.IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty,lastITime=@auditTime
					WHERE companyId=@companyId AND warehouseId=@inputId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@inputNo,'') AND itemId=@itemId;
				END
				ELSE
				BEGIN
					---如果库里面没有 进行插入
					SELECT @befQty1=0.0;
					--写入库位库存
					INSERT INTO dbo.IMS_Stock(stockId,companyId,warehouseId,regionId,lotNo,locationNo,eId,itemId,onhandQty,allocQty,lastITime)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@inputId,@regionIn,@lotNo,@inputNo,@eId,@itemId,@ioQty,0.0,@auditTime);
				END
				--处理IMS_Book表
				INSERT INTO IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,
					eId,itemId,befQty,ioQty,afterQty,handlerId,deptId,createTime,creatorId,auditTime,auditorId,memo)
				VALUES(REPLACE(NEWID(),'-',''),'Y100',@companyId,@transferId,@transferNo,@billNo,'',@inputId,ISNULL(@lotNo,''),
					ISNULL(@inputNo,''),@eId,@itemId,@befQty1,@ioQty,ISNULL(@befQty1,0.0)+ISNULL(@ioQty,0.0),@handlerId,
					@deptInId,@createTime,@creatorId,@auditTime,@operatorId,@memo);
					
				FETCH NEXT FROM myCursor INTO @transferId,@lotNo,@inputNo,@outputNo,@eId,@itemId,@ioQty,@pkgQty,@bulkQty,@remarks
			END
			CLOSE myCursor
			Deallocate myCursor
		END
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'proc_Audit_Transfer','YI_INV_TRANSFER_ERROR',LEFT(@ErrMsg,2000),@transferNo,@transferNo);
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END CATCH
END
	

	
	
	




go

