
-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-08-28>
-- Description:	<Description:通过数据库方式同步供应商>
-- 依赖：
--      无
-- 关联：
--		主要联系人
-- =============================================

CREATE PROCEDURE [dbo].[up_SyncF10Supplier] 
(
	@companyId VARCHAR(32),		--公司Id,如果前台调用，需传值，为空时，手动修改这个值
	@ownerId VARCHAR(32),		--业主Id
	@creatorId VARCHAR(32),		--操作员，前天调用的当前用户，后台执行时，可赋值
	@encrypt INT,				--是否对重要数据进行加密1-是;0-否
	@startTime DATETIME,		--同步供应商的开始时间（修改时间）
	@endTime DATETIME			--同步供应商的截至时间（修改时间）
)
AS
BEGIN
	DECLARE @VendorNo VARCHAR(32)
	DECLARE @Vendor TABLE(VendorId BIGINT,VendorNo VARCHAR(32));
	--如果接口正在同步中，则直接退出
	IF EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Supplier' AND isLocked=1)
		RETURN;
	--获取需要同步的数据
	INSERT INTO @Vendor(VendorId,VendorNo)
	SELECT VendorId,VendorNo 
	FROM F10BMS.dbo.BDM_Vendor 
	WHERE syncFlag=0;
	IF NOT EXISTS(SELECT 1 FROM @Vendor)
		RETURN;	
	--1.锁定同步接口
	UPDATE dbo.SAM_Store SET isLocked=1,lockerId=@creatorId,lockedTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Supplier';
	--开始同步
	BEGIN TRY 	
		BEGIN TRANSACTION
		--2.同步供应商资料
		WHILE EXISTS(SELECT 1 FROM @Vendor)
		BEGIN
			--取第一个供应商
			SELECT TOP 1 @VendorNo=VendorNo FROM @Vendor ORDER BY VendorId; 
			--同步
			EXEC F10BMS.dbo.sp_AfterVendorSaved @VendorNo;
			--同步成功后更新同步状态
			UPDATE F10BMS.dbo.BDM_Vendor SET syncFlag=1 WHERE VendorNo=@VendorNo;
			--删除同步成功的临时客户
			DELETE FROM @Vendor WHERE VendorNo=@VendorNo;
		END
		--3.释放同步接口
		UPDATE dbo.SAM_Store SET isLocked=0,lockerId='',syncTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Supplier';
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		--释放同步接口
		UPDATE dbo.SAM_Store SET isLocked=0,lockerId='' WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Supplier';
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int;
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END CATCH
END
go

