-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-08-22>
-- Description:	<Description:同步F10客户资料到WMS>
--      @companyId：公司Id
--      @ownerId：业主Id
--      @creatorId：操作员Id
--      @encrypt：敏感资料是否加密（1-是；0-否）
--      @startTime：同步开始时间 yyyy-MM-dd HH:mm:ss格式
--      @endTime：同步截至时间 yyyy-MM-dd HH:mm:ss格式
-- =============================================

CREATE Proc  [dbo].[up_SyncF10Customer]
(
	@companyId VARCHAR(32),		--公司Id,如果前台调用，需传值，为空时，手动修改这个值
	@ownerId VARCHAR(32),		--业主Id
	@creatorId VARCHAR(32),		--操作员，前天调用的当前用户，后台执行时，可赋值
    @encrypt INT,				--是否对重要数据进行加密1-是;0-否
	@startTime DATETIME,		--同步客户的开始时间（修改时间）
	@endTime DATETIME			--同步客户的截至时间（修改时间）
)
AS
BEGIN
	DECLARE @custNo VARCHAR(32)
	DECLARE @cust TABLE(custId BIGINT,custNo VARCHAR(32));
	--如果接口正在同步中，则直接退出
	IF EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Customer' AND isLocked=1)
		RETURN;
	--获取需要同步的数据
	INSERT INTO @cust(custId,custNo)
	SELECT custId,custNo 
	FROM F10BMS.dbo.BDM_Customer 
	WHERE syncFlag=0;
	IF NOT EXISTS(SELECT 1 FROM @cust)
		RETURN;	
	--1.锁定同步接口
	UPDATE dbo.SAM_Store SET isLocked=1,lockerId=@creatorId,lockedTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Customer';
	--开始同步
	BEGIN TRY 	
		BEGIN TRANSACTION
		--2.同步客户资料
		WHILE EXISTS(SELECT 1 FROM @cust)
		BEGIN
			--取第一个客户
			SELECT TOP 1 @custNo=custNo FROM @cust ORDER BY custId; 
			--同步
			EXEC F10BMS.dbo.sp_AfterCustomerSaved @custNo;
			--同步成功后更新同步状态
			UPDATE F10BMS.dbo.BDM_Customer SET syncFlag=1 WHERE custNo=@custNo;
			--删除同步成功的临时客户
			DELETE FROM @cust WHERE custNo=@custNo;
		END
		--3.释放同步接口
		UPDATE dbo.SAM_Store SET isLocked=0,lockerId='',syncTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Customer';
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		--释放同步接口
		UPDATE dbo.SAM_Store SET isLocked=0,lockerId='' WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Customer';
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int;
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END CATCH
END 

go

