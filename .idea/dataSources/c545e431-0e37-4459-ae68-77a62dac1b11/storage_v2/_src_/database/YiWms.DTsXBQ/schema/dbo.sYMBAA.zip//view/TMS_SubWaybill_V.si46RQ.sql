
CREATE View  [dbo].[TMS_SubWaybill_V]
as
SELECT  a.boxId,a.shipNo,a.shipId,a.billType,a.stockNo,a.stockBillNo,a.waybillId,
    a.boxBillNum,a.boxState,a.exShip01,a.exShip02,a.exShip03,a.exShip04,a.exShip05,
    a.exShip06,a.exShip07,a.exShip08,
    CASE a.billType WHEN 10 THEN '销售出库单' 
                    WHEN 20 THEN '调拨出库单' 
                    WHEN 30 THEN '经营领用单' 
                    WHEN 31 THEN '管理领用单' 
                    WHEN 32 THEN '其他出库单'
                    WHEN 40 THEN '赠品出库单' 
                    WHEN 50 THEN '报损报废单'
                    WHEN 60 THEN '销售退货单'
                    WHEN 70 THEN '销售发票单'
                    WHEN 80 THEN '销售出库单'
                    WHEN 90 THEN '项目单' ELSE '运单' END billTypeName,
    CASE a.boxState WHEN 10 THEN '待装车'
                    WHEN 20 THEN '已装车'
                    WHEN 30 THEN '已发车' ELSE '其他' END boxStateName,
    b.shipTime,b.shipDate,b.driverId,b.driverNo,b.driverName,b.deliveryId,b.deliveryNo,
    b.deliveryName,b.carNumber,b.carId,b.billNo,b.companyId,b.shipState,b.shipStateName,
    b.lineId,b.lineName,a.remarks,a.isSelected
FROM dbo.TMS_SubWaybill a  
    INNER JOIN dbo.WMS_Ship_V b ON a.shipNo=b.shipNo
go

