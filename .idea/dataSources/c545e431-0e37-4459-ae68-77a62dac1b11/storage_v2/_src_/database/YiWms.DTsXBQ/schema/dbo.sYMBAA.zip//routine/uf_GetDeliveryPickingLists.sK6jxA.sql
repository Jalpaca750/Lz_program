CREATE FUNCTION [dbo].[uf_GetDeliveryPickingLists] 
(
	@stockNos AS Filter_Type READONLY
)
RETURNS TABLE
RETURN(
		SELECT c.salesId,CASE WHEN ISNULL(c.organizeId,'')='' THEN CASE WHEN c.serviceFee>0.00 THEN c.customerName+'B'+ convert(varchar(10),CAST(c.serviceFee as int)) ELSE c.customerName END ELSE CASE WHEN c.serviceFee>0.00 THEN c.organizeId +'B'+ convert(varchar(10),CAST(c.serviceFee as int)) ELSE c.organizeId END END AS organizeId, b.billNo AS pickBillNo,c.billNo,a.boxBillNum,a.stockNo,a.stockBillNo,c.receiverName,c.receiverAddress,c.receiverTel,c.receiverMobile,ISNULL(c.receiverMobile,'') + ' ' + ISNULL(c.receiverTel,'') AS fullTel,
			   a.companyId,c.customerId,c.customerNo,c.customerName,c.customerSpell,c.shortName,
			   a.stockBox,a.boxOrder,1 AS boxes,a.isPackage,CASE a.isPackage WHEN 1 THEN '整箱' ELSE '散件' END As isPackageDesc,
			   a.pkgQty,a.lclQty,a.pickerId,u1.userNick AS pickerName,CONVERT(VARCHAR(20),b.getTime,120) AS getTime,
				 CONVERT(VARCHAR(20),a.pickTime,120) AS pickTime,
			 CASE a.isPackage WHEN 1 THEN u1.userNick ELSE u3.userNick  end AS packingName,
			 CONVERT(VARCHAR(20), CASE a.isPackage WHEN 1 THEN a.pickTime ELSE a.packingTime END,120) AS packingTime,cp.companyTel,cp.companyMobile,cp.copyRight,cp.hotLine
		FROM dbo.WMS_PickingOrder a INNER JOIN
			  dbo.WMS_Picking b ON a.pickingNo=b.pickingNo LEFT JOIN     
			  (SELECT m.salesId,m.serviceFee,m.organizeId,m.stockNO,m.billNo,m.receiverName,m.receiverAddress,m.receiverTel,m.receiverMobile,m.customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,
					 p.shortName,p.partnerSpell AS customerSpell,m.mergeNo
			   FROM dbo.SAD_Stock m INNER JOIN
					 dbo.BAS_Partner p ON m.customerId=p.partnerId) c ON a.stockNo=c.stockNo LEFT JOIN 
			  dbo.SAM_User u1 ON a.pickerId=u1.userId LEFT JOIN
			  dbo.SAM_User u3 ON a.packingId=u3.userId 
			  LEFT JOIN SAM_Company cp ON a.companyId=cp.companyId
			WHERE EXISTS(SELECT 1 FROM @stockNos b WHERE b.charId=a.stockNo) AND c.billNo IS NOT NULL
)


go

