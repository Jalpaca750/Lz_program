










/*==============================================================*/
/* View: WMS_PickingBHD_V                                       */
/*==============================================================*/
--creator：     Frank
--create time:  2017-03-18
--Description: 补货分拣标签打印（下架上架用）
CREATE view [dbo].[WMS_PickingBHD_V] as
SELECT a.pickId,a.pickingNo,a.companyId,a.stockNo,a.stockBillNo,a.stockBox,a.boxBillNum,a.lclQty,a.pkgQty,b.totalQty,
      p.taskState,u1.userNo AS pickerNo,u1.userNick AS pickerName,CONVERT(VARCHAR(20),a.pickTime,120) AS pickTime,
      u2.userNo AS checkerNo,u2.userNick AS checkerName,CONVERT(VARCHAR(20),a.checkTime,120) AS checkTime,
      CONVERT(VARCHAR(20),p.getTime,120) AS getTime,u3.userNo AS packagerNo,u3.userNick AS packagerName,
      CONVERT(VARCHAR(20),a.packingTime,120) AS packingTime,c.itemNo,c.itemName,c.itemSpec,c.barcode,c.colorName,
      c.sizeName,c.unitName,c.locationNo,c.batchNo AS lotNo,d.targetLocNo,p.waveBillNo,c.pickQty,c.pkgUnit,
      (case when ISNULL(c.pkgRatio,0.0)=0 then c.realQty else  (ISNULL(c.pickQty,0.0)*ISNULL(c.pkgRatio,0.0)) end)  AS stockQty,c.realQty,c.pkgRatio,c.packageId,d.billNo,p.printNum,
      p.printTime,c.pickingOrder,c.pickingId,c.printNum AS isprint,
      '整 ' + CAST(a.stockBox AS VARCHAR) + '/' + CAST(CAST(a.pkgQty AS INT) AS VARCHAR) + ' 总 ' + CAST(b.totalQty AS VARCHAR) AS pickingDesc1
FROM dbo.WMS_PickingOrder a
      INNER JOIN (SELECT stockNo,COUNT(1) as totalQty,SUM(CASE isPackage WHEN 1 THEN 0 ELSE 1 END) AS lclQty
                  FROM dbo.WMS_PickingOrder
                  GROUP BY stockNo) b ON a.stockNo=b.stockNo
      INNER JOIN (SELECT pd.printNum,pd.pickingId,pd.pickId,bi.itemNo,bi.itemName,bi.itemSpec,bi.barcode,bi.colorName,bi.sizeName,
                        bi.unitName,pd.stockQty,pd.pickQty,pd.realQty,bi.pkgUnit,pd.pkgRatio,pd.batchNo,pd.locationNo,bi.packageId,
                        loc.pickingOrder
                  FROM dbo.WMS_PickingDetail pd
                        INNER JOIN dbo.BAS_Item bi ON pd.itemId=bi.itemId
                        INNER JOIN dbo.BAS_Location loc ON pd.companyId=loc.companyId AND pd.warehouseId=loc.warehouseId AND pd.locationNo=loc.locationNo
                  ) c ON a.pickId=c.pickId
      INNER JOIN dbo.IMS_Replenish d ON a.stockNo=d.replenishId
      INNER JOIN dbo.WMS_Picking p ON a.pickingNo=p.pickingNo
      LEFT JOIN dbo.SAM_User u1 ON a.pickerId=u1.userId
      LEFT JOIN dbo.SAM_User u2 ON a.checkerId=u2.userId
      LEFT JOIN dbo.SAM_User u3 ON a.packingId=u3.userId
WHERE a.isPackage=1



go

