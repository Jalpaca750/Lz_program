/*==============================================================*/
/* View: SAM_Store_V                                            */
/*==============================================================*/
CREATE view [dbo].[SAM_Store_V] as
SELECT a.storeId,a.companyId,c.companyNo,c.companyName,a.ownerId,o.partnerNo AS ownerNo,o.partnerName AS ownerName,
    a.warehouseId,a.storeName,a.storeSource,CASE a.storeSource WHEN 1 THEN 'API' WHEN 0 THEN 'DB' END AS sourceFlag,
    a.customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,a.appKey,a.appSecret,a.sessionKey,a.appUrl,
    a.interfaceType, CASE a.interfaceType WHEN 0 THEN '排队作业'
                                        WHEN 10 THEN '商品资料' 
                                        WHEN 11 THEN '客户资料'
                                        WHEN 12 THEN '供应商资料'
                                        WHEN 19 THEN '基础资料同步作业'
                                        WHEN 20 THEN '销售订单' 
                                        WHEN 30 THEN '采购订单' 
                                        WHEN 40 THEN '调拨申请单' 
                                        WHEN 50 THEN '商品库存'
                                        WHEN 70 THEN '业务数据同步作业'
                                        WHEN 80 THEN '推送业务到第三方'
                                        WHEN 81 THEN '订单自动审核作业' END AS interfaceTypeName,a.syncTime,
    CONVERT(VARCHAR(20),a.startTime,120) AS startTime,CONVERT(VARCHAR(20),a.expiresTime,120) AS expiresTime,
    a.isDisable,CASE a.isDisable WHEN 1 THEN '禁用' ELSE '启用' END as disableFlag,
    a.isLocked,CASE a.isLocked WHEN 1 THEN '运行中' ELSE '空闲' END AS runDesc,
    a.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(10),a.lockedTime,23) AS lockedTime,
    a.createTime,a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName,
    a.isSelected
FROM dbo.SAM_Store a 
    INNER JOIN dbo.SAM_Company c ON a.companyId=c.companyId 
    LEFT JOIN dbo.BAS_Partner o ON a.ownerId=o.partnerId 
    LEFT JOIN dbo.BAS_Partner p ON a.customerId=p.partnerId 
    LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId 
    LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId 
    LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId
go

