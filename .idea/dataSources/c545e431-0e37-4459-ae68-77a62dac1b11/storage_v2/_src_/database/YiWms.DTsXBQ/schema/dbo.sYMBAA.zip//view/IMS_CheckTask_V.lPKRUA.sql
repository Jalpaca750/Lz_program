
/*==============================================================*/
/* View: IMS_CheckTask_V                                        */
/*==============================================================*/
create view IMS_CheckTask_V as
SELECT a.taskId,a.pointId,b.pointNo,a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,
      a.regionId,r.regionNo,r.regionDesc,a.locationWay,b.checkState,a.taskState,
      CASE a.taskState WHEN 1 THEN '已领取' WHEN 0 THEN  '待领取' WHEN 2 THEN '已完成' END AS stateDesc,
      a.checkerId,u.userNick AS checkerName,CONVERT(VARCHAR(20),a.checkTime,120) AS checkTime
FROM dbo.IMS_CheckTask a 
      INNER JOIN dbo.IMS_CheckPoint b ON a.pointId=b.pointId
      INNER JOIN dbo.BAS_Warehouse_V w ON a.warehouseId=w.warehouseId
      LEFT JOIN dbo.BAS_Region r ON a.regionId=r.regionId
      LEFT JOIN dbo.SAM_User u ON a.checkerId=u.userId
go

