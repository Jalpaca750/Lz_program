/*==============================================================*/
/* View: XSCK_HZ                                                */
/*==============================================================*/
-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-02-13>
-- Description:	<Description:SAP所需销售出库单视图>
--      待同步的（thirdSyncFlag=0），
--      已完成发货（taskState=60）的销售出库单（orderType=10)
-- =============================================
create view [dbo].[XSCK_HZ] as
SELECT o.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,a.mergeNo AS SHANGJ_DANJ_NO,c.customerNo AS CARDCODE,
	CONVERT(VARCHAR(10),a.auditTime,23) AS docdate,a.totalFee,a.memo AS comments,u.userNo AS U_opcode,
	u.userNick AS U_OPNAME,0 AS discprcnt,w.warehouseNo AS whNo,
	CASE a.orderType WHEN 10 THEN '销售出库' 
					 WHEN 30 THEN '经营领用' 
					 WHEN 31 THEN '管理领用' 
					 WHEN 40 THEN '赠品出库' 
					 WHEN 50 THEN '报损报废' END AS YEW_TYPE,a.thirdSyncFlag AS SC_FLG
FROM dbo.SAD_Stock a INNER JOIN
      dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId INNER JOIN
      dbo.BAS_Customer_V c ON a.customerId=c.customerId LEFT JOIN
      dbo.BAS_Owner_V o ON a.ownerId=o.ownerId LEFT JOIN 
      dbo.SAM_User u ON a.creatorId=u.userId
WHERE (a.orderType=10 OR a.orderType=30 OR a.orderType=31 OR a.orderType=40 OR a.orderType=50)
      AND (a.taskState>=60) AND a.ioState > 0
      AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2)


go

