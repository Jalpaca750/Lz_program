
-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2016-12-23>
-- Description:	<Description:通过数据库方式同步销售订单>
-- 依赖：
--      客户资料（客户编码）
--      客户地址（客户、地址、收货人）
--		物流策略（市区县地址获取物理公司）
--      商品资料（商品编码、件/箱转换系数）    
--		接口设置（店铺类型，接口类型，业主，同步时间）  
-- =============================================

CREATE PROCEDURE [dbo].[up_SyncSalesOrder] 
(
	@companyId VARCHAR(32),		--公司Id,如果前台调用，需传值，为空时，手动修改这个值
	@creatorId VARCHAR(32)		--操作员，前天调用的当前用户，后台执行时，可赋值
)
AS
BEGIN
	DECLARE @storeId VARCHAR(32),		--接口Id
			@syncTime DATETIME,			--最近一次同步时间
			@ownerId VARCHAR(32),		--业主Id
			@storeSource INT,			--storeSource:1-淘宝;2-京东;8-办公伙伴;9-内部平台;10-F10
			@curTime DATETIME			--当前同步时间
	
	SET @curTime=GETDATE();
	--interfaceType:接口类型[1-订单；2-库存;3-采购订单;4-调拨申请单]	
	DECLARE myCursor CURSOR
	FOR 
		SELECT storeId,syncTime,ownerId,storeSource
		FROM SAM_Store
		WHERE companyId=@companyId AND interfaceType=1 AND (storeSource=8 OR storeSource=9 OR storeSource=10)
	OPEN myCursor
	FETCH NEXT FROM myCursor INTO @storeId,@syncTime,@ownerId,@storeSource
	WHILE @@FETCH_STATUS=0
	BEGIN
		--SAP\Bone\F10
		IF (@storeSource=8 OR @storeSource=9 OR @storeSource=10)
			EXEC up_SyncErpSalesOrder @companyId,@ownerId,@creatorId,@syncTime,@curTime
		--更新最后一次同步时间
		UPDATE SAM_Store SET syncTime=@curTime WHERE storeId=@storeId;
		
		FETCH NEXT FROM myCursor INTO @storeId,@syncTime,@ownerId,@storeSource
	END
	CLOSE myCursor
	DEALLOCATE myCursor
END
go

