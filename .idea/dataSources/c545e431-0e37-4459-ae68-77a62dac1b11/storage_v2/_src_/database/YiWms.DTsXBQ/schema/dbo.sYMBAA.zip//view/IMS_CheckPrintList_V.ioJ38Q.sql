
/*==============================================================*/
/* View: IMS_CheckPrintList_V                                   */
/*==============================================================*/
create view IMS_CheckPrintList_V as
SELECT a.checkNo,a.billNo,corp.companyName,b.pointNo,a.checkDate,c.warehouseNo,c.warehouseName,
	e.employeeName AS handlerName,d.deptNo,d.deptName,a.billState,
	CASE a.billState WHEN 0 THEN '已作废' WHEN 10 THEN '待审核' WHEN 20 THEN '已审核' WHEN 30 THEN '已完成' END AS stateName,
	a.memo,u1.userNick AS auditorName,CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,
	a.createTime,u2.userNick AS creatorName,a.editTime,u3.userNick AS editorName,
	dtl.viewOrder,dtl.itemNo,dtl.itemName,dtl.itemSpec,dtl.barcode,dtl.colorName,dtl.sizeName,
	dtl.unitName,dtl.onhandQty,dtl.actQty,dtl.plQty,dtl.pkgQty,dtl.bulkQty
FROM dbo.IMS_Check AS a 
	INNER JOIN (SELECT x.viewOrder,x.checkNo,y.itemNo,y.itemName,y.itemSpec,y.barcode,y.colorName,y.sizeName,y.unitName,
	                z.onhandQty,x.actQty,x.pkgQty,x.bulkQty,ISNULL(z.onhandQty,0.0)-ISNULL(x.actQty,0.0) AS plQty
	            FROM dbo.IMS_CheckDetail x 
					INNER JOIN dbo.BAS_Item y ON x.itemId=y.itemId 
					INNER JOIN dbo.IMS_CheckStock z ON x.pointId=z.pointId AND x.companyId = z.companyId AND x.warehouseId = z.warehouseId AND ISNULL(x.lotNo,'') = ISNULL(z.lotNo,'') AND ISNULL(x.locationNo,'') = ISNULL(z.locationNo,'') AND x.itemId = z.itemId
				) dtl ON a.checkNo=dtl.checkNo
	INNER JOIN dbo.SAM_Company AS corp ON a.companyId=corp.companyId 
	INNER JOIN dbo.BAS_Warehouse AS c ON a.warehouseId = c.warehouseId 
	INNER JOIN dbo.IMS_CheckPoint AS b ON a.pointId = b.pointId 
	LEFT JOIN dbo.BAS_Department AS d ON d.deptId = a.deptId 
	LEFT JOIN dbo.BAS_Employee AS e ON a.handlerId = e.employeeId 
	LEFT JOIN dbo.SAM_User AS u1 ON a.auditorId = u1.userId 
	LEFT JOIN dbo.SAM_User AS u2 ON a.creatorId = u2.userId 
	LEFT JOIN dbo.SAM_User AS u3 ON a.editorId = u3.userId
	LEFT JOIN dbo.SAM_User AS u4 ON a.lockerId = u4.userId
go

