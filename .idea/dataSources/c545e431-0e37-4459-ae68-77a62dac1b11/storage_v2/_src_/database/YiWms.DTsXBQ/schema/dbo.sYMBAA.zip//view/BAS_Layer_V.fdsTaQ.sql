
/*==============================================================*/
/* View: BAS_Layer_V                                            */
/*==============================================================*/
create view BAS_Layer_V as
SELECT a.layerId,a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,a.locationWay,
	a.locationRow,a.locationLayer,a.locationCol,a.layerLong,a.layerWidth,a.layerHeight,
	a.stdVolume,a.useRate,a.maxVolume,a.shelvesType,a.isLocked,a.lockerId,u1.userNick AS lockerName,
	CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,a.creatorId,
	u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName,a.isSelected
FROM dbo.BAS_Layer a
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId
	LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId
	LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId
go

