
/*==============================================================*/
/* View: SYS_Months_V                                           */
/*==============================================================*/
create view SYS_Months_V as
SELECT 1 AS iMonth
UNION ALL
SELECT 2 AS iMonth
UNION ALL
SELECT 3 AS iMonth
UNION ALL
SELECT 4 AS iMonth
UNION ALL
SELECT 5 AS iMonth
UNION ALL
SELECT 6 AS iMonth
UNION ALL
SELECT 7 AS iMonth
UNION ALL
SELECT 8 AS iMonth
UNION ALL
SELECT 9 AS iMonth
UNION ALL
SELECT 10 AS iMonth
UNION ALL
SELECT 11 AS iMonth
UNION ALL
SELECT 12 AS iMonth
go

