
/*==============================================================*/
/* View: WMS_F10_ShipDtl_V                                      */
/*==============================================================*/
create view WMS_F10_ShipDtl_V as
SELECT a.shipNo,a.billNo AS CarNumberNo,c.CustID,b.receiverAddress AS SendAddr,
    CASE b.billType WHEN 10 THEN b.stockBillNo ELSE '' END AS StockNo,
    b.fclQty AS ZQty,b.totalFee AS ZAmt,'' AS BoxupNo,b.remarks,b.viewOrder AS IndexXH,
    b.fclQty AS PartQty,
    CASE b.billType WHEN 20 THEN b.stockBillNo ELSE '' END AS AllotNo,
    b.stockBillNo AS BillNo,CASE b.billType WHEN 10 THEN '销售出库单' 
					                        WHEN 20 THEN '调拨出库单' 
					                        WHEN 40 THEN '赠品出库单' 
					                        WHEN 60 THEN '销售退货单'
					                        WHEN 70 THEN '销售发票'
					                        WHEN 90 THEN '项目订单' END billType,
	b.receiverName AS LinkMan,b.receiverTel AS Phone,b.boxBillNums AS ExpressNo,b.postFee
FROM dbo.WMS_Ship a
    INNER JOIN dbo.WMS_ShipDetail b ON a.shipNo=b.shipNo
    INNER JOIN F10BMS.dbo.WMS_F10_Customer_V c ON b.customerId=c.customerId
WHERE (a.shipState='30')
    AND (ISNULL(a.syncFlag,0)=0)
go

