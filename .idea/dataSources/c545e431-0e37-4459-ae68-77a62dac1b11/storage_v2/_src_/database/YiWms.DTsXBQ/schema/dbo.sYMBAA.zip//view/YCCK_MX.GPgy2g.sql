
/*==============================================================*/
/* View: YCCK_MX                                                */
/*==============================================================*/
create view YCCK_MX as
SELECT t.billNo AS DANJ_NO,bi.itemNo AS itemcode,a.ioQty AS quantity,a.viewOrder AS HANGHAO,t.WhsCode,t.TO_WhsCode
FROM dbo.IMS_TransferDetail a INNER JOIN
      dbo.BAS_Item bi ON a.itemId=bi.itemId INNER JOIN
      (SELECT m.billNo,m.transferNo,w1.warehouseNo AS WhsCode,w2.warehouseNo AS TO_WhsCode
       FROM dbo.IMS_Transfer m INNER JOIN
             dbo.BAS_Warehouse w1 ON m.outputId=w1.warehouseId INNER JOIN
             dbo.BAS_Warehouse w2 ON m.inputId=w2.warehouseId
       WHERE (m.ioState=2) AND (m.thirdSyncFlag=0) 
             AND (((w2.storage=0) AND (w1.storage=1)) OR ((w2.storage=1) AND (w1.storage=0)))
      ) t ON a.transferNo=t.transferNo
go

