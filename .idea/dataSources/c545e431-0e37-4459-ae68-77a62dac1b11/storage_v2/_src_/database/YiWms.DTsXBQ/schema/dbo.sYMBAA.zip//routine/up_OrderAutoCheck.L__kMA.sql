CREATE PROCEDURE [dbo].[up_OrderAutoCheck]
AS 
BEGIN
	DECLARE @companyId VARCHAR(32),									--公司Id
			@ownerId VARCHAR(32),									--业主Id
			@operatorId VARCHAR(32),								--操作员Id
			@orderDate DATE,										--订单日期
			@week INT;												--星期				
	SET @companyId='B3EE906B60C04C22A8753E0D644369EC';
	SET @ownerId='1405130eda994ee484b08216874b1fa0';
	SET @operatorId='b4afd5180b04434ca7f5bf514491d419';				--管理员
	
	SET DATEFIRST 1;
	SET @week=DATEPART(WEEKDAY,GETDATE());
	IF (@week<5)
		SET @orderDate=DATEADD(d,1,GETDATE());
	IF (@week=5)
		SET @orderDate=DATEADD(d,3,GETDATE());
	IF (@week>5)
		RETURN;
	DECLARE @orderNo VARCHAR(32),				--订单No
			@billNo VARCHAR(32),				--订单编号
			@shipDate DATE,						--发货日期
			@shipTime VARCHAR(40),				--发货时间
			@isTogether INT,					--1-货齐一起送
			@lineId VARCHAR(32),				--送货线路
			@itemNo VARCHAR(2000),				--商品编码	
			@aFlag INT,							--订单类型:0-普通订单;1-有A单（原单）；2-A单;3-直送订单
			@aOrderNo VARCHAR(32);				--A单原订单号		
	DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int,@sqlText VARCHAR(2000);
	--存储当前未下达订单数据
	DECLARE @orders TABLE(orderNo VARCHAR(32),billNo VARCHAR(32),shipDate DATE,shipTime VARCHAR(40),isTogether INT,lineId VARCHAR(32),aFlag INT,aOrderNo VARCHAR(32));
	--如果没有启动订单自动审核功能，则直接退出
	IF NOT EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_OrderAutoCheck' AND isDisable=0)
		RETURN;
	--如果没有开启订单审核功能
	IF NOT EXISTS(SELECT 1 FROM dbo.SAM_Config WHERE companyId=@companyId AND configCode='SALES_ORDER_AUTO_CHECK' AND configValue='1')
		RETURN;
	--如果作业正在执行，则退出等待上一个作业完成
	IF EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_OrderAutoCheck' AND isLocked=1)
		RETURN;
	--开始自动审核作业(接口状态独占)
	UPDATE dbo.SAM_Store SET isLocked=1 WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_OrderAutoCheck';
	IF (@@ROWCOUNT>0)
	BEGIN
		--未下达订单写入临时表
		INSERT INTO @orders(orderNo,billNo,shipDate,shipTime,isTogether,lineId,aFlag,aOrderNo)
		SELECT orderNo,billNo,shipDate,shipTime,isTogether,lineId,aFlag,aOrderNo
		FROM dbo.SAD_Order
		WHERE (sdState=10)						--待审核的订单
			AND (taskState=10)					--任务状态为待处理订单
			AND (shipDate<=@orderDate)			--第二天前要送达的订单
			AND (aFlag BETWEEN 0 AND 2)			--0~2 原单,A单和普通订单自动下达；直送订单手工下达
		--把需要下达的订单全部锁定
		UPDATE dbo.SAD_Order SET isLocked=1,lockedTime=GETDATE(),lockerId=@operatorId WHERE orderNo IN(SELECT orderNo FROM @orders);
		--循环下达
		BEGIN TRY
			BEGIN TRANSACTION
			WHILE (EXISTS(SELECT 1 FROM @orders))		
			BEGIN
				--获取第一条数据
				SELECT TOP 1 @orderNo=orderNo,@billNo=billNo,@shipDate=shipDate,@shipTime=shipTime,@isTogether=isTogether,@lineId=lineId,@aFlag=aFlag 
				FROM @orders 
				ORDER BY billNo;
				--检查订单送货线路是否设置
				IF (ISNULL(@lineId,'')='' OR NOT EXISTS(SELECT 1 FROM dbo.BAS_AddressLine WHERE lineId=@lineId))
				BEGIN
					UPDATE dbo.SAD_Order SET msgText='没有设置送货线路',isLocked=0,lockedTime=NULL,lockerId='' 
					WHERE orderNo=@orderNo;
					DELETE FROM @orders WHERE orderNo=@orderNo;
					CONTINUE;
				END
				--定制品判断
				IF EXISTS(SELECT 1
						  FROM dbo.SAD_OrderDetail a
							  LEFT JOIN dbo.PMS_PurToOrder_V b ON a.contractId=b.sdOrderId
						  WHERE a.orderNo=@orderNo
							  AND ISNULL(a.toOrder,0)=1
							  AND ISNULL(a.orderQty,0.0)-ISNULL(b.orderQty,0.0)>0.0)
				BEGIN
					UPDATE dbo.SAD_Order SET msgText='定制品没有库存',isLocked=0,lockedTime=NULL,lockerId='' 
					WHERE orderNo=@orderNo;
					DELETE FROM @orders WHERE orderNo=@orderNo;
					CONTINUE;
				END
				--普通订单和原单（配货用）基础资料与库存是否完好
				IF (ISNULL(@aFlag,0)=0 OR ISNULL(@aFlag,0)=1)
				BEGIN
					--检查订单对应基础数据是否完好
					IF EXISTS(SELECT 1 
							  FROM dbo.SAD_OrderDetail a 
							      INNER JOIN BAS_Item b ON a.itemId=b.itemId
							  WHERE a.orderNo=@orderNo
								  AND (b.itemVolume=0.0 OR b.pkgRatio=0 OR b.itemWeight=0.0) 
							      AND ISNULL(a.orderQty,0.0)-ISNULL(a.shipQty,0.0)>0.0)
					BEGIN 
						UPDATE dbo.SAD_Order SET msgText='明细商品资料单位体积或者整箱数量需要完善!',isLocked=0,lockedTime=NULL,lockerId='' 
						WHERE orderNo=@orderNo;
						DELETE FROM @orders WHERE orderNo=@orderNo;
						CONTINUE;
					END
					--检测库存是否足够
					SET @itemNo='';
					SELECT @itemNo=@itemNo + bi.itemNo + ','
					FROM (
							SELECT warehouseId,itemId,SUM(ISNULL(orderQty,0.0)-ISNULL(shipQty,0.0)) AS orderQty
							FROM dbo.SAD_OrderDetail
							WHERE orderNo=@orderNo
							GROUP BY warehouseId,itemId
						) t1 LEFT JOIN dbo.IMS_Ledger t2 ON t1.warehouseId=t2.warehouseId AND t1.itemId=t2.itemId
						INNER JOIN dbo.BAS_Item bi ON t1.itemId=bi.itemId
					WHERE ISNULL(t1.orderQty,0.0) - (ISNULL(t2.onhandQty,0.0)-ISNULL(t2.allocQty,0.0))>0.0;
					--如果检查到商品不满足库存，则退出
					IF (ISNULL(@itemNo,'')!='')
					BEGIN
						UPDATE dbo.SAD_Order SET msgText='明细商品[' + @itemNo + ']库存不满足订货量',isLocked=0,lockedTime=NULL,lockerId='' 
						WHERE orderNo=@orderNo;
						DELETE FROM @orders WHERE orderNo=@orderNo;
						CONTINUE;
					END
				END
				--有A单的单据，对应A单是否已下达
				IF (@aFlag=1)
				BEGIN
					IF NOT EXISTS(SELECT 1 FROM SAD_Order WHERE aFlag=2 AND aOrderNo=@billNo AND sdState=30) 
					BEGIN
						SELECT @aOrderNo=billNo FROM SAD_Order WHERE aFlag=2 AND aOrderNo=@billNo;
						UPDATE dbo.SAD_Order SET msgText='对应A单[' + @aOrderNo + ']没有审核',isLocked=0,lockedTime=NULL,lockerId='' 
						WHERE orderNo=@orderNo;
						DELETE FROM @orders WHERE orderNo=@orderNo;
						CONTINUE;
					END
				END					
				SET @sqlText='DECLARE @orderNo VARCHAR(32),@companyId VARCHAR(32),@operatorId VARCHAR(32);
							  SET @orderNo=''' + @orderNo + ''';
							  SET @companyId=''' + @companyId + ''';
							  SET @operatorId=''' + @operatorId + ''';
							  EXEC up_OrderAudit @orderNo,@companyId,@operatorId;'
				--订单自动下达
				EXEC up_OrderAudit @orderNo,@companyId,@operatorId;
				--写入系统日志表
				INSERT INTO SAM_Log(logId,companyId,operatorId,createTime,functionName,description,sqlText)
				VALUES(REPLACE(NEWID(),'-',''),@companyId,@operatorId,GETDATE(),'up_OrderAutoCheck','系统自动审核发货订单,订单编号[' + @billNo + ']',@sqlText);
				DELETE FROM @orders WHERE orderNo=@orderNo;
			END
			--释放自动审核作业(接口状态释放)
			UPDATE SAM_Store SET isLocked=0 WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_OrderAutoCheck';
			COMMIT;
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				 ROLLBACK;
			--释放自动审核作业(接口状态释放)
			UPDATE SAM_Store SET isLocked=0 WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_OrderAutoCheck';
			SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();
			RAISERROR(@ErrMsg, @ErrSeverity, 1);
		END CATCH
	END
END

go

