
/*==============================================================*/
/* View: CGRK_HZ                                                */
/*==============================================================*/
-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-02-13>
-- Description:	<Description:SAP所需采购入库单视图>
--      待同步的（thirdSyncFlag=0），
--      已完成上架（ioState=30）的采购入库单
-- =============================================
create view [dbo].[CGRK_HZ] as
SELECT o.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,a.mergeNo AS SHANGJ_DANJ_NO,s.supplierNo AS CARDCODE,
      CONVERT(VARCHAR(10),isnull(a.auditTime,GETDATE()),23) AS docdate,a.memo AS comments,u.userNo AS U_opcode,
      u.userNick AS U_OPNAME,0 AS discprcnt,'采购入库单' AS YEW_TYPE,a.thirdSyncFlag AS SC_FLG
FROM dbo.PMS_Stock a INNER JOIN
      dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId INNER JOIN
      dbo.BAS_Supplier_V s ON a.supplierId=s.supplierId LEFT JOIN
      dbo.BAS_Owner_V o ON a.ownerId=o.ownerId LEFT JOIN 
      dbo.SAM_User u ON a.creatorId=u.userId
WHERE (a.ioType='P100') AND (a.ioState=30) AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2)



go

