/*==============================================================*/
/* View: WMS_Ship_V                                             */
/*==============================================================*/
--creator：     Frank
--create time:  2016-11-18
--Description: 装车单视图
--Modify:       增加同步标识
CREATE view [dbo].[WMS_Ship_V] as
SELECT a.shipNo,a.companyId,b.companyNo,b.companyName,a.billNo,a.createTime,a.carId,c.carNumber,c.maxVolume,
	c.maxWeight,t.allocVolumn,t.allocWeight,a.driverId,e1.userNo AS driverNo,e1.userNick AS driverName,
	a.deliveryId,e2.userNo AS deliveryNo,e2.userNick AS deliveryName,e2.userMobile AS deliveryMobile,
	a.groupId,g.groupName,a.lineId,l.lineName,a.handlerId,u6.userNick AS handlerName,CONVERT(VARCHAR(10),a.shipDate,23) AS shipDate,
	a.shipTime,t.pkgQty,t.lclQty,t.fileQty,t.totalQty,t.fclQty,CASE a.shipState WHEN 10 THEN '待装车' 
																				WHEN 20 THEN '已装车' 
																				WHEN 30 THEN '已发车' END shipStateName,
    a.shipState,t.postFee,a.creatorId,u1.userNick AS creatorName,a.auditorId,u2.userNick AS auditorName,
    CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,a.isLocked,a.lockerId,u3.userNick AS lockerName,
    CASE a.isLocked WHEN 1 THEN '排车中' ELSE '已排车' END LockedDesc, 
    CONVERT(VARCHAR(10),a.lockedTime,23) AS lockedTime,a.editTime,a.editorId,u4.userNick AS editorName,
    a.printNum,a.printId,u5.userNick AS printMan,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,
    a.memo,a.syncFlag,CONVERT(VARCHAR(20),a.syncTime,120) AS syncTime, a.isSelected
FROM dbo.WMS_Ship AS a 
	INNER JOIN(SELECT shipNo,SUM(ISNULL(pkgvolumn,0.0)+ISNULL(lclVolumn,0.0)) AS allocVolumn,
					SUM(grossWeight) AS allocWeight,
					SUM(pkgQty) AS pkgQty,
					SUM(lclQty) AS lclQty,
					SUM(fileQty) AS fileQty,
					SUM(fclQty) AS fclQty,
					SUM(ISNULL(pkgQty,0)+ISNULL(lclQty,0)) AS totalQty,
					SUM(postFee) AS postFee
				FROM WMS_ShipDetail 
				GROUP BY shipNo) t ON a.shipNo=t.shipNo 
	INNER JOIN dbo.SAM_Company AS b ON a.companyId = b.companyId 
	INNER JOIN dbo.BAS_Car AS c ON a.carId = c.carId 
	LEFT JOIN dbo.SAM_User AS e2 ON a.deliveryId = e2.userId 
	LEFT JOIN dbo.SAM_User AS e1 ON a.driverId = e1.userId 
	LEFT JOIN dbo.BAS_AddressGroup AS g ON a.groupId = g.groupId 
	LEFT JOIN dbo.BAS_AddressLine AS l ON a.lineId = l.lineId 
	LEFT JOIN dbo.SAM_User AS u1 ON a.creatorId = u1.userId 
	LEFT JOIN dbo.SAM_User AS u2 ON a.auditorId = u2.userId 
	LEFT JOIN dbo.SAM_User AS u3 ON a.lockerId = u3.userId 
	LEFT JOIN dbo.SAM_User AS u4 ON a.editorId = u4.userId 
	LEFT JOIN dbo.SAM_User AS u5 ON a.printId=u5.userId
	LEFT JOIN dbo.SAM_User AS u6 ON a.handlerId=u6.userId


go

