
/*==============================================================*/
/* View: PMS_Stock_V                                            */
/*==============================================================*/
--creator：        Frank
--create time：  2016-03-17
--modify: 2017-02-07日整理（增加接口需要的几个字段）
--        2017-10-23日整理 （增加整体折扣，自定义字段等） Frank.He
--采购入库视图
CREATE view [dbo].[PMS_Stock_V] (stockNo, billNo, receiveDate, companyId, companyName, ownerId, ownerNo, ownerName, ownerShortName, supplierId, supplierNo, supplierName, shortName, supplierSpell, warehouseId, warehouseNo, warehouseName, orderSource, orderSourceDesc, ioType, ioTypeDesc, currencyId, exchangeRate, taxFlag, ioState, stateName, apState, totalFee, postFee, discount, discountFee, deliveryNo, buyerId, buyerName, handlerId, handlerName, deptId, deptNo, deptName, receiverId, receiverName, shelvesId, shelvesName, shelvesTime, auditorId, auditorName, auditTime, msgText, memo, mergeNo, ordField1, ordField2, ordField3, ordField4, ordField5, thirdPartyNo, thirdSyncFlag, syncFlagDesc, thirdSyncTime, printNum, printId, printMan, printTime, createTime, creatorId, creatorName, isLocked, lockerId, lockerName, lockedTime, editTime, editorId, editorName, isSelected) as
SELECT a.stockNo,a.billNo,a.receiveDate,a.companyId,c.companyName,a.ownerId,o.ownerNo,o.ownerName,
	o.shortName AS ownerShortName,a.supplierId,s.partnerNo AS supplierNo,s.partnerName AS supplierName,
	s.shortName,s.partnerSpell AS supplierSpell,a.warehouseId,w.warehouseNo,w.warehouseName,a.orderSource,
	CASE a.orderSource WHEN 11 THEN '普通订单' 
                       WHEN 12 THEN '应急订单' 
                       WHEN 13 THEN '临时采购' 
                       WHEN 14 THEN '转场订单' 
                       WHEN 21 THEN '调拨入库单' 
                       WHEN 31 THEN '赠品入库单'
                       WHEN 41 THEN '其他入库单' END AS orderSourceDesc,	
	a.ioType,CASE a.ioType WHEN 'P100' THEN '采购入库单' 
						   WHEN 'D100' THEN '调拨入库单' 
						   WHEN 'G100' THEN '赠品入库单' 
				           WHEN 'O100' THEN '其他入库单' END AS ioTypeDesc,a.currencyId,a.exchangeRate,a.taxFlag,
	a.ioState,CASE a.ioState WHEN 0 THEN '已关闭' 
							 WHEN 10 THEN '待审核' 
							 WHEN 20 THEN '待上架' 
							 WHEN 25 THEN '部分上架'
							 WHEN 30 THEN '全部上架' END AS stateName,a.apState,a.totalFee,a.postFee,
	a.discount,a.discountFee,a.deliveryNo,a.buyerId,e1.employeeName AS buyerName,a.handlerId, 
	e2.employeeName AS handlerName,a.deptId,d.deptNo,d.deptName,a.receiverId,e3.userNick AS receiverName,
	a.shelvesId,e4.userNick AS shelvesName,CONVERT(VARCHAR(20),a.shelvesTime,120) AS shelvesTime,a.auditorId,
	u1.userNick AS auditorName,CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,a.msgText,a.memo, 
	a.mergeNo,a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5,a.thirdPartyNo,a.thirdSyncFlag,
	CASE a.thirdSyncFlag WHEN -1 THEN '无需同步' 
						 WHEN 0 THEN '待同步' 
						 WHEN 1 THEN '同步成功' 
						 ELSE '同步失败' END AS SyncFlagDesc,
	CONVERT(VARCHAR(20),a.thirdSyncTime,120) AS thirdSyncTime,a.printNum,a.printId,u5.userNick AS printMan,
	CONVERT(VARCHAR(20),a.printTime,120) AS printTime,a.createTime,a.creatorId,u2.userNick AS creatorName,
	a.isLocked,a.lockerId,u4.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
	a.editTime,a.editorId,u3.userNick AS editorName,a.isSelected
FROM dbo.PMS_Stock AS a 
      INNER JOIN dbo.SAM_Company AS c ON a.companyId = c.companyId 
      INNER JOIN dbo.BAS_Warehouse AS w ON a.warehouseId = w.warehouseId
      INNER JOIN dbo.BAS_Partner AS s ON a.supplierId = s.partnerId
      LEFT JOIN dbo.BAS_Owner_V AS o ON a.ownerId=o.ownerId
      LEFT JOIN dbo.BAS_Employee AS e1 ON a.buyerId = e1.employeeId
      LEFT JOIN dbo.BAS_Employee AS e2 ON a.handlerId = e2.employeeId 
      LEFT JOIN dbo.BAS_Department AS d ON a.deptId = d.deptId 
      LEFT JOIN dbo.SAM_User AS e3 ON a.receiverId = e3.userId 
      LEFT JOIN dbo.SAM_User AS e4 ON a.shelvesId = e4.userId 
      LEFT JOIN dbo.SAM_User AS u1 ON a.auditorId = u1.userId 
      LEFT JOIN dbo.SAM_User AS u2 ON a.creatorId = u2.userId 
      LEFT JOIN dbo.SAM_User AS u3 ON a.editorId = u3.userId 
      LEFT JOIN dbo.SAM_User AS u4 ON a.lockerId=u4.userId 
      LEFT JOIN dbo.SAM_User AS u5 ON a.printId=u5.userId


go

