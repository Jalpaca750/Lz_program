
/*==============================================================*/
/* View: BAS_Employee_V                                         */
/*==============================================================*/
--creator：        Frank
--create time：    2016-02-25
--modify:          frank 2016-09-22日整理
create view BAS_Employee_V as
SELECT e.employeeId,e.employeeNo,e.employeeName,e.sex,e.nationality,CONVERT(VARCHAR(10),e.birthday,23) AS birthday,
	e.officeTel,e.mobileNo,e.email,e.idCardNo,e.idAddress,e.currAddress,e.deptId,d.deptNo,d.deptName,e.titleId, 
	e.companyId,e.employeeState,CASE e.employeeState WHEN 1 THEN '在职' ELSE '离职' END AS stateName,e.isLocked, 
	e.lockerId,u3.userNick AS lockerName,CONVERT(VARCHAR(20),e.lockedTime,120) AS lockedTime,e.memo,e.createTime, 
	e.creatorId,u1.userNick AS creatorName,e.editTime,e.editorId,u2.userNick AS editorName,e.isSelected
FROM dbo.BAS_Employee AS e 
	LEFT JOIN dbo.BAS_Department AS d ON e.deptId = d.deptId 
	LEFT JOIN dbo.SAM_User AS u1 ON e.creatorId = u1.userId 
	LEFT JOIN dbo.SAM_User AS u2 ON e.editorId = u2.userId 
	LEFT JOIN dbo.SAM_User AS u3 ON e.lockerId = u3.userId
go

