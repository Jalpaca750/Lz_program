
/*==============================================================*/
/* View: WMS_F10_BAS_Brand_V                                    */
/*==============================================================*/
create view WMS_F10_BAS_Brand_V as
SELECT a.CodeID,a.CodeNo,b.brandId,b.brandNo 
FROM F10BMS.dbo.BDM_Code a
    LEFT JOIN dbo.BAS_Brand b ON a.CodeNo=b.brandNo 
WHERE a.Classify='FL09'
go

