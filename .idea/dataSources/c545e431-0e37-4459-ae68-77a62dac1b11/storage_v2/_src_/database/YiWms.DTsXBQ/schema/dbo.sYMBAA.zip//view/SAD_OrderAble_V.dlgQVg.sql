/*==============================================================*/
/* View: SAD_OrderAble_V                                        */
/*==============================================================*/
create view SAD_OrderAble_V as
SELECT dtl.orderNo,dtl.warehouseId,dtl.itemId,dtl.restQty,ISNULL(inv.onhandQty,0.0) AS onhandQty,
    ISNULL(inv.allocQty,0.0) AS allocQty,
    ISNULL(inv.onhandQty,0.0)-ISNULL(inv.allocQty,0.0)-ISNULL(dtl.restQty,0.0) AS ableQty,
    (SELECT SUM(realQty) FROM IMS_Advance WHERE dtl.warehouseId=warehouseId AND dtl.itemId=itemId AND dtl.orderNo!=orderNo) AS advQty
FROM (SELECT orderNo,warehouseId,itemId,SUM(ISNULL(orderQty,0.0)-ISNULL(shipQty,0.0)) AS restQty
      FROM dbo.SAD_OrderDetail
      WHERE ISNULL(isVirtual,0)=0
      GROUP BY orderNo,warehouseId,itemId) dtl
    LEFT JOIN dbo.IMS_Ledger inv ON dtl.warehouseId=inv.warehouseId AND dtl.itemId=inv.itemId
go

