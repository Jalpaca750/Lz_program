






--包装材料领用视图修改
/*==============================================================*/
/* View: WMS_PACK_F10_IMS_Other_V                               */
/*==============================================================*/
CREATE view [dbo].[WMS_PACK_F10_IMS_Other_V] as
SELECT a.billNo AS otherNo,CONVERT(VARCHAR(10),a.createTime,23) AS CreateDate,w1.DeptNo,
	w1.Warehouse,'20' AS BillType,'35' AS IOObject,w1.DeptNo AS DepartNo,'10' AS BillSts,
	0 AS PFlag,CONVERT(VARCHAR(10),a.createTime,23) AS AuditDate,b.employeeID AS AuditID,
	b.employeeID AS CreatorID,GETDATE() AS editTime,packNo AS wmsOrder,billNo AS wmsBillNo,
	1 AS syncFlag,'出库单据[' + a.stockBillNo + ']领用标准纸板箱,操作人员[' + u1.userNick + ']' AS remarks
FROM dbo.WMS_Packing a
    INNER JOIN dbo.BAS_Worktable_V w ON a.deskCode=w.worktableId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V b ON a.creatorId=b.userId 
	LEFT JOIN dbo.SAM_User u1 ON a.creatorId=u1.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_Warehouse_V w1 ON w.warehouseId=w1.warehouseId 
WHERE a.materialFlag=10
	AND (a.syncFlag=0 OR a.syncFlag=2)
go

