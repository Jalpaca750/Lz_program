CREATE PROCEDURE [dbo].[proc_GetDisPlay]
(
    @companyId VARCHAR(32),
    @warehouseId VARCHAR(32),
    @startTime DATETIME,
    @endTime DATETIME
)
AS 

BEGIN
	
DECLARE @endMtime DATETIME=''
SET @endMtime=DATEADD(month,-1,@startTime)

DECLARE @TaskInc INT=0,@PkgInc INT =0,@BulkInc INT=0,@CheckInc INT =0,@RepairInc INT =0,@PMSInc INT =0,@AllocaInc INT =0,@SalesInc INT =0
SELECT @TaskInc=COUNT(1) FROM WMS_Picking_V WHERE companyId=@companyId AND taskState=0
SELECT @PkgInc=COUNT(1) FROM WMS_Picking WHERE companyId=@companyId AND taskState=1 AND taskType=1
SELECT @BulkInc=COUNT(1) FROM WMS_Picking WHERE companyId=@companyId AND taskState=1 AND taskType=0
SELECT @RepairInc=COUNT(1) FROM WMS_Picking WHERE companyId=@companyId AND taskState < 9 AND taskType=2
SELECT @CheckInc=COUNT(1) FROM WMS_Picking WHERE companyId=@companyId AND taskState=2
-----
SELECT @PMSInc=COUNT(1) From WMS_Putaway WHERE  companyId=@companyId AND billType='P100' And ioState < 30
SELECT @AllocaInc=COUNT(1) From WMS_Putaway WHERE companyId=@companyId AND billType='D100' And ioState < 30
SELECT @SalesInc=COUNT(1) From WMS_Putaway WHERE companyId=@companyId AND billType='S200' And ioState < 30
----
SELECT @TaskInc AS TaskInc,@PkgInc AS PkgInc,@BulkInc AS BulkInc,@CheckInc as CheckInc,@RepairInc AS RepairInc ,@PMSInc AS PMSInc,@AllocaInc AS AllocaInc,@SalesInc AS SalesInc

SELECT COUNT(1) AS rowscount,b.logisticsName FROM SAD_Logistics a
LEFT JOIN BAS_Logistics b ON a.logisticsId=b.logisticsId
WHERE a.companyId=@companyId AND a.createTime BETWEEN @startTime AND @endTime
GROUP BY b.logisticsName

SELECT COUNT(1) AS boxRowscount FROM SAD_LogisticsDetail a
INNER JOIN SAD_Logistics AS b ON a.expressNo=b.expressNo
WHERE b.createTime BETWEEN @startTime AND @endTime AND b.companyId=@companyId;

DECLARE @weekS DATETIME,@weekE DATETIME
SELECT  @weekS=DATEADD(week,-1,DATEADD(week,DATEDIFF(week,0,getdate()),0)),@weekE=DATEADD(ss,-1,DATEADD(week,0,DATEADD(week,DATEDIFF(week,0,getdate()),0)))
SELECT datename(weekday,(convert(varchar(10),pickingTime,121))) AS weekdayName,COUNT(1) AS rowsCount FROM SAD_Stock 
WHERE companyId=@companyId AND taskState>60 AND pickingTime BETWEEN @weekS AND @weekE
GROUP BY convert(varchar(10),pickingTime,121)

SELECT * FROM(
SELECT
REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(a.areaName,'省',''),'维吾尔自治区',''),'壮族自治区',''),'回族自治区',''),'自治区',''),'特别行政区','')
 as areaName,ISNULL(b.rowscount,0)AS rowscount FROM BAS_Area a
LEFT JOIN(SELECT receiverState,COUNT(1)rowscount FROM SAD_Logistics 
          WHERE companyId=@companyId AND LEN(receiverState)>0 AND convert(varchar(10),createTime,121) BETWEEN @endMtime AND @startTime
          GROUP BY receiverState)b ON a.areaName=b.receiverState
WHERE a.areaType=2)t ORDER BY t.rowscount desc

SELECT convert(varchar(10),createTime,121) AS DataStr,COUNT(1) AS rowsCount  FROM SAD_Order WHERE companyId=@companyId AND createTime BETWEEN @weekS AND @weekE GROUP BY convert(varchar(10),createTime,121) 
----作业排名----
	SELECT 
		userNick AS '作业人员',
		pickCount as '分拣条目',
		pickErrCount '分拣出错条目',
		pickErrRate '分拣错误率',
		pickFCLBoxes '分拣整箱数',	
		pickPCLBoxes '分拣整拖数',	
		checkCount '复核条目',
		checkFclCount '复核整件数',		
		packCount '打包条目',
		packBoxes '打包箱数',
		physicalCount '盘点条目',
		replenishCount '补货条目数',
		putawayCount '补货上架条目',
		ReceiveCount '采购收货条目',	
		PurchaseCount '采购上架条目',			
		ReturnCount '退货上架' FROM uf_GetAchievement(@companyId,@startTime,@endTime) order by(pickCount + pickErrCount +pickErrRate +pickFCLBoxes +pickPCLBoxes +checkCount +checkFclCount +packCount +packBoxes +physicalCount +replenishCount + putawayCount +ReceiveCount+PurchaseCount +ReturnCount)desc
END
go

