
/*==============================================================*/
/* View: PMS_StockDetail_V                                      */
/*==============================================================*/
--creator：      WJ
--create time：  2016-12-02
--modify:        2017-02-07日整理
--				 2017-10-25增加自定义字段以及冗余订单表中的几个字段 Frank.he
--采购入库明细视图
create view PMS_StockDetail_V as
SELECT dtl.stockId,dtl.stockNo,b.billNo,b.receiveDate,b.createTime,b.supplierId,b.ioType,dtl.ioState,dtl.orderId, 
      dtl.orderNo,dtl.orderBillNo,dtl.companyId,dtl.warehouseId,bw.warehouseNo,bw.warehouseName,dtl.viewOrder,
      dtl.lotNo,dtl.recBin,dtl.locationNo,dtl.eId,dtl.itemId,sku.itemNo,sku.itemCTitle,sku.itemETitle,sku.itemName,
      sku.sellingPoint,sku.itemSpell,sku.itemSpec,sku.barcode,sku.midBarcode,sku.bigBarcode,sku.pkgBarcode,
      sku.brandId,sku.brandCName,sku.brandEName,sku.categoryId,sku.categoryNo,sku.categoryCName,sku.categoryEName,
      sku.colorName,sku.sizeName,sku.unitName,sku.pkgUnit,sku.pkgRatio,dtl.unitId,od.orderQty,
      ISNULL(od.orderQty,0.0)-ISNULL(od.receiveQty,0.0)+ISNULL(dtl.receiveQty,0.0) AS restQty,dtl.receiveQty,t.putawayQty,
      dtl.pkgQty,dtl.bulkQty,b.taxFlag,dtl.befPrice,dtl.discount,dtl.discountFee,dtl.price,dtl.taxrate,dtl.fee,
      dtl.taxFee,dtl.totalFee,sku.purPrice,sku.lastPurPrice,sku.maxPrice,sku.packageId,sku.inventoryMode,sku.isUnsalable,
      sku.isStop,sku.isVirtual,sku.isSafety,sku.safetyMonth,dtl.returnQty,ISNULL(dtl.receiveQty,0.0)-ISNULL(dtl.returnQty,0.0) AS returnAbleQty,
      dtl.invoiceQty,ISNULL(dtl.receiveQty,0.0)-ISNULL(dtl.invoiceQty,0.0) AS invableQty,dtl.invoiceFee,
      ISNULL(dtl.totalFee,0.0)-ISNULL(dtl.invoiceFee,0.0) AS invableFee,dtl.payQty,dtl.payFee,dtl.rebate,dtl.toOrder,
      dtl.updPrice,dtl.isTemporary,dtl.isEmergency,dtl.isPromotion,dtl.buyerId,dtl.putawayId,
      CONVERT(VARCHAR(20),dtl.putawayTime,120) AS putawayTime,dtl.handlerId,dtl.deptId,dtl.planId,dtl.planNo,dtl.planBillNo,
      dtl.sdOrderId,dtl.sdOrderNo,dtl.sdBillNo,dtl.sdCustomerNo,dtl.sdCustomerName,dtl.contractId,dtl.contractNo,
      dtl.ordDtlEx01,dtl.ordDtlEx02,dtl.ordDtlEx03,dtl.ordDtlEx04,dtl.ordDtlEx05,l.inputDate,l.productDate,l.expiryDate,
      l.attribute01,l.attribute02,l.attribute03,l.attribute04,l.attribute05,dtl.remarks,dtl.isSelected
FROM dbo.PMS_StockDetail dtl 
	INNER JOIN dbo.PMS_Stock b ON dtl.stockNo=b.stockNo 
	INNER JOIN dbo.BAS_Goods_V sku ON dtl.itemId=sku.itemId 
	LEFT JOIN(SELECT n.stockId,SUM(CASE n.unitLevel WHEN 'EA' THEN n.putQty ELSE n.putQty*n.pkgRatio END) AS putawayQty
			  FROM dbo.WMS_Putaway m
					INNER JOIN dbo.WMS_PutawayDetail n ON m.putawayNo=n.putawayNo
			  WHERE n.ioState=30
			  GROUP BY n.stockId) t ON dtl.stockId=t.stockId
	LEFT JOIN dbo.PMS_OrderDetail od ON dtl.orderId=od.orderId 
	LEFT JOIN BAS_Warehouse AS bw ON dtl.warehouseId=bw.warehouseId
	LEFT JOIN dbo.IMS_Batch l ON dtl.companyId=sku.companyId AND dtl.lotNo=l.lotNo
go

