
/*==============================================================*/
/* View: WMS_ShipPackage_V                                      */
/*==============================================================*/
--2018-07-14 新建整件计费视图
create view WMS_ShipPackage_V as
SELECT stockId,stockNo,pkgQty,wgtQty,volQty,pkgVolumn,grossWeight,
    CASE WHEN ISNULL(wgtQty,0.0)-ISNULL(volQty,0.0)>0.0 THEN ISNULL(wgtQty,0.0) ELSE ISNULL(volQty,0.0) END AS jfQty
FROM (
    SELECT m1.stockNo,m1.stockId, 
	    m1.pickQty AS pkgQty,												
	    CASE WHEN ISNULL(m2.pkgWeight,0.0)-25.0>0.0 THEN m1.pickQty*CEILING(m2.pkgWeight/25.0) ELSE m1.pickQty END AS wgtQty,
	    CASE WHEN ISNULL(m2.pkgVolume,0.0)-100000.0>0.0 THEN m1.pickQty*CEILING(m2.pkgVolume/100000.0) ELSE m1.pickQty END AS volQty,
	    m1.pickQty*m2.pkgVolume AS pkgVolumn,
	    m1.pickQty*m2.pkgWeight AS grossWeight					
    FROM dbo.WMS_PickingDetail m1
	    INNER JOIN dbo.BAS_Item m2 ON m1.itemId=m2.itemId
    WHERE m1.isPackage=1) t
go

