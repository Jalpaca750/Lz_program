
-- Author:		<Frank.He>
-- Create date: <2018-05-10>
-- Description:	<获取送达目的地的运费>
-- Parameters:
--      @companyId VARCHAR(32),             --公司Id    
--      @warehouseId VARCHAR(32),           --始发仓库Id
--      @logisticsId VARCHAR(32),           --物流公司Id
--      @areaId VARCHAR(32),                --目的省市Id
--      @totalWeight DECIMAL(10,4)          --包裹重量

CREATE FUNCTION [dbo].[uf_GetPostFee]
(
    @companyId VARCHAR(32),             --公司Id    
    @warehouseId VARCHAR(32),           --始发仓库Id
    @logisticsId VARCHAR(32),           --物流公司Id
    @areaId VARCHAR(32),                --目的省市Id
    @totalWeight DECIMAL(10,4)          --包裹重量
)
RETURNS DECIMAL(20,2)
AS
BEGIN
    DECLARE @postFee DECIMAL(20,2);             --运费
    DECLARE @firstWeight DECIMAL(10,4),         --首重
            @increaseWeight DECIMAL(10,4),      --续重
            @firstFee DECIMAL(20,10),           --首重运费
            @increaseFee DECIMAL(20,10),        --续重运费
            @OverFirstWeight DECIMAL(10,4);     --超过首重部分
    SET @postFee=0.00;
    IF EXISTS(SELECT * FROM BAS_AreaLogistics WHERE companyId=@companyId AND warehouseId=@warehouseId AND areaId=@areaId AND logisticsId=@logisticsId)
    BEGIN 
        --获取快递公司发货计算数据
        SELECT @firstWeight=firstWeight,@firstFee=firstFee,@increaseWeight=increaseWeight,@increaseFee=increaseFee
        FROM BAS_AreaLogistics
        WHERE companyId=@companyId AND warehouseId=@warehouseId AND areaId=@areaId AND logisticsId=@logisticsId;
        --如果重量小于首重，则直接返回首重运费
        IF (@totalWeight-@firstWeight<0.0) 
        BEGIN
            SET @postFee=@firstFee;
        END
        ELSE
        BEGIN
            --超过首重部分总量
            SET @OverFirstWeight=@totalWeight-@firstWeight;
            --超过首重部分重量运费
            SET @postFee=@firstFee+CEILING(@OverFirstWeight/@increaseWeight)*@increaseFee
        END
    END
    RETURN @postFee;
END
go

