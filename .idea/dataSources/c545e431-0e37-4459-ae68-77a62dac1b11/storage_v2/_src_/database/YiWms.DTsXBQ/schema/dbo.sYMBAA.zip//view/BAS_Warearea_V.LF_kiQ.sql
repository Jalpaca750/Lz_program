
/*==============================================================*/
/* View: BAS_Warearea_V                                         */
/*==============================================================*/
create view BAS_Warearea_V as
SELECT wa.areaId,wa.companyId,wa.warehouseId,w.warehouseNo,w.warehouseName,wa.regionId,r.regionNo,r.regionDesc,
	wa.areaNo,wa.areaDesc,wa.isDisable,CASE wa.isDisable WHEN 1 THEN '是' ELSE '否' END disableFlag,wa.isLocked,
	wa.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),wa.lockedTime,120) AS lockedTime,wa.createTime,
	wa.creatorId,u2.userNick AS creatorName,wa.editTime,wa.editorId,u3.userNick AS editorName,wa.isSelected
FROM dbo.BAS_Warearea wa 
	INNER JOIN dbo.BAS_Warehouse w ON wa.warehouseId=w.warehouseId
	INNER JOIN dbo.BAS_Region r ON wa.regionId=r.regionId
	LEFT JOIN dbo.SAM_User u1 ON wa.lockerId=u1.userId
	LEFT JOIN dbo.SAM_User u2 ON wa.creatorId=u2.userId
	LEFT JOIN dbo.SAM_User u3 ON wa.editorId=u3.userId
go

