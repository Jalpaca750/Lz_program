/*==============================================================*/
/* View: BAS_Goods_V                                            */
/*==============================================================*/
--creator：Frank
--create time：2017-08-15 
--商品分类视图,去掉多余链接，
--只保留商品最基础的属性和关键属性，
--专用于和其他表做视图链接
CREATE view [dbo].[BAS_Goods_V] as
SELECT sku.eId,bi.itemId,bi.companyId,bi.itemNo,bi.itemCTitle,bi.itemETitle,bi.itemName,bi.itemSpec,
	bi.itemSpell,bi.sellingPoint,bi.barcode,bi.brandId,b.brandNo,b.brandCName,b.brandEName,bi.categoryId,
	cat.categoryNo,cat.categoryCName,cat.categoryEName,sku.colorId,bi.colorName,sku.sizeId,bi.sizeName,
	bi.packageId,sku.unitId,bi.unitName,bi.itemWeight,bi.itemVolume,bi.middleUnit,bi.middleVolume,
	bi.middleWeight,bi.middleRatio,bi.midBarcode,bi.bigUnit,bi.bigVolume,bi.bigWeight,bi.bigRatio,
	bi.bigBarcode,bi.pkgUnit,bi.pkgRatio,bi.pkgBarcode,bi.pkgLong,bi.pkgWidth,bi.pkgHeight,bi.pkgWeight,
	bi.pkgVolume,bi.palletRatio,bi.allowExcess,bi.excessRate,bi.putRegion,bi.eachGroup,bi.csPutRegion,
	bi.pickRegion,bi.csPickRegion,bi.caseGroup,bi.replenishMode,bi.eaMaxQty,bi.eaMinQty,bi.csMaxQty,bi.csMinQty,
	bi.mixMaxQty,bi.mixMinQty,bi.taxFlag,bi.taxRate,bi.webPrice,bi.marketPrice,bi.vipPrice,bi.retailPrice,
	bi.tradePrice,bi.salesPrice,bi.autoIncrease,bi.webIncrease,bi.vipIncrease,bi.retailIncrease,
	bi.tradeIncrease,bi.salesIncrease,bi.purPrice,bi.lastPurPrice,bi.minPrice,bi.maxPrice,bi.purLeadTime,
	bi.itemPara,itemDescription,bi.inventoryMode,bi.isSafety,bi.safetyMonth,bi.safetyDays,bi.onhandQty,
	bi.allocQty,ISNULL(bi.onhandQty,0.0)-ISNULL(bi.allocQty,0.0) AS availQty,bi.serviceMode,bi.isUnsalable,
	bi.isStop,bi.isVirtual,bi.allowSplit,bi.splitRatio,bi.printControl,bi.allowDiscount,bi.pickingMode, 
	bi.isIrregular,img.largeUrl,img.middleUrl, img.smallUrl, img.littleUrl,bi.itemState,bi.commodityId,
	bi.ownerId,bi.shopUrl,bi.supplierId,bi.remarks,bi.isSelected 
FROM dbo.BAS_Item bi 
	INNER JOIN dbo.ECM_ItemSku sku ON bi.itemId=sku.itemId 
	LEFT JOIN dbo.BAS_Brand b ON bi.brandId=b.brandId 
	LEFT JOIN dbo.BAS_Category cat ON bi.categoryId=cat.categoryId
	LEFT JOIN (SELECT eId,itemId,imageType,largeUrl,middleUrl,smallUrl,littleUrl
			   FROM dbo.BAS_ItemImage
			   WHERE (imageType = 1)
			   ) AS img ON bi.itemId = img.itemId
go

