
/*==============================================================*/
/* View: SAM_TempletDetail_V                                    */
/*==============================================================*/
create view SAM_TempletDetail_V as
SELECT td.templetId,td.templetCode,t.templetName,td.formName,td.viewOrder,td.fieldCode,td.fieldName,
    td.controlName,td.controlType,td.allowEmpty,td.allowEdit,td.allowDisplay,td.allowSort,td.allowFilter, 
    td.inputDataType,td.maxLenght,td.dataFormat,td.defaultValue,td.alignMode,td.colWidth,td.memo,
    td.isLocked,td.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),td.lockedTime,120) AS lockedTime,
    td.createTime,td.creatorId,u2.userNick AS creatorName,td.editTime,td.editorId,u3.userNick AS editorName
FROM SAM_TempletDetail td
    INNER JOIN SAM_Templet t ON td.templetCode=t.templetCode
    LEFT JOIN SAM_User u1 ON td.lockerId=u1.userId
    LEFT JOIN SAM_User u2 ON td.creatorId=u2.userId
    LEFT JOIN SAM_User u3 ON td.editorId=u3.userId
go

