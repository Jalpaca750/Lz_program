

/*==============================================================*/
/* View: BAS_ItemZone_V                                         */
/*==============================================================*/
create view [dbo].[BAS_ItemZone_V] as
SELECT z.pkId,z.itemId,z.warehouseId,w.warehouseNo,w.warehouseName,z.companyId,z.putRegion,
    r1.regionDesc AS putRegionDesc,z.putZone,z1.zoneDesc AS putZoneDesc,z.csPutRegion,
    r2.regionDesc AS csPutRegionDesc,z.csPutZone,z2.zoneDesc AS csPutZoneDesc
FROM BAS_ItemZone z 
    LEFT JOIN BAS_Warehouse w ON z.warehouseId=w.warehouseId
    LEFT JOIN BAS_Region r1 ON z.putRegion=r1.regionId
    LEFT JOIN BAS_Zone z1 ON z.putZone=z1.zoneId
    LEFT JOIN BAS_Region r2 ON z.csPutRegion=r2.regionId
    LEFT JOIN BAS_Zone z2 ON z.csPutZone=z2.zoneId


go

