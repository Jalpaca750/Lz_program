
/*==============================================================*/
/* View: BAS_Owner_V                                            */
/*==============================================================*/
--creator：        WJ
--create time：  2018-11-20日整理 
--物流快递接口
create view [dbo].[BAS_LogisticsConfig_V] as
SELECT a.*,b.logisticsCode,b.logisticsName,c.partnerNo AS ownerNo,c.partnerName AS ownerName,c.shortName AS ownershortName
  FROM BAS_LogisticsConfig a 
LEFT JOIN BAS_Logistics b ON a.logisticsId=b.logisticsId
LEFT JOIN BAS_Partner c ON a.ownerId=c.partnerId AND c.partnerType=3

go

