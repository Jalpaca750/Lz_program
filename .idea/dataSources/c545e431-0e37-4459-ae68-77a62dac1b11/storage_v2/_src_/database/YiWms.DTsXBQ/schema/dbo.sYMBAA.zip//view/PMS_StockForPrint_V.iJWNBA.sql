
/*==============================================================*/
/* View: PMS_StockForPrint_V                                    */
/*==============================================================*/
create view PMS_StockForPrint_V as
SELECT a.stockNo,a.billNo,a.receiveDate,a.companyId,c.companyName,a.ownerId,o.ownerNo,o.ownerName,
      o.shortName AS ownerShortName,a.supplierId,s.partnerNo AS supplierNo,s.partnerName AS supplierName,
      s.shortName,s.partnerSpell AS supplierSpell,a.warehouseId,w.warehouseNo,w.warehouseName,a.ioType, 
      CASE a.ioType WHEN 'P100' THEN '采购入库单' 
                    WHEN 'D100' THEN '调拨入库单' 
                    WHEN 'G100' THEN '赠品入库单'
                    WHEN 'O200' THEN '其他入库单' END AS ioTypeDesc,
      a.currencyId,a.exchangeRate,a.taxFlag,a.ioState,CASE a.ioState WHEN 0 THEN '已作废' 
																	 WHEN 10 THEN '待审核' 
																     WHEN 20 THEN '已审核' 
                                                                     WHEN 25 THEN '部分上架'
                                                                     WHEN 30 THEN '全部上架' END AS stateName, 
      a.apState,a.postFee,a.deliveryNo,a.buyerId,e1.employeeName AS buyerName,a.handlerId, 
      e2.employeeName AS handlerName,a.deptId,d.deptNo,d.deptName,a.receiverId,e3.userNick AS receiverName, 
      a.shelvesId,e4.userNick AS shelvesName,CONVERT(VARCHAR(20),a.shelvesTime,120) AS shelvesTime,
      a.auditorId,u1.userNick AS auditorName,CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,a.memo, 
      a.mergeNo,a.thirdPartyNo,a.thirdSyncFlag,CONVERT(VARCHAR(20),a.thirdSyncTime,120) AS thirdSyncTime,
      ISNULL(a.printNum,0)+1 AS printNum,a.printId,u5.userNick AS printMan,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,
      a.createTime,a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName, 
      t.viewOrder,t.itemNo,t.itemName,t.itemSpec,t.packageId,t.sizeName,t.colorName,t.unitName,t.pkgUnit,
      t.pkgRatio,t.receiveQty,t.discount,t.discountFee,t.price,t.taxrate,t.fee,t.taxFee,t.totalFee,
      t.remarks,dbo.uf_GetUpper(a.totalFee) AS upperRMB,'订单:' + ISNULL(a.mergeNo,'') + ISNULL(a.memo,'') AS orderMemo
FROM dbo.PMS_Stock AS a 
      INNER JOIN dbo.SAM_Company AS c ON a.companyId = c.companyId 
      INNER JOIN dbo.BAS_Warehouse AS w ON a.warehouseId = w.warehouseId
      INNER JOIN dbo.BAS_Partner AS s ON a.supplierId = s.partnerId
      INNER JOIN (SELECT dtl.stockId,dtl.stockNo,dtl.ioState,dtl.orderId,dtl.orderNo,dtl.orderBillNo,dtl.viewOrder,
                         dtl.lotNo,dtl.recBin,dtl.locationNo,dtl.eId,dtl.itemId,sku.itemNo,sku.itemName,sku.itemSpell,
						 sku.itemSpec,sku.barcode,sku.brandCName,sku.categoryNo,sku.categoryCName,sku.colorName,
						 sku.sizeName,sku.unitName,sku.pkgUnit,sku.pkgRatio,dtl.receiveQty,dtl.pkgQty,dtl.bulkQty, 
						 dtl.befPrice, dtl.discount,dtl.discountFee,dtl.price,dtl.taxrate,dtl.fee,dtl.taxFee,
						 dtl.totalFee,sku.purPrice,sku.lastPurPrice,sku.maxPrice,sku.packageId,sku.inventoryMode,
						 sku.isUnsalable,sku.isStop,sku.isVirtual,sku.isSafety,sku.safetyMonth,dtl.returnQty,
						 dtl.remarks
				  FROM dbo.PMS_StockDetail dtl 
						  INNER JOIN dbo.BAS_Item_V sku ON dtl.itemId=sku.itemId
				 ) t ON a.stockNo=t.stockNo
      LEFT JOIN dbo.BAS_Owner_V AS o ON a.ownerId=o.ownerId
      LEFT JOIN dbo.BAS_Employee AS e1 ON a.buyerId = e1.employeeId
      LEFT JOIN dbo.BAS_Employee AS e2 ON a.handlerId = e2.employeeId 
      LEFT JOIN dbo.BAS_Department AS d ON a.deptId = d.deptId 
      LEFT JOIN dbo.SAM_User AS e3 ON a.receiverId = e3.userId 
      LEFT JOIN dbo.SAM_User AS e4 ON a.shelvesId = e4.userId 
      LEFT JOIN dbo.SAM_User AS u1 ON a.auditorId = u1.userId 
      LEFT JOIN dbo.SAM_User AS u2 ON a.creatorId = u2.userId 
      LEFT JOIN dbo.SAM_User AS u3 ON a.editorId = u3.userId 
      LEFT JOIN dbo.SAM_User AS u4 ON a.lockerId=u4.userId 
      LEFT JOIN dbo.SAM_User AS u5 ON a.printId=u5.userId
go

