CREATE FUNCTION [dbo].[uf_GetDiffrentStock]
(
    @companyId VARCHAR(32)				        --公司Id
)
RETURNS TABLE
RETURN(    
	SELECT t.warehouseNo,c.warehouseName,t.itemNo,b.itemName,b.itemCTitle,b.itemSpell,b.sellingPoint,b.itemSpec,
		b.colorName,b.sizeName,b.unitName,b.packageId,b.barcode,b.midBarcode,b.bigBarcode,b.pkgBarcode,
		SUM(myQty) AS myQty,SUM(thirdQty) AS thirdQty,SUM(ISNULL(t.myQty,0.0)-ISNULL(t.thirdQty,0.0)) diffQty
	FROM (
			SELECT w.warehouseNo,m2.itemNo,m1.onhandQty AS myQty,0.0 AS thirdQty
			FROM YiWms.dbo.IMS_Ledger m1
				INNER JOIN YiWms.dbo.BAS_Item m2 ON m1.itemId=m2.itemId
				INNER JOIN YiWms.dbo.BAS_Warehouse w ON m1.warehouseId=w.warehouseId
			WHERE m1.companyId=@companyId
			UNION ALL
			SELECT t1.WareHouse,t2.ItemNo,0.0 AS myQty,t1.OnHandQty AS thirdQty
			FROM F10BMS.dbo.IMS_Ledger t1
				INNER JOIN F10BMS.dbo.BDM_ItemInfo t2 ON t1.itemId=t2.itemId
			WHERE t1.DeptNo IN(SELECT DeptNo FROM F10BMS.dbo.WMS_Config)
		) t INNER JOIN YiWms.dbo.BAS_Item b ON t.itemNo=b.itemNo
		INNER JOIN YiWms.dbo.BAS_Warehouse c ON t.warehouseNo=c.warehouseNo
	GROUP BY t.warehouseNo,c.warehouseName,t.itemNo,b.itemName,b.itemCTitle,b.itemSpell,b.sellingPoint,b.itemSpec,
		b.colorName,b.sizeName,b.unitName,b.packageId,b.barcode,b.midBarcode,b.bigBarcode,b.pkgBarcode
	HAVING SUM(ISNULL(t.myQty,0.0)-ISNULL(t.thirdQty,0.0))!=0.0
)
go

