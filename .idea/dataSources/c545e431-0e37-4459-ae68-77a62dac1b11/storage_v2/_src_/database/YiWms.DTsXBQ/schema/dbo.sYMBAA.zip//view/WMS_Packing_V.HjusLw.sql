/*==============================================================*/
/* View: WMS_Packing_V                                          */
/*==============================================================*/
CREATE view [dbo].[WMS_Packing_V] as
SELECT a.packNo,a.billNo,a.companyId,b.companyName,a.boxBillNum,a.pickId,a.stockNo,a.stockBillNo,
	a.customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,p.shortName AS customerShortName,
	a.lineId,l.lineCode,l.lineName,a.regionId,r.regionNo,r.regionDesc,a.boxNum,a.lclCount,a.fclCount,
	ISNULL(a.lclCount,0) +ISNULL (a.fclCount,0) AS boxCount,
	a.materialFlag,CASE a.materialFlag WHEN 10 THEN '标准纸板箱' 
	                                   WHEN 20 THEN '标准周转箱'
	                                   WHEN 30 THEN '回收纸板箱'
	                                   WHEN 40 THEN '塑料袋'
	                                   WHEN 50 THEN '原箱' END AS materialDesc,a.cartonId,bs.sizeNo AS cartonNo,
	bs.sizeName AS cartonName,bs.stdVolume,t.totalVolume,bs.boxBearing,t.totalWeight,t.totalVolume/bs.stdVolume AS useRate,
	a.deskCode, a.packState,CASE a.packState WHEN 10 THEN '待排车' 
	                                         WHEN 20 THEN '已排车' 
	                                         WHEN 30 THEN '已装车' 
	                                         WHEN 40 THEN '已发货'
	                                         WHEN 45 THEN '未发货'
	                                         WHEN 50 THEN '未送达' 
	                                         WHEN 90 THEN '已妥投'
	                                         ELSE '待排车' END AS packStateDesc,a.syncFlag,
	CONVERT(VARCHAR(20),a.syncTime,120) AS syncTime,a.packingId,u1.userNick AS packingName,
	CONVERT(VARCHAR(20),a.packingTime,120) AS packingTime,a.printNum,a.printId,u2.userNick AS printName,
	CONVERT(VARCHAR(20),a.printTime,120) AS printTime,a.createTime,a.creatorId,u3.userNick AS creatorName,
	a.editTime,a.editorId,u4.userNick AS editorName
FROM dbo.WMS_Packing a
	INNER JOIN (SELECT m1.packNo,SUM(m1.packQty*m2.itemVolume) AS totalVolume,SUM(m1.packQty*m2.itemWeight) AS totalWeight
				FROM dbo.WMS_PackingDetail m1
					INNER JOIN dbo.BAS_Item m2 ON m1.itemId=m2.itemId
				GROUP BY m1.packNo) t ON a.packNo=t.packNo
   INNER JOIN dbo.SAM_Company b ON a.companyId = b.companyId
   INNER JOIN dbo.SAD_Stock c ON a.stockNo = c.stockNo
   INNER JOIN dbo.BAS_Partner p ON a.customerId = p.partnerId
   LEFT JOIN dbo.BAS_Region r ON a.regionId = r.regionId
   LEFT JOIN dbo.BAS_AddressLine l ON a.lineId = l.lineId
   LEFT JOIN dbo.WMS_BoxSize bs ON a.cartonId=bs.sizeId
   LEFT JOIN dbo.SAM_User u1 ON a.packingId = u1.userId
   LEFT JOIN dbo.SAM_User u2 ON a.printId = u2.userId
   LEFT JOIN dbo.SAM_User u3 ON a.creatorId = u3.userId
   LEFT JOIN dbo.SAM_User u4 ON a.editorId = u4.userId
go

