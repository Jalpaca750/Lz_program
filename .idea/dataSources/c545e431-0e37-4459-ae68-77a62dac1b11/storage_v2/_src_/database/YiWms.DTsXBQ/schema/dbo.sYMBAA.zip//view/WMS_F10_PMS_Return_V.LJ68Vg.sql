





/*==============================================================*/
/* View: WMS_F10_PMS_Return_V                                   */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_PMS_Return_V] as
SELECT a.billNo AS returnNo,CONVERT(VARCHAR(10),a.auditTime,23) AS createDate,w.DeptNo, 
	w.warehouse AS WareHouse,s.vendorID,'10' AS billSts,0 AS Forcible,
	CONVERT(VARCHAR(10),a.auditTime,23) AS AuditDate,u1.employeeID AS AuditID,
	ISNULL(a.memo,'') AS Remarks,1 AS syncFlag,a.reason,a.returnNo AS wmsOrder,
	a.billNo AS wmsBillNo,u2.employeeID AS creatorId
FROM dbo.PMS_Return a 
	INNER JOIN F10BMS.dbo.WMS_F10_Warehouse_V w ON a.warehouseId=w.warehouseId
	INNER JOIN F10BMS.dbo.WMS_F10_Supplier_V s ON a.supplierId=s.supplierId
	LEFT  JOIN F10BMS.dbo.WMS_F10_User_V u1 ON a.auditorId=u1.userId
	LEFT  JOIN F10BMS.dbo.WMS_F10_User_V u2 ON a.creatorId=u2.userId 
WHERE a.ioState=20
	AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2)
go

