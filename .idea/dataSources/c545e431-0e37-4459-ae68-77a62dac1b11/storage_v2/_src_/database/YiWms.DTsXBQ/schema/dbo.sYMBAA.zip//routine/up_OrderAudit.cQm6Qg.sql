-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-08-20>
-- Description:	<Description:审核订单，并生成库位数量预分配与补货临时表（预分配算法）>
-- 依赖：
--      分配策略对应函数(uf_GetPickLocation)
--      上架策略对应函数(uf_GetPutawayLocation)
--      临时分配表WMS_Allocate     
--      临时补货表WMS_Allocate
--      预分配完毕后通过预分配表生成出库表数据   
--      Frank.He 2017-12-01 取消了预分配算法，并处理厂商直送订单(自动扣库) review V1.2.1    
--      Frank.He 2017-12-14 对送货线路的判断增加了自动处理限制，并统一officemate版本 review V1.2.2 
--      Frank.He 2018-02-09 针对F10编号调整，并写入订单配送节点记录 review V1.2.3 
--      Frank.He 2018-12-14 预占库存处理 review V1.2.4
--      Frank.He 2019-12-04 增加排队操作，并处理预占库存
-- =============================================
CREATE PROCEDURE [dbo].[up_OrderAudit]
(
	@orderNo VARCHAR(32),                   --订单No
	@companyId VARCHAR(32),			        --公司Id
	@creatorId VARCHAR(32),			        --操作员
	@errMsg VARCHAR(2000) OUTPUT            --返回消息
)
AS
BEGIN
    DECLARE	@createTime DATETIME;				--创建时间
    DECLARE @orderBillNo VARCHAR(32);			--订单编号
    DECLARE @warehouseId VARCHAR(32);			--仓库Id
    DECLARE @lineId VARCHAR(32);				--送货线路
    DECLARE @eId VARCHAR(32);					--主商品Id
    DECLARE @itemId VARCHAR(32);				--产品Id
    DECLARE @stockQty DECIMAL(20,6);			--出库单（订单）数量
    DECLARE @befQty DECIMAL(20,6);				--出库前数量
    DECLARE @handleId VARCHAR(32);				--经手人Id
    DECLARE @deptId VARCHAR(32);				--部门Id
    DECLARE @memo VARCHAR(2000);				--备注
    DECLARE @regionId VARCHAR(32);				--库区Id
    DECLARE @lotNo VARCHAR(32);					--批次编号
    DECLARE @locationNo VARCHAR(32);			--库位编号
    DECLARE @stockId VARCHAR(32);				--出库单明细Id
    DECLARE @stockNo VARCHAR(32);				--出库单编号
    DECLARE @stockBillNo VARCHAR(32);			--出库单号
    DECLARE @ioType VARCHAR(32);				--入出库类型
    DECLARE @aFlag INT;							--A单标识:
    DECLARE @sdState INT;						--订单状态:0-关闭交易;10-待审核;15,部分审核;20,已审核;25-部分下达;30-已下达
    DECLARE @taskState INT;						--任务状态：20-审核，30-已排车（已排线）；70-已打包
    DECLARE @isTogether INT;					--发货方式：1-货齐一起送;0-有货先送					
	DECLARE @preAllocate VARCHAR(100);			--1-启动预分配算法，0，正常生成出库单
    DECLARE @orderDealMode VARCHAR(100);		--0,提示用户自行处理;1,按实际库存红冲下单	
    DECLARE @orderShipTime VARCHAR(100);		--1,波次计划前装车;2-打包完成后装车		
    DECLARE @orderAutoCheck VARCHAR(100);		--1,自动审核；0-手工审核
    DECLARE @virtualStore VARCHAR(100);         --1,启动虚拟化仓库功能;0-不启动;
    DECLARE @start2F10 VARCHAR(100);            --1，对接F10接口开启;0-无F10接口
    DECLARE @tmplocation VARCHAR(32);			--直送订单临时库位（直送订单对应F10需要扣减库存）   
    DECLARE @errors BIGINT;                     --错误代码
    DECLARE @tmpAble TABLE(orderNo VARCHAR(32),warehouseId VARCHAR(32),itemId VARCHAR(32),itemNo VARCHAR(32),restQty DECIMAL(20,6),availQty DECIMAL(20,6));    
	DECLARE @tmpPre TABLE(orderNo VARCHAR(32),warehouseId VARCHAR(32),itemId VARCHAR(32),itemNo VARCHAR(32),restQty DECIMAL(20,6),advQty DECIMAL(20,6),availQty DECIMAL(20,6));
	DECLARE @tmpVirtual TABLE(companyId VARCHAR(32),deptId VARCHAR(32),itemId VARCHAR(32),itemNo VARCHAR(32),restQty DECIMAL(20,6),advQty DECIMAL(20,6),availQty DECIMAL(20,6));
	SET @createTime=GETDATE();	
	SET @errMsg='';
	SET @errors=0;
	--清除错误日志
	DELETE FROM SAM_Error WHERE companyId=@companyId AND funCode='up_OrderAudit' AND creatorId=@creatorId;
	--获取系统参数:--1-启动预分配算法，0，正常生成出库单
	SELECT @preAllocate=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='ORDER_AUDIT_PRE_ALLOCATE';
	--装车时机：1,波次计划前装车;2-打包完成后装车
	SELECT @orderShipTime=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='ORDER_SHIP_TIME';
	--订单处理模式（库存不足）0,提示用户自行处理;1,按实际库存红冲下单
	SELECT @orderDealMode=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='ORDER_AUDIT_DEAL_WITH_MODE';
	--直送订单临时库位（直送订单对应F10需要扣减库存）
	SELECT @tmplocation=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='FACTORY_DELIVERY_ORDER_LOCATION';
	--开启订单自动审核功能1,开启自动审核；0-手工审核
	SELECT @orderAutoCheck=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='SALES_ORDER_AUTO_CHECK';
	--是否开启和WMS的接口
	SELECT @start2F10=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='WITH_F10_INTERFACE_START';
	--1-启动虚拟化仓库功能;0不启动
	SELECT @virtualStore=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='VIRTUALIZATION_WAREHOUSE';
	SET @preAllocate=ISNULL(@preAllocate,'0');
	SET @orderDealMode=ISNULL(@orderDealMode,'0');
	SET @orderShipTime=ISNULL(@orderShipTime,'1');
	SET @tmplocation=ISNULL(@tmplocation,'');
	SET @orderAutoCheck=ISNULL(@orderAutoCheck,'0');
	SET @start2F10=ISNULL(@start2F10,'0');
	SET @virtualStore=ISNULL(@virtualStore,'0')
	BEGIN TRY
		BEGIN TRANSACTION
		--排队等待
        WHILE EXISTS(SELECT * FROM dbo.SAM_Schedule WHERE jobCode='so_audit_job' AND IsLocked=1)
        BEGIN
            SET @errors=0;
        END
        UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='up_OrderAudit',lockedTime=@createTime,lockerID=@creatorId WHERE jobCode='so_audit_job';
		--订单不存在
		IF NOT EXISTS(SELECT * FROM dbo.SAD_Order WHERE orderNo=@orderNo)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单已取消或者被拦截，操作无效!';
			RETURN;
		END
		--非当前用户锁定数据不能进行预分配处理，避免重复
		IF NOT EXISTS(SELECT * FROM dbo.SAD_Order WHERE orderNo=@orderNo AND isLocked=1 AND lockerId=@creatorId)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单被其他人锁定，操作无效!';
		    UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			RETURN;
		END
		--订单编号
		--orderType:10-销售订单;20调拨订单 对应 S100-销售出库单;D200-调拨出库单;L100-领用出库单;G200-赠品出库单;B200-报损报废;O100-其他出库单
		SELECT @orderBillNo=billNo,@ioType=CASE orderType WHEN 10 THEN 'S100' 
														  WHEN 20 THEN 'D200' 
														  WHEN 30 THEN 'L100' 
														  WHEN 31 THEN 'L100' 
														  WHEN 32 THEN 'O100' 
														  WHEN 40 THEN 'G200' 
														  WHEN 50 THEN 'B200' END,@warehouseId=warehouseId,
			--波次计划前装车，任务状态为20-待装车；打包完装车则有送货线路的直接30已装车，没有则20-待装车--主要用于不排车直接配货完装车
			@taskState=CASE @orderShipTime WHEN '1' THEN 20 ELSE CASE ISNULL(lineId,'') WHEN '' THEN 20 ELSE 30 END END,			
			@sdState=sdState,@isTogether=isTogether,@aFlag=ISNULL(aFlag,0),@lineId=lineId,@handleId=handlerId,@deptId=deptId,@memo=memo
		FROM dbo.SAD_Order 
		WHERE orderNo=@orderNo;
        --订单、仓库、商品库存
	    INSERT INTO @tmpAble(orderNo,warehouseId,itemId,itemNo,restQty,availQty)
	    SELECT dtl.orderNo,dtl.warehouseId,dtl.itemId,dtl.itemNo,dtl.restQty,
            ISNULL(inv.onhandQty,0.0)-ISNULL(inv.allocQty,0.0) AS availQty            
        FROM (SELECT a.orderNo,a.warehouseId,a.itemId,c.itemNo,SUM(ISNULL(a.orderQty, 0.0) - ISNULL(a.shipQty, 0.0)) AS restQty
              FROM SAD_OrderDetail a
                  INNER JOIN SAD_Order b ON a.orderNo=b.orderNo
                  INNER JOIN BAS_Item c ON a.itemId=c.itemId
              WHERE (a.orderNo=@orderNo)
                  AND (ISNULL(c.isVirtual,0)=0)
                  AND (ISNULL(a.orderQty, 0.0) - ISNULL(a.shipQty, 0.0)>0.0)
              GROUP BY a.orderNo,a.warehouseId,a.itemId,c.itemNo) dtl
            LEFT JOIN dbo.IMS_Ledger inv ON dtl.warehouseId=inv.warehouseId AND dtl.itemId=inv.itemId;
		--可用量(带预占)
	    INSERT INTO @tmpPre(orderNo,warehouseId,itemId,itemNo,restQty,availQty,advQty)
	    SELECT dtl.orderNo,dtl.warehouseId,dtl.itemId,dtl.itemNo,dtl.restQty,
            ISNULL(inv.onhandQty,0.0)-ISNULL(inv.allocQty,0.0) AS availQty,
            (SELECT SUM(realQty) FROM IMS_Advance WHERE warehouseId=dtl.warehouseId AND itemId=dtl.itemId AND orderNo!=@orderNo) AS advQty
        FROM (SELECT a.orderNo,a.warehouseId,a.itemId,c.itemNo,SUM(ISNULL(a.orderQty,0.0)-ISNULL(a.shipQty,0.0)) AS restQty
              FROM SAD_OrderDetail a
                  INNER JOIN BAS_Item c ON a.itemId=c.itemId
              WHERE (a.orderNo=@orderNo)
                  AND (ISNULL(c.isVirtual,0)=0)
                  AND (ISNULL(a.orderQty, 0.0) - ISNULL(a.shipQty, 0.0)>0.0)
                  AND (a.orderId NOT IN(SELECT orderId FROM IMS_Advance WHERE orderNo=@orderNo))
              GROUP BY a.orderNo,a.warehouseId,a.itemId,c.itemNo) dtl
            LEFT JOIN dbo.IMS_Ledger inv ON dtl.warehouseId=inv.warehouseId AND dtl.itemId=inv.itemId;            
		--订单已被关闭
		IF (@sdState=0)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单已关闭，操作无效!';
		    UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			RETURN;
		END
		--订单已终止
		IF (@sdState=15)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单已终止，操作无效!';
		    UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			RETURN;
		END		
		--订单已审核
		IF (@sdState=20)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单已审核，操作无效!';
		    UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			RETURN;
		END
		--订单已下达
		IF (@sdState=30)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单已审核，操作无效!';
		    UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			RETURN;
		END
		--自动审核未分配送货线路
		IF (ISNULL(@lineId,'')='')
		BEGIN
		    ROLLBACK;
		    SET @errMsg='订单尚未设置配送线路，操作无效!';	
		    UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;	    
			RETURN;
		END		
		--检查是否有明细数据
		IF NOT EXISTS(SELECT * FROM @tmpAble)
		BEGIN
		    ROLLBACK;
		    SET @errMsg='没有需要配货的明细商品，操作无效!';
		    UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			RETURN;
		END		
		--直送订单
		IF (@aFlag=3)
		BEGIN
			--直送订单的临时库位不能为空
			IF (ISNULL(@tmplocation,'')='')	
			BEGIN
			    ROLLBACK;
		        SET @errMsg='厂商送货临时库位未设置，操作无效!';
		        UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			    RETURN;
			END
			--取得库区
			SELECT @regionId=ISNULL(regionId,''),@warehouseId=warehouseId
			FROM dbo.BAS_Location  
			WHERE companyId=@companyId AND locationNo=@tmplocation;
			--系统直送仓库与直送订单配送仓库相同
			IF NOT EXISTS(SELECT * FROM dbo.SAD_Order WHERE orderNo=@orderNo AND warehouseId=@warehouseId)
			BEGIN
			    ROLLBACK;
		        SET @errMsg='直送订单配送仓库与系统设置直送仓库不一致，操作无效!';
		        UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			    RETURN;			
			END
			--直送订单库位库存是否充足
			IF EXISTS(
				SELECT 1
				FROM @tmpAble t1 
				    LEFT  JOIN (SELECT warehouseId,itemId,SUM(ISNULL(onhandQty,0.0)-ISNULL(allocQty,0.0)) AS availQty
					            FROM dbo.IMS_Stock
					            WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@tmplocation
					            GROUP BY warehouseId,itemId) t2 ON t1.warehouseId=t2.warehouseId AND t1.itemId=t2.itemId
				WHERE ISNULL(t1.restQty,0.0)-ISNULL(t2.availQty,0.0)>0.0
			)
			BEGIN
			    ROLLBACK;
		        SET @errMsg='订单明细商品库存不足，操作无效!';
		        UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			    RETURN;
			END
		END
		--原单必须检查库存
		ELSE IF (ISNULL(@aFlag,0)=1 OR ISNULL(@aFlag,0)=0)
		BEGIN
		    --检查商品单个体积与重量
		    IF EXISTS(SELECT * FROM BAS_Item WHERE itemId=ANY(SELECT itemId FROM @tmpAble) AND (ISNULL(itemVolume,0.0)=0.0 OR ISNULL(pkgRatio,0)=0 OR ISNULL(itemWeight,0.0)=0.0) AND ISNULL(isVirtual,0)=0) 
		    BEGIN
		        ROLLBACK;
		        SELECT TOP 1 @errMsg='商品['+itemNo+']整箱数量、单位体积或者重量设置不全，操作无效!' 
		        FROM BAS_Item
		        WHERE itemId=ANY(SELECT itemId FROM @tmpAble) AND (ISNULL(itemVolume,0.0)=0.0 OR ISNULL(pkgRatio,0)=0 OR ISNULL(itemWeight,0.0)=0.0)  AND ISNULL(isVirtual,0)=0
	            UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
		        RETURN;
		    END
		    --提示自拆分商品未设置拆分数量
		    IF EXISTS(SELECT * FROM BAS_Item WHERE itemId IN(SELECT itemId FROM @tmpAble) AND allowSplit=2 AND splitRatio=0 AND ISNULL(isVirtual,0)=0)
		    BEGIN
		        ROLLBACK;
		        SELECT TOP 1 @errMsg='商品['+itemNo+']自拆分参数设置错误，操作无效!'
		        FROM BAS_Item 
		        WHERE itemId IN(SELECT itemId FROM @tmpAble) AND allowSplit=2 AND splitRatio=0 AND ISNULL(isVirtual,0)=0;
		        UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			    RETURN;
			END			
		    --预占库存是否足够(暂存缺陷(收货时更新purQty)，需要改到上架操作更新purQty来弥补)
		    IF EXISTS(SELECT * FROM IMS_Advance WHERE orderNo=@orderNo AND ISNULL(advQty,0.0)-ISNULL(realQty,0.0)-ISNULL(purQty,0.0)>0.0)
		    BEGIN
		        ROLLBACK;
		        SELECT TOP 1 @errMsg='商品['+b.itemNo+']预占库存尚未采购入库，操作无效!'
		        FROM IMS_Advance a 
		            INNER JOIN BAS_Item b ON a.itemId=b.itemId
		        WHERE a.orderNo=@orderNo AND ISNULL(a.advQty,0.0)-ISNULL(a.realQty,0.0)-ISNULL(a.purQty,0.0)>0.0;
		        UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			    RETURN;
		    END		    
			--提示用户处理或者货齐一起送的，订单必须全部满足库存
			IF (@orderDealMode='0' OR @isTogether=1) 
			BEGIN
			    IF EXISTS(SELECT * FROM @tmpAble WHERE orderNo=@orderNo AND ISNULL(availQty,0.0)-ISNULL(restQty,0.0)<0.0)
			    BEGIN
			        ROLLBACK;
		            SELECT TOP 1 @errMsg='商品['+itemNo+']库存可用量不足，操作无效!'
		            FROM @tmpAble 
		            WHERE orderNo=@orderNo AND ISNULL(availQty,0.0)-ISNULL(restQty,0.0)<0.0;
		            UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			        RETURN;
			    END
			    --有预占库存的，则库存占用+采购占用-订单发货量必须>0
	            IF EXISTS(SELECT * FROM IMS_Advance a INNER JOIN SAD_OrderDetail b ON a.orderId=b.orderId WHERE b.orderNo=@orderNo AND ISNULL(a.purQty,0.0)+ISNULL(a.realQty,0.0)-(ISNULL(b.orderQty,0.0)-ISNULL(b.shipQty,0.0))<0.0)
                BEGIN
                    ROLLBACK;
                    SELECT TOP 1 @errMsg='商品['+bi.itemNo+']预占库存尚未采购入库，操作无效!'
                    FROM IMS_Advance a 
                        INNER JOIN SAD_OrderDetail b ON a.orderId=b.orderId
                        INNER JOIN BAS_Item bi ON a.itemId=bi.itemId
                    WHERE b.orderNo=@orderNo AND ISNULL(a.purQty,0.0)+ISNULL(a.realQty,0.0)-(ISNULL(b.orderQty,0.0)-ISNULL(b.shipQty,0.0))<0.0;
                    UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
	                RETURN;
                END
                --无预占库存的，则需要判断是否被别的订单占用
                IF EXISTS(SELECT * FROM @tmpPre WHERE ISNULL(availQty,0.0)-ISNULL(advQty,0.0)-ISNULL(restQty,0.0)<0.0)
                BEGIN
                    ROLLBACK;
                    SELECT TOP 1 @errMsg='商品['+bi.itemNo+']被其他订单预占，不满足发货数量，操作无效!'
                    FROM @tmpPre a
                        INNER JOIN BAS_Item bi ON a.itemId=bi.itemId
                    WHERE ISNULL(availQty,0.0)-ISNULL(advQty,0.0)-ISNULL(restQty,0.0)<0.0;
                    UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
                    RETURN;
                END
			    --虚拟仓也必须满足
		        IF (@virtualStore='1') AND EXISTS(SELECT * FROM IMS_DeptLedger_MAP WHERE companyId=@companyId AND warehouseId=@warehouseId AND IsDisable=0)
                BEGIN
                    INSERT INTO @tmpVirtual(companyId,deptId,itemId,itemNo,restQty,advQty,availQty)
	                SELECT dtl.companyId,dtl.deptId,dtl.itemId,dtl.itemNo,dtl.restQty,
                        (SELECT SUM(realQty) FROM IMS_Advance WHERE warehouseId=dtl.warehouseId AND itemId=dtl.itemId AND orderNo!=@orderNo) AS advQty,
                        ISNULL(inv.onhandQty,0.0)-ISNULL(inv.allocQty,0.0) AS availQty            
                    FROM (SELECT a.companyId,a.warehouseId,a.deptId,a.itemId,c.itemNo,SUM(ISNULL(a.orderQty, 0.0) - ISNULL(a.shipQty, 0.0)) AS restQty
                          FROM SAD_OrderDetail a
                              INNER JOIN SAD_Order b ON a.orderNo=b.orderNo
                              INNER JOIN BAS_Item c ON a.itemId=c.itemId
                          WHERE (a.orderNo=@orderNo)
                              AND (ISNULL(c.isVirtual,0)=0)
                              AND (ISNULL(a.orderQty, 0.0) - ISNULL(a.shipQty, 0.0)>0.0)
                          GROUP BY a.companyId,a.warehouseId,a.deptId,a.itemId,c.itemNo) dtl
                        LEFT JOIN dbo.IMS_DeptLedger inv ON dtl.companyId=inv.companyId AND dtl.deptId=inv.deptId AND dtl.itemId=inv.itemId;
                    --判断虚拟仓可用量是否足够
                    IF EXISTS(SELECT * FROM @tmpVirtual WHERE ISNULL(availQty,0.0)-ISNULL(restQty,0.0)<0)
                    BEGIN
                        ROLLBACK;
		                SELECT TOP 1 @errMsg='商品['+itemNo+']虚拟库存可用量不足，操作无效!'
		                FROM @tmpVirtual 
		                WHERE ISNULL(availQty,0.0)-ISNULL(restQty,0.0)<0.0;
		                UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
			            RETURN;
                    END
                END
			END
			--有A单的A单没审核不允许审核
		    IF (ISNULL(@aFlag,0)=1)
		    BEGIN
			    --查询A单是否已经审核
			    IF NOT EXISTS(SELECT * FROM SAD_Order WHERE aFlag=2 AND aOrderNo=@orderBillNo AND sdState=30)
			    BEGIN
			        ROLLBACK;
		            SELECT @errMsg='对应A单['+billNo+']未审核，操作无效!' FROM SAD_Order WHERE aFlag=2 AND aOrderNo=@orderBillNo
		            UPDATE dbo.SAD_Order SET msgText=ISNULL(@errMsg,'对应A单不存在，操作无效!') WHERE orderNo=@orderNo;
			        RETURN;
			    END
		    END  
		END		
		--定制品没有库存不予许审核
		IF EXISTS(SELECT * FROM dbo.SAD_OrderDetail a LEFT JOIN dbo.PMS_PurToOrder_V b ON a.contractId=b.sdOrderId WHERE a.orderNo=@orderNo AND ISNULL(a.toOrder,0)=1 AND ISNULL(a.orderQty,0.0)-ISNULL(b.orderQty,0.0)>0.0)
		BEGIN
		    ROLLBACK;
	        SET @errMsg='定制品没有足够的库存，操作无效!';
	        UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
		    RETURN;
		END		
		--出库单No
		SET @stockNo=LOWER(REPLACE(NEWID(),'-',''));
		--出库单编号(调拨出库单、销售出库单、其他出库单、赠品出库单、报损出库单）
		IF (@ioType='D200')
			EXEC up_CreateCode @companyId,'IMS_Allot',@creatorId,@stockBillNo OUTPUT;
		ELSE IF(@ioType='B200' OR @ioType='G200' OR @ioType='O100')
			SET @stockBillNo=@orderBillNo;
		ELSE
			EXEC up_CreateCode @companyId,'SAD_Stock',@creatorId,@stockBillNo OUTPUT;
		--检查商品单个体积与重量
		IF ISNULL(@stockBillNo,'')=''
		BEGIN
		    ROLLBACK;
	        SET @errMsg='系统繁忙，生成单号失败，操作无效!';
	        UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;
		    RETURN;
		END
		--A单、厂家直送单
		IF (@aFlag=2 OR @aFlag=3)
		BEGIN
			--生成出库单主表(A单，直接生成为已打包状态方便打印，不需要配货）
			INSERT INTO dbo.SAD_Stock(stockNo,companyId,ownerId,billNo,createTime,warehouseId,ioType,customerId,
				addressId,receiverState,receiverCity,receiverDistrict,receiverAddress,lineId,groupId,receiverName,
				receiverTel,receiverMobile,orderType,payMode,settlementId,shipDate,shipTime,currencyId,exchangeRate,
				taxFlag,ioState,taskState,arState,totalFee,totalDiscount,discount,serviceFee,postFee,payFee,orderSource,
				buyerId,organizeId,poNo,salesId,handlerId,deptId,flag,expressNo,logisticsId,logisticsFee,buyerMessage,
				aFlag,aStockNo,memo,mergeNo,ordField1,ordField2,ordField3,ordField4,ordField5,creatorId,isLocked,
				lockerId,lockedTime,editTime,editorId)
			SELECT @stockNo,@companyId,ownerId,@stockBillNo,@createTime,warehouseId,@ioType,customerId,addressId,
				receiverState,receiverCity,receiverDistrict,receiverAddress,lineId,groupId,receiverName,receiverTel,
				receiverMobile,orderType,payMode,settlementId,shipDate,shipTime,currencyId,exchangeRate,taxFlag,
				10 AS ioState,70,arState,totalFee,totalDiscount,discount,serviceFee,postFee,payFee,orderSource,
				buyerId,organizeId,poNo,salesId,handlerId,deptId,flag,expressNo,logisticsId,logisticsFee,buyerMessage,
				aFlag,aOrderNo,memo,billNo,ordField1,ordField2,ordField3,ordField4,ordField5,@creatorId,0 AS isLocked,
				'' AS lockerId,NULL AS lockedTime,@createTime,@creatorId
			FROM dbo.SAD_Order
			WHERE orderNo=@orderNo;
			INSERT INTO dbo.SAD_StockDetail(stockId,stockNo,orderId,orderNo,orderBillNo,companyId,warehouseId,
				viewOrder,lotNo,locationNo,eId,itemId,stockQty,pkgQty,bulkQty,pkgVolumn,bulkVolumn,pkgWeight,
				bulkWeight,befPrice,discount,discountFee,price,taxrate,fee,taxFee,totalFee,toOrder,updPrice,
				isPromotion,isGift,isVirtual,needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
				contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,pickQty,remarks)
			SELECT stockId,@stockNo AS stockNo,orderId,orderNo,billNo AS orderBillNo,companyId,warehouseId,
				viewOrder,lotNo,locationNo,eId,itemId,stockQty,pkgQty,bulkQty,pkgQty*pkgVolume AS pkgVolumn,
				bulkQty*itemVolume AS bulkVolumn,pkgWeight*pkgQty AS pkgWeight,bulkQty*itemWeight AS bulkWeight,
				befPrice,discount,discountFee,price,taxrate,fee,totalFee-fee AS taxFee,totalFee,toOrder,updPrice,
				isPromotion,isGift,ISNULL(isVirtual,0),needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
				contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,stockQty,remarks
			FROM (SELECT LOWER(REPLACE(NEWID(),'-','')) AS stockId,orderId,orderNo,billNo,companyId,warehouseId,
						ROW_NUMBER() OVER (ORDER BY viewOrder) AS viewOrder,'' AS lotNo,
						CASE @aFlag WHEN 3 THEN @locationNo ELSE locationNo END AS locationNo,eId,itemId,
						restQty AS stockQty,FLOOR(restQty/pkgRatio) AS pkgQty,(restQty%pkgRatio) AS bulkQty,
						befPrice,discount,discountFee,price,taxRate,
						CAST(restQty*price/(1+taxrate/100.0) AS DECIMAL(20,2)) AS fee,
						CAST(restQty*price AS DECIMAL(20,2)) AS totalFee,rebate,toOrder,updPrice,isPromotion,isGift,
						needAssemble,groupId,contractId,contractNo,salesId,handlerId,deptId,isVirtual,itemVolume,
						itemWeight,pkgWeight,pkgVolume,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,
						remarks
				  FROM dbo.SAD_OrderDetail_V
				  WHERE orderNo=@orderNo AND restQty>0.0) t;
			--回写订单已发货数据（预分配）	  
			UPDATE a SET a.shipQty=ISNULL(a.shipQty,0.0)+ISNULL(b.shipQty,0.0)
			FROM dbo.SAD_OrderDetail a 
				LEFT JOIN (SELECT orderId,SUM(stockQty) AS shipQty
						   FROM dbo.SAD_StockDetail
						   WHERE stockNo=@stockNo
						   GROUP BY orderId) b ON a.orderId=b.orderId
			WHERE a.orderNo=@orderNo; 
			--更新出库单总金额
			UPDATE a SET a.totalFee=b.totalFee
			FROM dbo.SAD_Stock a 
				INNER JOIN (SELECT stockNo,SUM(totalFee) AS totalFee 
							FROM dbo.SAD_StockDetail 
							WHERE stockNo=@stockNo
							GROUP BY stockNo) b ON a.stockNo=b.stockNo
			WHERE a.stockNo=@stockNo;
			--如果是厂家直送订单，则需要扣减库存
			IF (@aFlag=3)
			BEGIN
			    --打开游标
				DECLARE myCursor CURSOR
				FOR SELECT stockId,eId,itemId,stockQty
				    FROM SAD_StockDetail
				    WHERE stockNo=@stockNo
				    ORDER BY viewOrder;
				OPEN myCursor 
				FETCH NEXT FROM myCursor INTO @stockId,@eId,@itemId,@stockQty
				WHILE @@fetch_status=0 
				BEGIN  
					--更新库存总量
					UPDATE BAS_Item SET onhandQty=ISNULL(onhandQty,0.0)-ISNULL(@stockQty,0.0) WHERE itemId=@itemId;
					--仓库总账	
					IF EXISTS(SELECT 1 FROM IMS_Ledger WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId)
					BEGIN
						UPDATE IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)-@stockQty,lastOTime=@createTime
						WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
					END
					ELSE
					BEGIN
						INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastOTime)
						VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@eId,@itemId,@stockQty,0.0,@createTime);
					END								
					IF EXISTS(SELECT 1 FROM IMS_Stock WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@tmplocation,'') AND itemId=@itemId)
					BEGIN
						--入出库(调整)前库存
						SELECT @befQty=onhandQty
						FROM dbo.IMS_Stock
						WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@tmplocation,'') AND itemId=@itemId;
						UPDATE dbo.IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)-@stockQty,lastOTime=@createTime
						WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@tmplocation,'') AND itemId=@itemId;
					END
					ELSE
					BEGIN
						---如果库里面没有 进行插入
						SELECT @befQty=0.0;
						INSERT INTO dbo.IMS_Stock(stockId,companyId,warehouseId,regionId,lotNo,locationNo,eId,itemId,onhandQty,allocQty,lastOTime)
						VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@regionId,@lotNo,@tmplocation,@eId,@itemId,-@stockQty,0.0,@createTime);
					END
					--处理IMS_Book表
					INSERT INTO IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,
						eId,itemId,befQty,ioQty,afterQty,handlerId,deptId,createTime,creatorId,auditTime,auditorId,memo)
					VALUES(REPLACE(NEWID(),'-',''),'S100',@companyId,@stockId,@stockNo,@stockBillNo,'',@warehouseId,ISNULL(@lotNo,''),
						ISNULL(@tmplocation,''),@eId,@itemId,@befQty,-@stockQty,ISNULL(@befQty,0.0)-ISNULL(@stockQty,0.0),@handleId,
						@deptId,@createTime,@creatorId,@createTime,@creatorId,@memo);
					FETCH NEXT FROM myCursor INTO @stockId,@eId,@itemId,@stockQty
				END   
				CLOSE myCursor
				Deallocate myCursor
			END
		END
		ELSE
		BEGIN
			--生成出库单主表
			INSERT INTO dbo.SAD_Stock(stockNo,companyId,ownerId,billNo,createTime,warehouseId,ioType,customerId,
				addressId,receiverState,receiverCity,receiverDistrict,receiverAddress,lineId,groupId,receiverName,
				receiverTel,receiverMobile,orderType,payMode,settlementId,shipDate,shipTime,currencyId,exchangeRate,
				taxFlag,ioState,taskState,arState,totalFee,totalDiscount,discount,serviceFee,postFee,payFee,orderSource,
				buyerId,organizeId,poNo,salesId,handlerId,deptId,flag,expressNo,logisticsId,logisticsFee,buyerMessage,
				aFlag,aStockNo,memo,mergeNo,ordField1,ordField2,ordField3,ordField4,ordField5,creatorId,isLocked,
				lockerId,lockedTime,editTime,editorId)
			SELECT @stockNo,@companyId,ownerId,@stockBillNo,@createTime,warehouseId,@ioType,customerId,addressId,
				receiverState,receiverCity,receiverDistrict,receiverAddress,lineId,groupId,receiverName,receiverTel,
				receiverMobile,orderType,payMode,settlementId,shipDate,shipTime,currencyId,exchangeRate,taxFlag,
				10 AS ioState,@taskState,arState,totalFee,totalDiscount,discount,serviceFee,postFee,payFee,orderSource,
				buyerId,organizeId,poNo,salesId,handlerId,deptId,flag,expressNo,logisticsId,logisticsFee,buyerMessage,
				aFlag,aOrderNo,memo,billNo,ordField1,ordField2,ordField3,ordField4,ordField5,@creatorId,0 AS isLocked,
				'' AS lockerId,NULL AS lockedTime,@createTime,@creatorId
			FROM dbo.SAD_Order
			WHERE orderNo=@orderNo; 
			--orderDealMode:0,提示用户后处理(全部满足库存)；1,按实际库存红冲下单;
			IF (@orderDealMode='0')
			BEGIN
				INSERT INTO dbo.SAD_StockDetail(stockId,stockNo,orderId,orderNo,orderBillNo,companyId,warehouseId,
					viewOrder,lotNo,locationNo,eId,itemId,stockQty,pickQty,pkgQty,bulkQty,pkgVolumn,bulkVolumn,pkgWeight,
					bulkWeight,befPrice,discount,discountFee,price,taxrate,fee,taxFee,totalFee,toOrder,updPrice,
					isPromotion,isGift,isVirtual,needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
					contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,remarks)
				SELECT stockId,@stockNo AS stockNo,orderId,orderNo,billNo AS orderBillNo,companyId,warehouseId,
					viewOrder,lotNo,locationNo,eId,itemId,stockQty,0 AS pickQty,pkgQty,bulkQty,pkgQty*pkgVolume AS pkgVolumn,
					bulkQty*itemVolume AS bulkVolumn,pkgWeight*pkgQty AS pkgWeight,bulkQty*itemWeight AS bulkWeight,
					befPrice,discount,discountFee,price,taxrate,fee,totalFee-fee AS taxFee,totalFee,toOrder,updPrice,
					isPromotion,isGift,ISNULL(isVirtual,0),needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
					contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,remarks
				FROM (SELECT LOWER(REPLACE(NEWID(),'-','')) AS stockId,orderId,orderNo,billNo,companyId,warehouseId,
							ROW_NUMBER() OVER (ORDER BY viewOrder) AS viewOrder,'' AS lotNo,locationNo,eId,itemId,
							restQty AS stockQty,FLOOR(restQty/pkgRatio) AS pkgQty,(restQty%pkgRatio) AS bulkQty,
							befPrice,discount,discountFee,price,taxRate,
							CAST(restQty*price/(1+taxrate/100.0) AS DECIMAL(20,2)) AS fee,
							CAST(restQty*price AS DECIMAL(20,2)) AS totalFee,rebate,toOrder,updPrice,isPromotion,isGift,
							needAssemble,groupId,contractId,contractNo,boneOrdId,salesId,handlerId,deptId,isVirtual,
							itemVolume,itemWeight,pkgWeight,pkgVolume,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,
							remarks
					  FROM dbo.SAD_OrderDetail_V
					  WHERE orderNo=@orderNo AND restQty>0.0) t;
				--回写订单已发货数据（预分配）	  
				UPDATE a SET a.shipQty=ISNULL(a.shipQty,0.0)+ISNULL(b.shipQty,0.0)
				FROM dbo.SAD_OrderDetail a 
					LEFT JOIN (SELECT orderId,SUM(stockQty) AS shipQty
							   FROM dbo.SAD_StockDetail
							   WHERE stockNo=@stockNo
							   GROUP BY orderId) b ON a.orderId=b.orderId
				WHERE a.orderNo=@orderNo;
			END
			ELSE IF (@orderDealMode='1')
			BEGIN
				--把订单按库存和订单数量对比写入出库单明细（库存小于订单数量时，按库存数量写入——虚拟商品除外）
				INSERT INTO dbo.SAD_StockDetail(stockId,stockNo,orderId,orderNo,orderBillNo,companyId,warehouseId,
					viewOrder,lotNo,locationNo,eId,itemId,stockQty,pickQty,pkgQty,bulkQty,pkgVolumn,bulkVolumn,pkgWeight,
					bulkWeight,befPrice,discount,discountFee,price,taxrate,fee,taxFee,totalFee,toOrder,updPrice,
					isPromotion,isGift,isVirtual,needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,
					contractNo,boneOrdId,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,remarks)
				SELECT stockId,@stockNo AS stockNo,orderId,orderNo,billNo AS orderBillNo,companyId,warehouseId,
					viewOrder,lotNo,locationNo,eId,itemId,stockQty,0 AS pickQty, FLOOR(stockQty/pkgRatio) AS pkgQty,
					(stockQty%pkgRatio) AS bulkQty,FLOOR(stockQty/pkgRatio)*pkgVolume AS pkgVolumn,
					(stockQty%pkgRatio)*itemVolume AS bulkVolumn,FLOOR(stockQty/pkgRatio)*pkgWeight AS pkgWeight,
					(stockQty%pkgRatio)*itemWeight AS bulkWeight,befPrice,discount,discountFee,price,taxrate,
					CAST(stockQty*price/(1+taxrate/100.0) AS DECIMAL(20,2)) AS fee,
					CAST(stockQty*price AS DECIMAL(20,2))-CAST(stockQty*price/(1+taxrate/100.0) AS DECIMAL(20,2)) AS taxFee,
					CAST(stockQty*price AS DECIMAL(20,2)) AS totalFee,toOrder,updPrice,isPromotion,isGift,ISNULL(isVirtual,0),
					needAssemble,groupId,rebate,salesId,handlerId,deptId,contractId,contractNo,boneOrdId,ordDtlEx01,
					ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,remarks					
				FROM (SELECT LOWER(REPLACE(NEWID(),'-','')) AS stockId,orderId,orderNo,billNo,companyId,warehouseId,
							ROW_NUMBER() OVER (ORDER BY viewOrder) AS viewOrder,'' AS lotNo,locationNo,eId,itemId,
							CASE ISNULL(isVirtual,0) WHEN 0 THEN (CASE WHEN ISNULL(restQty,0.0)-ISNULL(availQty,0.0)>0.0 THEN availQty ELSE restQty END) 
							                         ELSE ISNULL(restQty,0.0) END AS stockQty,
							befPrice,discount,discountFee,price,taxRate,rebate,toOrder,updPrice,isPromotion,isGift,needAssemble,
							groupId,contractId,contractNo,boneOrdId,salesId,handlerId,deptId,isVirtual,itemVolume,itemWeight,
							pkgWeight,pkgVolume,pkgRatio,ordDtlEx01,ordDtlEx02,ordDtlEx03,ordDtlEx04,ordDtlEx05,remarks
					  FROM dbo.SAD_OrderDetail_V
					  WHERE orderNo=@orderNo AND restQty>0.0) t;
				--更新已预分配发货数量
				UPDATE a SET a.shipQty=ISNULL(a.shipQty,0.0)+ISNULL(b.shipQty,0.0)
				FROM dbo.SAD_OrderDetail a 
					LEFT JOIN (SELECT orderId,SUM(stockQty) AS shipQty
							   FROM dbo.SAD_StockDetail
							   WHERE stockNo=@stockNo
							   GROUP BY orderId) b ON a.orderId=b.orderId
				WHERE a.orderNo=@orderNo;
				--如果有未分配发货数量的数据，则冲红
				UPDATE dbo.SAD_OrderDetail SET orderQty=ISNULL(shipQty,0.0),isRed=1 WHERE orderNo=@orderNo AND ISNULL(stockQty,0.0)-ISNULL(shipQty,0.0)>0.0; 
			END
			--更新出库单总金额
			UPDATE a SET a.totalFee=b.totalFee
			FROM dbo.SAD_Stock a 
				INNER JOIN (SELECT stockNo,SUM(totalFee) AS totalFee 
							FROM dbo.SAD_StockDetail 
							WHERE stockNo=@stockNo
							GROUP BY stockNo) b ON a.stockNo=b.stockNo
			WHERE a.stockNo=@stockNo;
			--更新IMS_Ledger表已分配量
			UPDATE a SET a.allocQty=ISNULL(a.allocQty,0.0)+ISNULL(b.allocQty,0.0)
			FROM dbo.IMS_Ledger a
				INNER JOIN (SELECT companyId,warehouseId,itemId,SUM(stockQty) AS allocQty
							FROM dbo.SAD_StockDetail
							WHERE stockNo=@stockNo AND ISNULL(isVirtual,0)=0
							GROUP BY companyId,warehouseId,itemId
							) b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId
			INSERT INTO dbo.IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty)
			SELECT LOWER(REPLACE(NEWID(),'-','')),companyId,warehouseId,eId,itemId,0.0 AS onhandQty,allocQty
			FROM (SELECT companyId,warehouseId,eId,itemId,SUM(stockQty) AS allocQty
				  FROM dbo.SAD_StockDetail
				  WHERE stockNo=@stockNo AND isVirtual=0
				  GROUP BY companyId,warehouseId,eId,itemId
				 ) a 
			WHERE NOT EXISTS(SELECT 1 FROM dbo.IMS_Ledger b WHERE a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId);
			--虚拟库存表
            IF (ISNULL(@virtualStore,'0')='1')
            BEGIN
			    UPDATE a SET a.allocQty=ISNULL(a.allocQty,0.0)+ISNULL(b.allocQty,0.0)
			    FROM dbo.IMS_DeptLedger a
				    INNER JOIN (SELECT x.companyId,x.warehouseId,x.deptId,y.itemId,SUM(y.stockQty) AS allocQty
							    FROM dbo.SAD_Stock x 
							        INNER JOIN dbo.SAD_StockDetail y ON x.stockNo=y.stockNo
							    WHERE x.stockNo=@stockNo AND y.isVirtual=0
							    GROUP BY x.companyId,x.warehouseId,x.deptId,y.itemId
							    ) b ON a.companyId=b.companyId AND a.deptId=b.deptId AND a.itemId=b.itemId
			    INSERT INTO IMS_DeptLedger(ledgerId,companyId,deptId,eId,itemId,onhandQty,allocQty)
			    SELECT LOWER(REPLACE(NEWID(),'-','')),companyId,deptId,eId,itemId,0.0 AS onhandQty,allocQty
			    FROM (SELECT x.companyId,x.warehouseId,x.deptId,y.eid,y.itemId,SUM(y.stockQty) AS allocQty
				      FROM dbo.SAD_Stock x 
				          INNER JOIN dbo.SAD_StockDetail y ON x.stockNo=y.stockNo
				      WHERE x.stockNo=@stockNo AND y.isVirtual=0
				      GROUP BY x.companyId,x.warehouseId,x.deptId,y.eid,y.itemId
				     ) a 
			    WHERE NOT EXISTS(SELECT * FROM dbo.IMS_DeptLedger b WHERE a.companyId=b.companyId AND b.deptId=b.deptId AND a.itemId=b.itemId);
			END
		END
		--修改订单状态
		--订单全部进入待配货表
		IF NOT EXISTS(SELECT 1 FROM dbo.SAD_OrderDetail WHERE orderNo=@orderNo AND ISNULL(orderQty,0.0)-ISNULL(shipQty,0.0)>0.0)
		BEGIN
			UPDATE dbo.SAD_Order SET msgText='',isLocked=0,lockerId='',sdState=30,taskState=20,editTime=@createTime,editorId=@creatorId WHERE orderNo=@orderNo;
			IF (@start2F10='1')
			    EXEC (N'UPDATE F10BMS.dbo.SMS_Order SET WmsFlag=''已下达'' WHERE OrderNo=''' + @orderBillNo + ''';')
		END
		ELSE
		BEGIN
			UPDATE dbo.SAD_Order SET msgText='',isLocked=0,lockerId='',sdState=25,taskState=15,editTime=@createTime,editorId=@creatorId WHERE orderNo=@orderNo;
			IF (@start2F10='1')
			    EXEC (N'UPDATE F10BMS.dbo.SMS_Order SET WmsFlag=''部分下达'' WHERE OrderNo=''' + @orderBillNo + ''';')
		END
		--释放订单预占库存
		UPDATE a SET a.advQty =ISNULL(a.advQty,0.0)-ISNULL(b.stockQty,0),
		             a.realQty=ISNULL(a.realQty,0.0)-ISNULL(b.stockQty,0)
		FROM dbo.IMS_Advance a
		    INNER JOIN dbo.SAD_StockDetail b ON a.orderId=b.orderId
		WHERE b.stockNo=@stockNo;
		DELETE FROM dbo.IMS_Advance WHERE orderNo=@OrderNo AND ISNULL(advQty,0.0)<=0.0;		
		--写入订单配送节点表(和Bone平台表对应）
		INSERT INTO SAD_OrderAction(stepId,orderNo,orderBillNo,stockNo,wmsStockNo,stockBillNo,[action],actionDesc,actionTime,companyId,ownerId,thirdSyncFlag)
		SELECT LOWER(REPLACE(NEWID(),'-','')),ordField2,billNo,orderNo,@stockNo,@stockBillNo,3,'您的订单已通过仓库审核，等待分拣',GETDATE(),companyId,ownerId,0
		FROM dbo.SAD_Order a
		WHERE orderNo=@orderNo
			AND NOT EXISTS(SELECT * FROM dbo.SAD_OrderAction b WHERE b.stockNo=@orderNo AND b.wmsStockNo=@stockNo AND b.action=3);
		--释放锁
		UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='so_audit_job';
		COMMIT;		
	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT>0)
			 ROLLBACK;
		SELECT @errMsg = ERROR_MESSAGE();		
        UPDATE dbo.SAD_Order SET msgText=@errMsg WHERE orderNo=@orderNo;		
	    RETURN -1;	
	END CATCH
END
go

