/*==============================================================*/
/* View: WMS_F10_PMS_StockDtl_V                                 */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_PMS_StockDtl_V] as
SELECT a.stockId,a.StockNo,h.billNo AS stockBillNo,w.warehouseNo AS WareHouse,a.locationNo,
	b.poId AS orderId,a.orderBillNo AS orderNo,c.f10Id AS itemId,ROUND(a.receiveQty/c.pkgRatio,4) AS pkgQty,
	a.receiveQty AS SQty,a.price,a.totalFee AS Amt,0.0 AS IQty,0.0 AS IAmt,0.0 AS RQty,
	b.updPrice AS IsEffect,b.toOrder AS IsSpecial,b.taxFlag,a.planId,a.planNo,a.isPromotion,
	a.isTemporary,a.isEmergency,b.sdOrderId AS XS_OrderId,a.sdOrderNo AS XS_OrderNo,
	b.sdCustomerNo AS XS_CustNo,b.sdCustomerName AS XS_CustName,a.contractId,a.contractNo,
    0.0 AS PAmt,0.0 AS PIAmt,a.remarks 
FROM dbo.PMS_StockDetail a
	INNER JOIN dbo.PMS_Stock h ON a.stockNo=h.stockNo
	INNER JOIN dbo.PMS_OrderDetail b On a.orderId=b.orderId
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	INNER JOIN F10BMS.dbo.WMS_F10_Item_V c ON a.itemId=c.itemId
WHERE (h.ioState=30)
	AND (h.thirdSyncFlag=0 OR h.thirdSyncFlag=2) 
    AND (h.orderSource IN(11,12,13,14,15,16,17,18))
go

