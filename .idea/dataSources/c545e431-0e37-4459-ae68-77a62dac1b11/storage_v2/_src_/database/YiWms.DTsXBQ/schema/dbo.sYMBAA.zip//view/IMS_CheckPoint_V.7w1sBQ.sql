/*==============================================================*/
/* View: IMS_CheckPoint_V                                       */
/*==============================================================*/
--creator：        Frank
--create time：  2016-03-02
--盘点设置视图 2017-04-01 V1.0 Frank.He重新整理
--盘点设置增加品牌和分类 2018-04-23 Frank.He
CREATE view [dbo].[IMS_CheckPoint_V] as
SELECT cp.pointId,cp.pointNo,cp.companyId,c.companyNo,c.companyName,cp.warehouseId,w.warehouseNo,
    w.warehouseName,cp.startArea,r1.regionNo AS startRegionNo,r1.regionDesc AS startRegionDesc, 
    cp.endArea,r2.regionNo AS endRegionNo,r2.regionDesc AS endRegionDesc,cp.startOwner,
    o1.ownerNo AS startOwnerNo,o1.ownerName AS startOwnerName,cp.endOwner,o2.ownerNo AS endOwnerNo, 
    o2.ownerName AS endOwnerName,cp.startNo,cp.endNo,cp.startItem,b1.itemNo AS startItemNo, 
    b1.itemName AS startItemName,cp.endItem,b2.itemNo AS endItemNo,b2.itemName AS endItemName, 
    cp.brandId,bd.brandNo,bd.brandCName,cp.categoryId,cat.categoryNo,cat.categoryCName,    
    cp.pointDate,CONVERT(VARCHAR(20),cp.startTime,120) AS startTime,CONVERT(VARCHAR(20),cp.endTime,120) AS endTime,
    cp.printNum,cp.inventory,CASE cp.inventory WHEN 1 THEN '库存归零' ELSE '保持原值' END inventoryDesc, 
    cp.checkState,CASE cp.checkState WHEN 0 THEN '已作废' WHEN 10 THEN '待盘点' WHEN 20 THEN '盘点中' WHEN 30 THEN '已完成' END stateName,
    cp.checkData,CASE cp.checkData WHEN 1 THEN '账面库存' WHEN 2 THEN '动态库存' END AS checkDataDesc,
    cp.parentId,CASE cp.parentId WHEN '-1' THEN '原始设置' ELSE '复盘设置' END AS reCheckDesc,
    cp.isLocked,cp.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),cp.lockedTime,120) AS lockedTime,
    cp.createTime,cp.creatorId,u2.userNick AS creatorName,cp.editTime,cp.editorId,
    u3.userNick AS editorName,cp.isSelected
FROM dbo.IMS_CheckPoint AS cp 
    INNER JOIN dbo.SAM_Company AS c ON cp.companyId = c.companyId 
    INNER JOIN dbo.BAS_Warehouse AS w ON cp.warehouseId = w.warehouseId 
    LEFT JOIN dbo.BAS_Region AS r1 ON cp.startArea = r1.regionId 
    LEFT JOIN dbo.BAS_Region AS r2 ON cp.endArea = r2.regionId 
    LEFT JOIN dbo.BAS_Owner_V AS o1 ON cp.startOwner = o1.ownerId 
    LEFT JOIN dbo.BAS_Owner_V AS o2 ON cp.endOwner = o2.ownerId 
    LEFT JOIN dbo.BAS_Brand AS bd ON cp.brandId =bd.brandId 
    LEFT JOIN dbo.BAS_Category cat ON cp.categoryId=cat.categoryId 
    LEFT JOIN dbo.BAS_Item AS b1 ON cp.startItem = b1.itemId 
    LEFT JOIN dbo.BAS_Item AS b2 ON cp.endItem = b2.itemId 
    LEFT JOIN dbo.SAM_User AS u1 ON cp.lockerId = u1.userId 
    LEFT JOIN dbo.SAM_User AS u2 ON cp.creatorId = u2.userId 
    LEFT JOIN dbo.SAM_User AS u3 ON cp.editorId = u3.userId
go

