





--creator：     Frank
--create time:  2017-03-18
--description:	拼箱分拣标签打印
--modify:       2017-10-17 frank.He 整理 系统增加整件超过N件时只生成一个任务，只打印一个标签的算法，修改对应打印标签视图
CREATE view [dbo].[WMS_PickingLCL_V] as
SELECT a.pickId,a.pickingNo,a.companyId,a.stockNo,a.stockBillNo,a.stockBox,a.boxBillNum,a.taskState,c.waveBillNo,
	d.customerNo,d.customerName,d.customerDepart,d.shortName,w.warehouseName,r.regionDesc,al.lineName,d.collectOrder AS lineOrder,
	d.mergeNo,ISNULL(r.regionDesc,a.cargoArea) AS tmpRegion,CAST(b.lclQty AS INT) AS lclQty,CAST(pd.pkgQty AS INT) AS pkgQty,
	CAST(ISNULL(b.lclQty,0)+ISNULL(pd.pkgQty,0) AS INT) AS totalQty,u1.userNo AS pickerNo,u1.userNick AS pickerName,
	CONVERT(VARCHAR(20),a.pickTime,120) AS pickTime,u2.userNo AS checkerNo,u2.userNick AS checkerName,
	CONVERT(VARCHAR(20),a.checkTime,120) AS checkTime,CONVERT(VARCHAR(20),c.getTime,120) AS getTime,u3.userNo AS packagerNo,
	u3.userNick AS packagerName,CONVERT(VARCHAR(20),a.packingTime,120) AS packingTime,d.fullAddress,d.receiverName,
	d.collectOrder,LTRIM(ISNULL(d.receiverMobile,'')+' '+ISNULL(d.receiverTel,'')) AS fullTel,d.buyerId,c.printNum,c.printTime,
	d.organizeId,'第'+cast(a.stockBox as varchar(20))+'件 共'+ cast(b.lclQty as varchar(20))+'件' AS labDesc,
	'总计:'+CAST(ISNULL(b.lclQty,0)+ISNULL(pd.pkgQty,0) AS varchar(4))+'件' AS labTotalDesc,d.memo,
	'拼 ' + CAST(a.stockBox AS VARCHAR) + '/' + CAST(CAST(b.lclQty AS INT) AS VARCHAR) + ' 总 ' + CAST(CAST(ISNULL(b.lclQty,0)+ISNULL(pd.pkgQty,0) AS INT) AS VARCHAR) AS pickingDesc
FROM dbo.WMS_PickingOrder a
	INNER JOIN (SELECT stockNo,SUM(CASE isPackage WHEN 0 THEN 1 ELSE 0 END) lclQty
                FROM dbo.WMS_PickingOrder
                GROUP BY stockNo) b ON a.stockNo=b.stockNo
    INNER JOIN (SELECT stockNo,CAST(SUM(CASE isPackage WHEN 0 THEN 0 ELSE pickQty END) AS INT) AS pkgQty
				FROM dbo.WMS_PickingDetail
				GROUP BY stockNo) pd ON a.stockNo=pd.stockNo
    INNER JOIN dbo.WMS_Picking c ON a.pickingNo=c.pickingNo
    INNER JOIN (SELECT x.stockNo,x.mergeNo,p.partnerNo AS customerNo,p.partnerName AS customerName,
					p.shortName,x.organizeId,x.groupId,x.buyerId,x.collectOrder,						
					LTRIM(ISNULL(p.partnerName,'') + '  ' + ISNULL(x.organizeId,'')) AS customerDepart,
                    ISNULL(x.receiverAddress,'') AS fullAddress,x.receiverName,x.receiverMobile,x.receiverTel,
                    x.taskState,x.memo
                FROM dbo.SAD_Stock x
                    INNER JOIN dbo.BAS_Partner p ON x.customerId=p.partnerId
                ) d ON a.stockNo=d.stockNo
	INNER JOIN dbo.BAS_Warehouse w ON c.warehouseId=w.warehouseId
	LEFT JOIN dbo.BAS_AddressLine al ON a.lineId=al.lineId
	LEFT JOIN dbo.BAS_Region r ON a.cargoArea=r.regionId
	LEFT JOIN dbo.SAM_User u1 ON a.pickerId=u1.userId
	LEFT JOIN dbo.SAM_User u2 ON a.checkerId=u2.userId
    LEFT JOIN dbo.SAM_User u3 ON a.packingId=u3.userId
WHERE a.isPackage=0
go

