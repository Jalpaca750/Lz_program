
/*==============================================================*/
/* View: BAS_Package_V                                          */
/*==============================================================*/
create view BAS_Package_V as
SELECT p.packageId,p.companyId, p.packageNo,p.packageName,p.isDisable,CASE p.isDisable WHEN 1 THEN '是' ELSE '否' END AS disableName,
      p.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(10),p.lockedTime,23) AS lockedTime,p.createTime,p.creatorId,
      u2.userNick AS creatorName,p.editTime,p.editorId,u3.userNick AS editorName,p.isSelected
FROM dbo.BAS_Package p LEFT JOIN
      dbo.SAM_User u1 ON p.lockerId=u1.userId LEFT JOIN
      dbo.SAM_User u2 ON p.creatorId=u2.userId LEFT JOIN
      dbo.SAM_User u3 ON p.editorId=u3.userId
go

