-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2016-12-20>
-- Description:	<Description:采购入库单收货处理（更新订单、入库单状态，并生成上架数据(预分配表和历史表））>
-- 依赖：
--      采购上架策略
--      对应函数(dbo.uf_GetPurchaseLocation)    
--      Frank 2017.05.03 增加partnerId字段到上架任务表  
--      zdy:2017-11-08 多区域的时候  putawayNo 取的的方式修改
--      Frank 2019.01.08 修改采购上架算法，可根据库位体积推荐上架库位
--      Frank 2019.08.01 增加作业排队，避免死锁
--      Frank 2019.12.02 临采订单进入临时库位（一对一采购:
--                       采购订单池中的销售ID(PMS_OrderDetail.sdOrderId)对销售订单池中的销售ID(SAD_OrderDetail.contractId)
-- =============================================
CREATE PROCEDURE [dbo].[up_Audit_PurReceive] 
(
    @stockNo VARCHAR(32),			--收货单No(主键）
	@operatorId VARCHAR(32)			--操作员
)
AS
BEGIN
    DECLARE @stockId VARCHAR(32);			--入库单明细Id
    DECLARE @companyId VARCHAR(32);			--公司Id
    DECLARE @billNo VARCHAR(32);			--收货单编号
    DECLARE @billType VARCHAR(32);			--业务类型
    DECLARE @partnerId VARCHAR(32);			--供应商Id
    DECLARE @ownerId VARCHAR(32);			--业主Id
    DECLARE @warehouseId VARCHAR(32);		--仓库Id
    DECLARE @itemId VARCHAR(32);			--商品Id
    DECLARE @recBin VARCHAR(32);			--收货库位(过渡库位)
    DECLARE @receiveQty DECIMAL(20,6);		--收货数量
    DECLARE @stockQty DECIMAL(20,6);		--临时数量
    DECLARE @maxQty DECIMAL(20,6);			--总数量
    DECLARE @onhandQty DECIMAL(20,6);		--预计库存
    DECLARE @lotNo VARCHAR(32);				--批次号
    DECLARE @orderSource INT;				--订单类型
    DECLARE @unitLevel VARCHAR(10);			--单位级别
    DECLARE @orderNo VARCHAR(32);			--订单主表No
    DECLARE @pkgRatio INT;                  --包装规格
    DECLARE @viewOrder INT;					--序号						
	DECLARE @putawayMode VARCHAR(100);		--收货模式：1,按整散数量分离上架;2,优先满足散件库位最高库存
    DECLARE @regionId VARCHAR(32);			--区域
    DECLARE @locationNo VARCHAR(32);		--库位(上架库位)
    DECLARE @tmpId INT;                     --临时库位表主键Id
    DECLARE @putawayNo VARCHAR(32);			--上架主表No
    DECLARE @flowId VARCHAR(32);            --主键Id
    DECLARE @sdOrderId VARCHAR(32);         --销售订单Id(F10或者第三方系统)
    DECLARE @sdOrderNo VARCHAR(32);         --销售订单No(F10或者第三方系统)
    DECLARE @orderId VARCHAR(32);           --销售订单Id
	DECLARE @ErrMsg nvarchar(1000), @ErrSeverity BIGINT,@errors BIGINT;
	--用于存储临时数据
	DECLARE @temp TABLE(stockId VARCHAR(32),companyId VARCHAR(32),ownerId VARCHAR(32),warehouseId VARCHAR(32),orderSource VARCHAR(32),itemId VARCHAR(32),receiveQty DECIMAL(20,6),pkgRatio INT,lotNo VARCHAR(32),recBin VARCHAR(32),unitLevel VARCHAR(10),orderNo VARCHAR(32),viewOrder INT IDENTITY(1,1),sdOrderId VARCHAR(32),sdOrderNo VARCHAR(32));
	--临时存放库位表（体积限制）
	DECLARE @uTable TABLE(viewOrder INT,warehouseId VARCHAR(32),regionId VARCHAR(32),itemId VARCHAR(32),locationNo VARCHAR(32),lotNo VARCHAR(32),SQty DECIMAL(20,6));
	--收货单编号
	SELECT @companyId=companyId,@ownerId=ownerId,@warehouseId=warehouseId,@billNo=billNo,@partnerId=supplierId,@billType=ioType
	FROM dbo.PMS_Stock 
	WHERE stockNo=@stockNo;	
	--收货模式：1,按整散数量分离上架;2,优先满足散件库位最高库存
	SELECT @putawayMode=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='RECEIVE_PUTAWAY_QTY_MODE';
	SET @putawayMode=CASE ISNULL(@putawayMode,'') WHEN '' THEN '1' ELSE @putawayMode END;
	SET @errors=0;
	BEGIN TRY
		BEGIN TRANSACTION	
		--排队等待
        WHILE EXISTS(SELECT * FROM dbo.SAM_Schedule WHERE jobCode='po_receive_job' AND IsLocked=1)
        BEGIN
            SET @errors=0;
        END
        UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='up_Audit_PurReceive',lockedTime=GETDATE() WHERE jobCode='po_receive_job';  
        SET @errors=@errors+@@ERROR;  
		--收货模式：1,按整散数量分离上架
		IF (@putawayMode='1')
		BEGIN
			INSERT INTO @temp(stockId,companyId,ownerId,warehouseId,orderSource,itemId,receiveQty,pkgRatio,lotNo,recBin,unitLevel,orderNo,sdOrderId,sdOrderNo)
			SELECT stockId,@companyId,@ownerId,@warehouseId,orderSource,itemId,receiveQty,pkgRatio,lotNo,recBin,unitLevel,orderNo,sdOrderId,sdOrderNo
			FROM (
					SELECT b.stockId,c.orderSource,b.itemId,FLOOR(b.receiveQty/bi.pkgRatio) AS receiveQty,bi.pkgRatio,b.lotNo,b.recBin,
						'CS' AS unitLevel,b.orderNo,b.viewOrder,b.sdOrderId,b.sdOrderNo
					FROM dbo.PMS_StockDetail b
						INNER JOIN dbo.BAS_Item bi ON b.itemId=bi.itemId 
						LEFT JOIN dbo.PMS_Order c ON b.orderNo=c.orderNo
					WHERE b.stockNo=@stockNo AND FLOOR(b.receiveQty/bi.pkgRatio)>0.0 AND bi.isVirtual=0
					UNION ALL
					--散件上架(临时数据）
					SELECT b.stockId,c.orderSource,b.itemId,(b.receiveQty % bi.pkgRatio) AS receiveQty,bi.pkgRatio,b.lotNo,b.recBin,
						'EA' AS unitLevel,b.orderNo,b.viewOrder,b.sdOrderId,b.sdOrderNo
					FROM dbo.PMS_StockDetail b 
						INNER JOIN dbo.BAS_Item bi ON b.itemId=bi.itemId
						LEFT JOIN dbo.PMS_Order c ON b.orderNo=c.orderNo
					WHERE b.stockNo=@stockNo AND (b.receiveQty % bi.pkgRatio)>0.0 AND bi.isVirtual=0
				) t 
			ORDER BY unitLevel,viewOrder;
			SET @errors=@errors+@@ERROR;
		END
		ELSE
		BEGIN
			--收货模式：2,优先满足散件库位最高库存
			DECLARE tmpStock CURSOR
			FOR
				SELECT b.stockId,c.orderSource,b.itemId,b.receiveQty,bi.pkgRatio,b.lotNo,b.recBin,b.orderNo,b.viewOrder,b.sdOrderId,b.sdOrderNo
				FROM dbo.PMS_StockDetail b 
					INNER JOIN dbo.BAS_Item bi ON b.itemId=bi.itemId 
					LEFT JOIN dbo.PMS_Order c ON b.orderNo=c.orderNo
				WHERE b.stockNo=@stockNo AND bi.isVirtual=0;
			OPEN tmpStock;
			FETCH NEXT FROM tmpStock INTO @stockId,@orderSource,@itemId,@receiveQty,@pkgRatio,@lotNo,@recBin,@orderNo,@viewOrder,@sdOrderId,@sdOrderNo;
			WHILE @@FETCH_STATUS=0
			BEGIN
				SET @stockQty=0;
				SET @maxQty=0;
				--判断是否散件库位固定存储
				IF EXISTS(SELECT * FROM BAS_Location WHERE warehouseId=@warehouseId AND isPackage=10 AND isFixed=1 AND itemId=@itemId AND ISNULL(maxQty,0.0)>0.0)
				BEGIN
					SELECT TOP 1 @maxQty=maxQty,@locationNo=locationNo FROM BAS_Location WHERE warehouseId=@warehouseId AND isPackage=10 AND isFixed=1 AND itemId=@itemId ORDER BY putawayOrder;
					--判断固定库位当前库存
					SELECT @onhandQty=ISNULL(onhandQty,0.0)-ISNULL(allocQty,0.0)+ISNULL(onWayQty,0.0) 
					FROM dbo.IMS_Stock
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@locationNo AND itemId=@itemId;
					--可以再存放的数据
					SET @maxQty=ISNULL(@maxQty,0.0)-ISNULL(@onhandQty,0.0);	
					--如果当前收货数量只够放在散件固定库位	
					IF (ISNULL(@maxQty,0.0)-ISNULL(@receiveQty,0.0)>=0.0)
					BEGIN
						INSERT INTO @temp(stockId,companyId,ownerId,warehouseId,orderSource,itemId,receiveQty,pkgRatio,lotNo,recBin,unitLevel,orderNo,sdOrderId,sdOrderNo)
						VALUES(@stockId,@companyId,@ownerId,@warehouseId,@orderSource,@itemId,@receiveQty,@pkgRatio,@lotNo,@recBin,'EA',@orderNo,ISNULL(@sdOrderId,''),ISNULL(@sdOrderNo,''));		
					    SET @errors=@errors+@@ERROR;
					END
					ELSE
					BEGIN
						--多出部分(最小整件数，0.12件算0件）整件数，满足散件					
						SET @stockQty=FLOOR((ISNULL(@receiveQty,0.0)-ISNULL(@maxQty,0.0))/@pkgRatio)*@pkgRatio;
						SET @errors=@errors+@@ERROR;
						--收货数量大于整件数量，且整件数量大于零
						IF (ISNULL(@stockQty,0.0)>0.0)
						BEGIN
							INSERT INTO @temp(stockId,companyId,ownerId,warehouseId,orderSource,itemId,receiveQty,pkgRatio,lotNo,recBin,unitLevel,orderNo,sdOrderId,sdOrderNo)
							VALUES(@stockId,@companyId,@ownerId,@warehouseId,@orderSource,@itemId,@stockQty/@pkgRatio,@pkgRatio,@lotNo,@recBin,'CS',@orderNo,ISNULL(@sdOrderId,''),ISNULL(@sdOrderNo,''));
						    SET @errors=@errors+@@ERROR;
						END
						IF (ISNULL(@receiveQty,0.0)-ISNULL(@stockQty,0.0)>0.0)
						BEGIN						
							INSERT INTO @temp(stockId,companyId,ownerId,warehouseId,orderSource,itemId,receiveQty,pkgRatio,lotNo,recBin,unitLevel,orderNo,sdOrderId,sdOrderNo)
							VALUES(@stockId,@companyId,@ownerId,@warehouseId,@orderSource,@itemId,(ISNULL(@receiveQty,0.0)-ISNULL(@stockQty,0.0)),@pkgRatio,@lotNo,@recBin,'EA',@orderNo,ISNULL(@sdOrderId,''),ISNULL(@sdOrderNo,''));
						    SET @errors=@errors+@@ERROR;
						END
					END
				END
				ELSE
				BEGIN
					--没找到固定库位，则整件数量
					SET @stockQty=FLOOR(ISNULL(@receiveQty,0.0)/@pkgRatio)*@pkgRatio;
					SET @errors=@errors+@@ERROR;
					IF (ISNULL(@stockQty,0.0)>0.0)
					BEGIN
						INSERT INTO @temp(stockId,companyId,ownerId,warehouseId,orderSource,itemId,receiveQty,pkgRatio,lotNo,recBin,unitLevel,orderNo,sdOrderId,sdOrderNo)
						VALUES(@stockId,@companyId,@ownerId,@warehouseId,@orderSource,@itemId,@stockQty/@pkgRatio,@pkgRatio,@lotNo,@recBin,'CS',@orderNo,ISNULL(@sdOrderId,''),ISNULL(@sdOrderNo,''));
					    SET @errors=@errors+@@ERROR;
					END
					--整件分配完还有散件
					IF (ISNULL(@receiveQty,0.0)-ISNULL(@stockQty,0.0)>0.0)
					BEGIN
						INSERT INTO @temp(stockId,companyId,ownerId,warehouseId,orderSource,itemId,receiveQty,pkgRatio,lotNo,recBin,unitLevel,orderNo,sdOrderId,sdOrderNo)
						VALUES(@stockId,@companyId,@ownerId,@warehouseId,@orderSource,@itemId,(ISNULL(@receiveQty,0.0)-ISNULL(@stockQty,0.0)),@pkgRatio,@lotNo,@recBin,'EA',@orderNo,ISNULL(@sdOrderId,''),ISNULL(@sdOrderNo,''));
					    SET @errors=@errors+@@ERROR;
					END
				END
				FETCH NEXT FROM tmpStock INTO @stockId,@orderSource,@itemId,@receiveQty,@pkgRatio,@lotNo,@recBin,@orderNo,@viewOrder,@sdOrderId,@sdOrderNo;
			END
			CLOSE tmpStock;
			DEALLOCATE tmpStock;
		END
		--如果没有需要上架的数据（全部非实物商品）
        IF NOT EXISTS(SELECT * FROM @temp)
        BEGIN
            --更新入库单
		    UPDATE PMS_Stock SET ioState=30,editorId=@operatorId,editTime=GETDATE(),auditorId=@operatorId,auditTime=GETDATE() WHERE stockNo=@stockNo;
		    SET @errors=@errors+@@ERROR;
        END
        ELSE
        BEGIN
		    --取得上架数据	
		    DECLARE myStock CURSOR
		    FOR 
			    SELECT stockId,companyId,ownerId,warehouseId,orderSource,itemId,receiveQty,pkgRatio,lotNo,recBin,unitLevel,orderNo,viewOrder,sdOrderId,sdOrderNo
			    FROM @temp
			    ORDER BY unitLevel,viewOrder;
		    OPEN myStock;
		    FETCH NEXT FROM myStock INTO @stockId,@companyId,@ownerId,@warehouseId,@orderSource,@itemId,@receiveQty,@pkgRatio,@lotNo,@recBin,@unitLevel,@orderNo,@viewOrder,@sdOrderId,@sdOrderNo;
		    WHILE @@FETCH_STATUS=0
		    BEGIN
		        --预分配了采购库位
		        IF EXISTS(SELECT * FROM SAD_OrderDetail WHERE contractId=@sdOrderId AND ISNULL(locationNo,'')!='')
		        BEGIN
		            UPDATE IMS_Advance SET purQty=CASE @unitLevel WHEN 'EA' THEN ISNULL(purQty,0.0)+ISNULL(@receiveQty,0.0) 
		                                                          WHEN 'CS' THEN ISNULL(purQty,0.0)+ISNULL(@receiveQty,0.0)*@pkgRatio END
		            WHERE companyId=@companyId AND orderId=(SELECT orderId FROM SAD_OrderDetail WHERE contractId=@sdOrderId);
		            SET @errors=@errors+@@ERROR;
		        END
		        --如果对应销售订单有预分配库位
		        IF (@unitLevel='EA') AND EXISTS(SELECT * FROM SAD_OrderDetail WHERE contractId=@sdOrderId AND ISNULL(locationNo,'')!='') 
		        BEGIN		            
		            SELECT TOP 1 @locationNo=ISNULL(locationNo,'')
	                FROM SAD_OrderDetail 
	                WHERE contractId=@sdOrderId;
		            INSERT INTO @uTable(viewOrder,warehouseId,regionId,locationNo,lotNo,itemId,SQty)
		            SELECT TOP 1 1,warehouseId,regionId,locationNo,@lotNo,@itemId,@receiveQty
		            FROM BAS_Location
		            WHERE warehouseId=@warehouseId AND locationNo=@locationNo;     
		        END
		        ELSE
		        BEGIN
		            --生成上架库位
			        INSERT INTO @uTable(viewOrder,warehouseId,regionId,locationNo,lotNo,itemId,SQty)
			        SELECT viewOrder,warehouseId,regionId,locationNo,lotNo,itemId,SQty
			        FROM dbo.uf_GetPurchaseLocation(@companyId,@ownerId,@warehouseId,@itemId,@recBin,@receiveQty,@lotNo,@orderSource,@unitLevel);
			    END
			    SET @errors=@errors+@@ERROR;
		        IF NOT EXISTS(SELECT * FROM @uTable)
		        BEGIN
		            SELECT @ErrMsg='商品[' + itemNo +']未找到可用的存储库位' FROM BAS_Item WHERE itemId=@itemId;
		            SET @errors=@errors+101;
		            BREAK;
		        END	
			    --循环生产上架数据
			    WHILE EXISTS(SELECT * FROM @uTable)
			    BEGIN
			        SELECT TOP 1 @tmpId=viewOrder,@locationNo=locationNo,@regionId=regionId FROM @uTable ORDER BY viewOrder;
			        --判断上架主表是否已经写入
			        IF NOT EXISTS(SELECT 1 FROM WMS_Putaway WHERE stockNo=@stockNo AND unitLevel=@unitLevel AND regionId=@regionId)
			        BEGIN
				        SET @putawayNo =REPLACE(NEWID(),'-','');	
				        INSERT INTO WMS_Putaway(putawayNo,billType,stockNo,billNo,partnerId,companyId,ownerId,warehouseId,regionId,unitLevel,ioState,isLocked,lockerId,lockedTime,createTime,creatorId)
				        VALUES(@putawayNo,@billType,@stockNo,@billNo,@partnerId,@companyId,@ownerId,@warehouseId,@regionId,@unitLevel,20,0,'',NULL,GETDATE(),@operatorId);
			        END
			        ELSE
			        BEGIN
			            SELECT @putawayNo=putawayNo FROM WMS_Putaway WHERE stockNo=@stockNo AND unitLevel=@unitLevel AND regionId=@regionId
			        END
			        SET @errors=@errors+@@ERROR;
			        
			        --写入上架清单
			        SET @flowId=REPLACE(NEWID(),'-','');
			        INSERT INTO WMS_PutawayDetail(flowId,putawayNo,stockId,stockNo,companyId,warehouseId,viewOrder,lotNo,locationNo,itemId,unitLevel,putQty,pkgRatio,ioState,createTime,creatorId)
			        VALUES(@flowId,@putawayNo,@stockId,@stockNo,@companyId,@warehouseId,@viewOrder,@lotNo,@locationNo,@itemId,@unitLevel,@receiveQty,@pkgRatio,20,GETDATE(),@operatorId);
			        SET @errors=@errors+@@ERROR;
			        --写入预分配表
			        INSERT INTO IMS_Allocate(allocId,stockId,stockNo,companyId,warehouseId,regionId,locationNo,lotNo,itemId,allocQty,ioFlag,unitLevel)
			        VALUES(@flowId,@stockId,@stockNo,@companyId,@warehouseId,@regionId,@locationNo,@lotNo,@itemId,@receiveQty,'+',@unitLevel);
				    SET @errors=@errors+@@ERROR;
				    --删除临时表
				    DELETE FROM @uTable WHERE viewOrder=@tmpId;
				    SET @errors=@errors+@@ERROR;
    			END
    			--更新入库单状态
			    UPDATE PMS_StockDetail SET ioState=20 WHERE stockId=@stockId;
			    SET @errors=@errors+@@ERROR;
		        --处理订单
		        IF EXISTS(SELECT 1 FROM PMS_OrderDetail WHERE orderNo=@orderNo AND ISNULL(orderQty,0.0)-ISNULL(receiveQty,0.0)>0.0)
			        UPDATE PMS_Order SET poState=3,editTime=GETDATE(),editorId=@operatorId WHERE orderNo=@orderNo;
		        ELSE
			        UPDATE PMS_Order SET poState=4,editTime=GETDATE(),editorId=@operatorId WHERE orderNo=@orderNo;
			    SET @errors=@errors+@@ERROR;
			    FETCH NEXT FROM myStock INTO @stockId,@companyId,@ownerId,@warehouseId,@orderSource,@itemId,@receiveQty,@pkgRatio,@lotNo,@recBin,@unitLevel,@orderNo,@viewOrder,@sdOrderId,@sdOrderNo
		    END
		    CLOSE myStock;
		    DEALLOCATE myStock;
		    --更新入库单
		    UPDATE PMS_Stock SET ioState=20,editorId=@operatorId,editTime=GETDATE(),auditorId=@operatorId,auditTime=GETDATE() WHERE stockNo=@stockNo;
		    SET @errors=@errors+@@ERROR;
		END
	    UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='po_receive_job';	
	    SET @errors=@errors+@@ERROR;
		--缺少库位，需要回滚事务，并写入日志	
		IF (@errors=0)
		BEGIN
		    COMMIT;
		END
		ELSE
		BEGIN
		    IF (@@TRANCOUNT > 0)
                ROLLBACK;
            --写日志
            INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_Audit_PurReceive','YI_PURCHASE_RECEIVE_IS_ERROR',@ErrMsg,@stockNo,@billNo);
		    UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='po_receive_job';
		END
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK;
	    --解除功能
	    UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='po_receive_job';
		--获取出错消息
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();
		--写入错误日志
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_Audit_PurReceive','YI_PURCHASE_RECEIVE_IS_ERROR',LEFT(@ErrMsg,2000),@stockNo,@billNo);
	END CATCH
END
go

