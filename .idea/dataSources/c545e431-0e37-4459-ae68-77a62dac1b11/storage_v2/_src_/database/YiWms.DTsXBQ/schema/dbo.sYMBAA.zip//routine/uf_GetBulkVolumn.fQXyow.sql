
-- =============================================
-- Author:		<Frank.He>
-- Create date: <2016-12-07>
-- Description:	<获取拼箱对应的箱子体积>
-- =============================================

CREATE FUNCTION [dbo].[uf_GetBulkVolumn]
(
	@companyId VARCHAR(32),
	@volumn DECIMAL(20,6)
)
RETURNS DECIMAL(20,6)
AS
BEGIN
	DECLARE @boxVolumn VARCHAR(32);
	SET @boxVolumn=@volumn;
	SELECT Top 1 @boxVolumn=boxVolume
	FROM WMS_BoxSize
	WHERE companyId=@companyId AND boxVolume>@volumn 
	ORDER BY boxVolume;
	RETURN @boxVolumn;
END
go

