-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-08-04>
-- Description:	<Description:留仓扫描>
--      2018-04-16日修正退货单、发票、项目类单据送货员获取Bug
-- Parameter:
--		@companyId:公司Id
--		@siteId: 网点Id
--      @waybillId:出库单Id
--      @waybillNo: 出库单编号
--		@typeId:留仓类型
--		@reasonId:留仓原因
--		@otherReason:其他原因
--      @operatorId:操作员Id
-- =============================================

CREATE PROCEDURE [dbo].[up_TransportUndelivered] 
(
	@companyId VARCHAR(32),			--公司Id
	@siteId VARCHAR(32),			--网点Id
    @waybillId VARCHAR(32),			--运单Id
	@waybillNo VARCHAR(32),			--运单编号
	@typeId VARCHAR(32),			--留仓原因
	@reasonId VARCHAR(32),			--留仓原因
	@otherReason VARCHAR(200),		--下次派件时间 exField01
	@personId VARCHAR(32),			--留仓责任人   exField02
	@operatorId VARCHAR(32)			--操作员Id
)
AS
BEGIN
	DECLARE @curTime DATETIME,@stockNo VARCHAR(32),@stockBillNo VARCHAR(32),@undelivered INT,@billType INT,@deliveryId VARCHAR(32);
	DECLARE @ownerId VARCHAR(32),@orderNo VARCHAR(32),@orderBillNo VARCHAR(32),@boneOrdNo VARCHAR(32)
	DECLARE @tmpOrder TABLE(ownerId VARCHAR(32),orderNo VARCHAR(32),orderBillNo VARCHAR(32),boneOrdNo VARCHAR(32));
	SET @curTime=GETDATE();	
	SELECT @undelivered=CASE recount WHEN 1 THEN 0 ELSE 1 END
	FROM dbo.TMS_Reason
	WHERE reasonId=@reasonId;
	DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='up_TransportUndelivered' AND billId=@waybillId;
	BEGIN TRY
		BEGIN TRANSACTION	
		IF EXISTS(SELECT 1 FROM dbo.TMS_WayBill WHERE waybillId=@waybillId AND billState=99)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_TransportUndelivered','YI_TRANSPORT_UNDELIVERED_ERROR','单据[' + @waybillNo + ']已回单，操作无效',@waybillId,@waybillNo);		
			COMMIT;
			RETURN;
		END	
		IF EXISTS(SELECT 1 FROM dbo.TMS_WayBill WHERE waybillId=@waybillId AND billState=90)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_TransportUndelivered','YI_TRANSPORT_UNDELIVERED_ERROR','单据[' + @waybillNo + ']已妥投，操作无效',@waybillId,@waybillNo);		
			COMMIT;
			RETURN;
		END	
		IF EXISTS(SELECT 1 FROM dbo.TMS_WayBill WHERE waybillId=@waybillId AND billState<30)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_TransportUndelivered','YI_TRANSPORT_UNDELIVERED_ERROR','单据[' + @waybillNo + ']未派件，操作无效',@waybillId,@waybillNo);		
			COMMIT;
			RETURN;
		END			
		--配送中的运单状态更新为80-未送达
		UPDATE dbo.TMS_WayBill SET billState=80 WHERE waybillId=@waybillId AND billState=30;
		IF(@@ROWCOUNT>0)
		BEGIN			
			--查找当前运单对应的出库单
			SELECT @stockNo=wmsStockNo,@billType=billType,@stockBillNo=waybillNo FROM dbo.TMS_WayBill WHERE waybillId=@waybillId;
			--查找出最后的送货员
			SELECT TOP 1 @deliveryId=wayUserId
            FROM TMS_WaySite
            WHERE waybillId=@waybillId AND wayState=40
            ORDER BY createTime DESC
			--写入站点状态表
			--wayState:10-揽件;20-发件;30-收件;40-派件;80-留仓;90-妥投;99-回单
			INSERT INTO TMS_WaySite(wayId,waybillId,companyId,siteId,wayState,wayUserId,typeId,reasonId,exField01,
				exField02,nextSite,isLocked,lockerId,lockedTime,createTime,creatorId,editTime,editorId)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@waybillId,@companyId,@siteId,80,@deliveryId,@typeId,@reasonId,@otherReason,
				@personId,'-1',0,'',NULL,GETDATE(),@operatorId,GETDATE(),@operatorId);	
			--更新出库单对应的箱子状态为50-留仓单（未送达）
			UPDATE WMS_Packing SET packState=50 WHERE stockNo=@stockNo AND packState=40;  
			UPDATE WMS_PickingOrder SET shipState=50 WHERE stockNo=@stockNo AND shipState=40;		
			--更新出库单
			IF (@billType<60)	
				UPDATE dbo.SAD_Stock SET taskState=96,undelivered=@undelivered,editTime=@curTime,editorId=@operatorId WHERE stockNo=@stockNo;			
			--对接F10的单据清除装车状态，允许再次装车
			IF (@billType=10)
				UPDATE F10BMS.dbo.SMS_Stock SET CarNumberSts='',CarNumberDate='' WHERE StockNo=@waybillNo;
			ELSE IF (@billType=20)
				UPDATE F10BMS.dbo.IMS_Allot SET CarNumberSts='',CarNumberDate='' WHERE AllotNo=@waybillNo;
			ELSE IF (@billType=40)
				UPDATE F10BMS.dbo.IMS_Present SET CarNumberSts='',CarNumberDate='' WHERE PresentNo=@waybillNo;
			 IF (@billType=60)					--销售退货单
				UPDATE F10BMS.dbo.SMS_Return SET CarNumberSts='',CarNumberDate='' WHERE ReturnNo=@waybillNo;
			ELSE IF (@billType=70)				--销售发票
				UPDATE F10BMS.dbo.SMS_Invoice SET CarNumberSts='',CarNumberDate='' WHERE InvoiceNo=@waybillNo;
			ELSE IF (@billType=80)				--销售收款单
				UPDATE F10BMS.dbo.SMS_Payment SET CarNumberSts='',CarNumberDate='' WHERE PaymentNo=@waybillNo;
			ELSE IF (@billType=90)				--项目单
				UPDATE F10BMS.dbo.PRJ_Order SET CarNumberSts='',CarNumberDate='' WHERE BillNo=@waybillNo;
			
			
			--订单信息
			INSERT INTO @tmpOrder(ownerId,orderNo,orderBillNo,boneOrdNo)
			SELECT ownerId,orderNo,billNo,ordField2
			FROM dbo.SAD_Order
			WHERE orderNo IN(SELECT orderNo FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo);
			WHILE EXISTS(SELECT 1 FROM @tmpOrder)
			BEGIN
				SELECT TOP 1 @ownerId=ownerId,@orderNo=orderNo,@orderBillNo=orderBillNo,@boneOrdNo=boneOrdNo FROM @tmpOrder ORDER BY orderBillNo;
				--如果订单对应的出库单都未送达，则订单未送达
				UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='未送达' WHERE OrderNo=@orderBillNo;				
				--写入订单配送节点表(和Bone平台表对应）
				INSERT INTO dbo.SAD_OrderAction(stepId,orderNo,orderBillNo,stockNo,wmsStockNo,stockBillNo,[action],actionDesc,actionTime,companyId,ownerId,thirdSyncFlag)
				VALUES(LOWER(REPLACE(NEWID(),'-','')),@boneOrdNo,@orderBillNo,@orderNo,@stockNo,@stockBillNo,9,'您的订单派送不成功，将于下一个送货时间再次派送。',GETDATE(),@companyId,@ownerId,0);
				--删除，下一个
				DELETE FROM @tmpOrder WHERE orderNo=@orderNo;
			END
		END
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_TransportUndelivered','YI_TRANSPORT_UNDELIVERED_ERROR',LEFT(@ErrMsg,2000),@waybillNo,@waybillNo);		
		RAISERROR(@ErrMsg, @ErrSeverity, 1);			
	END CATCH
END
go

