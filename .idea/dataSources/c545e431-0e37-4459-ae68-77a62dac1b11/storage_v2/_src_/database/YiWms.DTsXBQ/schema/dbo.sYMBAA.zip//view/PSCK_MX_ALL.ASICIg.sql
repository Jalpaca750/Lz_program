

CREATE view [dbo].[PSCK_MX_ALL] as

/*此视图SAP需要用，请勿改动*/

SELECT a.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,dtl.viewOrder AS linenum,bi.itemNo AS itemcode,
	CASE WHEN ISNULL(pk.actQty,0.0)-ISNULL(dtl.stockQty,0.0)>0 THEN dtl.stockQty ELSE pk.actQty END AS quantity,
	a.mergeNo
FROM dbo.SAD_StockDetail dtl INNER JOIN
      (SELECT m.stockNo,m.billNo,n.ownerNo,m.mergeNo
       FROM dbo.SAD_Stock m LEFT JOIN 
             dbo.BAS_Owner_V n ON m.ownerId=n.ownerId
       WHERE (m.orderType=20) AND (m.taskState>=40) 
       ) a ON dtl.stockNo=a.stockNo INNER JOIN
      dbo.BAS_Item bi ON dtl.itemId=bi.itemId INNER JOIN
      (SELECT stockId,SUM(CASE isPackage WHEN 0 THEN pickQty WHEN 1 THEN pickQty * realQty END) AS actQty
	   FROM WMS_PickingDetail
	   WHERE pickQty>0.0
	   GROUP BY stockId) pk ON dtl.stockId=pk.stockId



go

