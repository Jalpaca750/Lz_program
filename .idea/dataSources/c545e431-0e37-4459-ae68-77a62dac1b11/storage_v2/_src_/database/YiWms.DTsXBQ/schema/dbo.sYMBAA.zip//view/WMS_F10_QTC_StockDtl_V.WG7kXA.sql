/*==============================================================*/
/* View: WMS_F10_QTC_StockDtl_V                                 */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_QTC_StockDtl_V] as
SELECT a.stockId AS wmsStockId,b.stockNo AS wmsStock,b.billNo AS allotNo,a.contractId AS orderId,a.contractNo AS orderNo,
	w.warehouseNo AS warehouse,bi.f10Id AS itemId,a.locationNo AS location,ROUND(t.actQty/bi.pkgRatio,4) AS pkgQty,
	t.actQty AS SQty,a.price,ISNULL(t.actQty,0.0)*ISNULL(a.price,0.0) AS Amt,0.0 AS IQty,a.orderId AS wmsOrderId,
	bi.SPrice,bi.PPrice,bi.itemWeight,a.remarks
FROM dbo.SAD_StockDetail a
	INNER JOIN dbo.SAD_Stock b ON a.stockNo=b.stockNo
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	INNER JOIN F10BMS.dbo.WMS_F10_Item_V bi ON a.itemId=bi.itemId
	LEFT JOIN (SELECT stockId,SUM(CASE isPackage WHEN 0 THEN pickQty WHEN 1 THEN pickQty*pkgRatio END) AS actQty 
				FROM dbo.WMS_PickingDetail
				GROUP BY stockId) t ON a.stockId=t.stockId
WHERE (b.taskState>=60)									                        --复核过后
	AND (b.thirdSyncFlag=0 OR b.thirdSyncFlag=2)		                        --待同步和同步出错的
	AND (b.orderType=20 OR b.orderType=32 OR b.orderType=40 OR b.orderType=50)  --调拨出库，其他出库等
go

