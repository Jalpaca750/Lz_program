
/*==============================================================*/
/* View: TMS_WaySite_V                                          */
/*==============================================================*/
create view TMS_WaySite_V as
SELECT a.wayId,a.waybillId,a.companyId,a.siteId,b.siteName,a.wayState,
    CASE a.wayState WHEN 10 THEN '已揽件'
                    WHEN 20 THEN '运输中'
                    WHEN 30 THEN '派送中'
                    WHEN 40 THEN '已派件'
                    WHEN 80 THEN '未送达'
                    WHEN 90 THEN '已妥投'
                    WHEN 99 THEN '已回单' END AS wayStateDesc,a.wayUserId, 
    a.reasonId,r.reasonDesc,a.nextSite,a.typeId,rt.typeName,a.exField01,a.exField02,
    a.exField03,a.exField04,a.exField05,a.isLocked,a.lockerId,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
    a.creatorId,u1.userNick AS creatorName, a.createTime,a.editTime,a.editorId,
    u2.userNick AS editorName,a.isSelected
FROM TMS_WaySite a
    INNER JOIN TMS_Site b ON a.siteId=b.siteId
    LEFT JOIN dbo.TMS_ReasonType rt ON a.typeId=rt.typeId
    LEFT JOIN dbo.TMS_Reason r ON a.reasonId=r.reasonId
    LEFT JOIN dbo.SAM_User u1 ON a.creatorId =u1.userId
    LEFT JOIN dbo.SAM_User u2 ON a.editorId=u2.userId
go

