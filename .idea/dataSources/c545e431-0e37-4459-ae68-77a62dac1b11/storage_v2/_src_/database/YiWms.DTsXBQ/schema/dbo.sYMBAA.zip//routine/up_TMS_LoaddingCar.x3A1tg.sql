/*----------------------------------------------------------------------------
==-  zdy  创建于 2018-05-23 17:22 装车存储过程
==-  20180608 修改package  pickingorder 表 状态
------------------------------------------------------------------------------*/
CREATE  PROC  [dbo].[up_TMS_LoaddingCar]
(
	@shipNo varchar(32),
	@companyId varchar(32),
	@boxId varchar(32),
	@operatorId varchar(32)
)
AS
DECLARE @shipId varchar(32)='',@stockNo varchar(32)='',@ispackage int
DECLARE @CDATE VARCHAR(20)=CONVERT(varchar(100), GETDATE(), 20),@boxNum varchar(32)
DECLARE @loadCount int=0
BEGIN
 -------------------------------------------------------------------------------------------
  BEGIN TRY
 -------------------------------------------------------------------------------------------
    BEGIN TRANSACTION
 -------------------------------------------------------------------------------------------
    SELECT @shipId=shipId FROM TMS_SubWaybill WHERE boxId=@boxId
    
	UPDATE  TMS_SubWaybill  
	set boxState=20,exShip01=@operatorId,exShip02=@CDATE,@stockNo=stockNo,
	@ispackage=isPackage,@boxNum=boxBillNum    
	WHERE boxId=@boxId and boxState=10;
	
	/*
	  WMS_Packing 表的packState 由20变为30
何小健 2018-06-08 18:23:59
WMS_Picking 表的shipState 由20变为30
	*/
    
    IF @@ROWCOUNT > 0 
    BEGIN
        --==========================修改SHIPDETAIL状态=========================================
         SELECT @loadCount=COUNT(boxId) FROM TMS_SubWaybill WHERE shipId=@shipId and boxState=10
         IF  @loadCount=0  --全部装车
         BEGIN
            UPDATE  WMS_ShipDetail SET shipState=20 WHERE  shipId=@shipId
         END ELSE BEGIN   ---部分装车
            UPDATE  WMS_ShipDetail SET shipState=15 WHERE  shipId=@shipId
         END
        --==========================修改发车单据状态===========================================
		IF (SELECT COUNT(boxId) FROM TMS_SubWaybill WHERE shipNo=@shipNo AND boxState=10)=0
		BEGIN
			UPDATE WMS_Ship SET shipstate=20,auditTime=GETDATE(),
			auditorId=@operatorId,editTime=GETDATE(),
			editorId=@operatorId WHERE shipNo=@shipNo and shipstate=10;
		END
		---===================修改箱子只身的状态==============================================================
		IF @ispackage=1  --如果是整件
		BEGIN
		    UPDATE WMS_PickingOrder SET shipState=30 
		    WHERE companyId=@companyId and  stockNo=@stockNo and isPackage=1 
		          and shipState=20 and boxBillNum=cast(@boxNum as numeric(10,0))
		END ELSE BEGIN  --散件
		    UPDATE WMS_Packing SET packState=30  
		    WHERE companyId=@companyId AND  stockNo=@stockNo AND boxBillNum=@boxNum AND packState=20
		END
    END
---提交事务
COMMIT;
END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
	END CATCH
END


go

