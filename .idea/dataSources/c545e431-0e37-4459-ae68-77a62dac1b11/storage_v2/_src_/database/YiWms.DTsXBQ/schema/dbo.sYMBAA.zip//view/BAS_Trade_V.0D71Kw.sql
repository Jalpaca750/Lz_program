
/*==============================================================*/
/* View: BAS_Trade_V                                            */
/*==============================================================*/
create view BAS_Trade_V as
--2016-09-19 企业行业视图统一修正
SELECT a.tradeId,a.tradeNo,a.tradeCName,a.tradeEName,a.companyId,u1.userNick AS lockerName,
      a.lockerId,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,u2.userNick AS creatorName,
      a.creatorId,a.createTime,u3.userNick AS editorName,a.editorId,a.editTime,a.isSelected
FROM dbo.BAS_Trade a LEFT JOIN
      dbo.SAM_User u1 ON a.lockerId=u1.userId LEFT JOIN
      dbo.SAM_User u2 ON a.creatorId=u2.userId LEFT JOIN
      dbo.SAM_User u3 ON a.editorId=u3.userId
go

