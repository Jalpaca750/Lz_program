
-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-08-22>
-- Description:	<Description:同步F10员工资料到WMS>
--      @companyId：公司Id
--      @ownerId：业主Id
--      @creatorId：操作员Id
--      @encrypt：敏感资料是否加密（1-是；0-否）
--      @startTime：同步开始时间 yyyy-MM-dd HH:mm:ss格式
--      @endTime：同步截至时间 yyyy-MM-dd HH:mm:ss格式
-- =============================================

CREATE Proc  [dbo].[up_SyncF10Employee]
(
	@companyId VARCHAR(32),		--公司Id,如果前台调用，需传值，为空时，手动修改这个值
	@ownerId VARCHAR(32),		--业主Id
	@creatorId VARCHAR(32),		--操作员，前天调用的当前用户，后台执行时，可赋值
    @encrypt INT,				--是否对重要数据进行加密1-是;0-否
	@startTime DATETIME,		--同步员工的开始时间（修改时间）
	@endTime DATETIME			--同步员工的截至时间（修改时间）
)
AS
BEGIN
	DECLARE @employeeNo VARCHAR(32)
	DECLARE @employee TABLE(employeeId BIGINT,employeeNo VARCHAR(32));
	--如果接口正在同步中，则直接退出
	IF EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Employee' AND isLocked=1)
		RETURN;
	--获取需要同步的数据
	INSERT INTO @employee(employeeId,employeeNo)
	SELECT EmployeeID,EmployeeNo 
	FROM F10BMS.dbo.BDM_Employee 
	WHERE syncFlag=0;
	IF NOT EXISTS(SELECT 1 FROM @employee)
		RETURN;	
	--1.锁定同步接口
	UPDATE dbo.SAM_Store SET isLocked=1,lockerId=@creatorId,lockedTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Employee';
	--开始同步
	BEGIN TRY 	
		BEGIN TRANSACTION
		--2.同步员工资料
		WHILE EXISTS(SELECT 1 FROM @employee)
		BEGIN
			--取第一个员工
			SELECT TOP 1 @employeeNo=employeeNo FROM @employee ORDER BY employeeId; 
			--同步
			EXEC F10BMS.dbo.sp_AfterEmployeeSaved @employeeNo;
			--同步成功后更新同步状态
			UPDATE F10BMS.dbo.BDM_Employee SET syncFlag=1 WHERE employeeNo=@employeeNo;
			--删除同步成功的临时员工
			DELETE FROM @employee WHERE employeeNo=@employeeNo;
		END
		--3.释放同步接口
		UPDATE dbo.SAM_Store SET isLocked=0,lockerId='',syncTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Employee';
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		--释放同步接口
		UPDATE dbo.SAM_Store SET isLocked=0,lockerId='' WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Employee';
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int;
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END CATCH
END 

go

