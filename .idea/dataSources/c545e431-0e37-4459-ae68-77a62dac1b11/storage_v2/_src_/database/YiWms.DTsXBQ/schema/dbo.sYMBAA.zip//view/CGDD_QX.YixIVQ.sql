/*==============================================================*/
-- View: CGDD_QX        
--   @edit:  张东彦  @at:2017-07-07 11:01
--   @edit:  WJ  @at:2017-07-19 11:01 添加中止状态
--   @content: 添加仓库代码返回                                
/*==============================================================*/
create view [dbo].[CGDD_QX] as
SELECT a.billNo,a.thirdSyncFlag,w.warehouseNo  WHNO
FROM PMS_Order a inner join BAS_Warehouse w on a.warehouseId=w.warehouseId
WHERE (poState=0 OR poState=-3) AND (thirdSyncFlag=0 OR thirdSyncFlag=2)
go

