-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2016-30-10>
-- Description:	<Description:确认发货存储过程  V1.2>
-- 影响：
--      装车单状态-已发货
--      分拣订单任务状态-已发货
--      出库单状态-已发货
--		F10订单已发货
--		WMS订单节点记录
--  可扩展：
--      写入物流路径表
-- =============================================
CREATE PROCEDURE [dbo].[up_Audit_OrderShip]
(
	@companyId VARCHAR(32),			--公司Id
	@shipNo VARCHAR(32),			--装车单No
	@operatorId VARCHAR(32)			--操作员Id
)
AS
BEGIN
	DECLARE @ownerId VARCHAR(32),@deliveryId VARCHAR(32),@billNo VARCHAR(32),@hasTms INT,@thirdFlag INT,@deliveryInfo VARCHAR(200),@tmpInfo VARCHAR(200);	
	DECLARE @shipId VARCHAR(32),@billType INT,@stockNo VARCHAR(32),@stockBillNo VARCHAR(32),@orderNo VARCHAR(32),@orderBillNo VARCHAR(32),@boneOrdNo VARCHAR(32),@expressNo VARCHAR(40);
	DECLARE @tmpTable TABLE(shipId VARCHAR(32),billType INT,stockNo VARCHAR(32),stockBillNo VARCHAR(32),expressNo VARCHAR(40),viewOrder INT);
	DECLARE @tmpOrder TABLE(ownerId VARCHAR(32),orderNo VARCHAR(32),orderBillNo VARCHAR(32),boneOrdNo VARCHAR(32),iCount INT);
	DECLARE @DelDetail INT;
	SET @DelDetail=0
	--是否有获得Tms产品授权
	IF EXISTS(SELECT 1 FROM SAM_CompanyProduct WHERE companyId=@companyId AND productCode='YFP0006') 
		SET @hasTms=1;
	ELSE
		SET @hasTms=0;
	--清除错误日志
	DELETE FROM SAM_Error WHERE companyId=@companyId AND funCode='up_Audit_OrderShip';
	--获取送货员Id,单据编号
	SELECT @deliveryId=a.deliveryId,@billNo=a.billNo,@thirdFlag=ISNULL(c.thirdFlag,0),
		   @tmpInfo=CASE ISNULL(c.thirdFlag,0) 
						      WHEN 1 THEN '您的订单已通过' + ISNULL(c.carNumber,'') + '发出,快递单号:'  
						      ELSE '您的订单已经发出，送货员:' + ISNULL(u1.userNick,'') + ' ' + ISNULL(u1.userMobile,'') END
	FROM dbo.WMS_Ship a 
		INNER JOIN dbo.SAM_User u1 ON a.deliveryId=u1.userId 
		INNER JOIN dbo.BAS_Car c ON a.carId=c.carId 
	WHERE a.shipNo=@shipNo;	
	BEGIN TRY
		BEGIN TRANSACTION
		--如果装车单处于装车状态（装车环节锁定）
		IF EXISTS(SELECT * FROM dbo.WMS_Ship WHERE shipNo=@shipNo AND isLocked=1)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_Audit_OrderShip','YI_CONFIRM_SHIP_ERROR','装车单尚未完成装车，操作无效！',@shipNo,@billNo);
			COMMIT;
			RETURN;
		END	
		--如果没有装车，则提示退出，带TMS外用PDA解除注释
		/*
		IF NOT EXISTS(SELECT * FROM dbo.WMS_ShipDetail WHERE shipNo=@shipNo AND shipState=20)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_Audit_OrderShip','YI_CONFIRM_SHIP_ERROR','装车单尚未完成装车，操作无效！',@shipNo,@billNo);
			COMMIT;
			RETURN;
		END		
		*/
		--如果装车单单据没有分拣完成，则不允许发车
		IF EXISTS(SELECT * FROM dbo.SAD_Stock WHERE stockNo IN(SELECT billNo FROM dbo.WMS_ShipDetail WHERE shipNo=@shipNo) AND taskState<70)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_Audit_OrderShip','YI_CONFIRM_SHIP_ERROR','出库单尚未完成配货，操作无效！',@shipNo,@billNo);
			COMMIT;
			RETURN;
		END
		--更新发车单主表状态为已发货
		UPDATE dbo.WMS_Ship SET shipState=30,auditTime=GETDATE(),auditorId=@operatorId,editTime=GETDATE(),editorId=@operatorId 
		WHERE shipNo=@shipNo AND shipState<30;
		IF (@@ROWCOUNT>0)
		BEGIN
		    /*
		    --未装车单明细
			INSERT INTO @tmpTable(shipId,billType,stockNo,stockBillNo,expressNo,viewOrder)
			SELECT shipId,billType,billNo,stockBillNo,boxBillNums,viewOrder
			FROM dbo.WMS_ShipDetail 
			WHERE shipNo=@shipNo AND shipState=10;
			IF EXISTS(SELECT 1 FROM @tmpTable)
			    SET @DelDetail=1;
			ELSE
			    SET @DelDetail=0;
			--循环装车明细
			WHILE EXISTS(SELECT 1 FROM @tmpTable)
			BEGIN
				SELECT TOP 1 @shipId=shipId,@billType=billType,@stockNo=stockNo,@stockBillNo=stockBillNo,@expressNo=expressNo 
				FROM @tmpTable 
				ORDER BY viewOrder;
				--删除对应明细
				DELETE FROM WMS_ShipDetail WHERE shipId=@shipId;				
		        --取消对应单据状态
		        IF (@hasTms=1)
		        BEGIN
			        DECLARE @waybillId VARCHAR(32);
			        SELECT @waybillId=waybillId FROM dbo.TMS_WayBill WHERE companyId=@companyId AND wmsStockNo=@stockNo AND billType=@billType;
			        --箱子状态更改为待排车状态(散件批量)
			        UPDATE a SET a.packState=10
			        FROM dbo.WMS_Packing a
			        WHERE EXISTS(SELECT * FROM dbo.TMS_SubWaybill b WHERE a.companyId=b.companyId AND a.boxBillNum=b.boxBillNum AND shipId=@shipId AND isPackage=0);
			        --箱子状态更改为待排车状态(整件批量)
			        UPDATE a SET a.shipState=10
			        FROM dbo.WMS_PickingOrder a
			        WHERE EXISTS(SELECT * FROM dbo.TMS_SubWaybill b WHERE a.companyId=b.companyId AND a.boxBillNum=b.boxBillNum AND shipId=@shipId AND isPackage=1);
			        --删除运单子表
			        DELETE FROM dbo.TMS_SubWaybill WHERE waybillId=@waybillId AND shipId=@shipId;
			        --如果子运单全部删除，则删除运单
			        IF NOT EXISTS(SELECT 1 FROM dbo.TMS_SubWaybill WHERE stockNo=@stockNo AND billType=@billType)
			        BEGIN
			            DELETE FROM dbo.TMS_WayBill WHERE waybillId=@waybillId;
			            DELETE FROM dbo.TMS_WaySite WHERE waybillId=@waybillId;
			        END
		        END
		        --更新
		        UPDATE SAD_Stock SET shipState=0,taskState=70,shipTime=NULL WHERE stockNo=@stockNo;
		        --更新出库单状态为已装车（排计划）
		        IF (@billType=10)
			        UPDATE F10BMS.dbo.SMS_Stock SET CarNumberSts='',CarNumberDate='' WHERE StockNo=@stockBillNo;
		        ELSE IF (@billType=20)
			        UPDATE F10BMS.dbo.IMS_Allot SET CarNumberSts='',CarNumberDate='' WHERE AllotNo=@stockBillNo;
		        ELSE IF (@billType=40)
			        UPDATE F10BMS.dbo.IMS_Present SET CarNumberSts='',CarNumberDate='' WHERE PresentNo=@stockBillNo;
		        ELSE IF (@billType=60)				--销售退货单
			        UPDATE F10BMS.dbo.SMS_Return SET CarNumberSts='',CarNumberDate='' WHERE ReturnNo=@stockBillNo;
		        ELSE IF (@billType=70)				--销售发票
			        UPDATE F10BMS.dbo.SMS_Invoice SET CarNumberSts='',CarNumberDate='' WHERE InvoiceNo=@stockBillNo;
		        ELSE IF (@billType=80)				--销售收款单
			        UPDATE F10BMS.dbo.SMS_Payment SET CarNumberSts='',CarNumberDate='' WHERE PaymentNo=@stockBillNo;
		        ELSE IF (@billType=90)				--项目单
			        UPDATE F10BMS.dbo.PRJ_Order SET CarNumberSts='',CarNumberDate='' WHERE BillNo=@stockBillNo;
				--删除临时表数据				
				DELETE FROM @tmpTable WHERE shipId=@shipId;
			END
			IF (@DelDetail=1)
			BEGIN
			    --重新排序
	            UPDATE a SET a.viewOrder=b.viewOrder
	            FROM dbo.WMS_ShipDetail a
		            INNER JOIN (SELECT shipId,ROW_NUMBER() OVER (ORDER BY viewOrder) AS viewOrder
					            FROM dbo.WMS_ShipDetail
					            WHERE shipNo=@shipNo) b ON a.shipId=b.shipId;
	            --如果明细全部删除，则连带主表一起删除
	            DELETE FROM dbo.WMS_Ship WHERE shipNo=@shipNo AND NOT EXISTS(SELECT 1 FROM dbo.WMS_ShipDetail WHERE shipNo=@shipNo);
		    END
		    */
		    IF (@hasTms=1)
			BEGIN
		        --已装车的箱子状态更新40-已发货
		        UPDATE p SET p.packState=40
		        FROM dbo.WMS_Packing p
		            INNER JOIN (SELECT companyId,boxBillNum
		                        FROM dbo.TMS_SubWaybill
			                    WHERE shipNo=@shipNo AND isPackage=0 AND boxState=20
			                    ) t ON p.companyId=t.companyId AND p.boxBillNum=t.boxBillNum
			    UPDATE p SET p.shipState=40
		        FROM dbo.WMS_PickingOrder p
		            INNER JOIN (SELECT companyId,CAST(boxBillNum AS BIGINT) boxBillNum
		                        FROM dbo.TMS_SubWaybill
			                    WHERE shipNo=@shipNo AND isPackage=1 AND boxState=20
			                    ) t ON p.companyId=t.companyId AND p.boxBillNum=t.boxBillNum
                --未装车的箱子状态更新为45-未发货
                UPDATE p SET p.packState=45
		        FROM dbo.WMS_Packing p
		            INNER JOIN (SELECT companyId,boxBillNum
		                        FROM dbo.TMS_SubWaybill 
			                    WHERE shipNo=@shipNo AND isPackage=0 AND boxState=10
			                    ) t ON p.companyId=t.companyId AND p.boxBillNum=t.boxBillNum
			    UPDATE p SET p.shipState=45
		        FROM dbo.WMS_PickingOrder p
		            INNER JOIN (SELECT companyId,CAST(boxBillNum AS BIGINT) boxBillNum
		                        FROM dbo.TMS_SubWaybill
			                    WHERE shipNo=@shipNo AND isPackage=1 AND boxState=20
			                    ) t ON p.companyId=t.companyId AND p.boxBillNum=t.boxBillNum
            END
			--更新发车单明细状态为已发货
			--UPDATE dbo.WMS_ShipDetail SET shipState=30 WHERE shipNo=@shipNo;			
			UPDATE dbo.WMS_ShipDetail SET shipState=30 WHERE shipNo=@shipNo AND shipState=20;
			UPDATE dbo.WMS_ShipDetail SET shipState=25 WHERE shipNo=@shipNo AND shipState=15;
			--装车单明细
			INSERT INTO @tmpTable(shipId,billType,stockNo,stockBillNo,expressNo,viewOrder)
			SELECT shipId,billType,billNo,stockBillNo,boxBillNums,viewOrder
			FROM dbo.WMS_ShipDetail 
			WHERE shipNo=@shipNo AND shipState=30;
			--循环装车明细
			WHILE EXISTS(SELECT 1 FROM @tmpTable)
			BEGIN
				SELECT TOP 1 @shipId=shipId,@billType=billType,@stockNo=stockNo,@stockBillNo=stockBillNo,@expressNo=expressNo 
				FROM @tmpTable 
				ORDER BY viewOrder;
				--第三方快递单号
				IF (ISNULL(@thirdFlag,0)=1)
					SET @deliveryInfo=@tmpInfo+ISNULL(@expressNo,''); 
				ELSE
				    SET @deliveryInfo=@tmpInfo;
				IF (@billType<60)
				BEGIN
					--更新发车单中对应分拣任务的状态
					UPDATE dbo.WMS_PickingOrder SET taskState=6 WHERE stockNo=@stockNo AND taskState<6;
					--更新销售出库单状态		
					UPDATE dbo.SAD_Stock SET taskState=90,ioState=20,editorId=@operatorId,editTime=GETDATE(),
					    deliveryId=@deliveryId,deliveryTime=GETDATE()
					WHERE stockNo=@stockNo;					
					--获取出库单对应订单
					INSERT INTO @tmpOrder(ownerId,orderNo,orderBillNo,boneOrdNo)
					SELECT ownerId,orderNo,billNo,ISNULL(ordField2,'')
					FROM dbo.SAD_Order a
					WHERE a.orderNo IN(SELECT orderNo FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo);										
					--接口部分(F10和Bone平台)
					WHILE EXISTS(SELECT 1 FROM @tmpOrder)
					BEGIN
						SELECT TOP 1 @ownerId=ownerId,@orderNo=orderNo,@orderBillNo=orderBillNo,@boneOrdNo=boneOrdNo 
						FROM @tmpOrder 
						ORDER BY orderBillNo;	
						--如果订单对应的出库单全部发货，则订单已发货
						IF NOT EXISTS(SELECT 1 FROM dbo.SAD_Order WHERE orderNo=@orderNo AND sdState<30)
							UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='已发货' WHERe orderNo=@orderBillNo;
						ELSE
							UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='部分发货' WHERe orderNo=@orderBillNo;						
						--写入订单配送节点表(和Bone平台表对应,可多次派件）
						INSERT INTO dbo.SAD_OrderAction(stepId,orderNo,orderBillNo,stockNo,wmsStockNo,stockBillNo,[action],actionDesc,actionTime,companyId,ownerId,thirdSyncFlag)
						VALUES(LOWER(REPLACE(NEWID(),'-','')),@boneOrdNo,@orderBillNo,@orderNo,@stockNo,@stockBillNo,8,@deliveryInfo,GETDATE(),@companyId,@ownerId,0);
						--删除订单，继续下一个
						DELETE FROM @tmpOrder WHERE orderNo=@orderNo;
					END					
				END
				--如果TMS授权，则自动生成派件记录
				IF (@hasTms=1)
				BEGIN
					--运单状态：10-已揽件;20-运输中;30-派送中;
					UPDATE dbo.TMS_WayBill SET billState=30,editTime=GETDATE(),editorId=@operatorId WHERE companyId=@companyId AND wmsStockNo=@stockNo AND billType=@billType AND (billState IN(10,20,80));
					IF (@@ROWCOUNT>0)
					BEGIN
						--wayState:10-揽件;20-发件;30-收件;40-派件;80-留仓;90-妥投;99-回单
						INSERT INTO TMS_WaySite(wayId,waybillId,companyId,siteId,wayState,wayUserId,nextSite,isLocked,lockerId,
							lockedTime,createTime,creatorId,editTime,editorId)
						SELECT LOWER(REPLACE(NEWID(),'-','')),waybillId,companyId,siteId,40,@deliveryId,'-1',0,'',NULL,
							GETDATE(),@operatorId,GETDATE(),@operatorId
						FROM dbo.TMS_WayBill
						WHERE companyId=@companyId AND wmsStockNo=@stockNo AND billType=@billType; 
					END
				END
				--删除临时表数据				
				DELETE FROM @tmpTable WHERE shipId=@shipId;
			END
		END
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_Audit_OrderShip','YI_CONFIRM_SHIP_ERROR',LEFT(@ErrMsg,2000),@shipNo,@billNo);
		RAISERROR(@ErrMsg, @ErrSeverity, 1)					
	END CATCH
END
go

