CREATE Proc [dbo].[proc_TMS_Sign]
(
    @signName varchar(32),
    @companyId varchar(32),
    @waybillId varchar(32),
    @operatorId varchar(32),
    @fileimg image
)
AS
BEGIN
    declare @siteId varchar(32)=''                          --网点ID
    declare @wayState int=90                                --已妥投
    declare @stockNo  varchar(32)=''                        --出库单
    declare @stockBillNo varchar(32)=''                     --出库单编号
    declare @billType int                                   --单据类型
    declare @fileid varchar(32)=REPLACE(NEWID(),'-','')
    declare @signTime  datetime=GETDATE()
    declare @wayId   varchar(32)=REPLACE(NEWID(),'-','')
    declare  @errorCount int=0
    --处理订单节点资料
    DECLARE @tmpOrder TABLE(ownerId VARCHAR(32),orderNo VARCHAR(32),orderBillNo VARCHAR(32),boneOrdNo VARCHAR(32));
    DECLARE @ownerId VARCHAR(32),@orderNo VARCHAR(32),@orderBillNo VARCHAR(32),@boneOrdNo VARCHAR(32)
    BEGIN TRAN
    /*-------------------------------------第一步赋值--------------------------------------------------------*/
    SELECT @siteId=siteId,@stockNo=wmsStockNo,@billType=billType,@stockBillNo=waybillNo  
    FROM dbo.TMS_WayBill 
    WHERE waybillId=@waybillId;
    ---更新装运单的状态(90-已妥投)
    UPDATE dbo.TMS_WayBill SET billState=90 WHERE waybillId=@waybillId and billState=30;
    set @errorCount+=@@ERROR;
    IF (@@ROWCOUNT>0) 
    BEGIN
        ---更新出库单状态(95-已妥投)  如果是其他装运项目的话（全部收到签收）
        UPDATE dbo.SAD_Stock SET signName=@signName,signTime=@signTime,taskState=95 WHERE stockNo=@stockNo AND taskState=90;
        set @errorCount+=@@ERROR;
        ----签收的文件存储
        INSERT INTO dbo.TMS_Sign(fileid,companyId,siteId,wayBillId,billType,stockNo,signName,signTime,signImage,billImage,createtime,creatorId,editTime,editorid,isselected)
        VALUES(@fileid,@companyId,@siteId,@waybillId,@billType,@stockNo,@signName,@signTime,@fileimg,null,@signTime,@operatorId,@signTime,@operatorId,0);
        set @errorCount+=@@ERROR;
        ----装运项目操作
        INSERT INTO dbo.TMS_WaySite(wayId,waybillId,companyId,siteId,wayState,wayUserId,nextSite,typeId,reasonId,
            isLocked,createTime ,creatorId,editTime,editorId,isSelected)
        VALUES(@wayId,@waybillId,@companyId,@siteId,@wayState,@operatorId,-1,null,null,0,
            @signTime,@operatorId,@signTime,@operatorId,0);
        set @errorCount+=@@ERROR;
        
        
        --处理箱子状态(90-已妥投)
        UPDATE dbo.WMS_Packing SET packState=90 WHERE stockNo=@stockNo AND packState=40;
        set @errorCount+=@@ERROR;
        UPDATE dbo.WMS_PickingOrder SET shipState=90 WHERE stockNo=@stockNo AND shipState=40;
        set @errorCount+=@@ERROR;
        --同步F10出库单状态处理
        IF (@billType=10)
        BEGIN
            UPDATE F10BMS.dbo.SMS_Stock SET SignName=@signName,signDate=@signTime WHERE StockNo=@stockBillNo; 
            set @errorCount+=@@ERROR;
        END
        --写入订单节点(已妥投的)
		INSERT INTO @tmpOrder(ownerId,orderNo,orderBillNo,boneOrdNo)
		SELECT ownerId,orderNo,billNo,ordField2
		FROM dbo.SAD_Order
		WHERE orderNo IN(SELECT orderNo FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo AND EXISTS(SELECT * FROM dbo.SAD_Stock WHERE stockNo=@stockNo AND taskState=95));
		set @errorCount+=@@ERROR;
		WHILE EXISTS(SELECT 1 FROM @tmpOrder)
		BEGIN
			SELECT TOP 1 @ownerId=ownerId,@orderNo=orderNo,@orderBillNo=orderBillNo,@boneOrdNo=boneOrdNo FROM @tmpOrder ORDER BY orderBillNo;
			--如果订单对应的出库单都未送达，则订单未送达
			UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='已妥投' WHERE OrderNo=@orderBillNo;
			set @errorCount+=@@ERROR;				
			--写入订单配送节点表(和Bone平台表对应）
			INSERT INTO dbo.SAD_OrderAction(stepId,orderNo,orderBillNo,stockNo,wmsStockNo,stockBillNo,[action],actionDesc,actionTime,companyId,ownerId,thirdSyncFlag)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@boneOrdNo,@orderBillNo,@orderNo,@stockNo,@stockBillNo,10,'您的订单已签收。欢迎再次光临，祝您购物愉快。',GETDATE(),@companyId,@ownerId,0);
			set @errorCount+=@@ERROR;
			--可添加对平台订单状态的处理
			
			--删除，下一个
			DELETE FROM @tmpOrder WHERE orderNo=@orderNo;
			set @errorCount+=@@ERROR;
		END
        
    END
    --------------------------------------错误处理-----------------------------------------------------
	IF @errorCount<>0
	BEGIN
        rollback;
	END
	ELSE  
	BEGIN
	    commit;
	END 
END
go

