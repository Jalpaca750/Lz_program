
/*==============================================================*/
/* View: IMS_Replenish_V                                        */
/*==============================================================*/
--creator：        Frank
--create time：  2016-12-16日整理 
--补货
create view IMS_Replenish_V as
SELECT a.replenishId,a.companyId,a.replenishDate,a.billNo,a.replenishType,
      CASE a.replenishType WHEN 1 THEN '主动补货' WHEN 2 THEN '被动补货' END AS replenishDesc,
      a.waveNo,a.waveBillNo,a.sourceWhId,w1.warehouseNo AS sourceWhNo,w1.warehouseName AS sourceWhName,
      a.sourceRegId,r1.regionNo AS sourceRegNo,r1.regionDesc AS sourceRegDesc,a.sourceLocNo,a.targetWhId,
      w2.warehouseNo AS targetWhNo,w2.warehouseName AS targetWhName,a.targetRegId,r2.regionNo AS targetRegNo,
      r2.regionDesc AS targetRegDesc,a.targetLocNo,a.eId,a.itemId,b.itemNo,b.itemName,b.itemCTitle,b.itemETitle,
      b.sellingPoint,b.itemSpec,b.itemSpell,b.barcode,b.brandId,b.brandNo,b.brandCName,b.categoryId,b.categoryNo,
      b.categoryCName,b.colorName,b.sizeName,b.unitName,b.pkgUnit,b.packageId,b.pkgRatio,b.pkgBarcode,b.inventoryMode,
      b.pickingMode,a.replenishQty,a.pkgQty,a.ioState,
      CASE a.ioState WHEN 0 THEN '已关闭' WHEN 10 THEN '待下架' WHEN 20 THEN '待上架' WHEN 30 THEN '已完成' END AS ioStateDesc,
      a.pickerId,u1.userNick AS pickerName,CONVERT(VARCHAR(20),a.pickingTime,120) AS pickingTime,
      a.putawayId,u2.userNick AS putawayName,CONVERT(VARCHAR(20),a.putawayTime,120) AS putawayTime,
      a.printNum,a.printId,u3.userNick AS printMan,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,
      a.isLocked,a.lockerId,u4.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
      a.createTime,a.creatorId,u5.userNick AS creatorName
FROM dbo.IMS_Replenish a INNER JOIN
      dbo.BAS_Item_V b ON a.itemId=b.itemId INNER JOIN
      dbo.BAS_Warehouse w1 ON a.sourceWhId=w1.warehouseId INNER JOIN
      dbo.BAS_Warehouse w2 ON a.targetWhId=w2.warehouseId LEFT JOIN
      dbo.BAS_Region r1 ON a.sourceRegId=r1.regionId LEFT JOIN
      dbo.BAS_Region r2 ON a.targetRegId=r2.regionId LEFT JOIN
      dbo.SAM_User u1 ON a.pickerId=u1.userId LEFT JOIN
      dbo.SAM_User u2 ON a.putawayId=u2.userId LEFT JOIN
      dbo.SAM_User u3 ON a.printId=u3.userId LEFT JOIN
	  dbo.SAM_User u4 ON a.lockerId=u4.userId LEFT JOIN
	  dbo.SAM_User u5 ON a.creatorId=u5.userId
go

