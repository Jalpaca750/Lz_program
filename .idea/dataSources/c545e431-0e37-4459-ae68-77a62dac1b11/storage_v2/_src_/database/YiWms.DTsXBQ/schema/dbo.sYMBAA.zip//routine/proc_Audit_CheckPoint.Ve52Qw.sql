CREATE PROC  [dbo].[proc_Audit_CheckPoint]
(
   @pointId  VARCHAR(32),
   @operatorId VARCHAR(32)
)
AS 
BEGIN TRAN
-------------定义变量--------
DECLARE @Stock TABLE(eId VARCHAR(32),itemId VARCHAR(32),pkgRatio DECIMAL(20,6),lotNo VARCHAR(50),locationNo VARCHAR(50),inventory INT,IsChecked INT,onhandQty DECIMAL(20,6),actQty DECIMAL(20,6),difQty DECIMAL(20,6),pkgQty DECIMAL(20,6),bulkQty DECIMAL(20,6),ownerId  VARCHAR(32))
DECLARE @companyId VARCHAR(32),@warehouseId VARCHAR(32)
DECLARE @adjustNo VARCHAR(32),@billNo VARCHAR(32)
DECLARE @errorSun int =0

SELECT TOP 1 @adjustNo=LOWER(REPLACE(NEWID(),'-','')), @companyId=companyId,@warehouseId=warehouseId  FROM IMS_CheckPoint WHERE pointId=@pointId
EXEC up_CreateCode @companyId,'IMS_AdJUST',@operatorId,@billNo OUTPUT
---------插入临时表---------------				
INSERT INTO @Stock(itemId,eId,pkgRatio,lotNo,locationNo,inventory,IsChecked,onhandQty,actQty,difQty,pkgQty,bulkQty,ownerId)
			SELECT temp.itemId,temp.eId,temp.pkgRatio,temp.lotNo,temp.locationNo,temp.inventory,temp.IsChecked,temp.onhandQty,temp.actQty,temp.actQty-isnull(temp.onhandQty,0) AS difQty,temp.pkgQty,temp.bulkQty,temp.ownerId
			  FROM(
			SELECT b.lotNo,b.locationNo,b.itemId,sk.eId,sk.pkgRatio,c.inventory, CASE WHEN a.itemId IS NULL THEN 0 ELSE 1 END AS IsChecked,b.onhandQty,CASE WHEN a.itemId IS NULL THEN CASE WHEN c.inventory=1 THEN 0 ELSE b.onhandQty END ELSE a.actQty END AS actQty,a.pkgQty,a.bulkQty,sk.ownerId
			FROM IMS_CheckStock b
			LEFT JOIN (SELECT itemId,eId,warehouseId,isnull(lotNo,'') lotNo,isnull(locationNo,'')AS locationNo,SUM(actQty) AS actQty,Sum(pkgQty) AS pkgQty,Sum(bulkQty) AS bulkQty FROM IMS_CheckDetail WHERE pointId=@pointId GROUP BY itemId,eId,warehouseId,lotNo,locationNo)a ON b.pointId=@pointId AND b.itemId=a.itemId AND b.lotNo=ISNULL(a.lotNo,'') AND b.locationNo=ISNULL(a.locationNo,'') AND b.warehouseId=a.warehouseId
			LEFT JOIN IMS_CheckPoint c ON c.pointId=@pointId
			LEFT JOIN IMS_Stock AS isk ON b.companyId=isk.companyId AND b.itemId=isk.itemId AND isnull(b.locationNo,'')=isnull(isk.locationNo,'') AND isnull(b.lotNo,'')=isnull(isk.lotNo,'')
			LEFT JOIN BAS_ItemSku_V AS sk ON sk.companyId=b.companyId AND sk.itemId=b.itemId
			WHERE b.pointId=@pointId)temp
---------------插入调整表-------------
IF EXISTS(SELECT 1 FROM @Stock WHERE difQty!=0)
BEGIN
	------插入调整表主表--------
	INSERT INTO IMS_Adjust(adjustNo,billNo,companyId,adjustDate,warehouseId,pointId,adjustReason,ioState,deptId,handlerId,memo,auditorId,auditTime,creatorId,editTime)
					VALUES(@adjustNo,@billNo,@companyId,GETDATE(),@warehouseId,@pointId,'盘点完成',20,'','','盘点完成',@operatorId,getdate(),@operatorId,GetDate());
	SET @errorSun=@errorSun+@@ERROR
	------插入明细---------
	INSERT INTO IMS_AdjustDetail(ownerId,adjustId,companyId,adjustNo,viewOrder,
							     warehouseId,lotNo,locationNo,eId,itemId,unitId,ioQty,pkgQty,bulkQty,fee,totalFee)
	SELECT ownerId,LOWER(REPLACE(NEWID(),'-','')),@companyId,@adjustNo,ROW_NUMBER() OVER (ORDER BY locationNo desc) AS RowNumber,
								@warehouseId,lotNo,locationNo,'',itemId ,    '',difQty,pkgQty,bulkQty,0,0 FROM @Stock WHERE difQty!=0
	------调整表结束-------
	SET @errorSun=@errorSun+@@ERROR
END
---------流水帐开始-----------------------------------------
INSERT INTO IMS_Book(
[bookId],[ioType],[companyId],[billId],[billNo],[billCode],[objectId],[warehouseId],
[lotNo],[locationNo],[eId],[itemId],[befQty],[ioQty],[afterQty],[handlerId],[deptId],[createTime],
[creatorId],[auditorId],[auditTime])
SELECT LOWER(REPLACE(NEWID(),'-','')),'I200',@warehouseId,b.pointId,b.pointNo,b.pointNo,b.pointId,b.warehouseId,
a.lotNo,a.locationNo,'',a.itemId,a.onhandQty,a.difQty,a.actQty,'','',GETDATE(),
@operatorId,@operatorId,GETDATE()
FROM @Stock a 
LEFT JOIN IMS_CheckPoint b ON b.pointId=@pointId
SET @errorSun=@errorSun+@@ERROR
---------流水帐结束----------------------------------------

---------更新库存开始----------------------------------------
UPDATE a SET a.onhandQty=b.actQty FROM IMS_Stock a
INNER JOIN @Stock b 
ON a.companyId=@companyId AND a.warehouseId=@warehouseId
   AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.locationNo,'') AND a.itemId=b.itemId
WHERE a.companyId=@companyId AND a.warehouseId=@warehouseId  AND b.difQty!=0
SET @errorSun=@errorSun+@@ERROR
---------更新库存结束--------------------------------------

---------更新商品库存开始----------------------------------
UPDATE a SET a.onhandQty=ISNULL(b.onhandQty,0.0)
		 FROM BAS_Item AS a 
		 LEFT JOIN(SELECT SUM(onhandQty) AS onhandQty,itemId FROM IMS_Stock WHERE companyId=@companyId AND itemId IN(SELECT itemId FROM @Stock WHERE difQty!=0) GROUP BY itemId)b ON a.itemId=b.itemId
		 WHERE companyId=@companyId AND a.itemId IN(SELECT itemId FROM @Stock WHERE difQty!=0)
SET @errorSun=@errorSun+@@ERROR
---------更新商品库存结束---------------------------------

---------更新盘点批次已盘点-----------------------
UPDATE IMS_CheckPoint SET checkState = 30 WHERE pointId=@pointId AND checkState=20
SET @errorSun=@errorSun+@@ERROR
UPDATE IMS_Check SET billState = 30 WHERE pointId=@pointId AND billState=20
SET @errorSun=@errorSun+@@ERROR

UPDATE a SET a.realQty=b.actQty FROM 
IMS_CheckStock a
INNER JOIN @Stock b ON a.itemId=b.itemId AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.locationNo,'')
WHERE a.pointId=@pointId 
SET @errorSun=@errorSun+@@ERROR

------更新库房总帐-----
UPDATE a SET a.onhandQty=ISNULL(a.onhandQty,0.0)+ISNULL(b.diffQty,0.0)
FROM IMS_Ledger a INNER JOIN	
	(SELECT companyId,warehouseId,itemId,SUM(ISNULL(realQty,0.0)-ISNULL(onhandQty,0.0)) AS diffQty
	 FROM IMS_CheckStock
	 WHERE pointId=@pointId
	 GROUP BY companyId,warehouseId,itemId) b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId
SET @errorSun=@errorSun+@@ERROR

----报错回滚----
IF @errorSun<>0 ROLLBACK TRAN;
ELSE COMMIT TRAN;



go

