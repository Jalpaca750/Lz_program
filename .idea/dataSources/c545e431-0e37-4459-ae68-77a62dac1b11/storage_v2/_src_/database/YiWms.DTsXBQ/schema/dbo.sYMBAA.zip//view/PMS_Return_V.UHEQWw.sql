/*==============================================================*/
/* View: PMS_Return_V                                           */
/*==============================================================*/
--creator：      Frank
--create time：  2016-03-17
--modify：       2017-11-23 增加字段并修改视图V1.2
CREATE view PMS_Return_V as
SELECT a.returnNo,a.billNo,CONVERT(VARCHAR(10),a.returnDate,23) AS returnDate,a.companyId,
	c.companyName,a.ownerId,o.partnerNo AS ownerNo,o.partnerName AS ownerName,o.shortName AS ownerShortName,
	a.supplierId,p.partnerNo AS supplierNo,p.partnerName AS supplierName,p.shortName,
	p.partnerSpell AS supplierSpell,a.warehouseId,w.warehouseNo,w.warehouseName,a.ioType,
	'采购退货单' AS ioTypeDesc,a.currencyId,a.exchangeRate,a.taxFlag,a.ioState,
	CASE a.ioState WHEN 0 THEN '已作废' WHEN 10 THEN '待审核' WHEN 20 THEN '已审核' END AS ioStateName,
	a.apState,a.totalFee,a.postFee,a.reason,a.expressNo,a.logisticsId,l.logisticsCode,l.logisticsName,
	a.buyerId,e1.employeeName AS buyerName,a.handlerId,e2.employeeName AS handlerName,a.deptId,
	d.deptNo,d.deptName,a.printNum,a.printId,u1.userNick AS printMan,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,
	a.auditorId,u2.userNick AS auditorName,CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,
	a.thirdPartyNo,a.thirdSyncFlag,CONVERT(VARCHAR(20),a.thirdSyncTime,120) AS thirdSyncTime,
	a.retField1,a.retField2,a.retField3,a.retField4,a.retField5,a.memo,a.isLocked,a.lockerId,
	u3.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,
	a.creatorId,u4.userNick AS creatorName,a.editTime,a.editorId,u5.userNick AS editorName,
	a.isSelected
FROM dbo.PMS_Return a
	INNER JOIN dbo.SAM_Company c ON a.companyId=c.companyId
	INNER JOIN dbo.BAS_Partner p ON a.supplierId=p.partnerId
	INNER JOIN dbo.BAS_Partner o ON a.ownerId=o.partnerId
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	LEFT JOIN dbo.BAS_Logistics l ON a.logisticsId=l.logisticsId
	LEFT JOIN dbo.BAS_Employee e1 ON a.buyerId=e1.employeeId
	LEFT JOIN dbo.BAS_Employee e2 ON a.handlerId=e2.employeeId
	LEFT JOIN dbo.BAS_Department d ON a.deptId=d.deptId
	LEFT JOIN dbo.SAM_User u1 ON a.printId=u1.userId
	LEFT JOIN dbo.SAM_User u2 ON a.auditorId=u2.userId
	LEFT JOIN dbo.SAM_User u3 ON a.lockerId=u3.userId
	LEFT JOIN dbo.SAM_User u4 ON a.creatorId=u4.userId
	LEFT JOIN dbo.SAM_User u5 ON a.editorId=u5.userId
go

