
/*==============================================================*/
/* View: TMS_Customer_V                                         */
/*==============================================================*/
create view TMS_Customer_V as
SELECT a.customerId,a.siteId,b.siteNo,b.siteName,a.companyId,a.customerNo,a.customerName,
	a.shortName,a.fromState,a1.areaName AS stateName,a.fromCity,a2.areaName AS cityName,
	a.fromDistrict,a3.areaName AS districtName,a.fromTown,a4.areaName AS townName,a.fromAddress,
	ISNULL(a1.areaName,'')+ISNULL(a2.areaName,'')+ISNULL(a3.areaName,'')+ISNULL(a4.areaName,'')+a.fromAddress AS fullAddress,
	a.fromContacts,a.fromPhone,a.fromMobile,a.settlementId,a.reportCode,
	a.exField01,a.exField02,a.exField03,a.exField04,a.exField05,a.exField06,a.exField07,
	a.exField08,a.exField09,a.exField10,a.isDisable,CASE a.isDisable WHEN 1 THEN '是' ELSE '否' END AS disableDesc,
	a.memo,a.isLocked,a.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
	a.createTime,a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName,
	a.isSelected
FROM dbo.TMS_Customer a
	INNER JOIN dbo.TMS_Site b ON a.siteId=b.siteId
	LEFT  JOIN dbo.BAS_Area a1 ON a.fromState=a1.areaId
	LEFT  JOIN dbo.BAS_Area a2 ON a.fromCity=a2.areaId
	LEFT  JOIN dbo.BAS_Area a3 ON a.fromDistrict=a3.areaId	
	LEFT  JOIN dbo.BAS_Area a4 ON a.fromTown=a4.areaId		
	LEFT  JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId
	LEFT  JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId
	LEFT  JOIN dbo.SAM_User u3 ON a.editorId=u3.userId
go

