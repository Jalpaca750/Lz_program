
/*==============================================================*/
/* View: TMS_Ship_V                                             */
/*==============================================================*/
create view TMS_Ship_V as
SELECT b.shipId,a.billNo AS shipBillNo,a.shipDate
FROM dbo.WMS_Ship a
    INNER JOIN dbo.WMS_ShipDetail b ON a.shipNo=b.shipNo
go

