

-- =============================================
-- Author:		zdy
-- Create date: <Create Date:2017-03-29>
-- EDIT   DATE:<2017-04-18--OK>
-- Description:	<Description:拣货扣库存>
-- =============================================
CREATE Proc  [dbo].[proc_PickingItem]
(@pickingId varchar(32),
@operatorId varchar(32),
@qty decimal(20,6))
as
declare @eid varchar(32)=''
declare @stockid  varchar(32)='' --库存ID
declare @pickingbillno varchar(100)=''--拣货单号
declare @pickingNo varchar(32)=''
declare @companyId varchar(32)=''
declare @warehouseId varchar(32)='' ---仓库
declare @itemId  varchar(32)=''     --商品的ID
declare @regionid varchar(32)=''    --区域
declare @stockQty decimal(20,6)=0   --库存的数量
declare @locationNo varchar(40)=''  --货位
declare @lotNo varchar(40)=''       --批次
declare @errorCount int ---错误计数器
declare @sad_stockNo  varchar(32) --出库单号
declare @result_code int 
declare @isPackage int=0 --是否是整包装
declare @realQty decimal(20,6) --散件数量
declare @pickQty decimal(20,6)=@qty
declare @pkgRatio int=0
---写入流水
DECLARE @book_StockNo varchar(32)
DECLARE @book_BillNo varchar(32)
DECLARE @book_StockId varchar(32)

declare @bef_qty decimal(20,6)
declare @stock_qty decimal(20,6)

begin  tran
---参数
select @companyId=companyid,
@warehouseId=warehouseId,
@itemId=itemId,
@pickingNo=pickingNo,
@regionid=isnull(regionId,''),
@pkgRatio=pkgRatio,
@realQty=realQty,
@sad_stockNo=stockNo,
@isPackage=isPackage,
@locationNo=isnull(locationNo,''),@lotNo=isnull(batchNo,''),
@book_BillNo=stockBillNo,@book_StockId=stockId,@book_StockNo=stockNo
from  WMS_PickingDetail_V where pickingId=@pickingId

--取pickingno
select @pickingbillno=billNo from WMS_Picking where pickingNo=@pickingNo
--实际库存
select  @eid=eId , @stockid=stockid, @stockQty=isnull(onhandQty,0) from IMS_Stock 
where companyId=@companyId and
 warehouseId=@warehouseId and isnull(regionId,'')=@regionid 
and  itemId=@itemId and locationNo=@locationNo and lotNo=@lotNo
if @isPackage=1
begin  --如果是整包装
   if @qty>0
   begin
    set @qty=(@qty*@pkgRatio)--@realQty
   end 
end
print  cast(@stockQty as varchar(30))+'---'+cast(@qty as varchar(40))
if not exists(select pickingId from WMS_PickingDetail where pickingId=@pickingId and pickState<2)
begin
print '----这里'
set @errorCount=1
set @result_code=-2
end
--else if  @stockQty<@qty --如果库存不够
--begin
--print '库存不足' 
-- set @errorCount=1
-- set @result_code=-1 
--end
else 
begin 
  set @result_code=1
 --修改拣货的状态
 Update   WMS_PickingDetail  set pickState=2,pickQty=@pickQty where pickingId=@pickingId
 set @errorCount+=@@ERROR
 --修改库存 
 update  IMS_Stock set 
 onhandQty=onhandQty-@qty,
 allocQty=(allocQty-@realQty),--占用量不能被扣为负数
 lastOTime=GETDATE() 
 where stockId=@stockid
 set @errorCount+=@@ERROR
 --修改总库存
 update  IMS_Ledger set onhandQty=onhandQty-@qty,allocQty=allocQty-@realQty ,lastOTime=GETDATE() 
 where companyId=@companyId and warehouseId=@warehouseId and itemId=@itemId
 set @errorCount+=@@ERROR
 
 ---累加出库单详细的拣货数量
 select @bef_qty=ISNULL(pickQty,0.0),@stock_qty=ISNULL(stockQty,0.0) from SAD_StockDetail where stockId=@book_StockId;
      UPDATE  SAD_StockDetail SET pickQty=ISNULL(pickQty,0)+@qty WHERE stockId=@book_StockId
      set @errorCount+=@@ERROR
      
      
 ---写入流水账
 INSERT INTO IMS_Book(
	[bookId],[ioType],[companyId],[billId],[billNo],[billCode],[objectId],[warehouseId],
	[lotNo],[locationNo],[eId],[itemId],[befQty],[taxFlag],
	[discount],[discountFee],[ioQty],[price],[fee],[taxFee],
	[afterQty],[handlerId],[deptId],[createTime],
	[creatorId],[auditorId],[auditTime],[memo])
 values(REPLACE(NEWID(),'-',''),'S100',@companyId,@book_StockId,@book_StockNo,@book_BillNo,@book_StockId,@warehouseId,
 @lotNo,@locationNo,@eid,@itemId,@stockQty,null,null,null,-@qty,null,null,null,
 (@stockQty-@qty),null,null,GETDATE(),@operatorId,'',GETDATE(),'')
 set @errorCount+=@@ERROR

------更新出库单审核状态

declare @_st_Count int=0;
declare @_st_had_Count int=-1;

---计算出出库单的拣货任务
select @_st_Count=COUNT(1) from WMS_PickingDetail 
where  stockNo=@sad_stockNo and stockQty>0 and len(locationNo)>0
---拣过的
select @_st_had_Count=COUNT(1) from WMS_PickingDetail
where stockNo=@sad_stockNo  and stockQty>0 and pickState<2 and len(locationNo)>0
----判断是不是拣货完成了
if @_st_had_Count=0
begin
   ---更新出库单的状态 审核人
   update  SAD_Stock set  taskState=50,auditorId=@operatorId,auditTime=GETDATE()
   where stockNo=@sad_stockNo
   set @errorCount+=@@ERROR
end
--========================如果拣货全部完成了====================================
declare @IS_ALL int=0
select @IS_ALL=COUNT(1) from  WMS_PickingDetail 
where pickingNo=@pickingNo and pickState<2  and stockQty>0   and len(locationNo)>0
if @IS_ALL=0
begin
		UPDATE  WMS_Picking  set taskState=2 WHERE   pickingNo=@pickingNo;
		UPDATE  WMS_PickingOrder SET taskState=2,pickTime=GETDATE() WHERE pickingNo=@pickingNo and  taskState<2;
		UPDATE  WMS_PickingDetail SET pickState=2 WHERE  pickingNo=@pickingNo and  pickState<2;
		---把那些整箱的直接搞成完成把
		/*IF EXISTS(SELECT pickingNo FROM WMS_Picking WHERE pickingNo=@pickingNo AND taskType=1)
		BEGIN
		update   WMS_PickingOrder set taskState=4
		where pickingNo=@pickingNo and isPackage=1;
		UPDATE WMS_Picking SET taskState=9 where pickingNo=@pickingNo;
		END */
		----如果是补货任务的货 完成后更新补货计划的数据
		IF EXISTS(SELECT PICKINGNO FROM WMS_PICKING WHERE PICKINGNO=@PICKINGNO AND TASKTYPE=2)
		BEGIN
		  update   WMS_PickingOrder set taskState=4
		  where pickingNo=@pickingNo and isPackage=1;
		UPDATE  IMS_REPLENISH  SET   IOSTATE=20,pickerId=@operatorId,pickingTime=GETDATE(),putawayId=@operatorId,putawayTime=GETDATE()  
		WHERE REPLENISHID IN (SELECT STOCKNO FROM WMS_PICKINGORDER WHERE PICKINGNO=@PICKINGNO)   
		END
  end
end
-----============================================================================
select @result_code
if @errorCount<>0
begin
 print  '返回'
 rollback tran;
end
else  begin
commit tran;
end 








































go

