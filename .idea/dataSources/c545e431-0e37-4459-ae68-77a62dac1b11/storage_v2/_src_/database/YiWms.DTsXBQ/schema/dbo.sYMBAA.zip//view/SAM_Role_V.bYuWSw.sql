/*==============================================================*/
/* View: SAM_Role_V                                             */
/*==============================================================*/
--creator：     Frank
--create time:  2016-08-04整理
--系统角色视图
CREATE view [dbo].[SAM_Role_V] as
SELECT r.roleId,r.roleNo,r.roleName,r.companyId,r.isLocked,r.lockerId,u3.userNick AS lockerName,
      CONVERT(VARCHAR(20),r.lockedTime,120) AS lockedTime,r.creatorId,u1.userNick AS creatorName,
      r.createTime,r.editorId,u2.userNick AS editorName, r.editTime, r.isSelected   
FROM dbo.SAM_Role r 
	LEFT JOIN dbo.SAM_User u1 ON r.creatorId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON r.editorId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON r.lockerId=u3.userId

go

