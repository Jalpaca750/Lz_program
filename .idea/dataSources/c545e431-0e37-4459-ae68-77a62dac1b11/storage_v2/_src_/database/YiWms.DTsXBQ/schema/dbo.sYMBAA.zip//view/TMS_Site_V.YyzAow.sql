
/*==============================================================*/
/* View: TMS_Site_V                                             */
/*==============================================================*/
create view TMS_Site_V as
SELECT a.siteId,a.siteNo,a.siteName,a.companyId,a.exSite01,a.exSite02,a.exSite03,
	a.exSite04,a.exSite05,a.parentId,p.siteNo AS parentNo,a.siteName AS parentName,
	a.siteState,CASE a.siteState WHEN 1 THEN '有效' WHEN 0 THEN '失效' END stateDesc,
	a.isLocked,a.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) lockedTime,
	a.createTime,a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,
	u3.userNick AS editorName,a.isSelected
FROM dbo.TMS_Site a
	LEFT  JOIN dbo.TMS_Site p ON a.parentId=p.siteId
	LEFT  JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId
	LEFT  JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId
	LEFT  JOIN dbo.SAM_User u3 ON a.editorId=u3.userId
go

