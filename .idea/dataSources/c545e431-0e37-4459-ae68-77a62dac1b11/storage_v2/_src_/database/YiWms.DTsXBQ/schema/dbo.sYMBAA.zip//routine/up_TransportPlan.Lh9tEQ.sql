-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2018-01-30>
-- Description:	<Description:配送计划（排车），扫描出库单、退货单、项目单、发票进行配送安排>
--		@shipNo:		--装车单No
--      @companyId:		--公司Id
--      @billType:		--单据类型
--      @billNo:		--装车单编号
--		@stockNo:		--出库单No(出库单、退货单、项目单、发票等）
--      @shipDate：		--发车日期
--      @shipTime：		--发车时间
--      @carId:			--车辆Id
--      @driverId:		--驾驶员
--		@deliveryId：	--送货员
--      @siteId：		--配送网点
--      @logisticsId:   --物流快递公司Id
--		@expressNo:		--快递单号
--      @postFee:       --快递费
--      @groupId：		--
--		@lineId：		--线路
--		@handlerId：	--经办人
--		@rewrite INT:	--补录装车
--		@operatorId:	--排计划的人
-- Modify:  2019-05-23 Frank 增加单据金额到装车单
--          2019-05-30 Frank 增加件数字段（主要用于对接第三方系统时，重打标签）
--          2019-06-27 Frank 修正部分装车Bug
-- =============================================
CREATE PROCEDURE [dbo].[up_TransportPlan]( 
	@shipNo VARCHAR(32),                --装车单No         
	@companyId VARCHAR(32),             --公司Id
	@billType INT,                      --单据类型
	@billNo VARCHAR(32),                --装车单编号
	@stockNo VARCHAR(32),               --出库单No(出库单、退货单、项目单、发票等）
	@pkgQty INT,                        --对接其他系统时，重新定义件数
	@shipDate VARCHAR(32),              --发车日期
	@shipTime VARCHAR(32),              --发车时间
	@carId VARCHAR(32),                 --车辆Id
	@driverId VARCHAR(32),              --驾驶员
	@deliveryId VARCHAR(32),            --送货员
	@siteId VARCHAR(32),                --配送网点
	@logisticsId VARCHAR(32),           --物流快递公司Id
	@expressNo VARCHAR(40),				--快递单号
	@postFee DECIMAL(20,10),            --快递费
	@groupId VARCHAR(32),               --辖区？分组？
	@lineId VARCHAR(32),                --线路
	@handlerId VARCHAR(32),             ---经办人
	@rewrite INT,						--补录装车:0-否1,是
	@operatorId VARCHAR(32)             --排计划的人
)
AS
BEGIN	
	DECLARE @fromCustomer VARCHAR(32),		--寄件客户
			@fromContacts VARCHAR(40),		--寄件人
			@fromPhone VARCHAR(100),		--寄件人电话
			@fromState VARCHAR(40),			--寄件地址（省）
			@fromCity VARCHAR(40),			--寄件地址（市）
			@fromDistrict VARCHAR(40),		--寄件地址（区）
			@fromTown VARCHAR(40),			--寄件地址（镇）
			@fromAddress VARCHAR(100),		--寄件地址（地址）
			@settlementId VARCHAR(32),		--结算方式
			@boxBillNum VARCHAR(32),        --子运单号
			@itemName VARCHAR(200);			--配送物品
	DECLARE @aFlag INT,@mergeNo VARCHAR(32),@delivery BIGINT,@sumWeight DECIMAL(10,4),@sumCount INT,@isLocked INT,@subQty INT;    
	DECLARE @maxOrder INT,@hasTms INT,@thirdFlag INT,@stockBillNo VARCHAR(20),@shipId VARCHAR(32),@waybillId VARCHAR(32),@wlDesc VARCHAR(200);
	--临时数据，存储重量用于分摊运费
    DECLARE @tmpSales TABLE(stockId VARCHAR(32),stockQty DECIMAL(20,6),subWeight DECIMAL(10,4),postPrice DECIMAL(20,10));
	--初始化排队锁
	SET @isLocked=1;
	--排队
    WHILE EXISTS(SELECT * FROM dbo.BAS_Car WHERE carId=@carId AND isSelected=1)
    BEGIN
        SET @isLocked=1;
    END
	--锁定
    UPDATE dbo.BAS_Car SET isSelected=1 WHERE carId=@carId;	
	--是否有获得Tms产品授权
	IF EXISTS(SELECT 1 FROM SAM_CompanyProduct WHERE companyId=@companyId AND productCode='YFP0006') 
		SET @hasTms=1;
	ELSE
		SET @hasTms=0;
	--第三方配送标识
	SELECT @thirdFlag=ISNULL(thirdFlag,0),@wlDesc=CASE ISNULL(thirdFlag,0) WHEN 0 THEN '' ELSE ISNULL(carNumber,'') + ':' + @expressNo END    
	FROM dbo.BAS_Car 
	WHERE carId=@carId;	
	--获取当前出库单类型
	SELECT @aFlag=aFlag,@mergeNo=mergeNo FROM dbo.SAD_Stock WHERE stockNo=@stockNo;
	--清除错误日志
	DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='up_TransportPlan' AND creatorId=@operatorId;
	BEGIN TRY
		BEGIN TRANSACTION
		--如果发车单已发车则直接退出
		IF @rewrite=0 AND EXISTS(SELECT 1 FROM dbo.WMS_Ship WHERE shipNo=@shipNo AND shipState>10)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_TransportPlan','YI_TRANSPORT_REMOVE_CANNOT_REMOVE','装车单已经装车发货，操作无效！',@shipId,@shipNo);		
			--解锁
            UPDATE dbo.BAS_Car SET isSelected=0 WHERE carId=@carId;
			COMMIT;
			RETURN;
		END
		--已经装过车了
		IF (EXISTS(SELECT 1 FROM dbo.WMS_Ship WHERE shipNo=@shipNo))
		BEGIN
			UPDATE dbo.WMS_Ship SET lineId=@lineId,driverId=@driverId,deliveryId=@deliveryId,editTime=GETDATE(),editorId=@operatorId,
				isLocked=1,lockerId=@operatorId,lockedTime=GETDATE() 
			WHERE shipNo=@shipNo AND @rewrite=0;
			--当前车辆最大序号
			SELECT @maxOrder=MAX(viewOrder) FROM dbo.WMS_ShipDetail WHERE shipNo=@shipNo;
			SET @maxOrder=ISNULL(@maxOrder,0)+1;
		END
		ELSE
		BEGIN
			--装第一单(锁定状态，不允许发车）避免多人操作
			INSERT INTO dbo.WMS_Ship(shipNo,companyId,billNo,createTime,shipDate,shipTime,carId,driverId,deliveryId,
				groupId,lineId,handlerId,shipState,memo,printNum,printId,creatorId,auditorId,auditTime,isLocked,
				lockerId,lockedTime,editTime,editorId)
			VALUES(@shipNo,@companyId,@billNo,GETDATE(),@shipDate,@shipTime,@carId,@driverId,@deliveryId,
				@groupId,@lineId,@handlerId,10,'',0,'',@operatorId,'',NULL,1,@operatorId,GETDATE(),GETDATE(),@operatorId);
			SET @maxOrder=1;
		END
		--装当前单据
		IF (NOT EXISTS(SELECT 1 FROM dbo.WMS_ShipDetail WHERE shipNo=@shipNo AND billNo=@stockNo AND billType=@billType))
		BEGIN
		    SET @shipId=LOWER(REPLACE(NEWID(),'-',''));
		    IF (@billType<60)       --发货单
		        INSERT INTO dbo.WMS_ShipDetail(shipId,shipNo,companyId,viewOrder,billType,billNo,stockBillNo,customerId,
			          receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,
			          pkgQty,fclQty,pkgVolumn,lclQty,lclVolumn,fileQty,shipState,netWeight,grossWeight,mergeNo,boxBillNums,
			          postFee,totalFee,isInvalid,lineOrder,remarks)
		        SELECT @shipId,@shipNo,@companyId,@maxOrder,billType,billNo,stockBillNo,customerId,
			          receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,
			          pkgQty,fclQty,pkgVolumn,lclQty,lclVolumn,fileQty,10,netWeight,grossWeight,mergeNo,@expressNo,
			          @postFee,totalFee,isInvalid,lineOrder,remarks
		        FROM dbo.WMS_ShipBill_V a
		        WHERE (billNo=@stockNo)
		            AND (billType=@billType);
		    ELSE IF(@billType=60)   --退货单
		        INSERT INTO dbo.WMS_ShipDetail(shipId,shipNo,companyId,viewOrder,billType,billNo,stockBillNo,customerId,
			          receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,
			          pkgQty,fclQty,pkgVolumn,lclQty,lclVolumn,fileQty,shipState,netWeight,grossWeight,mergeNo,boxBillNums,
			          postFee,totalFee,isInvalid,lineOrder,remarks)
		        SELECT @shipId,@shipNo,@companyId,@maxOrder,billType,billNo,stockBillNo,customerId,
			          receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,
			          pkgQty,@pkgQty,pkgVolumn,lclQty,lclVolumn,fileQty,10,netWeight,grossWeight,mergeNo,@expressNo,
			          @postFee,totalFee,isInvalid,lineOrder,remarks
		        FROM dbo.WMS_ShipReturn_V a
		        WHERE (billNo=@stockNo)
		            AND (billType=@billType);
		    ELSE IF(@billType=70)   --发票
		        INSERT INTO dbo.WMS_ShipDetail(shipId,shipNo,companyId,viewOrder,billType,billNo,stockBillNo,customerId,
			          receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,
			          pkgQty,fclQty,pkgVolumn,lclQty,lclVolumn,fileQty,shipState,netWeight,grossWeight,mergeNo,boxBillNums,
			          postFee,totalFee,isInvalid,lineOrder,remarks)
		        SELECT @shipId,@shipNo,@companyId,@maxOrder,billType,billNo,stockBillNo,customerId,
			          receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,
			          pkgQty,@pkgQty,pkgVolumn,lclQty,lclVolumn,fileQty,10,netWeight,grossWeight,mergeNo,@expressNo,
			          @postFee,totalFee,isInvalid,lineOrder,remarks
		        FROM dbo.WMS_ShipInvoice_V a
		        WHERE (billNo=@stockNo)
		            AND (billType=@billType);
		    ELSE IF(@billType=80)   --其他出库单
		        INSERT INTO dbo.WMS_ShipDetail(shipId,shipNo,companyId,viewOrder,billType,billNo,stockBillNo,customerId,
			          receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,
			          pkgQty,fclQty,pkgVolumn,lclQty,lclVolumn,fileQty,shipState,netWeight,grossWeight,mergeNo,boxBillNums,
			          postFee,totalFee,isInvalid,lineOrder,remarks)
		        SELECT @shipId,@shipNo,@companyId,@maxOrder,billType,billNo,stockBillNo,customerId,
			          receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,
			          pkgQty,@pkgQty,pkgVolumn,@pkgQty,lclVolumn,fileQty,10,netWeight,grossWeight,mergeNo,@expressNo,
			          @postFee,totalFee,isInvalid,lineOrder,remarks
		        FROM dbo.WMS_ShipStock_V a
		        WHERE (billNo=@stockNo)
		            AND (billType=@billType);
		    ELSE IF(@billType=90)   --项目单
		        INSERT INTO dbo.WMS_ShipDetail(shipId,shipNo,companyId,viewOrder,billType,billNo,stockBillNo,customerId,
			          receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,
			          pkgQty,fclQty,pkgVolumn,lclQty,lclVolumn,fileQty,shipState,netWeight,grossWeight,mergeNo,boxBillNums,
			          postFee,totalFee,isInvalid,lineOrder,remarks)
		        SELECT @shipId,@shipNo,@companyId,@maxOrder,billType,billNo,stockBillNo,customerId,
			          receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,
			          pkgQty,@pkgQty,pkgVolumn,lclQty,lclVolumn,fileQty,10,netWeight,grossWeight,mergeNo,@expressNo,
			          @postFee,totalFee,isInvalid,lineOrder,remarks
		        FROM dbo.WMS_ShipProject_V a
		        WHERE (billNo=@stockNo)
		            AND (billType=@billType);
		END
		IF (@@ROWCOUNT>0)
		BEGIN
			--装车单据号（编号）
			SELECT @stockBillNo=stockBillNo FROM dbo.WMS_ShipDetail a WHERE shipId=@shipId;		
			--如果授权了TMS系统，则同时生成运单
			IF (@hasTms=1)
			BEGIN	
				--当前设置的配送客户Id
				SET @fromCustomer='c24d5045d03048cc972b31f4b644e5d2';
				SELECT @fromContacts=fromContacts,@fromPhone=fromPhone,@fromState=fromState,@fromCity=fromCity,
					@fromDistrict=fromDistrict,@fromTown=fromTown,@fromAddress=fromAddress,@settlementId=settlementId
				FROM dbo.TMS_Customer
				WHERE customerId=@fromCustomer;				
				--写入运单(第一次安排物流时)
				IF NOT EXISTS(SELECT * FROM dbo.TMS_WayBill WHERE wmsStockNo=@stockNo AND billType=@billType)
				BEGIN
				    SET @waybillId=LOWER(REPLACE(NEWID(),'-',''));
				    IF @billType<60
				        INSERT INTO dbo.TMS_WayBill(waybillId,companyId,siteId,waybillDate,pickerId,waybillNo,waybillType,
					        lineId,boxCount,boxWeight,settleCount,settleWeight,postFee,settlementId,isInsure,premium,insureFee,
					        agentFee,poundage,fromCustomerId,fromContacts,fromPhone,fromState,fromCity,fromDistrict,fromTown,
					        fromAddress,toCustomerId,toContacts,toPhone,toState,toCity,toDistrict,toTown,toAddress,shipId,
					        wmsStockNo,billState,billType,itemName,memo,exField01,isLocked,lockerId,lockedTime,createTime,
					        creatorId,editTime,editorId)
				        SELECT @waybillId,@companyId,@siteId,GETDATE(),@operatorId,stockBillNo,'-1',
					        @lineId,ISNULL(pkgQty,0.0)+ISNULL(lclQty,0.0)+ISNULL(fileQty,0.0),grossWeight,ISNULL(fclQty,0.0)+ISNULL(fileQty,0.0),
					        grossWeight,@postFee,@settlementId,0 AS isInsure,0.0 AS premium,0.0 AS insureFee,
					        0.0 AS agentFee,0.0 AS poundage,@fromCustomer,@fromContacts,@fromPhone,@fromState,@fromCity,@fromDistrict,@fromTown,
					        @fromAddress,customerId,receiverName,receiverTel,receiverState,receiverCity,receiverDistrict,'' AS toTown,receiverAddress,
					        @shipId,billNo,10,@billType,@itemName,remarks,ServiceName,0,'',NULL,GETDATE(),@operatorId,GETDATE(),@operatorId
				        FROM dbo.WMS_ShipBill_V a
				        WHERE (billNo=@stockNo)
				            AND (billType=@billType);
				    ELSE IF (@billType=60)
				        INSERT INTO dbo.TMS_WayBill(waybillId,companyId,siteId,waybillDate,pickerId,waybillNo,waybillType,
					        lineId,boxCount,boxWeight,settleCount,settleWeight,postFee,settlementId,isInsure,premium,insureFee,
					        agentFee,poundage,fromCustomerId,fromContacts,fromPhone,fromState,fromCity,fromDistrict,fromTown,
					        fromAddress,toCustomerId,toContacts,toPhone,toState,toCity,toDistrict,toTown,toAddress,shipId,
					        wmsStockNo,billState,billType,itemName,memo,exField01,isLocked,lockerId,lockedTime,createTime,
					        creatorId,editTime,editorId)
				        SELECT @waybillId,@companyId,@siteId,GETDATE(),@operatorId,stockBillNo,'-1',
					        @lineId,ISNULL(pkgQty,0.0)+ISNULL(lclQty,0.0)+ISNULL(fileQty,0.0),grossWeight,ISNULL(fclQty,0.0)+ISNULL(fileQty,0.0),
					        grossWeight,@postFee,@settlementId,0 AS isInsure,0.0 AS premium,0.0 AS insureFee,
					        0.0 AS agentFee,0.0 AS poundage,@fromCustomer,@fromContacts,@fromPhone,@fromState,@fromCity,@fromDistrict,@fromTown,
					        @fromAddress,customerId,receiverName,receiverTel,receiverState,receiverCity,receiverDistrict,'' AS toTown,receiverAddress,
					        @shipId,billNo,10,@billType,@itemName,remarks,ServiceName,0,'',NULL,GETDATE(),@operatorId,GETDATE(),@operatorId
				        FROM dbo.WMS_ShipReturn_V a
				        WHERE (billNo=@stockNo)
				            AND (billType=@billType);
				    ELSE IF (@billType=70)
				        INSERT INTO dbo.TMS_WayBill(waybillId,companyId,siteId,waybillDate,pickerId,waybillNo,waybillType,
					        lineId,boxCount,boxWeight,settleCount,settleWeight,postFee,settlementId,isInsure,premium,insureFee,
					        agentFee,poundage,fromCustomerId,fromContacts,fromPhone,fromState,fromCity,fromDistrict,fromTown,
					        fromAddress,toCustomerId,toContacts,toPhone,toState,toCity,toDistrict,toTown,toAddress,shipId,
					        wmsStockNo,billState,billType,itemName,memo,exField01,isLocked,lockerId,lockedTime,createTime,
					        creatorId,editTime,editorId)
				        SELECT @waybillId,@companyId,@siteId,GETDATE(),@operatorId,stockBillNo,'-1',
					        @lineId,ISNULL(pkgQty,0.0)+ISNULL(lclQty,0.0)+ISNULL(fileQty,0.0),grossWeight,ISNULL(fclQty,0.0)+ISNULL(fileQty,0.0),
					        grossWeight,@postFee,@settlementId,0 AS isInsure,0.0 AS premium,0.0 AS insureFee,
					        0.0 AS agentFee,0.0 AS poundage,@fromCustomer,@fromContacts,@fromPhone,@fromState,@fromCity,@fromDistrict,@fromTown,
					        @fromAddress,customerId,receiverName,receiverTel,receiverState,receiverCity,receiverDistrict,'' AS toTown,receiverAddress,
					        @shipId,billNo,10,@billType,@itemName,remarks,ServiceName,0,'',NULL,GETDATE(),@operatorId,GETDATE(),@operatorId
				        FROM dbo.WMS_ShipInvoice_V a
				        WHERE (billNo=@stockNo)
				            AND (billType=@billType);
				    ELSE IF (@billType=80)
				        INSERT INTO dbo.TMS_WayBill(waybillId,companyId,siteId,waybillDate,pickerId,waybillNo,waybillType,
					        lineId,boxCount,boxWeight,settleCount,settleWeight,postFee,settlementId,isInsure,premium,insureFee,
					        agentFee,poundage,fromCustomerId,fromContacts,fromPhone,fromState,fromCity,fromDistrict,fromTown,
					        fromAddress,toCustomerId,toContacts,toPhone,toState,toCity,toDistrict,toTown,toAddress,shipId,
					        wmsStockNo,billState,billType,itemName,memo,exField01,isLocked,lockerId,lockedTime,createTime,
					        creatorId,editTime,editorId)
				        SELECT @waybillId,@companyId,@siteId,GETDATE(),@operatorId,stockBillNo,'-1',
					        @lineId,ISNULL(pkgQty,0.0)+ISNULL(lclQty,0.0)+ISNULL(fileQty,0.0),grossWeight,ISNULL(fclQty,0.0)+ISNULL(fileQty,0.0),
					        grossWeight,@postFee,@settlementId,0 AS isInsure,0.0 AS premium,0.0 AS insureFee,
					        0.0 AS agentFee,0.0 AS poundage,@fromCustomer,@fromContacts,@fromPhone,@fromState,@fromCity,@fromDistrict,@fromTown,
					        @fromAddress,customerId,receiverName,receiverTel,receiverState,receiverCity,receiverDistrict,'' AS toTown,receiverAddress,
					        @shipId,billNo,10,@billType,@itemName,remarks,ServiceName,0,'',NULL,GETDATE(),@operatorId,GETDATE(),@operatorId
				        FROM dbo.WMS_ShipStock_V a
				        WHERE (billNo=@stockNo)
				            AND (billType=@billType);
				    ELSE IF (@billType=90)
				        INSERT INTO dbo.TMS_WayBill(waybillId,companyId,siteId,waybillDate,pickerId,waybillNo,waybillType,
					        lineId,boxCount,boxWeight,settleCount,settleWeight,postFee,settlementId,isInsure,premium,insureFee,
					        agentFee,poundage,fromCustomerId,fromContacts,fromPhone,fromState,fromCity,fromDistrict,fromTown,
					        fromAddress,toCustomerId,toContacts,toPhone,toState,toCity,toDistrict,toTown,toAddress,shipId,
					        wmsStockNo,billState,billType,itemName,memo,exField01,isLocked,lockerId,lockedTime,createTime,
					        creatorId,editTime,editorId)
				        SELECT @waybillId,@companyId,@siteId,GETDATE(),@operatorId,stockBillNo,'-1',
					        @lineId,ISNULL(pkgQty,0.0)+ISNULL(lclQty,0.0)+ISNULL(fileQty,0.0),grossWeight,ISNULL(fclQty,0.0)+ISNULL(fileQty,0.0),
					        grossWeight,@postFee,@settlementId,0 AS isInsure,0.0 AS premium,0.0 AS insureFee,
					        0.0 AS agentFee,0.0 AS poundage,@fromCustomer,@fromContacts,@fromPhone,@fromState,@fromCity,@fromDistrict,@fromTown,
					        @fromAddress,customerId,receiverName,receiverTel,receiverState,receiverCity,receiverDistrict,'' AS toTown,receiverAddress,
					        @shipId,billNo,10,@billType,@itemName,remarks,ServiceName,0,'',NULL,GETDATE(),@operatorId,GETDATE(),@operatorId
				        FROM dbo.WMS_ShipProject_V a
				        WHERE (billNo=@stockNo)
				            AND (billType=@billType);
			    END
				ELSE
				BEGIN
				    SELECT @waybillId=waybillId FROM dbo.TMS_WayBill WHERE wmsStockNo=@stockNo AND billType=@billType
				END
				--生成运单子文件
				IF ((@billType<60) AND (@aFlag=0 OR @aFlag=1))
				BEGIN
				    INSERT INTO TMS_SubWaybill(boxId,companyId,shipNo,shipId,billType,stockNo,stockBillNo,boxBillNum,waybillId,boxState,isPackage,createTime,creatorId)
                    SELECT boxId,@companyId,@shipNo,@shipId,@billType,stockNo,stockBillNo,boxBillNum,@waybillId,10,isPackage,GETDATE(),@operatorId
                    FROM TMS_Box_V
                    WHERE stockNo=@stockNo;
                    --反写散件箱子状态
                    UPDATE a SET a.packState=20,a.editTime=GETDATE(),a.editorId=@operatorId
                    FROM dbo.WMS_Packing a 
                    WHERE EXISTS(SELECT * FROM dbo.TMS_SubWaybill b WHERE a.companyId=b.companyId AND a.boxBillNum=b.boxBillNum AND b.shipNo=@shipNo AND b.isPackage=0)
                        AND (a.stockNo=@stockNo);
                    --反写整件状态
                    UPDATE a SET a.shipState=20
                    FROM dbo.WMS_PickingOrder a 
                    WHERE EXISTS(SELECT * FROM dbo.TMS_SubWaybill b WHERE a.companyId=b.companyId AND a.boxBillNum=b.boxBillNum AND b.shipNo=@shipNo AND b.isPackage=1)
                        AND (a.stockNo=@stockNo);
				END
				ELSE
				BEGIN
				    --退单、发票、项目单、直送单等主单号就是子弹号
				    --文件类生成子文件
				    SET @subQty=1;
				    WHILE (@subQty<=@pkgQty)
				    BEGIN
				        IF (@pkgQty=1)
				            INSERT INTO TMS_SubWaybill(boxId,companyId,shipNo,shipId,billType,stockNo,stockBillNo,boxBillNum,waybillId,boxState,isPackage,createTime,creatorId)
			                SELECT LOWER(REPLACE(NEWID(),'-','')),@companyId,@shipNo,@shipId,@billType,billNo,stockBillNo,stockBillNo,@waybillId,10,2,GETDATE(),@operatorId
			                FROM dbo.WMS_ShipDetail a
			                WHERE billNo=@stockNo AND billType=@billType;
			            ELSE
			                INSERT INTO TMS_SubWaybill(boxId,companyId,shipNo,shipId,billType,stockNo,stockBillNo,boxBillNum,waybillId,boxState,isPackage,createTime,creatorId)
			                SELECT LOWER(REPLACE(NEWID(),'-','')),@companyId,@shipNo,@shipId,@billType,billNo,stockBillNo,stockBillNo + '-' + CAST(@subQty AS VARCHAR(4)),@waybillId,10,2,GETDATE(),@operatorId
			                FROM dbo.WMS_ShipDetail a
			                WHERE billNo=@stockNo AND billType=@billType;
			            SET @subQty=@subQty+1;
			        END
				END
				--生成揽件记录				
			    --wayState:10-揽件;20-发件;30-收件;40-派件;80-留仓;90-妥投;99-回单
			    INSERT INTO TMS_WaySite(wayId,waybillId,companyId,siteId,wayState,wayUserId,typeId,reasonId,nextSite,
				    isLocked,lockerId,lockedTime,createTime,creatorId,editTime,editorId)
			    SELECT LOWER(REPLACE(NEWID(),'-','')),waybillId,companyId,siteId,10,@operatorId,'','','-1',0,'',NULL,
				    GETDATE(),@operatorId,GETDATE(),@operatorId
			    FROM dbo.TMS_WayBill a
			    WHERE waybillId=@waybillId AND NOT EXISTS(SELECT 1 FROM dbo.TMS_WaySite WHERE waybillId=@waybillId AND wayState=10);
			    --如果是补录数据（已发出的）
			    IF (@rewrite=1)
			    BEGIN
				    --运单状态：10-已揽件;20-运输中;30-已派件;
				    UPDATE dbo.TMS_WayBill SET billState=30,editTime=GETDATE(),editorId=@operatorId WHERE waybillId=@waybillId;
				    IF (@@ROWCOUNT>0)
				    BEGIN
					    --wayState:10-揽件;20-发件;30-收件;40-派件;80-留仓;90-妥投;99-回单
					    INSERT INTO TMS_WaySite(wayId,waybillId,companyId,siteId,wayState,wayUserId,nextSite,isLocked,lockerId,
						    lockedTime,createTime,creatorId,editTime,editorId)
					    SELECT LOWER(REPLACE(NEWID(),'-','')),waybillId,companyId,siteId,40,@deliveryId,'-1',0,'',NULL,
						    GETDATE(),@operatorId,GETDATE(),@operatorId
					    FROM dbo.TMS_WayBill
					    WHERE waybillId=@waybillId; 
				    END
			    END
			END
			--如果是补录数据（已发出的）
			IF (@rewrite=1)
			BEGIN
				--更新发车单中对应分拣任务的状态
				UPDATE dbo.WMS_PickingOrder SET taskState=6 WHERE stockNo=@stockNo;
				--更新打包表状态30-已发货
				UPDATE dbo.WMS_Packing SET packState=30 WHERE stockNo=@stockNo;
				--更新销售出库单状态		
				UPDATE dbo.SAD_Stock SET shipState=1,taskState=90,ioState=20,shipTime=GETDATE(),
				                         logisticsId=@logisticsId,expressNo=@expressNo,postFee=@postFee,
										 deliveryId=@deliveryId,deliveryTime=GETDATE(),editorId=@operatorId,editTime=GETDATE()
				WHERE stockNo=@stockNo OR (companyId=@companyId AND aStockNo=@mergeNo);
			END
			ELSE
			BEGIN
			    --更新发车单中对应分拣任务的状态
				UPDATE dbo.WMS_PickingOrder SET taskState=5 WHERE stockNo=@stockNo;
				--更新销售出库单状态
				UPDATE SAD_Stock SET shipState=1,taskState=80,shipTime=GETDATE(),
				                     logisticsId=@logisticsId,expressNo=@expressNo,postFee=@postFee,
									 deliveryId=@deliveryId,deliveryTime=GETDATE(),editorId=@operatorId,editTime=GETDATE()
				WHERE stockNo=@stockNo OR (companyId=@companyId AND aStockNo=@mergeNo);;
			END			
			--更新出库单状态为已装车（排计划）
			--送货员Id
	        SELECT @delivery=employeeID FROM F10BMS.dbo.WMS_F10_User_V WHERE userId=@deliveryId
			IF (@billType=10)
			BEGIN
				UPDATE F10BMS.dbo.SMS_Stock SET Delivery=@delivery,DeliveryTime=CONVERT(VARCHAR(20),GETDATE(),120),
				                                 CarNumberSts='已发车',CarNumberDate=CONVERT(VARCHAR(10),GETDATE(),23),
				                                 logisticsId=@logisticsId,postFee=@postFee,memo=ISNULL(memo,'') + @wlDesc 
				WHERE StockNo=@stockBillNo;
			END
			ELSE IF (@billType=20)
			BEGIN
				UPDATE F10BMS.dbo.IMS_Allot SET CarNumberSts='已发车',CarNumberDate=CONVERT(VARCHAR(10),GETDATE(),23),memo=ISNULL(memo,'') + @wlDesc,
				                                 logisticsId=@logisticsId,postFee=@postFee 
				WHERE AllotNo=@stockBillNo;
			    --分摊运费成本
			    --重量写入临时表
                INSERT INTO @tmpSales(stockId,stockQty,subWeight,postPrice)
                SELECT a.stockId,a.stockQty,a.stockQty*b.itemWeight,0.0
                FROM dbo.SAD_StockDetail a
                    INNER JOIN dbo.BAS_Item b ON a.itemId=b.itemId
                WHERE a.stockNo=@stockNo;
                --获取总重量与总条目数
                SELECT @sumWeight=SUM(subWeight),@sumCount=COUNT(*) FROM @tmpSales;
                --如果没有重量，则平均分摊
                IF (ISNULL(@sumWeight,0.0)=0.0)
                    UPDATE @tmpSales SET postPrice=ROUND(@postFee/@sumCount/stockQty,4);
                ELSE
                    UPDATE @tmpSales SET postPrice=ROUND(@postFee*subWeight/@sumWeight/stockQty,4);
                --同步到F10
                IF EXISTS(SELECT * FROM F10BMS.dbo.IMS_AllotDtl WHERE AllotNo=@stockBillNo)
                BEGIN
                    UPDATE a SET a.Price=ISNULL(a.befPrice,ISNULL(a.Price,0.0))+ISNULL(b.postPrice,0.0),
                                 a.Amt=ISNULL(a.SQty,0.0)*(ISNULL(a.befPrice,ISNULL(a.Price,0.0))+ISNULL(b.postPrice,0.0))
                    FROM F10BMS.dbo.IMS_AllotDtl a 
                        INNER JOIN @tmpSales b ON a.wmsStockId=b.stockId  
                    WHERE a.AllotNo=@stockBillNo;
                END
			END
			ELSE IF (@billType=40)
			BEGIN
				UPDATE F10BMS.dbo.IMS_Present SET CarNumberSts='已发车',CarNumberDate=CONVERT(VARCHAR(10),GETDATE(),23),Remarks=ISNULL(Remarks,'') + @wlDesc WHERE PresentNo=@stockBillNo;
			END
			ELSE IF (@billType=60)					--销售退货单
			BEGIN
				UPDATE F10BMS.dbo.SMS_Return SET CarNumberSts='已发车',CarNumberDate=CONVERT(VARCHAR(10),GETDATE(),23) WHERE ReturnNo=@stockBillNo;
			END
			ELSE IF (@billType=70)				--销售发票
			BEGIN
				UPDATE F10BMS.dbo.SMS_Invoice SET CarNumberSts='已发车',CarNumberDate=CONVERT(VARCHAR(10),GETDATE(),23) WHERE InvoiceNo=@stockBillNo;
			END
			ELSE IF (@billType=80)				--销售收款单
			BEGIN
				UPDATE F10BMS.dbo.SMS_Payment SET CarNumberSts='已发车',CarNumberDate=CONVERT(VARCHAR(10),GETDATE(),23) WHERE PaymentNo=@stockBillNo;
			END
			ELSE IF (@billType=90)				--项目单
			BEGIN
				UPDATE F10BMS.dbo.PRJ_Order SET CarNumberSts='已发车',CarNumberDate=CONVERT(VARCHAR(10),GETDATE(),23) WHERE BillNo=@stockBillNo; 			
		    END
		END
		--释放站队
		UPDATE dbo.BAS_Car SET isSelected=0 WHERE carId=@carId;
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_TransportPlan','YI_TRANSPORT_PLAN_ERROR',LEFT(@ErrMsg,2000),@shipNo,@billNo);		
		UPDATE dbo.BAS_Car SET isSelected=0 WHERE carId=@carId;		
	END CATCH
END
go

