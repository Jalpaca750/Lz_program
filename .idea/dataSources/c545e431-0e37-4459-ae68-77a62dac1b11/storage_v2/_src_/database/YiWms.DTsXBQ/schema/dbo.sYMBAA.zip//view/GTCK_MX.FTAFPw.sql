

/*==============================================================*/
/* View: GTCK_MX  */
/*       @editor:张东彦 @at:2017-07-07     @content:添加仓库编码返回 */
/*==============================================================*/
create view [dbo].[GTCK_MX] as
SELECT r.ownerNo AS YEZ_ID,r.billNo AS DANJ_NO,r.thirdPartyNo AS SHANGJ_DANJ_NO,rd.viewOrder AS linenum,
      bi.itemNo AS itemcode,rd.returnQty AS quantity,rd.price,rd.totalFee AS linetotal,
      rd.stockBillNo AS SAPdocnum,sd.viewOrder AS baseline,
      W.warehouseNo AS WHNO
FROM dbo.PMS_ReturnDetail rd INNER JOIN
      (SELECT m.returnNo,m.billNo,n.ownerNo,m.thirdPartyNo
       FROM dbo.PMS_Return m LEFT JOIN
             dbo.BAS_Owner_V n ON m.ownerId=n.ownerId
      ) r ON rd.returnNo=r.returnNo INNER JOIN
      dbo.BAS_Item bi ON rd.itemId=bi.itemId LEFT JOIN
      dbo.PMS_StockDetail sd ON rd.stockId=sd.stockId
      INNER JOIN BAS_Warehouse W on rd.warehouseId=W.warehouseId

go

