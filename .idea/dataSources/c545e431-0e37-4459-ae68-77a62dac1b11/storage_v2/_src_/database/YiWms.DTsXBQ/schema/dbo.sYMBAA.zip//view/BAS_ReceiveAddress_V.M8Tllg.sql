/*==============================================================*/
/* View: BAS_ReceiveAddress_V                                   */
/*==============================================================*/
--creator：        Frank
--create time：    2016-02-03日整理 
--modify:		   frank 2017-02-03日统一调整fullTel为移动电话+空格+座机
--modify:          frank 2018-12-27日增加单据编号，为齐心SAP对接准备
CREATE view [dbo].[BAS_ReceiveAddress_V] as
SELECT a.addressId,a.addressNo, a.companyId, a.customerId, g.partnerNo AS customerNo, g.partnerName AS customerName,
    g.shortName, g.partnerSpell AS customerSpell, a.receiverState, d.areaName AS stateName, 
    a.receiverCity, e.areaName AS cityName, a.receiverDistrict, f.areaName AS districtName, a.receiverAddress, 
    ISNULL(d.areaName,'') + ISNULL(e.areaName,'') + ISNULL(f.areaName,'') + a.receiverAddress AS fullAddress,
    a.zip, a.receiverName, a.receiverTel, a.receiverMobile, ISNULL(a.receiverMobile,'') + ' ' + ISNULL(a.receiverTel,'') AS fullTel, 
    a.isDefault, CASE a.isDefault WHEN 1 THEN '是' ELSE '否' END AS defaultFlag, a.logisticsId, l.logisticsName,
    a.logisticsMode, a.postFee, a.lineId, b.lineName, a.lineOrder, a.groupId, c.groupName,a.addrField1,a.addrField2,
    a.addrField3,a.addrField4,a.addrField5,a.isDisable,CASE a.isDisable WHEN 1 THEN '是' ELSE '否' END AS disableName, 
    a.isLocked, a.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(10),a.lockedTime,23) AS lockedTime, a.createTime,
    a.creatorId, u2.userNick AS creatorName, a.editTime, a.editorId, u3.userNick AS editorName, a.isSelected  
FROM dbo.BAS_ReceiveAddress AS a 
    INNER JOIN dbo.BAS_Partner AS g ON a.customerId = g.partnerId 
    LEFT JOIN dbo.BAS_AddressLine AS b ON a.lineId = b.lineId 
    LEFT JOIN dbo.BAS_AddressGroup AS c ON a.groupId = c.groupId 
    LEFT JOIN dbo.BAS_Area AS d ON a.receiverState = d.areaId 
    LEFT JOIN dbo.BAS_Area AS e ON a.receiverCity = e.areaId 
    LEFT JOIN dbo.BAS_Area AS f ON a.receiverDistrict = f.areaId 
    LEFT JOIN dbo.BAS_Logistics l ON a.logisticsId=l.logisticsId 
    LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId 
    LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId 
    LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId
go

