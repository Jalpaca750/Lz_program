CREATE PROC up_CopyParameterToItem
(
    @fromItemNo VARCHAR(32),
    @toItemNo VARCHAR(32)
)
AS
BEGIN
    DECLARE @item TABLE(itemNo varchar(32),
                    packageId VARCHAR(32),
                    itemLong DECIMAL(20,6),
                    itemWidth DECIMAL(20,6),
                    itemHeight DECIMAL(20,6),
                    itemVolume DECIMAL(20,6),
                    itemWeight DECIMAL(20,6),
                    pkgLong DECIMAL(20,6),
                    pkgWidth DECIMAL(20,6),
                    pkgHeight DECIMAL(20,6),
                    pkgRatio DECIMAL(20,6),
                    pkgUnit VARCHAR(40),
                    pkgWeight DECIMAL(20,6),
                    pkgVolume DECIMAL(20,6))
    INSERT INTO @item(itemNo,packageId,itemLong,itemWidth,itemHeight,itemVolume,itemWeight,pkgLong,pkgWidth,pkgHeight,pkgRatio,pkgUnit, pkgWeight,pkgVolume) 
    SELECT @toItemNo,a.packageId, itemLong,itemWidth,itemHeight,a.itemVolume,a.itemWeight,a.pkgLong,a.pkgWidth,a.pkgHeight,a.pkgRatio,pkgUnit,pkgWeight ,pkgVolume
    FROM BAS_Item a
    WHERE a.itemNo=@fromItemNo;

    UPDATE a SET a.itemWidth=b.itemWidth,a.itemHeight=b.itemHeight,a.itemLong=b.itemLong,a.itemVolume =b.itemVolume,
        a.itemWeight=b.itemWeight,a.pkgRatio=b.pkgRatio,a.pkgVolume =b.pkgVolume,a.pkgWeight =b.pkgWeight , 
        a.pkgUnit=b.pkgUnit,a.pkgLong=b.pkgLong,a.pkgWidth =b.pkgWidth,a.pkgHeight=b.pkgHeight,
        a.packageId =b.packageId          
    FROM BAS_Item a 
        INNER JOIN @item b ON a.itemNo=b.itemNo
END
go

