

/*==============================================================*/
/* View: API_PD_BS  盘亏主表                                                 */
/* @editor:张东彦 @at:07/09/2020 12:07:11     @content:添加仓库编码返回 */
/*==============================================================*/
CREATE VIEW  [dbo].[API_PD_PS_HZ]
AS
SELECT  a.adjustNo AS PKID,b.YEZ_ID,b.ownerId,a.companyId,a.warehouseId,a.adjustReason AS pdReason,a.adjustDate  AS docdate,a.auditTime,a.pointId,A.memo  comment,
        c.pointNo PD_NO, 0 AS PD_FLAG ,WH.warehouseNo AS WHNO 
FROM IMS_Adjust A  
INNER JOIN (SELECT PKID,ownerId,YEZ_ID FROM   API_PD_PS GROUP BY PKID,ownerId,YEZ_ID) B
ON A.adjustNo=B.PKID
LEFT JOIN  IMS_CheckPoint  C ON A.pointId=C.pointId
LEFT JOIN  BAS_Warehouse  WH ON a.warehouseId=WH.warehouseId

go

