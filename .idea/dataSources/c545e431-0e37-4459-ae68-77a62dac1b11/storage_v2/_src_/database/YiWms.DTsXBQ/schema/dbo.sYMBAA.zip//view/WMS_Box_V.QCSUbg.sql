
/*==============================================================*/
/* View: WMS_Box_V                                              */
/*==============================================================*/
-- Author:<Frank.He>
-- Create date: <2016-09-03>
-- Description:<周转箱/托盘视图>
create view WMS_Box_V as
SELECT b.boxId,b.companyId,b.sizeId,bs.sizeNo,bs.sizeName,b.boxCode,bs.boxLength,bs.boxWidth,bs.boxHeight,
    bs.boxVolume,bs.boxBearing, bs.boxType,b.boxState, CASE b.boxState WHEN 1 THEN '可用' ELSE '损坏' END AS stateName,
    b.isFrozen,CASE b.isFrozen WHEN 1 THEN '是' ELSE '否' END as frozenState,b.isLocked,b.lockerId,
    u1.userNick AS lockerName,CONVERT(VARCHAR(20),b.lockedTime,120) AS lockedTime,b.createTime, 
    b.creatorId,u2.userNick AS creatorName,b.editTime,b.editorId,u3.userNick AS editorName,b.isSelected
FROM dbo.WMS_Box b 
	INNER JOIN dbo.WMS_BoxSize bs ON b.sizeId=bs.sizeId 
	LEFT JOIN dbo.SAM_User u1 ON b.lockerId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON b.creatorId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON b.editorId=u3.userId
go

