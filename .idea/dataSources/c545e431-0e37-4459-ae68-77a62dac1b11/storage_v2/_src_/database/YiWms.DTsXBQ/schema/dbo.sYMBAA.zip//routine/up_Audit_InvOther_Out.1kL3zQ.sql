
-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-02-06>
-- Description:	<Description:其他出库单审核                         
--  操作影响商品库存(BAS_Item表onhandQty)
--          仓库库存(IMS_Ledger表的onhandQty)，成本处理忽略不计
--          库位库存(IMS_Stock表) 
--          入出库流水帐(IMS_Book)
-- =============================================

CREATE PROCEDURE [dbo].[up_Audit_InvOther_Out]
(
    @otherNo VARCHAR(32),		--出库单号
	@operatorId VARCHAR(32)		--操作员
)
AS
BEGIN	
			
	DECLARE @companyId VARCHAR(32),		--公司Id
			@billNo VARCHAR(32),		--出库单号
			@warehouseId VARCHAR(32),	--仓库Id
			@objId VARCHAR(32),			--出库对象Id
			@createTime DATETIME,		--制单时间
			@creatorId VARCHAR(32),		--制单人Id
			@handlerId VARCHAR(32),		--经办人Id
			@deptId VARCHAR(32),		--经办部门Id
			@memo VARCHAR(2000),		--主表备注
			@ioType VARCHAR(32),		--入出库类
			@taxFlag INT,				--是否含税（默认含税）
			@otherId VARCHAR(32),		--明细Id
			@eId VARCHAR(32),			--主商品Id
			@itemId VARCHAR(32),		--SkuId			
			@ioQty DECIMAL(20,6),		--数量
			@befPrice DECIMAL(20,10),	--折前价
			@discount DECIMAL(6,2),		--折扣
			@discountFee DECIMAL(6,2),	--折扣金额
			@price DECIMAL(20,10),		--单价（折扣后）
			@taxrate DECIMAL(6,2),		--税率
			@fee DECIMAL(20,10),		--金额（不含税）
			@taxFee DECIMAL(20,10),		--税额
			@totalFee DECIMAL(20,10),	--金额（含税）
			@lotNo VARCHAR(32),			--批次号
			@regionId VARCHAR(32),		--库区
			@locationNo VARCHAR(32)		--库位	
					
	--此处可用于计算成本
	DECLARE @befQty DECIMAL(20,6),			--出入库前数量			
			@afterQty DECIMAL(20,6),		--出入库后数量			
			@auditTime DATETIME				--审核时间
	--审核时间
	SET @auditTime=GETDATE();
	BEGIN TRY
		BEGIN TRANSACTION
		--主表信息		
		SELECT @billNo=billNo,@companyId=companyId,@warehouseId=warehouseId,@objId=objId,@ioType=ioType,
			@taxFlag=1,@createTime=createTime,@creatorId=creatorId,@handlerId=handlerId,@deptId=deptId,@memo=memo
		FROM IMS_Other 
		WHERE otherNo=@otherNo
		
		--处理明细数据
		DECLARE myCursor CURSOR
		FOR SELECT otherId,eId,itemId,lotNo,locationNo,-ioQty,price,taxrate,-fee,-taxFee,-totalFee
			FROM IMS_OtherDetail
			WHERE otherNo=@otherNo
			ORDER BY viewOrder		 
		OPEN myCursor
		FETCH NEXT FROM myCursor INTO @otherId,@eId,@itemId,@lotNo,@locationNo,@ioQty,@price,@taxrate,@fee,@taxFee,@totalFee
		WHILE @@FETCH_STATUS=0
		BEGIN
			--库区
			SELECT @regionId=regionId 
			FROM BAS_Location 
			WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@locationNo;			
			--处理商品库存
			UPDATE BAS_Item SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty WHERE itemId=@itemId;						
			--入库前数量
			SELECT @befQty=ISNULL(onhandQty,0.0)
			FROM IMS_Ledger
			WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
			--入出库后数量与金额
			SET @afterQty=ISNULL(@befQty,0.0)+ISNULL(@ioQty,0.0);
			--处理IMS_Ledger表,如果表中没有数据，则新增一条记录
			IF EXISTS(SELECT 1 FROM IMS_Ledger WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId)
				UPDATE IMS_Ledger SET onhandQty=@afterQty,lastITime=@auditTime
				WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
			ELSE
				INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastITime)
				VALUES(REPLACE(NEWID(),'-',''),@companyId,@warehouseId,@eId,@itemId,@afterQty,0.0,@auditTime);
			
			--入库前数量（用于流水帐）
			SELECT @befQty=ISNULL(onhandQty,0.0)
			FROM IMS_Stock
			WHERE companyId=@companyId AND warehouseId=@warehouseId 
				AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') 
				AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') 
				AND itemId=@itemId;
			--入出库后数量与金额
			SET @afterQty=ISNULL(@befQty,0.0)+ISNULL(@ioQty,0.0);			
			--处理IMS_Stock表(如果表中没有数据，则直接新增一条)
			IF EXISTS(SELECT 1 FROM IMS_Stock WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId)
				UPDATE IMS_Stock SET onhandQty=@afterQty,
				                     lastITime=@auditTime
				WHERE companyId=@companyId AND warehouseId=@warehouseId 
					AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') 
					AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') 
					AND itemId=@itemId;
			ELSE
				INSERT INTO IMS_Stock(stockId,companyId,warehouseId,regionId,locationNo,lotNo,eId,itemId,onhandQty,allocQty,lastITime)
				VALUES(REPLACE(NEWID(),'-',''),@companyId,@warehouseId,@regionId,@locationNo,@lotNo,@eId,@itemId,@afterQty,0.0,@auditTime);
		
			--处理IMS_Book表
			INSERT INTO IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,
				eId,itemId,befQty,taxFlag,taxrate,befPrice,discount,discountFee,ioQty,price,fee,taxFee,totalFee,afterQty,
				handlerId,deptId,createTime,creatorId,auditTime,auditorId,memo)
			VALUES(REPLACE(NEWID(),'-',''),@ioType,@companyId,@otherId,@otherNo,@billNo,@objId,@warehouseId,ISNULL(@lotNo,''),ISNULL(@locationNo,''),
			    @eId,@itemId,@befQty,@taxFlag,@taxrate,@price,100.0,0.0,@ioQty,@price,@fee,@taxFee,@totalFee,@afterQty,
			    @handlerId,@deptId,@createTime,@creatorId,@auditTime,@operatorId,@memo);
			FETCH NEXT FROM myCursor INTO @otherId,@eId,@itemId,@lotNo,@locationNo,@ioQty,@price,@taxrate,@fee,@taxFee,@totalFee
		END
		CLOSE myCursor
		DEALLOCATE myCursor
		--更新状态
		UPDATE IMS_Other SET ioState=20,editTime=@auditTime,editorId=@operatorId,auditTime=@auditTime,auditorId=@operatorId 
		WHERE otherNo=@otherNo
		COMMIT
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END CATCH
END
go

