
/*==============================================================*/
/* View: XTRK_HZ         Script Date: 07/13/2020 14:42:54  zdy                                         */
/*==============================================================*/
CREATE view [dbo].[API_XTRK_HZ] as
SELECT a.returnNo AS PKID,a.companyId,a.ownerId,w.warehouseId,o.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,a.thirdPartyNo AS SHANGJ_DANJ_NO,c.customerNo AS CARDCODE,
	CONVERT(VARCHAR(10),a.auditTime,23) AS docdate,w.warehouseNo AS whNo,
	CASE WHEN LEN(ISNULL(a.reason,''))>0 THEN '退货原因:'+a.reason+',备注:'+a.memo else a.memo END  AS comments,u.userNo AS U_opcode,u.userNick AS U_OPNAME,0 AS discprcnt,
	CASE a.orderType WHEN 10 THEN '销售退货' 
                     WHEN 20 THEN '调拨申请' 
                     WHEN 30 THEN '经营退货' 
                     WHEN 31 THEN '管理退货' 
                     WHEN 40 THEN '赠品退货' 
                     WHEN 50 THEN '报损报废' else '销售退货' END AS orderTypeName,a.orderType,
	thirdSyncFlag AS SC_FLG,a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5
FROM dbo.SAD_Return a INNER JOIN
      dbo.BAS_Customer_V c ON a.customerId=c.customerId INNER JOIN
      dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId LEFT JOIN
      dbo.BAS_Owner_V o ON a.ownerId=o.ownerId LEFT JOIN 
      dbo.SAM_User u ON a.creatorId=u.userId 
WHERE (a.ioState=30) AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2)

go

