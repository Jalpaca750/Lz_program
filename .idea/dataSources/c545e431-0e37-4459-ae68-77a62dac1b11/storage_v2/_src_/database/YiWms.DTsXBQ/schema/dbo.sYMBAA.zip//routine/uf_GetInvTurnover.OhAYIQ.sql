-- =============================================
-- Author:		<Frank.He>
-- Create date: <2017-03-02>
-- Description:	<计算库存周转率与周转天数>
--      计算周期内销售数据为0或者平均存货余额为0时另行考虑
--		Frank.He review V1.2 2017-11-04
-- =============================================
CREATE FUNCTION [dbo].[uf_GetInvTurnover]
(
    @companyId VARCHAR(32),				        --公司Id
	@warehouseId VARCHAR(32),					--仓库Id
	@startTime DATETIME,						--起始日期
	@endTime DATETIME							--截止日期
)
RETURNS @result TABLE
(
	warehouseId VARCHAR(32),
	warehouseNo VARCHAR(32),
	warehouseName VARCHAR(200),
	ownerId VARCHAR(32),
	ownerNo VARCHAR(32),
	ownerName VARCHAR(200),
	ownerShortName VARCHAR(200),
	itemId VARCHAR(32),
	itemNo VARCHAR(32),
	itemName varchar(200),
    itemCTitle varchar(200),
    itemETitle varchar(200),
    itemSpec varchar(100),
    itemSpell varchar(200),
    sellingPoint varchar(200),
	barcode varchar(100),
	midBarcode varchar(100),
	bigBarcode varchar(100),
	pkgBarcode varchar(100),
	packageId VARCHAR(32),
    brandId varchar(32),
    brandNo varchar(32),
    brandCName varchar(200),
	categoryId varchar(32),
	categoryNo varchar(32),
	categoryCName varchar(200),
	colorName varchar(100),
	sizeName varchar(100),
	unitName varchar(100),
	pkgUnit varchar(100),
	pkgRatio int,
	inventoryMode int,
	isSafety int,
	safetyMonth int,
	safetyDays int,
	qcQty DECIMAL(20,6),
	xsQty DECIMAL(20,6),
	qmQty DECIMAL(20,6),
	zzRate DECIMAL(10,4),
	zzDays DECIMAL(10,4)
	PRIMARY KEY(warehouseId,itemId)
)
AS
BEGIN
	DECLARE @days INT
	--计算期天数
	SET @days=DATEDIFF(d,@startTime,@endTime)+1;	
	--临时存储表
	DECLARE @tmpInv Table(warehouseId VARCHAR(32),itemId VARCHAR(32),qcQty DECIMAL(20,6),xsQty DECIMAL(20,6),qmQty DECIMAL(20,6));
	--计算表
	DECLARE @Inv Table(warehouseId VARCHAR(32),itemId VARCHAR(32),qcQty DECIMAL(20,6),xsQty DECIMAL(20,6),qmQty DECIMAL(20,6),hjQty DECIMAL(20,6) PRIMARY KEY(warehouseId,itemId));
	--截止日期的库存
	INSERT INTO @tmpInv(warehouseId,itemId,qmQty)
	SELECT warehouseId,itemId,SUM(ioQty)
	FROM dbo.IMS_Book
	WHERE companyId=@companyId 
		AND warehouseId=@warehouseId 
		AND auditTime<=@endTime
	GROUP BY warehouseId,itemId;	
	--起始日期的库存
	INSERT INTO @tmpInv(warehouseId,itemId,qcQty)
	SELECT warehouseId,itemId,SUM(ioQty)
	FROM dbo.IMS_Book
	WHERE companyId=@companyId 
		AND warehouseId=@warehouseId 
		AND auditTime<@startTime
	GROUP BY warehouseId,itemId;
	--本月销售数据（包含退货）	
	INSERT INTO @tmpInv(warehouseId,itemId,xsQty)
	SELECT warehouseId,itemId,SUM(-ISNULL(ioQty,0.0))
	FROM dbo.IMS_Book
	WHERE companyId=@companyId 
		AND warehouseId=@warehouseId 
		AND (auditTime BETWEEN @startTime AND @endTime) 
		AND (ioType='S100' OR ioType='S200')
	GROUP BY warehouseId,itemId;
	--汇总
	INSERT INTO @Inv(warehouseId,itemId,qcQty,xsQty,qmQty,hjQty)
	SELECT warehouseId,itemId,SUM(qcQty) AS qcQty,SUM(xsQty) AS xsQty,SUM(qmQty) AS qmQty,SUM(ISNULL(qcQty,0.0)+ISNULL(qmQty,0.0))
	FROM @tmpInv
	GROUP BY warehouseId,itemId
	--计算
	INSERT INTO @result(warehouseId,warehouseNo,warehouseName,ownerId,ownerNo,ownerName,ownerShortName,    
		itemId,itemNo,itemName,itemCTitle,itemETitle,sellingPoint,itemSpec,itemSpell,barcode,midBarcode,
		bigBarcode,pkgBarcode,packageId,brandId,brandNo,brandCName,categoryId,categoryNo,categoryCName,
		colorName,sizeName,unitName,pkgUnit,pkgRatio,inventoryMode,isSafety,safetyMonth,safetyDays,qcQty,
		qmQty,xsQty,zzRate,zzDays)
	SELECT a.warehouseId,w.warehouseNo,w.warehouseName,bi.ownerId,p.partnerNo,p.partnerName,p.shortName,
		a.itemId,bi.itemNo,bi.itemName,bi.itemCTitle,bi.itemETitle,bi.sellingPoint,bi.itemSpec,bi.itemSpell,
		bi.barcode,bi.midBarcode,bi.bigBarcode,bi.pkgBarcode,bi.packageId,bi.brandId,bi.brandNo,bi.brandCName,
		bi.categoryId,bi.categoryNo,bi.categoryCName,bi.colorName,bi.sizeName,bi.unitName,bi.pkgUnit,bi.pkgRatio,
		bi.inventoryMode,bi.isSafety,bi.safetyMonth,bi.safetyDays,ISNULL(a.qcQty,0.0),ISNULL(a.qmQty,0.0),
		ISNULL(a.xsQty,0.0),CASE ISNULL(hjQty,0.0) WHEN 0.0 THEN 0.0
							   ELSE ROUND(ISNULL(xsQty,0.0)/(ISNULL(hjQty,0.0)/2),4) END AS zzRate,
		CASE ISNULL(xsQty,0.0) WHEN 0.0 THEN 0.0
							   ELSE ROUND((ISNULL(hjQty,0.0)/2)/ISNULL(xsQty,0.0)*@days,4) END AS ZZDays
	FROM @Inv a 
		INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
		INNER JOIN dbo.BAS_Goods_V bi ON a.itemId=bi.itemId
		INNER JOIN dbo.BAS_Partner p ON bi.ownerId=p.partnerId
	RETURN;
END
go

