CREATE PROCEDURE [dbo].[up_ReceiptRollBack]
(
	@companyId VARCHAR(32),			--公司Id
	@stockNo VARCHAR(32),			--出单Id
	@billNo VARCHAR(32),			--出库单编号
	@operatorId VARCHAR(32)			--操作员Id
)
AS
BEGIN
    DECLARE @curTime DATETIME,@waybillId VARCHAR(32)
    SET @curTime=GETDATE();    
    --获取出库单对应运单Id           
    SELECT @waybillId=waybillId
	FROM dbo.TMS_WayBill
	WHERE companyId=@companyId AND waybillNo=@billNo AND wmsStockNo=@stockNo;
	--删除错误日志
    DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='up_ReceiptRollBack' AND billId=@stockNo;
	BEGIN TRY
		BEGIN TRANSACTION		
        --更新出库单(更新到已发货状态）
		UPDATE dbo.SAD_Stock SET taskState=90,isReceipt=0,backerId='',receiptTime=NULL,editTime=@curTime,editorId=@operatorId 
		WHERE stockNo=@stockNo AND taskState>90; 
		IF(@@ROWCOUNT>0)
		BEGIN
			--更新F10出库单状态
			UPDATE F10BMS.dbo.SMS_Stock SET BackDate='' WHERE StockNo=@billNo; 
		END	
        --更新运单为已派件（还原到派件状态）30-派送中
	    UPDATE dbo.TMS_WayBill SET billState=30 WHERE waybillId=@waybillId;
	    --删除运单其他状态(还原到40状态）
	    DELETE FROM TMS_WaySite WHERE waybillId=@waybillId AND wayState>40;
	    COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_ReceiptRollBack','YI_RETURN_BILL_ROLL_BACK_ERROR',LEFT(@ErrMsg,2000),@stockNo,@billNo);		
		RAISERROR(@ErrMsg, @ErrSeverity, 1);			
	END CATCH
END
go

