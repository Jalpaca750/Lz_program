
/*==============================================================*/
/* View: TMS_ReasonType_V                                       */
/*==============================================================*/
create view TMS_ReasonType_V as
SELECT a.typeId,a.typeNo,a.typeName,a.companyId,a.exType01,a.exType02,a.exType03,a.exType04,a.exType05,
   a.isLocked,a.lockerId,u1.userNick as lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) as lockedTime,
   a.createTime,a.creatorId,u2.userNick as creatorName,a.editTime,a.editorId,u3.userNick as editorName,
   a.isSelected
FROM TMS_ReasonType a
   LEFT JOIN dbo.SAM_User u1 on  a.lockerId = u1.userId
   LEFT JOIN dbo.SAM_User u2 on  a.creatorId = u2.userId
   LEFT JOIN dbo.SAM_User u3 on  a.editorId = u3.userId
go

