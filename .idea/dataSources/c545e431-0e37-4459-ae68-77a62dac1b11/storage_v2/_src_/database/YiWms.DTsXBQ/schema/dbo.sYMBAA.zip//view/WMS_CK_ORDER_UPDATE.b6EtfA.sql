CREATE VIEW WMS_CK_ORDER_UPDATE 
AS 
SELECT  billNo,thirdSyncFlag SC_FLG,thirdSyncTime SC_FLAG_TIME  
FROM  SAD_Order  WHERE  thirdSyncFlag IN (0,2)
go

