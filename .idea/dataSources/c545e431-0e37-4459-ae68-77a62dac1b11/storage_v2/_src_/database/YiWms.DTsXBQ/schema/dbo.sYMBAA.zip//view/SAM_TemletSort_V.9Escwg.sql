
/*==============================================================*/
/* View: SAM_TemletSort_V                                       */
/*==============================================================*/
create view SAM_TemletSort_V as
SELECT ts.sortId,ts.templetCode,t.templetName,ts.formName,ts.fieldCode,ts.fieldName,
    ts.sorted,ts.sortMode,CASE ts.sortMode WHEN 0 THEN 'ASC' ELSE 'DESC' END AS sortModeDesc,
    ts.isLocked,ts.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),ts.lockedTime,120) AS lockedTime,
    ts.createTime,ts.creatorId,u2.userNick AS creatorName,ts.editTime,ts.editorId,u3.userNick AS editorName
FROM SAM_TempletSort ts
    INNER JOIN SAM_Templet t ON ts.templetCode=t.templetCode
    LEFT JOIN SAM_User u1 ON ts.lockerId=u1.userId
    LEFT JOIN SAM_User u2 ON ts.creatorId=u2.userId
    LEFT JOIN SAM_User u3 ON ts.editorId=u3.userId
go

