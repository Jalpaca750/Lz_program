-- =============================================
-- Author:		<Frank.He>
-- Create date: <2017-07-04>
-- Description:	<获取需要打包商品的外箱(纸箱）规格>
-- Parameter:   
--      @companyId—公司Id
--      @volumn—体积
--      @weight—重量
-- =============================================

CREATE FUNCTION [dbo].[uf_GetOutsideBox]
(
	@companyId VARCHAR(32),		--公司Id
	@volumn DECIMAL(20,6),		--体积
	@weight DECIMAL(10,3)		--重量
)
RETURNS VARCHAR(32)
AS
BEGIN
	DECLARE @sizeId VARCHAR(32);
	SET @sizeId='';
	SELECT Top 1 @sizeId=sizeId
	FROM WMS_BoxSize
	WHERE companyId=@companyId AND boxType=2 AND boxVolume>=@volumn AND boxBearing>=@weight
	ORDER BY boxVolume;
	--当取不到合适的箱子时取最大箱
	IF ISNULL(@sizeId,'')=''
		SELECT Top 1 @sizeId=sizeId
		FROM WMS_BoxSize
		WHERE companyId=@companyId AND boxType=2
		ORDER BY boxVolume DESC,boxBearing DESC;
	RETURN ISNULL(@sizeId,'');
END
go

