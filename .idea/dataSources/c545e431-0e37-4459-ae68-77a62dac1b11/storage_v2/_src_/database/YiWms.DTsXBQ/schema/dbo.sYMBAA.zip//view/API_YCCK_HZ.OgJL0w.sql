
/*==============================================================*/
/* View: YCCK_HZ                                                */
/* create at:2020-07-09 zdy  接口移仓视图主表                  */
/*==============================================================*/
CREATE view [dbo].[API_YCCK_HZ] as
SELECT a.transferNo AS PKID,c.OwnerId,a.CompanyId,c.ownerNo AS YEZ_ID,c.ownerName AS YEZ_NAME,
   a.billNo AS DANJ_NO,CONVERT(VARCHAR(20),a.auditTime,120) AS docdate,w1.warehouseNo AS WhsCode,
      w2.warehouseNo AS TO_WhsCode,u1.userNo AS operatorNo,a.thirdSyncFlag AS SC_FLG,
      a.memo AS comments,a.auditTime
FROM dbo.IMS_Transfer a INNER JOIN 
      (
			SELECT  b.transferNo,item.ownerId FROM IMS_TransferDetail b 
			INNER JOIN BAS_Item  item WITH(NOLOCK) ON b.itemId=item.itemId
			group by b.transferNo,item.ownerId
       ) _dtl  ON  A.transferNo=_dtl.transferNo   INNER JOIN 
      BAS_Owner_V  c on _dtl.ownerId=c.ownerId INNER JOIN
      dbo.BAS_Warehouse w1 ON a.outputId=w1.warehouseId INNER JOIN
      dbo.BAS_Warehouse w2 ON a.inputId=w2.warehouseId LEFT JOIN
      dbo.SAM_User u1 ON a.creatorId=u1.userId
WHERE (a.ioState=2) AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2) 
      AND  w1.warehouseId<>w2.warehouseId

go

