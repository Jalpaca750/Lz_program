



--3.修改调整单（其他入出库）同步视图，单据状态从20改为10
/*==============================================================*/
/* View: WMS_F10_IMS_Adjust_V                                   */
/*==============================================================*/
CREATE VIEW [dbo].[WMS_F10_IMS_Adjust_V] as
SELECT a.adjustNo AS wmsStock,billNo AS wmsBillNo,billNo AS otherNo,CONVERT(VARCHAR(10),a.adjustDate,23) AS createDate,
	w.deptNo,w.warehouse AS warehouse,50 AS billType,'40' AS IOObject,'10' AS billSts,0 AS pFlag,
	CONVERT(VARCHAR(10),a.auditTime,23) AS auditDate,u2.employeeID AS auditId,u1.employeeID AS creatorId,
	NULL AS printerId,0 AS printNum,GETDATE() AS editTime,1 AS syncFlag,'WMS系统盘点调整单:'+a.billNo AS memo,
	a.memo AS remarks,a.pointId,p.pointNo 
FROM dbo.IMS_Adjust a
	LEFT JOIN F10BMS.dbo.WMS_F10_Warehouse_V w ON a.warehouseId=w.warehouseId
	LEFT JOIN dbo.IMS_CheckPoint p ON a.pointId=p.pointId 
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u1 ON a.creatorId=u1.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u2 ON a.auditorId=u2.userId
WHERE (a.thirdSyncFlag=0)
	AND (a.ioState=20)
go

