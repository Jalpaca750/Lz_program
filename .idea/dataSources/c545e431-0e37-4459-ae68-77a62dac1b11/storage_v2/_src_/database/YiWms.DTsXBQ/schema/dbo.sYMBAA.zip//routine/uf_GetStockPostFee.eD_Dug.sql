--修改运费获取函数
CREATE FUNCTION [dbo].[uf_GetStockPostFee]
(
    @stockNo VARCHAR(32),                       --出库单No
    @logisticsId VARCHAR(32)                    --物流公司Id
)
RETURNS DECIMAL(20,2)
AS
BEGIN
    DECLARE @result DECIMAL(20,2);              --返回运费
    SET @result=0.00;
    DECLARE @companyId VARCHAR(32),             --公司Id    
            @warehouseId VARCHAR(32),           --始发仓库Id
            @areaId VARCHAR(32),                --目的省市Id
            @receiverAddress VARCHAR(200),      --目的地址
            @totalWeight DECIMAL(10,4),         --出库单重量
            @count INT,
            @i INT;
    DECLARE @tmpArea TABLE(viewOrder INT IDENTITY(1,1),areaId VARCHAR(32),areaName VARCHAR(100),parentId VARCHAR(32),areaType INT);        
    --取得单据始发仓库，地址与物流公司
    SELECT @companyId=companyId,@receiverAddress=receiverAddress,@warehouseId=warehouseId
    FROM dbo.SAD_Stock
    WHERE stockNo=@stockNo;
    --统计出库单发货重量
    SELECT @totalWeight=SUM(pickQty*b.itemWeight) 
    FROM dbo.SAD_StockDetail a
        INNER JOIN dbo.BAS_Item b ON a.itemId=b.itemId
    WHERE stockNo=@stockNo;    
    INSERT INTO @tmpArea(areaId,areaName,areaType,parentId)
    SELECT areaId,areaName,areaType,parentId
    FROM BAS_Area
    WHERE CHARINDEX(areaName,@receiverAddress)>0 OR CHARINDEX(@receiverAddress,areaName)>0;
    SELECT @i=1,@count=COUNT(*) FROM @tmpArea;
    WHILE (@i<=@count)
    BEGIN
        SELECT @areaId=areaId FROM @tmpArea WHERE viewOrder=@i;
        IF (LEN(@areaId)>3)
        BEGIN
            IF NOT EXISTS(SELECT * FROM @tmpArea WHERE areaId=SUBSTRING(@areaId,1,LEN(@areaId)-2))
                DELETE FROM @tmpArea WHERE areaId=@areaId;
        END
        SET @i=@i+1;
    END
    --如果找到目的地址对应的省市
    IF (EXISTS(SELECT * FROM @tmpArea))
    BEGIN
        --取得物流始发地址对应省市
        SELECT TOP 1 @areaId=areaId
        FROM @tmpArea
        ORDER BY areaId;
        SELECT @result=dbo.uf_GetPostFee(@companyId,@warehouseId,@logisticsId,@areaId,@totalWeight);
    END
    RETURN @result;
END
go

