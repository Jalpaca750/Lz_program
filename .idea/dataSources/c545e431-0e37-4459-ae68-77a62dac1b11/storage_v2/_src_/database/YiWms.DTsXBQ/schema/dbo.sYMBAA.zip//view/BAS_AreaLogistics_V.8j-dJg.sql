
/*==============================================================*/
/* View: BAS_AreaLogistics_V                                    */
/*==============================================================*/
create view BAS_AreaLogistics_V as
SELECT a.policyId,a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,a.areaId,
    a1.areaName,a.logisticsId,l1.logisticsCode,l1.logisticsName,a.firstWeight,a.firstFee,
    a.increaseWeight,a.increaseFee,a.addressKey,a.exLogisticsId,l2.logisticsCode AS exlogisticsCode,
    l2.logisticsName AS exlogisticsName,a.exfirstWeight,a.exfirstFee,a.exIncreaseWeight,
    a.exIncreaseFee,a.isDefault,a.isLocked,a.lockerId,u1.userNick AS lockerName,
    CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,a.creatorId,
    u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName
FROM dbo.BAS_AreaLogistics a
    INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
    INNER JOIN dbo.BAS_Area a1 ON a.areaId=a1.areaId
    INNER JOIN dbo.BAS_Logistics l1 ON a.logisticsId=l1.logisticsId
    LEFT JOIN dbo.BAS_Logistics l2 ON a.exLogisticsId=l2.logisticsId
    LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId
    LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId
    LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId
go

