-- =============================================
-- Author:		<Author: W.J>
-- Create date: <Create Date:2016-12-23>
-- Description:	<Description:作业同步快递应发消息>
CREATE PROCEDURE [dbo].[up_SyncWMSToBoneMessage] 

AS
BEGIN
	DECLARE @companyId VARCHAR(32)='31B75DF1CC084914AEAF09EA2C60F77B'----Bone公司ID
	DECLARE @billType VARCHAR(32)='AIL_MESSEGE'                      ----固定值
	DECLARE @singName VARCHAR(32)='谊风信息'                         ----阿里短信签名
	DECLARE @TempletCode VARCHAR(32)='SMS_185210597'                 ----阿里短信模版
	DECLARE @creatorId VARCHAR(32)='dc83582f5d204c6a95a049480e1a4841'----Bone创建人ID

	DECLARE @Errors BIGINT=0;
	
	DECLARE @tempTable TABLE (expressId VARCHAR(32),expressNo VARCHAR(50),logisticsName NVARCHAR(50),receiverTel VARCHAR(32))
	-----写入表变量------
	INSERT INTO @tempTable(expressId, expressNo, logisticsName, receiverTel)
	SELECT a.expressId,a.billNo,c.logisticsName,b.receiverTel
	  FROM SAD_LogisticsDetail a
	INNER JOIN SAD_Logistics b ON a.expressNo=b.expressNo
	INNER JOIN BAS_Logistics c ON b.logisticsId=c.logisticsId
	WHERE LEN(b.receiverTel)=11 AND CHARINDEX(b.receiverTel,'-')<1 
	AND ISNULL(SyncFlag,0)=0 AND len(isnull(a.Field3,''))>0
	SET @Errors=@Errors+@@ERROR;
	
	------写入Bone数据库-----

	IF EXISTS(SELECT 1 FROM @tempTable)
		BEGIN
			INSERT INTO BoneDB.[Bone].[dbo].[SAM_Message]([messageId],[companyId],[messageSource],[messageType],[billNo],[billType],[billDescription],[messageTitle],[messageText],[toAddress],[state],[creatorId],[createTime],[editorId],[editTime])
			SELECT REPLACE(NEWID(),'-',''),@companyId,3,3,expressId,@billType,@singName,@TempletCode,'{"logisticsname":"'+logisticsName+'","expressno":"'+expressNo+'"}',receiverTel,0,@creatorId,getdate(),@creatorId,getdate() FROM @tempTable
			SET @Errors=@Errors+@@ERROR;
		END
	IF(@Errors=0)
	BEGIN
		IF EXISTS(SELECT 1 FROM @tempTable)
		BEGIN
			----更新
			UPDATE a SET SyncFlag=1,SyncTime=GETDATE() FROM SAD_LogisticsDetail a
			INNER JOIN @tempTable b ON a.expressId=b.expressId
		END

	END
END

go

