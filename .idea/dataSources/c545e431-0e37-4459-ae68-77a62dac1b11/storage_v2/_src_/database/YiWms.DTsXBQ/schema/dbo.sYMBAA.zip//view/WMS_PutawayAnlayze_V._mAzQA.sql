/*==============================================================*/
/* View: WMS_PutawayAnlayze_V                                   */
/*==============================================================*/
--creator：     Frank
--create time:  2017-05-07
--Description: 采购上架跟踪分析
CREATE view [dbo].[WMS_PutawayAnlayze_V] as
SELECT b.flowId,a.putawayNo,a.billType,a.billNo,b.stockId,b.stockNo,a.partnerId,p.partnerNo,p.partnerName,
      CASE a.billType WHEN 'S200' THEN '销售退货上架' 
                      WHEN 'P100' THEN '采购入库上架' 
                      WHEN 'D100' THEN '调拨入库上架'
                      WHEN 'G100' THEN '赠品入库上架'
                      WHEN 'O200' THEN '其他入库上架' END AS billTypeDesc,
      a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,a.regionId,r.regionNo,r.regionDesc,a.ioState,
      CASE a.ioState WHEN 20 THEN '待上架' WHEN 25 THEN '部分上架' WHEN 30 THEN '全部上架' END AS stateName,
      a.lockerId,u3.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,      
      b.viewOrder,b.lotNo,b.locationNo,b.itemId,bi.itemNo,bi.itemName,bi.itemCTitle,bi.itemETitle,
      bi.itemSpec,bi.itemSpell,bi.barcode,bi.midBarcode,bi.bigBarcode,bi.pkgBarcode,bi.sizeName,bi.colorName,
      bi.unitName,CASE b.unitLevel WHEN 'EA' THEN b.putQty ELSE putQty*b.pkgRatio END AS putawayQty,b.putQty,
      b.pkgRatio,b.ioState AS dtlState,CASE b.ioState WHEN 20 THEN '待上架' WHEN 30 THEN '已上架' END AS dtlStateName,
      b.putawayId,u1.userNick AS putawayName,CONVERT(VARCHAR(20),b.putawayTime,120) AS putawayTime,
      a.creatorId,u2.userNick AS creatorName,a.createTime
FROM dbo.WMS_Putaway a
      INNER JOIN dbo.WMS_PutawayDetail b ON a.putawayNo=b.putawayNo
      INNER JOIN dbo.BAS_Item bi ON b.itemId=bi.itemId
      INNER JOIN dbo.BAS_Partner p ON a.partnerId=p.partnerId
      INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
      LEFT JOIN dbo.BAS_Region r ON a.regionId=r.regionId
      LEFT JOIN dbo.SAM_User u1 ON b.putawayId=u1.userId
      LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId
      LEFT JOIN dbo.SAM_User u3 ON a.lockerId=u3.userId
go

