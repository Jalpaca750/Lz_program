/***************************配合F10BMS V2.0升级 升级脚本***************************/
/*    1.修改销售出库单同步视图，单据状态从20改为10                                */
/*    2.修改采购入库单同步视图，单据状态从20改为10                                */
/*    3.修改调整单（其他入出库）同步视图，单据状态从20改为10                      */
/*    4.修改其他入出库（赠品，调拨，其他入出库等）同步视图，单据状态改为10        */
/*    5.修改销售退货同步视图，增加仓库字段                                        */
/*    6.修改其他出库单（赠品，调拨，其他入出库等）同步视图，单据状态改为10        */
/*    7.修改采购退货同步视图，单据状态从20改为10                                  */
/*    8.修改包装材料同步视图，单据状态从20改为10，取消某些固定参数                */
/*    9.增加品牌，盘点时刻表对应同步视图                                          */
/***************************配合F10BMS V2.0升级 升级脚本***************************/





--1.修改销售出库单同步视图，单据状态从20改为10
/*==============================================================*/
/* View: WMS_F10_SMS_Stock_V                                    */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_SMS_Stock_V] as
SELECT a.stockNo AS wmsStock,a.billNo AS stockBillNo,a.billNo AS stockNo,CONVERT(VARCHAR(10),a.createTime,23) AS createDate,
	d.CodeID AS DeptNo,w.warehouseNo AS warehouse,b.custId,'10' AS billType,a.handlerId AS CostsId,buyerId AS orderRenInfo,
	ISNULL(a1.areaName,'')+ISNULL(a2.areaName,'')+ISNULL(a3.areaName,'')+ISNULL(a.receiverAddress,'') AS sendAddr,
	a.receiverName AS LinkMan,RTRIM(ISNULL(a.receiverMobile,'') + ' ' + ISNULL(a.receiverTel,'')) AS Phone,
	s.settlementNo AS sendId,a.shipDate AS sendDate,a.shipTime AS SendTime,'10' AS billSts,a.receiptTime AS backDate,
	u4.employeeID AS PH_OperatorId,CONVERT(VARCHAR(20),a.pickingTime,120) AS PH_DateTime,a.logisticsId,a.postFee,
	a.arState AS paidUp,payFee AS paidAmt,0.0 AS discAmt,0 AS Integral,ISNULL(s1.f10Id,99) AS salesId,u1.employeeID AS auditId,
	CONVERT(VARCHAR(10),a.auditTime,23) AS auditDate,u2.employeeID AS CreatorId,a.aFlag,a.aStockNo,a.mergeNo,a.ordField2 AS boneOrdNo,
	a.printNum,u3.employeeID AS  printerId,'WMS系统出库单：' + a.billNo AS memo,a.memo AS remarks,a.poNo
	,li.CodeID
FROM dbo.SAD_Stock a
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	INNER JOIN F10BMS.dbo.WMS_F10_Customer_V b ON a.customerId=b.customerId
	LEFT JOIN F10BMS.dbo.WMS_F10_Department_V d ON a.deptId=d.deptId
	LEFT JOIN dbo.BAS_Area a1 ON a.receiverState=a1.areaId
	LEFT JOIN dbo.BAS_Area a2 ON a.receiverCity=a2.areaId
	LEFT JOIN dbo.BAS_Area a3 ON a.receiverDistrict=a3.areaId
	LEFT JOIN dbo.BAS_Settlement s ON a.settlementId=s.settlementId
	LEFT JOIN F10BMS.dbo.WMS_F10_Employee_V s1 ON a.salesId=s1.employeeId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u1 ON a.auditorId=u1.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u2 ON a.creatorId=u2.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u3 ON a.printId=u3.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u4 ON a.pickingId=u4.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_Line_V li ON a.lineId=li.lineId
WHERE (a.taskState>=60)									--复核过后
	AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2)		--待同步和同步出错的
	AND (a.orderType=10)								--销售订单
go

