-- =============================================
-- Author:		<Frank.He>
-- Create date: <2017-04-07>
-- Description:	<销售发货单跟踪分析>
--      WMS_PickingOrder表 任务状态:  
--                       -2-品项错误；
--                       -1-数量错误；
--                       0-待领取；
--                       1-待拣货；
--                       2-待复核；
--                       3-待打包；
--                       4--待装车；
--                       5-已装车-
--                       6已发货
--      SAD_Stock表任务状态
--		2017-12-19 与办公伙伴版本对拼箱的取值不同，注意 review v1.2 
-- =============================================
CREATE FUNCTION [dbo].[uf_GetDeliveryTracking] 
(
	@companyId VARCHAR(32)
)
RETURNS TABLE
RETURN(
	SELECT a.stockNo,a.companyId,a.ownerId,o.partnerNo AS ownerNo,o.partnerName AS ownerName,o.shortName AS ownerShortName,
		a.billNo,a.createTime,a.warehouseId,w.warehouseNo,w.warehouseName,a.ioType,
		CASE a.ioType WHEN 'S100' THEN '销售出库单' WHEN 'D200' THEN '调拨出库单' WHEN 'L100' THEN '领用出库单' WHEN 'O200' THEN '其他出库单' WHEN 'G200' THEN '赠品出库单' WHEN 'B200' THEN '报损出库单' END AS ioTypeName,
		a.customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,p.partnerSpell AS customerSpell,p.shortName,a.receiverState,
		ISNULL(a1.areaName,a.receiverState) AS receiverStateName,ISNULL(a2.areaName,a.receiverCity) AS receiverCityName,
		ISNULL(a3.areaName,a.receiverDistrict) AS receiverDistrictName,a.receiverAddress,
		ISNULL(a1.areaName,ISNULL(a.receiverState,''))+ISNULL(a2.areaName,ISNULL(a.receiverCity,''))+ISNULL(a3.areaName,ISNULL(a.receiverDistrict,''))+ISNULL(a.receiverAddress,'') AS fullAddress,
		a.lineId,l.lineName,a.groupId,a.receiverName,a.receiverTel,a.receiverMobile,LTRIM(ISNULL(a.receiverMobile,'')+' '+ISNULL(a.receiverTel,'')) AS fullTel,
		a.orderType,CASE a.orderType WHEN 10 THEN '普通订单' WHEN 20 THEN '调拨申请' WHEN 30 THEN '经营领用' WHEN 31 THEN '管理领用' WHEN 32 THEN '其他出库' WHEN 40 THEN '赠品出库' WHEN 50 THEN '报损报废' END AS orderTypeName,
		a.payMode,a.settlementId,a.shipDate,a.shipTime,a.currencyId,a.exchangeRate,a.taxFlag,a.ioState,a.taskState,
		CASE a.taskState WHEN 10 THEN '已关闭' WHEN 20 THEN '已审核' WHEN 30 THEN '已排车' WHEN 40 THEN '待拣货' WHEN 50 THEN '待复核' WHEN 60 THEN '待打包' WHEN 70 THEN '待装车' WHEN 80 THEN '已装车' WHEN 90 THEN '已发货' WHEN 95 THEN '已妥投' WHEN 96 THEN '未送达' WHEN 99 THEN '已回单' END AS taskStateDesc, 
		a.arState,a.totalFee,a.orderSource,a.buyerId,a.organizeId,a.poNo,a.salesId,a.handlerId,a.deptId,a.flag,a.expressNo,
		a.logisticsId,lg.logisticsName,a.logisticsFee,a.buyerMessage,a.mergeNo,a.memo,a.isReceipt,CASE a.isReceipt WHEN 1 THEN '是' ELSE '否' END AS isReceiptDesc,
		CONVERT(VARCHAR(20),a.receiptTime,120) AS receiptTime,a.backerId,u1.userNick AS backerName,a.thirdSyncFlag,
		CASE a.thirdSyncFlag WHEN -1 THEN '无需同步' WHEN 1 THEN '已同步' WHEN 0 THEN '待同步' WHEN 2 THEN '同步出错' END AS SyncFlag,
		CONVERT(VARCHAR(20),a.thirdSyncTime,120) AS thirdSyncTime,a.printNum,a.printId,u2.userNick AS printMan,
		a.creatorId,u3.userNick AS creatorName,a.isLocked,a.lockerId,u4.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
		a.editTime,a.editorId,u5.userNick AS editorName,ISNULL(t1.fclQty,0) AS fclQty,ISNULL(t2.lclQty,0) AS lclQty,
        ISNULL(t1.fclQty,0.0)+ISNULL(t2.lclQty,0.0) AS boxes,a.serviceFee,a.collectOrder,a.aStockNo,a.aFlag,
        CASE a.aFlag WHEN 0 THEN '订单' WHEN 1 THEN '有A单' WHEN 2 THEN 'A单' WHEN 3 THEN '直送订单' END AS aFlagDesc,
        CONVERT(VARCHAR(20),a.printTime,120) AS printTime
	FROM dbo.SAD_Stock AS a
		INNER JOIN dbo.BAS_Partner p ON a.customerId=p.partnerId
		INNER JOIN dbo.BAS_Partner o ON a.ownerId=o.partnerId
		LEFT JOIN (
					SELECT stockNo,SUM(CASE isPackage WHEN 1 THEN pickQty WHEN 0 THEN 0.0 END) fclQty
					FROM dbo.WMS_PickingDetail
					GROUP BY stockNo
					) t1 ON a.stockNo=t1.stockNo
		LEFT JOIN (
					SELECT stockNo,COUNT(1) lclQty
					FROM dbo.WMS_PackingDetail
					GROUP BY stockNo
					) t2 ON a.stockNo=t2.stockNo
		LEFT JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
		LEFT JOIN dbo.BAS_Area a1 ON a.receiverState=a1.areaId
		LEFT JOIN dbo.BAS_Area a2 ON a.receiverCity=a2.areaId
		LEFT JOIN dbo.BAS_Area a3 ON a.receiverDistrict=a3.areaId
		LEFT JOIN dbo.BAS_AddressLine l ON a.lineId=l.lineId
		LEFT JOIN dbo.BAS_Logistics lg ON a.logisticsId=lg.logisticsId
		LEFT JOIN dbo.SAM_User u1 ON a.backerId=u1.userId
		LEFT JOIN dbo.SAM_User u2 ON a.printId=u2.userId
		LEFT JOIN dbo.SAM_User u3 ON a.creatorId=u3.userId
		LEFT JOIN dbo.SAM_User u4 ON a.lockerId=u4.userId		
		LEFT JOIN dbo.SAM_User u5 ON a.editorId=u5.userId
	WHERE a.companyId=@companyId
)


go

