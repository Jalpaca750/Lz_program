
/*==============================================================*/
/* View: IMS_OtherDetail_V                                      */
/*==============================================================*/
--creator：        Frank
--create time：  2016-03-10
--其他入出库单明细视图
create view IMS_OtherDetail_V as
SELECT b.otherId,b.otherNo,a.billNo,b.ownerId,o.ownerNo,o.ownerName,b.viewOrder,a.ioDate,
      a.createTime,a.ioType,a.ioState,a.objId,b.companyId,b.warehouseId,b.lotNo,b.locationNo,       
      b.eId,b.itemId,sku.itemNo,sku.itemCTitle,sku.itemETitle,sku.itemName,sku.sellingPoint, 
      sku.itemSpell,sku.itemSpec,sku.barcode,sku.brandId,sku.brandCName,sku.brandEName, 
      sku.categoryId,sku.categoryNo,sku.categoryCName,sku.categoryEName,sku.colorName, 
      sku.sizeName,sku.unitName,sku.pkgUnit,sku.pkgRatio,sku.purPrice,sku.lastPurPrice,
      sku.inventoryMode,sku.isUnsalable,sku.isStop,sku.isVirtual,sku.isSafety,sku.safetyMonth,    
      b.ioQty,b.pkgQty,b.bulkQty,b.price,b.taxrate,b.taxPrice,b.fee,b.taxFee,b.totalFee, 
      a.handlerId,a.deptId,b.remarks,b.isSelected
FROM dbo.IMS_Other AS a INNER JOIN
      dbo.IMS_OtherDetail AS b ON a.otherNo = b.otherNo INNER JOIN
      dbo.BAS_ItemSku_V AS sku ON b.itemId = sku.itemId LEFT JOIN
      dbo.BAS_Owner_V AS o ON b.ownerId=o.ownerId LEFT JOIN
      dbo.IMS_Batch lt ON b.companyId=lt.companyId AND lt.lotNo=b.lotNo LEFT JOIN
      dbo.IMS_Stock s ON b.warehouseId=s.warehouseId AND ISNULL(b.lotNo,'')=ISNULL(s.lotNo,'') AND ISNULL(b.locationNo,'')=ISNULL(s.locationNo,'') AND b.itemId=s.itemId
go

