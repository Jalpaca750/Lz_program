
CREATE PROCEDURE  Pda_Proc_PkgPickingItem_TP(@pickingNo varchar(32),@operatorId varchar(32))
AS
declare @eid varchar(32)=''
declare @stockid  varchar(32)='' --库存ID
declare @pickingbillno varchar(100)=''--拣货单号
declare @companyId varchar(32)=''
declare @warehouseId varchar(32)='' ---仓库
declare @itemId  varchar(32)=''     --商品的ID
declare @regionid varchar(32)=''    --区域
declare @stockQty decimal(20,6)=0   --库存的数量
declare @locationNo varchar(40)=''  --货位
declare @lotNo varchar(40)=''       --批次
declare @errorCount int ---错误计数器
declare @sad_stockNo  varchar(32) --出库单号
declare @result_code int 
declare @isPackage int=0 --是否是整包装
declare @pickingId varchar(32)=''
declare @qty decimal(20,6)  --散件数量
BEGIN TRAN  --开始事务
SET NOCOUNT ON;
--=========================定义游标

DECLARE @book_StockNo varchar(32)
DECLARE @book_BillNo varchar(32)
DECLARE @book_StockId varchar(32),@_TYPE varchar(32)='S100'
IF EXISTS(SELECT PICKINGNO FROM WMS_PICKING WHERE PICKINGNO=@PICKINGNO AND TASKTYPE=2)
		BEGIN
		    SET @_TYPE='B200'
		END
--取pickingno
select @pickingbillno=billNo from WMS_Picking where pickingNo=@pickingNo
--
--
--
DECLARE   SMyCursor  cursor  FOR
SELECT pickingId,companyId,warehouseId,itemId,isnull(regionId,'') regionId,
realQty,stockQty,stockNo,isPackage,isnull(locationNo,'') locationNo, 
isnull(batchNo,'') lotNo
FROM  WMS_PICKINGDETAIL 
where pickingNo=@pickingNo
for read only
--
--
--
OPEN  SMyCursor ---打开游标
Fetch  NEXT  FROM SMyCursor  into @pickingId,  
@companyId,@warehouseId,@itemId,@regionid,@qty,@stockQty,
@sad_stockNo,@isPackage,@locationNo,@lotNo

WHILE @@fetch_status=0 
BEGIN  
/**************************************************************************************************/
		select 					
		@book_BillNo=stockBillNo,@book_StockId=stockId,@book_StockNo=stockNo
		from  WMS_PickingDetail_V where pickingId=@pickingId
		--实际库存
		select  @eid=eId , @stockid=stockid, @stockQty=isnull(onhandQty,0) from IMS_Stock 
		where companyId=@companyId and
		warehouseId=@warehouseId and isnull(regionId,'')=@regionid 
		and  itemId=@itemId and locationNo=@locationNo and lotNo=@lotNo
		--==================================================================================================
		--开始库存数量的计算
		--==================================================================================================
		--修改拣货的状态
		
		--修改库存 
		print '数量'+cast(@qty as varchar(32))
		update  IMS_Stock set 
		onhandQty=onhandQty-@qty,
		allocQty=(allocQty-@qty) ,--占用量不能被扣为负数
		lastOTime=GETDATE() 
		where stockId=@stockid
		set @errorCount+=@@ERROR
		--修改总库存
		update  IMS_Ledger set onhandQty=onhandQty-@qty,
		allocQty=(allocQty-@qty)
		,lastOTime=GETDATE() 
		where companyId=@companyId and warehouseId=@warehouseId and itemId=@itemId
		set @errorCount+=@@ERROR
		
		---写入流水账
		INSERT INTO IMS_Book(
		[bookId],[ioType],[companyId],[billId],[billNo],[billCode],[objectId],[warehouseId],
		[lotNo],[locationNo],[eId],[itemId],[befQty],[taxFlag],
		[discount],[discountFee],[ioQty],[price],[fee],[taxFee],
		[afterQty],[handlerId],[deptId],[createTime],
		[creatorId],[auditorId],[auditTime],[memo])
		values(REPLACE(NEWID(),'-',''),@_TYPE,@companyId,@book_StockId,@book_StockNo,@book_BillNo,@book_StockId,@warehouseId,
		@lotNo,@locationNo,@eid,@itemId,@stockQty,null,null,null,-@qty,null,null,null,
		(@stockQty-@qty),null,null,GETDATE(),@operatorId,'',GETDATE(),'')
		set @errorCount+=@@ERROR

					Fetch  NEXT  FROM SMyCursor  into @pickingId,  
@companyId,@warehouseId,@itemId,@regionid,@qty,@stockQty,
@sad_stockNo,@isPackage,@locationNo,@lotNo
END

/**************************************************************************************************/

CLOSE SMyCursor
Deallocate SMyCursor

if @errorCount<>0
begin
 print  '返回'
 rollback tran;
end
else  begin
commit tran;
end
go

