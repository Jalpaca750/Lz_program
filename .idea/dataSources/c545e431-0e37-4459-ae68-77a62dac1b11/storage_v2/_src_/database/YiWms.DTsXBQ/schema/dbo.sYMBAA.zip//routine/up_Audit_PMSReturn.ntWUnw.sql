-- =============================================
-- Author:		<Author: WJ>
-- Create date: <Create Date:2017-02-06>
-- Description:	<Description:审核采购退货单>
-- =============================================

CREATE PROCEDURE [dbo].[up_Audit_PMSReturn]
(
    @returnNo VARCHAR(32),		--退货单号
	@operatorId VARCHAR(32)		--操作员
)
AS
BEGIN
	DECLARE @companyId VARCHAR(32),		--公司Id
			@billNo VARCHAR(32),		--退货单号
			@warehouseId VARCHAR(32),	--仓库Id
			@supplierId VARCHAR(32),	--供应商Id
			@createTime DATETIME,		--制单时间
			@creatorId VARCHAR(32),		--制单人Id
			@handlerId VARCHAR(32),		--经办人Id
			@deptId VARCHAR(32),		--经办部门Id
			@memo VARCHAR(2000),		--主表备注
			@ioType VARCHAR(32),		--入出库类型（P200-销售退货单）
			@taxFlag INT,				--是否含税（默认含税）
			@returnId VARCHAR(32),		--明细Id
			@eId VARCHAR(32),			--主商品Id
			@itemId VARCHAR(32),		--SkuId			
			@returnQty DECIMAL(20,6),	--退货数量
			@befPrice DECIMAL(20,10),	--折前价
			@discount DECIMAL(6,2),		--折扣
			@discountFee DECIMAL(6,2),	--折扣金额
			@price DECIMAL(20,10),		--单价（折扣后）
			@taxrate DECIMAL(6,2),		--税率
			@fee DECIMAL(20,10),		--金额（不含税）
			@taxFee DECIMAL(20,10),		--税额
			@totalFee DECIMAL(20,10),	--金额（含税）
			@lotNo VARCHAR(32),			--批次号
			@locationNo VARCHAR(32)		--库位			
	--此处可用于计算成本
	DECLARE @befQty DECIMAL(20,6),			--出入库前数量
			@befFee DECIMAL(20,10),			--出入库前金额（不含税）
			@befTotalFee DECIMAL(20,10),	--出入库前金额（含税）	
			@befCPrice DECIMAL(20,10),		--出入库前单价（不含税）
			@befCTaxPrice DECIMAL(20,10),	--出入库前单价（含税）
			@auditTime DATETIME				--审核时间
	BEGIN TRY
		BEGIN TRANSACTION
		--主表信息		
		SELECT @billNo=billNo,@companyId=companyId,@warehouseId=warehouseId,@supplierId=supplierId,@ioType=ioType,
			@taxFlag=taxFlag,@createTime=createTime,@creatorId=creatorId,@handlerId=handlerId,@deptId=deptId,@memo=memo
		FROM PMS_Return 
		WHERE returnNo=@returnNo
		--审核时间
		SET @auditTime=GETDATE();
		
	----判断退货库存-----
	IF NOT EXISTS(SELECT 1 FROM PMS_ReturnDetail a 
				   LEFT JOIN IMS_Stock b ON a.companyId=b.companyId AND b.warehouseId=@warehouseId
				   AND a.itemId=b.itemId AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.locationNo,'') 
	              WHERE a.returnNo=@returnNo AND a.returnQty>ISNULL(b.onhandQty,0.0))
	BEGIN
			
			DECLARE myCursor CURSOR
			FOR SELECT returnId,eId,itemId,lotNo,locationNo,0-returnQty,befPrice,price,taxrate,discount,discountFee,0-fee,0-taxFee,0-totalFee
				FROM PMS_ReturnDetail
				WHERE returnNo=@returnNo
				ORDER BY viewOrder		 
			OPEN myCursor
			FETCH NEXT FROM myCursor INTO @returnId,@eId,@itemId,@lotNo,@locationNo,@returnQty,@befPrice,@price,@taxrate,@discount,@discountFee,@fee,@taxFee,@totalFee
			WHILE @@FETCH_STATUS=0
			BEGIN	
				--入库前数量（成本数据此处不用）
				SELECT @befQty=onhandQty,@befFee=fee,@befTotalFee=totalFee,@befCPrice=price,@befCTaxPrice=taxPrice
				FROM IMS_Stock 
				WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'');
				
				--处理商品库存
				 
				--处理IMS_Ledger表
				UPDATE IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)+@returnQty
				WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
				--如果表中没有数据，则新增一条记录
				INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,
					price,taxrate,taxPrice,fee,totalFee)
				SELECT REPLACE(NEWID(),'-',''),@companyId,@warehouseId,@eId,@itemId,@returnQty,0.0 AS allocQty,
					0.0 AS price,@taxrate,0.0 AS taxPrice,0.0 AS fee,0.0 AS totalFee
				WHERE NOT EXISTS(SELECT 1 FROM IMS_Ledger WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId);
				
					
				--处理IMS_Stock表
				UPDATE IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)+@returnQty
				WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId;
				--如果表中没有数据，则直接新增一条
				INSERT INTO IMS_Stock(stockId,companyId,warehouseId,regionId,locationNo,lotNo,eId,itemId,onhandQty,allocQty,price,taxrate,taxPrice,fee,totalFee)
				SELECT REPLACE(NEWID(),'-',''),@companyId,@warehouseId,(SELECT Top 1 regionId FROM BAS_Location WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@locationNo),
					@locationNo,@lotNo,@eId,@itemId,@returnQty,0.0 AS allocQty,0.0 AS price,@taxrate,0.0 AS taxPrice,0.0 AS fee,0.0 AS totalFee
				WHERE NOT EXISTS(
								 SELECT 1
								 FROM IMS_Stock
								 WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId
								)
				--处理IMS_Book表

				INSERT INTO IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,eId,itemId,
					befQty,befFee,befTotalFee,taxFlag,taxrate,befPrice,discount,discountFee,ioQty,price,fee,taxFee,totalFee,costFee,costTotalFee,
					afterQty,afterFee,afterTotalFee,handlerId,deptId,createTime,creatorId,auditTime,auditorId,memo)
				VALUES(REPLACE(NEWID(),'-',''),@ioType,@companyId,@returnId,@returnNo,@billNo,@supplierId,@warehouseId,ISNULL(@lotNo,''),ISNULL(@locationNo,''),@eId,@itemId,
					@befQty,@befFee,@befTotalFee,@taxFlag,@taxrate,@befPrice,@discount,@discountFee,@returnQty,@price,@fee,@taxFee,@totalFee,0.0,0.0,
					ISNULL(@befQty,0.0)+ISNULL(@returnQty,0.0),0.0,0.0,@handlerId,@deptId,@createTime,@creatorId,@auditTime,@operatorId,@memo);

				FETCH NEXT FROM myCursor INTO @returnId,@eId,@itemId,@lotNo,@locationNo,@returnQty,@befPrice,@price,@taxrate,@discount,@discountFee,@fee,@taxFee,@totalFee
			END
			CLOSE myCursor
			DEALLOCATE myCursor
			--更新退货单状态
			UPDATE PMS_Return SET ioState=20,editTime=@auditTime,editorId=@operatorId,auditTime=@auditTime,auditorId=@operatorId 
			WHERE returnNo=@returnNo
		
		
	  END----判断满足库退------
		COMMIT
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END CATCH
END




go

