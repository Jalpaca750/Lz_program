
CREATE PROC [dbo].[up_SyncF10SalesOrder]
(    
	@companyId VARCHAR(32),		--公司Id,如果前台调用，需传值，为空时，手动修改这个值
	@ownerId VARCHAR(32),		--业主Id
	@creatorId VARCHAR(32),		--操作员，前天调用的当前用户，后台执行时，可赋值
	@startTime DATETIME,		--同步产品的开始时间（修改时间）
	@endTime DATETIME			--同步产品的截至时间（修改时间）
)
AS
BEGIN
	DECLARE @userId BIGINT;
	DECLARE @orderNo VARCHAR(32),@orderType INT;
	DECLARE @sales TABLE(orderNo VARCHAR(20),orderType INT);
	SET @endTime=GETDATE();
	SELECT @userId=employeeId FROM F10BMS.dbo.WMS_F10_User_V WHERE userId=@creatorId;
    IF EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10SalesOrder' AND isDisable=1)
        RETURN;
	--开始同步
	BEGIN TRY 	
		BEGIN TRANSACTION
		--如果接口正在同步中，则直接退出
		IF EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10SalesOrder' AND isLocked=1)
		BEGIN
			COMMIT;
			RETURN;
		END
		--1.锁定同步接口
		--UPDATE dbo.SAM_Store SET isLocked=1,lockerId=@creatorId,lockedTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10SalesOrder' AND isLocked=0;
		IF (@@ROWCOUNT>0)
		BEGIN
			--1.1获取需要同步销售订单数据
			INSERT INTO @sales(orderNo,orderType)
			SELECT OrderNo,10 
			FROM F10BMS.dbo.SMS_Order 
			WHERE (DeptNo IN(SELECT DeptNo FROM F10BMS.dbo.WMS_Config)) 
				AND (syncFlag=0)
				AND (BillSts='20' OR BillSts='25')
			--1.2获取调拨申请单
			INSERT INTO @sales(orderNo,orderType)
			SELECT orderNo,20
			FROM F10BMS.dbo.PMS_Order
			WHERE (BillType='调拨申请单') 
				AND (DeptNo_A IN(SELECT DeptNo FROM F10BMS.dbo.WMS_Config)) 
				AND (syncFlag=0)
				AND (BillSts='20' OR BillSts='25')
			--1.3获取赠品出库单
			INSERT INTO @sales(orderNo,orderType)
			SELECT PresentNo,30 
			FROM F10BMS.dbo.IMS_Present 
			WHERE (DeptNo IN(SELECT DeptNo FROM F10BMS.dbo.WMS_Config)) 
				AND (BillType='20')
				AND (syncFlag=0)
				AND (BillSts='15')
			--1.4获取报损单和其他入出库单
			INSERT INTO @sales(orderNo,orderType)
			SELECT OtherNo,CASE billType WHEN '20' THEN 40 ELSE 50 END 
			FROM F10BMS.dbo.IMS_Other 
			WHERE (DeptNo IN(SELECT DeptNo FROM F10BMS.dbo.WMS_Config)) 
				AND (BillType='20' OR BillType='30')
				AND (syncFlag=0)
				AND (BillSts='15')
		    --1.5获取需要同步的销售退货单
		    INSERT INTO @sales(orderNo,orderType)
		    SELECT ReturnNo,60
		    FROM F10BMS.dbo.SMS_Return a
		    WHERE EXISTS(SELECT * FROM F10BMS.dbo.WMS_Config b WHERE a.DeptNo=b.DeptNo AND (a.WareHouse=b.Warehouse OR a.WareHouse=b.DclWarehouse OR a.WareHouse=b.whId01 OR a.WareHouse=b.whId02 OR a.WareHouse=b.whId03))	
		        AND (syncFlag=0)
				AND (BillSts='15')
			--2.同步出库类订单到订单池	
			IF EXISTS(SELECT 1 FROM @sales)
			BEGIN
				WHILE EXISTS(SELECT 1 FROM @sales)
				BEGIN
					--取第一个商品
					SELECT TOP 1 @orderNo=orderNo,@orderType=orderType FROM @sales ORDER BY orderType,orderNo; 
					--删除单据对应的错误数据
					DELETE FROM SAM_Error WHERE companyId=@companyId AND billId=@orderNo;
					--同步
					IF (@orderType=10)
						EXEC F10BMS.dbo.sp_AfterSMS30Audit @orderNo,'20',@userId;
					ELSE IF(@orderType=20)
						EXEC F10BMS.dbo.sp_AfterIMS10Audit @orderNo,'20',@userId;
					ELSE IF(@orderType=30)
						EXEC F10BMS.dbo.sp_AfterIMS60Audit @orderNo,'20',@userId;
					ELSE IF(@orderType=40 OR @orderType=50)
						EXEC F10BMS.dbo.sp_AfterIMS90Audit @orderNo,'20',@userId;
				    ELSE IF (@orderType=60)
				        EXEC F10BMS.dbo.sp_AfterSMS60Audit @orderNo,'20',@userId;
					--删除同步成功的临时单据
					DELETE FROM @sales WHERE orderNo=@orderNo AND orderType=@orderType;
				END
			END
			--释放锁
			--UPDATE dbo.SAM_Store SET isLocked=0,lockerId='',lockedTime=NULL,syncTime=@endTime WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10SalesOrder' AND lockerId=@creatorId;
		END
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int;
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();
		INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		SELECT LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@creatorId,'up_SyncF10SalesOrder','YI_SO_SYNC_ERROR',@ErrMsg,@OrderNo,@OrderNo
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END CATCH
END
go

