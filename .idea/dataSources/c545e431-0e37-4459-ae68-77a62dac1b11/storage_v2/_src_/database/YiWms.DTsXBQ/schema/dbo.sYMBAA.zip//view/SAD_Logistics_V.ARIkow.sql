

/*==============================================================*/
/* View: BAS_Owner_V                                            */
/*==============================================================*/
--creator：        WJ
--create time：  2018-03-27 日整理 
--快递
CREATE  view [dbo].[SAD_Logistics_V] as
SELECT a.expressNo, a.ownerId, a.companyId, a.stockNo, a.stockBillNo, a.pkgQty,
       a.pkgWeight, a.pkgVolume, a.isColl, a.[collection], a.logisticsId,
       a.expressType, a.receiverState, a.receiverCity, a.receiverDistrict,
       a.receiverAddress, a.receiverTel, a.receiverMobile, a.creatorId,
       a.createTime, a.printNum, a.printId, a.printTime, a.memo, a.payMethod,
       a.slField1, a.slField2, a.slField3, a.slField4, a.slField5,f.receiverName,f.receiverAddress AS stockreceiverAddress,
      CASE WHEN LEN(a.receiverMobile)>0 THEN a.receiverMobile+'/'+a.receiverTel 
      ELSE a.receiverTel END AS fullTel,
       a.receiverState+a.receiverCity+a.receiverDistrict+a.receiverAddress AS fullAddress,g.partnerNo AS customerNo,g.shortName AS shortName,g.partnerName AS customerName,e.partnerName AS ownerName,b.logisticsCode,b.logisticsName,c.userNo,c.userNick AS creatorName,d.userNick AS printName
,CASE a.payMethod WHEN '1' THEN '月结' ELSE '' end as payMethodName,CASE a.isColl WHEN '1' THEN '是' ELSE '否' end as isCollName
,h.reportCode,(SELECT COUNT(1) FROM SAD_LogisticsDetail WHERE expressNo=a.expressNo) AS pkgQtyCount ,
f.mergeNo orderBillNo
FROM SAD_Logistics a
LEFT JOIN BAS_Logistics b ON a.logisticsId=b.logisticsId
LEFT JOIN SAM_User c ON a.creatorId=c.userId
LEFT JOIN SAM_User d ON a.printId=d.userId
LEFT JOIN BAS_Partner e ON a.ownerId=e.partnerId AND e.partnerType=3
LEFT JOIN SAD_Stock f ON a.stockNo=f.stockNo
LEFT JOIN BAS_Partner g ON f.customerId=g.partnerId
LEFT JOIN BAS_LogisticsConfig h ON a.logisticsId=h.logisticsId

go

