/*==============================================================*/
/* View: WMS_PACK_F10_IMS_OtherDtl_V                            */
/*==============================================================*/
CREATE view [dbo].[WMS_PACK_F10_IMS_OtherDtl_V] as
SELECT a.billNo AS otherNo,w.warehouseNo AS WareHouse,b.ItemID,w.locationNo AS Location,1 AS PkgQty,
	1 AS SQty,b.PPrice,b.PPrice AS Amt,packNo AS wmsStockId
FROM dbo.WMS_Packing a 
	INNER JOIN F10BMS.dbo.WMS_F10_Packing_Item_V b ON a.cartonId=b.cartonId
	INNER JOIN dbo.BAS_Worktable_V w ON a.deskCode=w.worktableId
WHERE a.materialFlag=10
	AND (a.syncFlag=0 OR a.syncFlag=2)
go

