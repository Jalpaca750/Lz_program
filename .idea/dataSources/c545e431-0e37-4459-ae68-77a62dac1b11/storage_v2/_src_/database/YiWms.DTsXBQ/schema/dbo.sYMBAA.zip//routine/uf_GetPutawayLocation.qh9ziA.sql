-- =============================================
-- Author:		<Author:Frank.He>
-- Create date: <Create Date:2016-12-14>
-- Description:	<Description:通过上架策略取得商品上架建议库位（补货）  V1.0.6>
--              211-上架到目标库位	
--              212-上架到商品指定的件拣货库位（库位资料维护中指定）
--              213-上架到商品指定的箱拣货库位（库位资料维护中指定）
--              221-上架到目标区域(合适的库位)
--              222-上架到商品指定的散件上架区域(合适的库位)
--              223-上架到商品指定的整件上架区域(合适的库位)
--              224-上架到目标库区（新增）
--              225-上架到商品指定的散件上架库区（新增）
--              226-上架到商品指定的整件上架库区（新增）
--              231-上架到目标区域(历史库位)
--              232-上架到商品指定的散件上架区域(历史库位)
--              233-上架到商品指定的整件上架区域(历史库位)
--              234-上架到目标库区(历史库位)
--              235-上架到商品指定的散件上架库区(历史库位)
--              236-上架到商品指定的整件上架库区(历史库位)
-- Modify:      <Frank.He 2017-02-08 增加预分配机制，避免空库位重复分配>
--              <Frank.He 2017-04-23 除固定库位上架策略外，其他策略不允许上架到固定库位>
--              <Frank.He 2017-05-02 修正2017-04-23 Bug>
--              <Frank.He 2017-08-12 调整上架算法以及上架策略，减少不必要的上架策略>
--              <Frank.He 2019-01-06 精简上架策略，调整上架算法，并只作为补货上架算法使用 V1.0.1>
--              <Frank.He 2019-05-21 修正上架策略Bug(排除法用外连接BAS_Location LEFT JOIN IMS_Stock V1.0.2>
--              <Frank.He 2019-11-28 原商品上上架区域改为按仓库指定上架区域(BAS_ItemZone)>
--              <Frank.He 2020-01-17 同步所有策略>
--              <Frank.He 2020-10-09 允许产品混放时，历史库位Bug修正>
-- =============================================
CREATE FUNCTION [dbo].[uf_GetPutawayLocation] 
(
	@companyId VARCHAR(32),			--公司Id
	@ownerId VARCHAR(32),			--业主Id
	@warehouseId VARCHAR(32),		--仓库Id
	@itemId VARCHAR(32),			--商品Id
	@recBin VARCHAR(32),			--收货库位
	@receiveQty DECIMAL(20,6),		--入库数量
	@lotNo VARCHAR(32),				--批次号
	@orderSource INT,				--订单类型 0,所有单据
	@unitLevel VARCHAR(10)			--单位级别：预留字段，分别对应EA-件CS-箱PL-托盘OT-其他
)
RETURNS VARCHAR(32)
AS
BEGIN
    DECLARE @putPolicy INT;                 --规则代码
	DECLARE	@targRegion VARCHAR(32);		--目标区域
	DECLARE	@targZone VARCHAR(32);          --目标库区（逻辑库区）
	DECLARE	@targLocation VARCHAR(32);		--目标库位
	DECLARE	@itemMix INT;					--允许产品混放,1-允许;0-不允许
	DECLARE	@lotMix INT;					--允许批次混放,1-允许;0-不允许
	DECLARE	@isPackage INT;					--库位使用：10-件捡货库位；20-箱捡货库位;30-混合拣库位; 40-储货位库位；50-过渡库位
	DECLARE	@putMode INT;					--优先模式：1-储位放满优先;2-空货位优先;	
	DECLARE @result VARCHAR(32);			--返回结果
	DECLARE @viewOrder INT;					--序号
	DECLARE @locationNo VARCHAR(32);		--库位编码
	DECLARE @inventoryMode INT;				--0-无;1-批次	
	DECLARE @eachRegion VARCHAR(32);		--散件上架区域
	DECLARE @eachZone VARCHAR(32);          --散件上架库区
	DECLARE @caseRegion VARCHAR(32);		--整件上架区域
	DECLARE @caseZone VARCHAR(32);          --整件上架库区
	--存放商品历史库位
	DECLARE @hisLocation TABLE(viewOrder INT IDENTITY(1,1),companyId VARCHAR(32),warehouseId VARCHAR(32),locationNo VARCHAR(32),onhandQty DECIMAL(20,6),putawayOrder INT);
	--参数形成表
    DECLARE @tbParas TABLE(warehouseId VARCHAR(32),itemId VARCHAR(32),lotNo VARCHAR(32),SQty DECIMAL(20,6));
    INSERT INTO @tbParas(warehouseId,itemId,lotNo,SQty) VALUES(@warehouseId,@itemId,ISNULL(@lotNo,''),@receiveQty);
	--当前商品批次管理、散件上架区域，散件上架库区，整件上架区域，整件上架库区;
	SELECT @inventoryMode=inventoryMode,@eachRegion=putRegion,@caseRegion=csPutRegion,@eachZone=putZone,@caseZone=csPutZone FROM BAS_Item WHERE itemId=@itemId;
    --散件上架区域，散件上架库区，整件上架区域，整件上架库区;
	--SELECT @eachRegion=putRegion,@caseRegion=csPutRegion,@eachZone=putZone,@caseZone=csPutZone
	--FROM BAS_Item
	--WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
	--循环上架策略，查找上架库位
	DECLARE myPlicy CURSOR
	FOR 
		SELECT putPolicy,ISNULL(targRegion,'') targRegion,ISNULL(targLocation,'') targLocation,ISNULL(targZone,'') targZone,itemMix,lotMix,isPackage,putMode
		FROM WMS_PutawayPolicy
		WHERE (companyId=@companyId)								--公司
			AND (warehouseId=@warehouseId)							--仓库
			AND (ownerId=@ownerId)									--业主
			AND (isDisable=0)										--有效的
			AND (orderSource=0 OR orderSource=@orderSource)			--订单类型
			AND (unitLevel=@unitLevel)								--包装规格：EA-散件;CS-整箱;PL-整托;OT-其他
			AND (policyType)=0                                      --0-补货上架策略；1-采购上架策略
		ORDER BY viewOrder;
	OPEN myPlicy;
	FETCH NEXT FROM myPlicy INTO @putPolicy,@targRegion,@targLocation,@targZone,@itemMix,@lotMix,@isPackage,@putMode;
	WHILE @@FETCH_STATUS=0
	BEGIN
		--1.上架到指定库位
		--1.1.上架到目标库位（211）
		IF (@putPolicy=211)
		BEGIN
			SET @result=@targLocation;
			IF (ISNULL(@result,'')!='')
				BREAK;
		END 
		--1.2. 上架到商品指定的拣货库位（212-件拣货库位；213-箱拣货库位）（库位资料维护中指定）		
		ELSE IF (@putPolicy=212 OR @putPolicy=213)
		BEGIN
			SELECT TOP 1 @result=locationNo
			FROM dbo.BAS_Location
			WHERE (companyId=@companyId)						--公司Id
				AND (warehouseId=@warehouseId)					--仓库Id
				AND (itemId=@itemId)							--商品Id
				AND (isFixed=1)									--固定库位
				AND (isDisable=0)								--有效库位
				AND (isPackage=@isPackage)						--库位使用
			ORDER BY putawayOrder;
			IF (ISNULL(@result,'')!='')
				BREAK;
		END
		--2.上架到指定区域		
		ELSE IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223 OR @putPolicy=231 OR @putPolicy=232 OR @putPolicy=233)
		BEGIN
		    --222-上架到商品指定的散件上架区域
		    IF (@putPolicy=222 OR @putPolicy=232)
			    SET @targRegion=@eachRegion;
		    --223-上架到商品指定的整件上架区域(合适的库位)
		    IF (@putPolicy=223 OR @putPolicy=233)
			    SET @targRegion=@caseRegion;
		    --2.1指定区域库位(空闲优先)
			IF (@putMode=2)
			BEGIN
			    --2.1.1指定区域历史库库位
		        SELECT TOP 1 @result=locationNo
			    FROM (
					    SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
					    FROM dbo.BAS_Location a 
						    INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					    WHERE (a.companyId=@companyId)						                            --公司Id
						    AND (a.warehouseId=@warehouseId)				                            --仓库Id							    
						    AND (a.regionId=@targRegion)					                            --目标区域
						    AND (a.isDisable=0)								                            --有效库位	
						    AND (a.isFixed=0)								                            --非固定库位			
						    AND (a.isPackage=@isPackage)					                            --库位使用
						    AND (b.itemId=@itemId)                                                      --历史库位
						    AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))             --非批次或者对应批次
						    AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo AND c.ioFlag='+'))
					    GROUP BY a.locationNo,a.putawayOrder
				    ) t 
			    WHERE t.onhandQty=0.0 
			    ORDER BY putawayOrder;
			    IF (ISNULL(@result,'')!='')
				    BREAK;
				--2.1.2指定区域历史库位优先，其他空库位也可以
				IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
				BEGIN
				    SELECT TOP 1 @result=locationNo
				    FROM (
						    SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
							FROM dbo.BAS_Location a 
							    LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						    WHERE (a.companyId=@companyId)						                        --公司Id
							    AND (a.warehouseId=@warehouseId)				                        --仓库Id
							    AND (a.regionId=@targRegion)					                        --目标区域
							    AND (a.isDisable=0)								                        --有效库位
							    AND (a.isFixed=0)								                        --非固定库位
							    AND (a.isPackage=@isPackage)					                        --库位使用
							    AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo AND c.ioFlag='+'))
						    GROUP BY a.locationNo,a.putawayOrder
					    ) t 
				    WHERE t.onhandQty=0.0 
				    ORDER BY putawayOrder;
				    IF (ISNULL(@result,'')!='')
					    BREAK;
				END
			END
			--2.2.指定区域库位（储满优先）
			ELSE
			BEGIN
			    --2.2.1.批次管理，不允许产品、批次混放（排除法，排除非当前产品、当前批次的其他任何有库存的商品所在的库位）
			    IF (@inventoryMode=1 AND @lotMix=0 AND @itemMix=0)
		        BEGIN
		            INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.regionId=@targRegion)						                            --目标区域
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
                        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo=t.lotNo))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.regionId=@targRegion)						                            --目标区域
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
				        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo=t.lotNo))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
                    --获取历史可用预分配库位
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
			                    AND (a.warehouseId=@warehouseId)					                    --目标仓库
			                    AND (a.regionId=@targRegion)						                    --目标区域
			                    AND (a.isDisable=0)									                    --有效库位
			                    AND (a.isFixed=0)									                    --非固定库位
			                    AND (a.isPackage=@isPackage)						                    --库位使用
			                    AND (b.itemId=@itemId)                                                  --当前商品
			                    AND (b.lotNo=@lotNo)                                                    --当前批次
			                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
		            IF (ISNULL(@result,'')!='')
			            BREAK;
                    --获取历史可用库位
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
				                AND (a.warehouseId=@warehouseId)					                    --目标仓库
				                AND (a.regionId=@targRegion)						                    --目标区域
				                AND (a.isDisable=0)									                    --有效库位
				                AND (a.isFixed=0)									                    --非固定库位
				                AND (a.isPackage=@isPackage)						                    --库位使用
				                AND (b.itemId=@itemId)                                                  --当前商品
				                AND (b.lotNo=@lotNo)                                                    --当前批次
				                AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
			        IF (ISNULL(@result,'')!='')
				        BREAK;
				    --获取其他可用库位(满足优先、上架顺序优先)
                    IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
                    BEGIN                  
                        SELECT TOP 1 @result=locationNo
                        FROM (
                                SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty,
                                    SUM(CASE WHEN b.itemId=@itemId THEN 1 ELSE 0 END) AS hisFlag
                                FROM BAS_Location a
                                    LEFT JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
					                AND (a.warehouseId=@warehouseId)					                --目标仓库
					                AND (a.regionId=@targRegion)						                --目标区域
					                AND (a.isDisable=0)									                --有效库位
					                AND (a.isFixed=0)									                --非固定库位
					                AND (a.isPackage=@isPackage)						                --库位使用
                                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				        IF (ISNULL(@result,'')!='')
					        BREAK;	
			        END
			    END
			    --2.2.2批次管理，允许混放批次（不允许产品混放）；非批次管理(不允许产品混放）（排除法：排除其他任何有库存的商品所在的库位）
			    ELSE IF (@inventoryMode=1 AND @lotMix=1 AND @itemMix=0) OR (@inventoryMode=0 AND @itemMix=0) 
			    BEGIN
			        INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.regionId=@targRegion)						                            --目标区域
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
                        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.regionId=@targRegion)						                            --目标区域
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
				        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
                    --获取历史可用预分配库位
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
			                    AND (a.warehouseId=@warehouseId)					                    --目标仓库
			                    AND (a.regionId=@targRegion)						                    --目标区域
			                    AND (a.isDisable=0)									                    --有效库位
			                    AND (a.isFixed=0)									                    --非固定库位
			                    AND (a.isPackage=@isPackage)						                    --库位使用
			                    AND (b.itemId=@itemId)                                                  --当前商品
			                    AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))         --当前批次
			                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
		            IF (ISNULL(@result,'')!='')
			            BREAK;
                    --获取历史可用库位
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
				                AND (a.warehouseId=@warehouseId)					                    --目标仓库
				                AND (a.regionId=@targRegion)						                    --目标区域
				                AND (a.isDisable=0)									                    --有效库位
				                AND (a.isFixed=0)									                    --非固定库位
				                AND (a.isPackage=@isPackage)						                    --库位使用
				                AND (b.itemId=@itemId)                                                  --当前商品
				                AND (@inventoryMode=0 OR (b.lotNo=@lotNo AND @inventoryMode=1))         --当前批次
				                AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
			        IF (ISNULL(@result,'')!='')
				        BREAK;    
                    --获取其他可用库位(历史库位、满足优先、上架顺序优先)
                    IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
                    BEGIN    
                        SELECT TOP 1 @result=locationNo
                        FROM (
                                SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty,
                                    SUM(CASE WHEN b.itemId=@itemId THEN 1 ELSE 0 END) AS hisFlag
                                FROM BAS_Location a
                                    LEFT JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
					                AND (a.warehouseId=@warehouseId)					                --目标仓库
					                AND (a.regionId=@targRegion)						                --目标区域
					                AND (a.isDisable=0)									                --有效库位
					                AND (a.isFixed=0)									                --非固定库位
					                AND (a.isPackage=@isPackage)						                --库位使用
                                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				        IF (ISNULL(@result,'')!='')
					        BREAK;
			        END
			    END
			    --2.2.3.批次管理，不允许批次混放，允许产品混放(排除法，不允许放在当前商品其他批次有库存的库位)
			    ELSE IF (@inventoryMode=1 AND @lotMix=0 AND @itemMix=1)
			    BEGIN
			        INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                        --公司Id
                        AND (a.warehouseId=@warehouseId)					                        --目标仓库
				        AND (a.regionId=@targRegion)						                        --目标区域
				        AND (a.isDisable=0)									                        --有效库位
				        AND (a.isFixed=0)									                        --非固定库位
				        AND (a.isPackage=@isPackage)						                        --库位使用
                        AND (EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo!=t.lotNo))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                        --公司Id
                        AND (a.warehouseId=@warehouseId)					                        --目标仓库
				        AND (a.regionId=@targRegion)						                        --目标区域
				        AND (a.isDisable=0)									                        --有效库位
				        AND (a.isFixed=0)									                        --非固定库位
				        AND (a.isPackage=@isPackage)						                        --库位使用
				        AND (EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo!=t.lotNo))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
                    --获取历史可用预分配库位
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
			                    AND (a.warehouseId=@warehouseId)					                    --目标仓库
			                    AND (a.regionId=@targRegion)						                    --目标区域
			                    AND (a.isDisable=0)									                    --有效库位
			                    AND (a.isFixed=0)									                    --非固定库位
			                    AND (a.isPackage=@isPackage)						                    --库位使用
			                    AND (b.itemId=@itemId)                                                  --当前商品
			                    AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))         --当前批次
			                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
		            IF (ISNULL(@result,'')!='')
			            BREAK;
                    --获取历史可用库位
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
				                AND (a.warehouseId=@warehouseId)					                    --目标仓库
				                AND (a.regionId=@targRegion)						                    --目标区域
				                AND (a.isDisable=0)									                    --有效库位
				                AND (a.isFixed=0)									                    --非固定库位
				                AND (a.isPackage=@isPackage)						                    --库位使用
				                AND (b.itemId=@itemId)                                                  --当前商品
				                AND (@inventoryMode=0 OR (b.lotNo=@lotNo AND @inventoryMode=1))         --当前批次
				                AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
			        IF (ISNULL(@result,'')!='')
				        BREAK;    
                    --获取其他空用库位（历史优先、满足优先、顺序优先）
                    IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
                    BEGIN
                        SELECT TOP 1 @result=locationNo
                        FROM (
                                SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty,
                                    SUM(CASE WHEN b.itemId=@itemId THEN 1 ELSE 0 END) AS hisFlag
                                FROM BAS_Location a
                                    LEFT JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
					                AND (a.warehouseId=@warehouseId)					                --目标仓库
					                AND (a.regionId=@targRegion)						                --目标库区
					                AND (a.isDisable=0)									                --有效库位
					                AND (a.isFixed=0)									                --非固定库位
					                AND (a.isPackage=@isPackage)						                --库位使用
                                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				        IF (ISNULL(@result,'')!='')
					        BREAK;	
			        END
			    END 
				--2.2.4.批次管理，允许混放批次（允许产品混放）,非批次管理(允许产品混放）（历史库位优先，其他任何库位都可）
				ELSE IF (@inventoryMode=1 AND @lotMix=1 AND @itemMix=1) OR (@inventoryMode=0 AND @itemMix=1) 
				BEGIN
				    --2.2.4.1.取历史预分配库位
				    SELECT TOP 1 @result=a.locationNo
				    FROM BAS_Location a 
					    INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
				    WHERE (a.companyId=@companyId)							                --公司Id
					    AND (a.warehouseId=@warehouseId)					                --目标仓库
					    AND (a.regionId=@targRegion)						                --目标区域								    
					    AND (a.isDisable=0)									                --有效库位
					    AND (a.isFixed=0)									                --非固定库位
					    AND (a.isPackage=@isPackage)						                --库位使用
					    AND (b.itemId=@itemId)							                    --历史商品
					    AND (b.ioFlag='+')									                --预分配
					    AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
                    ORDER BY b.allocQty DESC,a.putawayOrder;
				    IF (ISNULL(@result,'')!='')
					    BREAK;										
			        --2.2.4.2.取库存表中的历史库位
				    SELECT TOP 1 @result=a.locationNo
				    FROM BAS_Location a 
					    INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
				    WHERE (a.companyId=@companyId)							                --公司Id
					    AND (a.warehouseId=@warehouseId)					                --目标仓库
					    AND (a.regionId=@targRegion)						                --目标区域					    
					    AND (a.isDisable=0)									                --有效库位
					    AND (a.isFixed=0)									                --非固定库位
					    AND (a.isPackage=@isPackage)						                --库位使用
                        AND (b.itemId=@itemId)                                              --历史商品
                        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
                    ORDER BY b.onhandQty DESC,a.putawayOrder;
				    IF (ISNULL(@result,'')!='')
					    BREAK;
				    --2.2.4.3.取库位表中的其他库存从0-N
				    SELECT TOP 1 @result=locationNo
				    FROM (
						    SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)) AS onhandQty
						    FROM BAS_Location a 
							    LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						    WHERE (a.companyId=@companyId)							        --公司Id
							    AND (a.warehouseId=@warehouseId)					        --目标仓库
							    AND (a.regionId=@targRegion)						        --目标区域
							    AND (a.isDisable=0)									        --有效库位
							    AND (a.isFixed=0)									        --非固定库位
							    AND (a.isPackage=@isPackage)						        --库位使用
							GROUP BY a.locationNo,a.putawayOrder
					    ) t
				    ORDER BY onhandQty DESC,putawayOrder;
				    IF (ISNULL(@result,'')!='')
					    BREAK;
				END
			END
		END
		--3.上架到指定库区（比区域更小的范围，可分类存储） 
		ELSE IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226 OR @putPolicy=234 OR @putPolicy=235 OR @putPolicy=236)
        BEGIN
            --225-上架到商品指定的散件上架库区(合适的库位)
		    IF (@putPolicy=225 OR @putPolicy=235)	
		        SET @targZone =@eachZone;
		    --226-指定商品整件上架库区为目标库区
		    IF (@putPolicy=226 OR @putPolicy=236)	
		        SET @targZone =@caseZone;
		    --3.1指定库区库位（空闲优先）
			IF (@putMode=2)                 
			BEGIN
			    --3.1.1 上架到指定库区(历史库位)
		        SELECT TOP 1 @result=locationNo
			    FROM (
					    SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
					    FROM dbo.BAS_Location a 
						    INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					    WHERE (a.companyId=@companyId)						                    --公司Id
						    AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
						    AND (a.zoneId=@targZone)					                        --目标库区
						    AND (a.isDisable=0)								                    --有效库位
						    AND (a.isFixed=0)								                    --非固定库位
						    AND (a.isPackage=@isPackage)					                    --库位使用
						    AND (b.itemId=@itemId)                                              --历史商品
						    AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
						    AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo))
					    GROUP BY a.locationNo,a.putawayOrder
				    ) t 
			    WHERE t.onhandQty=0.0 
			    ORDER BY putawayOrder;
			    IF (ISNULL(@result,'')!='')
				    BREAK;
			    --3.1.2 上架到指定库区(其他库区)
			    IF(@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
			    BEGIN
			        SELECT TOP 1 @result=locationNo
				    FROM (
						    SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
							    SUM(CASE WHEN b.itemId=@itemId THEN 1 ELSE 0 END) AS hisFlag
						    FROM dbo.BAS_Location a 
							    LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						    WHERE (a.companyId=@companyId)						--公司Id
							    AND (a.warehouseId=@warehouseId)				--仓库Id
							    AND (a.zoneId=@targZone)					    --目标库区
							    AND (a.isDisable=0)								--有效库位
							    AND (a.isFixed=0)								--非固定库位
							    AND (a.isPackage=@isPackage)					--库位使用
							    AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo))
						    GROUP BY a.locationNo,a.putawayOrder
					    ) t 
				    WHERE t.onhandQty=0.0 
				    ORDER BY hisFlag DESC,putawayOrder;
				    IF (ISNULL(@result,'')!='')
					    BREAK;
			    END
			END
			--3.2指定库区库位（储满优先）
			ELSE		                    	
			BEGIN
			    --3.2.1批次管理，不允许产品、批次混放（排除法，排除非当前产品、当前批次的其他任何有库存的商品所在的库位）
			    IF (@inventoryMode=1 AND @lotMix=0 AND @itemMix=0)
		        BEGIN
			        INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							--公司Id
                        AND (a.warehouseId=@warehouseId)					--目标仓库
				        AND (a.zoneId=@targzone)						    --目标库区
				        AND (a.isDisable=0)									--有效库位
				        AND (a.isFixed=0)									--非固定库位
				        AND (a.isPackage=@isPackage)						--库位使用
                        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo=t.lotNo))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							--公司Id
                        AND (a.warehouseId=@warehouseId)					--目标仓库
				        AND (a.zoneId=@targZone)						    --目标库区
				        AND (a.isDisable=0)									--有效库位
				        AND (a.isFixed=0)									--非固定库位
				        AND (a.isPackage=@isPackage)						--库位使用
				        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo=t.lotNo))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
                    --获取历史可用预分配库位                     
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
			                    AND (a.warehouseId=@warehouseId)					                    --目标仓库
			                    AND (a.zoneId=@targZone)						                        --目标库区
			                    AND (a.isDisable=0)									                    --有效库位
			                    AND (a.isFixed=0)									                    --非固定库位
			                    AND (a.isPackage=@isPackage)						                    --库位使用
			                    AND (b.itemId=@itemId)                                                  --当前商品
			                    AND (@inventoryMode=0 OR(@inventoryMode=1 AND b.lotNo=@lotNo))          --当前批次
			                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
			        IF (ISNULL(@result,'')!='')
				        BREAK;			              
                    --获取历史可用库位          
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
				                AND (a.warehouseId=@warehouseId)					                    --目标仓库
				                AND (a.zoneId=@targZone)						                        --目标库区
				                AND (a.isDisable=0)									                    --有效库位
				                AND (a.isFixed=0)									                    --非固定库位
				                AND (a.isPackage=@isPackage)						                    --库位使用
				                AND (b.itemId=@itemId)                                                  --当前商品
			                    AND (@inventoryMode=0 OR(@inventoryMode=1 AND b.lotNo=@lotNo))          --当前批次
			                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
			        IF (ISNULL(@result,'')!='')
				        BREAK;
				    IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
                    BEGIN
                        SELECT TOP 1 @result=locationNo
                        FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty,
                                SUM(CASE ISNULL(b.itemId,'') WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
                            FROM BAS_Location a
                                LEFT JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							--公司Id
				                AND (a.warehouseId=@warehouseId)					--目标仓库
				                AND (a.zoneId=@targZone)						    --目标库区
				                AND (a.isDisable=0)									--有效库位
				                AND (a.isFixed=0)									--非固定库位
				                AND (a.isPackage=@isPackage)						--库位使用    
                                AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                        ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
			            IF (ISNULL(@result,'')!='')
				            BREAK;
				    END	
		        END
			    --3.2.2.批次管理，允许混放批次（不允许产品混放）；非批次管理(不允许产品混放）（排除法：排除其他任何有库存的商品所在的库位）
			    ELSE IF (@inventoryMode=1 AND @lotMix=1 AND @itemMix=0) OR (@inventoryMode=0 AND @itemMix=0) 
			    BEGIN
			        INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							--公司Id
                        AND (a.warehouseId=@warehouseId)					--目标仓库
				        AND (a.zoneId=@targZone)						    --目标库区
				        AND (a.isDisable=0)									--有效库位
				        AND (a.isFixed=0)									--非固定库位
				        AND (a.isPackage=@isPackage)						--库位使用
                        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							--公司Id
                        AND (a.warehouseId=@warehouseId)					--目标仓库
				        AND (a.zoneId=@targZone)						    --目标库区
				        AND (a.isDisable=0)									--有效库位
				        AND (a.isFixed=0)									--非固定库位
				        AND (a.isPackage=@isPackage)						--库位使用
				        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
                    --获取历史可用预分配库位                     
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
			                    AND (a.warehouseId=@warehouseId)					                    --目标仓库
			                    AND (a.zoneId=@targZone)						                        --目标库区
			                    AND (a.isDisable=0)									                    --有效库位
			                    AND (a.isFixed=0)									                    --非固定库位
			                    AND (a.isPackage=@isPackage)						                    --库位使用
			                    AND (b.itemId=@itemId)                                                  --当前商品
			                    AND (@inventoryMode=0 OR(@inventoryMode=1 AND b.lotNo=@lotNo))          --当前批次
			                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
			        IF (ISNULL(@result,'')!='')
				        BREAK;			              
                    --获取历史可用库位          
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
				                AND (a.warehouseId=@warehouseId)					                    --目标仓库
				                AND (a.zoneId=@targZone)						                        --目标库区
				                AND (a.isDisable=0)									                    --有效库位
				                AND (a.isFixed=0)									                    --非固定库位
				                AND (a.isPackage=@isPackage)						                    --库位使用
				                AND (b.itemId=@itemId)                                                  --当前商品
			                    AND (@inventoryMode=0 OR(@inventoryMode=1 AND b.lotNo=@lotNo))          --当前批次
			                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
			        IF (ISNULL(@result,'')!='')
				        BREAK;
				    IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
                    BEGIN
                        --获取可用库位                     
                        SELECT TOP 1 @result=locationNo
                        FROM (
                                SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty,
                                    SUM(CASE ISNULL(b.itemId,'') WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
                                FROM BAS_Location a
                                    LEFT JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							--公司Id
					                AND (a.warehouseId=@warehouseId)					--目标仓库
					                AND (a.zoneId=@targZone)						    --目标库区
					                AND (a.isDisable=0)									--有效库位
					                AND (a.isFixed=0)									--非固定库位
					                AND (a.isPackage=@isPackage)						--库位使用
                                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				        IF (ISNULL(@result,'')!='')
					        BREAK;
			        END
			    END
			    --3.2.3.批次管理，不允许批次混放，允许产品混放(排除法，不允许放在当前商品其他批次有库存的库位)
			    ELSE IF (@inventoryMode=1 AND @lotMix=0 AND @itemMix=1)
			    BEGIN
		            --当前产品（非当前批次）已经预分配的库位和系统已经存在的库位
			        INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							--公司Id
                        AND (a.warehouseId=@warehouseId)					--目标仓库
				        AND (a.zoneId=@targZone)						    --目标库区
				        AND (a.isDisable=0)									--有效库位
				        AND (a.isFixed=0)									--非固定库位
				        AND (a.isPackage=@isPackage)						--库位使用
                        AND (EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo!=t.lotNo))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							--公司Id
                        AND (a.warehouseId=@warehouseId)					--目标仓库
				        AND (a.zoneId=@targZone)						    --目标库区
				        AND (a.isDisable=0)									--有效库位
				        AND (a.isFixed=0)									--非固定库位
				        AND (a.isPackage=@isPackage)						--库位使用
				        AND (EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo!=t.lotNo))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
                    --获取历史可用预分配库位                     
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
			                    AND (a.warehouseId=@warehouseId)					                    --目标仓库
			                    AND (a.zoneId=@targZone)						                        --目标库区
			                    AND (a.isDisable=0)									                    --有效库位
			                    AND (a.isFixed=0)									                    --非固定库位
			                    AND (a.isPackage=@isPackage)						                    --库位使用
			                    AND (b.itemId=@itemId)                                                  --当前商品
			                    AND (@inventoryMode=0 OR(@inventoryMode=1 AND b.lotNo=@lotNo))          --当前批次
			                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
			        IF (ISNULL(@result,'')!='')
				        BREAK;			              
                    --获取历史可用库位          
                    SELECT TOP 1 @result=locationNo
                    FROM (
                            SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty
                            FROM BAS_Location a
                                INNER JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                            WHERE (a.companyId=@companyId)							                    --公司Id
				                AND (a.warehouseId=@warehouseId)					                    --目标仓库
				                AND (a.zoneId=@targZone)						                        --目标库区
				                AND (a.isDisable=0)									                    --有效库位
				                AND (a.isFixed=0)									                    --非固定库位
				                AND (a.isPackage=@isPackage)						                    --库位使用
				                AND (b.itemId=@itemId)                                                  --当前商品
			                    AND (@inventoryMode=0 OR(@inventoryMode=1 AND b.lotNo=@lotNo))          --当前批次
			                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                            GROUP BY a.locationNo,a.putawayOrder
                          ) t
                    ORDER BY onhandQty DESC,putawayOrder;
			        IF (ISNULL(@result,'')!='')
				        BREAK;
				    IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
                    BEGIN
                        SELECT TOP 1 @result=locationNo
                        FROM (
                                SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty,
                                    SUM(CASE WHEN b.itemId=@itemId AND b.lotNo=@lotNo THEN 1000
                                             WHEN b.itemId=@itemId OR b.lotNo=@lotNo THEN 1 
                                             ELSE 0 END) AS hisFlag
                                FROM BAS_Location a
                                    LEFT JOIN IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							--公司Id
					                AND (a.warehouseId=@warehouseId)					--目标仓库
					                AND (a.zoneId=@targZone)						    --目标库区
					                AND (a.isDisable=0)									--有效库位
					                AND (a.isFixed=0)									--非固定库位
					                AND (a.isPackage=@isPackage)						--库位使用
                                    AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				        IF (ISNULL(@result,'')!='')
					        BREAK;
			        END
			    END
			    --3.2.4.批次管理，允许混放批次（允许产品混放）,非批次管理(允许产品混放）（历史库位优先，其他任何库位都可）
			    ELSE IF (@inventoryMode=1 AND @lotMix=1 AND @itemMix=1) OR (@inventoryMode=0 AND @itemMix=1) 
			    BEGIN
				    --3.2.4.1.取预分配库位(历史)
				    SELECT TOP 1 @result=a.locationNo
			        FROM BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
			        WHERE (a.companyId=@companyId)							                --公司Id
				        AND (a.warehouseId=@warehouseId)					                --目标仓库
				        AND (a.zoneId=@targZone)						                    --目标库区
				        AND (a.isDisable=0)									                --有效库位
				        AND (a.isFixed=0)									                --非固定库位
				        AND (a.isPackage=@isPackage)						                --库位使用
				        AND (b.itemId=@itemId)							                    --历史商品
				        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者对应批次
				        AND (b.ioFlag='+')                                                  --预分配标识                           
				    ORDER BY b.allocQty DESC,a.putawayOrder;
				    IF (ISNULL(@result,'')!='')
					    BREAK;
			        --3.2.4.2.取库存表中的历史库位
			        SELECT TOP 1 @result=a.locationNo
				    FROM BAS_Location a 
					    INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
				    WHERE (a.companyId=@companyId)							                --公司Id
					    AND (a.warehouseId=@warehouseId)					                --目标仓库
					    AND (a.zoneId=@targZone)						                    --目标库区
					    AND (a.isDisable=0)									                --有效库位
					    AND (a.isFixed=0)									                --非固定库位
					    AND (a.isPackage=@isPackage)						                --库位使用
                        AND (b.itemId=@itemId)							                    --历史商品
				        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者对应批次
                    ORDER BY b.onhandQty DESC,a.putawayOrder;
				    IF (ISNULL(@result,'')!='')
					    BREAK;					
				    --3.2.4.3.从空库位开始
				    SELECT TOP 1 @result=locationNo
				    FROM (
						    SELECT a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)) AS onhandQty
						    FROM BAS_Location a 
							    LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						    WHERE (a.companyId=@companyId)							--公司Id
							    AND (a.warehouseId=@warehouseId)					--目标仓库
							    AND (a.zoneId=@targZone)						    --目标库区
							    AND (a.isDisable=0)									--有效库位
							    AND (a.isFixed=0)									--非固定库位
							    AND (a.isPackage=@isPackage)						--库位使用
							GROUP BY a.locationNo,a.putawayOrder
					    ) t
				    ORDER BY onhandQty DESC,putawayOrder;
				    IF (ISNULL(@result,'')!='')
					    BREAK;
				END
			END
		END
		FETCH NEXT FROM myPlicy INTO @putPolicy,@targRegion,@targLocation,@targZone,@itemMix,@lotMix,@isPackage,@putMode;
	END
	CLOSE myPlicy;
	DEALLOCATE myPlicy;
    RETURN ISNULL(@result,'');
END

go

