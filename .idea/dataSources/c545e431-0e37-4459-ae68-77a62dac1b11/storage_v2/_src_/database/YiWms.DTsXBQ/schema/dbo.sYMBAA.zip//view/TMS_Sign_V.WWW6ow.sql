

/*==============================================================*/
/* View: TMS_Sign_V                                             */
/*==============================================================*/
CREATE view [dbo].[TMS_Sign_V] as
SELECT a.fileId,a.waybillId,a.companyId,a.siteId,b.siteName,a.billType,CASE a.billType WHEN 10 THEN '销售出库单' 
																			WHEN 20 THEN '调拨出库单' 
																			WHEN 30 THEN '经营领用单' 
																			WHEN 31 THEN '管理领用单' 
																			WHEN 32 THEN '其他出库单'
																			WHEN 40 THEN '赠品出库单' 
																			WHEN 50 THEN '报损报废单'
																			WHEN 60 THEN '销售退货单'
																			WHEN 70 THEN '销售发票单'
																			WHEN 80 THEN '销售收款单'
																			WHEN 90 THEN '项目单' ELSE '运单' END billTypeName,
	a.stockNo,a.signName,a.signTime,a.signImage,billImage,a.isLocked,a.lockerId,u1.userNick AS lockerName,
	CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,a.creatorId,u2.userNick AS creatorName,
	a.editTime,a.editorId,u3.userNick AS editorName,a.isSelected	
FROM dbo.TMS_Sign a
	INNER JOIN dbo.TMS_Site b ON a.siteId=b.siteId
	LEFT  JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId
	LEFT  JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId
	LEFT  JOIN dbo.SAM_User u3 ON a.editorId=u3.userId

go

