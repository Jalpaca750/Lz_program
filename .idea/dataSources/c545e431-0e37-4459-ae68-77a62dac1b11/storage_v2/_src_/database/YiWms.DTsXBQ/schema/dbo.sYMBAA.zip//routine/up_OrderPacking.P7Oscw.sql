-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-09-20>
-- Description:	<Description:单独打包，并生成装箱清单>       
-- =============================================
CREATE PROCEDURE [dbo].[up_OrderPacking]
( 
	@packNo VARCHAR(32),				--装箱单No
	@billNo VARCHAR(32),				--装箱单编号
	@boxBillNum VARCHAR(32),			--箱号（等于装箱单编号)
	@boxNum INT,						--序号
	@companyId VARCHAR(32),				--公司Id
	@pickId VARCHAR(32),				--主任务Id
	@stockNo VARCHAR(32),				--出库单No
	@stockBillNo VARCHAR(32),			--出库单编号
	@customerId VARCHAR(32),			--客户Id
	@lineId VARCHAR(32),				--送货线路
	@regionId VARCHAR(32),				--集货区
	@lclCount INT,						--拼箱数
	@fclCount INT,						--整箱数
	@materialFlag INT,					--装箱材料
	@cartonId VARCHAR(32),				--包装材料规格Id
	@deskCode VARCHAR(32),				--复核打包台面编号
	@packState INT,						--装箱单状态
	@operatorId VARCHAR(32),			--操作员	
	@filter Filter_Type READONLY		--装箱明细（分拣任务明细Id)
)
AS
BEGIN
	DECLARE @fclQty DECIMAL(20,6),@lclQty INT,@cargoArea VARCHAR(32),@maxLclCount int;
	DECLARE @ownerId VARCHAR(32),@orderNo VARCHAR(32),@orderBillNo VARCHAR(32),@boneOrdNo VARCHAR(32);	
	DECLARE @boxId VARCHAR(32),@boxCode VARCHAR(32);
	DECLARE @tmpPackage TABLE(pickingId VARCHAR(32),packQty DECIMAL(20,6));
	DECLARE @tmpSUM TABLE(pickingId VARCHAR(32),packQty DECIMAL(20,6));
	DECLARE @tmpOrder TABLE(ownerId VARCHAR(32),orderNo VARCHAR(32),billNo VARCHAR(32),boneOrdNo VARCHAR(32), billCount INT);
	--处理包装材料
	DECLARE @eId VARCHAR(32),@itemId VARCHAR(32),@itemName VARCHAR(200),@locationNo VARCHAR(32),@regId VARCHAR(32),@warehouseId VARCHAR(32),@afterQty DECIMAL(20,6),@ioQty DECIMAL(20,6);
	--清理错误消息
	DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='up_OrderPacking' AND creatorId=@operatorId;
	BEGIN TRY
		BEGIN TRANSACTION 
		--出库单开始装箱则锁定出库单，避免多人同时装箱时拼箱数量不一致导致错误(暂借isSelected字段用)
		WHILE EXISTS(SELECT 1 FROM dbo.SAD_Stock WHERE stockNo=@stockNo AND isSelected=0)
		BEGIN
			UPDATE dbo.SAD_Stock SET isSelected=1 WHERE stockNo=@stockNo;
		END
		--转换到临时表
		INSERT INTO @tmpPackage(pickingId,packQty)
		SELECT a.pickingId,CAST(charKey AS DECIMAL(20,6))
		FROM dbo.WMS_PickingDetail a 
			INNER JOIN @filter b ON a.pickingId=b.charId; 
		--汇总当前装箱数量与已经装箱的数量
		INSERT INTO @tmpSUM(pickingId,packQty)
		SELECT pickingId,SUM(packQty)
		FROM (
			SELECT pickingId,packQty
			FROM @tmpPackage
			UNION ALL
			SELECT a.pickingId,a.packQty
			FROM dbo.WMS_PackingDetail a INNER JOIN @tmpPackage b ON a.pickingId=b.pickingId
			) t
		GROUP BY pickingId;
		--判断是否超过明细分拣数量
		IF EXISTS(SELECT 1 FROM dbo.WMS_PickingDetail a INNER JOIN @tmpSUM b ON a.pickingId=b.pickingId AND ISNULL(a.pickQty,0.0)-ISNULL(b.packQty,0.0)<0.0)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_OrderPacking','YI_ORDER_PACKING_QTY_ERROR','装箱数量超过了分拣数量，操作无效！',@packNo,@packNo);
			--释放出库单占用
			UPDATE dbo.SAD_Stock SET isSelected=0 WHERE stockNo=@stockNo;
			COMMIT;
			RETURN;
		END
		--取得出库单最大装箱序号
		IF EXISTS(SELECT 1 FROM dbo.WMS_Packing WHERE stockNo=@stockNo)
		BEGIN
			SELECT @boxNum=MAX(boxNum) FROM WMS_Packing WHERE companyId=@companyId AND stockNo=@stockNo;
			SELECT @boxNum=ISNULL(@boxNum,0)+1;
		END
		ELSE
		BEGIN
			SET @boxNum=1;
		END		
		--写入装箱单主表
		INSERT INTO WMS_Packing(packNo,billNo,boxBillNum,companyId,pickId,stockNo,stockBillNo,customerId,
			lineId,regionId,boxNum,lclCount,fclCount,materialFlag,cartonId,deskCode,packState,packingId,
			packingTime,printNum,printId,printTime,createTime,creatorId,editTime,editorId)
		VALUES(@packNo,@billNo,@boxBillNum,@companyId,@pickId,@stockNo,@stockBillNo,@customerId,@lineId,
			@regionId,@boxNum,@lclCount,@fclCount,@materialFlag,@cartonId,@deskCode,@packState,@operatorId,
			GETDATE(),0,'',NULL,GETDATE(),@operatorId,GETDATE(),@operatorId)
		--写入装箱单明细表
		INSERT INTO WMS_PackingDetail(packId,packNo,pickingId,pickId,pickingNo,companyId,warehouseId,
			regionId,lotNo,locationNo,eId,itemId,isPackage,pickQty,packQty,stockId,stockNo,stockBillNo,plasticId)
		SELECT LOWER(REPLACE(NEWID(),'-','')),@packNo,a.pickingId,a.pickId,a.pickingNo,a.companyId,a.warehouseId,
			a.regionId,a.batchNo,a.locationNo,a.eId,a.itemId,a.isPackage,a.pickQty,CAST(b.charKey AS DECIMAL(20,6)) AS packQty,
			a.stockId,a.stockNo,a.stockBillNo,b.charKey
		FROM dbo.WMS_PickingDetail a 
			INNER JOIN @filter b ON a.pickingId=b.charId;	
		--更新明细状态
		UPDATE a SET a.pickState=4
		FROM dbo.WMS_PickingDetail a 
			INNER JOIN @tmpSUM b ON a.pickingId=b.pickingId
		WHERE ISNULL(a.pickQty,0.0)-ISNULL(b.packQty,0.0)=0.0;
		--更新任务状态和释放周转箱
		DECLARE myCursor CURSOR
		FOR SELECT DISTINCT pickId 
			FROM WMS_PackingDetail 
			WHERE packNo=@packNo
		OPEN myCursor
		FETCH NEXT FROM myCursor INTO @pickId
		WHILE @@fetch_status=0 
		BEGIN
			--判断当前任务是否全部装箱，如果全部装箱，则更新任务状态为已装箱
			IF NOT EXISTS(SELECT 1 FROM WMS_PickingDetail WHERE pickId=@pickId AND pickState<=3)
			BEGIN
				--更新分拣任务订单状态
				UPDATE WMS_PickingOrder SET taskState=4,packingId=@operatorId,packingTime=GETDATE() WHERE pickId=@pickId;
				SELECT @boxId=boxId FROM WMS_PickingOrder WHERE pickId=@pickId;
				SELECT @boxCode=boxCode FROM WMS_Box WHERE boxId=@boxId; 
				--释放任务对应周转箱
				UPDATE WMS_Box SET isFrozen=0 WHERE boxId=@boxId;
				IF (@@ROWCOUNT>0)
				    INSERT INTO SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
				    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,GETDATE(),'up_OrderPacking','释放周转箱' + @boxCode,@pickId,'');
			END
			FETCH NEXT FROM myCursor INTO @pickId
		END
		CLOSE myCursor
		Deallocate myCursor			
		--最后一箱装完更新对应出库单装箱数（整箱数与拼箱数）
		IF NOT EXISTS(SELECT 1 FROM dbo.WMS_PickingOrder WHERE stockNo=@stockNo AND taskState<4)
		BEGIN
			SELECT @fclQty=SUM(pickQty) FROM dbo.WMS_PickingDetail WHERE stockNo=@stockNo AND isPackage=1;
			SELECT @lclQty=COUNT(1) FROM dbo.WMS_Packing WHERE stockNo=@stockNo;
			UPDATE dbo.SAD_Stock SET fclCount=CAST(@fclQty AS INT),lclCount=@lclQty,taskState=70,
				reviewTime=GETDATE(),reviewerId=@operatorId 
			WHERE stockNo=@stockNo;
			--更新出库单对应拼箱总数
			UPDATE dbo.WMS_Packing SET lclCount=@lclQty WHERE stockNo=@stockNo;			
			--2018-01-18日增加对F10状态的更新处理 V1.2.1 开始	
			INSERT INTO @tmpOrder(ownerId,orderNo,billNo,boneOrdNo)
			SELECT ownerId,orderNo,billNo,ISNULL(ordField2,'')
			FROM dbo.SAD_Order 
			WHERE orderNo IN(SELECT orderNo FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo);
			WHILE EXISTS(SELECT 1 FROM @tmpOrder)
			BEGIN
				SELECT TOP 1 @ownerId=ownerId,@orderNo=orderNo,@orderBillNo=billNo,@boneOrdNo=boneOrdNo FROM @tmpOrder ORDER BY billNo;
				--如果订单对应的出库单都已经打包
				UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='已出仓' WHERE OrderNo=@orderBillNo;			
				--写入订单配送节点表(和Bone平台表对应）（启用合并订单功能时，此处需修改）
				INSERT INTO SAD_OrderAction(stepId,orderNo,orderBillNo,stockNo,wmsStockNo,stockBillNo,[action],actionDesc,actionTime,companyId,ownerId,thirdSyncFlag)
				SELECT LOWER(REPLACE(NEWID(),'-','')),@boneOrdNo,@orderBillNo,@orderNo,@stockNo,@stockBillNo,6,'您的订单已经复核打包完成。',GETDATE(),@companyId,@ownerId,0
				WHERE NOT EXISTS(SELECT 1 FROM dbo.SAD_OrderAction WHERE orderNo=@boneOrdNo AND stockNo=@orderNo AND wmsStockNo=@stockNo AND [action]=6);
				--删除，下一个
				DELETE FROM @tmpOrder WHERE orderNo=@orderNo;
			END
			--2018-01-18日增加对F10状态的更新处理 V1.2.1 结束			
		END
		--装箱单对应出库单是否都在一个箱子，如果是，则指定集货区，否则指定到待发区		
		IF NOT EXISTS(SELECT 1 
					  FROM dbo.WMS_PickingDetail  
					  WHERE stockNo=@stockNo 
						AND stockId NOT IN(SELECT stockId FROM dbo.WMS_PackingDetail WHERE packNo=@packNo)
					 )
		BEGIN
			--重新获取集货区
			SELECT TOP 1 @cargoArea=regionId FROM dbo.BAS_LineRegion WHERE lineId=@lineId;
			UPDATE dbo.WMS_PickingOrder SET cargoArea=@cargoArea WHERE stockNo=@stockNo;
			UPDATE dbo.WMS_Packing SET regionId=@cargoArea WHERE packNo=@packNo;
		END
		--处理纸箱库存
		IF (@materialFlag=10)
		BEGIN
			--包装材料对应扣减临时库位、库区、仓库
			SELECT @warehouseId=warehouseId,@regId=regionId,@locationNo=locationNo FROM dbo.BAS_Worktable WHERE worktableId=@deskCode;
			SET @ioQty=-1.0;
			--包装材料对应商品Id
			SELECT @eId=eId,@itemId=itemId,@itemName=itemName FROM dbo.BAS_Goods_V WHERE itemNo=(SELECT sizeNo FROM dbo.WMS_BoxSize WHERE sizeId=@cartonId);					
			--更新商品库存
			UPDATE dbo.BAS_Item SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty WHERE itemId=@itemId;
			--更新仓库商品库存
			IF EXISTS(SELECT 1 FROM dbo.IMS_Ledger WHERE warehouseId=@warehouseId AND itemId=@itemId)
				UPDATE dbo.IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty WHERE warehouseId=@warehouseId AND itemId=@itemId;
			ELSE
				INSERT INTO dbo.IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastOTime)
				VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@eId,@itemId,@ioQty,0,GETDATE());
			--更新库位商品库存
			IF EXISTS(SELECT 1 FROM dbo.IMS_Stock WHERE warehouseId=@warehouseId AND locationNo=@locationNo AND itemId=@itemId)
				UPDATE dbo.IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty WHERE warehouseId=@warehouseId AND locationNo=@locationNo AND itemId=@itemId;
			ELSE
				INSERT INTO dbo.IMS_Stock(stockId,companyId,warehouseId,regionId,locationNo,lotNo,eId,itemId,onhandQty,allocQty,onWayQty,lastOTime)
				VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@regId,@locationNo,'',@eId,@itemId,@ioQty,0,0,GETDATE());
			--更新后库存
			SELECT @afterQty=ISNULL(onhandQty,0.0) FROM dbo.IMS_Stock WHERE warehouseId=@warehouseId AND locationNo=@locationNo AND itemId=@itemId;
			--写入流水账(领用出库)
			INSERT INTO dbo.IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,eId,itemId,befQty,ioQty,afterQty,createTime,creatorId,auditTime,auditorId,memo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),'L100',@companyId,@packNo,@packNo,@billNo,@operatorId,@warehouseId,'',@locationNo,@eId,@itemId,@afterQty-@ioQty,@ioQty,@afterQty,GETDATE(),@operatorId,GETDATE(),@operatorId,'出库单['+@stockBillNo+']对应['+@billNo+']箱号使用周转箱:'+@itemName);
		END
		--释放出库单占用
		UPDATE dbo.SAD_Stock SET isSelected=0 WHERE stockNo=@stockNo;
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_OrderPacking','YI_ORDER_PACKING_ERROR',LEFT(@ErrMsg,2000),'','');
		RAISERROR(@ErrMsg, @ErrSeverity, 1)					
	END CATCH
END

go

