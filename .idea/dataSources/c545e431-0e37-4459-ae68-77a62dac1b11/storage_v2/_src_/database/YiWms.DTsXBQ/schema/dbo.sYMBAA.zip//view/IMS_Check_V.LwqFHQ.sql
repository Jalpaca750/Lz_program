/*==============================================================*/
/* View: IMS_Check_V                                            */
/*==============================================================*/
--creator：        Frank
--create time：  2016-03-02
--盘点单视图 2017-04-01 V1.0 Frank.He重新整理
--			 2018-01-12 V1.2 调整经手人为盘点人;
CREATE view [dbo].[IMS_Check_V] as
SELECT a.checkNo,a.billNo,a.companyId,corp.companyName,a.pointId,b.pointNo,a.checkDate,
	a.warehouseId,c.warehouseNo,c.warehouseName,a.handlerId,u5.userNick AS handlerName,
	a.deptId,d.deptNo,d.deptName,a.billState,CASE a.billState WHEN 0 THEN '已作废' 
															WHEN 10 THEN '待审核' 
															WHEN 20 THEN '已审核' 
															WHEN 30 THEN '已完成' END AS stateName,
	a.memo,a.auditorId,u1.userNick AS auditorName,CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,
	a.isLocked,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.lockerId,u4.userNick AS lockerName, 
	a.createTime,a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName, 
	a.isSelected
FROM dbo.IMS_Check AS a 
	INNER JOIN dbo.SAM_Company AS corp ON a.companyId=corp.companyId 
	INNER JOIN dbo.BAS_Warehouse AS c ON a.warehouseId = c.warehouseId 
	INNER JOIN dbo.IMS_CheckPoint AS b ON a.pointId = b.pointId 
	LEFT JOIN dbo.BAS_Department AS d ON d.deptId = a.deptId 
	LEFT JOIN dbo.SAM_User AS u5 ON a.handlerId = u5.userId 
	LEFT JOIN dbo.SAM_User AS u1 ON a.auditorId = u1.userId 
	LEFT JOIN dbo.SAM_User AS u2 ON a.creatorId = u2.userId 
	LEFT JOIN dbo.SAM_User AS u4 ON a.lockerId = u4.userId  
	LEFT JOIN dbo.SAM_User AS u3 ON a.editorId = u3.userId

go

