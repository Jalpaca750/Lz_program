-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-02-06>
-- Description:	<Description:盘点单盘点完成> 
--      盘点完后更新盘点时刻表的盘点数量(realQty)
--      把盈亏数量写入IMS_Adjust表（调整表）和IMS_AdjustDetail                        
--      操作影响商品库存(BAS_Item表onhandQty)
--      仓库库存(IMS_Ledger表的onhandQty)，成本处理忽略不计
--      库位库存(IMS_Stock表) 
--      入出库流水帐(IMS_Book)
-- =============================================

CREATE PROCEDURE [dbo].[up_Audit_InvCheckFinished]
(
    @pointId VARCHAR(32),		--盘点设置Id
	@operatorId VARCHAR(32)		--操作员
)
AS
BEGIN	
	DECLARE @companyId VARCHAR(32),				--公司Id
			@pointNo VARCHAR(32),				--盘点期号
			@warehouseId VARCHAR(32),			--仓库Id
			@regionId VARCHAR(32),				--库区Id
			@locationWay VARCHAR(10),			--通道
			@inventory INT,						--未盘点到商品处理方式 0,保持原值;1,库存归零
			@checkState INT,					--当前盘点设置状态 0-已作废；10-待盘点；20-盘点中；30-已完成
			@YKFlag INT,						--盈亏标识
			@billNo VARCHAR(32),				--调整单编号
			@adjustNo VARCHAR(32),				--调整单No
			@billType INT,						--10-盘亏调整单;11-盘盈调整单;20-手工调亏单;21-手工调盈单
			@count INT,						
			@memo VARCHAR(200),					--备注
			@syncFlag INT,						--同步状态；0-待同步;-1无需同步;
			@pcsMode VARCHAR(200);				--盘点单同步模式：0,通过调整单同步；1,盘点单直接同步						
	DECLARE @createTime DATETIME				--过账时间
	SET @createTime=GETDATE();	
	DECLARE @tmpStock TABLE(stockId VARCHAR(32),pointId VARCHAR(32),companyId VARCHAR(32),ownerId VARCHAR(32),warehouseId VARCHAR(32),regionId VARCHAR(32),locationWay VARCHAR(10),lotNo VARCHAR(32),locationNo VARCHAR(32),eId VARCHAR(32),itemId VARCHAR(32),plQty DECIMAL(20,6),realQty DECIMAL(20,6),pkgRatio INT,YKFlag INT)
	--获取盘点设置
	SELECT @companyId=companyId,@warehouseId=warehouseId,@inventory=inventory,@checkState=checkState,@pointNo=pointNo
	FROM IMS_CheckPoint
	WHERE pointId=@pointId;
	--通过调整单同步
	SET @syncFlag=0;
	SET @memo=''
	--清除当前操作过程中的错误信息
	DELETE FROM SAM_Error WHERE companyId=@companyId AND creatorId=@operatorId AND funCode='up_Audit_InvCheckFinished';
	--盘点录入单据状态
	IF EXISTS(SELECT 1 FROM IMS_Check WHERE pointId=@pointId AND billState=10)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'up_Audit_InvCheckFinished','YI_INV_CHECK_WAITING_COUNT','盘点尚未完成，操作无效！',@pointId,@pointNo);
		RETURN;
	END
	--未盘点
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@pointId AND checkState=10) OR (NOT EXISTS(SELECT 1 FROM IMS_Check WHERE pointId=@pointId))
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'up_Audit_InvCheckFinished','YI_INV_CHECK_WAITING_COUNT','盘点尚未进行，操作无效！',@pointId,@pointNo);
		RETURN;
	END
	--已盘点
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@pointId AND checkState=30)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'up_Audit_InvCheckFinished','YI_INV_CHECK_AUDITED','盘点计划已经盘点完成，操作无效！',@pointId,@pointNo);
		RETURN;
	END
	--已盘点
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@pointId AND checkState=0)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'up_Audit_InvCheckFinished','YI_INV_CHECK_CLOSED','盘点计划已经作废，操作无效！',@pointId,@pointNo);
		RETURN;
	END
	BEGIN TRY
		BEGIN TRANSACTION		
		--盘点完成自己签出的计划（防止并发）
		UPDATE IMS_CheckPoint SET checkState=30,editTime=@createTime,editorId=@operatorId WHERE pointId=@pointId AND checkState=20 AND lockerId=@operatorId;
		if (@@ROWCOUNT>0)
		BEGIN
			--统计盘点数据(@inventory:0,保持原值;1,库存归零)
			UPDATE cs SET cs.realQty = CASE @inventory WHEN 0 THEN ISNULL(tmp.realQty,ISNULL(cs.onhandQty,0.0)) ELSE ISNULL(tmp.realQty,0.0) END
			FROM dbo.IMS_CheckStock cs LEFT JOIN
				(SELECT a.companyId,a.warehouseId,b.lotNo,b.locationNo,b.itemId,SUM(b.actQty) AS realQty
				 FROM dbo.IMS_Check a 
					INNER JOIN dbo.IMS_CheckDetail b ON a.checkNo=b.checkNo 
				 WHERE (a.pointId=@pointId) AND (a.billState=20)
				 GROUP BY a.companyId,a.warehouseId,b.lotNo,b.locationNo,b.itemId
				) tmp ON cs.companyId=tmp.companyId AND cs.warehouseId=tmp.warehouseId AND ISNULL(cs.lotNo,'')=ISNULL(tmp.lotNo,'') AND ISNULL(cs.locationNo,'')=ISNULL(tmp.locationNo,'') AND cs.itemId=tmp.itemId
			WHERE cs.pointId=@pointId;
			--盈亏数据
			INSERT INTO @tmpStock(stockId,pointId,companyId,warehouseId,ownerId,regionId,locationWay,lotNo,locationNo,eId,itemId,plQty,realQty,pkgRatio,YKFlag)
			SELECT cs.stockId,cs.pointId,cs.companyId,cs.warehouseId,bi.ownerId,cs.regionId,loc.locationWay,ISNULL(cs.lotNo,''),ISNULL(cs.locationNo,''),cs.eId,cs.itemId,
				ISNULL(cs.realQty,0.0)-ISNULL(cs.onhandQty,0.0) AS plQty,ISNULL(cs.realQty,0.0) AS realQty,bi.pkgRatio,
				CASE WHEN ISNULL(cs.realQty,0.0)-ISNULL(cs.onhandQty,0.0)>0 THEN 1 ELSE 0 END
			FROM dbo.IMS_CheckStock cs 
				INNER JOIN dbo.BAS_Item bi ON cs.itemId=bi.itemId 
				INNER JOIN dbo.BAS_Location loc ON cs.companyId=loc.companyId AND cs.warehouseId=loc.warehouseId AND cs.locationNo=loc.locationNo
			WHERE (cs.pointId=@pointId) AND (ISNULL(cs.realQty,0.0)-ISNULL(cs.onhandQty,0.0)!=0.0);
			--通过调整单同步，盘点单无需同步
			UPDATE IMS_Check SET billState=30,auditTime=@createTime,auditorId=@operatorId,editTime=@createTime,editorId=@operatorId,thirdSyncFlag=-1 WHERE pointId=@pointId;
			--如果有盘点盈亏数据
			IF EXISTS(SELECT 1 FROM @tmpStock)
			BEGIN
				--写入库存调整单处理
				DECLARE myStock CURSOR
				FOR
					SELECT companyId,warehouseId,YKFlag,COUNT(1)
					FROM @tmpStock
					GROUP BY companyId,warehouseId,YKFlag
				OPEN myStock
				FETCH NEXT FROM myStock INTO @companyId,@warehouseId,@YKFlag,@count
				WHILE @@FETCH_STATUS=0
				BEGIN
					--10-盘亏调整单;11-盘盈调整单;20-手工调亏单;21-手工调盈单
					IF @YKFlag>0
						SET @billType=11;
					ELSE
						SET @billType=10;
					--根据公司、仓库、盈亏，写入调整单（主表ownerId无效）
					EXEC up_CreateCode @companyId,'IMS_Adjust',@operatorId,@billNo OUTPUT;
					--调整单No
					--2018-01-27日调整，通过参数控制同步模式
					SET @adjustNo=LOWER(REPLACE(NEWID(),'-',''));
					INSERT INTO IMS_Adjust(adjustNo,billNo,companyId,billType,adjustDate,warehouseId,pointId,adjustReason,ioState,
						handlerId,isLocked,lockerId,lockedTime,createTime,creatorId,editTime,editorId,thirdSyncFlag,memo)
					VALUES(@adjustNo,@billNo,@companyId,@billType,CONVERT(VARCHAR(10),GETDATE(),23),@warehouseId,@pointId,'盘点调整',
						10,@operatorId,0,'',NULL,GETDATE(),@operatorId,GETDATE(),@operatorId,@syncFlag,@memo);
					--调整单明细
					INSERT INTO IMS_AdjustDetail(adjustId,adjustNo,companyId,ownerId,warehouseId,viewOrder,lotNo,locationNo,
						eId,itemId,ioQty,afterQty,pkgQty,bulkQty,fee,totalFee,remarks)			
					SELECT LOWER(REPLACE(NEWID(),'-','')),@adjustNo,@companyId,ownerId,warehouseId,ROW_NUMBER() OVER (ORDER BY locationNo) AS viewOrder,
						ISNULL(lotNo,''),locationNo,eId,itemId,plQty,realQty,
						CASE ISNULL(pkgRatio,0) WHEN 0 THEN 0.0 ELSE FLOOR(plQty/pkgRatio) END AS pkgQty,
						CASE ISNULL(pkgRatio,0) WHEN 0 THEN plQty ELSE (plQty % pkgRatio) END AS bulkQty,0.0,0.0,''
					FROM @tmpStock
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND YKFlag=@YKFlag;
					--调调整单审核存储过程
					EXEC up_Audit_InvAdjust @adjustNo,@operatorId;
					FETCH NEXT FROM myStock INTO @companyId,@warehouseId,@YKFlag,@count
				END
				CLOSE myStock
				DEALLOCATE myStock
			END
		END
		COMMIT
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000),@ErrSeverity int;
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'up_Audit_InvCheckFinished','YI_INV_CHECK_ERROR',LEFT(@ErrMsg,2000),@pointId,@pointNo);
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END CATCH
END
go

