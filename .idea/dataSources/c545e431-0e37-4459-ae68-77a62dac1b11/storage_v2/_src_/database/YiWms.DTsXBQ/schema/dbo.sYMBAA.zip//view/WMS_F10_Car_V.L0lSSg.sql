CREATE VIEW WMS_F10_Car_V
AS
SELECT a.carId,b.CodeID AS CarNo
FROM dbo.BAS_Car a 
    INNER JOIN F10BMS.dbo.BDM_CarNo_V b ON a.carNumber=b.CHName
go

