
/*==============================================================*/
/* View: IMS_TransferDetail_V                                   */
/*==============================================================*/
--creator： Frank
--create time：  2016-03-10
--移仓单明细表视图
create view IMS_TransferDetail_V as
SELECT dtl.transferId,dtl.transferNo,h.billNo,h.createTime,h.ioState,dtl.companyId,dtl.ownerId,
	o.partnerNo AS ownerNo,o.partnerName AS ownerName,o.shortName AS ownerShortName,dtl.viewOrder, 
	dtl.outputId,dtl.inputId,dtl.lotNo,dtl.outputNo,dtl.inputNo,l.isFixed,dtl.eId,dtl.itemId,sku.itemNo, 
	sku.itemCTitle,sku.itemETitle,sku.itemName,sku.itemSpell,sku.itemSpec,sku.sellingPoint,sku.barcode, 
	sku.midBarcode,sku.bigBarcode,sku.pkgBarcode,sku.brandId,sku.brandNo,sku.brandCName,sku.brandEName,
	sku.categoryId,sku.categoryNo,sku.categoryCName,sku.categoryEName,sku.unitName,sku.itemWeight,
	sku.itemVolume,sku.pkgUnit,sku.pkgRatio,sku.colorName,sku.sizeName,sku.isUnsalable,sku.isStop,
	sku.isVirtual,sku.allowDiscount,dtl.unitId,s1.onhandQty,dtl.ioQty,dtl.pkgQty,dtl.bulkQty,dtl.price, 
	dtl.taxrate,dtl.taxPrice,dtl.fee,dtl.taxFee,dtl.totalFee,dtl.remarks,dtl.isSelected
FROM dbo.IMS_Transfer AS h 
	INNER JOIN dbo.IMS_TransferDetail AS dtl ON h.transferNo = dtl.transferNo 
	INNER JOIN dbo.BAS_Goods_V AS sku ON dtl.itemId = sku.itemId 
	LEFT JOIN dbo.BAS_Partner o ON dtl.ownerId=o.partnerId
	LEFT JOIN dbo.IMS_Stock AS s2 ON dtl.companyId = s2.companyId AND dtl.inputId = s2.warehouseId AND ISNULL(dtl.lotNo,'') = ISNULL(s2.lotNo,'') AND ISNULL(dtl.inputNo,'') = ISNULL(s2.locationNo,'') AND dtl.itemId=s2.itemId 
	LEFT JOIN dbo.IMS_Stock AS s1 ON dtl.companyId = s1.companyId AND dtl.outputId = s1.warehouseId AND ISNULL(dtl.lotNo,'') = ISNULL(s1.lotNo,'') AND ISNULL(dtl.outputNo,'') = ISNULL(s1.locationNo,'') AND dtl.itemId=s1.itemId 
	LEFT JOIN dbo.BAS_Location AS l ON dtl.inputId = l.warehouseId AND ISNULL(dtl.inputNo,'') = ISNULL(l.locationNo,'')
go

