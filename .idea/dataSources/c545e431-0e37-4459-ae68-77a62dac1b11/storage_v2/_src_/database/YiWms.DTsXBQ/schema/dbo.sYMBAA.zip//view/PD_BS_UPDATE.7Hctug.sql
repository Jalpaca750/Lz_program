CREATE VIEW PD_BS_UPDATE
as
SELECT 
a.billNo AS DANJ_NO,a.thirdSyncFlag AS SC_FLG,A.by_thirdSyncTime AS SC_FLAG_TIME
FROM dbo.IMS_Adjust a  
WHERE  (a.thirdSyncFlag=0 or a.thirdSyncFlag=2) 
go

