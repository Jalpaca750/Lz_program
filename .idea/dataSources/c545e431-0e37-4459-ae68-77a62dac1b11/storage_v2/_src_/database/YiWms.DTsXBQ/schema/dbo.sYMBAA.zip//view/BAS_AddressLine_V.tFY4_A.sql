
/*==============================================================*/
/* View: BAS_AddressLine_V                                      */
/*==============================================================*/
-- Author:		Frank.He
-- Create date: 2017-11-11
-- Description:	送货线路视图         
-- Ver：        V1.2
create view BAS_AddressLine_V as
SELECT a.lineId,a.lineCode,a.lineName,a.companyId,a.isDisable,CASE a.isDisable WHEN 1 THEN '是' ELSE '否' END AS isDisableName,
	a.isLocked,a.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,a.creatorId,
	u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName,a.isSelected 
FROM dbo.BAS_AddressLine a 
	LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId
go

