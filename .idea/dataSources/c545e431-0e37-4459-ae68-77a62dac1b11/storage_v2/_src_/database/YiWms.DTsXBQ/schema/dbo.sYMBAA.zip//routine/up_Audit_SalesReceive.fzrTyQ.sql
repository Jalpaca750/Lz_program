-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2016-12-20>
-- Description:	<Description:退货入库单收货处理（生成上架数据(预分配表和历史表））>
-- 依赖：
--      采购上架策略
--      对应函数(dbo.uf_GetPurchaseLocation)      
--      按单位，序号排序（解决整件、散件问题）
--      Frank.He 2017-05-05 重新计算上架整件与散件
-- =============================================
CREATE PROCEDURE [dbo].[up_Audit_SalesReceive] 
(
    @returnNo VARCHAR(32),			--退货单No(主键）
	@operatorId VARCHAR(32)			--操作员
)
AS
BEGIN
	DECLARE @returnId VARCHAR(32),			--退货入库单明细Id
            @billNo VARCHAR(32),			--退货单号
            @billType VARCHAR(32),			--单据类型
            @partnerId VARCHAR(32),			--上架对象（客户）
			@companyId VARCHAR(32),			--公司Id
			@ownerId VARCHAR(32),			--业主Id
			@warehouseId VARCHAR(32),		--仓库Id
			@itemId VARCHAR(32),			--商品Id
			@recBin VARCHAR(32),			--收货库位(过渡库位)
			@receiveQty DECIMAL(20,6),		--收货数量
			@lotNo VARCHAR(32),				--批次号
			@orderSource INT,				--订单类型
			@unitLevel VARCHAR(10),			--单位级别
			@orderNo VARCHAR(32),			--订单主表No
			@viewOrder INT,					--序号
			@pkgRatio INT;                  -- 转换规格		
	DECLARE @regionId VARCHAR(32),			--区域
			@locationNo VARCHAR(32),		--库位（上架库位）
			@needRollBack INT,              --1-需要回滚（主要是未找到上架库位）
			@tmpId INT,                      --临时库位表主键Id
			@putawayNo VARCHAR(32),			--上架主表No
			@flowId VARCHAR(32);			--主键Id
	--用于存储临时数据
	DECLARE @temp TABLE(stockId VARCHAR(32),companyId VARCHAR(32),ownerId VARCHAR(32),warehouseId VARCHAR(32),orderSource VARCHAR(32),itemId VARCHAR(32),receiveQty DECIMAL(20,6),pkgRatio INT,lotNo VARCHAR(32),recBin VARCHAR(32),unitLevel VARCHAR(10),orderNo VARCHAR(32),viewOrder INT IDENTITY(1,1));
	--临时存放库位表（体积限制）
	DECLARE @uTable TABLE(viewOrder INT,warehouseId VARCHAR(32),regionId VARCHAR(32),itemId VARCHAR(32),locationNo VARCHAR(32),lotNo VARCHAR(32),SQty DECIMAL(20,6));
	BEGIN TRY
		BEGIN TRANSACTION	
        --单据编号
		SELECT @billNo=billNo,@billType=ioType,@partnerId=customerId FROM SAD_Return WHERE returnNo=@returnNo;        		
		INSERT INTO @temp(stockId,companyId,ownerId,warehouseId,orderSource,itemId,receiveQty,pkgRatio,lotNo,recBin,unitLevel,orderNo)
		SELECT returnId,companyId,ownerId,warehouseId,orderSource,itemId,receiveQty,pkgRatio,lotNo,recBin,unitLevel,orderNo
		FROM (
				--整箱上架(临时数据）
				SELECT b.returnId,a.companyId,a.ownerId,a.warehouseId,30 AS orderSource,b.itemId,
					FLOOR(b.returnQty/bi.pkgRatio) AS receiveQty,bi.pkgRatio,b.lotNo,'' AS recBin,'CS' AS unitLevel,
					b.orderNo,b.viewOrder 
				FROM dbo.SAD_Return a 
					INNER JOIN dbo.SAD_ReturnDetail b ON a.returnNo=b.returnNo
					INNER JOIN dbo.BAS_Item bi ON b.itemId=bi.itemId
				WHERE a.returnNo=@returnNo AND FLOOR(b.returnQty/bi.pkgRatio)>0
				UNION ALL
				SELECT b.returnId,a.companyId,a.ownerId,a.warehouseId,30 AS orderSource,b.itemId,
					(b.returnQty % bi.pkgRatio) AS receiveQty,bi.pkgRatio,b.lotNo,'' AS recBin,'EA' AS unitLevel,
					b.orderNo,b.viewOrder 
				FROM dbo.SAD_Return a 
					INNER JOIN dbo.SAD_ReturnDetail b ON a.returnNo=b.returnNo
					INNER JOIN dbo.BAS_Item bi ON b.itemId=bi.itemId
				WHERE a.returnNo=@returnNo AND (b.returnQty % bi.pkgRatio)>0
			) t 
		ORDER BY unitLevel,viewOrder	
		--如果没有需要上架的数据（全部非实物商品）
        IF NOT EXISTS(SELECT * FROM @temp)
        BEGIN
            --更新入库单
		    UPDATE SAD_Return SET ioState=30,editTime=GETDATE(),editorId=@operatorId,auditTime=GETDATE(),auditorId=@operatorId WHERE returnNo=@returnNo;
        END
        ELSE
        BEGIN 
		    --取得上架数据	
		    DECLARE myStock CURSOR
		FOR 
			SELECT stockId,companyId,ownerId,warehouseId,orderSource,itemId,receiveQty,pkgRatio,lotNo,recBin,unitLevel,orderNo,viewOrder
			FROM @temp
			ORDER BY unitLevel,viewOrder;
		    OPEN myStock;
		    FETCH NEXT FROM myStock INTO @returnId,@companyId,@ownerId,@warehouseId,@orderSource,@itemId,@receiveQty,@pkgRatio,@lotNo,@recBin,@unitLevel,@orderNo,@viewOrder;
		    WHILE @@FETCH_STATUS=0
		    BEGIN
		        --生成上架库位
			    INSERT INTO @uTable(viewOrder,warehouseId,regionId,locationNo,lotNo,itemId,SQty)
			    SELECT viewOrder,warehouseId,regionId,locationNo,lotNo,itemId,SQty
			    FROM dbo.uf_GetPurchaseLocation(@companyId,@ownerId,@warehouseId,@itemId,@recBin,@receiveQty,@lotNo,@orderSource,@unitLevel)
			    IF NOT EXISTS(SELECT * FROM @uTable)
			    BEGIN
			        SET @needRollBack=1
			        BREAK;
			    END
			    --循环生产上架数据
			    WHILE EXISTS(SELECT * FROM @uTable)
			    BEGIN
			        SELECT TOP 1 @tmpId=viewOrder,@locationNo=locationNo,@regionId=regionId FROM @uTable ORDER BY viewOrder;
			        --判断上架主表是否已经写入
			        IF NOT EXISTS(SELECT 1 FROM WMS_Putaway WHERE stockNo=@returnNo AND unitLevel=@unitLevel)
			        BEGIN
				        SET @putawayNo =REPLACE(NEWID(),'-','');	
				        INSERT INTO WMS_Putaway(putawayNo,billType,stockNo,billNo,partnerId,companyId,ownerId,warehouseId,regionId,unitLevel,ioState,isLocked,lockerId,lockedTime,createTime,creatorId)
				        VALUES(@putawayNo,@billType,@returnNo,@billNo,@partnerId,@companyId,@ownerId,@warehouseId,@regionId,@unitLevel,20,0,'',NULL,GETDATE(),@operatorId);
			        END
			        --写入上架清单
			        SET @flowId=REPLACE(NEWID(),'-','');
			        INSERT INTO WMS_PutawayDetail(flowId,putawayNo,stockId,stockNo,companyId,warehouseId,viewOrder,lotNo,locationNo,itemId,unitLevel,putQty,ioState,createTime,creatorId,pkgRatio)
			        VALUES(@flowId,@putawayNo,@returnId,@returnNo,@companyId,@warehouseId,@viewOrder,@lotNo,@locationNo,@itemId,@unitLevel,@receiveQty,20,GETDATE(),@operatorId,@pkgRatio);
			        --写入预分配表
			        INSERT INTO IMS_Allocate(allocId,stockId,stockNo,companyId,warehouseId,regionId,locationNo,lotNo,itemId,allocQty,ioFlag,unitLevel)
			        VALUES(@flowId,@returnId,@returnNo,@companyId,@warehouseId,@regionId,@locationNo,@lotNo,@itemId,@receiveQty,'+',@unitLevel);
			        --删除临时表
				    DELETE FROM @uTable WHERE viewOrder=@tmpId;
				END
			    FETCH NEXT FROM myStock INTO @returnId,@companyId,@ownerId,@warehouseId,@orderSource,@itemId,@receiveQty,@pkgRatio,@lotNo,@recBin,@unitLevel,@orderNo,@viewOrder
		    END
		    CLOSE myStock;
		    DEALLOCATE myStock;
		    --更新为待上架
            UPDATE SAD_Return SET ioState=20,editTime=GETDATE(),editorId=@operatorId,auditTime=GETDATE(),auditorId=@operatorId WHERE returnNo=@returnNo;
		END
        --缺少库位，需要回滚事务，并写入日志	
		IF (@needRollBack=1)
		BEGIN
		    IF (@@TRANCOUNT > 0)
                ROLLBACK;
            --写日志
            INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_Audit_SalesReceive','YI_SALES_RECEIVE_IS_ERROR','未找到存储商品的库位，操作无效!',@returnNo,@billNo);
		END
		ELSE
		BEGIN
		    COMMIT;
		END 
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int;
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_Audit_PurReceive','YI_PURCHASE_RECEIVE_IS_ERROR',LEFT(@ErrMsg,2000),@returnNo,@billNo);		
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END CATCH
END
go

