CREATE PROCEDURE [dbo].[proc_FinishShip] 
(
    @companyId VARCHAR(32),			--公司ID
	@shipNo VARCHAR(32),			--发车单号
	@editorId VARCHAR(32)           --操作员
)
AS
BEGIN
	------------完成发车判断是否整单没捡------------------------------------------
	DECLARE @orderQty INT=0,@actQty INT=0
	DECLARE m_cursor CURSOR SCROLL FOR
	SELECT billNo FROM WMS_ShipDetail WHERE shipNo=@shipNo AND companyId=@companyId
	OPEN  m_cursor
	DECLARE @stockNo varchar(32),@orderNo varchar(32)
	FETCH NEXT FROM m_cursor INTO @stockNo
	WHILE @@FETCH_STATUS=0
	BEGIN 
		-----订单-------
		DECLARE o_cursor CURSOR SCROLL FOR
		SELECT DISTINCT orderNo FROM SAD_StockDetail WHERE stockNo=@stockNo AND companyId=@companyId
		OPEN  o_cursor
		FETCH NEXT FROM o_cursor INTO @orderNo
		WHILE @@FETCH_STATUS=0
		BEGIN 
			-----判断是否拆单-----
	        IF NOT EXISTS(SELECT 1 FROM SAD_OrderDetail od 
								LEFT JOIN SAD_StockDetail os ON od.orderId=os.orderId
								WHERE od.orderNo=@orderNo AND os.orderId IS NULL AND os.stockNo=@stockNo)
			BEGIN
				SELECT @orderQty=COUNT(1) FROM SAD_OrderDetail WHERE orderNo=@orderNo And orderQty > 0
				SELECT @actQty=COUNT(1) FROM SAD_StockDetail_V WHERE orderNo=@orderNo AND actQty=0
				IF(@orderQty=@actQty)		
				BEGIN
					UPDATE SAD_Stock SET ioState = 0,editorId =@editorId,editTime = GETDATE() WHERE stockNo=@stockNo AND companyId=@companyId And ioState>0;
					UPDATE SAD_Order SET sdState = 0,editorId =@editorId,editTime = GETDATE() WHERE orderNo=@orderNo AND companyId=@companyId And sdState>0;
				END
				
			END
			-----判断是否拆单-----
		   FETCH NEXT FROM o_cursor INTO @orderNo
		END
		CLOSE o_cursor
		DEALLOCATE o_cursor

		FETCH NEXT FROM m_cursor INTO @stockNo
	END
	CLOSE m_cursor
	DEALLOCATE m_cursor
END
go

