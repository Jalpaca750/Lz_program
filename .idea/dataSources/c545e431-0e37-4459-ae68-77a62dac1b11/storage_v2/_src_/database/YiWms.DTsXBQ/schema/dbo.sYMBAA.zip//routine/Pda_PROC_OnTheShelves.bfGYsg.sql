

/*
    Creator:   ZDY
    CreateDate:2017-03-17
    Descr:PDA 上架
    Edit in 2019-04-18 zdy  部分上架 
*/
CREATE   Proc  [dbo].[Pda_PROC_OnTheShelves]
( 
     @flowId varchar(32),--上架清单详细表主键 
     @locationNo varchar(32), --货位编码
     @stockAllocQty decimal(20,6),--上架数量
     @putQty        decimal(20,6),--上架数量
     @operatorId varchar(32) --操作人
)
AS
DECLARE @stockId varchar(32)='',@regionId   varchar(32)--区域
DECLARE @stockNo varchar(32)='',@billCode varchar(100),@IMS_STOCKID varchar(32)
DECLARE @itemId   varchar(32)=''
DECLARE @eId      varchar(32)=''
DECLARE @lotNo    varchar(100)=''
DECLARE @unitLevel varchar(100)='' 
DECLARE @companyId varchar(32)=''
DECLARE @warehouseId varchar(32)=''
DECLARE @allocQty decimal(20,6)=0
DECLARE @billType varchar(100)  
DECLARE @FLAG int=0,@errorSum int =0,
@hadQty decimal(20,6)=0,@resultQty decimal(20,6)=0,@IS_RETURN INT=0,
@PUT_AWAY_NO VARCHAR(32),--上架单编码
@tempPutQty decimal(20,6),--总上架数量
@tempflowId varchar(32)=replace(newid(),'-','')  ---临时的flowId
DECLARE @deptId  varchar(32)   --业务部门针对虚拟业务
DECLARE @TEMP_QTY decimal(20,6)=0---   用来计算上架的
--------------------------------------------------------------------------------------------
BEGIN  Tran
if not exists(select * from WMS_PutawayDetail WHERE   flowId=@flowId and ioState<30)  
begin   
    set  @errorSum=1
end
else  begin
  SELECT  @PUT_AWAY_NO=putawayNo,@stockId=stockId,@stockNo=stockNo
          ,@companyId=companyId,@warehouseId=warehouseId,
          @itemId=itemid,@unitLevel=unitLevel
         ,@tempPutQty=putQty,@lotNo=lotNo
  FROM    WMS_PutawayDetail_V
  WHERE   flowId=@flowId
 ----部分上架
 IF  @tempPutQty-@putQty>0
 BEGIN
   ------插入任务表200000 
   INSERT INTO WMS_PutawayDetail(flowId,putawayNo,stockId,stockNo,
    companyId,warehouseId,viewOrder,lotNo,locationNo,eId,itemId,unitLevel,
    putQty,ioState,putawayId,putawayTime,createTime,creatorId,pkgRatio)
   SELECT   @tempflowId flowId,putawayNo,stockId,stockNo,
   companyId,warehouseId,viewOrder,lotNo,locationNo,eId,itemId,unitLevel,
   (@tempPutQty-@putQty) putQty,20 ioState,null putawayId,null putawayTime,GETDATE() createTime,creatorId,pkgRatio
   FROM    WMS_PutawayDetail 
   WHERE   flowId=@flowId
   ------插入临时占用表
   insert into  IMS_Allocate(allocId,stockId,stockNo,companyId,
   warehouseId,regionId,locationNo,lotNo,itemId,allocQty,unitLevel,ioFlag)
   SELECT  @tempflowId allocId,stockId,stockNo,companyId,
   warehouseId,regionId,locationNo,lotNo,itemId,(@tempPutQty-@putQty),unitLevel,ioFlag
   FROM  IMS_Allocate WHERE allocId=@flowId
   
 END ---如果上架数量大于要上架的数量
 ELSE IF @tempPutQty<@putQty
 BEGIN
    set  @errorSum=1
    rollback;
    return;
 END 
  
  
      
  
---上架清单同步
update  WMS_PutawayDetail set  locationNo=@locationNo,ioState=30,
 putawayId=@operatorId, 
 putawayTime=GETDATE()
where  flowId=@flowId 
--putawayNo=@PUT_AWAY_NO and  stockId=@stockId and unitLevel=@unitLevel 
set @errorSum=@errorSum+@@ERROR
  
  ----如果是退货单
  IF EXISTS(SELECT * FROM SAD_Return WHERE returnNo=@stockNo)
  BEGIN
       set  @IS_RETURN=1;--退货单
        set  @billType='S200'
       select @billCode=billNo,@deptId=deptId from SAD_Return where  returnNo=@stockNo
  END   
  ELSE BEGIN   --入库单
      ---入库单
     set  @IS_RETURN=0;--采购单
     set  @billType='P100'
	select @billCode=billNo,@deptId=deptId from PMS_Stock where  stockNo=@stockNo
  END
	
  ---上架数量  整包装散包装已经换算的
  set  @allocQty=@stockAllocQty
  ---区域
  SELECT @regionId=regionId
  from BAS_Location where warehouseId=@warehouseId and locationNo=@locationNo
  ---商品
  select @eId=eid from ECM_ItemSku where itemId=@itemId
  
/*--------------------------------------找库存中商品是否存在---------------------------------------------------------*/  
  
if not exists(select * from IMS_Stock where  companyId=@companyId and warehouseId=@warehouseId and  itemId=@itemId and isnull(lotNo,'')=isnull(@lotNo,'') and isnull(locationNo,'')=isnull(@locationNo,''))
begin
			---如果库里面没有 进行插入
			insert into  IMS_Stock(stockId,companyId,warehouseId,lotNo,locationNo,eId,itemId,onhandQty,
			allocQty,price,taxrate,taxPrice,fee,totalFee,lastITime,lastIPrice,
			lastITaxPrice,lastOTime,lastOPrice,lastOTaxPrice,regionId)
			values
			(
			   REPLACE(NEWID(),'-',''),@companyId,@warehouseId,@lotNo,@locationNo,@eId,@itemId,
			   0,0,0,17,0,0,0,GETDATE(),0,0,null,0,0,@regionId
			)
			 set @errorSum=@errorSum+@@ERROR
end 
----如果主表里面没有的
if not exists(select * from IMS_Ledger where companyId=@companyId and warehouseId=@warehouseId and  itemId=@itemId)
begin 
	insert into IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,
	allocQty,price,taxrate,taxPrice,
	fee,totalFee,maxDays,minDays,maxQty,
	minQty,stabilityRate,lastITime,lastIPrice,lastITaxPrice,lastOTime,lastOPrice,lastOTaxPrice)
	values(replace(NEWID(),'-',''),@companyId,@warehouseId,@eId,@itemId,0,0,0,17,0,
	0,0,0,0,0,0,0,GETDATE(),0,0,null,0,0)
	 set @errorSum=@errorSum+@@ERROR
end 

-------------------------如果对应的虚拟表里面没有数据
/*
IF EXISTS(select * from IMS_DeptLedger_MAP where companyId=@companyId and warehouseId=@warehouseId AND IsDisable=0) AND ISNULL(@deptId,'')!=''
BEGIN
     IF NOT EXISTS(SELECT ledgerId FROM IMS_DeptLedger WHERE companyId=@companyId and deptId=@deptId and itemid=@itemId)
     BEGIN  ---新增
		insert into IMS_DeptLedger(ledgerId,companyId,deptId,eId,itemId,onhandQty,
		allocQty,price,taxrate,taxPrice,
		fee,totalFee,maxDays,minDays,maxQty,
		minQty,stabilityRate,lastITime,lastIPrice,lastITaxPrice,lastOTime,lastOPrice,lastOTaxPrice)
		values(replace(NEWID(),'-',''),@companyId,@deptId,@eId,@itemId,@allocQty,0,0,16,0,
		0,0,0,0,0,0,0,GETDATE(),0,0,null,0,0)
		set @errorSum=@errorSum+@@ERROR
     END  
     ELSE BEGIN  --修改
		update  IMS_DeptLedger set  onhandQty=(onhandQty+@allocQty),lastOTime=GETDATE(),lastITime=GETDATE()
		where   companyId=@companyId and deptId=@deptId and itemid=@itemId
		set @errorSum=@errorSum+@@ERROR
     END 
END
*/
-------------------------------------------------------------------------------------------------------------


-----修改库存
select @IMS_STOCKID=stockId,@hadQty=onhandQty  from IMS_Stock 
where  companyId=@companyId 
and warehouseId=@warehouseId 
and  itemId=@itemId 
and isnull(lotNo,'')=isnull(@lotNo,'') 
and isnull(locationNo,'')=isnull(@locationNo,'')
--赋值
set @resultQty=@hadQty+@allocQty
INSERT INTO IMS_Book(
[bookId],[ioType],[companyId],[billId],[billNo],[billCode],[objectId],[warehouseId],
[lotNo],[locationNo],[eId],[itemId],[befQty],[taxFlag],
[discount],[discountFee],[ioQty],[price],[fee],[taxFee],[afterQty],[handlerId],[deptId],[createTime],
[creatorId],[auditorId],[auditTime],[memo])
values(REPLACE(NEWID(),'-',''),
@billType
,@companyId,@stockId,@stockNo,@billCode,@stockId,
@warehouseId,@lotNo,@locationNo,@eId,@itemId,@hadQty,null,null,null,@stockAllocQty,null,null,null,@resultQty,@operatorId,
null,GETDATE(),@operatorId,@operatorId,GETDATE(),'PDA')
set @errorSum=@errorSum+@@ERROR
/****************************************更新库存*****************************/
update  IMS_Stock set  onhandQty=(onhandQty+@allocQty),lastOTime=GETDATE(),lastITime=GETDATE()
where  stockId=@IMS_STOCKID
set @errorSum=@errorSum+@@ERROR

update  IMS_Ledger set  onhandQty=onhandQty+@allocQty,lastOTime=GETDATE(),lastITime=GETDATE()
where   companyId=@companyId and warehouseId=@warehouseId and itemId=@itemId
set @errorSum=@errorSum+@@ERROR
---------------------------------------删除
DELETE  IMS_Allocate WHERE allocId=@flowId
--DELETE  IMS_Allocate WHERE   stockId=@stockId and unitLevel=@unitLevel

-----------------------------------------------------------------------------------------------
IF   @IS_RETURN=1  --退货
BEGIN
    if exists(select allocId from IMS_Allocate where stockNo =@stockNo)
    BEGIN   --部分上架
           UPDATE SAD_Return  
           SET ioState=25,
           editTime=GETDATE(),
           editorId=@operatorId,
           auditTime=GETDATE()
           WHERE returnNo=@stockNo
           set @errorSum=@errorSum+@@ERROR
    END ELSE
    BEGIN  --全部上架
          UPDATE SAD_Return  SET ioState=30,
                             editTime=GETDATE(),
                             editorId=@operatorId,
                             auditTime=GETDATE()  
          WHERE returnNo=@stockNo
          set @errorSum=@errorSum+@@ERROR
    END
END ELSE
BEGIN
---------------------------------------------------详细同步上架状态---------------------------
if exists(select allocId from IMS_Allocate where stockId=@stockId)
begin  --部分上架了
	 UPDATE PMS_StockDetail SET ioState=25 ,putawayTime=GETDATE(),
	 putawayId=@operatorId,locationNo=@locationNo     
	 where stockId=@stockId
	 set @errorSum=@errorSum+@@ERROR
end 
else begin  --全部上架了
	  UPDATE PMS_StockDetail SET ioState=30 ,putawayTime=GETDATE(),
	 putawayId=@operatorId,locationNo=@locationNo     
	 where stockId=@stockId
	 set @errorSum=@errorSum+@@ERROR
end
-----------------------------------------------入库单同步状态----------------------------------
if exists(select allocId from IMS_Allocate where stockNo =@stockNo)
BEGIN
UPDATE PMS_Stock SET ioState=25,editorId=@operatorId,editTime=GETDATE() WHERE stockNo=@stockNo  
END ELSE 
BEGIN
UPDATE PMS_Stock SET ioState=30,editorId=@operatorId,editTime=GETDATE() WHERE stockNo=@stockNo  
END	
-----------------------------------------------------------------------------------------------
END 
--======================================================如果全部上架了就把单子状态改了=======
 if exists(select flowId from WMS_PutawayDetail where putawayNo=@PUT_AWAY_NO and ioState<30)
 begin --如果还有没有上架的
      update  WMS_Putaway  set ioState=25 ,putawayId=@operatorId,putawayTime=GETDATE()
      where putawayNo=@PUT_AWAY_NO  
      set @errorSum=@errorSum+@@ERROR
 end
 else 
 begin  --上架单里面的东西上架完成了
      update  WMS_Putaway  set ioState=30 ,putawayId=@operatorId,putawayTime=GETDATE()
      where putawayNo=@PUT_AWAY_NO  
      set @errorSum=@errorSum+@@ERROR
 end
--------------------------------------------------------------------------------------------------
end
if @errorSum>0  
begin
Rollback
end
else begin
commit;
end





go

