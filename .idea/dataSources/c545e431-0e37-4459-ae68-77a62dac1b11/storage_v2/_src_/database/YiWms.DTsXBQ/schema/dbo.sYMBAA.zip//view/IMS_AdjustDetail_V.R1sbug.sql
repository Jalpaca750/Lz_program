
/*==============================================================*/
/* View: IMS_AdjustDetail_V                                     */
/*==============================================================*/
--creator： Frank
--create time：  2016-12-29
--调整单明细表视图
create view IMS_AdjustDetail_V as
SELECT a.adjustId,a.adjustNo,b.billNo,b.adjustDate,b.ioState,a.companyId,a.ownerId,a.warehouseId,
	a.viewOrder,a.lotNo,a.locationNo,a.eId,a.itemId,sku.itemNo,sku.itemCTitle,sku.itemETitle,
	sku.itemName,sku.itemSpec,sku.itemSpell,sku.sellingPoint,sku.barcode,sku.midBarcode,sku.bigBarcode,
	sku.pkgBarcode,sku.brandId,sku.brandNo,sku.brandCName,sku.brandEName,sku.categoryId,sku.categoryNo,
	sku.categoryCName,sku.categoryEName,sku.colorName,sku.sizeName,a.unitId,sku.unitName,a.ioQty,a.pkgQty,
	a.bulkQty,a.afterQty,ISNULL(a.afterQty,0.0)-ISNULL(a.ioQty,0.0) AS onhandQty,sku.pkgRatio,a.fee,a.totalFee,
	sku.pkgUnit,sku.inventoryMode,sku.isSafety,sku.safetyMonth,sku.safetyDays,sku.isUnsalable,sku.isStop,
	sku.isVirtual,a.remarks,a.isSelected
FROM dbo.IMS_AdjustDetail a 
	INNER JOIN dbo.IMS_Adjust b ON a.adjustNo=b.adjustNo 
	INNER JOIN dbo.BAS_Goods_V sku on a.itemId=sku.itemId
go

