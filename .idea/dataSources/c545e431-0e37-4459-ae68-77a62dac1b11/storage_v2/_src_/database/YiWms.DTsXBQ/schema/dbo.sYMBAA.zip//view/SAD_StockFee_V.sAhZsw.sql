
/*==============================================================*/
/* View: SAD_StockFee_V                                         */
/*==============================================================*/
create view SAD_StockFee_V as
SELECT dtl.stockNo,SUM(CAST(pk.actQty*dtl.price AS DECIMAL(20,2))) AS totalFee
       FROM dbo.SAD_StockDetail dtl INNER JOIN
             (SELECT stockId,SUM(CASE isPackage WHEN 0 THEN pickQty WHEN 1 THEN pickQty * realQty END) AS actQty
              FROM WMS_PickingDetail
	          WHERE pickQty>0.0
	          GROUP BY stockId) pk ON dtl.stockId=pk.stockId 
       GROUP BY dtl.stockNo
go

