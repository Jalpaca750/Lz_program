
/*==============================================================*/
/* View: WMS_ReplenishPolicy_V                                  */
/*==============================================================*/
create view WMS_ReplenishPolicy_V as
SELECT a.policyId,a.companyId,a.ownerId,o.ownerNo,o.ownerName,a.warehouseId,w.warehouseNo,w.warehouseName,
      a.categoryId,cat.categoryNo,cat.categoryCName,a.brandId,b.brandNo,b.brandCName,a.viewOrder,a.calcMode,
      CASE a.calcMode WHEN 1 THEN '按库存补充' WHEN 2 THEN '按销量补充' END AS calcModeDesc,a.mdFlag,a.calcTime,
      a.replenishRate,a.isDisable,CASE a.isDisable WHEN 1 THEN '是' ELSE '否' END AS isDisableName,
      a.isLocked,a.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
      a.createTime,a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName,
      a.isSelected
FROM dbo.WMS_ReplenishPolicy a 
      INNER JOIN dbo.BAS_Owner_V o ON a.ownerId=o.ownerId 
      INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId 
      LEFT JOIN dbo.BAS_Category cat ON a.categoryId=cat.categoryId
      LEFT JOIN dbo.BAS_Brand b ON a.brandId=b.brandId
      LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId 
      LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId 
      LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId
go

