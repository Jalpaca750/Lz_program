


/*==============================================================*/
/* View: WMS_PutawayPolicy_V                                    */
/*==============================================================*/
--creator：     Frank
--create time： 2016-12-12 日整理 
--Modify:       Frank 2018-12-28日 增加policyType字段
--上架策略视图
CREATE view [dbo].[WMS_PutawayPolicy_V] as
SELECT a.policyId,a.policyDesc,a.policyType,a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,a.ownerId, 
	o.ownerNo,o.ownerName,a.putPolicy,a.recLocation,a.targRegion,r.regionNo AS targRegionNo, 
	r.regionDesc AS targRegionDesc,a.targZone,z.zoneDesc,a.targLocation,a.allowVolumed,a.allowLonger,a.allowWider,
	a.allowHigher,a.itemMix,CASE a.itemMix WHEN 1 THEN '是' ELSE '否' END AS itemMixDesc,
	a.lotMix,CASE a.lotMix WHEN 1 THEN '是' ELSE '否' END AS lotMixDesc, a.isPackage,
	CASE a.isPackage WHEN 10 THEN '件拣货库位' WHEN 20 THEN '箱拣货库位' WHEN 40 THEN '储货位库位' WHEN 50 THEN '过渡库位' END AS packageDesc,
	a.putMode,CASE a.putMode WHEN 1 THEN '储位放满优先' WHEN 2 THEN '空货位优先' END AS putModeDesc, 
    a.categoryId,cat.categoryNo,cat.categoryCName,a.orderSource,
    CASE a.orderSource WHEN 11 THEN '普通订单' WHEN 12 THEN '应急订单' WHEN 13 THEN '零采购' WHEN 14 THEN '转场订单' WHEN 21 THEN '调拨入库单' END AS sourceDesc,
    a.unitLevel,CASE a.unitLevel WHEN 'EA' THEN '件' WHEN 'CS' THEN '箱' WHEN 'PL' THEN '托盘' WHEN 'OT' THEN '其他' END AS unitLevelDesc,
    a.isDisable,CASE a.isDisable WHEN 1 THEN '是' ELSE '否' END AS disableName,a.viewOrder,
    a.isLocked,a.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime, 
    a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName,a.isSelected
FROM dbo.WMS_PutawayPolicy AS a 
    INNER JOIN dbo.BAS_Warehouse AS w ON a.warehouseId = w.warehouseId 
    INNER JOIN dbo.BAS_Owner_V AS o ON a.ownerId = o.ownerId 
    LEFT JOIN dbo.BAS_Region AS r ON a.targRegion = r.regionId 
    LEFT JOIN dbo.BAS_Zone AS z ON a.targZone=z.zoneId
    LEFT JOIN dbo.BAS_Category AS cat ON a.categoryId = cat.categoryId 
    LEFT JOIN dbo.SAM_User AS u1 ON a.lockerId = u1.userId 
    LEFT JOIN dbo.SAM_User AS u2 ON a.creatorId = u2.userId 
    LEFT JOIN dbo.SAM_User AS u3 ON a.editorId = u3.userId
go

