
/***************************************************************************************
-- 2020-07-08  @zdy      API 出库单回传明细   视图
-- 
*****************************************************************************************/
CREATE VIEW  [dbo].[API_XSCK_MX]
AS
SELECT a.stockNo PKID,o.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,ISNULL(_dtlp.ordDtlEx03,a.mergeNo) AS SHANGJ_DANJ_NO,
    ISNULL(dtl.viewOrder,_dtlp.vieworder) AS linenum,_item.itemNo AS itemcode,
    (CASE dtl.isVirtual WHEN 1 THEN ISNULL(dtl.stockQty,0) ELSE ISNULL(dtl.pickQty,0) END) AS quantity,
    ISNULL(dtl.stockQty,_dtlp.stockQty)  squantity,
    ISNULL(dtl.price,_dtlp.price) price,ISNULL(dtl.befPrice,_dtlp.befPrice) befPrice,
    (CASE dtl.isVirtual WHEN 1 THEN CAST( ISNULL(dtl.stockQty,0)*ISNULL(dtl.price,0) AS DECIMAL(20,2)) 
                        ELSE CAST(ISNULL(dtl.pickQty,0)*ISNULL(dtl.befPrice,0) AS DECIMAL(20,2))  END)  AS linetotal,
    _dtlp.viewOrder AS HANGHAO,ISNULL(dtl.remarks,_dtlp.remarks) lineNotes,W.warehouseNo AS WHNO,
    _dtlp.ordDtlEx01,_dtlp.ordDtlEx02,_dtlp.ordDtlEx03,_dtlp.ordDtlEx04,_dtlp.ordDtlEx05
FROM SAD_OrderDetail _dtlp  with(nolock)
    INNER JOIN dbo.SAD_Order _order with(nolock) ON _dtlp.orderNo=_order.orderNo
    INNER JOIN dbo.SAD_Stock a  with(nolock) ON A.mergeNo=_order.billNo and a.ordertype=_order.ordertype
    LEFT  JOIN  SAD_StockDetail dtl with(nolock) ON _dtlp.orderId=dtl.orderId   
    LEFT JOIN BAS_Warehouse  W with(nolock) ON a.warehouseId=W.warehouseId
    LEFT JOIN dbo.BAS_Partner c with(nolock) ON a.customerId=c.partnerId 
    LEFT JOIN  BAS_Item _item with(nolock) ON _dtlp.itemId=_item.itemId
    LEFT JOIN BAS_Owner_V o ON a.ownerId=o.ownerId 
    LEFT JOIN dbo.SAM_User u with(nolock) ON a.creatorId=u.userId
WHERE (a.taskState>=60) AND a.ioState > 0
      AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2) 


go

