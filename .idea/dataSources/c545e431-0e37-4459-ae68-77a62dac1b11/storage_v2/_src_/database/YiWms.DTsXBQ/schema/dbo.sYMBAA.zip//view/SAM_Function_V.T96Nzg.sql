
/*==============================================================*/
/* View: SAM_Function_V                                         */
/*==============================================================*/
--creator：        Frank
--create time：    2016-09-24
--modify:          2017-11-22 整理V1.2
create view SAM_Function_V as
SELECT f.functionId,f.functionType,f.functionCode,f.functionName,f.formUrl,f.winUrl,f.opCode,
	f.imageOpen,f.imageClose,f.parentId,p.functionCode AS parentCode,p.functionName AS parentName,   
	f.functionDesc,f.[action],f.isDisable,f.viewOrder, 
	(SELECT productName + ';' 
	 FROM (SELECT pf.productCode,pf.functionId,p.productName
           FROM dbo.SAM_ProductFunction pf INNER JOIN 
				dbo.SAM_YiProduct p ON pf.productCode=p.productCode) t 
	 WHERE f.functionId=t.functionId 
     FOR XML PATH('')
	) AS productList,f.isLocked,f.lockerId,u1.userNick AS lockerName,
	CONVERT(VARCHAR(20),f.lockedTime,120) AS lockedTime,f.createTime,f.creatorId,u2.userNick AS creatorName,
	f.editTime,f.editorId,u3.userNick AS editorName,f.isSelected      
FROM dbo.SAM_Function f 
	LEFT JOIN dbo.SAM_Function p ON f.parentId=f.functionId 
	LEFT JOIN dbo.SAM_User u1 ON f.lockerId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON f.creatorId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON f.editorId=u3.userId
go

