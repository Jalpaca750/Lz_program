

create view [dbo].[XSCK_HZ_QT_YSC] as

/*此视图SAP需要用，请勿改动*/

SELECT o.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,a.mergeNo AS SHANGJ_DANJ_NO,c.customerNo AS CARDCODE,
	CONVERT(VARCHAR(10),a.auditTime,23) AS docdate,0 AS totalFee,a.memo AS comments,u.userNo AS U_opcode,
	u.userNick AS U_OPNAME,0 AS discprcnt,w.warehouseNo AS whNo,
	CASE a.orderType WHEN 10 THEN '销售出库' 
					 WHEN 30 THEN '经营领用' 
					 WHEN 31 THEN '管理领用' 
					 WHEN 40 THEN '赠品出库' 
					 WHEN 50 THEN '报损报废' END AS YEW_TYPE,a.thirdSyncFlag AS SC_FLG
FROM dbo.SAD_Stock a INNER JOIN
      dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId INNER JOIN
      dbo.BAS_Customer_V c ON a.customerId=c.customerId LEFT JOIN
      dbo.BAS_Owner_V o ON a.ownerId=o.ownerId LEFT JOIN 
      dbo.SAM_User u ON a.creatorId=u.userId
WHERE ( a.orderType=30 OR a.orderType=31 OR a.orderType=40 OR a.orderType=50)
      AND (a.taskState>=60) 
      AND (a.thirdSyncFlag=1)

go

