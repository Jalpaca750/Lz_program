

-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-08-22>
-- Description:	<Description:同步F10商品资料到WMS>
--      @companyId：公司Id
--      @ownerId：业主Id
--      @creatorId：操作员Id
--      @startTime：同步开始时间 yyyy-MM-dd HH:mm:ss格式
--      @endTime：同步截至时间 yyyy-MM-dd HH:mm:ss格式
-- =============================================

CREATE Proc  [dbo].[up_SyncF10Item]
(
    @companyId VARCHAR(32),		--公司Id,如果前台调用，需传值，为空时，手动修改这个值
	@ownerId VARCHAR(32),		--业主Id
	@creatorId VARCHAR(32),		--操作员，前天调用的当前用户，后台执行时，可赋值
	@startTime DATETIME,		--同步产品的开始时间（修改时间）
	@endTime DATETIME			--同步产品的截至时间（修改时间）
)
AS
BEGIN
	DECLARE @itemNo VARCHAR(32)
	DECLARE @item TABLE(itemId BIGINT,itemNo VARCHAR(32));
	--如果接口正在同步中，则直接退出
	IF EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Item' AND isLocked=1)
		RETURN;
	--获取需要同步的数据
	INSERT INTO @item(itemId,itemNo)
	SELECT itemId,itemNo 
	FROM F10BMS.dbo.BDM_ItemInfo 
	WHERE syncFlag=0;
	IF NOT EXISTS(SELECT 1 FROM @item)
		RETURN;	
	--1.锁定同步接口
	UPDATE dbo.SAM_Store SET isLocked=1,lockerId=@creatorId,lockedTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Item';
	--开始同步
	BEGIN TRY 	
		BEGIN TRANSACTION
		--2.同步商品资料
		WHILE EXISTS(SELECT 1 FROM @item)
		BEGIN
			--取第一个商品
			SELECT TOP 1 @itemNo=itemNo FROM @item ORDER BY itemId; 
			--同步
			EXEC F10BMS.dbo.sp_AfterItemSaved @itemNo;
			--同步成功后更新同步状态
			UPDATE F10BMS.dbo.BDM_ItemInfo SET syncFlag=1 WHERE ItemNo=@itemNo;
			--删除同步成功的临时商品
			DELETE FROM @item WHERE itemNo=@itemNo;
		END
		--3.释放同步接口
		UPDATE dbo.SAM_Store SET isLocked=0,lockerId='',syncTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Item';
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		--释放同步接口
		UPDATE dbo.SAM_Store SET isLocked=0,lockerId='' WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Item';
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int;
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END CATCH
END 

go

