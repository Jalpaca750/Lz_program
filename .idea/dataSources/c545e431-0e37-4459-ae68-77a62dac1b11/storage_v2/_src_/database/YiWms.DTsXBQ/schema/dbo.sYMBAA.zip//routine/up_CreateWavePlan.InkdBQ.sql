

-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-05-09>
-- Description:	<Description:手动生成波茨分拣计划（摘果法） V9.3>
-- 原uf_CreateWaveTask分支算法
-- 依赖：
--      分配策略
--      上架策略
--      周转箱规格
--      库存数量
--      销售出库单
--      补货表
--      分配策略取得产品对应的仓库、库区、批次等数据
--      对应函数(uf_GetPickLocation)
--               uf_GetPutawayLocation
--      对比以前算法增加了自动拆分出库单功能（散件拼箱数为N)
--      自动补货（被动补货） ,同时把补货的可用量与在途量增加到数据中
--      V4.0增加单品拆箱，并修正3.0版本6.2节点Bug
--      V6.0再次回到V1.0模式，按单据进行分配，并占用库存
--      V7.0单品爆箱（1个）时取最大箱
--      V8.0拼箱，没库存的等
--      V9.0增加单条商品拆零控制，整件任务按商品生成，补货任务按商品生成任务
--      V9.2增加虚拟商品过滤处理
--      V9.3增加整件区存在散件的处理和增加补货任务生成控制
-- =============================================

CREATE PROCEDURE [dbo].[up_CreateWavePlan] 
(
	@stocks Filter_Type READONLY,	--charId对应StockNo字段
    @companyId VARCHAR(32),			--公司Id
	@creatorId VARCHAR(32)			--操作员
)
AS
BEGIN
    DECLARE @stockId VARCHAR(32),				--出库单明细Id
			@stockNo VARCHAR(32),				--出库单No
			@shipNo VARCHAR(32),				--装车单No
			@warehouseId VARCHAR(32),			--仓库Id
			@ownerId VARCHAR(32),				--业主Id
			@regionId VARCHAR(32),				--库区Id
			@lotNo VARCHAR(32),					--批次编号
			@locationNo VARCHAR(32),			--库位编号
			@toLocationNo VARCHAR(32),			--库位编号
			@viewOrder INT,						--序号
			@itemId VARCHAR(32),				--产品Id
			@itemNo VARCHAR(32),				--商品编码
			@itemVolume DECIMAL(20,6),			--散件体积
			@pkgRatio INT,						--包装数量
			@pickingMode INT,					--分拣模式0-自动分拆；1-散件；2-整箱
			@allowSplit INT,					--允许单条拆单
			@stockQty DECIMAL(20,6),			--出库单（订单）数量
			@bulkQty DECIMAL(20,6),				--散件数量	
			@pkgQty DECIMAL(20,6),				--整箱数量
			@pickQty DECIMAL(20,6),				
			@availQty DECIMAL(20,6),
			@totalQty DECIMAL(20,6),
			@needQty DECIMAL(20,6),
			@bhQty DECIMAL(20,6)				--补货数量
	DECLARE @policyId VARCHAR(32),				--策略Id
			@lineId VARCHAR(32),				--线路Id
			@logisticsId VARCHAR(32),			--物流公司Id
			@orderType VARCHAR(32),				--订单类型
			@minRows INT,						--订单Sku条目数（最小）
			@maxRows INT,						--订单Sku条目数（最大）
			@minOrders INT,						--最小订单数
			@maxOrders INT,						--最大订单数
			@limitedVolumn DECIMAL(10,2),		--最大体积
			@limitedWeight DECIMAL(20,3),		--最大总量
			@unitLevel VARCHAR(10)				--EA-散件;CS-整箱
	DECLARE @lclVolumn DECIMAL(20,6),			--拼箱体积
			@lclQty INT,						--拼箱数
			@maxVolumn DECIMAL(20,6),			--最大箱规
			@maxBoxes INT,						--最大拼箱数
			@sumVolumn DECIMAL(20,6),			--散件体积累计
			@bulkVolumn DECIMAL(20,6),			--散件体积
			@boxCount INT,						--临时变量
			@boxIndex INT,						--临时变量
			@sizeId VARCHAR(32),				--周转箱规格
			@waveNo VARCHAR(32),				--波茨No
			@waveBillNo VARCHAR(32),			--波茨编号
			@waveCount INT,						--波茨策略存在最大订单数时的波茨数
			@waveIndex INT,						--波茨索引
			@billNo	VARCHAR(32),				--波茨编号
			@pickingNo VARCHAR(32),				--分拣任务No
			@pickBillNo VARCHAR(32),			--分拣任务编号
			@pickId VARCHAR(32),				--任务订单Id			
			@itemBoxes INT,						--单品装箱数（单品拆箱）
			@itemCount INT,						--单品数量（单品拆箱）
			@detailId INT						--明细id
	DECLARE @createTime DATETIME,
			@replenishId VARCHAR(32),
			@errorMsg VARCHAR(2000),
			@maxSizeId VARCHAR(32),
			@pickOrder INT,
			@replenishBillNo VARCHAR(32),
			@replenishQty DECIMAL(20,6),
			@waveAlgorithm VARCHAR(200),
			@replenishTaskMode VARCHAR(200)		--补货任务模式；1-按单条商品生成补货任务;0-按波茨生成补货任务
			
	SET @createTime=GETDATE();	
	--存储需要生成波茨的出库单
	DECLARE @tmpHead TABLE(viewOrder INT,stockNo VARCHAR(32),billNo VARCHAR(32),warehouseId VARCHAR(32),ownerId VARCHAR(32),lineId VARCHAR(32),logisticsId VARCHAR(32),orderType INT,skuCount INT,lclVolumn DECIMAL(20,6),maxBoxes INT,flag INT);
	DECLARE @tmpDetail TABLE(stockId VARCHAR(32),stockNo VARCHAR(32),billNo VARCHAR(32),viewOrder INT,ownerId VARCHAR(32),warehouseId VARCHAR(32),itemId VARCHAR(32),itemNo VARCHAR(32),stockQty DECIMAL(20,6),bulkQty DECIMAL(20,6),pkgQty DECIMAL(20,6),itemVolume DECIMAL(20,6),pkgRatio INT,pickingMode INT,boxNum INT DEFAULT 1,sizeId VARCHAR(32),shipNo VARCHAR(32),allowSplit INT,printNum INT);
	DECLARE @sales TABLE(policyId VARCHAR(32),stockNo VARCHAR(32),viewOrder INT,stockId VARCHAR(32),bulkVolumn DECIMAL(20,6),pickQty DECIMAL(20,6),itemVolume DECIMAL(20,6),allowSplit INT);
	--库位表
	DECLARE @tmpLocation TABLE(viewOrder INT,warehouseId VARCHAR(32),regionId VARCHAR(32),lotNo VARCHAR(32),locationNo varchar(32),itemId VARCHAR(32),pickQty DECIMAL(20,6),needReplenish INT);
	--补货下架数据
	DECLARE @tmpReplenish TABLE(replenishId VARCHAR(32),stockId VARCHAR(32),stockNo VARCHAR(32),viewOrder INT,warehouseId VARCHAR(32),regionId VARCHAR(32),lotNo VARCHAR(32),locationNo varchar(32),itemId VARCHAR(32),pickQty DECIMAL(20,6),toRegionId VARCHAR(32),toLocationNo varchar(32),needReplenish INT,pkgQty INT,pkgRatio INT);
	--临时分配表
	DECLARE @tmpAllocate TABLE(detailId INT IDENTITY(1,1),stockId VARCHAR(32),stockNo VARCHAR(32),billNo VARCHAR(32),warehouseId VARCHAR(32),ownerId VARCHAR(32),regionId VARCHAR(32),lotNo VARCHAR(32),locationNo VARCHAR(32),itemId VARCHAR(32),unitLevel VARCHAR(10),pickQty DECIMAL(20,6),realQty DECIMAL(20,6),pkgRatio INT,itemVolume DECIMAL(10,3),boxNum INT DEFAULT 1,sizeId VARCHAR(32),shipNo VARCHAR(32),allowSplit INT);
	--临时分拣表
	DECLARE @tmpPick TABLE(pickOrder INT IDENTITY(1,1),stockId VARCHAR(32),stockNo VARCHAR(32),stockBillNo VARCHAR(32),ownerId VARCHAR(32),warehouseId VARCHAR(32),regionId VARCHAR(32),itemId VARCHAR(32),batchNo VARCHAR(32),locationNo VARCHAR(32),pickQty DECIMAL(20,6),isPackage INT,itemVolume DECIMAL(20,6),pkgRatio INT,boxNum INT,sizeId VARCHAR(32),shipNo VARCHAR(32));
	--清除错误日志
	DELETE FROM SAM_Error WHERE companyId=@companyId AND funCode='up_CreateWaveTask' AND creatorId=@creatorId;
	--启用单条商品拆零控制时拼箱算法
	SELECT @waveAlgorithm=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='WAVE_TASK_ALGORITHM_LCL';
	SET @waveAlgorithm = ISNULL(@waveAlgorithm,'1');
	--补货任务模式；1-按单条商品生成补货任务;0-按波茨生成补货任务
	SELECT @replenishTaskMode=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='WAVE_TASK_REPLENISH_MODE';
	SET @replenishTaskMode = ISNULL(@replenishTaskMode,'0');
	--最大箱规
	SELECT @maxVolumn = MAX(boxVolume) FROM WMS_BoxSize WHERE companyId=@companyId AND boxType=1;
	--最大箱
	SELECT TOP 1 @maxSizeId=sizeId FROM WMS_BoxSize WHERE companyId=@companyId AND boxType=1 AND boxVolume=@maxVolumn;
	--如果没有维护周转箱规格，则直接退出（写错误日志）
	IF (ISNULL(@maxVolumn,0.0)=0.0)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_NON_BOXSIZE','请您先维护周转箱规格！','','');
		RETURN;
	END
	--粗略检查是否设置件/箱分配策略
	IF NOT EXISTS(SELECT 1 FROM WMS_PickingPolicy WHERE companyId=@companyId AND isDisable=0 AND (unitLevel='EA' OR unitLevel='CS')) 
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_NON_PICKING_POLICY','请您先维护配货策略！','','');
		RETURN;
	END
	--粗略检查是否设置件上架策略
	IF NOT EXISTS(SELECT 1 FROM WMS_PutawayPolicy WHERE companyId=@companyId AND isDisable=0 AND (unitLevel='EA')) 
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_NON_PUTAWAY_POLICY','请您先维护上架策略！','','');
		RETURN;
	END		
	BEGIN TRY
		BEGIN TRANSACTION		
		--1.摘出当前需要编制计划的单据
		--订单数据（发车单状态10-待发出，出库单30-已排车的数据）
		--统计出库单，仓库、业主、线路、物流公司、单据类型、每单SKU数、总体积、总重量等
		IF NOT EXISTS(SELECT 1 FROM @stocks)
			INSERT INTO @tmpHead(viewOrder,stockNo,billNo,warehouseId,ownerId,lineId,logisticsId,orderType,skuCount,lclVolumn,maxBoxes,flag)
			SELECT ROW_NUMBER() OVER (ORDER BY a.billNo),a.stockNo,a.billNo,a.warehouseId,a.ownerId,a.lineId,a.logisticsId,
				a.orderType,b.skuCount,1 AS lclVolumn,1 AS maxBoxes,a.flag
			FROM dbo.SAD_Stock a INNER JOIN
				(SELECT stockNo,COUNT(1) AS skuCount
				 FROM SAD_StockDetail
				 GROUP BY stockNo) b ON a.stockNo=b.stockNo
			WHERE (a.companyId=@companyId) 
				AND (a.stockNo=ANY(SELECT y.billNo FROM WMS_Ship x INNER JOIN WMS_ShipDetail y ON x.shipNo=y.shipNo WHERE x.shipState='10'))
				AND (a.taskState=30);--10-待审核；20-已审核；30-已排车；40-待配货；50-已配货(待复核)；60-待发货； 70-已发货
		ELSE
			INSERT INTO @tmpHead(viewOrder,stockNo,billNo,warehouseId,ownerId,lineId,logisticsId,orderType,skuCount,lclVolumn,maxBoxes,flag)
			SELECT ROW_NUMBER() OVER (ORDER BY a.billNo),a.stockNo,a.billNo,a.warehouseId,a.ownerId,a.lineId,a.logisticsId,
				a.orderType,b.skuCount,b.lclVolumn,1 AS maxBoxes,a.flag
			FROM dbo.SAD_Stock a INNER JOIN
				(SELECT stockNo,COUNT(1) AS skuCount,SUM(bulkVolumn) AS lclVolumn
				 FROM SAD_StockDetail
				 GROUP BY stockNo) b ON a.stockNo=b.stockNo
			WHERE EXISTS(SELECT 1 FROM @stocks c WHERE a.stockNo=c.charId)
				AND (a.taskState=30)--10-待审核；20-已审核；30-已排车；40-待配货；50-已配货(待复核)；60-待发货； 70-已发货
		--如果没有需要生成计划的单据
		IF NOT EXISTS(SELECT 1 FROM @tmpHead)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_NO_DATA','没有需要生成波茨计划的数据！','','');
			COMMIT;
			RETURN;
		END			
		--出库单明细,为避免重复,特把装箱No(shipNo)字段取消，改为任务完成后更新
		INSERT INTO @tmpDetail(stockId,stockNo,billNo,viewOrder,ownerId,warehouseId,itemId,itemNo,stockQty,bulkQty,pkgQty,
			itemVolume,pkgRatio,pickingMode,shipNo,allowSplit,printNum)
		SELECT a.stockId,b.stockNo,b.billNo,a.viewOrder,b.ownerId,a.warehouseId,a.itemId,bi.itemNo,a.stockQty,
			(ISNULL(a.stockQty,0.0) % bi.pkgRatio) AS bulkQty,FLOOR(ISNULL(a.stockQty,0.0)/bi.pkgRatio) AS pkgQty,
			bi.itemVolume,bi.pkgRatio,bi.pickingMode,'',bi.allowSplit,CASE bi.printControl WHEN 1 THEN -1 ELSE 0 END
		FROM SAD_StockDetail a 
			INNER JOIN @tmpHead b ON a.stockNo=b.stockNo
			INNER JOIN BAS_Item bi ON a.itemId=bi.itemId
		WHERE a.isVirtual=0
		ORDER BY b.billNo,a.viewOrder
		--更新明细发车单号
		UPDATE a SET a.shipNo=b.shipNo 
		FROM @tmpDetail a INNER JOIN WMS_ShipDetail b ON a.stockNo=b.billNo;
		
		--2.对发货进行预分配
		--循环需要分拣的单据和产品
		DECLARE myCursor CURSOR
		FOR SELECT stockId,stockNo,billNo,warehouseId,ownerId,itemId,stockQty,pkgRatio,pickingMode,itemVolume,shipNo,allowSplit
			FROM @tmpDetail
			ORDER BY billNo,viewOrder 
		OPEN myCursor
		FETCH NEXT FROM myCursor INTO @stockId,@stockNo,@billNo,@warehouseId,@ownerId,@itemId,@stockQty,@pkgRatio,@pickingMode,@itemVolume,@shipNo,@allowSplit
		WHILE @@FETCH_STATUS=0
		BEGIN
			--判断可用量是否足够整仓
			SELECT @availQty=SUM(ISNULL(onhandQty,0.0)-ISNULL(allocQty,0.0)+ISNULL(onwayQty,0.0))
			FROM IMS_Stock
			WHERE warehouseId=@warehouseId AND itemId=@itemId 
				AND ISNULL(onhandQty,0.0)-ISNULL(allocQty,0.0)+ISNULL(onwayQty,0.0)>0;
			IF (ISNULL(@stockQty,0.0)-ISNULL(@availQty,0.0)>0.0)
				SET @stockQty=@availQty;
			IF (ISNULL(@stockQty,0.0)>0.0)
			BEGIN
				--2.1对分拣数量进行整散重新计算
				IF (@pickingMode=0)
				BEGIN
					SET @bulkQty=(@stockQty % @pkgRatio);
					SET @pkgQty=FLOOR(@stockQty / @pkgRatio);
				END
				ELSE IF(@pickingMode=1)
				BEGIN
					SET @bulkQty=@stockQty;
					SET @pkgQty=0;
				END
				ELSE IF(@pickingMode=2)
				BEGIN
					SET @bulkQty=0
					SET @pkgQty=@stockQty;
				END
				--2.2 整箱分拣
				IF (ISNULL(@pkgQty,0.0)>0.0)
				BEGIN
					SET @totalQty=0.0;
					--分拣数量(订单上的实际数量)
					SET @pickQty=@pkgQty*@pkgRatio
					DELETE FROM @tmpLocation;
					--取得整箱分拣库位，分拣数量
					INSERT INTO @tmpLocation(viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)
					SELECT viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish
					FROM dbo.uf_GetPickLocation(@companyId,@warehouseId,@ownerId,@itemId,@pickQty,'CS',0)
					--如果没分配到直接提示并返回
					IF (NOT EXISTS(SELECT 1 FROM @tmpLocation)) OR (NOT EXISTS(SELECT 1 FROM @tmpLocation WHERE FLOOR(pickQty/@pkgRatio)>0)) 
					BEGIN
						SET @pkgQty=0.0;
						--转入拆零分拣
						SET @bulkQty=ISNULL(@bulkQty,0.0)+ISNULL(@pickQty,0.0);
						--更新出库单明细件分拣数量
						UPDATE @tmpDetail SET pkgQty=0 WHERE stockId=@stockId;						
					END
					ELSE
					BEGIN
						--已分拣数量
						SELECT @totalQty=SUM(FLOOR(pickQty/@pkgRatio)*@pkgRatio) FROM @tmpLocation						
						--写入临时分配表
						INSERT INTO @tmpAllocate(stockId,stockNo,billNo,warehouseId,ownerId,regionId,lotNo,locationNo,itemId,pickQty,realQty,unitLevel,itemVolume,pkgRatio,shipNo,allowSplit)
						SELECT @stockId,@stockNo,@billNo,warehouseId,@ownerId,regionId,lotNo,locationNo,itemId,FLOOR(pickQty/@pkgRatio),FLOOR(pickQty/@pkgRatio)*@pkgRatio,'CS',@itemVolume,@pkgRatio,@shipNo,@allowSplit
						FROM @tmpLocation
						WHERE FLOOR(pickQty/@pkgRatio)>0;	
						--更新IMS_Stock表已分配量
						UPDATE a SET allocQty=ISNULL(a.allocQty,0.0)+ FLOOR(b.pickQty/@pkgRatio)*@pkgRatio
						FROM IMS_Stock a INNER JOIN 
							@tmpLocation b ON a.companyId=@companyId AND a.warehouseId=b.warehouseId AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.locationNo,'') AND a.itemId=b.itemId
						WHERE FLOOR(b.pickQty/@pkgRatio)>0;						
						SET @pkgQty=@totalQty/@pkgRatio;
						--更新出库单明细件分拣数量
						UPDATE @tmpDetail SET pkgQty=@totalQty/@pkgRatio WHERE stockId=@stockId;	
						--如果存在整货区分拣数量不够，则转入拆零
						IF (ISNULL(@totalQty,0.0)-ISNULL(@pickQty,0.0)<0.0)
							SET @bulkQty=ISNULL(@bulkQty,0.0)+ISNULL(@pickQty,0.0)-ISNULL(@totalQty,0.0);
					END 
				END 
				--2.3件分拣
				IF (ISNULL(@bulkQty,0.0)>0.0)
				BEGIN	
					SET @totalQty=0.0;
					DELETE FROM @tmpLocation;
					--取得散件分拣库位，分拣数量
					INSERT INTO @tmpLocation(viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)
					SELECT viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish
					FROM dbo.uf_GetPickLocation(@companyId,@warehouseId,@ownerId,@itemId,@bulkQty,'EA',0)
					--2.3.1如果没分配到直接0
					IF NOT EXISTS(SELECT 1 FROM @tmpLocation)
					BEGIN
						--如果没有分配到数量
						UPDATE @tmpDetail SET bulkQty=0.0 WHERE stockId=@stockId;
					END
					ELSE
					BEGIN	
						--2.3.2如果需要补货
						IF (EXISTS(SELECT 1 FROM @tmpLocation WHERE needReplenish=1))
						BEGIN
							--从整件区进行补货处理
							--因为是汇总散件，所以所缺库存需要转换成整件库存(只按照整包装进行补货）
							SELECT @totalQty=CEILING(pickQty/@pkgRatio)*@pkgRatio,@locationNo=locationNo,@needQty=pickQty
							FROM @tmpLocation
							WHERE needReplenish=1	
							SELECT @regionId=regionId
							FROM BAS_Location
							WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@locationNo
                            
							--2.3.2.1补货下架库位
							INSERT INTO @tmpReplenish(replenishId,stockId,stockNo,viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish,pkgQty,pkgRatio)
							SELECT REPLACE(NEWID(),'-',''),@stockId,@stockNo,viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish,pickQty/@pkgRatio,@pkgRatio
							FROM dbo.uf_GetPickLocation(@companyId,@warehouseId,@ownerId,@itemId,@totalQty,'CS',0)
							WHERE needReplenish=0
							--2.3.2.2删除需要补货的记录，重新分拣
							DELETE FROM @tmpLocation WHERE needReplenish=1;							
							--如果没有补货记录
							IF (EXISTS(SELECT 1 FROM @tmpReplenish WHERE stockId=@stockId))
							BEGIN						
								--如果新品（库位上没有的产品）
								IF (ISNULL(@locationNo,'')='')
								BEGIN
									DECLARE myPutaway CURSOR
									FOR SELECT replenishId,viewOrder,dbo.uf_GetPutawayLocation(@companyId,@ownerId,@warehouseId,@itemId,'',pickQty,lotNo,0,'EA'),pickQty,lotNo
										FROM @tmpReplenish
										WHERE stockId=@stockId
									OPEN myPutaway
									FETCH NEXT FROM myPutaway INTO @replenishId,@viewOrder,@locationNo,@pickQty,@lotNo
									WHILE @@FETCH_STATUS=0
									BEGIN
										--上架库区
										SELECT @regionId=regionId 
										FROM BAS_Location
										WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@locationNo
										--更新上架库位、库区
										UPDATE @tmpReplenish SET toLocationNo=@locationNo,toRegionId=@regionId WHERE replenishId=@replenishId;
										FETCH NEXT FROM myPutaway INTO @replenishId,@viewOrder,@locationNo,@pickQty,@lotNo
									END
									CLOSE myPutaway
									DEALLOCATE myPutaway
								END
								ELSE
								BEGIN
									UPDATE @tmpReplenish SET toLocationNo=@locationNo,toRegionId=@regionId WHERE stockId=@stockId;								
								END
								--写入预分配表，防止重复补货到同一库位
								INSERT INTO IMS_Allocate(allocId,stockId,stockNo,companyId,warehouseId,regionId,locationNo,lotNo,itemId,allocQty,unitLevel,ioFlag)
								SELECT replenishId,stockId,@stockNo,@companyId,warehouseId,toRegionId,toLocationNo,lotNo,itemId,pickQty,'EA','+'
								FROM @tmpReplenish
								WHERE stockId=@stockId								
								--更新IMS_Stock表的在途库存（目标库位在途）
								UPDATE a SET a.onWayQty=ISNULL(a.onWayQty,0.0)+ISNULL(b.pickQty,0.0)
								FROM IMS_Stock a INNER JOIN
									(SELECT warehouseId,lotNo,toLocationNo,itemId,SUM(pickQty) AS pickQty
									 FROM @tmpReplenish
									 WHERE stockId=@stockId
									 GROUP BY warehouseId,lotNo,toLocationNo,itemId
									 ) b ON a.companyId=@companyId AND a.warehouseId=b.warehouseId AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.toLocationNo,'') AND a.itemId=b.itemId									
								--补货到新库位（目标库位）
								INSERT INTO IMS_Stock(stockId,companyId,warehouseId,regionId,locationNo,lotNo,itemId,onhandQty,allocQty,onWayQty)
								SELECT REPLACE(NEWID(),'-',''),@companyId,warehouseId,toRegionId,b.toLocationNo,lotNo,itemId,0.0,0.0,pickQty
								FROM (SELECT warehouseId,lotNo,toRegionId,toLocationNo,itemId,SUM(pickQty) AS pickQty
									 FROM @tmpReplenish
									 WHERE stockId=@stockId
									 GROUP BY warehouseId,lotNo,toRegionId,toLocationNo,itemId
									 ) b
								WHERE NOT EXISTS(SELECT 1 FROM IMS_Stock a WHERE a.companyId=@companyId AND a.warehouseId=b.warehouseId AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.toLocationNo,'') AND a.itemId=b.itemId)
								--更新IMS_Stock表的已分配数量（原始库位已分配）
								UPDATE a SET a.allocQty=ISNULL(a.allocQty,0.0)+ISNULL(b.pickQty,0.0)
								FROM IMS_Stock a INNER JOIN
									(SELECT warehouseId,lotNo,locationNo,itemId,SUM(pickQty) AS pickQty
									 FROM @tmpReplenish
									 WHERE stockId=@stockId
									 GROUP BY warehouseId,lotNo,locationNo,itemId
									) b ON a.companyId=@companyId AND a.warehouseId=b.warehouseId AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.locationNo,'') AND a.itemId=b.itemId																						
								--根据补货数据重新安排分拣位
								DECLARE myPutaway CURSOR
								FOR SELECT tolocationNo,SUM(pickQty),lotNo
									FROM @tmpReplenish
									WHERE stockId=@stockId 
									GROUP BY toLocationNo,lotNo
								OPEN myPutaway
								FETCH NEXT FROM myPutaway INTO @locationNo,@pickQty,@lotNo
								WHILE @@FETCH_STATUS=0
								BEGIN
									--判断当前上架库位是否满足							
									IF (ISNULL(@needQty,0.0)>0.0)
									BEGIN
										IF (ISNULL(@needQty,0.0)-ISNULL(@pickQty,0.0)>0.0)
											INSERT INTO @tmpLocation(viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)
											VALUES(@viewOrder,@warehouseId,@regionId,@lotNo,@locationNo,@itemId,@pickQty,1)
										ELSE
											INSERT INTO @tmpLocation(viewOrder,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)
											VALUES(@viewOrder,@warehouseId,@regionId,@lotNo,@locationNo,@itemId,@needQty,1)
										SET @needQty=@needQty-@pickQty;
									END
									FETCH NEXT FROM myPutaway INTO @locationNo,@pickQty,@lotNo
								END
								CLOSE myPutaway
								DEALLOCATE myPutaway								
							END
						END
						--写入临时分配表
						INSERT INTO @tmpAllocate(stockId,stockNo,billNo,warehouseId,ownerId,regionId,lotNo,locationNo,itemId,pickQty,realQty,unitLevel,itemVolume,pkgRatio,shipNo,allowSplit)
						SELECT @stockId,@stockNo,@billNo,warehouseId,@ownerId,regionId,lotNo,locationNo,itemId,SUM(pickQty),SUM(pickQty),'EA',@itemVolume,@pkgRatio,@shipNo,@allowSplit
						FROM @tmpLocation
						WHERE ISNULL(pickQty,0.0)>0.0
						GROUP BY warehouseId,regionId,lotNo,locationNo,itemId
						--散件分拣总数量
						SELECT @totalQty=SUM(pickQty) FROM @tmpLocation	
						--更新出库单明细件分拣数量
						UPDATE @tmpDetail SET bulkQty=@totalQty WHERE stockId=@stockId;	
						--更新IMS_Stock表已分配量
						UPDATE a SET allocQty=ISNULL(a.allocQty,0.0)+ ISNULL(b.pickQty,0.0)
						FROM IMS_Stock a INNER JOIN 
							(SELECT warehouseId,lotNo,locationNo,itemId,SUM(pickQty) AS pickQty
							 FROM @tmpLocation
							 WHERE ISNULL(pickQty,0.0)>0.0
							 GROUP BY warehouseId,lotNo,locationNo,itemId
							) b ON a.companyId=@companyId AND a.warehouseId=b.warehouseId AND ISNULL(a.lotNo,'')=ISNULL(b.lotNo,'') AND ISNULL(a.locationNo,'')=ISNULL(b.locationNo,'') AND a.itemId=b.itemId
						WHERE ISNULL(b.pickQty,0.0)>0.0;			
					END
				END
			END
			FETCH NEXT FROM myCursor INTO @stockId,@stockNo,@billNo,@warehouseId,@ownerId,@itemId,@stockQty,@pkgRatio,@pickingMode,@itemVolume,@shipNo,@allowSplit
		END
		CLOSE myCursor
		DEALLOCATE myCursor	

		--3.重新拼箱处理
		--处理整箱分拣
		INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,sizeId,shipNo)
		SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,1,itemVolume,pkgRatio,1,'-1',shipNo
		FROM @tmpAllocate a
		WHERE unitLevel='CS' AND pickQty>0.0
		--重新拼箱
		DECLARE myOrder CURSOR 
		FOR 
			SELECT stockNo,shipNo,lclVolumn,dbo.uf_GetMaximalBoxes(@companyId,lclVolumn)
			FROM (
				  SELECT stockNo,shipNo,SUM(ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0)) AS lclVolumn
				  FROM @tmpAllocate
				  WHERE unitLevel='EA' AND pickQty>0.0
				  GROUP BY stockNo,shipNo
				) t
		OPEN myOrder
		FETCH NEXT FROM myOrder INTO @stockNo,@shipNo,@lclVolumn,@maxBoxes
		WHILE @@FETCH_STATUS=0
		BEGIN
			--如果最大拼箱数为1
			IF (@maxBoxes=1)
				BEGIN									
					--写入临时分配表明细
					INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,sizeId,shipNo)
					SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,CASE ISNULL(sizeId,'') WHEN '' THEN @maxSizeId ELSE sizeId END,shipNo
					FROM (	
						  SELECT stockId,stockNo,billNo,ownerId,warehouseId,CASE ISNULL(regionId,'') WHEN '' THEN @regionId ELSE regionId END AS regionId,
						        lotNo,locationNo,itemId,pickQty,0 AS isPackage,itemVolume,pkgRatio,1 AS boxNum,dbo.uf_GetContainer(@companyId,@lclVolumn) AS sizeId,@shipNo AS shipNo
						  FROM @tmpAllocate a
						  WHERE stockNo=@stockNo AND unitLevel='EA' AND pickQty>0.0
						 ) t
				END
			ELSE
			BEGIN
				--自动拼箱
				SET @sumVolumn=0.0
				SET @boxCount=1;
				--单品爆箱每个一箱
				DECLARE myBox CURSOR 
				FOR SELECT detailId,stockId,ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0),pickQty,itemVolume
					FROM @tmpAllocate
					WHERE stockNo=@stockNo AND unitLevel='EA' AND ISNULL(pickQty,0.0)>0.0 AND itemVolume>=@maxVolumn
				OPEN myBox
				FETCH NEXT FROM myBox INTO @detailId,@stockId,@bulkVolumn,@bulkQty,@itemVolume
				WHILE @@FETCH_STATUS=0
				BEGIN
					--最大拼箱数就是散件数
					SET @itemBoxes=@bulkQty
					--最大箱装货数量1
					SET @pickQty=1;
					SET @itemCount=1;
					WHILE @itemCount<=@itemBoxes
					BEGIN
						--只分拆单散件
						--爆箱时获取最大箱
						INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,sizeId,shipNo)
						SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,0,itemVolume,pkgRatio,@boxCount,@maxSizeId,@shipNo
						FROM @tmpAllocate a
						WHERE detailId=@detailId;
						SET @boxCount=@boxCount+1
						SET @itemCount=@itemCount+1;
					END				
					FETCH NEXT FROM myBox INTO @detailId,@stockId,@bulkVolumn,@bulkQty,@itemVolume
				END
				CLOSE myBox
				DEALLOCATE myBox	
				
				--重新拼箱
				DELETE FROM @sales;				
				INSERT INTO @sales(viewOrder,stockId,bulkVolumn,pickQty,itemVolume,allowSplit)	
				SELECT detailId,stockId,ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0),pickQty,itemVolume,allowSplit
				FROM @tmpAllocate
				WHERE stockNo=@stockNo AND unitLevel='EA' AND ISNULL(pickQty,0.0)>0.0 AND itemVolume<@maxVolumn 
				--单品小于最大周转箱的进行拼箱					
				SET @pickQty=0.0
				SET @sumVolumn=0.0
				
				--根据系统参数进行拼箱
				IF (@waveAlgorithm='1')
					SELECT TOP 1 @detailId=viewOrder
					FROM @sales a
					ORDER BY viewOrder
				ELSE
					SELECT TOP 1 @detailId=viewOrder
					FROM @sales a
					ORDER BY allowSplit DESC,viewOrder
				WHILE (EXISTS(SELECT 1 FROM @sales))
				BEGIN					
					--单条体积，数量，单个体积，是否允许拆分
					SELECT @bulkVolumn=bulkVolumn,@stockId=stockId,@bulkQty=pickQty,@itemVolume=itemVolume,@allowSplit=allowSplit 
					FROM @sales 
					WHERE viewOrder=@detailId;
					--当前明细体积超过最大体积
					IF (@bulkVolumn-@maxVolumn>0) 
					BEGIN
						--如果不允许单条拆箱
						IF (ISNULL(@allowSplit,1)=0)
						BEGIN
							INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,sizeId,shipNo)
							SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,pickQty,0,itemVolume,pkgRatio,@boxCount,@maxSizeId,@shipNo
							FROM @tmpAllocate a
							WHERE detailId=@detailId;
							SET @boxCount=@boxCount+1
						END
						ELSE
						BEGIN
							--允许拆箱的
							--最大箱装货数量
							SET @pickQty=FLOOR(@maxVolumn/@itemVolume);
							--单品最大拼箱数
							SET @itemBoxes=FLOOR(@bulkQty/@pickQty);
							SET @itemCount=1;
							--循环装N-1箱，剩下的余额和其他单品进行拼箱
							WHILE @itemCount<=@itemBoxes
							BEGIN
								--分拆散件
								INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,sizeId,shipNo)
								SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,0,itemVolume,pkgRatio,@boxCount,@maxSizeId,@shipNo
								FROM @tmpAllocate a
								WHERE detailId=@detailId;
								SET @boxCount=@boxCount+1
								SET @itemCount=@itemCount+1;
							END
							--剩余拼箱数量
							SET @pickQty=@bulkQty-@itemBoxes*@pickQty;
							--如果有余额，则和其他产品进行拼箱
							IF (ISNULL(@pickQty,0.0)>0.0)
							BEGIN
								--剩余数量再拼箱（对应整件放最后一个散件，避免重复）
								SET @sumVolumn=@sumVolumn+@pickQty*@itemVolume;	
								INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,sizeId,shipNo)
								SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,0,itemVolume,pkgRatio,@boxCount,'',@shipNo
								FROM @tmpAllocate
								WHERE detailId=@detailId;
							END
						END
						--删除当前对应临时数据，进入下一个循环
						DELETE FROM @sales WHERE viewOrder=@detailId;
					END
					ELSE
					BEGIN
						--当前拼箱和当前商品体积超过最大箱，则进行当前产品拆箱拼接
						IF (@sumVolumn+@bulkVolumn-@maxVolumn>0)
						BEGIN
							--如果不允许单条拆箱
							IF (ISNULL(@allowSplit,1)=1)
							BEGIN
								IF (@sumVolumn+@itemVolume-@maxVolumn>0)
								BEGIN
									SET @boxCount=@boxCount+1
									SET @sumVolumn=@bulkVolumn;
									--当前就装入下一箱
									INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,sizeId,shipNo)
									SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@bulkQty,0,itemVolume,pkgRatio,@boxCount,'',@shipNo
									FROM @tmpAllocate
									WHERE detailId=@detailId;							
								END
								ELSE
								BEGIN
									--拼箱数(最大体积-已经拼箱的体积再除以当前商品的体积得到可以拼箱的拼箱数量）
									SET @pickQty=0.0
									SET @pickQty=FLOOR((@maxVolumn-@sumVolumn)/@itemVolume);
									INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,sizeId,shipNo)
									SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,0,itemVolume,pkgRatio,@boxCount,'',@shipNo
									FROM @tmpAllocate
									WHERE detailId=@detailId;
									--剩余数量再装箱		
									SET @sumVolumn=@bulkVolumn-@pickQty*@itemVolume;	
									SET @pickQty=@bulkQty-@pickQty				
									SET @boxCount=@boxCount+1
									INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,sizeId,shipNo)
									SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@pickQty,0,itemVolume,pkgRatio,@boxCount,'',@shipNo
									FROM @tmpAllocate
									WHERE detailId=@detailId;							
								END
								--删除当前对应临时数据，进入下一个循环
								DELETE FROM @sales WHERE viewOrder=@detailId;
							END
							ELSE
							BEGIN
								SET @boxCount=@boxCount+1
								SET @sumVolumn=@bulkVolumn;
								--当前就装入下一箱
								INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,sizeId,shipNo)
								SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@bulkQty,0,itemVolume,pkgRatio,@boxCount,'',@shipNo
								FROM @tmpAllocate
								WHERE detailId=@detailId;
								--删除当前对应临时数据，进入下一个循环
								DELETE FROM @sales WHERE viewOrder=@detailId;
							END
						END
						ELSE
						BEGIN
							--剩余数量再拼箱（对应整件放最后一个散件，避免重复）
							SET @sumVolumn=@sumVolumn+@bulkVolumn
							INSERT INTO @tmpPick(stockId,stockNo,stockBillNo,ownerId,warehouseId,regionId,batchNo,locationNo,itemId,pickQty,isPackage,itemVolume,pkgRatio,boxNum,sizeId,shipNo)
							SELECT stockId,stockNo,billNo,ownerId,warehouseId,regionId,lotNo,locationNo,itemId,@bulkQty,0,itemVolume,pkgRatio,@boxCount,'',@shipNo
							FROM @tmpAllocate
							WHERE detailId=@detailId;
							--循环下一个箱
							DELETE FROM @sales WHERE viewOrder=@detailId;
						END					
					END	
					
					SELECT TOP 1 @detailId=viewOrder
					FROM @sales a
					ORDER BY allowSplit DESC,viewOrder
				END
				UPDATE a SET a.sizeId=dbo.uf_GetContainer(@companyId,b.lclVolumn)
				FROM @tmpPick a INNER JOIN
					(SELECT boxNum,stockNo,SUM(ISNULL(pickQty,0.0)*ISNULL(itemVolume,0.0)) AS lclVolumn
					 FROM @tmpPick
					 WHERE stockNo=@stockNo AND ISNULL(sizeId,'')=''
					 GROUP BY boxNum,stockNo) b ON a.stockNo=b.stockNo AND a.boxNum=b.boxNum
				WHERE a.stockNo=@stockNo AND ISNULL(a.sizeId,'')='';
			END				
			FETCH NEXT FROM myOrder INTO @stockNo,@shipNo,@lclVolumn,@maxBoxes
		END
		CLOSE myOrder
		DEALLOCATE myOrder		
		--如果没有箱号的给最大周转箱
		UPDATE @tmpPick SET sizeId=@maxSizeId WHERE ISNULL(sizeId,'')=''
		--5.根据波茨策略生成波茨计划
		--波茨计划:定义单据游标,分波茨任务，并写入临时表(根据波茨策略)		
		DECLARE @wave TABLE(waveNo VARCHAR(32),createTime DATETIME,creatorId VARCHAR(32));
		DECLARE @waveDtl TABLE(waveId VARCHAR(32),waveNo VARCHAR(32),stockNo VARCHAR(32));
		DECLARE myPolicy CURSOR
		FOR
			SELECT policyId,warehouseId,ownerId,lineId,logisticsId,orderType,minRows,maxRows,minOrders,maxOrders,limitedVolumn,limitedWeight
			FROM dbo.WMS_WavePolicy
			WHERE companyId=@companyId AND isDisable=0
			ORDER BY viewOrder
		OPEN myPolicy
		FETCH NEXT FROM myPolicy INTO @policyId,@warehouseId,@ownerId,@lineId,@logisticsId,@orderType,@minRows,@maxRows,@minOrders,@maxOrders,@limitedVolumn,@limitedWeight
		WHILE @@FETCH_STATUS=0
		BEGIN	
			IF (ISNULL(@maxRows,0)=0)
				SET @maxRows=9999
			--根据策略对订单进行分组（临时订单表）
			INSERT INTO @sales(policyId,stockNo,viewOrder)
			SELECT @policyId,stockNo,ROW_NUMBER() OVER (ORDER BY viewOrder)
			FROM @tmpHead a
			WHERE warehouseId=@warehouseId AND ownerId=@ownerId								--公司、业主
				  AND (ISNULL(lineId,'')=@lineId OR ISNULL(@lineId,'')='')					--线路
				  AND (ISNULL(logisticsId,'')=@logisticsId OR ISNULL(@logisticsId,'')='')	--物流
				  AND (ISNULL(@orderType,10)=@orderType)									--订单类型
				  AND (skuCount BETWEEN @minRows AND @maxRows)								--Sku数量
				  AND EXISTS(SELECT 1 FROM @tmpPick b WHERE a.stockNo=b.stockNo)
			ORDER BY viewOrder;
			--如果当前策略没有对应的数据
			IF EXISTS(SELECT 1 FROM @sales WHERE policyId=@policyId)
			BEGIN
				--订单数量超过波茨最大订单数量时，需要分波茨
				IF ISNULL(@maxOrders,0)>0
				BEGIN
					SELECT @waveIndex=1,@waveCount=COUNT(1)/@maxOrders + 1 FROM @sales WHERE policyId=@policyId;
					WHILE (@waveIndex<=@waveCount)
					BEGIN
						SET @waveNo=REPLACE(NEWID(),'-','')
						--写入波茨数据(主表)
						INSERT INTO @wave(waveNo,createTime,creatorId)
						VALUES(@waveNo,@createTime,@creatorId);		
						--写入波茨数据明细表
						INSERT INTO @waveDtl(waveId,waveNo,stockNo)
						SELECT REPLACE(NEWID(),'-',''),@waveNo,stockNo
						FROM @sales
						WHERE viewOrder BETWEEN (@waveIndex-1)*@maxOrders+1 AND @waveIndex*@maxOrders
						ORDER BY viewOrder; 	
						SET @waveIndex=@waveIndex+1;				
					END
				END
				ELSE
				BEGIN
					SET @waveNo=REPLACE(NEWID(),'-','')
					--写入波茨数据(主表)
					INSERT INTO @wave(waveNo,createTime,creatorId)
					VALUES(@waveNo,@createTime,@creatorId);					
					--写入波茨数据明细表
					INSERT INTO @waveDtl(waveId,waveNo,stockNo)
					SELECT REPLACE(NEWID(),'-',''),@waveNo,stockNo
					FROM @sales 
					WHERE policyId=@policyId;			
				END
			END
			--释放@sales
			DELETE FROM @sales;
			FETCH NEXT FROM myPolicy INTO @policyId,@warehouseId,@ownerId,@lineId,@logisticsId,@orderType,@minRows,@maxRows,@minOrders,@maxOrders,@limitedVolumn,@limitedWeight
		END
		CLOSE myPolicy
		DEALLOCATE myPolicy

		--6.生成波茨分拣任务
		DECLARE myWave CURSOR
		FOR SELECT waveNo FROM @wave
		OPEN myWave
		FETCH NEXT FROM myWave INTO @waveNo
		WHILE @@FETCH_STATUS=0
		BEGIN
			--生产波茨计划单
			EXEC up_CreateCode @companyId,'WMS_Wave',@creatorId,@waveBillNo OUTPUT;
			INSERT INTO WMS_Wave(waveNo,billNo,companyId,autoFlag,createTime,creatorId)
			VALUES(@waveNo,@waveBillNo,@companyId,1,@createTime,@creatorId);
			INSERT INTO WMS_WaveDetail(waveId,waveNo,companyId,stockNo)
			SELECT REPLACE(NEWID(),'-',''),@waveNo,@companyId,stockNo
			FROM @waveDtl
			WHERE waveNo=@waveNo;			
			--6.1波茨下的箱拣货任务(每个仓库、库区为一个分拣任务——排分拣任务)
			--2017-04-25 增加按单据进行分配任务
			DECLARE myTask CURSOR 
			FOR 
				SELECT warehouseId,regionId,stockNo,SUM(pickQty) AS iCount
				FROM @tmpPick a
				WHERE EXISTS(SELECT 1 FROM @waveDtl b WHERE b.waveNo=@waveNo AND a.stockNo=b.stockNo)
					AND isPackage=1 AND pickQty>0.0
				GROUP BY warehouseId,regionId,stockNo
			OPEN myTask
			FETCH NEXT FROM myTask INTO @warehouseId,@regionId,@stockNo,@boxCount
			WHILE @@FETCH_STATUS=0
			BEGIN			
				--装箱序号改为按单设置	
				SET @boxCount=1;
				DECLARE @iRow INT;				
				DECLARE myOrder CURSOR
				FOR SELECT pickOrder,shipNo,stockBillNo,itemId,pickQty AS pickQty
					FROM @tmpPick a
					WHERE stockNo=@stockNo AND warehouseId=@warehouseId AND regionId=@regionId AND isPackage=1 
						AND EXISTS(SELECT 1 FROM @waveDtl b WHERE b.waveNo=@waveNo AND a.stockNo=b.stockNo)
				OPEN myOrder
				FETCH NEXT FROM myOrder INTO @pickOrder,@shipNo,@billNo,@itemId,@pickQty
				WHILE @@FETCH_STATUS=0
				BEGIN
					SET @pickingNo=REPLACE(NEWID(),'-','');
					--创建任务单据编号
					EXEC up_CreateCode @companyId,'WMS_Picking',@creatorId,@pickBillNo OUTPUT;
					--写入分拣任务taskType:0-散件;1-整箱;2-补货
					INSERT INTO WMS_Picking(pickingNo,companyId,billNo,waveNo,waveBillNo,warehouseId,regionId,taskType,sizeId,boxNumber,taskState,createTime,editTime,creatorId,editorId)  
					VALUES(@pickingNo,@companyId,@pickBillNo,@waveNo,@waveBillNo,@warehouseId,@regionId,1,'-1',0,0,@createTime,@createTime,@creatorId,@creatorId);
					--写入分拣任务订单表(WMS_PickingOrder)
					SET @iRow=1; 
					WHILE @iRow<=@pickQty
					BEGIN
						SET @pickId=REPLACE(NEWID(),'-','');
						INSERT INTO WMS_PickingOrder(pickId,pickingNo,companyId,stockNo,stockBillNo,stockBox,boxId,boxOrder,isPackage,pkgQty,lclQty,pickerId,taskState,shipNo)
						VALUES(@pickId,@pickingNo,@companyId,@stockNo,@billNo,@boxCount,'',@boxCount,1,@pickQty,0.0,'',0,@shipNo);
						--写入分拣任务订单明细表(WMS_PickingDetail)
						INSERT INTO WMS_PickingDetail(pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,itemId,
							isPackage,pickState,stockQty,pickQty,actualQty,realQty,boxId,boxOrder,stockId,stockNo,stockBillNo)
						SELECT REPLACE(NEWID(),'-',''),@pickId,@pickingNo,@companyId,@warehouseId,@regionId,batchNo,locationNo,@itemId,
							1,0,1.0,1.0,0.0,pkgRatio,'',@boxCount,stockId,stockNo,stockBillNo 
						FROM @tmpPick 
						WHERE pickOrder=@pickOrder		
						--累加计数器
						SET @boxCount=@boxCount+1
						SET @iRow=@iRow+1
					END
					FETCH NEXT FROM myOrder INTO @pickOrder,@shipNo,@billNo,@itemId,@pickQty
				END
				CLOSE myOrder
				DEALLOCATE myOrder
				FETCH NEXT FROM myTask INTO @warehouseId,@regionId,@stockNo,@boxCount
			END
			CLOSE myTask
			DEALLOCATE myTask		
			--6.2 波茨下的件拣货任务
			DECLARE myTask CURSOR 
			FOR SELECT warehouseId,regionId,sizeId
				FROM (SELECT warehouseId,regionId,sizeId,COUNT(1) As boxCount
					  FROM @tmpPick a
					  WHERE EXISTS(SELECT 1 FROM @waveDtl b WHERE b.waveNo=@waveNo AND a.stockNo=b.stockNo)
						AND a.isPackage=0 AND pickQty>0.0
					  GROUP BY warehouseId,regionId,sizeId
					 ) t
			OPEN myTask
			FETCH NEXT FROM myTask INTO @warehouseId,@regionId,@sizeId
			WHILE @@FETCH_STATUS=0
			BEGIN
				--周转箱规格组合数
				SELECT @maxBoxes=boxNumber FROM WMS_BoxSize WHERE sizeId=@sizeId;
				SET @boxCount=1;
				SET @pickingNo=REPLACE(NEWID(),'-','');
				--循环当前仓库\区域\箱规的所有单据与箱号
				DECLARE myOrder CURSOR
				FOR SELECT stockNo,shipNo,stockBillNo,boxNum
					FROM @tmpPick a
					WHERE warehouseId=@warehouseId AND regionId=@regionId AND sizeId=@sizeId 
						AND EXISTS(SELECT 1 FROM @waveDtl b WHERE b.waveNo=@waveNo AND a.stockNo=b.stockNo)
						AND isPackage=0
					GROUP BY stockNo,shipNo,stockBillNo,boxNum
				OPEN myOrder
				FETCH NEXT FROM myOrder INTO @stockNo,@shipNo,@billNo,@boxIndex
				WHILE @@FETCH_STATUS=0
				BEGIN
					IF (@boxCount-@maxBoxes>0)
					BEGIN
						SET @boxCount=1;
						SET @pickingNo=REPLACE(NEWID(),'-',''); 
					END
					--写入任务表
					IF NOT EXISTS(SELECT 1 FROM WMS_Picking WHERE pickingNo=@pickingNo)
					BEGIN
						--生成任务单编号
						EXEC up_CreateCode @companyId,'WMS_Picking',@creatorId,@pickBillNo OUTPUT;
						--taskType:0-散件;1-整箱;2-补货
						INSERT INTO WMS_Picking(pickingNo,companyId,billNo,waveNo,waveBillNo,warehouseId,regionId,taskType,sizeId,boxNumber,taskState,createTime,editTime,creatorId,editorId)  
						VALUES(@pickingNo,@companyId,@pickBillNo,@waveNo,@waveBillNo,@warehouseId,@regionId,0,@sizeId,@maxBoxes,0,GETDATE(),GETDATE(),@creatorId,@creatorId)
					END
					--写入分拣任务订单表
					SET @pickId=REPLACE(NEWID(),'-','');
					--拼箱数
					SELECT @lclQty=MAX(boxNum) FROM @tmpPick WHERE stockNo=@stockNo;
					INSERT INTO WMS_PickingOrder(pickId,pickingNo,companyId,stockNo,stockBillNo,stockBox,boxId,boxOrder,isPackage,pkgQty,lclQty,pickerId,taskState,shipNo)
					VALUES(@pickId,@pickingNo,@companyId,@stockNo,@billNo,@boxIndex,'',@boxCount,0,0.0,@lclQty,'',0,@shipNo)    
					--写入分拣任务明细
					INSERT INTO WMS_PickingDetail(pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,itemId,
						isPackage,pickState,stockQty,pickQty,actualQty,realQty,boxId,boxOrder,stockId,stockNo,stockBillNo)
					SELECT REPLACE(NEWID(),'-',''),@pickId,@pickingNo,@companyId,@warehouseId,@regionId,batchNo,locationNo,itemId,
						0,0,pickQty,pickQty,0.0,pickQty,'',@boxCount,stockId,stockNo,stockBillNo    
					FROM @tmpPick 
					WHERE stockNo=@stockNo AND warehouseId=@warehouseId AND regionId=@regionId AND sizeId=@sizeId AND boxNum=@boxIndex AND isPackage=0;
					SET @boxCount=@boxCount+1;
					FETCH NEXT FROM myOrder INTO @stockNo,@shipNo,@billNo,@boxIndex
				END
				CLOSE myOrder
				DEALLOCATE myOrder				
				FETCH NEXT FROM myTask INTO @warehouseId,@regionId,@sizeId
			END
			CLOSE myTask
			DEALLOCATE myTask
			--6.3波茨补货(散件分拣）
			IF EXISTS(SELECT 1 FROM @tmpReplenish)
			BEGIN
				--6.3.1 生成波茨补货计划
				EXEC up_CreateCode @companyId,'IMS_Replenish',@creatorId,@replenishBillNo OUTPUT;
				INSERT INTO IMS_Replenish(replenishId,companyId,replenishDate,billNo,replenishType,waveNo,waveBillNo,sourceWhId,sourceRegId,sourceLocNo,lotNo,targetWhId,targetRegId,targetLocNo,eId,itemId,replenishQty,pkgQty,ioState,printNum,isLocked,lockerId,lockedTime,createTime,creatorId,stockId,stockNo)
				SELECT replenishId,@companyId,GETDATE(),@replenishBillNo,2,@waveNo,@waveBillNo,warehouseId,regionId,locationNo,lotNo,warehouseId,toRegionId,toLocationNo,'',itemId,pickQty,pkgQty,10,0,0,'',NULL,@createTime,@creatorId,stockId,stockNo
				FROM @tmpReplenish 
				WHERE stockId=ANY(
								 SELECT a.stockId 
								 FROM @tmpPick a INNER JOIN @waveDtl b ON a.stockNo=b.stockNo
								 WHERE a.isPackage=0 AND b.waveNo=@waveNo
								)
				--清除已经生成补货任务的数据
				DELETE FROM @tmpReplenish 
				WHERE stockId=ANY(
								 SELECT a.stockId 
								 FROM @tmpPick a INNER JOIN @waveDtl b ON a.stockNo=b.stockNo
								 WHERE a.isPackage=0 AND b.waveNo=@waveNo
								)
				--6.3.2 生成波茨补货分拣任务
				DECLARE myTask CURSOR 
				FOR 
					SELECT sourceWhId,sourceRegId,COUNT(1)
					FROM IMS_Replenish 
					WHERE companyId=@companyId AND billNo=@replenishBillNo
					GROUP BY sourceWhId,sourceRegId
				OPEN myTask
				FETCH NEXT FROM myTask INTO @warehouseId,@regionId,@boxCount
				WHILE @@FETCH_STATUS=0
				BEGIN
					--补货任务模式；1-按单条商品生成补货任务;0-按波茨生成补货任务
					IF (@replenishTaskMode='0')
					BEGIN
						SET @pickingNo=REPLACE(NEWID(),'-','');
						--创建任务单据编号
						EXEC up_CreateCode @companyId,'WMS_Picking',@creatorId,@pickBillNo OUTPUT;
						--写入分拣任务taskType:0-散件;1-整箱;2-补货
						INSERT INTO WMS_Picking(pickingNo,companyId,billNo,waveNo,waveBillNo,warehouseId,regionId,taskType,sizeId,boxNumber,taskState,createTime,editTime,creatorId,editorId)  
						VALUES(@pickingNo,@companyId,@pickBillNo,@waveNo,@waveBillNo,@warehouseId,@regionId,2,'-1',0,0,@createTime,@createTime,@creatorId,@creatorId);
					END
					--生成补货分拣任务
					DECLARE myOrder CURSOR 
					FOR
						SELECT a.replenishId,a.itemId,a.lotNo,a.sourceLocNo,a.replenishQty,a.pkgQty,b.pkgRatio
						FROM IMS_Replenish a INNER JOIN BAS_Item b ON a.itemId=b.itemId 
						WHERE a.companyId=@companyId AND a.billNo=@replenishBillNo AND a.sourceWhId=@warehouseId AND a.sourceRegId=@regionId
					OPEN myOrder
					FETCH NEXT FROM myOrder INTO @replenishId,@itemId,@lotNo,@locationNo,@replenishQty,@pickQty,@pkgRatio
					WHILE @@FETCH_STATUS=0
					BEGIN
						--补货任务模式；1-按单条商品生成补货任务;0-按波茨生成补货任务
						IF (@replenishTaskMode='1')
						BEGIN
							SET @pickingNo=REPLACE(NEWID(),'-','');
							--创建任务单据编号
							EXEC up_CreateCode @companyId,'WMS_Picking',@creatorId,@pickBillNo OUTPUT;
							--写入分拣任务taskType:0-散件;1-整箱;2-补货
							INSERT INTO WMS_Picking(pickingNo,companyId,billNo,waveNo,waveBillNo,warehouseId,regionId,taskType,sizeId,boxNumber,taskState,createTime,editTime,creatorId,editorId)  
							VALUES(@pickingNo,@companyId,@pickBillNo,@waveNo,@waveBillNo,@warehouseId,@regionId,2,'-1',0,0,@createTime,@createTime,@creatorId,@creatorId);
						END
						IF (@pickQty>0)
						BEGIN
							SET @boxCount=1;
							WHILE @boxCount<=@pickQty
							BEGIN
								SET @pickId=REPLACE(NEWID(),'-','');
								INSERT INTO WMS_PickingOrder(pickId,pickingNo,companyId,stockNo,stockBillNo,stockBox,boxId,boxOrder,isPackage,pkgQty,lclQty,pickerId,taskState)
								VALUES(@pickId,@pickingNo,@companyId,@replenishId,@replenishBillNo,@boxCount,'',@boxCount,1,@pickQty,0.0,'',0);
								--写入分拣任务订单明细表(WMS_PickingDetail)
								INSERT INTO WMS_PickingDetail(pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,itemId,
									isPackage,pickState,stockQty,pickQty,actualQty,realQty,boxId,boxOrder,stockId,stockNo,stockBillNo)					
								VALUES(REPLACE(NEWID(),'-',''),@pickId,@pickingNo,@companyId,@warehouseId,@regionId,@lotNo,@locationNo,@itemId,
									1,0,1.0,1.0,0.0,@pkgRatio,'',@boxCount,@replenishId,@replenishId,@replenishBillNo)    
								--累加计数器
								SET @boxCount=@boxCount+1
							END
						END
						ELSE
						BEGIN
							SET @pickId=REPLACE(NEWID(),'-','');
							INSERT INTO WMS_PickingOrder(pickId,pickingNo,companyId,stockNo,stockBillNo,stockBox,boxId,boxOrder,isPackage,pkgQty,lclQty,pickerId,taskState)
							VALUES(@pickId,@pickingNo,@companyId,@replenishId,@replenishBillNo,@boxCount,'',@boxCount,1,1,0.0,'',0);
							--写入分拣任务订单明细表(WMS_PickingDetail)
							INSERT INTO WMS_PickingDetail(pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,itemId,
								isPackage,pickState,stockQty,pickQty,actualQty,realQty,boxId,boxOrder,stockId,stockNo,stockBillNo)					
							VALUES(REPLACE(NEWID(),'-',''),@pickId,@pickingNo,@companyId,@warehouseId,@regionId,@lotNo,@locationNo,@itemId,
								1,0,1.0,1.0,0.0,@replenishQty,'',@boxCount,@replenishId,@replenishId,@replenishBillNo) 							
						END
						FETCH NEXT FROM myOrder INTO @replenishId,@itemId,@lotNo,@locationNo,@replenishQty,@pickQty,@pkgRatio
					END
					CLOSE myOrder
					DEALLOCATE myOrder
					FETCH NEXT FROM myTask INTO @warehouseId,@regionId,@boxCount
				END 
				CLOSE myTask
				DEALLOCATE myTask				
			END
			--波次计划结束
			FETCH NEXT FROM myWave INTO @waveNo
		END
		CLOSE myWave
		DEALLOCATE myWave
		--更新任务等级
		UPDATE a SET flag=5
		FROM WMS_Picking a
		WHERE pickingNo=ANY(SELECT x.pickingNo
							FROM dbo.WMS_PickingOrder x
							      INNER JOIN @tmpHead y ON x.stockNo=y.stockNo
							WHERE y.flag=5)
		--免打印更新
		UPDATE a SET a.printNum=b.printNum
		FROM dbo.WMS_PickingDetail a 
			INNER JOIN @tmpDetail b ON a.stockId=b.stockId
		WHERE a.isPackage=1		
		--更新出库单状态
		UPDATE SAD_Stock SET taskState=40 WHERE stockNo=ANY(SELECT stockNo FROM @tmpPick WHERE pickQty>0.0)

		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@creatorId,'up_CreateWaveTask','YI_WAVE_TASK_ERROR',LEFT(@ErrMsg,2000),'','');					
	END CATCH
END



go

