/*==============================================================*/
/* View: IMS_CheckDetail_V                                      */
/*==============================================================*/
--creator：        Frank
--create time：  2016-03-02
--盘点单明细视图
CREATE view [dbo].[IMS_CheckDetail_V] as
SELECT b.checkId,b.checkNo,b.pointId,a.billNo,a.billState,b.companyId,b.viewOrder,b.warehouseId,b.lotNo,
	b.locationNo,b.eId,b.itemId,c.itemNo,c.itemCTitle,c.itemETitle,c.itemName,c.sellingPoint,c.itemSpell, 
	c.packageId,c.itemSpec,c.barcode,c.midBarcode,c.bigBarcode,c.pkgBarcode,c.brandId,c.brandCName,
	c.brandEName,c.categoryId,c.categoryNo,c.categoryCName,c.categoryEName,c.colorName,c.sizeName,c.unitName,
	c.pkgUnit,c.pkgRatio,c.inventoryMode,c.isSafety,c.safetyMonth,c.safetyDays,c.isUnsalable,c.isStop,
	c.isVirtual,d.onhandQty,d.realQty,b.actQty,b.pkgQty,b.bulkQty,isnull(b.actqty,0.0)-isnull(d.onhandqty,0.0) as plQty,
	b.price,b.taxrate,b.taxPrice,b.fee,b.taxFee,b.totalFee,bh.inputDate,bh.productDate,bh.expiryDate,bh.batchNo,
	bh.attribute01,bh.attribute02,bh.attribute03,bh.attribute04,attribute05,a.creatorId,b.remarks,b.isSelected
FROM dbo.IMS_Check AS a 
	INNER JOIN dbo.IMS_CheckDetail AS b ON a.checkNo = b.checkNo 
	INNER JOIN dbo.BAS_Goods_V AS c ON b.itemId = c.itemId 
	LEFT JOIN dbo.IMS_CheckStock AS d ON b.pointId = d.pointId AND b.companyId = d.companyId AND b.warehouseId = d.warehouseId AND ISNULL(b.lotNo,'') = ISNULL(d.lotNo,'') AND ISNULL(b.locationNo,'') = ISNULL(d.locationNo,'') AND b.itemId = d.itemId 
	LEFT JOIN dbo.IMS_Batch bh ON b.companyId=bh.companyId AND b.lotNo=bh.lotNo

go

