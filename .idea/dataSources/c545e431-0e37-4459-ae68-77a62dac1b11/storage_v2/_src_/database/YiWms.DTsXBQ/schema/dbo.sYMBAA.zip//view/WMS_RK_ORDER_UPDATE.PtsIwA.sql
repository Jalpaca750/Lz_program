CREATE  VIEW WMS_RK_ORDER_UPDATE
AS
SELECT  billNo,thirdSyncFlag SC_FLG,thirdSyncTime SC_FLAG_TIME  
FROM  PMS_Order  WHERE  thirdSyncFlag IN (0,2)
go

