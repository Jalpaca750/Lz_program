
-- =============================================
-- Author:		<Frank.He>
-- Create date: <2016-12-07>
-- Description:	<获取订单应该使用的周转箱规格>
-- Modify：      Frank 只获取周转箱箱规
-- =============================================

CREATE FUNCTION [dbo].[uf_GetContainer]
(
	@companyId VARCHAR(32),
	@volumn DECIMAL(20,6)
)
RETURNS VARCHAR(32)
AS
BEGIN
	DECLARE @sizeId VARCHAR(32);
	SELECT Top 1 @sizeId=sizeId
	FROM WMS_BoxSize
	WHERE companyId=@companyId AND boxType=1 AND boxVolume>@volumn 
	ORDER BY boxVolume;
    --如果体积超过了最大体积，则给最大箱
    IF ISNULL(@sizeId,'')=''
        SELECT Top 1 @sizeId=sizeId
        FROM WMS_BoxSize
        WHERE companyId=@companyId AND boxType=1
        ORDER BY boxVolume DESC;
	RETURN @sizeId;
END
go

