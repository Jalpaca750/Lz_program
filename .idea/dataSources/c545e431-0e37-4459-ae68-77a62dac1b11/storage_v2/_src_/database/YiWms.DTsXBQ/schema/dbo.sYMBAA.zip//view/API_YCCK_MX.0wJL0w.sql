

/*==============================================================*/
/* View: YCCK_HZ                                                */
/* create at:2020-07-09 zdy  接口移仓视图明细                   */                                            
/*==============================================================*/
CREATE view [dbo].[API_YCCK_MX] 
AS
SELECT t.transferNo PKID,c.ownerId
,c.ownerNo AS YEZ_ID,t.billNo AS DANJ_NO,bi.itemNo AS itemcode,a.ioQty AS quantity,a.viewOrder AS HANGHAO,t.WhsCode,t.TO_WhsCode
FROM dbo.IMS_TransferDetail a INNER JOIN
      dbo.BAS_Item bi ON a.itemId=bi.itemId INNER JOIN
       dbo.BAS_Owner_V c ON c.ownerId=bi.ownerId
      INNER JOIN
      (SELECT m.billNo,m.transferNo,w1.warehouseNo AS WhsCode,w2.warehouseNo AS TO_WhsCode
       FROM dbo.IMS_Transfer m INNER JOIN
             dbo.BAS_Warehouse w1 ON m.outputId=w1.warehouseId INNER JOIN
             dbo.BAS_Warehouse w2 ON m.inputId=w2.warehouseId
       WHERE (m.ioState=2) AND (m.thirdSyncFlag=0 OR m.thirdSyncFlag=2) 
             AND w1.warehouseId<>w2.warehouseId
      ) t ON a.transferNo=t.transferNo

go

