
/***************************************************************************************
---
--- 2020-07-08  @zdy      API 出库单回传表头   视图
---    
*****************************************************************************************/
CREATE VIEW  [dbo].[API_XSCK_HZ]
AS
SELECT A.stockNo PKID,A.companyId,A.warehouseId,o.ownerId,o.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,a.mergeNo AS SHANGJ_DANJ_NO,c.customerNo AS CARDCODE,
	CONVERT(VARCHAR(10),a.auditTime,23) AS docdate,a.totalFee,a.memo AS comments,u.userNo AS U_opcode,
	u.userNick AS U_OPNAME,0 AS discprcnt,w.warehouseNo AS whNo,a.orderType AS  orderTypeId,
	CASE a.orderType WHEN 10 THEN '普通订单' 
					 WHEN 20 THEN '调拨申请' 
					 WHEN 30 THEN '经营领用' 
					 WHEN 31 THEN '管理领用' 
					 WHEN 32 THEN '其他出库'
					 WHEN 40 THEN '赠品出库' 
					 WHEN 50 THEN '报损报废' END AS orderTypeName,a.thirdSyncFlag AS SC_FLG,
					 a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5,a.auditTime
FROM dbo.SAD_Stock a INNER JOIN
      dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId INNER JOIN
      dbo.BAS_Customer_V c ON a.customerId=c.customerId LEFT JOIN
      dbo.BAS_Owner_V o ON a.ownerId=o.ownerId LEFT JOIN 
      dbo.SAM_User u ON a.creatorId=u.userId
WHERE (a.taskState>=60) AND a.ioState > 0
      AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2)
      

go

