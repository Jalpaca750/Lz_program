-- =============================================
-- Author:		<Frank.He>
-- Create date: <2016-12-07>
-- Description:	<获取订单应该使用的周转箱规格>
-- Modify：      Frank 只获取周转箱箱规
-- =============================================
CREATE FUNCTION [dbo].[uf_GetCartonQty]
(
	@companyId VARCHAR(32),
	@deskCode VARCHAR(32),
	@cartonId VARCHAR(32)
)
RETURNS DECIMAL(20,6)
AS
BEGIN
	DECLARE @result DECIMAL(20,6);
	DECLARE @itemNo VARCHAR(32),				--商品编码
			@itemId VARCHAR(32),				--商品Id
			@warehouseId VARCHAR(32),			--仓库Id
			@locationNo VARCHAR(32);			--库位No
	--获取纸箱对应商品编码
	SELECT @itemNo=sizeNo FROM dbo.WMS_BoxSize WHERE sizeId=@cartonId;
	--获取商品Id
	SELECT @itemId=itemId FROM dbo.BAS_Item WHERE companyId=@companyId AND itemNo=@itemNo;
	--对应仓库，库位
	SELECT @warehouseId=warehouseId,@locationNo=locationNo FROM dbo.BAS_Worktable WHERE worktableId=@deskCode;
	--获取库存
	SELECT @result=onhandQty
	FROM dbo.IMS_Stock a
	WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@locationNo AND itemId=@itemId;
	RETURN @result;
END
go

