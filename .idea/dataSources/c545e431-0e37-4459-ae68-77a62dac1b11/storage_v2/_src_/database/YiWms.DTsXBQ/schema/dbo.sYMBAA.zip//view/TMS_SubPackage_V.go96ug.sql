
/*==============================================================*/
/* View: TMS_SubPackage_V                                       */
/*==============================================================*/
create view TMS_SubPackage_V as
SELECT a.boxId,a.shipNo,a.shipId,a.billType,CASE a.billType WHEN 10 THEN '销售出库单' 
								                            WHEN 20 THEN '调拨出库单' 
								                            WHEN 30 THEN '经营领用单' 
								                            WHEN 31 THEN '管理领用单' 
								                            WHEN 32 THEN '其他出库单'
								                            WHEN 40 THEN '赠品出库单' 
								                            WHEN 50 THEN '报损报废单'
								                            WHEN 60 THEN '销售退货单'
								                            WHEN 70 THEN '销售发票单'
								                            WHEN 80 THEN '销售收款单'
								                            WHEN 90 THEN '项目单' ELSE '运单' END billTypeName,
    a.stockNo,a.stockBillNo,a.waybillId,a.boxBillNum,a.boxState,
    CASE a.boxState WHEN 10 THEN '待装车' WHEN 20 THEN '已装车' END AS boxStateDesc,a.exShip01 AS stevedoreId,
    u2.userNick AS stevedoreName,a.exShip02,a.exShip03,a.exShip04,a.exShip05,a.exShip06,a.exShip07,a.exShip08,
    a.creatorId,u1.userNick AS creatorName,a.createTime,a.isPackage,
    CASE a.isPackage WHEN 0 THEN '散件' WHEN 1 THEN '整件' ELSE '文件' END AS isPackageDesc,a.remarks,a.isSelected
FROM dbo.TMS_SubWaybill a
    LEFT JOIN dbo.SAM_User u1 ON a.creatorId=u1.userId
    LEFT JOIN dbo.SAM_User u2 ON a.exShip01=u2.userId
go

