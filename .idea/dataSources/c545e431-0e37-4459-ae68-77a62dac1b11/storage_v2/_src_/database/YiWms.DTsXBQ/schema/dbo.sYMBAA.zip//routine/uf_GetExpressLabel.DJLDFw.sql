--creator：        WJ
--create time：  2019-11-07
--销售出库单等打印数据

CREATE FUNCTION [dbo].[uf_GetExpressLabel] 
(
	@boxBillNums AS Filter_Type READONLY
)
RETURNS TABLE
RETURN(
      SELECT a.*,h.receiverState+h.receiverCity+h.receiverDistrict+h.receiverAddress as receiverAddress,b.receiverName,b.receiverTel,b.receiverMobile,RIGHT(b.receiverTel,4) AS shortMobile,
		c.companyOwner,c.companyTel,c.companyMobile,
		d.areaName AS StateName,e.areaName AS CityName,f.areaName AS DistrictName,d.areaName +e.areaName+f.areaName+c.companyAddress AS fullAddress
	  FROM SAD_LogisticsDetail a
	LEFT JOIN SAD_Logistics h ON a.expressNo=h.expressNo
	LEFT JOIN SAD_Stock b ON a.stockNo=b.stockNo
	LEFT JOIN SAM_Company c ON b.companyId=c.companyId
	LEFT JOIN BAS_Area d ON c.companyState=d.areaId
	LEFT JOIN BAS_Area e ON c.companyCity=e.areaId
	LEFT JOIN BAS_Area f ON c.companyDistrict=f.areaId
	WHERE EXISTS(SELECT 1 FROM @boxBillNums g WHERE g.charId=a.boxBillNum)
)






go

