

/*==============================================================*/
/* View: GTCK_HZ                                                */
/*==============================================================*/
create view [dbo].[GTCK_HZ] as
SELECT o.ownerNo AS YEZ_ID,r.billNo AS DANJ_NO,r.thirdPartyNo AS SHANGJ_DANJ_NO,s.supplierNo AS CARDCODE,
      r.returnDate AS docdate,r.memo AS comments,u.userNo AS U_opcode,u.userNick AS U_OPNAME,0 AS discprcnt,
      '采购退货单' AS YEW_TYPE,r.thirdSyncFlag AS SC_FLG
FROM dbo.PMS_Return r INNER JOIN 
      dbo.BAS_Supplier_V s ON r.supplierId=s.supplierId LEFT JOIN
      dbo.BAS_Owner_V o ON r.ownerId=o.ownerId LEFT JOIN
      dbo.SAM_User u ON r.creatorId=u.userId
where r.ioState>10 and r.thirdSyncFlag in (0,2)
go

