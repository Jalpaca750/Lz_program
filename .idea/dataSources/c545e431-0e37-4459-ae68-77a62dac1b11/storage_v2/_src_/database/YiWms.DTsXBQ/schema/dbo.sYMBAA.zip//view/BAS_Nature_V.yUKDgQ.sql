
/*==============================================================*/
/* View: BAS_Nature_V                                           */
/*==============================================================*/
create view BAS_Nature_V as
--2016-09-18 企业性质视图统一修正
SELECT a.natureId,a.natureNo,a.natureCName,a.natureEName,a.companyId,a.isLocked,u1.userNick AS lockerName,
      a.lockerId,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,u2.userNick AS creatorName,
      a.creatorId,a.editTime,u3.userNick AS editorName,a.editorId,a.isSelected
FROM dbo.BAS_Nature a LEFT JOIN
      dbo.SAM_User u1 ON a.lockerId=u1.userId LEFT JOIN
      dbo.SAM_User u2 ON a.creatorId=u2.userId LEFT JOIN
      dbo.SAM_User u3 ON a.editorId=u3.userId
go

