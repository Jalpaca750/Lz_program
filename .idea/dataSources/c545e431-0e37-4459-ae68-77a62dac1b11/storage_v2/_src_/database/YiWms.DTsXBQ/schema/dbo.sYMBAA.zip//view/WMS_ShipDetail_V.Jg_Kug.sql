/*==============================================================*/
/* View: WMS_ShipDetail_V                                       */
/*==============================================================*/
--creator：     Frank
--create time:  2016-11-18
--Description: 装车单明细视图
--Modify：      2017-04-20 王军修改包装规格，回单状态等数据
--Modify：20170704 WJ添加打印价格
--              2019-05-23 增加金额字段后修改视图 Frank
CREATE view [dbo].[WMS_ShipDetail_V] as
SELECT a.shipId,a.shipNo,b.shipBillNo,b.createTime,a.companyId,c.companyName,
    ROW_NUMBER() OVER(PARTITION BY b.shipBillNo ORDER BY a.lineOrder,a.customerID) AS viewOrder,a.billType,
	CASE a.billType WHEN 10 THEN '销售出库单' 
					WHEN 20 THEN '调拨出库单' 
					WHEN 30 THEN '经营领用单' 
					WHEN 31 THEN '管理领用单' 
					WHEN 32 THEN '其他出库单'
					WHEN 40 THEN '赠品出库单' 
					WHEN 50 THEN '报损报废单'
					WHEN 60 THEN '销售退货单'
					WHEN 70 THEN '销售发票单'
					WHEN 80 THEN '销售出库单'
					WHEN 90 THEN '项目单' END billTypeName,a.billNo,a.stockBillNo,
	CASE WHEN ISNULL(s.groupId,'N')='N' THEN 'N' ELSE s.groupId END  AS groupId,b.shipDate,b.shipTime,
	b.deliveryName,b.driverName,b.auditTime,b.auditorName,b.creatorName,b.memo,a.customerId,d.customerNo,
	d.customerName,a.addressId,a.receiverState,a1.areaName AS stateName,a.receiverCity,a2.areaName AS cityName,
	a.receiverDistrict,a3.areaName AS districtName,a.receiverAddress,a.receiverName,
	ISNULL(a1.areaName,'') + ISNULL(a2.areaName,'') + ISNULL(a3.areaName,'') + a.receiverAddress AS fullAddress,
	a.receiverTel,a.receiverMobile,LTRIM(ISNULL(a.receiverMobile,'') + ' ' + ISNULL(a.receiverTel,'')) AS fullTel,
	a.pkgQty,a.lclQty,a.fclQty,a.fileQty,ISNULL(a.pkgQty,0.0)+ISNULL(a.lclQty,0.0) AS totalQty,a.totalFee,a.isInvalid,
	a.pkgVolumn,a.lclVolumn,ISNULL(a.pkgVolumn,0.0)+ISNULL(a.lclVolumn,0.0) AS totalVolumn,a.netWeight,a.grossWeight,a.shipState,
	CASE a.shipState WHEN 10 THEN '待装车' WHEN 15 THEN '部分装车' WHEN 20 THEN '已装车' WHEN 25 THEN '部分发车' WHEN 30 THEN '已发车' END shipStateName,
	a.mergeNo,b.lineName,a.lineOrder,b.carNumber,b.thirdFlag,a.boxBillNums,a.postFee,s.taskState,
	CASE s.taskState WHEN 10 THEN '已关闭'
					WHEN 20 THEN '已审核'
					WHEN 30 THEN '已排车'
					WHEN 40 THEN '待拣货'
					WHEN 50 THEN '待复核'
					WHEN 60 THEN '待打包'
					WHEN 70 THEN '待装车'
					WHEN 80 THEN '已装车'
					WHEN 90 THEN '已发货'
					WHEN 95 THEN '已妥投'
					WHEN 96 THEN '未送达'
					WHEN 99 THEN '已回单' ELSE '已装车' END AS taskStateName,s.printNum,s.backerId,s.backerName,
	CASE WHEN s.printNum=0 THEN '未打印' ELSE '已打印' END AS printDesc,CONVERT(VARCHAR(20),s.receiptTime,120) AS receiptTime,
	CASE s.isReceipt WHEN 1 THEN '是' WHEN 0 THEN '否' END AS isReceiptName,a.remarks,a.isSelected,bl.logisticsName	
FROM dbo.WMS_ShipDetail AS a 
	INNER JOIN (SELECT x.shipNo,x.billNo AS shipBillNo,x.createTime,CONVERT(VARCHAR(10),x.shipDate,23) AS shipDate,
					x.shipTime,e1.userNick AS deliveryName,e2.userNick AS driverName,u1.userNick AS auditorName,
					CONVERT(VARCHAR(20),x.auditTime,120) AS auditTime,u2.userNick AS creatorName,y.carNumber,z.lineName,
					x.memo,y.thirdFlag
				FROM dbo.WMS_Ship x 
					INNER JOIN dbo.BAS_Car y ON x.carId=y.carId 
					LEFT  JOIN dbo.BAS_AddressLine z ON x.lineId=z.lineId 
					INNER JOIN dbo.SAM_User e1 ON x.deliveryId=e1.userId 
					INNER JOIN dbo.SAM_User e2 ON x.driverId=e2.userId 
					LEFT JOIN dbo.SAM_User u1 ON x.auditorId=u1.userId 
					LEFT JOIN dbo.SAM_User u2 ON x.creatorId=u2.userId
				) AS b ON a.shipNo = b.shipNo 
	INNER JOIN dbo.SAM_Company c ON a.companyId=c.companyId 
	LEFT JOIN (SELECT m.stockNo,m.logisticsId,m.taskState,m.backerId,n.userNick AS backerName,m.printNum,m.isReceipt,m.receiptTime,m.groupId 
			   FROM dbo.SAD_Stock m 
					LEFT JOIN dbo.SAM_User AS n ON m.backerId=n.userId
			  ) AS s ON a.billNo=s.stockNo
	LEFT JOIN dbo.BAS_Customer_V d ON a.customerId=d.customerId 
	LEFT JOIN dbo.BAS_Area AS a1 ON a.receiverState = a1.areaId 
	LEFT JOIN dbo.BAS_Area AS a2 ON a.receiverCity = a2.areaId 
	LEFT JOIN dbo.BAS_Area AS a3 ON a.receiverDistrict = a3.areaId
	LEFT JOIN BAS_Logistics AS bl ON s.logisticsId=bl.logisticsId

go

