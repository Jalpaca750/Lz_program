

CREATE PROCEDURE [dbo].[up_WaveCheck] 
(
    @waveNo VARCHAR(32),                    --波次编号
    @companyId VARCHAR(32),			        --公司Id
    @items Type_WMS_WaveItem READONLY,      --波次商品明细
    @creatorId VARCHAR(32),			        --操作员
    @ErrMsg VARCHAR(2000) OUTPUT            --错误提示   
)
AS
BEGIN
    DECLARE @Errors BIGINT;
    SET @Errors=0;
    SET @ErrMsg='';
    BEGIN TRY
		BEGIN TRANSACTION
        UPDATE WMS_Wave SET taskState=30,checkerId=@creatorId,checkTime=GETDATE() WHERE waveNo=@waveNo;
        SET @Errors=@Errors+@@ERROR;
        INSERT INTO WMS_WaveItem(waveId,companyId,waveNo,itemId,pickQty,realQty,checkState,checkerId,checkTime)
        SELECT a.waveId,a.companyId,a.waveNo,a.itemId,a.pickQty,a.realQty,a.checkState,@creatorId,GETDATE()
        FROM @items a
        WHERE NOT EXISTS(SELECT * FROM WMS_WaveItem b WHERE b.waveNo=@waveNo AND a.waveNo=b.waveNo AND a.itemId=b.itemId)
        SET @Errors=@Errors+@@ERROR;
        IF (@Errors=0)
        BEGIN
            COMMIT;
        END
        ELSE
        BEGIN
            SET @ErrMsg='波次商品复核出错';
            ROLLBACK;
        END
    END TRY
    BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK;
	    SET @ErrMsg='波次商品复核出错';
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@creatorId,'up_WaveCheck','YI_WAVE_CHECK_ERROR',LEFT(@ErrMsg,2000),'','');				
	END CATCH
END
go

