-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2018-01-30>
-- Description:	<Description:装不下的单据移除当前计划>
--	    @shipId VARCHAR(32),				--装车单明细Id
--	    @shipNo VARCHAR(32),				--装车单主表No
--	    @companyId VARCHAR(32),				--公司Id
--	    @billType INT,						--单据类型:10,销售出库单;20,调拨出库单;30,经营领用单;31,管理领用单;32,其他出库单;40,赠品出库单;50,报损报废单;60,销售退货单;70,销售发票单;80,销售收款单;90,项目单
--	    @stockNo VARCHAR(32),				--单据No
--	    @stockBillNo VARCHAR(32),			--单据编号
--	    @operatorId VARCHAR(32)				--操作员Id
 -- =============================================

CREATE PROCEDURE [dbo].[up_TransportRemove]( 
	@shipId VARCHAR(32),				--装车单明细Id
	@shipNo VARCHAR(32),				--装车单主表No
	@companyId VARCHAR(32),				--公司Id
	@billType INT,						--单据类型:10,销售出库单;20,调拨出库单;30,经营领用单;31,管理领用单;32,其他出库单;40,赠品出库单;50,报损报废单;60,销售退货单;70,销售发票单;80,销售收款单;90,项目单
	@stockNo VARCHAR(32),				--单据No
	@stockBillNo VARCHAR(32),			--单据编号
	@operatorId VARCHAR(32)				--操作员Id
)
AS
BEGIN	
	DECLARE @hasTms INT;
	--是否有获得Tms产品授权
	IF EXISTS(SELECT 1 FROM SAM_CompanyProduct WHERE companyId=@companyId AND productCode='YFP0006') 
		SET @hasTms=1;
	ELSE
		SET @hasTms=0;
	--清除错误日志
	DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='up_TransportRemove';
	BEGIN TRY
		BEGIN TRANSACTION
		--如果发车单已发车则直接退出
		IF EXISTS(SELECT 1 FROM dbo.WMS_Ship WHERE shipNo=@shipNo AND shipState>10)
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_TransportRemove','YI_TRANSPORT_REMOVE_CANNOT_REMOVE','装车单已经装车发货，操作无效！',@shipId,@shipNo);		
			COMMIT;
			RETURN;
		END
		--删除明细
		DELETE FROM dbo.WMS_ShipDetail WHERE shipId=@shipId;
		--重新排序
		UPDATE a SET a.viewOrder=b.viewOrder
		FROM dbo.WMS_ShipDetail a
			INNER JOIN (SELECT shipId,ROW_NUMBER() OVER (ORDER BY viewOrder) AS viewOrder
						FROM dbo.WMS_ShipDetail
						WHERE shipNo=@shipNo) b ON a.shipId=b.shipId;
		--如果明细全部删除，则连带主表一起删除
		DELETE FROM dbo.WMS_Ship WHERE shipNo=@shipNo AND NOT EXISTS(SELECT 1 FROM dbo.WMS_ShipDetail WHERE shipNo=@shipNo);
		--取消对应单据状态
		IF (@hasTms=1)
		BEGIN
			DECLARE @waybillId VARCHAR(32);
			SELECT @waybillId=waybillId FROM dbo.TMS_WayBill WHERE companyId=@companyId AND wmsStockNo=@stockNo AND billType=@billType;
			--箱子状态更改为待排车状态(散件批量)
			UPDATE a SET a.packState=10
			FROM dbo.WMS_Packing a
			WHERE EXISTS(SELECT * FROM dbo.TMS_SubWaybill b WHERE a.companyId=b.companyId AND a.boxBillNum=b.boxBillNum AND shipId=@shipId AND isPackage=0);
			--箱子状态更改为待排车状态(整件批量)
			UPDATE a SET a.shipState=10
			FROM dbo.WMS_PickingOrder a
			WHERE EXISTS(SELECT * FROM dbo.TMS_SubWaybill b WHERE a.companyId=b.companyId AND a.boxBillNum=b.boxBillNum AND shipId=@shipId AND isPackage=1);
			--删除运单子表
			DELETE FROM dbo.TMS_SubWaybill WHERE waybillId=@waybillId AND shipId=@shipId;
			--如果子运单全部删除，则删除运单
			IF NOT EXISTS(SELECT 1 FROM dbo.TMS_SubWaybill WHERE stockNo=@stockNo AND billType=@billType)
			BEGIN
			    DELETE FROM dbo.TMS_WayBill WHERE waybillId=@waybillId;
			    DELETE FROM dbo.TMS_WaySite WHERE waybillId=@waybillId;
			END
		END
		--更新
		UPDATE SAD_Stock SET shipState=0,taskState=70,shipTime=NULL WHERE stockNo=@stockNo;
		
		--更新出库单状态为已装车（排计划）
		IF (@billType=10)
			UPDATE F10BMS.dbo.SMS_Stock SET CarNumberSts='',CarNumberDate='' WHERE StockNo=@stockBillNo;
		ELSE IF (@billType=20)
			UPDATE F10BMS.dbo.IMS_Allot SET CarNumberSts='',CarNumberDate='' WHERE AllotNo=@stockBillNo;
		ELSE IF (@billType=40)
			UPDATE F10BMS.dbo.IMS_Present SET CarNumberSts='',CarNumberDate='' WHERE PresentNo=@stockBillNo;
		ELSE IF (@billType=60)				--销售退货单
			UPDATE F10BMS.dbo.SMS_Return SET CarNumberSts='',CarNumberDate='' WHERE ReturnNo=@stockBillNo;
		ELSE IF (@billType=70)				--销售发票
			UPDATE F10BMS.dbo.SMS_Invoice SET CarNumberSts='',CarNumberDate='' WHERE InvoiceNo=@stockBillNo;
		ELSE IF (@billType=80)				--销售收款单
			UPDATE F10BMS.dbo.SMS_Payment SET CarNumberSts='',CarNumberDate='' WHERE PaymentNo=@stockBillNo;
		ELSE IF (@billType=90)				--项目单
			UPDATE F10BMS.dbo.PRJ_Order SET CarNumberSts='',CarNumberDate='' WHERE BillNo=@stockBillNo; 
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_TransportRemove','YI_TRANSPORT_REMOVE_ERROR',LEFT(@ErrMsg,2000),@shipId,@shipNo);		
		RAISERROR(@ErrMsg, @ErrSeverity, 1)			
	END CATCH
END


go

