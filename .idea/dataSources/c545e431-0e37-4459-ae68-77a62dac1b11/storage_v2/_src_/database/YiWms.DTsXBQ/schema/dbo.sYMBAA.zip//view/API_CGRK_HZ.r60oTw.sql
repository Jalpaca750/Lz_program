/*==============================================================*/
/* View: API_CGRK_HZ   @zdy create at:2020-07-08     采购回传主表                            */
/*==============================================================*/
CREATE view [dbo].[API_CGRK_HZ] 
AS
SELECT a.ownerId,a.warehouseId,A.companyId,A.stockNo PKID,o.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,a.mergeNo AS  SHANGJ_DANJ_NO,
      s.partnerNo AS CARDCODE,
      CONVERT(VARCHAR(10),isnull(a.auditTime,GETDATE()),23) AS docdate,
      a.memo AS comments,   --备注
      u.userNo AS U_opcode,  --收货人编码
      u.userNick AS U_OPNAME,--收货人名称
      0 AS discprcnt,'采购入库单' AS YEW_TYPE,
      a.orderSource  orderTypeId,
      CASE a.orderSource WHEN 11 THEN '普通订单' 
                       WHEN 12 THEN '应急订单' 
                       WHEN 13 THEN '零星采购' 
                       WHEN 14 THEN '转场订单' 
                       WHEN 21 THEN '调拨入库单' 
                       WHEN 31 THEN '赠品入库单'
                       WHEN 41 THEN '其他入库单' END AS orderTypeName,
      a.thirdSyncFlag AS SC_FLG,
      a.ordField2 docType,
      a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5,
      w.warehouseNo AS WHNO  --仓库编码
FROM dbo.PMS_Stock a INNER JOIN
      dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId INNER JOIN
      dbo.BAS_Partner s ON a.supplierId=s.partnerId LEFT JOIN
      dbo.BAS_Owner_V o ON a.ownerId=o.ownerId LEFT JOIN 
      dbo.SAM_User u ON a.creatorId=u.userId
WHERE (a.ioState=30) AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2)
     

go

