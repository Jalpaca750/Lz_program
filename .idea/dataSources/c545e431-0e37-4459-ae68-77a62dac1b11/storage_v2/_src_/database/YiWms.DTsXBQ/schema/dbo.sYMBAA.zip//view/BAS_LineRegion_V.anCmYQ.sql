
/*==============================================================*/
/* View: BAS_LineRegion_V                                       */
/*==============================================================*/
create view BAS_LineRegion_V as
SELECT a.lineId,a.regionId,b.regionNo,b.regionDesc,c.lineCode,c.lineName
FROM dbo.BAS_LineRegion a INNER JOIN 
      dbo.BAS_Region b ON a.regionId=b.regionId INNER JOIN
      dbo.BAS_AddressLine c ON a.lineId=c.lineId
go

