
/*==============================================================*/
/* View: WMS_WavePolicy_V                                       */
/*==============================================================*/
--creator：        Frank
--create time：  2016-12-05 日整理 
--波茨策略视图
create view WMS_WavePolicy_V as
SELECT p.policyId,p.policyDesc,p.companyId,p.warehouseId,w.warehouseNo,w.warehouseName,p.ownerId,o.ownerNo,
      o.ownerName,p.viewOrder,p.lineId,l.lineCode,l.lineName,p.logisticsId,lg.logisticsCode,lg.logisticsName,  
      p.orderType,CASE p.orderType WHEN 10 THEN '普通订单' WHEN 20 THEN '调拨订单' END AS orderTypeDesc,
      p.minRows,p.maxRows,p.minOrders,p.maxOrders,p.waitTimes,CONVERT(VARCHAR(20),p.waveTime,120) AS waveTime,
      p.limitedVolumn,p.limitedWeight,p.orderBy,p.isDisable,CASE p.isDisable WHEN 1 THEN '是' ELSE '否' END AS disableName,
      p.isLocked,p.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),p.lockedTime,120) AS lockedTime,
      p.createTime,p.creatorId,u2.userNick AS creatorName,p.editTime,p.editorId,u3.userNick AS editorName,
      p.isSelected
FROM dbo.WMS_WavePolicy AS p INNER JOIN
      dbo.BAS_Warehouse AS w ON p.warehouseId = w.warehouseId LEFT JOIN
      dbo.BAS_Owner_V AS o ON p.ownerId = o.ownerId LEFT JOIN
      dbo.BAS_AddressLine AS l ON p.lineId = l.lineId LEFT JOIN
      dbo.BAS_Logistics AS lg ON lg.logisticsId = p.logisticsId LEFT JOIN
      dbo.SAM_User AS u1 ON p.lockerId = u1.userId LEFT JOIN                
      dbo.SAM_User AS u2 ON p.creatorId = u2.userId LEFT JOIN
      dbo.SAM_User AS u3 ON p.editorId = u3.userId
go

