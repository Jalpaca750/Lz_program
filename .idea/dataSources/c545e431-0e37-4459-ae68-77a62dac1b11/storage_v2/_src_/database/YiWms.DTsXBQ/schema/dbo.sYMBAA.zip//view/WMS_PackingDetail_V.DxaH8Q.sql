
/*==============================================================*/
/* View: WMS_PackingDetail_V                                    */
/*==============================================================*/
create view WMS_PackingDetail_V as
SELECT a.packId,a.packNo,b.billNo,a.pickingId,a.pickId,a.pickingNo,b.boxBillNum,b.boxNum,
	c.billNo AS pickingBillNo,d.boxCode,d.boxBillNum AS oldBillNum,a.companyId,a.warehouseId,
	a.regionId,a.lotNo,a.locationNo,a.eId,a.itemId,bi.itemNo,bi.itemName,bi.itemCTitle,
	bi.itemETitle,bi.itemSpell,bi.itemSpec,bi.packageId,bi.barcode,bi.midBarcode,bi.bigBarcode,
	bi.pkgBarcode,bi.colorName,bi.sizeName,bi.unitName,a.isPackage,a.pickQty,a.packQty,bi.itemVolume,
	bi.itemWeight,a.packQty*bi.itemVolume AS totalVolume,a.packQty*bi.itemWeight AS totalWeight,   
	bi.pkgRatio,a.stockNo,a.stockId,a.stockBillNo,a.plasticId
FROM dbo.WMS_PackingDetail a 
	INNER JOIN dbo.WMS_Packing b ON a.packNo=b.packNo
	INNER JOIN dbo.WMS_Picking c ON a.pickingNo=c.pickingNo
	INNER JOIN (SELECT x.pickId,x.boxBillNum,y.boxCode
				FROM dbo.WMS_PickingOrder x
					LEFT JOIN WMS_Box y ON x.boxId=y.boxId) d ON a.pickId=d.pickId
	INNER JOIN dbo.BAS_Item bi ON a.itemId=bi.itemId
go

