
/*==============================================================*/
/* View: BAS_Partner_V                                          */
/*==============================================================*/
--2016-05-27 Frank 整理，并添加财务信息进视图
--2016-06-23 Frank 增加公司Logo和首页推荐字段（电商平台使用）
--客商视图
create view BAS_Partner_V as
SELECT a.partnerType,CASE a.partnerType WHEN 1 THEN '客户' WHEN 2 THEN '供应商' WHEN 3 THEN '业主' WHEN 9 THEN '往来客商' END AS partnerTypeName,
      a.companyId,a.ownerId,a.partnerId,a.partnerNo,a.partnerName,a.shortName,a.partnerSpell,a.companyState,
      a1.areaName AS stateName,a.companyCity,a2.areaName AS cityName,a.companyDistrict,a3.areaName AS districtName,
      ISNULL(a1.areaName,'') + ISNULL(a2.areaName,'') + ISNULL(a3.areaName,'') + a.companyAddress AS fullAddress,
      a.companyAddress,a.zip,a.parentId,p.partnerNo AS parentNo,p.partnerName AS parentName,a.typeId,t.typeCName,
      a.staffSizeId,s.staffSizeName,a.natureId,n.natureCName,a.tradeId,d.tradeCName,f.invoiceDay,f.affterDelivery,
      f.payTermLimited,CASE f.payTermLimited WHEN 0 THEN '不控制' WHEN 1 THEN '不许下单' WHEN 2 THEN '走审批控制' WHEN 3 THEN '只提示' END AS payTermLimitedDesc,
      f.payTerm,f.creditLimited,CASE f.creditLimited WHEN 0 THEN '不控制' WHEN 1 THEN '不许下单' WHEN 2 THEN '走审批控制' WHEN 3 THEN '只提示' END AS creditLimitedDesc,
      f.creditFee,f.priceLimited,CASE f.priceLimited WHEN 0 THEN '不控制' WHEN 1 THEN '只提示' WHEN 2 THEN '不许下单' WHEN 3 THEN '走审批控制' END AS priceLimitedDesc,
      f.rebate1,f.rebate2,f.rebate3,f.defPrice,CASE f.defPrice WHEN 'webprice' THEN '网站价' WHEN 'retailprice' THEN '零售价' WHEN 'salesprice' THEN '直销价' WHEN 'tradeprice' THEN '批发价' WHEN 'vipprice' THEN '会员价' END AS defPriceDesc, 
      f.befPrice,CASE f.befPrice WHEN 'webprice' THEN '网站价' WHEN 'retailprice' THEN '零售价' WHEN 'salesprice' THEN '直销价' WHEN 'tradeprice' THEN '批发价' WHEN 'vipprice' THEN '会员价' END AS befPriceDesc,
      f.taxFlag,f.payMode,f.isTogether,CASE f.isTogether WHEN 1 THEN '货齐一起送' ELSE '有货先送' END AS isTogetherDesc,
      f.currencyId,f.arFee,f.preFee,f.integral,f.salesId,f.salesName,f.assistantId,f.assistantName,f.outerId,f.outerName,
      a.partnerSource,CASE a.partnerSource WHEN 1 THEN '销售员开发' WHEN 2 THEN '客户介绍' WHEN 3 THEN '百度搜索' WHEN 4 THEN '线上注册' WHEN 5 THEN '其他渠道' END AS sourceName,
      a.userNo,a.userPwd,a.userMobile,a.userMail,a.icoUrl,a.logoUrl,a.isRecommend,a.partnerState,
      CASE a.partnerState WHEN 0 THEN '失效' ELSE '有效' END AS partnerStateName,a.reportTitle,a.reportCode,
      c.contactName,c.sex,c.contactTitle,c.officeTel,c.mobileNo,c.email,1 AS isDefault,a.isLocked,a.lockerId,
      u1.userNick AS lockerName,CONVERT(VARCHAR(10),a.lockedTime,23) AS lockedTime,a.createTime,
      a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName,a.remarks,a.isSelected      
FROM dbo.BAS_Partner a LEFT JOIN
      dbo.BAS_Partner p ON a.parentId=p.partnerId LEFT JOIN
      dbo.BAS_PartnerFinancial_V f ON a.partnerId=f.partnerId LEFT JOIN
      dbo.BAS_Area a1 ON a.companyState=a1.areaId LEFT JOIN
      dbo.BAS_Area a2 ON a.companyCity=a2.areaId LEFT JOIN
      dbo.BAS_Area a3 ON a.companyDistrict=a3.areaId LEFT JOIN
      dbo.BAS_PartnerType t ON a.typeId=t.typeId LEFT JOIN
      dbo.BAS_StaffSize s ON a.staffSizeId=s.staffSizeId LEFT JOIN
      dbo.BAS_Nature n on a.natureId=n.natureId LEFT JOIN
      dbo.BAS_Trade d ON a.tradeId=d.tradeId LEFT JOIN
      dbo.SAM_User u1 ON a.lockerId=u1.userId LEFT JOIN
      dbo.SAM_User u2 ON a.creatorId=u2.userId LEFT JOIN
      dbo.SAM_User u3 ON a.editorId=u3.userId LEFT JOIN
      (SELECT DISTINCT companyId,partnerId,contactName,contactTitle,officeTel,mobileNo,email,sex
       FROM BAS_Contact 
       WHERE isDefault=1) c ON a.partnerId=c.partnerId
go

