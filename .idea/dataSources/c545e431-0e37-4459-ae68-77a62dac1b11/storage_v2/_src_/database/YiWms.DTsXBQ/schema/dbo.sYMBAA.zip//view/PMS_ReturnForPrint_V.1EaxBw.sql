
/*==============================================================*/
/* View: PMS_ReturnForPrint_V                                   */
/*==============================================================*/
create view PMS_ReturnForPrint_V as
SELECT a.returnNo,a.returnDate,a.companyId,c.companyName,a.billNo,a.warehouseId,w.warehouseNo,
	w.warehouseName,a.supplierId,s.partnerNo AS supplierNo,s.partnerName AS supplierName,s.shortName,
	a.ioType,'采购退货单' AS ioTypeDesc,a.reason,a.expressNo,a.logisticsId,l.logisticsName,
	e1.employeeName AS handlerName,e2.employeeName AS buyerName,d.deptName,ISNULL(a.printNum,0)+1 AS printNum,
	CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,u2.userNick AS auditorName,a.retField1,a.retField2,
	a.retField3,a.retField4,a.retField5,a.memo,a.createTime,u1.userNick AS creatorName,b.orderBillNo,
	b.stockBillNo,b.viewOrder,bi.itemNo,bi.itemName,bi.itemSpec,bi.colorName,bi.sizeName,bi.unitName,
	bi.barcode,bi.midBarcode,bi.bigBarcode,bi.pkgBarcode,b.returnQty,b.pkgQty,b.bulkQty,b.befPrice,
	b.discount,b.discountFee,b.price,b.taxrate,b.fee,b.taxFee,b.totalFee,b.locationNo,b.lotNo,b.remarks
FROM dbo.PMS_Return a
    INNER JOIN dbo.PMS_ReturnDetail b ON a.returnNo=b.returnNo 
    INNER JOIN dbo.BAS_Item bi ON b.itemId=bi.itemId
    INNER JOIN dbo.SAM_Company c ON a.companyId=c.companyId
    INNER JOIN dbo.BAS_Partner s ON a.supplierId=s.partnerId
    INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
    LEFT JOIN dbo.BAS_Logistics l ON a.logisticsId=l.logisticsId
    LEFT JOIN dbo.BAS_Department d ON a.deptId=d.deptId
    LEFT JOIN dbo.BAS_Employee e1 ON a.handlerId=e1.employeeId
    LEFT JOIN dbo.BAS_Employee e2 ON a.buyerId=e2.employeeId
    LEFT JOIN dbo.SAM_User u1 ON a.creatorId=u1.userId
    LEFT JOIN dbo.SAM_User u2 ON a.auditorId=u2.userId
go

