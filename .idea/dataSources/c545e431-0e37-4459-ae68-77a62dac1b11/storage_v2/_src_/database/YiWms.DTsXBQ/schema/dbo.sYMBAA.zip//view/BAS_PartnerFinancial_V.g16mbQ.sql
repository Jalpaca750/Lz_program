
/*==============================================================*/
/* View: BAS_PartnerFinancial_V                                 */
/*==============================================================*/
create view BAS_PartnerFinancial_V as
SELECT a.partnerId,a.companyId,a.financialName,a.financialTel,a.invoiceDay,a.affterDelivery,
      a.payTermLimited,a.payTerm,a.creditLimited,a.creditFee,a.priceLimited,a.rebate1,a.rebate2,
      a.rebate3,a.defPrice,a.befPrice,a.taxFlag,a.payMode,a.isTogether,a.currencyId,a.arFee,
      a.preFee,a.integral,a.salesId,e1.employeeName as salesName,a.assistantId,
      e2.employeeName AS assistantName,a.outerId,e3.employeeName AS outerName
FROM BAS_PartnerFinancial a LEFT JOIN
      dbo.BAS_Employee e1 ON a.salesId=e1.employeeId LEFT JOIN
      dbo.BAS_Employee e2 ON a.assistantId=e2.employeeId LEFT JOIN
      dbo.BAS_Employee e3 ON a.outerId=e3.employeeId
go

