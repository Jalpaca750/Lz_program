

/*
select Volume,MAXpachun ,(a.Height/a.MAXpachun) itemHeight,   ---单位高度
(a.Width/a.MAXpachun)  itemWidth,    ---单位宽度
(a.Length/a.MAXpachun) itemLong,     ---单位长度
(a.Volume/a.MAXpachun) itemVolume   ---单位体积 
from sap_iteminfo a where itemcode='005616'
*/

--exec up_SyncBasicItem_INIT '1707AED3C85145CB92763B6FA619A438','0b4a6d1ec9bc4aaa8cdd996ece08441c','zdy','2017-04-23','2017-04-23'


CREATE Proc  [dbo].[up_SyncBasicItem_INIT]
(
    @companyId VARCHAR(32),		--公司Id,如果前台调用，需传值，为空时，手动修改这个值
	@ownerId VARCHAR(32),		--业主Id
	@creatorId VARCHAR(32),		--操作员，前天调用的当前用户，后台执行时，可赋值
	@startTime DATETIME,		--同步产品的开始时间（修改时间）
	@endTime DATETIME			--同步产品的截至时间（修改时间）
)
as
declare  @itemId varchar(32)='',--主键ID
         @itemNo varchar(32)='',--SKU编码
         @itemName varchar(100)='',--SKU名称
         @itemSpell varchar(200)='',--拼音码
         @barCode    varchar(100)='',--条码
         @brandId    varchar(32)='',--品牌 FirmName
         @categoryId varchar(32)='',--分类码
         @brandName  varchar(100)='',--品牌
         @itemSpec   varchar(100)='',--规格
         @colorName  varchar(100)='',--颜色
		 @unitName   varchar(100)='',--单位
		 @cate1      varchar(200),--分类 一级
		 @cate2      varchar(200),--分类 二级
		 @cate3      varchar(200),--分类 三级
		 @frozenFor  int,--是否冻结
		 @memo       varchar(2000),--备注
		 @zt         int,   --同步状态
		 @isSync   int,    --同步是否OK
		 @errorCount int, -- 错误数量
		 @cid1  varchar(32)='',--一级分类的ID
		 @cid2  varchar(32)='', --二级分类的ID
		 @cid3  varchar(32)='' --三级分类的ID
		 declare @flag int =0
		 declare @brand_isr varchar(30)
		 declare @tab_brand  table (bname varchar(100))
		 declare @jsq int =0  --计数器
		 DECLARE @BIT_FLAG INT =0  --批量的
begin
-------------------先把商品状态更新为待执行的事务--------------------------------------------
update  DBVIP.WMSSystem.dbo.sap_item set zt=3 where zt=0
----------------插入品牌事务------------------------------------
DECLARE  @MAX_BNO INT 
BEGIN TRY
    SELECT @MAX_BNO=cast(MAX(brandNo) as int) from BAS_Brand
END TRY 
BEGIN CATCH
       SELECT @MAX_BNO=COUNT(brandId)from BAS_Brand
END CATCH
set @MAX_BNO=ISNULL(@MAX_BNO,1)
----插入品牌 
BEGIN TRY
declare @brand_tab table(firmname varchar(200),bid int ,brand_no int)
insert into @brand_tab(firmname,bid,brand_no)
select a.firmname,len(isnull(b.brandid,'')) bid,@MAX_BNO+(ROW_NUMBER() OVER (ORDER BY b.brandid))
from(
select firmname from DBVIP.WMSSystem.dbo.sap_item 
where  LEN(firmname)>0
group by firmname ) a 
   left join BAS_Brand b
on a.firmname=b.brandCName
---插入品牌
insert into BAS_Brand(brandId,companyId,brandNo,brandCName,brandEName,pictureUrl,
usage,isRecommend,viewOrder,isDisable,isLocked,createTime,creatorId,editTime,editorId,isSelected)
select REPLACE(NEWID(),'-',''),@companyId,(brand_no),firmname,firmname,'',
0,0,(brand_no),0,0,GETDATE(),@creatorId,GETDATE(),@creatorId,0
from  @brand_tab where bid=0
print '插入品牌成功'
END TRY
BEGIN CATCH
print '插入品牌错误'
END CATCH

----------------------------------------------------------------
  
------------------------------------------------索引
/*========体积、长、宽、高、转换比==================*/


DECLARE   @itemHeight DECIMAL(10,2),
          @itemWidth  DECIMAL(10,2),
          @itemLong   DECIMAL(10,2),
          @itemVolume DECIMAL(10,2),
          @itemWeight DECIMAL(10,2),
          @pkgRatio   DECIMAL(10,2),
          @pkgUnit    varchar(40),
          @pkgHeight  DECIMAL(10,2),
          @pkgWidth   DECIMAL(10,2),
          @pkgLong    DECIMAL(10,2),
          @pkgWeight  DECIMAL(10,2),
          @pkgVolume  DECIMAL(10,2),
          @pkgBarcode varchar(100)='',   --整包条码   
          @packageId varchar(32)='' --包装规格
		 

declare   FMyCursor  cursor local   FOR 
select
[itemcode],[ItemName],--商品名称
[PinYinMa],--拼音码,
isnull([CodeBars],'') CodeBars,--条形码
isnull([U_Model],'') U_Model,--规格
isnull([U_Color],'') U_Color,--颜色
[SalUnitMsr],--单位
[FirmName],--品牌
isnull([Kind1],'') Kind1,--大类
isnull([Kind2],'') Kind2,--中类
isnull([Kind3],'') Kind3,--小类
(case [frozenFor] when 'Y' then 0 else 1 end) frozenFor,-- —-是否冻结（Y：冻结，N：活动）
isnull([memo],'') meno,--备注
[ZT],--同步状态  
b.brandId,  --品牌ID
a.codebars2 pkgBarcode, --整包条码
a.packing   packageId,   --包装规格
(a.Height/a.MAXpachun) itemHeight,   ---单位高度
(a.Width/a.MAXpachun)  itemWidth,    ---单位宽度
(a.Length/a.MAXpachun) itemLong,     ---单位长度
(a.Volume/a.MAXpachun) itemVolume,   ---单位体积
(isnull(a.Weight,0)) itemWeight,             ---单位重量
a.MAXpachun   pkgRatio,            ---转换比
a.maxpackmsr  pkgUnit,             ---整包装单位
a.Height  pkgHeight ,              ---整包装高度
a.Width   pkgWidth,                ---整包装宽度
a.Length  pkgLong  ,               ---整包装长度
(a.Weight*a.MAXpachun) pkgWeight,     ---整包装重量
a.Volume  pkgVolume                ---整包装体积
from DBVIP.WMSSystem.dbo.sap_item  a left join 
BAS_Brand b on a.FirmName=b.brandCName 
and b.companyId=@companyId
where  a.zt=3
for read only
----------------------------------------------------------------------------------
--  开始处理业务
--打开游标，然后一个一个去处理 
---------------------------------------------------------------------------------

OPEN  FMyCursor ---打开游标
		Fetch  NEXT  FROM FMyCursor  into   
		@itemNo,@itemName,@itemSpell,@barCode,
		@itemSpec,@colorName,@unitName,@brandName,@cate1,@cate2,@cate3,
		@frozenFor,@memo,@zt,@brandId,@pkgBarcode,@packageId,
		@itemHeight ,
		@itemWidth  ,
		@itemLong   ,
		@itemVolume ,
		@itemWeight ,
		@pkgRatio   ,
		@pkgUnit    ,
		@pkgHeight  ,
		@pkgWidth   ,
		@pkgLong    ,
		@pkgWeight  ,
		@pkgVolume  
	WHILE @@fetch_status=0 
	BEGIN  
	    set @itemId=''
	    set @categoryId=''
	    set @flag=0
	    set @jsq+=1
	          ----------------------处理品牌
	         BEGIN TRY
	          begin tran  temp_tran
	         
	          ---------------------处理商品
	          set @itemId=''
	          select @itemId=itemId 
	          from BAS_Item 
	          where companyId=@companyId and  ownerId=@ownerId and  itemNo=@itemNo
	          
	          if LEN(@itemId)>0
	          begin  --如果存在就更新现有商品
	               update BAS_Item  
	               set 
	               itemCTitle=@itemName,
	               itemName=@itemName,
	               itemSpec=@itemSpec,
	               itemSpell=@itemSpell,
	               barcode=(case len(@barCode) when  0  then barcode else @barCode end),
	               brandId=@brandId,
	               categoryId=@categoryId,
	               colorName=@colorName,
	               remarks=@memo,
	               editTime=GETDATE(),
	               editorId=@creatorId,
	               shopUrl=(@cate1+'>'+@cate2+'>'+@cate3),
	               pkgBarcode=@pkgBarcode,
	               packageId=@packageId,
				itemHeight=@itemHeight,
				itemWidth=@itemWidth,
				itemLong=@itemLong,
				itemVolume=@itemVolume,
				itemWeight=@itemWeight,
				pkgRatio=isnull(@pkgRatio,0),
				pkgUnit=@pkgUnit,
				pkgHeight=@pkgHeight,
				pkgWidth=@pkgWidth,
				pkgLong=@pkgLong,
				pkgWeight=@pkgWeight,
				pkgVolume=@pkgVolume
				
			   where itemId=@itemId
	               ---更新SKU
	               update ECM_ItemSku set colorname=colorName,unitName=@unitName
	               where itemId=@itemId
	          end
	          else 
	          begin
	             --如果不存在的话就新增
	             print '插入主表'
	                set @itemId= REPLACE(NEWID(),'-','')
	             --如果存在的话就更新
					INSERT INTO dbo.BAS_Item(itemId,companyId,itemNo,itemCTitle,
					itemETitle,itemName,itemSpec,itemSpell,
					barcode,brandId,categoryId,colorName,
					sizeName,unitName,itemState,ownerId,commodityId,remarks,
					isLocked,lockerId,lockedTime,createTime,creatorId,editTime,
					editorId,shopUrl,pkgBarcode,packageId,
					itemHeight,itemWidth,itemLong,itemVolume,itemWeight,pkgRatio,pkgUnit,pkgHeight,
				    pkgWidth,pkgLong,pkgWeight,pkgVolume
					)
					values(@itemId,@companyId,@itemNo,@itemName,'',@itemName,@itemSpec,@itemSpell,
					@barCode,@brandId,@categoryId,@colorName,'',@unitName,@frozenFor,@ownerId,'',@memo,
					0,@creatorId,null,GETDATE(),@creatorId,GETDATE(),
					@creatorId,(@cate1+'>'+@cate2+'>'+@cate3),@pkgBarcode,@packageId,
					@itemHeight,@itemWidth,@itemLong,@itemVolume,@itemWeight,@pkgRatio,@pkgUnit,
					@pkgHeight,
				    @pkgWidth,@pkgLong,@pkgWeight,@pkgVolume
					)
					---插入SKU
					print '插入SKU'
					INSERT INTO ECM_ItemSku(itemId,eId,colorId,colorName,sizeId,sizeName,unitId,unitName)
					values(@itemId,REPLACE(NEWID(),'-',''),'c999',@colorName,'s99','','EA',@unitName)
					print '插入SKU'
	          end
	          set  @flag=1
	         commit   tran temp_tran
	         update  DBVIP.WMSSystem.dbo.sap_item  set zt=1 where itemcode=@itemNo
	       END TRY
           BEGIN CATCH
			IF @@TRANCOUNT > 0
			ROLLBACK  tran temp_tran
			update  DBVIP.WMSSystem.dbo.sap_item  set zt=-1   where  itemcode=@itemNo
		    print '插入SKU失败'+ERROR_MESSAGE()
		    insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
            select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncBasicItem',@itemNo,ERROR_MESSAGE(),GETDATE()  
            END CATCH
	    ---取下一条
	    
	  BEGIN TRY
	    
	   Fetch  NEXT  FROM FMyCursor  into   
		@itemNo,@itemName,@itemSpell,@barCode,
		@itemSpec,@colorName,@unitName,@brandName,@cate1,@cate2,@cate3,
		@frozenFor,@memo,@zt,@brandId,@pkgBarcode,@packageId,
		@itemHeight ,
		@itemWidth  ,
		@itemLong   ,
		@itemVolume ,
		@itemWeight ,
		@pkgRatio   ,
		@pkgUnit    ,
		@pkgHeight  ,
		@pkgWidth   ,
		@pkgLong    ,
		@pkgWeight  ,
		@pkgVolume  
		 END TRY
           BEGIN CATCH
              select @itemNo,error_number() as error_number ,
             error_message() as error_message
           END Catch
		
		
	    end
	    CLOSE FMyCursor
	    Deallocate FMyCursor
end
 











go

