

/*==============================================================*/
/* View: WMS_PickingFCL_V                                       */
/*==============================================================*/
--creator：     Frank
--create time:  2017-03-18
--Description: 整箱分拣标签打印
--@modify in 2017-09-13 
--@editer zdy
--@content  add  'shortname'  to view  --(SELECT COUNT(pickingId) FROM WMS_PickingDetail WHERE pickingNo=a.pickingNo)
--frank.he 2017-10-17 日整理 (再打包模式整件和拼箱分开打印,否则拼箱件数不准确）
--frank.he 2018-03-13 日增加 ordField3(文之选地址辖区用）字段 --c.stockQty AS itemPrintQty
CREATE view [dbo].[WMS_PickingFCL_V] as
SELECT '' poNo,null serviceFee,'' AS itemPrintQty,a.pickId,a.pickingNo,a.companyId,a.stockNo,a.stockBillNo,a.stockBox,a.boxBillNum,
	d.customerNo,b.lclQty,a.pkgQty AS fclQty,a.pkgQty,ISNULL(a.pkgQty,0)+ISNULL(b.lclQty,0) AS totalQty,a.skuQty,
	a.taskState,d.customerName,d.shortName,d.customerDepart,r.regionDesc,al.lineName,ISNULL(r.regionDesc,a.cargoArea) AS tmpRegion,
	d.collectOrder AS lineOrder,d.mergeNo,u1.userNo AS pickerNo,u1.userNick AS pickerName,CONVERT(VARCHAR(20),a.pickTime,120) AS pickTime,
	u2.userNo AS checkerNo,u2.userNick AS checkerName,CONVERT(VARCHAR(20),a.checkTime,120) AS checkTime,
	CONVERT(VARCHAR(20),p.getTime,120) AS getTime,u3.userNo AS packagerNo,u3.userNick AS packagerName,
	CONVERT(VARCHAR(20),a.packingTime,120) AS packingTime,d.fullAddress,d.receiverName,
	LTRIM(ISNULL(d.receiverMobile,'')+' '+ISNULL(d.receiverTel,'')) AS fullTel,c.itemNo,c.itemName,c.itemSpec,
	c.barcode,c.colorName,c.sizeName,c.unitName,c.locationNo,c.batchNo AS lotNo,p.waveBillNo,c.pickQty,c.pkgUnit,
	ISNULL(c.pickQty,0.0)*ISNULL(c.pkgRatio,0.0) AS stockQty,c.packageId,p.printNum,p.printTime,d.organizeId,
    c.pickingOrder,c.isPrint,c.pickingId,d.collectOrder,d.buyerId,d.memo,d.ordField3,
	'第'+CAST(cast(a.stockBox AS INT) AS VARCHAR)+'件 共'+ CAST(cast(a.pkgQty AS INT) AS VARCHAR)+'件' AS labDesc,
    '总计:'+CAST(CAST(ISNULL(a.pkgQty,0) AS INT) AS VARCHAR)+'件' labTotalDesc,
    '整 ' + CAST(a.stockBox AS VARCHAR) + '/' + CAST(CAST(a.pkgQty AS INT) AS VARCHAR) + ' 总 ' + CAST(CAST(ISNULL(a.pkgQty,0)+ISNULL(b.lclQty,0) AS INT) AS VARCHAR) AS pickingDesc
FROM dbo.WMS_PickingOrder a
	INNER JOIN (SELECT stockNo,SUM(CASE isPackage WHEN 0 THEN 1 ELSE 0 END) lclQty
				FROM dbo.WMS_PickingOrder
                GROUP BY stockNo) b ON a.stockNo=b.stockNo                  
	INNER JOIN (SELECT pd.stockQty,pd.pickingId,pd.printNum isPrint,pd.pickId,bi.itemNo,bi.itemName,bi.itemSpec,bi.barcode,
					bi.colorName,bi.sizeName,bi.unitName,pd.pickQty,bi.pkgUnit,pd.pkgRatio,pd.batchNo,pd.locationNo,bi.packageId,
                    loc.pickingOrder,pd.realQty
                FROM dbo.WMS_PickingDetail pd
                    INNER JOIN dbo.BAS_Item bi ON pd.itemId=bi.itemId
                    INNER JOIN dbo.BAS_Location loc ON pd.companyId=loc.companyId AND pd.warehouseId=loc.warehouseId AND pd.locationNo=loc.locationNo
                ) c ON a.pickId=c.pickId
	INNER JOIN (SELECT x.buyerId,x.memo,x.stockNo,p.partnerNo AS customerNo,p.partnerName AS customerName,
					p.shortName,x.organizeId,x.mergeNo,x.receiverName,x.receiverMobile,x.receiverTel,
                    RTRIM(ISNULL(p.partnerName,'') + '  ' + ISNULL(x.organizeId,'')) AS customerDepart,
                    ISNULL(x.receiverAddress,'') AS fullAddress,x.collectOrder,x.taskState,x.ordField3
                FROM dbo.SAD_Stock x
                    INNER JOIN dbo.BAS_Partner p ON x.customerId=p.partnerId
                ) d ON a.stockNo=d.stockNo
	INNER JOIN dbo.WMS_Picking p ON a.pickingNo=p.pickingNo
	LEFT JOIN dbo.BAS_AddressLine al ON a.lineId=al.lineId
	LEFT JOIN dbo.BAS_Region r ON a.cargoArea=r.regionId
	LEFT JOIN dbo.SAM_User u1 ON a.pickerId=u1.userId
	LEFT JOIN dbo.SAM_User u2 ON a.checkerId=u2.userId
	LEFT JOIN dbo.SAM_User u3 ON a.packingId=u3.userId
WHERE a.isPackage=1



go

