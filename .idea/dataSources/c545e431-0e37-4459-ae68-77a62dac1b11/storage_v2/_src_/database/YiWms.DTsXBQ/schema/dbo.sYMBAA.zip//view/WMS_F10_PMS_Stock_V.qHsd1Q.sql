
--2.修改采购入库单同步视图，单据状态从20改为10
/*==============================================================*/
/* View: WMS_F10_PMS_Stock_V                                    */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_PMS_Stock_V] as
SELECT a.stockNo AS wmsOrder,a.billNo AS wmsBillNo,a.billNo AS stockNo,CONVERT(VARCHAR(10),a.receiveDate,23) AS createDate,
	a.companyId,a.ownerId,a.totalFee,d.CodeID AS deptNo,w.warehouseNo AS warehouse,b.vendorID,a.deliveryNo AS sendNo,a.PostFee,
	a.OrderSource AS orderType,'20' AS BillSts,CONVERT(VARCHAR(10),a.auditTime,23) AS auditTime,u1.employeeID AS auditId,
	a.printNum,u3.employeeID AS printerId,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,u4.employeeID AS RecieverId,
	CONVERT(VARCHAR(20),a.createTime,120) AS RecieverTime,u2.employeeID AS creatorId,a.mergeNo AS orderNo,a.memo AS remarks
FROM dbo.PMS_Stock a 
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	INNER JOIN F10BMS.dbo.WMS_F10_Supplier_V b ON a.supplierId=b.supplierId
	LEFT JOIN F10BMS.dbo.WMS_F10_Department_V d ON a.deptId=d.deptId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u1 ON a.auditorId=u1.userId 
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u2 ON a.creatorId=u2.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u3 ON a.printId=u3.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u4 ON a.receiverId=u4.userId
WHERE (a.ioState=30)
	AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2)
    AND (a.orderSource IN(11,12,13,14,15,16,17,18))

go

