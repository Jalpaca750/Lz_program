
/*==============================================================*/
/* View: CGRK_MX                 
                               */
 --@edit:张东彦 2017-07-07返回时候明细加入商品编码
/*==============================================================*/
create view [dbo].[CGRK_MX] as
SELECT b.ownerNo AS YEZ_ID,b.billNo AS DANJ_NO,b.mergeNo AS SHANGJ_DANJ_NO,a.viewOrder AS linenum,
      bi.itemNo AS itemcode,a.receiveQty AS quantity,a.price,a.totalFee AS linetotal,od.viewOrder AS HANGHAO,
      w.warehouseNo as WHNO
FROM dbo.PMS_StockDetail a INNER JOIN 
      (SELECT x.stockNo,y.ownerNo,x.billNo,x.mergeNo
       FROM dbo.PMS_Stock x LEFT JOIN 
             dbo.BAS_Owner_V y ON x.ownerId=y.ownerId
       WHERE (x.ioType='P100') AND (x.ioState=30) AND (x.thirdSyncFlag=0 OR x.thirdSyncFlag=2)) b ON a.stockNo=b.stockNo INNER JOIN
      dbo.PMS_OrderDetail od ON a.orderId=od.orderId INNER JOIN 
      dbo.BAS_Item bi ON a.itemId=bi.itemId
      INNER JOIN BAS_Warehouse W on a.warehouseId=W.warehouseId


go

