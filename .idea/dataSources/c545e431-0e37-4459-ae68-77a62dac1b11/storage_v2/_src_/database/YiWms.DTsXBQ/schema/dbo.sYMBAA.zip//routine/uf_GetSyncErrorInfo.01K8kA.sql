CREATE FUNCTION uf_GetSyncErrorInfo
(
	@companyId VARCHAR(32)
)
RETURNS TABLE
RETURN(
	SELECT ioType,CASE ioType WHEN 'S100' THEN '销售出库单' WHEN 'D200' THEN '调拨出库单' WHEN 'L100' THEN '领用出库单' WHEN 'G200' THEN '赠品出库单' WHEN 'B200' THEN '报损出库单' WHEN 'O100' THEN '其他出库单' END AS ioTypeDesc,
		stockNo,billNo,createTime,thirdSyncFlag,CASE thirdSyncFlag WHEN 0 THEN '待同步' WHEN 2 THEN '同步出错' END AS syncFlagDesc
	FROM SAD_Stock
	WHERE (companyId=@companyId)
		AND (taskState>60)
		AND (thirdSyncFlag=0 OR thirdSyncFlag=2)
	UNION ALL
	SELECT ioType,CASE ioType WHEN 'P100' THEN '采购入库单' WHEN 'D100' THEN '调拨入库单' WHEN 'G100' THEN '赠品入库单' WHEN 'O200' THEN '其他入库单' END AS ioTypeDesc,
		stockNo,billNo,createTime,thirdSyncFlag,CASE thirdSyncFlag WHEN 0 THEN '待同步' WHEN 2 THEN '同步出错' END AS syncFlagDesc
	FROM PMS_Stock
	WHERE (companyId=@companyId)
		AND (ioState=30)
		AND (thirdSyncFlag=0 OR thirdSyncFlag=2)
	UNION ALL
	SELECT ioType,'销售退货单' AS ioTypeDesc,returnNo,billNo,createtime,thirdSyncFlag,CASE thirdSyncFlag WHEN 0 THEN '待同步' WHEN 2 THEN '同步出错' END AS syncFlagDesc
	FROM SAD_Return
	WHERE (companyId=@companyId)
		AND (ioState=30)
		AND (thirdSyncFlag=0 OR thirdSyncFlag=2)
	UNION ALL
	SELECT ioType,'采购退货单' AS ioTypeDesc,returnNo,billNo,createTime,thirdSyncFlag,CASE thirdSyncFlag WHEN 0 THEN '待同步' WHEN 2 THEN '同步出错' END AS syncFlagDesc
	FROM PMS_Return
	WHERE (companyId=@companyId)
		AND (ioState=20)
		AND (thirdSyncFlag=0 OR thirdSyncFlag=2)
	UNION ALL
	SELECT 'T100' AS ioType,CASE billType WHEN 10 THEN '盘亏调整单' WHEN 20 THEN '盘亏调整单' WHEN 11 THEn '盘盈调整单' WHEN 21 THEN '盘盈调整单' END AS ioTypeDesc,
		adjustNo,billNo,createTime,thirdSyncFlag,CASE thirdSyncFlag WHEN 0 THEN '待同步' WHEN 2 THEN '同步出错' END AS syncFlagDesc                                                 
	FROM IMS_Adjust
	WHERE (companyId=@companyId)
		AND (ioState=20)
		AND (thirdSyncFlag=0 OR thirdSyncFlag=2)
	UNION ALL 
	SELECT 'Y100' AS ioType,'移仓单' AS ioTypeDesc,transferNo,billNo,createTime,thirdSyncFlag,CASE thirdSyncFlag WHEN 0 THEN '待同步' WHEN 2 THEN '同步出错' END AS syncFlagDesc 
	FROM IMS_Transfer
	WHERE (companyId=@companyId)
		AND (ioState=2)
		AND (thirdSyncFlag=0 OR thirdSyncFlag=2)
		AND (outputId!=inputId)
)
go

