/*==============================================================*/
/* View: SAD_StockDetail_V                                      */
/*==============================================================*/
--creator：        WANG_Jun
--create time：  2016-11-06
--modify: Frank.He 2016-12-21日整理
--        Frank.He 2017-08-15日优化
--销售出库单明细列表
CREATE view [dbo].[SAD_StockDetail_V] as
SELECT b.stockId,b.stockNo,a.billNo,a.createtime,a.ioType,a.ioState,a.taskState,b.orderId,b.orderNo,b.orderBillNo,
      b.companyId,b.warehouseId,bw.warehouseNo,bw.warehouseName,b.viewOrder,b.lotNo,b.locationNo,b.eId,b.itemId,
      sku.itemNo,sku.itemCTitle,sku.itemETitle,sku.itemName,sku.itemSpec,sku.itemSpell,sku.sellingPoint,sku.barcode,
      sku.brandId,sku.brandNo,sku.brandCName,sku.brandEName,sku.categoryId,sku.categoryNo,sku.categoryCName,
      sku.categoryEName,sku.colorName,sku.sizeName,sku.unitName,b.stockQty,b.pickQty AS actQty,sku.pkgUnit,
      sku.pkgRatio,b.pkgQty,b.bulkQty,b.pkgVolumn,b.bulkVolumn,b.pkgWeight,b.bulkWeight,
      b.stockQty*sku.itemVolume AS totalVolume,b.stockQty*sku.itemWeight AS totalWeight,b.befPrice,b.discount,
      b.discountFee,b.price,b.taxrate,b.fee,b.taxFee,b.totalFee,ISNULL(b.pickQty,0.0) - ISNULL(b.returnQty,0.0) AS residueQty,
      b.toOrder,b.updPrice,b.isPromotion,b.isGift,b.needAssemble,b.groupId,b.isVirtual,b.costPrice,b.rebate,b.returnQty,
      b.invoiceQty,b.invoiceFee,b.payQty,b.payFee,b.pickingId,b.pickingTime,b.salesId,b.handlerId,b.deptId,b.contractId,
      b.contractNo,sku.largeUrl,sku.middleUrl,sku.smallUrl,sku.littleUrl,sku.itemVolume,sku.itemWeight,sku.pkgVolume,
      sku.pkgWeight AS pkgGrossWeight,sku.webPrice,sku.marketPrice,sku.vipPrice,sku.retailPrice,sku.tradePrice,
      sku.salesPrice,sku.purPrice,sku.lastPurPrice,sku.minPrice,sku.maxPrice,sku.midBarcode,sku.bigBarcode,sku.pkgBarcode,sku.packageId,
      STUFF((SELECT ',' + CAST(boxNum AS VARCHAR(10)) FROM WMS_PackingBox_V WHERE stockId=b.stockId FOR XML PATH('')),1,1,'') AS boxNums,
      b.boneOrdId,b.remarks,b.isSelected
FROM dbo.SAD_StockDetail AS b 
      INNER JOIN dbo.SAD_Stock AS a ON b.stockNo = a.stockNo 
      INNER JOIN dbo.BAS_Goods_V AS sku ON b.itemId = sku.itemId 
      INNER JOIN dbo.BAS_Warehouse AS bw ON b.warehouseId=bw.warehouseId


go

