



--4.修改其他入出库（赠品，调拨，其他入出库等）同步视图，单据状态改为10
CREATE view [dbo].[WMS_F10_IMS_Other_V] as
SELECT a.stockNo AS wmsOrder,a.billNo AS wmsBillNo,a.billNo AS stockNo,CONVERT(VARCHAR(10),a.receiveDate,23) AS createDate,
	a.companyId,a.ownerId,a.totalFee,d.CodeID AS deptNo_I,w.warehouseNo AS warehouse,b.deptId AS DeptNo_O,a.deliveryNo AS sendNo,
	a.OrderSource AS orderType,'10' AS BillSts,CONVERT(VARCHAR(10),a.auditTime,23) AS auditTime,u1.employeeID AS auditId,
	a.printNum,u3.employeeID AS printerId,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,u4.employeeID AS RecieverId,
	CONVERT(VARCHAR(20),a.createTime,120) AS RecieverTime,u2.employeeID AS creatorId,a.mergeNo AS orderNo,a.memo AS remarks
FROM dbo.PMS_Stock a 
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	LEFT JOIN F10BMS.dbo.WMS_F10_DBSupplier_V b ON a.supplierId=b.supplierId
	LEFT JOIN F10BMS.dbo.WMS_F10_Department_V d ON a.deptId=d.deptId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u1 ON a.auditorId=u1.userId 
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u2 ON a.creatorId=u2.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u3 ON a.printId=u3.userId
	LEFT JOIN F10BMS.dbo.WMS_F10_User_V u4 ON a.receiverId=u4.userId
WHERE (a.ioState=30)
	AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2)
    AND (a.orderSource=21 OR a.orderSource=31 OR a.orderSource=41)
go

