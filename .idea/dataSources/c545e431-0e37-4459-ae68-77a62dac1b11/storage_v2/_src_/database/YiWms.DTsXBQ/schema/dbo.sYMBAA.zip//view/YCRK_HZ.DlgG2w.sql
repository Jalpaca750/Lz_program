
/*==============================================================*/
/* View: YCRK_HZ                                                */
/*==============================================================*/
create view YCRK_HZ as
SELECT a.billNo AS DANJ_NO,CONVERT(VARCHAR(10),a.createTime,23) AS docdate,w1.warehouseNo AS WhsCode,
      w2.warehouseNo AS TO_WhsCode,u1.userNo AS operator,a.thirdSyncFlag AS SC_FLG
FROM dbo.IMS_Transfer a INNER JOIN
      dbo.BAS_Warehouse w1 ON a.outputId=w1.warehouseId INNER JOIN
      dbo.BAS_Warehouse w2 ON a.inputId=w2.warehouseId LEFT JOIN
      dbo.SAM_User u1 ON a.creatorId=u1.userId
WHERE (a.ioState=2) AND (a.thirdSyncFlag=0) AND (w2.storage=1) AND (w1.storage=0)
go

