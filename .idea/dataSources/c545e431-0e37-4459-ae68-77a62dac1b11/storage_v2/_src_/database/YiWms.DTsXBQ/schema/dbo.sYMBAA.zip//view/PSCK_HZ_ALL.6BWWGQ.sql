

CREATE view [dbo].[PSCK_HZ_ALL] as

/*此视图SAP需要用，请勿改动*/

SELECT b.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,CONVERT(VARCHAR(10),a.auditTime,23) AS docdate,
      a.memo AS comments,u.userNo AS U_opcode,w.warehouseNo AS whNo,u.userNick AS U_OPNAME,
      '调拨出库' AS YEW_TYPE,a.thirdSyncFlag AS SC_FLG,v.customerNo,v.customerName,a.mergeNo
FROM dbo.SAD_Stock a INNER JOIN
      dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId LEFT JOIN
      dbo.BAS_Owner_V b ON a.ownerId=b.ownerId LEFT JOIN
      dbo.SAM_User u ON a.creatorId=u.userId left join 
      dbo.BAS_Customer_V v ON a.companyId=v.companyId and a.customerId=v.customerId
WHERE (a.orderType=20) AND (a.taskState>=60) --AND (a.thirdSyncFlag=0)




go

