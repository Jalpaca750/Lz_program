

/*==============================================================*/
/* View: WMS_ShipInvoice_V                                      */
/*==============================================================*/
CREATE view [dbo].[WMS_ShipInvoice_V] as
SELECT a.InvoiceID AS billNo,a.InvoiceNo AS stockBillNo,c.customerId,'' AS receiverState,
	'' AS receiverCity,'' AS receiverDistrict,a.SendAddr AS receiverAddress,ISNULL(addr.LinkMan,c.LinkMan) AS receiverName,
	ISNULL(addr.Phone,c.Phone) AS receiverTel,'' AS receiverMobile,0 AS pkgQty,0 AS fclQty,0.0 AS pkgVolumn,
	0 AS lclQty,0.0 AS lclVolumn,1 AS fileQty,a.CreateDate,0.0 AS netWeight,0.0 AS grossWeight,
	a.IAmt AS TotalFee,a.InvoiceNo AS mergeNo,70 AS billType,0 AS isInvalid,a.remarks,d.EmployeeName AS ServiceName,
	addr.viewOrder AS lineOrder
FROM F10BMS.dbo.SMS_Invoice a
	LEFT JOIN F10BMS.dbo.BDM_SendAddress addr ON a.CustID=addr.CustID AND a.SendAddr=addr.SendAddr AND a.LinkMan=addr.LinkMan
	INNER JOIN F10BMS.dbo.WMS_F10_Customer_V c ON a.CustID=c.CustID
	LEFT  JOIN F10BMS.dbo.BDM_Employee d ON a.CreatorID=d.EmployeeID 
WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30')
	AND (ISNULL(a.CarNumberSts,'')='')

go

