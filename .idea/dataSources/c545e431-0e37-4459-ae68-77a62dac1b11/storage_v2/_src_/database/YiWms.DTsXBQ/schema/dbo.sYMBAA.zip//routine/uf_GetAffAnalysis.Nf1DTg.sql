-- =============================================
-- Author:		<Author: Wang_Jun>
-- Create date: <Create Date:2017-05-05>
-- Description:	<Description:业绩报表 V1>
-- 包含：
-- =============================================
CREATE FUNCTION [dbo].[uf_GetAffAnalysis]
(
    @companyId VARCHAR(32),				        --公司Id
    @startTime DATETIME,						--起始时间
    @endTime DATETIME							--截止时间
)
RETURNS TABLE
RETURN(
	SELECT userId,userNick,SUM(soCount) AS soCount,SUM(waCount) AS waCount,SUM(prCount) AS prCount,SUM(psCount) AS psCount,SUM(adCount) AS adCount,
		SUM(ISNULL(ldCount,0)) AS ldCount,SUM(ISNULL(udCount,0)) AS udCount,SUM(ISNULL(bkCount,0)) AS bkCount,SUM(ISNULL(itemCount,0)) AS itemCount,SUM(ISNULL(moveCount,0)) AS moveCount,SUM(ISNULL(srCount,0)) AS srCount,
		SUM(ISNULL(soCount,0)+ISNULL(waCount,0)+ISNULL(prCount,0)+ISNULL(psCount,0)+ISNULL(adCount,0)+ISNULL(udCount,0)+ISNULL(ldCount,0)+ISNULL(bkCount,0)+ISNULL(itemCount,0)+ISNULL(moveCount,0)+ISNULL(srCount,0)) AS totalCount
	FROM (	
		--审核销售订单
		SELECT u1.userId,u1.userNick,COUNT(1) AS soCount,0 AS waCount,0 AS prCount,0 AS psCount,0 AS adCount,0 AS ldCount,0 AS udCount,0 AS bkCount,0 AS itemCount,0 AS moveCount,0 AS srCount
		FROM dbo.SAD_Stock a
			INNER JOIN dbo.SAM_User u1 ON a.creatorId=u1.userId 
		WHERE (a.companyId=@companyId)
			AND (a.createTime BETWEEN @startTime AND @endTime)
		GROUP BY u1.userId,u1.userNick
		UNION ALL
		--波次计划下达
		SELECT u2.userId,u2.userNick,0 AS soCount,COUNT(DISTINCT b.stockNo) AS waCount,0 AS prCount,0 AS psCount,0 AS adCount,0 AS ldCount,0 AS udCount,0 AS bkCount,0 AS itemCount,0 AS moveCount,0 AS srCount
		FROM dbo.WMS_Wave a 
			INNER JOIN dbo.WMS_WaveDetail b ON a.waveNo=b.waveNo
			INNER JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId
		WHERE (a.companyId=@companyId)
			AND (a.createTime BETWEEN @startTime AND @endTime)
		GROUP BY u2.userId,u2.userNick
		UNION ALL
		--采购退货制作
		SELECT u3.userId,u3.userNick,0 AS soCount,0 AS waCount,COUNT(1) AS prCount,0 AS psCount,0 AS adCount,0 AS ldCount,0 AS udCount,0 AS bkCount,0 AS itemCount,0 AS moveCount,0 AS srCount
		FROM PMS_Return a
			INNER JOIN dbo.SAM_User u3 ON a.creatorId=u3.userId
		WHERE (a.companyId=@companyId)
			AND (a.createTime BETWEEN @startTime AND @endTime)
		GROUP BY u3.userId,u3.userNick
		UNION ALL
		--收货单据（打印单据）制作
		SELECT u4.userId,u4.userNick,0 AS soCount,0 AS waCount,0 AS prCount,COUNT(1) AS psCount,0 AS adCount,0 AS ldCount,0 AS udCount,0 AS bkCount,0 AS itemCount,0 AS moveCount,0 AS srCount
		FROM PMS_Stock a
			INNER JOIN dbo.SAM_User u4 ON a.shelvesId=u4.userId
		WHERE (a.companyId=@companyId)
			AND (a.shelvesTime BETWEEN @startTime AND @endTime)
		GROUP BY u4.userId,u4.userNick
		UNION ALL
		--手工调整单
		SELECT u5.userId,u5.userNick,0 AS soCount,0 AS waCount,0 AS prCount,0 AS psCount,COUNT(1) AS adCount,0 AS ldCount,0 AS udCount,0 AS bkCount,0 AS itemCount,0 AS moveCount,0 AS srCount
		FROM dbo.IMS_Adjust a
			INNER JOIN dbo.SAM_User u5 ON a.creatorId=u5.userId
		WHERE (a.companyId=@companyId)
			AND (a.createTime BETWEEN @startTime AND @endTime)
			AND ISNULL(a.pointId,'')='' 
			AND (a.billType IN(20,21))
		GROUP BY u5.userId,u5.userNick
		UNION ALL
		SELECT u6.userId,u6.userNick,0 AS soCount,0 AS waCount,0 AS prCount,0 AS psCount,0 AS adCount,
			SUM(CASE a.wayState WHEN 10 THEN 1 ELSE 0 END) AS ldCount,
			SUM(CASE a.wayState WHEN 80 THEN 1 ELSE 0 END) AS udCount,
			SUM(CASE a.wayState WHEN 99 THEN 1 ELSE 0 END) AS bkCount,0 AS itemCount,0 AS moveCount,0 AS srCount
		FROM dbo.TMS_WaySite a 
			INNER JOIN dbo.SAM_User u6 ON a.creatorId=u6.userId
		WHERE (a.companyId=@companyId)
			AND (a.createTime BETWEEN @startTime AND @endTime)
			AND (a.wayState IN(10,80,99))
		GROUP BY u6.userId,u6.userNick
		UNION ALL
		SELECT userId,userNick,0 AS soCount,0 AS waCount,0 AS prCount,0 AS psCount,0 AS adCount,
			0 AS ldCount,0 AS udCount,0 AS bkCount,COUNT(1) AS itemCount,0 AS moveCount,0 AS srCount
		FROM (SELECT DISTINCT u7.userId,u7.userNick,v.itemId,v.editDate
			  FROM BAS_ItemVer v INNER JOIN SAM_User u7 ON v.editorId=u7.userId
			  WHERE (v.companyId=@companyId)
				  AND (v.editTime BETWEEN @startTime AND @endTime)
			  ) t
		GROUP BY userId,userNick
		UNION ALL
		SELECT u8.userId,u8.userNick,0 AS soCount,0 AS waCount,0 AS prCount,0 AS psCount,0 AS adCount,
			0 AS ldCount,0 AS udCount,0 AS bkCount,0 AS itemCount,COUNT(1) AS moveCount,0 AS srCount
		FROM dbo.IMS_Transfer a
			INNER JOIN dbo.SAM_User u8 ON a.creatorId=u8.userId
		WHERE (a.companyId=@companyId)
			AND (a.createTime BETWEEN @startTime AND @endTime)
			AND (a.ioState=2)
		GROUP BY u8.userId,u8.userNick
		UNION ALL
		--销售退货制作
		SELECT u9.userId,u9.userNick,0 AS soCount,0 AS waCount,0 AS prCount,0 AS psCount,0 AS adCount,0 AS ldCount,0 AS udCount,0 AS bkCount,0 AS itemCount,0 AS moveCount,COUNT(1) AS srCount
		FROM SAD_Return a
			INNER JOIN dbo.SAM_User u9 ON a.auditorId=u9.userId
		WHERE (a.companyId=@companyId)
			AND (a.auditTime BETWEEN @startTime AND @endTime)
		GROUP BY u9.userId,u9.userNick
		) t	
	GROUP BY userId,userNick
)



go

