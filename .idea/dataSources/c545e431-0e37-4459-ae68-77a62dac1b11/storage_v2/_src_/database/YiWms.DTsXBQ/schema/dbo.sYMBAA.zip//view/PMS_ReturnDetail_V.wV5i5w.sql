/*==============================================================*/
/* View: PMS_ReturnDetail_V                                     */
/*==============================================================*/
--creator：      Frank
--create time：  2016-03-17
--modify:        2017-11-23 review V1.2
CREATE view [dbo].[PMS_ReturnDetail_V] as
SELECT rd.returnId,rd.returnNo,r.billNo,CONVERT(VARCHAR(10),r.returnDate,23) AS returnDate,r.createTime, 
	r.supplierId,r.ioType,r.ioState,rd.stockId,rd.stockNo,rd.stockBillNo,rd.companyId,rd.warehouseId, 
	bw.warehouseNo,bw.warehouseName,rd.viewOrder,rd.lotNo,rd.locationNo,rd.eId,rd.itemId,sku.itemNo, 
	sku.itemCTitle,sku.itemETitle,sku.itemName,sku.itemSpec,sku.sellingPoint,sku.itemSpell,sku.barcode, 
	sku.midBarcode,sku.bigBarcode,sku.pkgBarcode,sku.brandId,sku.brandCName,sku.brandEName,sku.categoryId, 
	sku.categoryNo,sku.categoryCName,sku.categoryEName,sku.colorName,sku.sizeName,sku.unitName,sku.pkgUnit, 
	sku.pkgRatio,s.onhandQty,ISNULL(sd.receiveQty,0.0)-ISNULL(sd.returnQty,0.0)+ISNULL(rd.returnQty,0.0) AS returnAbleQty, 
	rd.returnQty,rd.pkgQty,rd.bulkQty,r.taxFlag,rd.befPrice,rd.discount,rd.discountFee,rd.price,rd.taxrate, 
	rd.fee,rd.taxFee,rd.totalFee,rd.invoiceQty,ISNULL(rd.returnQty, 0.0)-ISNULL(rd.invoiceQty, 0.0) AS invableQty, 
	rd.invoiceFee,ISNULL(rd.totalFee, 0.0)-ISNULL(rd.invoiceFee, 0.0) AS invableFee,rd.payQty,rd.payFee,rd.toOrder, 
	rd.isTemporary,rd.isEmergency,rd.isPromotion,rd.buyerId,rd.handlerId,rd.deptId,rd.orderId,rd.orderNo, 
	rd.orderBillNo,rd.sdOrderId,rd.sdOrderNo,rd.sdBillNo,rd.sdCustomerNo,rd.sdCustomerName,rd.contractId, 
	rd.contractNo,sku.itemWeight,sku.itemVolume,sku.pkgWeight,sku.pkgVolume,sku.purPrice,sku.lastPurPrice, 
	sku.maxPrice,sku.inventoryMode,sku.isUnsalable,sku.isStop,sku.isVirtual,rd.retDtlEx01,rd.retDtlEx02, 
	rd.retDtlEx03,rd.retDtlEx04,rd.retDtlEx05,rd.remarks,rd.isSelected

FROM dbo.PMS_Return AS r 
	INNER JOIN dbo.PMS_ReturnDetail AS rd ON r.returnNo = rd.returnNo 
	INNER JOIN dbo.BAS_Goods_V AS sku ON rd.itemId = sku.itemId 
	LEFT JOIN dbo.BAS_Warehouse AS bw ON rd.warehouseId = bw.warehouseId 
	LEFT JOIN dbo.PMS_StockDetail AS sd ON rd.stockId = sd.stockId 
	LEFT JOIN dbo.IMS_Stock AS s ON rd.companyId = s.companyId AND rd.warehouseId = s.warehouseId AND ISNULL(rd.lotNo,'')=ISNULL(s.lotNo,'') AND ISNULL(rd.locationNo,'')=ISNULL(s.locationNo,'') AND rd.itemId = s.itemId


go

