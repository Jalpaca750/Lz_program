
/*==============================================================*/
/* View: BAS_Worktable_V                                        */
/*==============================================================*/
create view [dbo].[BAS_Worktable_V] as
SELECT a.worktableId,a.companyId,a.worktableNo,a.worktableDesc,a.warehouseId,w.warehouseNo,
	w.warehouseName,a.regionId,r.regionNo,r.regionDesc,a.locationNo,a.ipAddress1,a.ipAddress2,
	a.ipAddress3,a.isDisable,CASE a.isDisable WHEN 0 THEN '否' ELSE '是' END AS disableFlag,
	a.isLocked,a.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
	a.createTime,a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName,
	a.isSelected,a.PortName,a.BaudRate,a.Parity,a.StopBits,a.DataBits,a.ReadBufferSize,a.ReadTimeout,a.ReceivedBytesThreshold,a.Sleep,a.AutoWeigh
FROM dbo.BAS_Worktable a 
	LEFT JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	LEFT JOIN dbo.BAS_Region r ON a.regionId=r.regionId
	LEFT JOIN SAM_User u1 ON a.lockerId=u1.userId
	LEFT JOIN SAM_User u2 ON a.creatorId=u2.userId
	LEFT JOIN SAM_User u3 ON a.editorId=u3.userId
go

