/*==============================================================*/
/* View: TMS_WayBill_V                                          */
/*==============================================================*/
CREATE view [dbo].[TMS_WayBill_V] as
SELECT a.waybillId,a.companyId,a.siteId,b.siteName,CONVERT(VARCHAR(10),a.waybillDate,23) AS waybillDate,
	a.pickerId,u1.userNick AS pickerName,a.waybillNo,a.waybillType,a.lineId,a1.lineName,a.boxCount,a.boxWeight,
	a.settleCount,a.settleWeight,a.postFee,a.settlementId,s.settlementName,a.isInsure,a.premium,a.insureFee,
	a.agentFee,a.poundage,a.fromCustomerId,tc.customerNo,tc.customerName,a.fromContacts,a.fromPhone,a.fromState,
	f1.areaName AS fromStateName,a.fromCity,f2.areaName AS fromCityName,a.fromDistrict,f3.areaName AS fromDistrictName,
	a.fromTown,f4.areaName AS fromTownName,a.fromAddress,ISNULL(f1.areaName,'')+ISNULL(f2.areaName,'')+ISNULL(f3.areaName,'')
	+ISNULL(f4.areaName,'') +ISNULL(a.fromAddress,'') AS fromFullAddress,a.toCustomerId,p.partnerNo AS toCustomerNo,
	p.partnerName AS toCustomerName,a.toContacts,a.toPhone,a.toState,t1.areaName AS toStateName,a.toCity,t2.areaName AS toCityName,
	a.toDistrict,t3.areaName AS toDistrictName,a.toTown,t4.areaName AS toTownName,a.toAddress,ISNULL(t1.areaName,'')
	+ISNULL(t2.areaName,'')+ISNULL(t3.areaName,'')+ISNULL(t4.areaName,'') +ISNULL(a.toAddress,'') AS toFullAddress,
	a.exField01,a.exField02,a.exField03,a.exField04,a.exField05,a.exField06,a.exField07,a.exField08,a.exField09,
	a.exField10,a.shipId,a.wmsStockNo,a.billState,CASE a.billState WHEN 10 THEN '已揽件'
																   WHEN 20 THEN '运输中'
																   WHEN 30 THEN '派送中'
																   WHEN 80 THEN '未送达'
																   WHEN 90 THEN '已妥投'
																   WHEN 99 THEN '已回单' END as billStateDesc,
	a.billType,CASE a.billType WHEN 10 THEN '销售出库单' 
								WHEN 20 THEN '调拨出库单' 
								WHEN 30 THEN '经营领用单' 
								WHEN 31 THEN '管理领用单' 
								WHEN 32 THEN '其他出库单'
								WHEN 40 THEN '赠品出库单' 
								WHEN 50 THEN '报损报废单'
								WHEN 60 THEN '销售退货单'
								WHEN 70 THEN '销售发票单'
								WHEN 80 THEN '销售出库单'
								WHEN 90 THEN '项目单' ELSE '运单' END billTypeName,
	a.itemName,a.memo,a.isLocked,a.lockerId,u2.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
	a.createTime,a.creatorId,u3.userNick AS creatorName,a.editTime,a.editorId,u4.userNick AS editorName,a.isSelected
FROM dbo.TMS_WayBill a
	INNER JOIN dbo.TMS_Site b ON a.siteId=b.siteId
	LEFT JOIN dbo.SAM_User u1 ON a.pickerId=u1.userId
	LEFT JOIN dbo.BAS_AddressLine a1 ON a.lineId=a1.lineId
	LEFT JOIN dbo.BAS_Settlement s ON a.settlementId=s.settlementId
	LEFT JOIN dbo.TMS_Customer tc ON a.fromCustomerId=tc.customerId
	LEFT JOIN dbo.BAS_Area f1 ON a.fromState=f1.areaId
	LEFT JOIN dbo.BAS_Area f2 ON a.fromCity=f2.areaId
	LEFT JOIN dbo.BAS_Area f3 ON a.fromDistrict=f3.areaId
	LEFT JOIN dbo.BAS_Area f4 ON a.fromTown=f4.areaId 
	LEFT JOIN dbo.BAS_Partner p ON a.toCustomerId=p.partnerId
	LEFT JOIN dbo.BAS_Area t1 ON a.toState=t1.areaId
	LEFT JOIN dbo.BAS_Area t2 ON a.toCity=t2.areaId
	LEFT JOIN dbo.BAS_Area t3 ON a.toDistrict=f3.areaId
	LEFT JOIN dbo.BAS_Area t4 ON a.toTown=t4.areaId 
	LEFT JOIN dbo.SAM_User u2 ON a.lockerId=u2.userId
	LEFT JOIN dbo.SAM_User u3 ON a.creatorId=u3.userId
	LEFT JOIN dbo.SAM_User u4 ON a.editorId=u4.userId
go

