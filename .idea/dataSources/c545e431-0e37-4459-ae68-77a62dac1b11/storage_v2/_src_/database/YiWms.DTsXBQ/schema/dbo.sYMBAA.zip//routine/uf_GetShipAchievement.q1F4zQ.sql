-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-12-21>
-- Description:	<Description:装车日报表>       
-- =============================================
CREATE FUNCTION [dbo].[uf_GetShipAchievement]
(
    @companyId VARCHAR(32),
    @startDate DATE,
    @endDate DATE    
)
RETURNS TABLE
RETURN
(
    SELECT a.shipNo,a.billNo,a.shipDate,a.shipTime,CASE a.shipState WHEN 10 THEN '待发车' 
    																WHEN 20 THEN '待装车' 
    																WHEN 30 THEN '已装车'
    																WHEN 40 THEN '已发车' END shipStateName,
    	d.carNumber,b.userNick AS driverName,c.userNick AS deliveryName,d.maxVolume,d.maxWeight,
    	t.totalVolumn,t.totalWeight,t.totalQty,t.achieveQty,t.fileQty,t.billCount,t.custCount,
    	CASE ISNULL(d.maxVolume,0.0) WHEN 0.0 THEN 0.0 ELSE t.totalVolumn/d.maxVolume END AS useRate,
    	a.lineId,l.lineCode,l.lineName
    FROM dbo.WMS_Ship a
    	INNER JOIN (SELECT shipNo,SUM(ISNULL(pkgVolumn,0.0)+ISNULL(lclVolumn,0.0)) AS totalVolumn,
    					SUM(grossWeight) AS totalWeight,COUNT(1) AS billCount,COUNT(DISTINCT customerId) AS custCount,
    					SUM(CASE isInvalid WHEN 0 THEN ISNULL(lclQty,0.0)+ISNULL(pkgQty,0.0) ELSE 0 END) AS totalQty,
    					SUM(CASE isInvalid WHEN 0 THEN ISNULL(fileQty,0.0) ELSE 0 END) AS fileQty,
    					SUM(CASE isInvalid WHEN 0 THEN ISNULL(fclQty,0.0) ELSE 0 END) AS achieveQty
    				FROM dbo.WMS_ShipDetail
    				GROUP BY shipNo) t ON a.shipNo=t.shipNo
    	INNER JOIN dbo.SAM_User b ON a.driverId=b.userId 
    	INNER JOIN dbo.SAM_User c ON a.deliveryId=c.userId
    	INNER JOIN dbo.BAS_Car d ON a.carId=d.carId
    	LEFT  JOIN dbo.BAS_AddressLine l ON a.lineId=l.lineId
    WHERE (a.companyId=@companyId)
    	AND (a.shipDate BETWEEN @startDate AND @endDate)
    	AND (d.thirdFlag=0)
)
go

