
/*==============================================================*/
/* View: WMS_F10_Ship_V                                         */
/*==============================================================*/
create view WMS_F10_Ship_V as
SELECT a.shipNo,a.billNo AS CarNumberNo,CONVERT(VARCHAR(10),a.createTime,23) AS CreateDate,'20' AS BillSts,
    CASE printNum WHEN 0 THEN 0 ELSE 1 END AS PFlag,e.employeeID AS CarRenID,c.CarNo,
    CONVERT(VARCHAR(10),a.shipDate,23) AS CarDate,d.employeeID AS Delivery,
    l.lineCode AS LineID,e1.employeeID AS CreatorID,
    CONVERT(VARCHAR(10),ISNULL(a.auditTime,GETDATE()),23) AS AuditDate,
    e2.employeeID AS AuditID
FROM WMS_Ship a
    INNER JOIN WMS_F10_Car_V c ON a.carId=c.carId
    LEFT JOIN F10BMS.dbo.WMS_F10_User_V e ON a.driverId=e.userId
    LEFT JOIN F10BMS.dbo.WMS_F10_User_V d ON a.deliveryId=d.userId
    LEFT JOIN BAS_AddressLine l ON a.lineId=l.lineId 
    LEFT JOIN F10BMS.dbo.WMS_F10_User_V e1 ON a.creatorId=e1.userId 
    LEFT JOIN F10BMS.dbo.WMS_F10_User_V e2 ON a.auditorId=e2.userId
WHERE (a.shipState=30)
    AND (ISNULL(a.syncFlag,0)=0)
go

