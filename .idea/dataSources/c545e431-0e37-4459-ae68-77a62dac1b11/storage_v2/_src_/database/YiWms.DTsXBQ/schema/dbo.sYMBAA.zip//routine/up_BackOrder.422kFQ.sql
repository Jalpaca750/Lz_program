
CREATE PROCEDURE [dbo].[up_BackOrder] 
(
	@stockNo VARCHAR(32),					--出库单号
    @companyId VARCHAR(32),					--公司Id 
	@operatorId VARCHAR(32)					--操作员Id	
)
AS
BEGIN
    --订单编号    
    DECLARE @orderNo VARCHAR(32),@orderBillNo VARCHAR(32),@skuCount INT,@aFlag INT;
    --存放出库单删除前数据
    DECLARE @order TABLE(orderId VARCHAR(32),orderNo VARCHAR(32),orderBillNo VARCHAR(32),warehouseId VARCHAR(32),itemId VARCHAR(32),shipQty DECIMAL(20,6));  
    BEGIN TRY
        BEGIN TRANSACTION
        --单据类型
        SELECT @aFlag=aFlag FROM dbo.SAD_Stock WHERE stockNo=@stockNo;
        --对应订单
        INSERT INTO @order(orderId,orderNo,orderBillNo,warehouseId,itemId,shipQty)
        SELECT b.orderId,b.orderNo,b.orderBillNo,b.warehouseId,b.itemId,b.stockQty
        FROM dbo.SAD_Stock a 
            INNER JOIN dbo.SAD_StockDetail b ON a.stockNo=b.stockNo
        WHERE a.stockNo=@stockNo AND taskState=30;
        --返还订单，并修改订单状态
        IF EXISTS(SELECT * FROM @order) AND (@aFlag=0 OR @aFlag=1)
        BEGIN
            --删除出库单表数据
            DELETE FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo;
            DELETE FROM dbo.SAD_Stock WHERE stockNo=@stockNo; 
            --返还库存占用
            UPDATE a SET a.allocQty=ISNULL(a.allocQty,0.0)-ISNULL(b.allocQty,0.0)
            FROM dbo.IMS_Ledger a 
                INNER JOIN(
                    SELECT warehouseId,itemId,SUM(shipQty) AS allocQty
                    FROM @order 
                    GROUP BY warehouseId,itemId
                    ) b ON a.warehouseId=b.warehouseId AND a.itemId=b.itemId;     
            --返回订单明细
            UPDATE a SET a.shipQty=ISNULL(a.shipQty,0.0)-ISNULL(b.shipQty,0.0)
            FROM dbo.SAD_OrderDetail a
                INNER JOIN @order b ON a.orderId=b.orderId 
            IF (@@ROWCOUNT>0)
            BEGIN
                DECLARE myOrder CURSOR
                FOR SELECT orderNo,orderBillNo,COUNT(*)
                    FROM @order
                    GROUP BY orderNo,orderBillNo
                OPEN myOrder
                FETCH NEXT FROM myOrder INTO @orderNo,@orderBillNo,@skuCount
                WHILE @@FETCH_STATUS=0
                BEGIN
                    IF EXISTS(SELECT 1 FROM dbo.SAD_OrderDetail WHERE ISNULL(shipQty,0.0)>0.0 and orderNo=@orderNo)
                    BEGIN
                        UPDATE dbo.SAD_Order SET sdState=25,taskState=15 WHERE orderNo=@orderNo;
                        UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='部分下达' WHERE OrderNo=@orderBillNo;
                    END
                    ELSE
                    BEGIN
                        UPDATE dbo.SAD_Order SET sdState=10,taskState=10 WHERE orderNo=@orderNo;
                        UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='待下达' WHERE OrderNo=@orderBillNo;
                    END
                    FETCH NEXT FROM myOrder INTO @orderNo,@orderBillNo,@skuCount
                END
                CLOSE myOrder
		        DEALLOCATE myOrder
            END 
        END
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
    END CATCH
END

go

