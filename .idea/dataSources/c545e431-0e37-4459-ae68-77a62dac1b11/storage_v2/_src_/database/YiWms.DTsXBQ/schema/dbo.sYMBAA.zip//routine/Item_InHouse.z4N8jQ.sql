-- =============================================
-- Author:		<Author: Wang_Jun>
-- Create date: <Create Date:2017-07-10>
-- Description:	<Description:是否存在货位 V1>
-- 包含：
-- =============================================
CREATE FUNCTION [dbo].[Item_InHouse]
(
    @itemNo VARCHAR(32),				        --商品Id
    @warehouseNo VARCHAR(32)					--仓库NO
)
RETURNS TABLE
RETURN(
		SELECT CASE WHEN EXISTS
			(SELECT 1 FROM IMS_Stock a			 
				INNER JOIN BAS_Item b ON a.itemId=b.itemId 
				INNER JOIN BAS_Warehouse c ON a.warehouseId=c.warehouseId 
				WHERE  c.warehouseNo=@warehouseNo AND b.itemNo=@itemNo) THEN 1 ELSE 0 END AS inHouse
)


go

