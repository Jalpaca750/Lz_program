
-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-04-18>
-- Description:	<Description:取得出库单箱号>
-- =============================================

CREATE FUNCTION [dbo].[uf_GetStockBoxNums] 
(
	@stockId VARCHAR(32)
)
RETURNS VARCHAR(1000)
AS
BEGIN
	DECLARE @stockBoxes VARCHAR(1000)
	SET @stockBoxes=''
	SELECT @stockBoxes=CAST(p2.boxBillNum AS VARCHAR(10))+';'
	FROM dbo.WMS_PickingDetail p1 INNER JOIN
		  dbo.WMS_PickingOrder p2 ON p1.stockNo=p2.stockNo AND p1.boxOrder=p2.boxOrder AND p1.isPackage=p2.isPackage
	WHERE p1.stockId=@stockId AND p1.isPackage=0
	IF ISNULL(@stockBoxes,'')!=''
		SET @stockBoxes=SUBSTRING(@stockBoxes,1,LEN(@stockBoxes)-1)
	RETURN @stockBoxes
END
go

