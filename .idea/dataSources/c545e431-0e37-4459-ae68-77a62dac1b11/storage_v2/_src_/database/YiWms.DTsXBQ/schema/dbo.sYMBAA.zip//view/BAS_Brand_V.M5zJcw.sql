
/*==============================================================*/
/* View: BAS_Brand_V                                            */
/*==============================================================*/
--creator:Frank
--create time:2016-05-26
--modify: frank 2016-09-20 整理
--品牌视图
create view BAS_Brand_V as
SELECT b.brandId,b.companyId,b.brandNo,b.brandCName,b.brandEName,b.pictureUrl,b.usage, 
	CASE b.usage WHEN 1 THEN '内部平台' WHEN 2 THEN '电商平台' ELSE '所有平台' END usageName,
	b.isRecommend, CASE b.isRecommend WHEN 1 THEN '是' ELSE '否' END AS isRecommendName,
	b.viewOrder, b.isDisable, CASE b.isDisable WHEN 1 THEN '是' ELSE '否' END AS isDisableName, 
	b.isLocked, CONVERT(VARCHAR(20),b.lockedTime,120) AS lockedTime, b.lockerId, 
	u3.userNick AS lockerName, b.createTime, b.creatorId, u1.userNick AS creatorName, b.editTime, 
	b.editorId, u2.userNick AS editorName, b.isSelected
FROM dbo.BAS_Brand AS b 
	LEFT JOIN dbo.SAM_User AS u1 ON b.creatorId = u1.userId 
	LEFT JOIN dbo.SAM_User AS u2 ON b.editorId = u2.userId 
	LEFT JOIN dbo.SAM_User AS u3 ON b.lockerId=u3.userId
go

