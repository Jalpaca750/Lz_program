/*==============================================================*/
/* View: BAS_Car_V                                              */
/*==============================================================*/
--creator：        Frank
--create time：  2016-11-01
--车辆资料视图
CREATE view [dbo].[BAS_Car_V] as
SELECT a.carId,a.companyId,a.carNumber,a.carType,a.maxWeight,a.maxVolume,a.boxLong,a.boxWidth,a.boxHeight,
	a.carState,CASE a.carState WHEN 0 THEN '失效' WHEN 1 THEN '有效' END AS carStateName,a.thirdFlag,
	CASE a.thirdFlag WHEN 0 THEN '自有车辆' WHEN 1 THEN '第三方配送' WHEN 2 THEN '虚拟车辆' END AS thirdFlagDesc,
	a.isLocked,a.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(10),a.lockedTime,23) AS lockedTime,a.createTime,
	a.creatorId,u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName,a.isSelected
FROM dbo.BAS_Car a 
	LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId
go

