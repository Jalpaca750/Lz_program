/*==============================================================*/
/* View: XSCK_MX                                                */
/*      @editor:张东彦 @at:2017-07-07     @content:添加仓库编码返回 */
/*==============================================================*/
create view [dbo].[XSCK_MX] as
SELECT a.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,dtl.orderBillNo AS SHANGJ_DANJ_NO,dtl.viewOrder AS linenum,
      bi.itemNo AS itemcode,CASE WHEN ISNULL(pk.actQty,0.0)-ISNULL(dtl.stockQty,0.0)>0 THEN dtl.stockQty ELSE pk.actQty END AS quantity,dtl.price,dtl.befPrice,
      CAST(pk.actQty*dtl.price AS DECIMAL(20,2)) AS linetotal,od.viewOrder AS HANGHAO,
      dtl.remarks lineNotes , W.warehouseNo AS WHNO
FROM dbo.SAD_StockDetail dtl INNER JOIN
      (SELECT m.stockNo,m.billNo,n.ownerNo,m.mergeNo
       FROM dbo.SAD_Stock m LEFT JOIN 
             dbo.BAS_Owner_V n ON m.ownerId=n.ownerId
       WHERE (m.orderType=10 OR m.orderType=30 OR m.orderType=31 OR m.orderType=40 OR m.orderType=50) 
             AND (m.taskState>=60) AND (m.ioState > 0)
             AND (m.thirdSyncFlag=0 OR m.thirdSyncFlag=2)
       ) a ON dtl.stockNo=a.stockNo INNER JOIN
      dbo.BAS_Item bi ON dtl.itemId=bi.itemId INNER JOIN
      (SELECT stockId,SUM(CASE isPackage WHEN 0 THEN pickQty WHEN 1 THEN pickQty * realQty END) AS actQty
	   FROM WMS_PickingDetail p
	   INNER JOIN WMS_Picking pd ON p.pickingNo=pd.pickingNo
       WHERE (pd.taskType=0 OR pd.taskType=1)
	   GROUP BY stockId) pk ON dtl.stockId=pk.stockId LEFT JOIN
      dbo.SAD_OrderDetail od ON dtl.orderId=od.orderId
      INNER JOIN BAS_Warehouse W on dtl.warehouseId=W.warehouseId
WHERE ISNULL(pk.actQty,0.0)>0.0 AND dtl.isVirtual=0
UNION ALL
SELECT a.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,dtl.orderBillNo AS SHANGJ_DANJ_NO,dtl.viewOrder AS linenum,
      bi.itemNo AS itemcode,dtl.stockQty AS quantity,dtl.price,dtl.befPrice,
      dtl.totalFee AS linetotal,od.viewOrder AS HANGHAO,dtl.remarks lineNotes, W.warehouseNo AS WHNO
FROM dbo.SAD_StockDetail dtl INNER JOIN
      (SELECT m.stockNo,m.billNo,n.ownerNo,m.mergeNo
       FROM dbo.SAD_Stock m LEFT JOIN 
             dbo.BAS_Owner_V n ON m.ownerId=n.ownerId
       WHERE (m.orderType=10 OR m.orderType=30 OR m.orderType=31 OR m.orderType=40 OR m.orderType=50) 
             AND (m.taskState>=60) 
             AND (m.thirdSyncFlag=0 OR m.thirdSyncFlag=2)
       ) a ON dtl.stockNo=a.stockNo INNER JOIN
      dbo.BAS_Item bi ON dtl.itemId=bi.itemId LEFT JOIN
      dbo.SAD_OrderDetail od ON dtl.orderId=od.orderId
      INNER JOIN BAS_Warehouse W on dtl.warehouseId=W.warehouseId
WHERE dtl.isVirtual=1



go

