





/*==============================================================*/
/* View: PMS_OrderDetail_V                                      */
/*==============================================================*/
--creator：     Wang_Jun
--create time:  2016-11-30整理
--modify:       Frank.He 2017-01-16日修改
--				Frank.He 2017-10-23 增加自定义字段1~自定义字段5，去掉isMatch
CREATE view [dbo].[PMS_OrderDetail_V] as
SELECT dtl.orderId,dtl.orderNo,dtl.companyId,o.createTime,o.billNo,o.orderSource,dtl.planId,dtl.planNo,
	dtl.planBillNo,dtl.viewOrder,dtl.warehouseId,bw.warehouseNo,bw.warehouseName,dtl.eId,dtl.itemId,
	sku.itemNo,sku.itemName,sku.itemSpec,sku.itemSpell,sku.sellingPoint,sku.barcode,sku.midBarcode,
	sku.bigBarcode,sku.pkgBarcode,sku.brandId,sku.brandCName,sku.categoryId,sku.categoryNo,sku.categoryCName,
	sku.colorName,sku.sizeName,sku.unitName,dtl.orderQty,dtl.pkgQty,dtl.bulkQty,sku.pkgUnit,sku.pkgRatio,
	sku.excessRate,sku.allowExcess,sku.inventoryMode,dtl.befPrice,dtl.discount,dtl.discountFee,dtl.price,
	dtl.taxFlag,dtl.taxRate,dtl.fee,dtl.taxFee,dtl.totalFee,dtl.rebate,dtl.receiveQty,
	ISNULL(dtl.orderQty,0.0) - ISNULL(dtl.receiveQty,0.0) AS restQty,dtl.invoiceQty,dtl.invoiceFee,dtl.payQty,
	dtl.payFee,dtl.toOrder,dtl.updPrice,dtl.isTemporary,dtl.isEmergency,dtl.isPromotion,dtl.buyerId,dtl.handlerId,
	dtl.deptId,dtl.sdOrderId,dtl.sdOrderNo,dtl.sdBillNo,dtl.sdCustomerNo,dtl.sdCustomerName,dtl.contractId,
	dtl.contractNo,sku.webPrice,sku.marketPrice,sku.vipPrice,sku.retailPrice,sku.tradePrice,sku.salesPrice,
	sku.minPrice,sku.purPrice,sku.lastPurPrice,sku.maxPrice,sku.isUnsalable,sku.isStop,sku.isVirtual,sku.isSafety,
	sku.safetyMonth,sku.isIrregular,sku.pickingMode,sku.itemVolume,sku.itemState,sku.pkgVolume,sku.commodityId,
	o.ownerId,dtl.lotNo,b.batchNo,b.productDate,b.expiryDate,b.inputDate,b.attribute01,b.attribute02,
	b.attribute03,b.attribute04,b.attribute05,dtl.poId,dtl.ordDtlEx01,dtl.ordDtlEx02,dtl.ordDtlEx03,
	dtl.ordDtlEx04,dtl.ordDtlEx05,dtl.remarks,dtl.isSelected
FROM dbo.PMS_OrderDetail AS dtl 
	INNER JOIN dbo.PMS_Order o ON dtl.orderNo=o.orderNo 
	LEFT JOIN dbo.BAS_Goods_V AS sku ON dtl.itemId=sku.itemId 
	LEFT JOIN dbo.IMS_Batch b ON dtl.companyId=b.companyId AND dtl.lotNo=b.lotNo
	LEFT JOIN BAS_Warehouse AS bw ON dtl.warehouseId=bw.warehouseId
go

