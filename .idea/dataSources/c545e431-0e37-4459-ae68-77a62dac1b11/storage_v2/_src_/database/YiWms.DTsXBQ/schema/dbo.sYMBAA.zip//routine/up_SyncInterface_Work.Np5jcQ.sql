







-- =============================================
-- Author:		<Author: ZDY>
-- Create date: <Create Date:2017-04-05>
-- Description:	<Description:数据库同步数据作业>
-- 依赖：  --默认操作员编码 06AC5F6A59C34A298A168AB01DA6C447
-- =============================================
CREATE Proc  [dbo].[up_SyncInterface_Work]
as
declare @operatorId varchar(32)='06AC5F6A59C34A298A168AB01DA6C447'
declare @storeId  varchar(32)  --主键ID
declare @companyId  varchar(32) --公司
declare @ownerId    varchar(32) --业主
declare @storeSource int  --接口类型
declare @appUrl    varchar(100)--接口名称
declare @interfaceType int     --接口类型ID   
declare @startTime dateTime,@endTime dateTime --开始结束时间
declare @isError int=0
declare @bTime varchar(20)=CONVERT(varchar(100), GETDATE(), 20)
declare FMyCursor   cursor  for  ---同步接口游标
select storeId,companyId,ownerId,storeSource,appUrl,interfaceType 
from SAM_Store  
where storeSource=0  and isLocked=0  --这里还是不要了万一程序同步不了就坏了
order by  interfaceType   for read only
begin 
	OPEN  FMyCursor ---打开游标
	Fetch  NEXT   FROM FMyCursor  
	into @storeId,@companyId,@ownerId,@storeSource,@appUrl,@interfaceType     
WHILE @@fetch_status=0 
BEGIN  
	   --锁定
	   UPDATE    SAM_Store SET isLocked=1 WHERE storeId=@storeId
	   set  @startTime=GETDATE()
	   set  @endTime=GETDATE()  --返写状态
BEGIN  TRY
       print  '类型'+cast(@interfaceType as varchar(32))
	   IF  @interfaceType=10   --如果是同步商品
	   begin
	      ---同步商品 锁定 UPDATE 
	      print '同步商品资料'
	      exec  up_SyncBasicItem  @companyId,@ownerId,@operatorId,@startTime,@endTime
	      print  '同步商品资料成功'
	   end
	   ELSE IF @interfaceType=11  --同步客户
	   BEGIN 
	    print '同步客户资料资料'
	       EXEC  up_SyncBasicCustomer @companyId,@ownerId,@operatorId,0,@startTime,@endTime
	   END
	   else IF @interfaceType=12 --同步供应商
	   BEGIN
	        print '同步供应商资料资料'
	   EXEC  up_SyncBasicSupplier @companyId,@ownerId,@operatorId,0,@startTime,@endTime
	   END
	   ELSE IF @interfaceType=20  --订单，调拨出库
	   BEGIN
	        print  '同步销售订单'
	        EXEC up_SyncErpSalesOrder  @companyId,@ownerId,@operatorId,@startTime,@endTime
	   END
	   ELSE IF @interfaceType=30  --采购订单、采购出库
	   BEGIN
	       print  '同步采购定订单'
	        EXEC up_SyncPurchaseOrder @companyId,@ownerId,@operatorId,@startTime,@endTime
	   END  
	    
	   insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
        values(REPLACE(NEWID(),'-',''),@companyId,@appUrl,@appUrl,'同步作业完成'+@appUrl+'['+@bTime+']',GETDATE()) 
END TRY
BEGIN CATCH
      UPDATE    SAM_Store SET isLocked=0 WHERE storeId=@storeId
      insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
      select  REPLACE(NEWID(),'-',''),@companyId,@appUrl,@appUrl,'作业同步异常'+@@error,GETDATE()   
END CATCH
	   ---解除锁定
	   UPDATE    SAM_Store SET isLocked=0 WHERE storeId=@storeId
	   Fetch  NEXT   FROM FMyCursor  
	   into @storeId,@companyId,@ownerId,@storeSource,@appUrl,@interfaceType  
END
---关闭游标
CLOSE FMyCursor
Deallocate FMyCursor

END   







go

