/*==============================================================*/
/* View: WMS_F10_IMS_AdjustDtl_V                                */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_IMS_AdjustDtl_V] as
SELECT a.adjustId AS wmsStockId,a.adjustNo AS wmsStock,b.billNo AS otherNo,w.warehouseNo AS warehouse,
	bi.f10Id AS itemId,a.locationNo AS location,
	CASE ISNULL(bi.pkgRatio,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ABS(a.ioQty)/bi.pkgRatio,4) END AS pkgQty,
	a.ioQty AS SQty,0.0 AS price,0.0 AS Amt,0.0 AS CPrice,a.remarks,p.pointNo,bi.pkgRatio,bi.SPrice,p.pointId
FROM dbo.IMS_AdjustDetail a
	INNER JOIN dbo.IMS_Adjust b On a.adjustNo=b.adjustNo 
	LEFT  JOIN dbo.IMS_CheckPoint p ON p.pointId=b.pointId
	LEFT  JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	INNER JOIN F10BMS.dbo.WMS_F10_Item_V bi ON a.itemId=bi.itemId
WHERE (b.ioState=20)
	AND (b.thirdSyncFlag=0 OR b.thirdSyncFlag=2)
	AND ISNULL(a.ioQty,0.0)!=0.0
go

