

CREATE FUNCTION [dbo].[uf_GetShipBill] 
(
	@stockNo VARCHAR(32)
)
RETURNS TABLE
RETURN(
	SELECT a.stockNo AS billNo,a.billNo AS stockBillNo,a.customerId,a.receiverState,a.receiverCity,
		a.receiverDistrict,a.receiverAddress,a.receiverName,a.receiverTel,a.receiverMobile,
		ISNULL(d.pkgQty,0) AS pkgQty,ISNULL(d.fclQty,0.0)+ISNULL(p.wgtQty,0.0) AS fclQty,
		ISNULL(d.pkgVolumn,0.0) AS pkgVolumn,ISNULL(p.lclQty,0.0) AS lclQty,ISNULL(p.lclVolumn,0.0) AS lclVolumn,
		0 AS fileQty,a.shipDate,0.0 AS netWeight,ISNULL(d.grossWeight,0.0)+ISNULL(p.lclWeight,0.0) AS grossWeight,
		a.mergeNo,a.orderType AS billType,ISNULL(a.undelivered,0) AS isInvalid,a.memo AS remarks,a.groupId AS ServiceName
	FROM dbo.SAD_Stock a 
		LEFT JOIN (SELECT m1.stockNo,
						SUM(m1.pickQty) AS pkgQty,												
						SUM(CASE WHEN ISNULL(m2.pkgWeight,0.0)-25.0>0.0 THEN m1.pickQty*CEILING(m2.pkgWeight/25.0) ELSE m1.pickQty END) AS fclQty,
						SUM(m1.pickQty*m2.pkgVolume) AS pkgVolumn,
						SUM(m1.pickQty*m2.pkgWeight) AS grossWeight					
					FROM dbo.WMS_PickingDetail m1
						INNER JOIN dbo.BAS_Item m2 ON m1.itemId=m2.itemId
					WHERE m1.isPackage=1
					GROUP BY m1.stockNo) d ON a.stockNo=d.stockNo 
		LEFT JOIN (SELECT x1.stockNo,COUNT(1) AS lclQty,SUM(x2.lclVolumn) AS lclVolumn,SUM(x2.lclWeight) AS lclWeight,
						SUM(CASE WHEN ISNULL(x2.lclWeight,0.0)-25.0>0.0 THEN CEILING(x2.lclWeight/25.0) ELSE 1 END) AS wgtQty
					FROM dbo.WMS_Packing x1 
						INNER JOIN dbo.WMS_PackingVolumn_V x2 ON x1.packNo=x2.packNo
					GROUP BY x1.stockNo) p ON a.stockNo=p.stockNo
	WHERE (a.stockNo=@stockNo)
		AND (a.taskState=70 OR a.taskState=96)
		AND (a.aFlag IN(0,1,2))
	UNION ALL
	SELECT a.stockNo AS billNo,a.billNo AS stockBillNo,a.customerId,a.receiverState,a.receiverCity,
		a.receiverDistrict,a.receiverAddress,a.receiverName,a.receiverTel,a.receiverMobile,
		0.0 AS pkgQty,0 AS fclQty,0.0 AS pkgVolumn,0.0 AS lclQty,0.0 AS lclVolumn,
		1 AS fileQty,a.shipDate,0.0 AS netWeight,0.0 AS grossWeight,
		a.mergeNo,a.orderType AS billType,ISNULL(a.undelivered,0) AS isInvalid,a.memo AS remarks,a.groupId AS ServiceName
	FROM dbo.SAD_Stock a 
	WHERE (a.stockNo=@stockNo)
		AND (a.taskState=70 OR a.taskState=96)
		AND (a.aFlag=3)
	UNION ALL
	SELECT a.ReturnNo AS billNo,a.ReturnNo AS stockBillNo,c.customerId,'' AS receiverState,'' AS receiverCity,
		'' AS receiverDistrict,a.SendAddr AS receiverAddress,a.LinkMan AS receiverName,a.Phone AS receiverTel,
		'' AS receiverMobile,b.pkgQty,CASE WHEN b.bulkQty>0.0 THEN 1+b.pkgQty ELSE b.pkgQty END AS fclQty,
		b.pkgVolumn,CASE WHEN b.bulkQty>0.0 THEN 1 ELSE 0 END AS lclQty,b.lclVolumn, 0 AS fileQty,
		a.sendDate,0.0 AS netWeight,b.totalWeight AS grossWeight,a.ReturnNo AS mergeNo,60 AS billType,0 AS isInvalid,
		a.remarks,c.ServiceName
	FROM WZX2015.dbo.SMS_Return a
		INNER JOIN (SELECT t1.ReturnNo,
						SUM(CASE ISNULL(t2.pkgRatio,0) WHEN 0 THEN 0 ELSE FLOOR((ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))/t2.pkgRatio) END) AS pkgQty,
						SUM(CASE ISNULL(t2.pkgRatio,0) WHEN 0 THEN 0 ELSE FLOOR((ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))/t2.pkgRatio)*ISNULL(t2.pkgVolume,0.0) END) AS pkgVolumn,
						SUM(CASE ISNULL(t2.pkgRatio,0) WHEN 0 THEN ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0) ELSE (ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))%t2.pkgRatio END) AS bulkQty,
						SUM(CASE ISNULL(t2.pkgRatio,0) WHEN 0 THEN (ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))*ISNULL(t2.itemVolume,0.0) ELSE ISNULL(t2.itemVolume,0.0)*((ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))%t2.pkgRatio) END) AS lclVolumn,
						SUM((ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))*ISNULL(t2.itemWeight,0.0)) AS totalWeight
					FROM WZX2015.dbo.SMS_ReturnDtl t1
						INNER JOIN WZX2015.dbo.WMS_F10_Item_V t2 ON t1.ItemID=t2.f10Id 
					GROUP BY t1.ReturnNo) b ON a.ReturnNo=b.ReturnNo
		INNER JOIN WZX2015.dbo.WMS_F10_Customer_V c ON a.CustID=c.CustID
	WHERE (a.ReturnNo=@stockNo)
		AND (a.DeptNo='1055')
		AND (ISNULL(a.CarNumberSts,'')='')
	UNION ALL
	--销售发票
	SELECT CAST(a.InvoiceID AS VARCHAR(32)) AS billNo,a.InvoiceNo AS stockBillNo,c.customerId,'' AS receiverState,
		'' AS receiverCity,'' AS receiverDistrict,a.SendAddr AS receiverAddress,ISNULL(addr.LinkMan,c.LinkMan) AS receiverName,
		ISNULL(addr.Phone,c.Phone) AS receiverTel,'' AS receiverMobile,0 AS pkgQty,0 AS fclQty,0.0 AS pkgVolumn,
		0 AS lclQty,0.0 AS lclVolumn, 1 AS fileQty,a.CreateDate,0.0 AS netWeight,0.0 AS grossWeight,
		a.InvoiceNo AS mergeNo,70 AS billType,0 AS isInvalid,a.remarks,d.EmployeeName AS creatorName
	FROM WZX2015.dbo.SMS_Invoice a
		LEFT JOIN WZX2015.dbo.BDM_SendAddress addr ON a.CustID=addr.CustID AND a.SendAddr=addr.SendAddr
		INNER JOIN WZX2015.dbo.WMS_F10_Customer_V c ON a.CustID=c.CustID
		LEFT  JOIN WZX2015.dbo.BDM_Employee d ON a.CreatorID=d.EmployeeID
	WHERE CAST(a.InvoiceID AS VARCHAR(32))=@stockNo
		AND (a.DeptNo='1055')
		AND (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30')
		AND (ISNULL(a.CarNumberSts,'')='') 
	UNION ALL
	--90 项目单
	SELECT CAST(a.BillID AS VARCHAR(32)) AS billNo,a.BillNo AS stockBillNo,c.customerId,'' AS receiverState,
		'' AS receiverCity,'' AS receiverDistrict,a.SendAddr AS receiverAddress,ISNULL(addr.LinkMan,c.LinkMan) AS receiverName,
		ISNULL(addr.Phone,c.Phone) AS receiverTel,'' AS receiverMobile,0 AS pkgQty,1 AS fclQty,0.0 AS pkgVolumn,
		1 AS lclQty,0.0 AS lclVolumn, 0 AS fileQty,a.CreateDate,0.0 AS netWeight,0.0 AS grossWeight,
		a.BillNo AS mergeNo,90 AS billType,0 AS isInvalid,a.remarks,d.EmployeeName AS creatorName
	FROM WZX2015.dbo.PRJ_Order a
		LEFT JOIN WZX2015.dbo.BDM_SendAddress addr ON a.CustID=addr.CustID AND a.SendAddr=addr.SendAddr
		INNER JOIN WZX2015.dbo.WMS_F10_Customer_V c ON a.CustID=c.CustID
		LEFT  JOIN WZX2015.dbo.BDM_Employee d ON a.CreatorID=d.EmployeeID
	WHERE CAST(a.BillID AS VARCHAR(32))=@stockNo
		AND (a.DeptNo='1055')
		AND (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30')
		AND (ISNULL(a.CarNumberSts,'')='')
)
go

