-- =============================================
-- Author:		<Frank.He>
-- Create date: <2016-12-08>
-- Description:	<获取商品发货数量对应的库位 V1.2.2>
--			511-在商品指定库位查找(库位资料维护中指定)
--          521-在单据指定库位查找(单据上指定的库位)
--			531-在目标库区查找合适的库位
--			561-目标库位
-- Modify：     <2017-03-18日修改>
--     补充自动生成补货计划：
--     最后一个策略库存不足时必须是“自动生成补货计划”
--     缺货时，补货到有库存的库位或者空库位
--     2017-08-10日 增加分配算法515，并修正Bug
--	   Frank.He 2017-08-12日 调整算法，分配策略改为
--	   Frank.He 2017-11-02 当分配策略出现区域重叠时，去除重叠区域 V1.2.1
--	   Frank.He 2017-12-19 调整固定库位商品存放到非固定库位的算法 V1.2.2
--     Frank.He 2019-12-03 简化分配策略                           V1.2.3
-- =============================================
CREATE FUNCTION [dbo].[uf_GetPickLocation]
(
    @companyId VARCHAR(32),                     --公司Id
	@warehouseId VARCHAR(32),                   --仓库Id
	@ownerId VARCHAR(32),                       --业主
	@locNo VARCHAR(32),                         --指定库位
	@batchNo VARCHAR(32),                       --指定批次号(供应商的)
	@itemId VARCHAR(32),                        --商品Id
	@SQty DECIMAL(20,6),                        --计划数量
	@unitLevel VARCHAR(10),                     --包装规格（EA-散件;CS-整箱;PL-托盘;OT-其他，目前只又EA和CS）
	@orderType INT                              --订单类型0-不区分(暂时没用到）
)
RETURNS @result TABLE
(
	viewOrder INT IDENTITY(1,1),
	warehouseId VARCHAR(32),
	regionId VARCHAR(32),
	lotNo VARCHAR(32),
	locationNo varchar(32),
	itemId VARCHAR(32),
	pickQty DECIMAL(20,6),
    needReplenish INT
)
AS
BEGIN
	DECLARE @regionId VARCHAR(32);				--库区			
    DECLARE @lotNo VARCHAR(32);					--批次号
    DECLARE @locationNo VARCHAR(32);			--库位编码
    DECLARE @inventoryMode INT;					--批次管理：0-非批次；1-批次
    DECLARE @availQty DECIMAL(20,6);			--可用量
	DECLARE @pickPolicy INT;				    --分拣规则代码
    DECLARE @targRegion VARCHAR(32);		    --目标库区	
    DECLARE @targLocation VARCHAR(32);		    --目标库位
    DECLARE @isPackage INT;                     --库位使用:10,件拣货库位;20,箱拣货库位;30,混合拣库位;40,存储货库位;50,过渡库位
    DECLARE @replenishMode INT;				    --库位库存不足时处理方式：0-查找下一个库位；1-生成补货任务
    DECLARE @pickMode INT;					    --分配优先模式：1-满足优先；2-清库优先;3-顺序优先
    DECLARE @fifoFlag INT;					    --批次商品分配原则：1-现进先出；2-后进先出
    DECLARE @fifoBy INT;                        --批次商品排序原则：0-入库时间;1-过期日期;2-生产日期;3,批次号
    DECLARE @palletRatio INT;                   --整托数量
	--临时库存数据
	DECLARE @tmpStock TABLE(viewOrder INT,regionId VARCHAR(32),lotNo VARCHAR(32),locationNo VARCHAR(32),itemId VARCHAR(32),onhandQty DECIMAL(20,6),availQty DECIMAL(20,6),inputDate DATETIME)
	--批次管理	
	SELECT @inventoryMode=inventoryMode,@palletRatio=palletRatio
	FROM BAS_Item 
	WHERE itemId=@itemId;
	--循环分配策略，分配库位与库存量
	DECLARE myPolicy CURSOR
	FOR
		SELECT pickPolicy,targRegion,targLocation,isPackage,replenishMode,pickMode,fifoFlag,fifoBy
		FROM WMS_PickingPolicy
		WHERE (companyId=@companyId)							--公司Id
			AND (warehouseId=@warehouseId)						--仓库Id
			AND (ownerId=@ownerId)								--业主Id 
			AND (orderSource=@orderType OR orderSource=0)		--订单类型
			AND (unitLevel=@unitLevel)							--包装规格	
			AND (isDisable=0)									--有效的		
		ORDER BY viewOrder;
	OPEN myPolicy;
	FETCH NEXT FROM myPolicy INTO @pickPolicy,@targRegion,@targLocation,@isPackage,@replenishMode,@pickMode,@fifoFlag,@fifoBy;
	WHILE @@FETCH_STATUS=0
	BEGIN
		--数量分配完毕后不再循环
		IF (ISNULL(@SQty,0.0)<=0.0)
			BREAK;
        IF (@pickPolicy=511 OR @pickPolicy=521 OR @pickPolicy=561)
        BEGIN
            IF (@pickPolicy=511)        --商品固定库位查找
                SELECT TOP 1 @targLocation=locationNo,@targRegion=regionId
				FROM dbo.BAS_Location a
				WHERE (companyId=@companyId)						--公司
					AND (warehouseId=@warehouseId)					--仓库	
					AND (itemId=@itemId)							--商品Id
					AND (isFixed=1)									--固定库位
					AND (isDisable=0)								--有效库位				
					AND (isPackage=@isPackage)						--库位使用（0-有效库位;10-件捡货库位；20-箱捡货库位;40-储货位库位；50-过渡库位）
					AND NOT EXISTS(SELECT * FROM @result b WHERE a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo)
				ORDER BY pickingOrder;
            ELSE IF(@pickPolicy=521)    --单据指定库位查找
                SELECT @targLocation=locationNo,@targRegion=regionId
				FROM dbo.BAS_Location a
                WHERE (companyId=@companyId)						--公司
					AND (warehouseId=@warehouseId)					--仓库
					AND (locationNo=@locNo)                         --指定库位
					AND NOT EXISTS(SELECT * FROM @result b WHERE a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo)
            ELSE IF(@pickPolicy=561)    --策略指定库位查找
		        SELECT @targRegion=regionId
		        FROM dbo.BAS_Location
		        WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@targLocation;
		    IF (@inventoryMode=1)
		    BEGIN
		        --批次管理商品，可能存在一个库位多个批次的现象(实施时不建议这样混批次存放）
			    --1-现进先出；2-后进先出
			    IF (@fifoFlag=1)
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY t.inputDate ASC) AS viewOrder,a.regionId,
					    ISNULL(t.lotNo,'') AS lotNo,a.locationNo,t.itemId,ISNULL(t.onhandQty,0.0),ISNULL(t.availQty,0.0),
					    t.inputDate
				    FROM dbo.BAS_Location a 
				        LEFT  JOIN (SELECT m.companyId,m.warehouseId,m.lotNo,m.locationNo,m.itemId,m.onhandQty,
						                ISNULL(m.onhandQty,0.0)-ISNULL(m.allocQty,0.0)+ISNULL(m.onWayQty,0.0) AS availQty,
						                CASE ISNULL(@fifoBy,0) WHEN 0 THEN n.inputDate WHEN 1 THEN n.expiryDate WHEN 2 THEN n.productDate END AS inputDate
					                FROM dbo.IMS_Stock m 
					                    LEFT JOIN dbo.IMS_Batch n ON m.lotNo=n.lotNo
					                WHERE m.companyId=@companyId AND m.warehouseId=@warehouseId AND m.locationNo=@targLocation AND m.itemId=@itemId AND (n.batchNo=@batchNo OR ISNULL(@batchNo,'')='') 
					                ) t ON a.companyId=t.companyId AND a.warehouseId=t.warehouseId AND a.locationNo=t.locationNo
				    WHERE a.companyId=@companyId
					    AND a.warehouseId=@warehouseId
					    AND a.locationNo=@targLocation;
			    ELSE
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY t.inputDate DESC) AS viewOrder,a.regionId,
					    t.lotNo,a.locationNo,t.itemId,ISNULL(t.onhandQty,0.0),ISNULL(t.availQty,0.0),t.inputDate
				    FROM dbo.BAS_Location a 
				        LEFT  JOIN (SELECT m.companyId,m.warehouseId,m.lotNo,m.locationNo,m.itemId,m.onhandQty,
						                ISNULL(m.onhandQty,0.0)-ISNULL(m.allocQty,0.0)+ISNULL(m.onWayQty,0.0) AS availQty,
						                CASE ISNULL(@fifoBy,0) WHEN 0 THEN n.inputDate WHEN 1 THEN n.expiryDate WHEN 2 THEN n.productDate END AS inputDate
					                FROM dbo.IMS_Stock m 
					                    LEFT JOIN dbo.IMS_Batch n ON m.lotNo=n.lotNo 
					                WHERE m.companyId=@companyId AND m.warehouseId=@warehouseId AND m.locationNo=@targLocation AND m.itemId=@itemId AND (n.batchNo=@batchNo OR ISNULL(@batchNo,'')='')  
					                ) t ON a.companyId=t.companyId AND a.warehouseId=t.warehouseId AND a.locationNo=t.locationNo
				    WHERE a.companyId=@companyId
					    AND a.warehouseId=@warehouseId
					    AND a.locationNo=@targLocation;	
		    END
		    ELSE
		    BEGIN
		        --非批次管理商品（一个库位一个商品,唯一）
		        INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
		        SELECT ROW_NUMBER() OVER (ORDER BY a.pickingOrder ASC) AS viewOrder,a.regionId,b.lotNo,b.locationNo,b.itemId,b.onhandQty,b.availQty,b.inputDate
		        FROM dbo.BAS_Location a 
		            LEFT  JOIN (SELECT m.companyId,m.warehouseId,m.lotNo,m.locationNo,m.itemId,m.onhandQty,
					                ISNULL(m.onhandQty,0.0)-ISNULL(m.allocQty,0.0)+ISNULL(m.onWayQty,0.0) AS availQty,m.lastITime AS inputDate
			                    FROM dbo.IMS_Stock m 
			                    WHERE m.companyId=@companyId AND m.warehouseId=@warehouseId AND m.locationNo=@targLocation AND m.itemId=@itemId 
			         ) b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
		        WHERE a.companyId=@companyId
			        AND a.warehouseId=@warehouseId
			        AND a.locationNo=@targLocation;
			END
        END
	    ELSE IF (@pickPolicy=531)
	    BEGIN
		    --批次管理
		    IF (@inventoryMode=1)
		    BEGIN
			    --@fifoFlag 1-先进先出；2-后进先出
			    --@pickMode 1-满足优先；2-清库优先;
			    IF (@fifoFlag=1 AND @pickMode=1)			--先进先出，满足有限
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY inputDate ASC,availQty DESC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,
				              CASE ISNULL(@fifoBy,0) WHEN 0 THEN b.inputDate WHEN 1 THEN b.expiryDate WHEN 2 THEN b.productDate END AS inputDate
					      FROM dbo.IMS_Stock a 
					          LEFT JOIN dbo.IMS_Batch b ON a.lotNo=b.lotNo
					          INNER JOIN dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo
					      WHERE (a.companyId=@companyId)					        --公司Id
					            AND (a.warehouseId=@warehouseId)			        --仓库Id
					            AND (a.regionId=@targRegion)				        --目标库区
							    AND (a.itemId=@itemId)						        --目标商品
							    AND (c.isPackage=@isPackage)				        --目标库位类型
							    AND (b.batchNo=@batchNo OR ISNULL(@batchNo,'')='')  --指定批次
							    AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)
					    ) t							
			    ELSE IF (@fifoFlag=1 AND @pickMode=2)		--先进先出，清库优先
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY inputDate ASC,availQty ASC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,
				              CASE ISNULL(@fifoBy,0) WHEN 0 THEN b.inputDate WHEN 1 THEN b.expiryDate WHEN 2 THEN b.productDate END AS inputDate
					      FROM dbo.IMS_Stock a 
					          LEFT JOIN dbo.IMS_Batch b ON a.lotNo=b.lotNo 
					          INNER JOIN dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo	
					      WHERE (a.companyId=@companyId)					        --公司Id
					            AND (a.warehouseId=@warehouseId)			        --仓库Id
					            AND (a.regionId=@targRegion)				        --目标库区库区
							    AND (a.itemId=@itemId)						        --目标商品
							    AND (c.isPackage=@isPackage)				        --目标类型仓库
							    AND (b.batchNo=@batchNo OR ISNULL(@batchNo,'')='')  --指定批次
							    AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)		--不允许重复取库位
					    ) t 
			    ELSE IF (@fifoFlag=1 AND @pickMode=3)		--先进先出，顺序优先
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY inputDate ASC,pickingOrder ASC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,
				              CASE ISNULL(@fifoBy,0) WHEN 0 THEN b.inputDate WHEN 1 THEN b.expiryDate WHEN 2 THEN b.productDate END AS inputDate,c.pickingOrder
					      FROM dbo.IMS_Stock a 
					          LEFT JOIN dbo.IMS_Batch b ON a.lotNo=b.lotNo 
					          INNER JOIN dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo	
					      WHERE (a.companyId=@companyId)					        --公司Id
					            AND (a.warehouseId=@warehouseId)			        --仓库Id
					            AND (a.regionId=@targRegion)				        --目标库区库区
							    AND (a.itemId=@itemId)						        --目标商品
							    AND (c.isPackage=@isPackage)				        --目标类型仓库
							    AND (b.batchNo=@batchNo OR ISNULL(@batchNo,'')='')  --指定批次
							    AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)		--不允许重复取库位
					    ) t 
			    ELSE IF (@fifoFlag=2 AND @pickMode=1)		--后进先出，满足有限
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY inputDate DESC,availQty DESC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,
				              CASE ISNULL(@fifoBy,0) WHEN 0 THEN b.inputDate WHEN 1 THEN b.expiryDate WHEN 2 THEN b.productDate END AS inputDate
					      FROM dbo.IMS_Stock a 
					          LEFT JOIN  dbo.IMS_Batch b ON a.lotNo=b.lotNo 
					          INNER JOIN dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo	
					      WHERE (a.companyId=@companyId)					        --公司Id
					            AND (a.warehouseId=@warehouseId)			        --仓库Id
					            AND (a.regionId=@targRegion)				        --目标库区库区
							    AND (a.itemId=@itemId)						        --目标商品
							    AND (c.isPackage=@isPackage)				        --目标类型仓库
							    AND (b.batchNo=@batchNo OR ISNULL(@batchNo,'')='')  --指定批次
							    AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)		--不允许重复取库位
					    ) t 
			    ELSE IF (@fifoFlag=2 AND @pickMode=2)		--后进先出，清库优先
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY inputDate DESC,availQty ASC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,
				              CASE ISNULL(@fifoBy,0) WHEN 0 THEN b.inputDate WHEN 1 THEN b.expiryDate WHEN 2 THEN b.productDate END AS inputDate
					      FROM dbo.IMS_Stock a 
					          LEFT JOIN dbo.IMS_Batch b ON a.lotNo=b.lotNo 
					          INNER JOIN dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo
					      WHERE (a.companyId=@companyId)					        --公司Id
					            AND (a.warehouseId=@warehouseId)			        --仓库Id
					            AND (a.regionId=@targRegion)				        --目标库区库区
							    AND (a.itemId=@itemId)					            --目标商品
							    AND (c.isPackage=@isPackage)				        --目标类型仓库
							    AND (b.batchNo=@batchNo OR ISNULL(@batchNo,'')='')  --指定批次
							    AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)
					    ) t  
			    ELSE IF (@fifoFlag=2 AND @pickMode=3)		--后进先出，顺序优先
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY inputDate DESC,pickingOrder ASC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,
				              CASE ISNULL(@fifoBy,0) WHEN 0 THEN b.inputDate WHEN 1 THEN b.expiryDate WHEN 2 THEN b.productDate END AS inputDate,c.pickingOrder
					      FROM dbo.IMS_Stock a LEFT JOIN 
					          dbo.IMS_Batch b ON a.lotNo=b.lotNo INNER JOIN 
					          dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo
					      WHERE (a.companyId=@companyId)					        --公司Id
					            AND (a.warehouseId=@warehouseId)			        --仓库Id
					            AND (a.regionId=@targRegion)				        --目标库区库区
							    AND (a.itemId=@itemId)						        --目标商品
							    AND (c.isPackage=@isPackage)				        --目标类型仓库
							    AND (b.batchNo=@batchNo OR ISNULL(@batchNo,'')='')  --指定批次
							    AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)
					    ) t
		    END
		    ELSE		--非批次管理
		    BEGIN
		        --@fifoFlag 1-先进先出；2-后进先出
			    --@pickMode 1-满足优先；2-清库优先
			    IF (@fifoFlag=1 AND @pickMode=1)
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY lastITime,availQty DESC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,lastITime
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,a.lastITime
					      FROM dbo.IMS_Stock a 
					          INNER JOIN dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo	
					      WHERE (a.companyId=@companyId)					--公司Id
					          AND (a.warehouseId=@warehouseId)				--仓库Id
						      AND (a.regionId=@targRegion)					--目标库区库区
					          AND (a.itemId=@itemId)						--目标商品
						      AND (c.isPackage=@isPackage)					--目标类型仓库
						      AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)		--不允许重复取库位
					    ) t 
			    ELSE IF (@fifoFlag=1 AND @pickMode=2)
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY lastITime,availQty ASC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,lastITime
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,a.lastITime
					      FROM dbo.IMS_Stock a 
					          INNER JOIN dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo 	
					      WHERE (a.companyId=@companyId)					--公司Id
						      AND (a.warehouseId=@warehouseId)				--仓库Id
						      AND (a.regionId=@targRegion)					--目标库区库区
						      AND (a.itemId=@itemId)						--目标商品
						      AND (c.isPackage=@isPackage)					--目标类型仓库
						      AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)		--不允许重复取库位
					    ) t 
			    ELSE IF (@fifoFlag=1 AND @pickMode=3)
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY lastITime,pickingOrder ASC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,lastITime
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,c.pickingOrder,a.lastITime
					      FROM dbo.IMS_Stock a 
					          INNER JOIN dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo 	
					      WHERE (a.companyId=@companyId)					--公司Id
						      AND (a.warehouseId=@warehouseId)				--仓库Id
						      AND (a.regionId=@targRegion)					--目标库区库区
						      AND (a.itemId=@itemId)						--目标商品
						      AND (c.isPackage=@isPackage)					--目标类型仓库
						      AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)		--不允许重复取库位
					    ) t
		        IF (@fifoFlag=0 AND @pickMode=1)
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY lastITime DESC,availQty DESC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,lastITime
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,a.lastITime
					      FROM dbo.IMS_Stock a 
					          INNER JOIN dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo	
					      WHERE (a.companyId=@companyId)					--公司Id
					          AND (a.warehouseId=@warehouseId)				--仓库Id
						      AND (a.regionId=@targRegion)					--目标库区库区
					          AND (a.itemId=@itemId)						--目标商品
						      AND (c.isPackage=@isPackage)					--目标类型仓库
						      AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)		--不允许重复取库位
					    ) t 
			    ELSE IF (@fifoFlag=0 AND @pickMode=2)
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY lastITime DESC,availQty ASC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,lastITime
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,a.lastITime
					      FROM dbo.IMS_Stock a 
					          INNER JOIN dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo 	
					      WHERE (a.companyId=@companyId)					--公司Id
						      AND (a.warehouseId=@warehouseId)				--仓库Id
						      AND (a.regionId=@targRegion)					--目标库区库区
						      AND (a.itemId=@itemId)						--目标商品
						      AND (c.isPackage=@isPackage)					--目标类型仓库
						      AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)		--不允许重复取库位
					    ) t 
			    ELSE IF (@fifoFlag=0 AND @pickMode=3)
				    INSERT INTO @tmpStock(viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,inputDate)
				    SELECT ROW_NUMBER() OVER (ORDER BY lastITime DESC,pickingOrder ASC) AS viewOrder,regionId,lotNo,locationNo,itemId,onhandQty,availQty,lastITime
				    FROM (SELECT a.regionId,a.lotNo,a.locationNo,a.itemId,a.onhandQty,ISNULL(a.onhandQty,0.0)-ISNULL(a.allocQty,0.0)+ISNULL(a.onWayQty,0.0) AS availQty,c.pickingOrder,a.lastITime
					      FROM dbo.IMS_Stock a 
					          INNER JOIN dbo.BAS_Location c ON a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo 	
					      WHERE (a.companyId=@companyId)					--公司Id
						      AND (a.warehouseId=@warehouseId)				--仓库Id
						      AND (a.regionId=@targRegion)					--目标库区库区
						      AND (a.itemId=@itemId)						--目标商品
						      AND (c.isPackage=@isPackage)					--目标类型仓库
						      AND NOT EXISTS(SELECT 1 FROM @result d WHERE c.warehouseId=d.warehouseId AND c.locationNo=d.locationNo)		--不允许重复取库位
					    ) t	
		    END
	    END
		--2.如果找到可以分配的库位
		IF EXISTS(SELECT * FROM @tmpStock)
		BEGIN
			--初始化
			SET @locationNo=''
			SET @regionId=''
			SET @lotNo=''
			--2.1循环当前策略找到的库位，并分配数量		
			DECLARE myCursor CURSOR
			FOR SELECT regionId,lotNo,locationNo,itemId,availQty 
				FROM @tmpStock a
				WHERE availQty>0.0
				ORDER BY viewOrder
			OPEN myCursor
			FETCH NEXT FROM myCursor INTO @regionId,@lotNo,@locationNo,@itemId,@availQty
			WHILE @@FETCH_STATUS=0
			BEGIN	
				--数量分配完毕后不再循环
				IF (ISNULL(@SQty,0.0)<=0.0)
					BREAK;
				--如果当前库位可用量足够配货
				IF ISNULL(@availQty,0.0)-ISNULL(@SQty,0.0)>=0.0
					BEGIN
						INSERT INTO @result(warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)
						VALUES(@warehouseId,@regionId,ISNULL(@lotNo,''),ISNULL(@locationNo,''),@itemId,@SQty,0)
						SET @SQty=0.0;
						BREAK;
					END
				ELSE
					BEGIN
						INSERT INTO @result(warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)
						VALUES(@warehouseId,@regionId,@lotNo,@locationNo,@itemId,@availQty,0)
						SET @SQty=@SQty-@availQty;								
					END
				FETCH NEXT FROM myCursor INTO @regionId,@lotNo,@locationNo,@itemId,@availQty            
			END
			CLOSE	myCursor
			DEALLOCATE myCursor			
			--2.2.分配完成后如果还不能满足配货数量
			IF ISNULL(@SQty,0.0)>0.0
			BEGIN
				--@replenishMode 库位库存不足时处理方式：0-查找下一个库位；1-生成补货任务
				--固定库位分拣同样产生补货任务
				IF (@replenishMode=1)
				BEGIN
					--改变当前需求数量，并更新为需要补货
					INSERT INTO @result(warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)
					VALUES(@warehouseId,@targRegion,'','',@itemId,@SQty,1)
					SET @SQty=0.0;
					BREAK;
				END
			END
		END		
		ELSE
		BEGIN
			--@replenishMode 库位库存不足时处理方式：0-查找下一个库位；1-生成补货任务
			IF (@replenishMode=1)
			BEGIN
				--改变当前需求数量，并更新为需要补货
				INSERT INTO @result(warehouseId,regionId,lotNo,locationNo,itemId,pickQty,needReplenish)				
				VALUES(@warehouseId,@targRegion,'','',@itemId,@SQty,1)
				SET @SQty=0.0;
				BREAK;
			END
		END
		--3.清理当前策略所产生的临时数据
		DELETE FROM @tmpStock;
		FETCH NEXT FROM myPolicy INTO @pickPolicy,@targRegion,@targLocation,@isPackage,@replenishMode,@pickMode,@fifoFlag,@fifoBy;
	END
	CLOSE myPolicy;
	DEALLOCATE myPolicy;
    RETURN;
END
go

