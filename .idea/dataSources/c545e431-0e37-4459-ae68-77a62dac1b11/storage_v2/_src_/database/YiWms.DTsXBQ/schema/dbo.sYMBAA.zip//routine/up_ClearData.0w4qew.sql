-- =============================================
-- Author:		<Frank.He>
-- Create date: <2017-11-20>
-- Description:	<实施前清库>
-- parameter：
--		@companyId VARCHAR(32),			--公司Id(必要参数)
--		@all INT						--清除所有数据：1-是;0-否；
--		@itemFlag INT,					--商品资料参数：1-清理；0-保持；
--		@customerFlag INT,				--客户资料参数：1-清理；0-保持；
--		@supplierFlag INT,				--供应商资料参数：1-清理；0-保持；
--		@ownerFlag INT,					--清除业主参数：1-是;0-否
--		@wareFlag INT,					--清除仓库资料：1-是；0-否（清除库位资料，则清除库位资料并清除相关资料）;
--		@stockFlag INT,					--库位商品绑定参数:1-清理；0-保持（库位或者商品选择清理时，库位商品绑定必须清理）；	
--		@boxFlag INT,					--清除周转箱资料：1-是;0-否
--		@userFlag INT,					--清除用户角色：1-是；0-否
--		@putawayPolicy INT,				--清除上架策略：1-是;0-否；
--		@pickingPolicy INT,				--清除分配策略：1-是;0-否；
--		@wavePolicy INT,				--清除波次策略：1-是;0-否；
--		@repPolicy INT,					--清除补货策略：1-是;0-否；
--	    @parasFlag INT					--清除系统参数：1-是;0-否
-- =============================================

CREATE PROCEDURE [dbo].[up_ClearData]
(
	@companyId VARCHAR(32),			--公司Id(必要参数)
	@all INT,						--清除所有数据：1-是;0-否；
	@itemFlag INT,					--商品资料参数：1-清理；0-保持；
	@customerFlag INT,				--客户资料参数：1-清理；0-保持；
	@supplierFlag INT,				--供应商资料参数：1-清理；0-保持；
	@ownerFlag INT,					--清除业主参数：1-是;0-否
	@wareFlag INT,					--清除仓库资料：1-是；0-否（清除库位资料，则清除库位资料并清除相关资料）;
	@stockFlag INT,					--库位商品绑定参数:1-清理；0-保持（库位或者商品选择清理时，库位商品绑定必须清理）；	
	@boxFlag INT,					--清除周转箱资料：1-是;0-否
	@userFlag INT,					--清除用户角色：1-是；0-否
	@putawayPolicy INT,				--清除上架策略：1-是;0-否；
	@pickingPolicy INT,				--清除分配策略：1-是;0-否；
	@wavePolicy INT,				--清除波次策略：1-是;0-否；
	@repPolicy INT,					--清除补货策略：1-是;0-否；
	@parasFlag INT					--清除系统参数：1-是;0-否
)
AS
BEGIN
	--错误消息
	DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
	BEGIN TRY
		BEGIN TRANSACTION
		IF (@all=0)	
		BEGIN
			--删除商品资料（同时删除商品库存绑定资料）
			IF (@itemFlag=1)
			BEGIN
				DELETE FROM BAS_Brand WHERE companyId=@companyId;
				DELETE FROM BAS_Category WHERE companyId=@companyId;
				DELETE FROM BAS_CategoryBrand WHERE companyId=@companyId;
				DELETE FROM BAS_ItemImage WHERE companyId=@companyId;
				DELETE FROM ECM_ItemSku WHERE companyId=@companyId;
				DELETE FROM BAS_ItemVer WHERE companyId=@companyId;
				DELETE FROM BAS_Item WHERE companyId=@companyId;
				DELETE FROM IMS_Ledger WHERE companyId=@companyId;
				DELETE FROM IMS_Stock WHERE companyId=@companyId;
			END
			--删除客户资料
			IF (@customerFlag=1)
			BEGIN
				DELETE FROM BAS_AddressGroup WHERE companyId=@companyId;
				DELETE FROM BAS_AddressLine WHERE companyId=@companyId;
				DELETE FROM BAS_AreaLogistics WHERE companyId=@companyId;
				DELETE FROM BAS_LineRegion WHERE companyId=@companyId;
			
				DELETE FROM BAS_Contact WHERE partnerType=1 AND companyId=@companyId;			
				DELETE FROM BAS_Settlement WHERE companyId=@companyId;
				DELETE FROM BAS_StaffSize WHERE companyId=@companyId;
				DELETE FROM BAS_Trade WHERE companyId=@companyId;
				DELETE FROM BAS_Nature WHERE companyId=@companyId;
				DELETE FROM BAS_PartnerType WHERE companyId=@companyId;			
				DELETE FROM BAS_PartnerInvoice WHERE companyId=@companyId;
				DELETE FROM BAS_ReceiveAddress WHERE companyId=@companyId;
				DELETE FROM BAS_PartnerFinancial WHERE partnerId=ANY(SELECT partnerId FROM BAS_Partner WHERE partnerType=1 AND companyId=@companyId);
				DELETE FROM BAS_PartnerImage WHERE partnerId=ANY(SELECT partnerId FROM BAS_Partner WHERE partnerType=1 AND companyId=@companyId);
				DELETE FROM BAS_Partner WHERE partnerType=1 AND companyId=@companyId;
			END			
			--删除供应商资料
			IF (@supplierFlag=1)
			BEGIN
				DELETE FROM BAS_Contact WHERE partnerType=2 AND companyId=@companyId;
				DELETE FROM BAS_PartnerFinancial WHERE partnerId=ANY(SELECT partnerId FROM BAS_Partner WHERE partnerType=2 AND companyId=@companyId);
				DELETE FROM BAS_PartnerImage WHERE partnerId=ANY(SELECT partnerId FROM BAS_Partner WHERE partnerType=2 AND companyId=@companyId);
				DELETE FROM BAS_Contact WHERE partnerType=2 AND companyId=@companyId;
				DELETE FROM BAS_Partner WHERE partnerType=2 AND companyId=@companyId;
				DELETE FROM dbo.SAM_UserSupplier WHERE companyId=@companyId;

			END
			--删除业主数据
			IF (@ownerFlag=1)
			BEGIN
				DELETE FROM BAS_Contact WHERE partnerType=3 AND companyId=@companyId;
				DELETE FROM BAS_Partner WHERE partnerType=3 AND companyId=@companyId;
				DELETE FROM WMS_PutawayPolicy WHERE companyId=@companyId;
				DELETE FROM WMS_PickingPolicy WHERE companyId=@companyId;
				DELETE FROM WMS_WavePolicy WHERE companyId=@companyId;
				DELETE FROM WMS_ReplenishPolicy WHERE companyId=@companyId;
			END
			--删除仓库资料(同时删除仓库下的其他资料）
			IF (@wareFlag=1)
			BEGIN
				DELETE FROM BAS_Warehouse WHERE companyId=@companyId;
				DELETE FROM BAS_Region WHERE companyId=@companyId;
				DELETE FROM BAS_LineRegion WHERE companyId=@companyId;
				DELETE FROM BAS_WareArea WHERE companyId=@companyId;
				DELETE FROM BAS_Location WHERE companyId=@companyId;
				DELETE FROM BAS_layer WHERE companyId=@companyId;
				DELETE FROM BAS_Worktable WHERE companyId=@companyId;
				DELETE FROM IMS_Ledger WHERE companyId=@companyId;
				DELETE FROM IMS_Stock WHERE companyId=@companyId;
				DELETE FROM WMS_PutawayPolicy WHERE companyId=@companyId;
				DELETE FROM WMS_PickingPolicy WHERE companyId=@companyId;
				DELETE FROM WMS_WavePolicy WHERE companyId=@companyId;
				DELETE FROM WMS_ReplenishPolicy WHERE companyId=@companyId;
				DELETE FROM SAM_UserRegion WHERE companyId=@companyId;	
			END			
			--清除库位商品绑定数据
			IF (@stockFlag=1)
			BEGIN
				DELETE FROM IMS_Ledger WHERE companyId=@companyId;
				DELETE FROM IMS_Stock WHERE companyId=@companyId;
			END
			--清除周转箱资料		
			IF (@boxFlag=1)
			BEGIN
				DELETE FROM WMS_Box WHERE companyId=@companyId;
				DELETE FROM WMS_BoxSize WHERE companyId=@companyId;
				DELETE FROM BAS_Car WHERE companyId=@companyId;
			END	
			--清除用户角色
			IF (@userFlag=1)
			BEGIN
				--清除组织架构、员工资料
				DELETE FROM BAS_Department WHERE companyId=@companyId;
				DELETE FROM BAS_Employee WHERE companyId=@companyId;
			
				DELETE FROM SAM_User WHERE companyId=@companyId;
				DELETE FROM SAM_UserFunction WHERE companyId=@companyId;
				DELETE FROM SAM_UserPrint WHERE companyId=@companyId;
				DELETE FROM SAM_UserRole WHERE companyId=@companyId;
				DELETE FROM SAM_UserTemletSort WHERE companyId=@companyId;
				DELETE FROM SAM_UserTemplet WHERE companyId=@companyId;
				DELETE FROM SAM_UserTempletDetail WHERE companyId=@companyId;	
				DELETE FROM SAM_UserRegion WHERE companyId=@companyId;			
				DELETE FROM SAM_Role WHERE companyId=@companyId;			
				DELETE FROM SAM_RoleFunction WHERE companyId=@companyId;
				DELETE FROM SAM_CompanyProduct WHERE companyId=@companyId;
				DELETE FROM SAM_CompanyTemplet WHERE companyId=@companyId;
				DELETE FROM SAM_CompanyTemletSort WHERE companyId=@companyId;
				DELETE FROM SAM_CompanyTempletDetail WHERE companyId=@companyId;	
				DELETE FROM SAM_Store WHERE companyId=@companyId;
				DELETE FROM ECM_OpenBone WHERE companyId=@companyId;
				DELETE FROM dbo.SAM_UserSupplier WHERE companyId=@companyId;
			END			
			--清除上架策略
			IF (@putawayPolicy=1)
			BEGIN
				DELETE FROM WMS_PutawayPolicy WHERE companyId=@companyId;
			END
			--清除分配策略
			IF (@pickingPolicy=1)
			BEGIN
				DELETE FROM WMS_PickingPolicy WHERE companyId=@companyId;
			END
			--清除波次策略
			IF (@wavePolicy=1)
			BEGIN
				DELETE FROM WMS_WavePolicy WHERE companyId=@companyId;
			END
			--清除补货策略
			IF (@repPolicy=1)
			BEGIN
				DELETE FROM WMS_ReplenishPolicy WHERE companyId=@companyId;
			END
			--清理各种参数
			IF (@parasFlag=1)
			BEGIN
				--清除系统打印设置
				DELETE FROM SAM_PrintSetting WHERE companyId=@companyId;
				DELETE FROM SAM_Config WHERE companyId=@companyId;
				DELETE FROM SAM_BillType WHERE companyId=@companyId;
			END
		END
		ELSE
		BEGIN
			DELETE FROM BAS_AddressGroup WHERE companyId=@companyId;
			DELETE FROM BAS_AddressLine WHERE companyId=@companyId;
			DELETE FROM BAS_AreaLogistics WHERE companyId=@companyId;
			DELETE FROM BAS_LineRegion WHERE companyId=@companyId;
			DELETE FROM BAS_Car WHERE companyId=@companyId;
			--清除商品资料相关数据
			DELETE FROM BAS_Brand WHERE companyId=@companyId;
			DELETE FROM BAS_Category WHERE companyId=@companyId;
			DELETE FROM BAS_CategoryBrand WHERE companyId=@companyId;
			DELETE FROM BAS_ItemImage WHERE companyId=@companyId;
			DELETE FROM ECM_ItemSku WHERE companyId=@companyId;
			DELETE FROM BAS_ItemVer WHERE companyId=@companyId;
			DELETE FROM BAS_Item WHERE companyId=@companyId;
			--清除组织架构、员工资料
			DELETE FROM BAS_Department WHERE companyId=@companyId;
			DELETE FROM BAS_Employee WHERE companyId=@companyId;
			
			DELETE FROM ECM_OpenBone WHERE companyId=@companyId;
			--清除客户资料相关数据
			DELETE FROM BAS_Contact WHERE companyId=@companyId;			
			DELETE FROM BAS_Settlement WHERE companyId=@companyId;
			DELETE FROM BAS_StaffSize WHERE companyId=@companyId;
			DELETE FROM BAS_Trade WHERE companyId=@companyId;
			DELETE FROM BAS_Nature WHERE companyId=@companyId;
			DELETE FROM BAS_PartnerType WHERE companyId=@companyId;
			DELETE FROM BAS_PartnerFinancial WHERE companyId=@companyId;
			DELETE FROM BAS_PartnerInvoice WHERE companyId=@companyId;
			DELETE FROM BAS_ReceiveAddress WHERE companyId=@companyId;
			DELETE FROM BAS_PartnerImage WHERE companyId=@companyId;
			DELETE FROM BAS_Partner WHERE companyId=@companyId;
			
			--清除仓库资料相关数据
			DELETE FROM BAS_Warehouse WHERE companyId=@companyId;					--删除公司仓库
			DELETE FROM BAS_Region WHERE companyId=@companyId;						--删除仓库区域
			DELETE FROM BAS_WareArea WHERE companyId=@companyId;					--删除仓库库区
			DELETE FROM BAS_Layer WHERE companyId=@companyId;						--仓库层列规格定义
			DELETE FROM BAS_Location WHERE companyId=@companyId;					--删除仓库库位			
			DELETE FROM BAS_Worktable WHERE companyId=@companyId;					--删除工作台（复核台）
			--删除商品库存资料
			DELETE FROM IMS_Ledger WHERE companyId=@companyId;
			DELETE FROM IMS_Stock WHERE companyId=@companyId;
			--清除箱子规格与周转箱资料
			DELETE FROM WMS_Box WHERE companyId=@companyId;
			DELETE FROM WMS_BoxSize WHERE companyId=@companyId;
			--清除公司权限数据
			DELETE FROM SAM_User WHERE companyId=@companyId;
			DELETE FROM SAM_UserFunction WHERE companyId=@companyId;
			DELETE FROM SAM_UserPrint WHERE companyId=@companyId;
			DELETE FROM SAM_UserRole WHERE companyId=@companyId;
			DELETE FROM SAM_UserTemletSort WHERE companyId=@companyId;
			DELETE FROM SAM_UserTemplet WHERE companyId=@companyId;
			DELETE FROM SAM_UserTempletDetail WHERE companyId=@companyId;			
			DELETE FROM SAM_Role WHERE companyId=@companyId;			
			DELETE FROM SAM_RoleFunction WHERE companyId=@companyId;
			DELETE FROM SAM_Store WHERE companyId=@companyId;
			DELETE FROM SAM_UserRegion WHERE companyId=@companyId;		
			DELETE FROM SAM_CompanyProduct WHERE companyId=@companyId;
			DELETE FROM SAM_CompanyTemplet WHERE companyId=@companyId;
			DELETE FROM SAM_CompanyTemletSort WHERE companyId=@companyId;
			DELETE FROM SAM_CompanyTempletDetail WHERE companyId=@companyId;	
			--清除系统策略表
			DELETE FROM WMS_PickingPolicy WHERE companyId=@companyId;
			DELETE FROM WMS_PutawayPolicy WHERE companyId=@companyId;
			DELETE FROM WMS_ReplenishPolicy WHERE companyId=@companyId;
			DELETE FROM WMS_WavePolicy WHERE companyId=@companyId;
			--清理系统参数
			DELETE FROM SAM_PrintSetting WHERE companyId=@companyId;
			DELETE FROM SAM_Config WHERE companyId=@companyId;
			DELETE FROM SAM_BillType WHERE companyId=@companyId;
			--清理用户供应商
			DELETE FROM dbo.SAM_UserSupplier WHERE companyId=@companyId;
		END
		--清除出库订单池数据
		DELETE FROM SAD_OrderDetail WHERE companyId=@companyId;
		DELETE FROM SAD_Order WHERE companyId=@companyId;
		DELETE FROM SAD_OrderAction WHERE companyId=@companyId;
		--清除出库单数据
		DELETE FROM SAD_StockDetail WHERE companyId=@companyId;
		DELETE FROM SAD_Stock WHERE companyId=@companyId;
		--清除发货退货单数据
		DELETE FROM SAD_ReturnDetail WHERE companyId=@companyId;
		DELETE FROM SAD_Return WHERE companyId=@companyId;
		
		--清除入库订单池数据
		DELETE FROM PMS_OrderDetail WHERE companyId=@companyId;
		DELETE FROM PMS_Order WHERE companyId=@companyId;
		--清除入库单数据
		DELETE FROM PMS_StockDetail WHERE companyId=@companyId;
		DELETE FROM PMS_Stock WHERE companyId=@companyId;
		--清除收货退货单数据
		DELETE FROM PMS_ReturnDetail WHERE companyId=@companyId;
		DELETE FROM PMS_Return WHERE companyId=@companyId;
		
		--清除库存业务数据
		--清除调整单数据
		DELETE FROM IMS_AdjustDetail WHERE companyId=@companyId;
		DELETE FROM IMS_Adjust WHERE companyId=@companyId;
		--清除上架分配临时数据
		DELETE FROM IMS_Allocate WHERE companyId=@companyId;
		--清除批次数据
		DELETE FROM IMS_Batch WHERE companyId=@companyId;
		--清除流水账
		DELETE FROM IMS_Book WHERE companyId=@companyId;		
		--清除盘点数据
		DELETE FROM IMS_CheckPoint WHERE companyId=@companyId;
		DELETE FROM IMS_CheckStock WHERE companyId=@companyId;
		DELETE FROM IMS_CheckTask WHERE companyId=@companyId;
		DELETE FROM IMS_CheckDetail WHERE companyId=@companyId;
		DELETE FROM IMS_Check WHERE companyId=@companyId;
		--清除其他入出库单数据
		DELETE FROM IMS_OtherDetail WHERE companyId=@companyId;
		DELETE FROM IMS_Other WHERE companyId=@companyId;
		--清除补货数据
		DELETE FROM IMS_Replenish WHERE companyId=@companyId;
		--清除移仓单数据
		DELETE FROM IMS_TransferDetail WHERE companyId=@companyId;
		DELETE FROM IMS_Transfer WHERE companyId=@companyId;
		--更新库存数据
		UPDATE IMS_Ledger SET onhandQty=0.0,allocQty=0.0;
		UPDATE IMS_Stock SET onhandQty=0.0,allocQty=0,onWayQty=0.0;
				
		DELETE FROM WMS_Allocate WHERE companyId=@companyId;
		--清除打包数据
		DELETE FROM WMS_PackingDetail WHERE companyId=@companyId;
		DELETE FROM WMS_Packing WHERE companyId=@companyId;
		--清除波次任务数据
		DELETE FROM WMS_PickingDetail WHERE companyId=@companyId;
		DELETE FROM WMS_PickingOrder WHERE companyId=@companyId;
		DELETE FROM WMS_PickingError WHERE companyId=@companyId;
		DELETE FROM WMS_Picking WHERE companyId=@companyId;
		--重置箱号
		dbcc checkident(WMS_PickingOrder,RESEED,10000);
		--清除上架任务表
		DELETE FROM WMS_PutawayDetail WHERE companyId=@companyId;
		DELETE FROM WMS_Putaway WHERE companyId=@companyId;
		--清除临时补货任务数据与临时预分配数据（主要用在订单提前预分配算法中）
		DELETE FROM WMS_Replenish WHERE companyId=@companyId;		
		--清除发车单数据
		DELETE FROM WMS_ShipDetail WHERE companyId=@companyId;
		DELETE FROm WMS_ShipOther WHERE companyId=@companyId;
		DELETE FROM WMS_Ship WHERE companyId=@companyId;		
		--清除波次数据
		DELETE FROM WMS_WaveDetail WHERE companyId=@companyId;
		DELETE FROM WMS_Wave WHERE companyId=@companyId;
		--清除接口错误日志
		DELETE FROM WMS_Log WHERE companyId=@companyId;
		--清除系统错误日志
		DELETE FROM SAM_Error WHERE companyId=@companyId;
		--清除系统日志
		DELETE FROM SAM_Log WHERE companyId=@companyId;
		--清除系统编码
		DELETE FROM SAM_Coding WHERE companyId=@companyId;
		--清除系统消息
		DELETE FROM SAM_Message WHERE companyId=@companyId;
		--清除公司消息模板
		DELETE FROM SAM_MsgTemplet WHERE companyId=@companyId;	
		
		--清除TMS数据
		--DELETE FROM dbo.TMS_Customer WHERE companyId=@companyId;
		DELETE FROM dbo.TMS_Reason WHERE companyId=@companyId;
		DELETE FROM dbo.TMS_ReasonType WHERE companyId=@companyId;
		DELETE FROM dbo.TMS_ReasonType WHERE companyId=@companyId;
		DELETE FROM dbo.TMS_Sign WHERE companyId=@companyId;
		--DELETE FROM dbo.TMS_Site WHERE companyId=@companyId;
		DELETE FROM TMS_SubWaybill WHERE companyId=@companyId;
		DELETE FROM TMS_WayBill WHERE companyId=@companyId;		
		DELETE FROM TMS_WaySite WHERE companyId=@companyId;
		
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();	
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END CATCH
END


go

