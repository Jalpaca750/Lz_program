
/*==============================================================*/
/* View: SYS_Package_V                                          */
/*==============================================================*/
create view SYS_Package_V as
SELECT '主单位' AS unitDesc,'EA' AS unitCode,'个' AS unitName,1 AS viewOrder
UNION
SELECT '箱' AS unitDesc,'CS' AS unitCode,'箱' AS unitName,2 AS viewOrder
UNION
SELECT '托盘' AS unitDesc,'PL' AS unitCode,'托盘' AS unitName,3 AS viewOrder
UNION
SELECT '其他' AS unitDesc,'OT' AS unitCode,'其他' AS unitName,4 AS viewOrder
go

