 CREATE View  SDay_Order_V
 as
 select A.ItemID,A.SendAddr,a.StockNo,B.CustName,A.ItemName,A.OrderId,
 A.ItemNo,A.ColorName,A.ItemSpec,A.IQty,
 (select locationNo+',' from IMS_Stock_V where ItemNo=A.ItemNo FOR XML PATH('')) locationNo
 FROM  F10BMS.dbo.SMS_StockDtl_V  A 
 LEFT JOIN  F10BMS.dbo.BDM_Customer B
 ON A.CustID=B.CustId
 go

