CREATE VIEW [dbo].[PD_BY_UPDATE] as
SELECT 
a.billNo AS DANJ_NO,a.by_thirdSyncFlag AS SC_FLG,A.by_thirdSyncTime AS SC_FLAG_TIME
FROM dbo.IMS_Adjust a  
WHERE  (isnull(a.by_thirdSyncFlag,0)=0 or isnull(a.by_thirdSyncFlag,0)=2)
go

