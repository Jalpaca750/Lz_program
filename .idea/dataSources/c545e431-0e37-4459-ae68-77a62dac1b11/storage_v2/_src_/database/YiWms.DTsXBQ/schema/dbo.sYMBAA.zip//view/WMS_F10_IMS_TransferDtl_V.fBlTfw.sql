

/*==============================================================*/
/* View: WMS_F10_IMS_TransferDtl_V                              */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_IMS_TransferDtl_V] as
SELECT a.transferId,a.TransferNo,b.billNo,wo.warehouseNo AS WareHouse_O,
	wi.warehouseNo AS WareHouse_I,bi.f10Id AS itemId,ioQty AS TQty,a.price,
	a.totalFee AS amt,bi.pkgRatio, a.remarks
FROM dbo.IMS_TransferDetail a
	INNER JOIN dbo.IMS_Transfer b ON a.transferNo=b.transferNo
	INNER JOIN dbo.BAS_Warehouse wo ON a.outputId=wo.warehouseId
	INNER JOIN dbo.BAS_Warehouse wi ON a.inputId=wi.warehouseId
	LEFT JOIN F10BMS.dbo.WMS_F10_Item_V bi ON a.itemId=bi.itemId
WHERE (b.ioState=2)
	AND (b.thirdSyncFlag=0)
	AND (b.inputId!=b.outputId)
go

