/*==============================================================*/
/* View: WMS_PackingBox_V                                       */
/*==============================================================*/
CREATE view [dbo].[WMS_PackingBox_V] as
SELECT a.stockId,a.stockNo,b.boxNum,SUM(a.packQty) AS packQty 
FROM dbo.WMS_PackingDetail a
	INNER JOIN dbo.WMS_Packing b ON a.packNo=b.packNo
GROUP BY a.stockId,a.stockNo,b.boxNum

go

