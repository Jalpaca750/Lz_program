

/*==============================================================*/
/* View: WMS_PickingDetail_V                                    */
/*==============================================================*/
--creator：Frank
--create time：2016-02-18 
--拣货任务主明细视图
CREATE view [dbo].[WMS_PickingDetail_V] as
SELECT pd.pickingId,pd.pickId,pd.pickingNo,p.billNo AS pickBillNo,p.waveBillNo,pd.companyId,
	po.boxBillNum,pd.warehouseId,w.warehouseNo,w.warehouseName,pd.regionId,r.regionDesc,pd.batchNo,
	pd.locationNo,pd.eId,pd.itemId,sku.itemNo,sku.itemName,sku.itemCTitle,sku.itemETitle,sku.itemSpec,
	sku.itemSpell,sku.sellingPoint,sku.barcode,sku.brandId,sku.brandNo,sku.brandCName,sku.categoryId,
	sku.categoryNo,sku.categoryCName,sku.colorName,sku.sizeName,pd.isPackage,
	CASE pd.isPackage WHEN 1 THEN '整箱' ELSE '散件' END AS isPackageDesc,
	CASE pd.isPackage WHEN 1 THEN sku.pkgUnit ELSE sku.unitName END AS unitName,
	pd.pickState,CASE pd.pickState WHEN 0 THEN '待领取'
                                   WHEN 1 THEN '待拣货'
                                   WHEN 2 THEN '待复核'
                                   WHEN 3 THEN '待打包' 
                                   WHEN 4 THEN '已打包' END AS pickStateName,pd.stockQty,pd.pickQty,
    pd.actualQty,pd.realQty,CASE pd.printNum WHEN -1 THEN '是' ELSE '否' end as printNumName,
    CASE pd.isPackage WHEN 1 THEN pd.pickQty * pd.pkgRatio ELSE pd.pickQty END AS actQty,pd.boxId,bx.boxCode,
    pd.itemVolume,CASE pd.isPackage WHEN 1 THEN pd.pickQty*sku.pkgVolume ELSE pd.pickQty*pd.itemVolume END AS totalVolume,
    pd.itemWeight,CASE pd.isPackage WHEN 1 THEN pd.pickQty*sku.pkgWeight ELSE pd.pickQty*pd.itemWeight END AS totalWeight,
    pd.boxOrder,pd.stockId,pd.stockNo,pd.stockBillNo,pd.pkgRatio,sku.pkgUnit,sku.unitName AS skuUnit,
    sku.packageId,sku.largeUrl,sku.middleUrl,sku.littleUrl,sku.smallUrl,sd.orderBillNo,pd.printNum,pd.printId,
    CONVERT(VARCHAR(20),pd.printTime,120) AS printTime,pd.packId,sd.viewOrder,isnull(sd.toOrder,0) toOrder,
    CASE ISNULL(sd.toOrder,0) WHEN 0 THEN '' ELSE '定制品' END AS toOrderDesc,po.taskState
FROM dbo.WMS_PickingDetail pd 
	INNER JOIN dbo.WMS_PickingOrder po ON pd.pickId=po.pickId 
	INNER JOIN dbo.WMS_Picking p ON pd.pickingNo=p.pickingNo 
	INNER JOIN dbo.BAS_Warehouse w ON pd.warehouseId=w.warehouseId 
	INNER JOIN dbo.BAS_Goods_V sku ON pd.itemId=sku.itemId 
	LEFT JOIN dbo.SAD_StockDetail sd ON pd.stockId=sd.stockId 
	LEFT JOIN dbo.BAS_Region r ON pd.regionId=r.regionId 
	LEFT JOIN dbo.WMS_Box bx ON pd.boxId=bx.boxId



go

