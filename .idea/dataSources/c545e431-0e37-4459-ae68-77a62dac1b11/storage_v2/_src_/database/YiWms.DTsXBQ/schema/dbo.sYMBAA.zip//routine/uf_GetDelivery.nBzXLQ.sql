

-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-09-20>
-- Description:	<Description:销售A单打印报表>       
-- =============================================
CREATE FUNCTION [dbo].[uf_GetDelivery] 
(
	@stockNo VARCHAR(32),					--实际出库单No
	@aStockNo VARCHAR(32)					--A实际出库单No
)
RETURNS TABLE
RETURN(
	SELECT a.stockNo,CASE ISNULL(p.reportTitle,'') WHEN '' THEN c.companyName ELSE p.reportTitle END AS reportTitle,
		a.groupId,a.ioType,a.orderType,CASE a.orderType WHEN 10 THEN '销售出库单' 
														WHEN 20 THEN '调拨出库单' 
														WHEN 30 THEN '经营领用单' 
														WHEN 31 THEN '管理领用单' 
														WHEN 32 THEN '其他出库单'
														WHEN 40 THEN '赠品出库单' 
														WHEN 50 THEN '报损报废单' END AS subTitle,t.billNo,t.collectOrder,
		w.warehouseNo,w.warehouseName,p.partnerNo AS customerNo,p.partnerName AS customerName,ISNULL(a1.areaName,a.receiverState) AS stateName,
		ISNULL(a2.areaName,a.receiverCity) AS cityName,ISNULL(a3.areaName,a.receiverDistrict) AS districtName,a.receiverAddress,
		ISNULL(a1.areaName,a.receiverState)+ISNULL(a2.areaName,a.receiverCity)+ISNULL(a3.areaName,a.receiverDistrict)+ISNULL(a.receiverAddress,'') AS fullAddress,
		ln.lineCode,ISNULL(ln.lineName,'') + '  ' + CAST(a.collectOrder AS VARCHAR(4)) AS lineName,a.receiverName,a.receiverMobile,a.receiverTel,
		LTRIM(ISNULL(a.receiverMobile,'') + ' ' + ISNULL(a.receiverTel,'')) AS fullTel,CASE a.aFlag WHEN 0 THEN '' WHEN 3 THEN '' ELSE 'A' END AS aBillFlag,
		a.settlementId,ISNULL(s.settlementName,a.settlementId) AS settlementName,a.auditTime,a.shipDate,a.shipTime,a.salesId,
		ISNULL(e1.employeeName,a.salesId) AS salesName,a.deptId,a.expressNo,lg.logisticsCode,ISNULL(lg.logisticsName,a.logisticsId) AS logisticsName,
		a.mergeNo,ISNULL(a.printNum,0) + 1 AS printNum,a.memo,'订单:' + ISNULL(a.mergeNo,'') + ';' + ISNULL(a.memo,'') AS orderMemo,t.reviewerName,
		ROW_NUMBER() OVER (ORDER BY b.viewOrder) AS viewOrder,sku.itemNo,sku.itemName,sku.itemSpec,sku.packageId,
		sku.barcode,sku.midBarcode,sku.bigBarcode,sku.pkgBarcode,sku.colorName,sku.sizeName,sku.unitName,
		b.stockQty,isnull(b.stockQty,0.0) AS actQty,b.befPrice,b.price,b.discount,ISNULL(b.discountFee,0.0) AS discountFee,
		b.totalFee,dbo.uf_GetUpper(b.totalFee) AS upperRMB,b.remarks,u1.userNick AS creatorName,a.organizeId,NULL AS boxNums,t.lclCount,t.fclCount,
		ISNULL(t.lclCount,0)+ISNULL(t.fclCount,0) AS totalQty,a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5,
		LTRIM(CASE ISNULL(fcl.fclQty,0) WHEN 0 THEN '' ELSE '整箱  ' + CAST(fcl.fclQty AS VARCHAR(4)) END + CASE ISNULL(t.lclCount,0) WHEN 0 THEN '' ELSE '  拼箱  ' + CAST(t.lclCount AS VARCHAR(4)) END) + ' 共 ' + CAST(CAST(ISNULL(lcl.lclQty,0)+ISNULL(t.fclCount,0) AS INT) AS VARCHAR(40)) + ' 箱' AS packageDesc
	FROM dbo.SAD_StockDetail AS b 
		INNER JOIN dbo.SAD_Stock AS a ON b.stockNo = a.stockNo 
		INNER JOIN dbo.BAS_Item AS sku ON b.itemId = sku.itemId 
		INNER JOIN dbo.BAS_Partner p ON a.customerId=p.partnerId
		INNER JOIN dbo.SAM_Company c ON a.companyId=c.companyId      
		INNER JOIN dbo.BAS_Warehouse AS w ON a.warehouseId=w.warehouseId
		LEFT JOIN dbo.BAS_Area a1 ON a.receiverState=a1.areaId 
		LEFT JOIN dbo.BAS_Area a2 ON a.receiverCity=a2.areaId 
		LEFT JOIN dbo.BAS_Area a3 ON a.receiverDistrict=a3.areaId 
		LEFT JOIN dbo.BAS_AddressLine ln ON a.lineId=ln.lineId 
		LEFT JOIN dbo.BAS_Settlement s ON a.settlementId=s.settlementId  
		LEFT JOIN dbo.BAS_Logistics lg ON a.logisticsId=lg.logisticsId 
		LEFT JOIN dbo.SAM_User u1 ON a.creatorId=u1.userId
		LEFT JOIN dbo.BAS_Employee e1 ON a.salesId=e1.employeeId
		LEFT JOIN (SELECT @aStockNo AS stockNo,COUNT(1) AS lclQty
				   FROM dbo.WMS_Packing 
				   WHERE stockNo=@stockNo 
				   GROUP BY stockNo) lcl ON a.stockNo=lcl.stockNo
		LEFT JOIN (SELECT @aStockNo AS stockNo,SUM(CAST(m.pickQty AS INT)) AS fclQty 
				   FROM dbo.WMS_PickingDetail m 
				   WHERE m.stockNo=@stockNo AND m.isPackage=1 
				   GROUP BY m.stockNo) fcl ON a.stockNo=fcl.stockNo
		LEFT JOIN (SELECT @aStockNo AS stockNo,a.billNo,a.collectOrder,a.fclCount,a.lclCount,u1.userNick AS reviewerName
		           FROM dbo.SAD_Stock a 
						LEFT JOIN dbo.SAM_User u1 ON a.reviewerId=u1.userId  
		           WHERE a.stockNo=@stockNo) t ON b.stockNo=t.stockNo 
	WHERE a.stockNo=@aStockNo
)





go

