
-- =============================================
-- Author:		<Author:Frank>
-- Create date: <Create Date:2016-12-01>
-- Description:	<Description:预算散件拼箱数>
-- Modify:       Frank,2017-03-10 只计算周转箱
-- =============================================

CREATE FUNCTION uf_GetMaximalBoxes 
(
	@companyId VARCHAR(32),			--公司Id
	@bulkVolumn DECIMAL(20,6)		--体积
)
RETURNS INT
AS
BEGIN
	DECLARE @maxVolume DECIMAL(20,6);
	DECLARE @result INT;
	--最大箱规
	SELECT @maxVolume = MAX(boxVolume)
	FROM WMS_BoxSize
	WHERE companyId=@companyId AND boxType=1;
	--计算最大拼箱数
	IF (@maxVolume>0.0)
		SET @result=CEILING(@bulkVolumn/@maxVolume);
	ELSE
	   SET @result=1;

	RETURN @result;
END
go

