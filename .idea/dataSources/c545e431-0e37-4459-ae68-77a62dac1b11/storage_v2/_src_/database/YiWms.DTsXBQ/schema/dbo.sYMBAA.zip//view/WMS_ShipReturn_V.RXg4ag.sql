

/*==============================================================*/
/* View: WMS_ShipReturn_V                                       */
/*==============================================================*/
CREATE view [dbo].[WMS_ShipReturn_V] as
--销售退货单
SELECT a.ReturnNo AS billNo,a.ReturnNo AS stockBillNo,c.customerId,'' AS receiverState,'' AS receiverCity,
	'' AS receiverDistrict,a.SendAddr AS receiverAddress,a.LinkMan AS receiverName,a.Phone AS receiverTel,
	'' AS receiverMobile,b.pkgQty,CASE WHEN b.bulkQty>0.0 THEN 1+b.pkgQty ELSE b.pkgQty END AS fclQty,
	b.pkgVolumn,CASE WHEN b.bulkQty>0.0 THEN 1 ELSE 0 END AS lclQty,b.lclVolumn, 0 AS fileQty,
	a.sendDate,0.0 AS netWeight,b.totalWeight AS grossWeight,b.Amt AS TotalFee,
	a.ReturnNo AS mergeNo,60 AS billType,0 AS isInvalid,a.remarks,c.ServiceName,
	addr.viewOrder AS lineOrder
FROM F10BMS.dbo.SMS_Return a
	INNER JOIN (SELECT t1.ReturnNo,SUM(t1.Amt) AS Amt,
					SUM(CASE ISNULL(t2.pkgRatio,0) WHEN 0 THEN 0 ELSE FLOOR((ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))/t2.pkgRatio) END) AS pkgQty,
					SUM(CASE ISNULL(t2.pkgRatio,0) WHEN 0 THEN 0 ELSE FLOOR((ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))/t2.pkgRatio)*ISNULL(t2.pkgVolume,0.0) END) AS pkgVolumn,
					SUM(CASE ISNULL(t2.pkgRatio,0) WHEN 0 THEN ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0) ELSE (ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))%t2.pkgRatio END) AS bulkQty,
					SUM(CASE ISNULL(t2.pkgRatio,0) WHEN 0 THEN (ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))*ISNULL(t2.itemVolume,0.0) ELSE ISNULL(t2.itemVolume,0.0)*((ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))%t2.pkgRatio) END) AS lclVolumn,
					SUM((ISNULL(t1.RQty,0.0)+ISNULL(t1.ZQty,0.0))*ISNULL(t2.itemWeight,0.0)) AS totalWeight
				FROM F10BMS.dbo.SMS_ReturnDtl t1
					INNER JOIN F10BMS.dbo.WMS_F10_Item_V t2 ON t1.ItemID=t2.f10Id 
				GROUP BY t1.ReturnNo) b ON a.ReturnNo=b.ReturnNo
	INNER JOIN F10BMS.dbo.WMS_F10_Customer_V c ON a.CustID=c.CustID
	LEFT JOIN F10BMS.dbo.BDM_SendAddress addr ON a.CustID=addr.CustID AND a.SendAddr=addr.SendAddr AND a.LinkMan=addr.LinkMan
WHERE (ISNULL(a.CarNumberSts,'')='')

go

