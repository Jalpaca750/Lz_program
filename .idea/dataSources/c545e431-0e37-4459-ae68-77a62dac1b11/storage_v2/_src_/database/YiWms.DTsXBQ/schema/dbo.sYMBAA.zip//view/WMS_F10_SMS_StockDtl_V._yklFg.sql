/*==============================================================*/
/* View: WMS_F10_SMS_StockDtl_V                                 */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_SMS_StockDtl_V] as
SELECT a.stockId AS wmsStockId,b.stockNo AS wmsStock,b.billNo AS stockNo,a.contractId AS orderId,a.contractNo AS orderNo,
	w.warehouseNo AS warehouse,bi.f10Id AS itemId,a.locationNo AS location,ROUND(t.actQty/bi.pkgRatio,4) AS pkgQty,
	t.actQty AS SQty,a.price,ISNULL(t.actQty,0.0)*ISNULL(a.price,0.0) AS Amt,a.discount AS DiscRate,a.toOrder AS isSpecial,
	a.updPrice AS isEffect,0 AS taxFlag,0.0 AS IQty,0.0 AS IAmt,0.0 AS RQty,0.0 AS RZQty,0.0 AS PaidAmt,0.0 AS PAmt,
	a.isPromotion,a.isGift,bi.Integral,CAST(a.befPrice AS DECIMAL(18,6)) AS DiscountTemp,bi.pkgRatio,a.boneOrdId,
	a.ordDtlEx01 AS boneOrdNo,a.orderId AS wmsOrderId,a.remarks
FROM dbo.SAD_StockDetail a
	INNER JOIN dbo.SAD_Stock b ON a.stockNo=b.stockNo
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	INNER JOIN F10BMS.dbo.WMS_F10_Item_V bi ON a.itemId=bi.itemId
	LEFT JOIN (SELECT stockId,SUM(CASE isPackage WHEN 0 THEN pickQty WHEN 1 THEN pickQty*pkgRatio END) AS actQty 
				FROM WMS_PickingDetail
				GROUP BY stockId) t ON a.stockId=t.stockId
WHERE (b.taskState>=60)									--复核过后
	AND (b.thirdSyncFlag=0 OR b.thirdSyncFlag=2)		--待同步和同步出错的
	AND (b.orderType=10)								--销售订单
	AND (b.aFlag=0 OR b.aFlag=1)
UNION ALL
SELECT a.stockId AS wmsStockId,b.stockNo AS wmsStock,b.billNo AS stockNo,a.contractId AS orderId,a.contractNo AS orderNo,
	w.warehouseNo AS warehouse,bi.f10Id AS itemId,a.locationNo AS location,ROUND(a.stockQty/bi.pkgRatio,4) AS pkgQty,
	a.stockQty AS SQty,a.price,ISNULL(a.stockQty,0.0)*ISNULL(a.price,0.0) AS Amt,a.discount AS DiscRate,a.toOrder AS isSpecial,
	a.updPrice AS isEffect,0 AS taxFlag,0.0 AS IQty,0.0 AS IAmt,0.0 AS RQty,0.0 AS RZQty,0.0 AS PaidAmt,0.0 AS PAmt,
	a.isPromotion,a.isGift,bi.Integral,CAST(a.befPrice AS DECIMAL(18,6)) AS DiscountTemp,bi.pkgRatio,a.boneOrdId,
	a.ordDtlEx01 AS boneOrdNo, a.orderId AS wmsOrderId,a.remarks
FROM dbo.SAD_StockDetail a
	INNER JOIN dbo.SAD_Stock b ON a.stockNo=b.stockNo
	INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
	INNER JOIN F10BMS.dbo.WMS_F10_Item_V bi ON a.itemId=bi.itemId
WHERE (b.taskState>=60)									--复核过后
	AND (b.thirdSyncFlag=0 OR b.thirdSyncFlag=2)		--待同步和同步出错的
	AND (b.orderType=10)								--销售订单
	AND (b.aFlag=2 OR b.aFlag=3)
go

