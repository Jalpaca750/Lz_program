CREATE FUNCTION [dbo].[uf_GetFirstDifferent]
(
    @Warehouse VARCHAR(20)
)
RETURNS @result TABLE
(
    ItemNo VARCHAR(20),
    ItemName VARCHAR(200),
    ItemSpec VARCHAR(200),
    ColorName VARCHAR(100),
    UnitName VARCHAR(100),
    OnHandQty DECIMAL(18,6),
    WmsQty DECIMAL(18,6),
    DiffQty DECIMAL(18,6),
    PkgRatio INT
)
AS
BEGIN
    DECLARE @wmsStock TABLE(Warehouse VARCHAR(20),ItemID BIGINT,WmsQty DECIMAL(18,6),PkgRatio INT);
    INSERT INTO @wmsStock(Warehouse,ItemID,WmsQty,PkgRatio)
    SELECT b.warehouse,c.f10Id AS ItemID,SUM(a.actQty) AS WMSQty,c.pkgRatio
    FROM IMS_CheckDetail a
        INNER JOIN F10BMS.dbo.WMS_F10_Warehouse_V b ON a.warehouseId=b.warehouseId
        INNER JOIN F10BMS.dbo.WMS_F10_Item_V c ON a.itemId=c.itemId 
    GROUP BY b.warehouse,c.f10Id,c.pkgRatio;
    INSERT INTO @result(ItemNo,ItemName,ItemSpec,ColorName,UnitName,OnHandQty,WmsQty,DiffQty,PkgRatio)
    SELECT a.ItemNo,a.ItemName,a.ItemSpec,a.ColorName,a.UnitName,a.OnHandQty,b.WmsQty,
        ISNULL(b.WmsQty,0.0)-ISNULL(a.OnHandQty,0.0) AS diffQty,b.PkgRatio
    FROM F10BMS.dbo.IMS_Ledger_V a
        LEFT JOIN @wmsStock b ON a.warehouse=b.Warehouse AND a.ItemID=b.ItemID
    WHERE a.WareHouse=@Warehouse
        AND ISNULL(a.OnHandQty,0.0)-ISNULL(b.WmsQty,0.0)!=0.0;
    RETURN;
END
go

