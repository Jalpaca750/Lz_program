CREATE FUNCTION [dbo].[uf_GetDeliveryRate]
(
    @companyId VARCHAR(32),
    @startTime DATETIME,
    @endTime DATETIME
)    
RETURNS @result TABLE
(
    createDate DATE,                            --日期
    custCount INT DEFAULT 0,                    --当日客户数            
    stockCount INT DEFAULT 0,                   --当日出库单数
    deliveryCount INT DEFAULT 0,                --当日发货单数
    undeliveryCount INT DEFAULT 0,              --当日留仓单数
    avgCustBill DECIMAL(10,2),                  --客户平均出库单数
    deliveryRate DECIMAL(10,4),                 --发货率
    undeliveryRate DECIMAL(10,4),               --留仓率
    phyQty INT DEFAULT 0,                       --当日计件件数
    wgtQty INT DEFAULT 0,                       --当日重量件数
    avgStockQty DECIMAL(10,2),                  --平均每单件数
    billCust INT DEFAULT 0,                     --当日票据客户数
    billCount INT DEFAULT 0,                    --当日客户票据数
    billUndelivery INT DEFAULT 0,               --当日留仓票据数
    avgBillCount DECIMAL(10,2),                 --平均张数
    billUndeliveryRate  DECIMAL(10,4)           --留仓率
)
AS
BEGIN        
    DECLARE @tmpTable TABLE(
        createDate DATE,                                        --日期
        custCount DECIMAL(10,2) DEFAULT 0.0,                    --当日客户数            
        stockCount DECIMAL(10,2) DEFAULT 0.0,                   --当日出库单数
        deliveryCount DECIMAL(10,2) DEFAULT 0.0,                --当日发货单数
        undeliveryCount DECIMAL(10,2) DEFAULT 0,                --当日留仓单数
        phyQty DECIMAL(10,2) DEFAULT 0.0,                       --当日计件件数
        wgtQty DECIMAL(10,2) DEFAULT 0.0,                       --当日重量件数
        billCust DECIMAL(10,2) DEFAULT 0.0,                     --当日票据客户数
        billCount DECIMAL(10,2) DEFAULT 0.0,                    --当日客户票据数
        billUndelivery DECIMAL(10,2) DEFAULT 0.0                --当日留仓票据数
        )
    --统计当日出库单据
    INSERT INTO @tmpTable(createDate,stockCount) 
    SELECT CAST(createTime AS DATE),COUNT(*)
    FROM SAD_Stock 
    WHERE (companyId=@companyId)
        AND (createTime BETWEEN @startTime AND @endTime)
        AND (taskState>60)
        AND (aFlag!=2)
    GROUP BY CAST(createTime AS DATE)
    --统计当日发货单据
    INSERT INTO @tmpTable(createDate,custCount,deliveryCount,phyQty,wgtQty) 
    SELECT CAST(a.createTime AS DATE) AS createDate,COUNT(DISTINCT b.customerId) AS custCount,
        COUNT(*) AS deliveryCount,SUM(ISNULL(pkgQty,0.0)+ISNULL(lclQty,0.0)) AS phyQty,SUM(fclQty) AS wgtQty
    FROM dbo.WMS_Ship a
        INNER JOIN dbo.WMS_ShipDetail b ON a.shipNo=b.shipNo 
    WHERE (a.companyId=@companyId)
        AND (a.createTime BETWEEN @startTime AND @endTime)
        AND (ISNULL(fclQty,0.0)+ISNULL(pkgQty,0.0)+ISNULL(lclQty,0.0)>0.0) --排除直送单
    GROUP BY CAST(a.createTime AS DATE)
    --统计当日留仓单据数量
    INSERT INTO @tmpTable(createDate,undeliveryCount,billUndelivery)
    SELECT CAST(b.createTime AS DATE),
        SUM(CASE WHEN c.billType<60 THEN 1 ELSE 0 END),
        SUM(CASE WHEN c.billType>=60 THEN 1 ELSE 0 END)
    FROM dbo.TMS_WayBill a
        INNER JOIN dbo.TMS_WaySite b ON a.waybillId=b.waybillId
        INNER JOIN dbo.WMS_ShipDetail c ON a.shipId=c.shipId
    WHERE (a.companyId=@companyId) 
        AND (b.createTime BETWEEN @startTime AND @endTime)
        AND (b.wayState=80)
    GROUP BY CAST(b.createTime AS DATE)
    
    --统计当日送出票据
    INSERT INTO @tmpTable(createDate,billCust,billCount) 
    SELECT CAST(a.createTime AS DATE) AS createDate,COUNT(DISTINCT b.customerId),COUNT(*)
    FROM dbo.WMS_Ship a
        INNER JOIN dbo.WMS_ShipDetail b ON a.shipNo=b.shipNo 
    WHERE (a.companyId=@companyId)
        AND (a.createTime BETWEEN @startTime AND @endTime)
        AND ISNULL(fileQty,0)>0
    GROUP BY CAST(a.createTime AS DATE)
    
    INSERT INTO @result(createDate,custCount,stockCount,deliveryCount,undeliveryCount,phyQty,wgtQty,billCust,billCount,billUndelivery,
        avgCustBill,deliveryRate,undeliveryRate,avgStockQty,avgBillCount,billUndeliveryRate)
    SELECT createDate,custCount,stockCount,deliveryCount,undeliveryCount,phyQty,wgtQty,billCust,billCount,billUndelivery,
        CASE ISNULL(custCount,0.0) WHEN 0.0 THEN 0.0 ELSE deliveryCount/custCount END AS avgCustBill,
        CASE ISNULL(stockCount,0.0) WHEN 0.0 THEN 0.0 ELSE deliveryCount/stockCount END AS deliveryRate,
        CASE ISNULL(deliveryCount,0.0) WHEN 0.0 THEN 0.0 ELSE undeliveryCount/deliveryCount END AS undeliveryRate,
        CASE ISNULL(deliveryCount,0.0) WHEN 0.0 THEN 0.0 ELSE phyQty/deliveryCount END AS avgStockQty,
        CASE ISNULL(billCust,0.0) WHEN 0.0 THEN 0.0 ELSE billCount/billCust END AS avgBillCount,
        CASE ISNULL(billCount,0.0) WHEN 0.0 THEN 0.0 ELSE billUndelivery/billCount END AS billUndeliveryRate
    FROM (
        SELECT createDate,SUM(custCount) AS custCount,SUM(stockCount) AS stockCount,SUM(deliveryCount) AS deliveryCount,
            SUM(undeliveryCount) AS undeliveryCount,SUM(phyQty) AS phyQty,SUM(wgtQty) AS wgtQty,
            SUM(billCust) AS billCust,SUM(billCount) AS billCount,SUM(billUndelivery) AS billUndelivery
        FROM @tmpTable 
        GROUP BY createDate) t
    RETURN
END
go

