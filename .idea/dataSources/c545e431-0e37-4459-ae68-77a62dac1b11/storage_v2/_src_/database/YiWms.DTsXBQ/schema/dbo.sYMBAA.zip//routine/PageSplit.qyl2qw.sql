


CREATE  PROC [dbo].[PageSplit]
(
@tblName      varchar(1000),       -- 表名
@sortName	  varchar(255),      -- 字段名
@fldNames     varchar(MAX),      -- 返回字段
@PageSize     int = 10,           -- 页尺寸
@PageIndex    int,                -- 页码
@IsCount      bit = 1,            -- 是否返回记录总数。1：返回
@strWhere     nvarchar(MAX) = ''  -- 查询条件 (注意: 不要加 where)  
)
AS
declare @strSQL   nvarchar(MAX)
if @strWhere !=''
set @strWhere=' WHERE '+@strWhere
set @strSQL='SELECT * FROM (SELECT ROW_NUMBER() OVER (ORDER BY '+@sortName+') AS pos,'
+@fldNames+' FROM '+@tblName+''+@strWhere+') AS sp WHERE pos BETWEEN '
+str((@PageIndex-1)*@PageSize+1)+' AND '+str(@PageIndex*@PageSize)

--set @strSQL='SELECT * FROM (SELECT top  '+ str((@PageIndex-1)*@PageSize+@PageSize) +@fldNames
--+', ROW_NUMBER() OVER (order by '+@sortName+') AS pos FROM '
--+@tblName+''+@strWhere+' ) AS sp WHERE pos>'+str((@PageIndex-1)*@PageSize)

print @strSQL
exec (@strSQL)

if(@IsCount!=0)
begin
set   @strSQL='SELECT count(*) FROM '+@tblName+' '+@strWhere
--set @strSQL='SELECT max(pos) FROM (SELECT ROW_NUMBER() OVER (order by '+@sortName+') AS pos FROM '
--+@tblName+''+@strWhere+' ) AS sp '
exec (@strSQL)
return @@ROWCOUNT
END


go

