


/*==============================================================*/
/* View: BAS_ItemSku_V                                          */
/*==============================================================*/
--creator：     Frank
--create time:  2016-01-27
--Modify：      2016-02-29
--              Frank 2016-04-11日冗余了ECM_Item表大部分字段
--              Frank 2016-06-21 增加默认供应商，商品在第三方商城详情页地址
--              Frank 2017-03-09 增加是否异型，分拣模式0-自动;1-拆零;2-整件
CREATE view [dbo].[BAS_ItemSku_V] as
SELECT bi.itemId,sku.eId,bi.companyId,bi.itemNo,bi.itemCTitle,bi.itemETitle,bi.itemName,bi.itemSpec,bi.itemSpell,
    bi.sellingPoint,bi.barcode,bi.brandId,b.brandNo,b.brandCName,b.brandEName,b.pictureUrl AS brandUrl,
    bi.categoryId,cat.categoryNo,cat.categoryCName,cat.categoryEName,sku.colorId,bi.colorName,sku.sizeId,
    bi.sizeName,bi.packageId,bi.unitName,img.largeUrl, img.middleUrl, img.smallUrl, img.littleUrl,bi.itemLong, 
    bi.itemWidth,bi.itemHeight,bi.itemWeight,bi.itemVolume,bi.pkgUnit,bi.pkgRatio,bi.pkgBarcode,bi.netWeight,
    bi.pkgLong,bi.pkgWidth,bi.pkgHeight,bi.pkgWeight,bi.pkgVolume,bi.palletRatio,bi.allowExcess,bi.excessRate,
    bi.taxFlag,bi.taxRate,bi.webPrice,bi.marketPrice,bi.vipPrice,bi.retailPrice,bi.tradePrice,bi.salesPrice,
    bi.purPrice,bi.lastPurPrice,bi.minPrice,bi.maxPrice,bi.autoIncrease,bi.webIncrease,bi.vipIncrease,bi.retailIncrease,
    bi.tradeIncrease,bi.salesIncrease,bi.purLeadTime,bi.itemPara,bi.itemDescription,bi.inventoryMode,bi.isSafety,
    bi.safetyMonth,bi.safetyDays,bi.isIrregular,bi.pickingMode,bi.eaMaxQty,bi.eaMinQty,bi.csMaxQty,bi.csMinQty,bi.mixMaxQty,
    bi.mixMinQty,bi.onhandQty,bi.allocQty,bi.serviceMode,bi.isUnsalable,bi.isStop,bi.isVirtual,bi.allowDiscount,
    bi.usage,bi.itemState,bi.commodityId,bi.ownerId,bi.shopUrl,bi.supplierId,s.supplierNo,s.supplierName,s.shortName,
    s.logoUrl,s.isRecommend,bi.remarks,bi.isLocked,bi.lockerId,bi.lockedTime,bi.createTime,bi.creatorId,bi.editTime,
    bi.editorId,bi.isSelected
FROM dbo.BAS_Item AS bi LEFT OUTER JOIN 
      dbo.ECM_ItemSku AS sku ON bi.itemId = sku.itemId LEFT OUTER JOIN
      dbo.BAS_Category AS cat ON bi.categoryId = cat.categoryId LEFT OUTER JOIN
      dbo.BAS_Brand AS b ON bi.brandId = b.brandId LEFT OUTER JOIN
      dbo.BAS_Supplier_V AS s ON bi.supplierId=s.supplierId LEFT OUTER JOIN
      (SELECT eId,itemId,imageType,largeUrl,middleUrl,smallUrl,littleUrl
       FROM dbo.BAS_ItemImage
       WHERE (imageType = 1)) AS img ON bi.itemId = img.itemId

go

