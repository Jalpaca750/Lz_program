

--exec  up_SyncF10Basic
CREATE PROCEDURE [dbo].[up_SyncF10Basic]
AS
BEGIN
    DECLARE @companyId VARCHAR(32),			--公司Id
			@ownerId VARCHAR(32),			--业主Id
			@operatorId VARCHAR(32),		--操作员Id	
			@curTime DATETIME;				--操作时间
	DECLARE @syncNo VARCHAR(32),@syncId VARCHAR(32),@ErrMsg NVARCHAR(4000),@ErrSeverity INT;
    DECLARE @tmpTable TABLE(syncNo VARCHAR(32),syncId VARCHAR(32));
    --未定义接口直接退出
    --IF NOT EXISTS(SELECT * FROM dbo.SAM_Store WHERE appUrl='up_SyncF10Basic')
    --    RETURN;    
    --获取接口定义的公司与业主
    SELECT @companyId=companyId,@ownerId=ownerId FROM dbo.SAM_Store WHERE appUrl='up_SyncF10Basic';
    --管理员账号
    SELECT @operatorId=userId FROM dbo.SAM_User WHERE userNo='SYNC01'
    --当前时间
    SET @curTime=GETDATE();
	BEGIN TRY
		BEGIN TRANSACTION; 
        --锁定接口成功后开始同步
	    UPDATE dbo.SAM_Store SET isLocked=1 WHERE appUrl='up_SyncF10Basic' AND isLocked=0;
	    IF (@@ROWCOUNT>0)
	    BEGIN
	        --清除
            DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='up_SyncF10Basic';
            --1.同步基础代码(分类、部门、品牌、结算方式、配送线路)
            INSERT INTO @tmpTable(syncNo,syncId)
            SELECT CodeNo,CodeID
            FROM F10BMS.dbo.BDM_Code 
            WHERE Classify IN('FL02','FL04','FL09','FL13','FL30') AND syncFlag=0;
            WHILE (EXISTS(SELECT * FROM @tmpTable))    
            BEGIN
                SELECT TOP 1 @syncNo=syncNo,@syncId=syncId FROM @tmpTable ORDER BY syncId;
                EXEC F10BMS.dbo.sp_AfterCodeSaved @syncId;                
                DELETE FROM @tmpTable WHERE syncId=@syncId;
            END;
            --2.同步员工资料
            INSERT INTO @tmpTable(syncNo,syncId)
            SELECT EmployeeNo,EmployeeID
            FROM F10BMS.dbo.BDM_Employee 
            WHERE syncFlag=0;
            WHILE (EXISTS(SELECT * FROM @tmpTable))    
            BEGIN
                SELECT TOP 1 @syncNo=syncNo,@syncId=syncId FROM @tmpTable ORDER BY syncId;
                EXEC F10BMS.dbo.sp_AfterEmployeeSaved @syncNo;                
                DELETE FROM @tmpTable WHERE syncId=@syncId;
            END;
            --2.1同步登陆用户
            INSERT INTO @tmpTable(syncNo,syncId)
            SELECT EmployeeNo,EmployeeID
            FROM F10BMS.dbo.SAM_Operator_V  
            WHERE EmployeeNo NOT IN(SELECT userNo FROM dbo.SAM_User)
            WHILE (EXISTS(SELECT * FROM @tmpTable))    
            BEGIN
                SELECT TOP 1 @syncNo=syncNo,@syncId=syncId FROM @tmpTable ORDER BY syncId;
                EXEC F10BMS.dbo.sp_AfterUserSaved @syncId;                
                DELETE FROM @tmpTable WHERE syncId=@syncId;
            END;
            
            --3.同步商品资料
            INSERT INTO @tmpTable(syncNo,syncId)
            SELECT ItemNo,ItemID
            FROM F10BMS.dbo.BDM_ItemInfo 
            WHERE syncFlag=0;
            WHILE (EXISTS(SELECT * FROM @tmpTable))    
            BEGIN
                SELECT TOP 1 @syncNo=syncNo,@syncId=syncId FROM @tmpTable ORDER BY syncId;
                EXEC F10BMS.dbo.sp_AfterItemSaved @syncNo;                
                DELETE FROM @tmpTable WHERE syncId=@syncId;
            END;
            --4.同步客户资料
            INSERT INTO @tmpTable(syncNo,syncId)
            SELECT CustNo,CustID
            FROM F10BMS.dbo.BDM_Customer 
            WHERE syncFlag=0;
            WHILE (EXISTS(SELECT * FROM @tmpTable))    
            BEGIN
                SELECT TOP 1 @syncNo=syncNo,@syncId=syncId FROM @tmpTable ORDER BY syncId;
                EXEC F10BMS.dbo.sp_AfterCustomerSaved @syncNo;                
                DELETE FROM @tmpTable WHERE syncId=@syncId;
            END;
            --5.同步供应商资料
            INSERT INTO @tmpTable(syncNo,syncId)
            SELECT VendorNo,VendorID
            FROM F10BMS.dbo.BDM_Vendor 
            WHERE syncFlag=0;
            WHILE (EXISTS(SELECT * FROM @tmpTable))    
            BEGIN
                SELECT TOP 1 @syncNo=syncNo,@syncId=syncId FROM @tmpTable ORDER BY syncId;
                EXEC F10BMS.dbo.sp_AfterVendorSaved @syncNo;                
                DELETE FROM @tmpTable WHERE syncId=@syncId;
            END;
            --6.同步物流公司
            INSERT INTO @tmpTable(syncNo,syncId)
            SELECT logisticsCode,logisticsId
            FROM F10BMS.dbo.BAS_Logistics 
            WHERE syncFlag=0;
            WHILE (EXISTS(SELECT * FROM @tmpTable))    
            BEGIN
                SELECT TOP 1 @syncNo=syncNo,@syncId=syncId FROM @tmpTable ORDER BY syncId;
                EXEC F10BMS.dbo.sp_AfterLogisticsSaved @syncNo;                
                DELETE FROM @tmpTable WHERE syncId=@syncId;
            END;
        END;
        UPDATE dbo.SAM_Store SET isLocked=0 WHERE appUrl='up_SyncF10Basic' AND isLocked=1;
		COMMIT;
	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT>0)
			 ROLLBACK;
		--释放同步作业锁定
		UPDATE dbo.SAM_Store SET isLocked=0 WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10Basic';
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();	
		--写入同步错误日志	
		INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncF10Basic','YI_F10_TO_WMS_SYNC_ERROR',LEFT(@ErrMsg,2000),'','');
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END CATCH
END



go

