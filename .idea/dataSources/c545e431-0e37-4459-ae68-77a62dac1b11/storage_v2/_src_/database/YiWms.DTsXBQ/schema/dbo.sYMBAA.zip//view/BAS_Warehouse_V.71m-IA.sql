
/*==============================================================*/
/* View: BAS_Warehouse_V                                        */
/*==============================================================*/
--creator：        Frank
--create time：  2016-02-19
--modify:Frank 2016-09-22 增加WMS相关字段
--仓库代码视图
create view BAS_Warehouse_V as
SELECT w.warehouseId, w.warehouseNo, w.warehouseName, w.warehouseState, a1.areaName AS stateName, w.warehouseCity, 
      a2.areaName AS cityName, w.warehouseDistrict, a3.areaName AS districtName, w.warehouseAddress, w.zip,  
      ISNULL(a1.areaName,'') + ISNULL(a2.areaName,'') + ISNULL(a3.areaName,'') + w.warehouseAddress AS fullAddress,      
      w.contactName, w.contactTel, w.contactMobile, ISNULL(w.contactTel, '') + ' ' + ISNULL(w.contactMobile, '') AS fullTel,
      w.isFrozen, CASE w.isFrozen WHEN 1 THEN '是' ELSE '否' END as frozenName,      
      w.storage, CASE w.storage WHEN 0 THEN '残次品' WHEN 1 THEN '正常品' END AS storageName, 
      w.isPicking, CASE w.isPicking WHEN 1 THEN '是' ELSE '否' END AS pickingName,
      w.isPutaway, CASE w.isPutaway WHEN 1 THEN '是' ELSE '否' END AS putawayName,
      w.isReplenished,CASE w.isReplenished WHEN 1 THEN '是' ELSE '否' END AS replenishedName,
      w.useArea, CASE w.useArea WHEN 1 THEN '是' ELSE '否' END AS useAreaName,
      w.isDisable, CASE w.isDisable WHEN 1 THEN '是' ELSE '否' END AS disableName, 
      w.companyId, w.isLocked, w.lockerId,u3.userNick AS lockerName,CONVERT(VARCHAR(20),w.lockedTime,120) AS lockedTime,
      w.createTime, w.creatorId, u1.userNick AS creatorName,w.editTime, w.editorId, u2.userNick AS editorName, w.isSelected
FROM dbo.BAS_Warehouse AS w LEFT JOIN
      dbo.BAS_Area AS a1 ON w.warehouseState = a1.areaId LEFT JOIN
      dbo.BAS_Area AS a2 ON w.warehouseCity = a2.areaId LEFT JOIN
      dbo.BAS_Area AS a3 ON w.warehouseDistrict = a3.areaId LEFT JOIN 
      dbo.SAM_User u1 ON w.creatorId=u1.userId LEFT JOIN
      dbo.SAM_User u2 ON w.editorId=u2.userId LEFT JOIN
      dbo.SAM_User u3 ON w.lockerId=u3.userId
go

