
/*==============================================================*/
/* View: SAM_CompanyTempletDetail_V                             */
/*==============================================================*/
create view SAM_CompanyTempletDetail_V as
SELECT a.templetId,a.companyId,a.templetCode,b.templetName,a.formName,a.viewOrder,
    a.fieldCode,a.fieldName,a.controlName,a.controlType,a.allowEmpty,a.allowEdit,
    a.allowSort,a.allowFilter,a.allowDisplay,a.inputDataType,a.maxLenght,a.dataFormat,
    a.defaultValue,a.alignMode,a.colWidth,a.isEmpty,a.isEdit,a.isDisplay,a.isSort,
    a.isFilter,a.memo,a.isDisable,a.ver,a.isLocked,a.lockerId,u1.userNick AS lockerName,
    CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,a.creatorId,
    u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName
FROM dbo.SAM_CompanyTempletDetail a
    INNER JOIN dbo.SAM_Templet b ON a.templetCode=b.templetCode
    LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId
    LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId
    LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.editorId
go

