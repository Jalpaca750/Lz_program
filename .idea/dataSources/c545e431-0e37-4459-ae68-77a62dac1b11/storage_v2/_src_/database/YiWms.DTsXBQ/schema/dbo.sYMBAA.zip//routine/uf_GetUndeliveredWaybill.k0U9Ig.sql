CREATE FUNCTION [dbo].[uf_GetUndeliveredWaybill] 
(
	@companyId VARCHAR(32),
	@startTime DATETIME,
	@endTime DATETIME
)
RETURNS TABLE
RETURN(
	SELECT b.billType,CASE b.billType WHEN 10 THEN '销售出库单' 
									WHEN 20 THEN '调拨出库单' 
									WHEN 30 THEN '经营领用单' 
									WHEN 31 THEN '管理领用单' 
									WHEN 32 THEN '其他出库单'
									WHEN 40 THEN '赠品出库单' 
									WHEN 50 THEN '报损报废单'
									WHEN 60 THEN '销售退货单'
									WHEN 70 THEN '销售发票单'
									WHEN 80 THEN '销售收款单'
									WHEN 90 THEN '项目单' END billTypeName,b.waybillNo,b.wmsStockNo,
		a.typeId,t.typeName,a.reasonId,s.reasonDesc,u1.userNick AS deliveryName,p.partnerNo AS toCustomerNo,
		p.partnerName AS toCustomerName,b.toContacts,b.toPhone,b.lineId,l.lineCode,l.lineName,
		b.exField01,b.exField02,u2.userNick AS personName,b.exField03,b.exField04,b.exField05,a.createTime,b.waybillDate,
		b.billState,CASE b.billState WHEN 10 THEN '已揽件'
								   WHEN 20 THEN '运输中'
								   WHEN 30 THEN '派送中'
								   WHEN 40 THEN '再次派送'
								   WHEN 80 THEN '未送达'
								   WHEN 90 THEN '已妥投'
								   WHEN 99 THEN '已回单' END as billStateDesc,a.exField01 AS nextTime
	FROM dbo.TMS_WaySite a 
		INNER JOIN dbo.TMS_Reason s ON a.reasonId=s.reasonId
		INNER JOIN dbo.TMS_WayBill b ON a.waybillId=b.waybillId
		LEFT  JOIN dbo.BAS_Partner p ON b.toCustomerId=p.partnerId
		LEFT  JOIN dbo.BAS_AddressLine l ON b.lineId=l.lineId
		LEFT  JOIN dbo.TMS_ReasonType t ON a.typeId=t.typeId
		LEFT  JOIN dbo.SAM_User u1 ON a.wayUserId=u1.userId
		LEFT  JOIN dbo.SAM_User u2 ON a.exField02=u2.userId
	WHERE (a.companyId=@companyId)
		AND (a.wayState=80)
		AND (a.createTime BETWEEN @startTime AND @endTime) 
)
go

