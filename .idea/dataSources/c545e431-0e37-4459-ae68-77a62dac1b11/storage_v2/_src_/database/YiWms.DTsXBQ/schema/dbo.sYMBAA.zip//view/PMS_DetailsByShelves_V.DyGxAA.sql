
/*==============================================================*/
/* View: PMS_StockDetail_V                                      */
/*==============================================================*/
--creator：        WJ
--create time：  2016-12-24
--采购入库明细视图
create view [dbo].[PMS_DetailsByShelves_V] as
SELECT dtl.stockId, dtl.stockNo, b.billNo, b.createtime, b.supplierId, b.ioType, dtl.ioState, dtl.orderId, 
      dtl.orderNo, dtl.orderBillNo, dtl.companyId, dtl.warehouseId, dtl.viewOrder, 
      CASE ISNULL(bin.isFixed,0) WHEN 1 THEN 1 ELSE (CASE ISNULL(s.onhandQty,0.0) WHEN 0.0 THEN 0 ELSE 1 END) END AS isFixed, 
      dtl.eId, dtl.itemId, sku.itemNo, sku.itemCTitle, sku.itemETitle, sku.itemName, sku.sellingPoint, 
      sku.itemSpell, sku.barcode, sku.brandId, sku.brandCName, sku.brandEName, sku.categoryId, sku.categoryNo, 
      sku.categoryCName, sku.categoryEName, sku.colorName, sku.sizeName, sku.unitName, sku.pkgUnit, sku.pkgRatio, 
      s.onhandQty, dtl.unitId, dtl.receiveQty, ISNULL(o.orderQty, 0.0) - ISNULL(o.receiveQty, 0.0) AS residueQty, 
      dtl.pkgQty, dtl.bulkQty, b.taxFlag, dtl.befPrice, dtl.discount, dtl.discountFee, dtl.price, dtl.taxrate, 
      dtl.fee, dtl.taxFee, dtl.totalFee, sku.purPrice, sku.lastPurPrice, sku.maxPrice, sku.inventoryMode, sku.isUnsalable, 
      sku.isStop, sku.isVirtual, dtl.returnQty, ISNULL(dtl.receiveQty,0.0)-ISNULL(dtl.returnQty,0.0) AS returnAbleQty, 
      dtl.invoiceQty, ISNULL(dtl.receiveQty,0.0)-ISNULL(dtl.invoiceQty,0.0) AS invableQty, 
      dtl.invoiceFee, ISNULL(dtl.totalFee,0.0)-ISNULL(dtl.invoiceFee,0.0) AS invableFee,  
      dtl.payQty, dtl.payFee, dtl.toOrder, dtl.updPrice, dtl.isTemporary, dtl.isEmergency, 
      dtl.isPromotion, dtl.buyerId, dtl.handlerId, dtl.deptId, dtl.planId, dtl.planNo,o.planBillNo, 
      dtl.sdOrderId, dtl.sdOrderNo, o.sdBillNo, dtl.contractId, dtl.contractNo, dtl.remarks, dtl.isSelected
      ,sts.stateName,bw.warehouseName,
	   dbo.uf_GetPutawayLocation(b.companyId,sku.ownerId,b.warehouseId,dtl.itemId,'',dtl.receiveQty,ib.expiryDate,'10','') AS locationNo,
       dtl.lotNo
FROM PMS_StockDetail AS dtl 
	  INNER JOIN dbo.PMS_Stock AS b ON b.stockNo = dtl.stockNo 
	  INNER JOIN dbo.BAS_ItemSku_V AS sku ON  dtl.itemId = sku.itemId 
	  LEFT OUTER JOIN dbo.PMS_OrderDetail AS o ON dtl.orderId = o.orderId  
      LEFT JOIN BAS_Warehouse AS bw ON dtl.warehouseId=bw.warehouseId
      LEFT OUTER JOIN dbo.BAS_Location bin ON dtl.companyId =bin.companyId AND dtl.warehouseId=bin.warehouseId AND ISNULL(dtl.locationNo,'')=ISNULL(bin.locationNo,'') 
      LEFT OUTER JOIN dbo.IMS_Stock AS s ON dtl.companyId = s.companyId AND dtl.warehouseId = s.warehouseId AND ISNULL(dtl.lotNo,'') = ISNULL(s.lotNo,'') AND ISNULL(dtl.locationNo,'') = ISNULL(s.locationNo,'') AND dtl.eId = s.eId AND dtl.itemId = s.itemId
	  LEFT JOIN IMS_Batch AS ib ON dtl.lotNo=ib.lotNo AND dtl.companyId=ib.companyId
	  LEFT JOIN 
      (SELECT billState, stateName
       FROM dbo.SAM_BillState
       WHERE (billCode = 'PMS_STOCK')) AS sts ON isnull(dtl.ioState,2) = sts.billState




go

