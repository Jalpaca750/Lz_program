/*==============================================================*/
/* View: SAD_Return_V                                           */
/*==============================================================*/
--creator：        Frank
--create time：  2016-03-15日整理 
--销售退货单视图
CREATE view [dbo].[SAD_Return_V] as
SELECT r.returnNo,r.billNo,r.companyId,corp.companyName,r.ownerId,o.ownerNo,o.ownerName,r.returnDate,r.ioType, 
	'销售退货单' AS ioTypeDesc,r.warehouseId,w.warehouseNo,w.warehouseName,r.customerId,c.customerNo,c.customerName, 
	c.shortName,c.customerSpell,r.receiverState,a1.areaName AS stateName,r.receiverCity,a2.areaName AS cityName,
	r.receiverDistrict,a3.areaName AS districtName,r.receiverAddress, 
	ISNULL(a1.areaName,'') + ISNULL(a2.areaName,'') + ISNULL(a3.areaName,'') + r.receiverAddress AS fullAddress,
	r.receiverName,r.receiverTel,r.receiverMobile,ISNULL(r.receiverMobile,'') + ' ' + ISNULL(r.receiverTel,'') AS fullTel,
	r.groupId,g.groupName,r.lineId,l.lineName,r.currencyId,r.exchangeRate,r.taxFlag,r.ioState,r.apState,
	CASE r.ioState WHEN 0 THEN '已作废' WHEN 10 THEN '待审核' WHEN 20 THEN '待上架' WHEN 25 THEN '部分上架' WHEN 30 THEN '已上架' END AS ioStateName,
	r.totalFee,r.returnFee,r.postFee,ISNULL(r.totalFee,0.0)-ISNULL(dtl.invoiceFee,0.0) AS invableFee,
	r.reason,r.billSource,r.salesId,e1.employeeName AS salesName,r.buyerId,r.organizeId, 
	r.orderType,CASE r.orderType WHEN 10 THEN '销售退货' 
								WHEN 20 THEN '调拨申请' 
								WHEN 30 THEN '经营退货' 
								WHEN 31 THEN '管理退货' 
								WHEN 40 THEN '赠品退货' 
								WHEN 50 THEN '报损报废' END AS orderTypeName,
	r.isChange,CASE ISNULL(r.isChange,0) WHEN 0 THEN '换货' ELSE '退货' END AS isChangeName,
	r.logisticsType,CASE ISNULL(logisticsType,1) WHEN 1 THEN '上门取货' ELSE '自行寄回' END as logisticsTypeDesc, 
	r.deliveryId, e2.employeeName AS deliveryName,CONVERT(VARCHAR(20),r.deliveryTime,120) AS deliveryTime,
	r.expressNo, r.logisticsId,lg.logisticsName,r.handlerId,e3.employeeName AS handlerName,r.handlerTime,
	r.deptId,d.deptNo,d.deptName,CONVERT(VARCHAR(20),r.dealTime,120) AS dealTime,r.dealReason,
	r.thirdPartyNo,CONVERT(VARCHAR(20),r.thirdSyncTime,120) AS thirdSyncTime,r.thirdSyncFlag, 
    CASE r.thirdSyncFlag WHEN 0 THEN '待同步' WHEN -1 THEN '无需同步' WHEN 1 THEN '已同步' WHEN 2 THEN '同步失败' END syncFlagDesc,
    r.printNum,r.printId,r.shipState,r.memo,r.createtime,r.creatorId,u1.userNick AS creatorName,r.auditorId,
	u2.userNick AS auditorName,CONVERT(VARCHAR(20),r.auditTime,120) AS auditTime,r.isLocked,r.lockerId,
	u4.userNick AS lockerName,CONVERT(VARCHAR(20),r.lockedTime,120) AS lockedTime,r.editTime,r.editorId, 
	u3.userNick AS editorName,r.isSelected
FROM dbo.SAD_Return AS r 
	INNER JOIN dbo.SAM_Company AS corp ON r.companyId = corp.companyId 
	INNER JOIN(SELECT returnNo,SUM(ISNULL(invoiceFee,0.0)) AS invoiceFee
				FROM dbo.SAD_ReturnDetail
				GROUP BY returnNo) dtl ON r.returnNo=dtl.returnNo 
	INNER JOIN dbo.BAS_Customer_V AS c ON r.customerId = c.customerId 
	LEFT JOIN dbo.BAS_Owner_V o ON r.ownerId=o.ownerId 
	LEFT JOIN dbo.BAS_Warehouse AS w ON r.warehouseId = w.warehouseId 
	LEFT JOIN dbo.BAS_Area AS a1 ON r.receiverState = a1.areaId 
	LEFT JOIN dbo.BAS_Area AS a2 ON r.receiverCity = a2.areaId 
	LEFT JOIN dbo.BAS_Area AS a3 ON r.receiverDistrict = a3.areaId 
	LEFT JOIN dbo.BAS_AddressLine AS l ON r.lineId = l.lineId 
	LEFT JOIN dbo.BAS_AddressGroup AS g ON r.groupId = g.groupId 
	LEFT JOIN dbo.BAS_Logistics AS lg ON r.logisticsId = lg.logisticsId 
	LEFT JOIN dbo.BAS_Department AS d ON r.deptId = d.deptId 
	LEFT JOIN dbo.BAS_Employee AS e1 ON r.salesId = e1.employeeId 
	LEFT JOIN dbo.BAS_Employee AS e2 ON r.deliveryId = e2.employeeId 
	LEFT JOIN dbo.BAS_Employee AS e3 ON r.handlerId = e3.employeeId 
	LEFT JOIN dbo.SAM_User AS u1 ON r.creatorId = u1.userId 
	LEFT JOIN dbo.SAM_User AS u2 ON r.auditorId = u2.userId 
	LEFT JOIN dbo.SAM_User AS u3 ON r.editorId = u3.userId 
	LEFT JOIN dbo.SAM_User AS u4 ON r.lockerId=u4.userId
go

