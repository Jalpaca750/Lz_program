
 
/*==============================================================*/
/* View: API_CTRK_QX_HZ 采购退货取消        Script Date: 07/13/2020 14:42:54  zdy                                         */
/*==============================================================*/
CREATE view [dbo].[API_CTRK_QX_HZ] as
SELECT a.returnNo AS PKID,a.ownerId,w.warehouseId,a.companyId,o.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,a.thirdPartyNo AS SHANGJ_DANJ_NO,c.partnerId AS supplierId,c.partnerNo AS CARDCODE,
	CONVERT(VARCHAR(10),a.auditTime,23) AS docdate,w.warehouseNo AS whNo,
	CASE WHEN LEN(ISNULL(a.reason,''))>0 THEN '退货原因:'+a.reason+',备注:'+a.memo else a.memo END  AS comments,u.userNo AS U_opcode,u.userNick AS U_OPNAME,0 AS discprcnt,
	'采购退货'  AS orderTypeName,11 AS orderType,
	thirdSyncFlag AS SC_FLG,a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5
FROM dbo.PMS_Return a INNER JOIN
      dbo.BAS_Partner c   ON a.supplierId=c.partnerId INNER JOIN
      dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId LEFT JOIN
      dbo.BAS_Owner_V o ON a.ownerId=o.ownerId LEFT JOIN 
      dbo.SAM_User u ON a.creatorId=u.userId 
WHERE (a.ioState=0) AND (a.thirdSyncFlag=0 OR a.thirdSyncFlag=2)

go

