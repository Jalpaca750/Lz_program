
/*==============================================================*/
/* View: SAD_Order_V                                            */
/*==============================================================*/
create view SAD_Order_V as
SELECT a.orderNo,a.companyId,a.ownerId,o.ownerNo,o.ownerName,o.shortName AS ownerShortName,a.billNo,a.createTime,
	a.orderDate,a.customerId,b.customerNo,b.customerName,a.receiverState,a1.areaName AS receiverStateName,
	a.receiverCity,a2.areaName AS receiverCityName,a.receiverDistrict,a3.areaName AS receiverDistrictName,a.receiverAddress,
	ISNULL(a1.areaName,'')+ISNULL(a2.areaName,'')+ISNULL(a3.areaName,'')+ISNULL(a.receiverAddress,'') AS fullAddress,
	a.addressId,a.lineId,al.lineName,a.groupId,ag.groupName,a.receiverName,a.receiverTel,a.receiverMobile,
	LTRIM(ISNULL(a.receiverMobile,'') + ' ' + ISNULL(a.receiverTel,'')) AS fullTel,a.warehouseId,w.warehouseNo,
	w.warehouseName,a.orderType,CASE a.orderType WHEN 10 THEN '普通订单' 
                                                 WHEN 20 THEN '调拨申请' 
                                                 WHEN 30 THEN '经营领用' 
                                                 WHEN 31 THEN '管理领用' 
                                                 WHEN 32 THEN '其他出库'
                                                 WHEN 40 THEN '赠品出库' 
                                                 WHEN 50 THEN '报损报废' END AS orderTypeDesc,a.isTogether,
	CASE a.isTogether WHEN 1 THEN '货齐一起送' ELSE '有货先送' END AS isTogetherName,a.distributeId,
	CONVERT(VARCHAR(10),a.shipDate,23) AS shipDate,a.shipTime,a.payMode,a.settlementId,a.invoiceAlone,a.invoiceTypeName,
	a.invoiceFlag,a.invoiceCompany,a.invoiceAddress,a.invoiceTel,a.invoiceTax,a.invoiceAccount,a.invoiceBank,
	a.currencyId,a.exchangeRate,a.taxFlag,a.sdState,CASE a.sdState WHEN 0 THEN '已关闭' 
                                                                   WHEN 10 THEN '待审核'  
                                                                   WHEN 15 THEN '已终止' 
                                                                   WHEN 20 THEN '已审核' 
                                                                   WHEN 25 THEN '部分下达' 
                                                                   WHEN 30  THEN '全部下达'  END AS sdStateName,
	a.arState,CASE a.arState WHEN 1 THEN '是' ELSE '否' END AS arStateName,a.taskState,a.totalFee,a.discount,
	ISNULL(a.totalFee,0.0)-ISNULL(a.totalDiscount,0.0)+ISNULL(a.postFee,0.0) + ISNULL(a.serviceFee,0.0) AS arFee,
	a.totalDiscount,a.postFee,a.serviceFee,a.payFee,a.aFlag,a.aOrderNo,a.orderSource,
	CASE a.aFlag WHEN 0 THEN '订单' WHEN 1 THEN '有A单' WHEN 2 THEN 'A单' WHEN 3 THEN '直送订单' END AS aFlagDesc,
	CASE a.orderSource WHEN 1 THEN '淘宝' WHEN 2 THEN '京东' WHEN 8 THEN 'SAP' WHEN 9 THEN 'BONE' WHEN 10 THEN 'F10' END AS orderSourceName,
	a.buyerId,a.organizeId,a.poNo,a.salesId,ISNULL(e1.employeeName,a.salesId) AS salesName,a.handlerId,
	ISNULL(e2.employeeName,a.handlerId) AS handlerName,a.deptId,ISNULL(d.deptName,a.deptId) AS deptName,a.buyerMessage,
	a.thirdSyncFlag,CASE a.thirdSyncFlag WHEN 0 THEN '待同步' WHEN 1 THEN '已同步' WHEN 2 THEN '同步出错' end SyncFlag,
	CONVERT(VARCHAR(20),a.thirdSyncTime,120) AS thirdSyncTime,a.msgText,a.ordField1,a.ordField2,a.ordField3,a.ordField4,
	a.ordField5,a.ordField6,a.ordField7,a.ordField8,a.ordField9,a.memo,a.flag,a.expressNo,a.logisticsId,l.logisticsCode,
	ISNULL(l.logisticsName,a.logisticsId) AS logisticsName,a.logisticsFee,a.isLocked,a.lockerId,u1.userNick AS lockerName,
	CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.creatorId,u2.userNick AS creatorName,a.auditorId,u4.userNick AS auditorName,
	CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,a.editTime,a.editorId,u3.userNick AS editorName,a.isSelected
FROM dbo.SAD_Order a 
	INNER JOIN(SELECT x.orderNo,SUM(x.totalFee) AS totalFee
			   FROM dbo.SAD_OrderDetail x
			   GROUP BY x.orderNo) t ON a.orderNo=t.orderNo 
	INNER JOIN dbo.BAS_Owner_V o ON a.ownerId=o.ownerId 
	INNER JOIN dbo.BAS_Customer_V b ON a.customerId=b.customerId 
	LEFT JOIN dbo.BAS_Area a1 ON a.receiverState=a1.areaId 
	LEFT JOIN dbo.BAS_Area a2 ON a.receiverCity=a2.areaId 
	LEFT JOIN dbo.BAS_Area a3 ON a.receiverDistrict=a3.areaId 
	LEFT JOIN dbo.BAS_AddressLine al ON a.lineId=al.lineId 
	LEFT JOIN dbo.BAS_AddressGroup ag ON a.groupId=ag.groupId 
	LEFT JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId 
	LEFT JOIN dbo.BAS_Logistics l ON a.logisticsId=l.logisticsId 
	LEFT JOIN dbo.BAS_Employee e1 ON a.salesId=e1.employeeId
	LEFT JOIN dbo.BAS_Employee e2 ON a.handlerId=e2.employeeId
	LEFT JOIN dbo.BAS_Department d ON a.deptId=d.deptId
	LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId 
	LEFT JOIN dbo.SAM_User u4 ON a.auditorId=u4.userId
go

