-- =============================================
-- Author:		<Frank.He>
-- Create date: <2016-11-04>
-- Description:	<根据市/区、区/县、地址获取物流公司>
-- =============================================
CREATE FUNCTION uf_GetLogistics 
(
    @companyId VARCHAR(32),
	@cityId VARCHAR(32),
	@districtId VARCHAR(32),
	@address VARCHAR(100)
)
RETURNS VARCHAR(32)
AS
BEGIN
	DECLARE @areaId VARCHAR(32),
	        @exKey VARCHAR(1000),
	        @logisticsId VARCHAR(32),
	        @exLogisticsId VARCHAR(32),
	        @Result VARCHAR(32)
	IF (ISNULL(@districtId,'')='')
		SET @areaId=@cityId;
	ELSE
	    SET @areaId=@districtId
	--获取物流策略设置中的数据
	SELECT @logisticsId=logisticsId,@exLogisticsId=exLogisticsId,@exKey=addressKey
	FROM BAS_AreaLogistics
	WHERE areaId=@areaId AND companyId=@companyId
    --
    IF ISNULL(@logisticsId,'')=''
		SET @Result='';
	ELSE
		BEGIN
		    --如果地址中有默认快递不到的关键字，则取替代物流
			IF (CHARINDEX(@exKey,@address)>0)    
				SET @Result=ISNULL(@exLogisticsId,'')
			ELSE
				SET @Result=ISNULL(@logisticsId,'')		
		END
	--返回物流公司Id	
	RETURN @Result;
END
go

