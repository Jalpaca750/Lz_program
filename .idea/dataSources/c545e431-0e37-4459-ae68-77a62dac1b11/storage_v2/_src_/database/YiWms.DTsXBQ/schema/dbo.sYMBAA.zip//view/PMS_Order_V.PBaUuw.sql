



/*==============================================================*/
/* View: PMS_Order_V                                            */
/*==============================================================*/
--creator：        WANG_Jun
--create time：  2016-11-30
--@修改人  张东彦
--@修改日期内容  2016-12-03 15:10  加上 ownerName,postatename   
--Modify:   2017-01-16 Frank 重新整理
--			2017-10-23 Frank 增加整单折扣，整单折扣率，自定义1~自定义5,去掉isMatch匹配
--采购订单列表
CREATE view [dbo].[PMS_Order_V] 
AS
SELECT a.orderNo,a.billNo,a.orderDate,a.companyId,c.companyName,a.ownerId,o.ownerNo,o.ownerName,
	o.shortName AS ownerShortName,a.supplierId,s.partnerNo AS supplierNo,s.partnerName AS supplierName,
	s.shortName,s.partnerSpell AS supplierSpell,CONVERT(VARCHAR(10),a.requireDate,23) AS requireDate,
	a.requireTime,a.deptId,d.deptNo,d.deptName,a.handlerId,e1.employeeName AS handlerName,a.warehouseId,
	w.warehouseName,a.distributeId,a.buyerId,e2.employeeName AS buyerName,a.currencyId,a.exchangeRate,
	a.taxFlag,a.poState,CASE a.poState WHEN -3 THEN '已终止'
	                                   WHEN -2 THEN '拒绝' 
                                       WHEN -1 THEN '待审批' 
                                       WHEN 0 THEN '交易关闭' 
                                       WHEN 1 THEN '待审核'
                                       WHEN 2 THEN '已审核'
                                       WHEN 3 THEN '部分入库'                                                         
                                       WHEN 4 THEN '完全入库' END AS poStateName,a.apState,
	a.orderSource,CASE a.orderSource WHEN 11 THEN '普通订单' 
	                                 WHEN 12 THEN '应急订单' 
                                     WHEN 13 THEN '临时采购'
                                     WHEN 14 THEN '转场订单' 
                                     WHEN 21 THEN '调拨入库单' 
                                     WHEN 31 THEN '赠品入库单'
                                     WHEN 41 THEN '其他入库单' END AS orderSourceDesc,
	a.totalFee,a.discount,a.discountFee,CONVERT(VARCHAR(20),a.auditTime,120) AS auditTime,a.auditorId,
	u1.userNick AS auditorName,a.poNo,a.ordField1,a.ordField2,a.ordField3,a.ordField4,a.ordField5,
	a.printNum,a.printId,u5.userNick AS printMan,CONVERT(VARCHAR(20),a.printTime,120) AS printTime,
	a.thirdSyncFlag,CONVERT(VARCHAR(20),a.thirdSyncTime,120) AS thirdSyncTime,a.shutdownExplain,a.msgText,
	a.memo,a.isLocked,a.lockerId,u2.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
	a.createTime,a.creatorId,ISNULL(u3.userNick,a.creatorId) AS creatorName,a.editTime,a.editorId,
	u4.userNick AS editorName,a.isSelected
FROM dbo.PMS_Order a 
	INNER JOIN dbo.SAM_Company c ON a.companyId=c.companyId 
	LEFT JOIN dbo.BAS_Owner_V o ON a.ownerId=o.ownerId 
	LEFT JOIN dbo.BAS_Partner s ON a.supplierId=s.partnerId 
	LEFT JOIN dbo.BAS_Department d ON a.deptId=d.deptId 
	LEFT JOIN dbo.BAS_Employee e1 ON a.handlerId=e1.employeeId 
	LEFT JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId 
	LEFT JOIN dbo.BAS_Employee e2 ON a.buyerId=e2.employeeId 
	LEFT JOIN dbo.SAM_User u1 ON a.auditorId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON a.lockerId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON a.creatorId=u3.userId 
	LEFT JOIN dbo.SAM_User u4 ON a.editorId=u4.userId 
	LEFT JOIN dbo.SAM_User u5 ON a.printId=u5.userId

go

