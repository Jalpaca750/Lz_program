
/*==============================================================*/
/* View: BAS_LocationVolumn_V                                   */
/*==============================================================*/
create view BAS_LocationVolumn_V as
SELECT a.warehouseId,a.LocationWay,a.LocationRow,a.locationLayer,MIN(a.maxVolume) AS maxVolume,
    SUM(b.onhandVolume) AS onhandVolume,SUM(b.onwayVolume) AS onwayVolume
FROM BAS_Location a
    LEFT JOIN(SELECT x.warehouseId,x.locationNo,
                   ISNULL(x.onhandQty,0.0)*ISNULL(y.itemVolume,0.0) AS onhandVolume,
                   ISNULL(x.onWayQty,0.0)*ISNULL(y.itemVolume,0.0) AS onwayVolume
              FROM IMS_Stock x
                   INNER JOIN BAS_Item y ON x.itemId=y.itemId
              ) b ON a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
GROUP BY a.warehouseId,a.LocationWay,a.LocationRow,a.locationLayer
go

