


/*==============================================================*/
/* View: WMS_F10_IMS_CheckDtl_V                                 */
/*==============================================================*/
CREATE PROCEDURE [dbo].[up_SyncProcessToF10V1]
AS
BEGIN
	DECLARE @companyId VARCHAR(32),			    --公司Id
			@ownerId VARCHAR(32),			    --业主Id
			@operatorId VARCHAR(32),		    --操作员Id	
			@curTime DATETIME;				    --操作时间
	DECLARE @wmsStock VARCHAR(32),				--WMS中的入出库单号
			@wmsOrder VARCHAR(32),				--WMS中入出库单No
			@wmsBillNo VARCHAR(32),				--WMS中入出库单编号
			@stockNo VARCHAR(20),				--F10入出库单编号
			@createDate VARCHAR(10),			--F10制单日期
			@DeptNo VARCHAR(32),				--F10分部Id
			@warehouse VARCHAR(32),				--F10入出库仓库
			@warehouseId VARCHAR(32),			--WMS仓库Id
			@orderType INT,						--WMS中单据类型
			@billSts VARCHAR(2),				--F10入出库单状态,同步前默认10
			@auditTime VARCHAR(10),				--F10审核日期
			@auditId BIGINT,					--F10审核人
			@printNum INT,						--F10打印次数
			@printerId BIGINT,					--F10打印人
			@RecieverId BIGINT,					--收货人
			@RecieverTime VARCHAR(20),			--收货时间
			@creatorId BIGINT,					--F10制单人
			@orderNo VARCHAR(32),				--F10订单No,调拨申请单No,F10赠品入库单编号，其他入库单编号
			@memo VARCHAR(1000),				--说明文字
			@remarks VARCHAR(2000)				--F10备注
	DECLARE @VendorId BIGINT,					--F10供应商Id
			@SendNo VARCHAR(40),				--供应商送货单号
			@totalWeight DECIMAL(10,4),         --总重量
			@postFee DECIMAL(18,6);             --运费
	DECLARE @CustId BIGINT,						--F10客户Id
			@SendAddr VARCHAR(200),				--F10送货地址
			@LinkMan VARCHAR(40),				--F10收货人
			@Phone VARCHAR(80),					--F10收货人电话
			@SendDate VARCHAR(10),				--F10发货日期
			@SendTime VARCHAR(10),				--F10发货时间
			@SendId VARCHAR(32),				--F10结算方式;
			@SalesId BIGINT,					--F10销售员
			@aFlag INT,							--A单标识
			@aStockNo VARCHAR(32),				--A原始编号
			@orderBillNo VARCHAR(32),			--订单编号
			@orderSts VARCHAR(2),				--F10订单状态
			@boneOrdNo VARCHAR(32),				--VIP平台订单号
			@bonePkgId VARCHAR(32),				--VIP平台子订单号
			@aBillNo VARCHAR(32)				--A单原始单据编号			
	DECLARE @DBPriceMode VARCHAR(1),			--调拨出库单单价:P,P-参考进价;R,R-零售价;L,L-最近调拨价
			@DeptNo_O VARCHAR(20),				--F10出库分部
			@DeptNo_I VARCHAR(20),				--F10入库分部
			@logisticsId VARCHAR(32);           --物流公司Id
	DECLARE @CarNumberSts VARCHAR(20),@F10_LotNo VARCHAR(20);
	DECLARE @tmpStock TABLE(wmsOrder VARCHAR(32),wmsBillNo VARCHAR(32),stockNo VARCHAR(32),createDate VARCHAR(10),warehouse VARCHAR(32),deptNo VARCHAR(32),deptNo_O VARCHAR(32),deptNo_I VARCHAR(32),vendorID BIGINT,sendNo VARCHAR(32),orderType INT,BillSts CHAR(2),auditTime VARCHAR(10),auditId BIGINT,printNum INT,printerId BIGINT,printTime DATETIME,RecieverId BIGINT,RecieverTime DATETIME,creatorId BIGINT,orderNo VARCHAR(32),remarks VARCHAR(2000))
	DECLARE @tmpSales TABLE(wmsStock VARCHAR(32),stockNo VARCHAR(32),viewOrder INT IDENTITY(1,1),aFlag INT,aStockNo VARCHAR(32),orderBillNo varchar(32),boneOrdNo VARCHAR(32));
	DECLARE @tmpDetail TABLE(wmsStockId VARCHAR(32),wmsStock VARCHAR(32),stockNo VARCHAR(20),OrderId BIGINT,OrderNo VARCHAR(20),Warehouse VARCHAR(20),ItemID BIGINT,location VARCHAR(20),pkgQty DECIMAL(18,6),SQty DECIMAL(18,6),Price DECIMAL(18,6),Amt DECIMAL(18,6),ZQty DECIMAL(18,6),DiscRate DECIMAL(18,6),IsSpecial INT,IsEffect INT,taxFlag INT,PaidAmt DECIMAL(18,6),IsPromotion INT,isGift INT,DiscountTemp DECIMAL(18,6),PkgRatio INT,Integral DECIMAL(18,6),boneOrdId VARCHAR(32),boneOrdNo VARCHAR(32),wmsOrderId VARCHAR(32),remarks VARCHAR(1000));
    DECLARE @ErrMsg NVARCHAR(1000),@Errors BIGINT,@BillTypeDesc VARCHAR(40);	
    
    SET @curTime=GETDATE();
	--固定公司Id,业主Id,仓库Id和当前时间
	SELECT @companyId=companyId,@ownerId=ownerId,@operatorId=IOperatorId,@DBPriceMode=DBPriceMode FROM F10BMS.dbo.SYS_Config;
	
	----锁定时间太长自动解锁----
	UPDATE SAM_Store SET isLocked = 0 WHERE companyId=@companyId AND ownerId=@ownerId  and  DATEADD(mi,5, lockedTime) < GETDATE() AND appUrl='up_SyncProcessToF10' AND isLocked=1;

	
	--接口未启动直接退出（控制作业）
	IF EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncProcessToF10' AND isDisable=1)
		RETURN;
	--接口正在执行中直接退出(控制作业）
	IF EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncProcessToF10' AND isLocked=1)
		RETURN;
    --清除同步错误日志
	DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode='up_SyncProcessToF10';
    --开始同步操作
    UPDATE dbo.SAM_Store SET isLocked=1,lockedTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncProcessToF10'; 
	IF @@ROWCOUNT>0
	BEGIN
		--1.同步采购入库单
		--thirdSyncFlag:0-待同步;2-同步错误;1-同步成功;-1不需要同步
		INSERT INTO @tmpStock(wmsOrder,wmsBillNo,stockNo,createDate,warehouse,deptNo,vendorID,sendNo,orderType,
			BillSts,auditTime,auditId,printNum,printerId,printTime,RecieverId,RecieverTime,creatorId,orderNo,remarks)
		SELECT wmsOrder,wmsBillNo,stockNo,createDate,warehouse,deptNo,vendorID,sendNo,orderType,BillSts,auditTime,
			auditId,printNum,printerId,printTime,RecieverId,RecieverTime,creatorId,orderNo,remarks
		FROM dbo.WMS_F10_PMS_Stock_V
		WHERE (companyId=@companyId) AND (ownerId=@ownerId);
		IF (EXISTS(SELECT 1 FROM @tmpStock))
		BEGIN
			--如果有需要同步的数据
			DECLARE myPur CURSOR
			FOR SELECT wmsOrder,wmsBillNo,stockNo,createDate,warehouse,deptNo,vendorID,sendNo,orderType,BillSts,
					auditTime,auditId,printNum,printerId,RecieverId,RecieverTime,creatorId,orderNo,remarks
				FROM @tmpStock
				ORDER BY wmsBillNo
			OPEN myPur
			FETCH NEXT FROM myPur INTO @wmsOrder,@wmsBillNo,@stockNo,@createDate,@warehouse,@deptNo,@vendorID,@sendNo,@orderType,@BillSts,@auditTime,@auditId,@printNum,@printerId,@RecieverId,@RecieverTime,@creatorId,@orderNo,@remarks
			WHILE @@FETCH_STATUS=0
			BEGIN
			    SET @Errors=0;
                BEGIN TRY
		            BEGIN TRANSACTION		            
				    --写入采购入库单
				    INSERT INTO F10BMS.dbo.PMS_Stock(StockNo,CreateDate,DeptNo,WareHouse,VendorID,SendNo,BillType,BillSts,
					    AuditDate,AuditID,CreatorID,Remarks,PrintNum,PrinterID,RecieverId,RecieverTime,wmsStock,memo)
				    VALUES(@stockNo,@createDate,@DeptNo,@warehouse,@vendorID,@sendNo,'10',@billSts,@auditTime,@auditId,
					    @creatorId,@remarks,@printNum,@printerId,@RecieverId,@RecieverTime,@wmsOrder,'WMS系统入库单：' + @stockNo);
					SET @Errors=@Errors+@@ERROR;  
				    --写入采购入库单明细表				
			        INSERT INTO F10BMS.dbo.PMS_StockDtl(wmsStockId,StockNo,WareHouse,Location,OrderID,OrderNo,
				        ItemID,PkgQty,SQty,Price,Amt,IQty,IAmt,RQty,IsEffect,IsSpecial,TaxFlag,PlanID,PlanNo,IsPromotion,
				        isTemporary,isEmergency,XS_OrderID,XS_OrderNo,XS_CustNo,XS_CustName,PAmt,PIAmt,Remarks)
			        SELECT stockId,@stockNo,warehouse,locationNo,orderId,orderNo,itemId,pkgQty,SQty,Price,ROUND(Amt,2),IQty,IAmt,
				        RQty,IsEffect,IsSpecial,TaxFlag,PlanID,PlanNo,IsPromotion,isTemporary,isEmergency,XS_OrderID,
				        XS_OrderNo,XS_CustNo,XS_CustName,PAmt,PIAmt,Remarks
			        FROM dbo.WMS_F10_PMS_StockDtl_V
			        WHERE stockNo=@wmsOrder;
			        SET @Errors=@Errors+@@ERROR;				
				    --审核采购入库单
				    EXEC F10BMS.dbo.sp_PMSStockAudit @stockNo,'20';
				    SET @Errors=@Errors+@@ERROR;
				    --更新当前WMS入库单同步状态
				    UPDATE dbo.PMS_Stock SET thirdSyncFlag=1,thirdSyncTime=GETDATE() WHERE stockNo=@wmsOrder;
				    SET @Errors=@Errors+@@ERROR;
				    IF (@Errors=0) 
				    BEGIN
				        COMMIT;
				    END
				  	ELSE
				  	BEGIN
				  	    IF @@TRANCOUNT > 0
			                ROLLBACK;
			            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','采购入库单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
				    END
				END TRY
				BEGIN CATCH
				    IF @@TRANCOUNT > 0
		                ROLLBACK;
		            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
	                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','采购入库单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
				END CATCH	
				FETCH NEXT FROM myPur INTO @wmsOrder,@wmsBillNo,@stockNo,@createDate,@warehouse,@deptNo,@vendorID,@sendNo,@orderType,@BillSts,@auditTime,@auditId,@printNum,@printerId,@RecieverId,@RecieverTime,@creatorId,@orderNo,@remarks
			END
			CLOSE myPur
			DEALLOCATE myPur
			--清理临时数据
			DELETE FROM @tmpStock;
		END
		--2.同步其他入库单（调拨入库，赠品入库，其他入库)
		INSERT INTO @tmpStock(wmsOrder,wmsBillNo,stockNo,createDate,warehouse,deptNo_O,deptNo_I,sendNo,orderType,
			BillSts,auditTime,auditId,printNum,printerId,printTime,RecieverId,RecieverTime,creatorId,orderNo,remarks)
		SELECT wmsOrder,wmsBillNo,stockNo,createDate,warehouse,deptNo_O,deptNo_I,sendNo,orderType,BillSts,auditTime,
			auditId,printNum,printerId,printTime,RecieverId,RecieverTime,creatorId,orderNo,remarks
		FROM dbo.WMS_F10_IMS_Other_V
		WHERE (companyId=@companyId) AND (ownerId=@ownerId);
		--循环同步其他入库单
		WHILE (EXISTS(SELECT 1 FROM @tmpStock))
		BEGIN
		    SET @Errors=0;
		    --WMS入库单No,入库单编号,入库部门，出库部门，对应订单编号
			SELECT TOP 1 @wmsOrder=wmsOrder,@stockNo=stockNo,@DeptNo_I=deptNo_I,
						 @DeptNo_O=deptNo_O,@orderNo=orderNo,@orderType=orderType,
						 @warehouse=warehouse
			FROM @tmpStock
			ORDER BY orderType,wmsBillNo;
		    BEGIN TRY
		        BEGIN TRAN			
			    --调拨入库单
			    IF(@orderType=21)
			    BEGIN
			        SET @BillTypeDesc='调拨入库单';
				    --写入调拨入库单
				    INSERT INTO F10BMS.dbo.IMS_Incept(InceptNo,CreateDate,DeptNo,DeptNo_O,WareHouse,BillSts,
					    AuditDate,AuditID,CreatorID,Remarks,PrintNum,PrinterID,memo,wmsStock,PFlag)
				    SELECT stockNo,createDate,deptNo_I,deptNo_O,warehouse,'20',auditTime,auditId,creatorId,remarks,
					    printNum,printerId,'WMS系统入库单：' + @stockNo,wmsOrder,CASE printNum WHEN 0 THEN 0 ELSE 1 END AS pFlag
				    FROM @tmpStock
				    WHERE wmsOrder=@wmsOrder;
				    SET @Errors =@Errors+@@ERROR; 
				    --写入调拨入库单明细
				    INSERT INTO F10BMS.dbo.IMS_InceptDtl(wmsStockId,InceptNo,AllotID,AllotNo,OrderID,Location,
					    DeptNo,WareHouse,ItemID,PkgQty,IQty,Price,SPrice,Amt,Remarks)
				    SELECT stockId,@stockNo,orderId,orderNo,planId,locationNo,@DeptNo_I,warehouse,itemId,pkgQty,SQty,price,SPrice,Amt,Remarks
				    FROM dbo.WMS_F10_IMS_OtherDtl_V
				    WHERE StockNo=@wmsOrder
				    ORDER BY orderId;
				    SET @Errors =@Errors+@@ERROR;
				    --审核调拨入库单
				    EXEC F10BMS.dbo.sp_IMSInceptAudit @stockNo,'20';
				    SET @Errors =@Errors+@@ERROR;				
			    END
			    --赠品入库单
			    IF(@orderType=31)
			    BEGIN
			        SET @BillTypeDesc='赠品入库单';
			        --根据WMS入出库仓库处理（避免和F10库存不一致导致库存数据差异）
			        Update F10BMS.dbo.IMS_PresentDtl SET WareHouse=@warehouse WHERE PresentNo=@orderNo;
			        SET @Errors =@Errors+@@ERROR;
				    Update F10BMS.dbo.IMS_Present Set WareHouse=@warehouse,BillSts='20',syncFlag=1,editTime=GETDATE(),auditID=@auditId,auditDate=@auditTime,wmsBillNo=@stockNo WHERE PresentNo=@orderNo;
				    SET @Errors =@Errors+@@ERROR;
				    EXEC F10BMS.dbo.sp_IMSPresentAudit @orderNo,'20';
				    SET @Errors =@Errors+@@ERROR;				    
			    END
			    --其他入库单
			    IF(@orderType=41)
			    BEGIN
			        SET @BillTypeDesc='其他入库单';	
			        --根据WMS入出库仓库处理（避免和F10库存不一致导致库存数据差异）
			        UPDATE F10BMS.dbo.IMS_OtherDtl SET WareHouse=@warehouse WHERE OtherNo=@orderNo;
				    SET @Errors =@Errors+@@ERROR;
				    Update F10BMS.dbo.IMS_Other Set WareHouse=@warehouse,BillSts='20',syncFlag=1,editTime=GETDATE(),auditID=@auditId,auditDate=@auditTime,wmsBillNo=@stockNo WHERE OtherNo=@orderNo;
				    SET @Errors =@Errors+@@ERROR;
				    EXEC F10BMS.dbo.sp_IMSOtherAudit @orderNo,'20';		
				    SET @Errors =@Errors+@@ERROR;
			    END
			    --更新当前WMS入库单同步状态
			    UPDATE dbo.PMS_Stock SET thirdSyncFlag=1,thirdSyncTime=GETDATE() WHERE stockNo=@wmsOrder;
			    SET @Errors =@Errors+@@ERROR;
			    IF (@Errors=0)
			    BEGIN
			        COMMIT;
			    END
			    ELSE
			    BEGIN
			        IF @@TRANCOUNT > 0
		                ROLLBACK;
		            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
	                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR',@BillTypeDesc + '[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
			    END
			END TRY
			BEGIN CATCH
			    IF @@TRANCOUNT > 0
	                ROLLBACK;
	            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR',@BillTypeDesc + '[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
			END CATCH
		    --清除数据
            DELETE FROM @tmpStock WHERE wmsOrder=@wmsOrder;	
		END
		--3.同步销售退货单
		INSERT INTO @tmpStock(wmsOrder,wmsBillNo,stockNo,auditId,auditTime)
		SELECT wmsOrder,wmsBillNo,returnNo,auditorId,auditTime
		FROM dbo.WMS_F10_SAD_Return_V
		ORDER BY wmsBillNo;
		--循环同步销售退货单
		WHILE (EXISTS(SELECT 1 FROM @tmpStock))
		BEGIN
		    SET @Errors=0;
			--WMS入库单No,入库单编号,入库部门，出库部门，对应订单编号
			SELECT TOP 1 @wmsOrder=wmsOrder,@wmsBillNo=wmsBillNo,@stockNo=stockNo,@auditId=auditId,@auditTime=auditTime
			FROM @tmpStock
			ORDER BY wmsBillNo;			
			BEGIN TRY
			    BEGIN TRAN
			    --更新F10状态，并审核F10销售退货单
			    UPDATE F10BMS.dbo.SMS_Return SET BillSts='20',syncFlag=1,editTime=GETDATE(),wmsBillNo=@wmsBillNo WHERE ReturnNo=@stockNo;
			    SET @Errors=@Errors+@@ERROR;
			    EXEC F10BMS.dbo.sp_SMSReturnAudit @stockNo,'20';
			    SET @Errors=@Errors+@@ERROR;	
			    --更新当前WMS入库单同步状态
			    UPDATE dbo.SAD_Return SET thirdSyncFlag=1,thirdSyncTime=GETDATE() WHERE returnNo=@wmsOrder;
			    SET @Errors=@Errors+@@ERROR;
			    IF (@Errors=0)
			    BEGIN
			        COMMIT;
			    END 
			    ELSE
			    BEGIN
			        IF @@TRANCOUNT > 0
		                ROLLBACK;
		            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
	                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','销售退货单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
			    END
			END TRY
			BEGIN CATCH
			    IF @@TRANCOUNT > 0
		            ROLLBACK;    
			    INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','销售退货单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
			END CATCH
			--清除数据
			DELETE FROM @tmpStock WHERE wmsOrder=@wmsOrder;
		END
		--4.同步销售出库单（包含A单）
		INSERT INTO @tmpSales(wmsStock,stockNo,aFlag,aStockNo,orderBillNo,boneOrdNo)
		SELECT wmsStock,stockNo,aFlag,aStockNo,mergeNo,boneOrdNo
		FROM dbo.WMS_F10_SMS_Stock_V
		ORDER BY stockNo;
		WHILE (EXISTS(SELECT 1 FROM @tmpSales))
		BEGIN
		    SET @Errors=0;
			SELECT TOP 1 @wmsStock=wmsStock,@stockNo=stockNo,@aFlag=ISNULL(aFlag,0),@aStockNo=aStockNo,@orderBillNo=orderBillNo,@boneOrdNo=boneOrdNo
			FROM @tmpSales
			ORDER BY viewOrder;
			BEGIN TRY
			    BEGIN TRAN
			    --0,订单;1,有A单;2,A单;3,直送单
			    IF (@aFlag=0 OR @aFlag=1 OR @aFlag=3)
			    BEGIN
				    IF (@aFlag=1)
				    BEGIN
					    SET @billSts='30';
					    SET @CarNumberSts='不发车';
				    END
				    ELSE
				    BEGIN
					    --其他单据是A单原单
					    IF EXISTS(SELECT 1 FROM SAD_Order WHERE companyId=@companyId AND aFlag=2 AND aOrderNo=@orderBillNo)
					    BEGIN
						    SET @billSts='30';
						    SET @CarNumberSts='不发车';
					    END
					    ELSE
					    BEGIN
						    SET @billSts='20';
						    SET @CarNumberSts='';
					    END
				    END
				    --写入销售出库单主表		
				    INSERT INTO F10BMS.dbo.SMS_Stock(StockNo,CreateDate,DeptNo,WareHouse,CustID,BillType,SendAddr,LinkMan,Phone,
					    SendID,SendDate,SendTime,BillSts,PaidUp,PaidAmt,SalesID,AuditDate,AuditID,CreatorID,SMSAStockFlag,CostsID,
					    orderreninfo,PrintNum,PFlag,PrinterID,wmsStock,memo,Remarks,CarNumberSts,WLFlag,BoxupSts,PH_OperatorID,
					    PH_DateTime,logisticsId,postFee,PoNo,LineId)
				    SELECT stockNo,createDate,DeptNo,Warehouse,CustID,billType,sendAddr,LinkMan,Phone,SendId,SendDate,SendTime,
					    @billSts,PaidUp,PaidAmt,ISNULL(SalesID,99),AuditDate,AuditID,CreatorId,CASE aFlag WHEN 1 THEN 1 ELSE 0 END,
					    CostsId,orderRenInfo,printNum,CASE ISNULL(PrintNum,0) WHEN 0 THEN 0 ELSE 1 END,PrinterId,wmsStock,memo,remarks,
					    @CarNumberSts,'已配货','已装箱',PH_OperatorId,PH_DateTime,logisticsId,postFee,poNo,CodeID
				    FROM dbo.WMS_F10_SMS_Stock_V
				    WHERE wmsStock=@wmsStock;
				    SET @Errors=@Errors+@@ERROR;
				    --写入销售出库明细临时表		
				    INSERT INTO @tmpDetail(wmsStockId,wmsStock,stockNo,OrderId,OrderNo,Warehouse,ItemID,location,pkgQty,SQty,Price,Amt,
					    DiscRate,IsSpecial,IsEffect,taxFlag,PaidAmt,IsPromotion,isGift,DiscountTemp,PkgRatio,Integral,boneOrdId,boneOrdNo,
					    wmsOrderId,remarks)
				    SELECT wmsStockId,wmsStock,stockNo,OrderId,OrderNo,Warehouse,ItemID,location,pkgQty,SQty,Price,Amt,DiscRate,IsSpecial,
					    IsEffect,taxFlag,PaidAmt,IsPromotion,ISNULL(isGift,0),DiscountTemp,PkgRatio,Integral,boneOrdId,boneOrdNo,wmsOrderId,
					    remarks 
				    FROM dbo.WMS_F10_SMS_StockDtl_V 
				    WHERE wmsStock=@wmsStock;
				    SET @Errors=@Errors+@@ERROR;
				    --写入销售出库明细表
				    INSERT INTO F10BMS.dbo.SMS_StockDtl(StockNo,OrderID,OrderNo,WareHouse,ItemID,Location,
					    PkgQty,SQty,Price,Amt,ZQty,DiscRate,IsSpecial,IsEffect,TaxFlag,IsPromotion,IQty,IAmt,
					    RQty,RZQty,PaidAmt,PAmt,CPrice,Remarks,DiscountTemp,Integral,CreateDate,PkgRatio,
					    DiscType,boneOrdNo,wmsStockId)
				    SELECT t.stockNo,t.OrderId,t.OrderNo,t.Warehouse,t.ItemID,t.location,t.pkgQty,t.SQty,t.Price,
					    ROUND(t.Amt,2),t.ZQty,t.DiscRate,t.IsSpecial,t.IsEffect,t.taxFlag,t.IsPromotion,0.0 AS IQty,0.0 AS IAmt,
					    0.0 AS RQty,0.0 AS RZQty,t.PaidAmt,0.0 AS PAmt,0.0 AS CPrice,t.remarks,t.DiscountTemp,t.Integral,@createDate,
					    t.PkgRatio,'' AS DiscType,t.boneOrdNo,t.wmsStockId
				    FROM (
						    SELECT a.wmsStockId,a.wmsStock,a.stockNo,a.OrderId,a.OrderNo,a.Warehouse,a.ItemID,a.location,a.pkgQty,a.SQty,
							    a.Price,a.Amt,b.ZQty,a.DiscRate,a.IsSpecial,a.IsEffect,a.taxFlag,a.PaidAmt,a.IsPromotion,a.isGift,a.DiscountTemp,
							    a.PkgRatio,a.Integral,a.boneOrdNo,a.wmsOrderId,a.remarks 
						    FROM @tmpDetail a
							    LEFT JOIN (SELECT orderId,SUM(SQty) AS ZQty
										    FROM @tmpDetail
										    WHERE isGift=1
										    GROUP BY OrderId) b ON a.OrderId=b.OrderId
						    WHERE isGift=0
						    UNION ALL 
						    SELECT a.wmsStockId,a.wmsStock,a.stockNo,a.OrderId,a.OrderNo,a.Warehouse,a.ItemID,a.location,a.pkgQty,0.0 AS SQty,
							    a.Price,a.Amt,a.SQty AS ZQty,a.DiscRate,a.IsSpecial,a.IsEffect,a.taxFlag,a.PaidAmt,a.IsPromotion,a.isGift,a.DiscountTemp,
							    a.PkgRatio,a.Integral,a.boneOrdNo,a.wmsOrderId,a.remarks 
						    FROM @tmpDetail a
						    WHERE isGift=1
							    AND NOT EXISTS(SELECT 1 FROM @tmpDetail b WHERE a.OrderId=b.OrderId AND b.isGift=0)
					    ) t;
					SET @Errors=@Errors+@@ERROR;
				    --调用销售出库单审核存储过程
				    EXEC F10BMS.dbo.sp_SMSStockAudit @stockNo,'20';
				    SET @Errors=@Errors+@@ERROR;
				    ---消除预占库存
				    exec F10BMS.dbo.sp_YZStock_Audit_Stock @stockNo,'A1';
				    SET @Errors=@Errors+@@ERROR;
				    --更新当前WMS入库单同步状态
				    UPDATE dbo.SAD_Stock SET thirdSyncFlag=1,thirdSyncTime=GETDATE() WHERE stockNo=@wmsStock;
				    SET @Errors=@Errors+@@ERROR;
				    --更新VIP平台数据
				  --  IF EXISTS(SELECT 1 FROM Bone.dbo.ECM_Order WHERE orderNo=@boneOrdNo)
				  --  BEGIN
					 --   SELECT @bonePkgId=bonePkgId,@orderSts=BillSts FROM F10BMS.dbo.SMS_Order WHERE OrderNo=@orderBillNo;
					 --   IF (@orderSts='30')
						--    UPDATE Bone.dbo.ECM_OrderEx SET sdState=4 WHERE packageId=@bonePkgId;
					 --   IF (@orderSts='25')
						--    UPDATE Bone.dbo.ECM_OrderEx SET sdState=3 WHERE packageId=@bonePkgId;
					 --   IF NOT EXISTS(SELECT 1 FROM Bone.dbo.ECM_OrderEx WHERE orderNo=@boneOrdNo AND sdState<4)
						--    UPDATE Bone.dbo.ECM_Order SET sdState=4 WHERE orderNo=@boneOrdNo;
					 --   ELSE
						--    UPDATE Bone.dbo.ECM_Order SET sdState=3 WHERE orderNo=@boneOrdNo;
						--SET @Errors=@Errors+@@ERROR;
				  --  END
			    END
			    --A单
			    IF (@aFlag=2)
			    BEGIN
				    --原单已复核完成才允许生成A单以保证A单正确性,或者凭空A单
				    IF ISNULL(@aStockNo,'')!='' AND EXISTS(SELECT 1 FROM dbo.SAD_Stock WHERE mergeNo=@aStockNo AND (aFlag IN(0,1,3)) AND taskState>=60)
				    BEGIN
					    --获取A单出库单号
					    SELECT TOP 1 @aBillNo=billNo FROM dbo.SAD_Stock WHERE mergeNo=@aStockNo AND (aFlag IN(0,1,3)) AND taskState>=60;
					    IF NOT EXISTS(SELECT 1 FROM F10BMS.dbo.SMS_AStock WHERE StockNo=@aBillNo)
					    BEGIN
						    --更新A单订单状态
						    UPDATE F10BMS.dbo.SMS_Order SET BillSts='30',WmsFlag='已出仓' WHERE OrderNo=@orderBillNo;
						    SET @Errors=@Errors+@@ERROR;
						    --更新A单订单已发货数量
						    UPDATE F10BMS.dbo.SMS_OrderDtl SET SQty=ISNULL(OQty,0.0),SZQty=ISNULL(ZQty,0.0) WHERE OrderNo=@orderBillNo;
						    SET @Errors=@Errors+@@ERROR;
						    --写入A单表，用原单号做A单单号					
						    INSERT INTO F10BMS.dbo.SMS_AStock(StockNo,CreateDate,DeptNo,WareHouse,CustID,BillType,SendAddr,LinkMan,Phone,
							    SendID,SendDate,SendTime,BillSts,PaidUp,PaidAmt,SalesID,AuditDate,AuditID,CreatorID,CostsID,
							    orderreninfo,PrintNum,PFlag,PrinterID,wmsStock,memo,StockNo_O,Remarks)						
						    SELECT @aBillNo,createDate,DeptNo,Warehouse,CustID,billType,sendAddr,LinkMan,Phone,SendId,SendDate,SendTime,
							    '20',PaidUp,PaidAmt,ISNULL(SalesID,99),AuditDate,AuditID,CreatorId,CostsId,orderRenInfo,printNum,
							    CASE ISNULL(PrintNum,0) WHEN 0 THEN 0 ELSE 1 END,PrinterId,wmsStock,memo,@aBillNo,remarks
						    FROM dbo.WMS_F10_SMS_Stock_V
						    WHERE wmsStock=@wmsStock;
						    SET @Errors=@Errors+@@ERROR;
						    --写入销售出库明细表
						    INSERT INTO F10BMS.dbo.SMS_AStockDtl(StockNo,OrderID,OrderNo,WareHouse,ItemID,Location,
							    PkgQty,SQty,Price,Amt,ZQty,DiscRate,IsSpecial,IsEffect,TaxFlag,IsPromotion,IQty,IAmt,
							    RQty,RZQty,PaidAmt,PAmt,CPrice,Remarks,DiscountTemp,Integral,CreateDate,wmsStockId)
						    SELECT @aBillNo,OrderID,OrderNo,WareHouse,ItemID,Location,
							    PkgQty,SQty,Price,Amt,0.0 AS ZQty,DiscRate,IsSpecial,IsEffect,TaxFlag,IsPromotion,IQty,IAmt,
							    RQty,RZQty,PaidAmt,PAmt,0.0 AS CPrice,Remarks,DiscountTemp,Integral,@CreateDate,wmsStockId 
						    FROM dbo.WMS_F10_SMS_StockDtl_V 
						    WHERE wmsStock=@wmsStock; 
						    SET @Errors=@Errors+@@ERROR;
						    --更新当前WMS入库单同步状态
						    UPDATE dbo.SAD_Stock SET thirdSyncFlag=1,thirdSyncTime=GETDATE() WHERE stockNo=@wmsStock;
						    SET @Errors=@Errors+@@ERROR;
					    END
					    ELSE
					    BEGIN
						    INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
						    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10',
							    'YI_WMS_TO_F10_NON_SOURCE_BILL','销售A单[' + @stockNo + ']重复，不能同步',@wmsStock,@stockNo);
							SET @Errors=@Errors+@@ERROR;
					    END
				    END
				    ELSE
				    BEGIN
					    INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
					    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10',
						    'YI_WMS_TO_F10_NON_SOURCE_BILL','销售A单[' + @stockNo + ']对应的原始单据没有完成配货，不能同步',@wmsStock,@stockNo);
						SET @Errors=@Errors+@@ERROR;
				    END
			    END			
			    DELETE FROM @tmpDetail;
			    SET @Errors=@Errors+@@ERROR;
			    IF (@Errors=0)
			    BEGIN
			        COMMIT;
			    END
			    ELSE
			    BEGIN
			        IF @@TRANCOUNT > 0
	                    ROLLBACK;
	                INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','销售出库单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
			    END
			END TRY
			BEGIN CATCH
			    IF @@TRANCOUNT > 0
	                ROLLBACK;
	            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','销售出库单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
			END CATCH
			DELETE FROM @tmpSales WHERE wmsStock=@wmsStock;
		END	
		--5.同步其他出库单（包含调拨出库）
		INSERT INTO @tmpSales(wmsStock,stockNo)
		SELECT wmsStock,allotNo
		FROM dbo.WMS_F10_QTC_Stock_V
		ORDER BY allotNo;
		WHILE (EXISTS(SELECT 1 FROM @tmpSales))
		BEGIN
		    SET @Errors=0;
			--获取第一条数据
			SELECT TOP 1 @wmsStock=wmsStock,@stockNo=stockNo
			FROM @tmpSales
			ORDER BY viewOrder;
			--取得第一条其他出库数据
			SELECT @createDate=createDate,@DeptNo=DeptNo,@DeptNo_I=DeptNo_I,@warehouse=warehouse,@orderType=orderType,
				@auditTime=auditDate,@auditId=auditId,@creatorId=creatorId,@printerId=printerId,@printNum=printNum, 
				@memo=memo,@remarks=remarks,@billSts='20',@orderNo=mergeNo,@postFee=postFee,@logisticsId=logisticsId
			FROM dbo.WMS_F10_QTC_Stock_V
			WHERE wmsStock=@wmsStock;
			BEGIN TRY
			    BEGIN TRAN
			    --调拨出库单
			    IF (@orderType=20)
			    BEGIN
			        SET @BillTypeDesc='调拨出库单';
				    --生成调拨出库单
				    INSERT INTO F10BMS.dbo.IMS_Allot(AllotNo,CreateDate,DeptNo,DeptNo_I,WareHouse,BillSts,AuditDate,
					    AuditID,CreatorID,PrinterID,PrintNum,PFlag,WLFlag,wmsStock,memo,PostFee,logisticsId,Remarks)
				    VALUES(@stockNo,@createDate,@DeptNo,@DeptNo_I,@warehouse,@billSts,@auditTime,@auditId,@creatorId,
					    @printerId,@printNum,CASE ISNULL(@printNum,0) WHEN 0 THEN 0 ELSE 1 END,'已配货',@wmsStock,@memo,
					    @postFee,@logisticsId,@remarks);
				    SET @Errors=@Errors+@@ERROR;	
				    --总总量，按重量分摊运费用
				    SELECT @totalWeight=SUM(itemWeight*SQty) FROM WMS_F10_QTC_StockDtl_V WHERE wmsStock=@wmsStock;
				    --生成调拨出库单明细
				    INSERT INTO F10BMS.dbo.IMS_AllotDtl(AllotNo,DeptNo_I,OrderID,OrderNo,WareHouse,Location,ItemID,PkgQty,
					    SQty,Price,Amt,IQty,CPrice,SPrice,Remarks,wmsStockId,BefPrice)
				    SELECT a.allotNo,@DeptNo_I,a.OrderID,a.OrderNo,a.WareHouse,a.Location,a.ItemID,a.PkgQty,
					    a.SQty,ISNULL(a.PPrice,0.00)+ROUND(ISNULL(a.itemWeight,0.0)/@totalWeight*@postFee,4),
					    ROUND(ISNULL(a.SQty,0.0)*(ISNULL(a.PPrice,0.0)+ROUND(ISNULL(a.itemWeight,0.0)/@totalWeight*@postFee,4)),2) AS Amt,a.IQty,0.0 AS CPrice,
					    a.SPrice,a.Remarks,a.wmsStockId,a.PPrice
				    FROM dbo.WMS_F10_QTC_StockDtl_V a 
					    ---LEFT JOIN F10BMS.dbo.IMS_Subdepot b ON b.DeptNo=@DeptNo AND a.itemId=b.ItemID
				    WHERE a.wmsStock=@wmsStock;
				    SET @Errors=@Errors+@@ERROR;
				    --审核调拨出库单
				    EXEC F10BMS.dbo.sp_IMSAllotAudit @stockNo,'20';
				    SET @Errors=@Errors+@@ERROR;
			    END
			    --其他出库单
			    IF (@orderType=32)
			    BEGIN
			        SET @BillTypeDesc='其他出库单';
			        --根据WMS入出库仓库处理（避免和F10库存不一致导致库存数据差异）
			        Update F10BMS.dbo.IMS_OtherDtl SET WareHouse=@warehouse WHERE OtherNo=@orderNo;
			        SET @Errors=@Errors+@@ERROR;
				    Update F10BMS.dbo.IMS_Other Set WareHouse=@warehouse,BillSts='20',syncFlag=1,editTime=GETDATE(),auditID=@auditId,auditDate=@auditTime,wmsBillNo=@stockNo WHERE OtherNo=@orderNo;
				    SET @Errors=@Errors+@@ERROR;
				    EXEC F10BMS.dbo.sp_IMSOtherAudit @orderNo,'20';
				    SET @Errors=@Errors+@@ERROR;	
			    END
			    --赠品出库
			    IF (@orderType=40)
			    BEGIN
			        SET @BillTypeDesc='赠品出库单';
			        --根据WMS入出库仓库处理（避免和F10库存不一致导致库存数据差异）
			        Update F10BMS.dbo.IMS_PresentDtl SET WareHouse=@warehouse WHERE PresentNo=@orderNo;
			        SET @Errors=@Errors+@@ERROR;
				    Update F10BMS.dbo.IMS_Present Set WareHouse=@warehouse,BillSts='20',syncFlag=1,editTime=GETDATE(),auditID=@auditId,auditDate=@auditTime,wmsBillNo=@stockNo WHERE PresentNo=@orderNo;
				    SET @Errors=@Errors+@@ERROR;
				    EXEC F10BMS.dbo.sp_IMSPresentAudit @orderNo,'20';
				    SET @Errors=@Errors+@@ERROR;
			    END
			    --报损报废
			    IF (@orderType=50)
			    BEGIN
			        SET @BillTypeDesc='报损报废单';
			        --根据WMS入出库仓库处理（避免和F10库存不一致导致库存数据差异）
			        Update F10BMS.dbo.IMS_OtherDtl SET WareHouse=@warehouse WHERE OtherNo=@orderNo;
			        SET @Errors=@Errors+@@ERROR;
				    Update F10BMS.dbo.IMS_Other Set WareHouse=@warehouse,BillSts='20',syncFlag=1,editTime=GETDATE(),auditID=@auditId,auditDate=@auditTime,wmsBillNo=@stockNo WHERE OtherNo=@orderNo;
				    SET @Errors=@Errors+@@ERROR;
				    EXEC F10BMS.dbo.sp_IMSOtherAudit @orderNo,'20';
				    SET @Errors=@Errors+@@ERROR;
			    END
			    --更新当前WMS入库单同步状态
			    UPDATE dbo.SAD_Stock SET thirdSyncFlag=1,thirdSyncTime=GETDATE() WHERE stockNo=@wmsStock;
			    SET @Errors=@Errors+@@ERROR;
			    IF (@Errors=0)
			    BEGIN
			        COMMIT;
			    END
			    ELSE
			    BEGIN
			        IF @@TRANCOUNT > 0
	                    ROLLBACK;
	                INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR',@BillTypeDesc + '[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
			    END
			END TRY
			BEGIN CATCH
			    IF @@TRANCOUNT > 0
	                ROLLBACK;
	            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR',@BillTypeDesc + '[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
			END CATCH
			DELETE FROM @tmpSales WHERE wmsStock=@wmsStock;
		END
		--6.同步采购退货单
		INSERT INTO @tmpStock(wmsOrder,wmsBillNo)
		SELECT wmsOrder,returnNo
		FROM dbo.WMS_F10_PMS_Return_V
		ORDER BY returnNo;
		WHILE EXISTS(SELECT 1 FROM @tmpStock)
		BEGIN
		    SET @Errors=0;
		    --获取第一条数据
		    SELECT TOP 1 @wmsOrder=wmsOrder,@wmsBillNo=wmsBillNo
		    FROM @tmpStock
		    ORDER BY wmsBillNo;
		    BEGIN TRY
			    BEGIN TRAN			    
			    --如果存在明细（避免商品资料不同步）
			    IF EXISTS(SELECT 1 FROM dbo.WMS_F10_PMS_ReturnDtl_V WHERE wmsOrder=@wmsOrder)
			    BEGIN
				    --写入退货单主表
				    INSERT INTO F10BMS.dbo.PMS_Return(ReturnNo,CreateDate,DeptNo,WareHouse,VendorID,BillSts,Forcible,
					    AuditDate,AuditID,Remarks,syncFlag,wmsOrder,wmsBillNo,Reason,creatorId)
				    SELECT ReturnNo,CreateDate,DeptNo,WareHouse,VendorID,'20' AS BillSts,Forcible,
					    AuditDate,AuditID,Remarks,syncFlag,wmsOrder,wmsBillNo,Reason,creatorId
				    FROM dbo.WMS_F10_PMS_Return_V
				    WHERE wmsOrder=@wmsOrder;
				    SET @Errors=@Errors+@@ERROR;
				    --写入退货单明细表
				    INSERT INTO F10BMS.dbo.PMS_ReturnDtl(ReturnNo,StockID,StockNo,WareHouse,ItemID,
					    Location,PkgQty,RQty,Price,Amt,TaxFlag,IsSpecial,Remarks)
				    SELECT ReturnNo,StockID,StockNo,WareHouse,ItemID,
					    locationNo,PkgQty,returnQty,Price,Amt,TaxFlag,IsSpecial,Remarks
				    FROM dbo.WMS_F10_PMS_ReturnDtl_V
				    WHERE wmsOrder=@wmsOrder
				    ORDER BY viewOrder;
				    SET @Errors=@Errors+@@ERROR;
				    --审核采购退货单（扣减库存等操作）
				    EXEC F10BMS.dbo.sp_PMSReturnAudit @wmsBillNo,'20';
				    SET @Errors=@Errors+@@ERROR;
				    --更新当前WMS入库单同步状态
				    UPDATE dbo.PMS_Return SET thirdSyncFlag=1,thirdSyncTime=GETDATE() WHERE returnNo=@wmsOrder;
				    SET @Errors=@Errors+@@ERROR;
			    END
			    IF (@Errors=0)
			    BEGIN
			        COMMIT;
			    END
			    ELSE
			    BEGIN
			        IF @@TRANCOUNT > 0
	                    ROLLBACK;
	                INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','采购退货单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
			    END
			END TRY
			BEGIN CATCH
			    IF @@TRANCOUNT > 0
	                ROLLBACK;
	            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','采购退货单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 
			END CATCH
			DELETE FROM @tmpStock WHERE wmsOrder=@wmsOrder;
		END
		--7.移仓单同步回F10
		INSERT INTO @tmpSales(wmsStock,stockNo)
		SELECT transferNo,billNo
		FROM dbo.WMS_F10_IMS_Transfer_V
		ORDER BY billNo;
		WHILE (EXISTS(SELECT 1 FROM @tmpSales))
		BEGIN
		    SET @Errors=0;
			--获取第一条数据
			SELECT TOP 1 @wmsStock=wmsStock,@stockNo=stockNo
			FROM @tmpSales
			ORDER BY viewOrder;
			BEGIN TRY
			    BEGIN TRAN
			    --把Wms数据写入F10
			    INSERT INTO F10BMS.dbo.IMS_Transfer(TransferNo,CreateDate,DeptNo,WareHouse_O,WareHouse_I,
				    BillSts,PFlag,AuditDate,AuditID,CreatorID,ShelvesID,ShelvesTime,memo,wmsTrans,remarks)
			    SELECT billNo,CreateDate,DeptNo,WareHouse_O,WareHouse_I,BillSts,PFlag,AuditDate,AuditID,
				    CreatorID,ShelvesID,ShelvesTime,'WMS系统移仓单:' + billNo AS memo,TransferNo,remarks
			    FROM dbo.WMS_F10_IMS_Transfer_V
			    WHERE TransferNo=@wmsStock;
			    SET @Errors=@Errors+@@ERROR;
			    --明细数据
			    INSERT INTO F10BMS.dbo.IMS_TransferDtl(TransferNo,WareHouse_O,WareHouse_I,ItemID,PkgQty,TQty,Price,Amt,wmsTransId,Remarks)
			    SELECT billNo,WareHouse_O,WareHouse_I,ItemID,CASE ISNULL(pkgRatio,0.0) WHEN 0.0 THEN 0.0 ELSE TQty/pkgRatio END AS pkgQty,  
				    TQty,Price,Amt,transferId,Remarks
			    FROM dbo.WMS_F10_IMS_TransferDtl_V
			    WHERE TransferNo=@wmsStock;
			    SET @Errors=@Errors+@@ERROR;
			    --调用F10审核单据操作
			    exec F10BMS.dbo.sp_IMSTransferAudit @stockNo,'20';
			    SET @Errors=@Errors+@@ERROR;
			    --更新当前WMS入库单同步状态
			    UPDATE dbo.IMS_Transfer SET thirdSyncFlag=1,thirdSyncTime=GETDATE() WHERE transferNo=@wmsStock;
			    SET @Errors=@Errors+@@ERROR;
			    IF (@Errors=0)
			    BEGIN
			        COMMIT;
			    END
			    ELSE
			    BEGIN
			        IF @@TRANCOUNT > 0
	                    ROLLBACK;
	                INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','移仓单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 			    
			    END
			END TRY
			BEGIN CATCH
			    IF @@TRANCOUNT > 0
	                ROLLBACK;
	            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','移仓单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo); 			
			END CATCH
			DELETE FROM @tmpSales WHERE wmsStock=@wmsStock;
		END
		--8.盘点调整单同步回F10其他入出库单
		INSERT INTO @tmpSales(wmsStock,stockNo)
		SELECT wmsStock,otherNo
		FROM dbo.WMS_F10_IMS_Adjust_V
		WHERE ISNULL(pointId,'')=''
		ORDER BY otherNo;
		WHILE (EXISTS(SELECT 1 FROM @tmpSales))
		BEGIN
		    SET @Errors=0;
			--获取第一条数据
			SELECT TOP 1 @wmsStock=wmsStock,@stockNo=stockNo
			FROM @tmpSales
			ORDER BY viewOrder;
			BEGIN TRY
			    BEGIN TRAN
			    --如果调整单明细数据不存在，则无需调整
			    IF NOT EXISTS(SELECT 1 FROM dbo.IMS_AdjustDetail WHERE adjustNo=@wmsStock AND ioQty!=0.0)
			    BEGIN
				    UPDATE dbo.IMS_Adjust SET thirdSyncFlag=-1,thirdSyncTime=GETDATE(),memo=ISNULL(memo,'') + ' 盘查无差异，无需同步' WHERE adjustNo=@wmsStock;
				    SET @Errors=@Errors+@@ERROR; 
			    END
			    ELSE
			    BEGIN
				    --把Wms数据写入F10
				    INSERT INTO F10BMS.dbo.IMS_Other(OtherNo,CreateDate,DeptNo,Warehouse,BillType,IOObject,
					    BillSts,PFlag,AuditDate,AuditID,CreatorID,editTime,syncFlag,wmsOrder,WmsBillNo,Remarks)
				    SELECT OtherNo,CreateDate,DeptNo,Warehouse,billType,IOObject,'20' AS BillSts,PFlag,AuditDate,AuditID,
					    CreatorID,editTime,syncFlag,wmsStock,WmsBillNo,Remarks
				    FROM dbo.WMS_F10_IMS_Adjust_V
				    WHERE wmsStock=@wmsStock;
				    SET @Errors=@Errors+@@ERROR;		
				    --明细数据
				    INSERT INTO F10BMS.dbo.IMS_OtherDtl(OtherNo,WareHouse,ItemID,Location,PkgQty,SQty,Price,Amt,CPrice,Remarks,wmsStockId)
				    SELECT OtherNo,WareHouse,ItemID,Location,PkgQty,SQty,Price,Amt,CPrice,Remarks,wmsStockId
				    FROM dbo.WMS_F10_IMS_AdjustDtl_V
				    WHERE wmsStock=@wmsStock;
				    SET @Errors=@Errors+@@ERROR;
				    --调用F10审核单据操作
				    exec F10BMS.dbo.sp_IMSOtherAudit @stockNo,'20';
				    SET @Errors=@Errors+@@ERROR;
				    --更新当前WMS入库单同步状态
				    UPDATE dbo.IMS_Adjust SET thirdSyncFlag=1,thirdSyncTime=GETDATE() WHERE adjustNo=@wmsStock;
				    SET @Errors=@Errors+@@ERROR;
			    END
			    IF (@Errors=0)
			    BEGIN
			        COMMIT;
			    END
			    ELSE
			    BEGIN
                    IF @@TRANCOUNT > 0
	                    ROLLBACK;
	                INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','手动调整单[' + @stockNo + ']未能同步到F10（其他入出库单）',@wmsOrder,@stockNo); 			
                END
			END TRY
			BEGIN CATCH
                IF @@TRANCOUNT > 0
	                ROLLBACK;
	            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','手动调整单[' + @stockNo + ']未能同步到F10（其他入出库单）',@wmsOrder,@stockNo); 			
			END CATCH
			DELETE FROM @tmpSales WHERE wmsStock=@wmsStock;
		END
		--9盘点数据同步到盘点单(盘点期号、分部、仓库)
	    INSERT INTO @tmpStock(wmsOrder,wmsBillNo,deptNo,warehouse,printNum)
	    SELECT pointId,pointNo,deptNo,warehouse,COUNT(1)
	    FROM dbo.WMS_F10_IMS_Adjust_V
	    WHERE ISNULL(pointId,'')!=''
	    GROUP BY pointId,pointNo,deptNo,warehouse;
	    --循环同步
	    WHILE (EXISTS(SELECT 1 FROM @tmpStock))
	    BEGIN
	        SET @Errors=0;
	        --获取第一个盘点设置
	        SELECT TOP 1 @wmsOrder=wmsOrder,@wmsBillNo=wmsBillNo,@warehouse=warehouse,@DeptNo=deptNo 
	        FROM @tmpStock 
	        ORDER BY wmsBillNo,deptNo,warehouse;
	        BEGIN TRY
	            BEGIN TRANSACTION;
                --写入F10盘点计划
                INSERT INTO F10BMS.dbo.IMS_CheckPoint(pointId,pointNo,companyId,warehouseId,startArea,
                    endArea,startOwner,endOwner,startNo,endNo,startItem,endItem,pointDate,startTime,endTime,
                    printNum,inventory,checkData,checkState,parentId,isLocked,lockerId,lockedTime,createTime,
                    creatorId,editTime,editorId,brandId,categoryId)
                SELECT a.pointId,a.pointNo,a.companyId,w.warehouseNo AS WarehouseID,a.startArea,a.endArea,
                    a.startOwner,a.endOwner,a.startNo,a.endNo,b1.itemNo AS startItem,b2.itemNo AS endItem,
                    CONVERT(VARCHAR(10),a.pointDate,23) AS pointDate,a.startTime,a.endTime,a.printNum,
                    a.inventory,1 AS checkData,20 AS checkState,a.parentId,0 AS isLocked,99 AS lockerId,a.lockedTime,
                    a.createTime,a.creatorId,a.editTime,a.editorId,cat.categoryNo AS categoryId,b.CodeID
                FROM dbo.IMS_CheckPoint a
                    LEFT JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId 
                    LEFT JOIN dbo.BAS_Category cat ON a.categoryId=cat.categoryId
                    LEFT JOIN dbo.WMS_F10_BAS_Brand_V b ON a.brandId =b.brandId
                    LEFT JOIN dbo.BAS_Item b1 ON a.startItem=b1.itemId
                    LEFT JOIN dbo.BAS_Item b2 ON a.endItem=b2.itemId
                WHERE a.pointId=@wmsOrder;
                SET @Errors=@Errors+@@ERROR;
                --写入F10盘点时刻表
                INSERT INTO F10BMS.dbo.IMS_CheckStock(stockId,pointId,companyId,warehouseId,regionId,lotNo,locationWay,locationNo,eId,itemId,onhandQty,realQty)
                SELECT REPLACE(NEWID(),'-',''),a.pointId,'' companyId,a.warehouseID,'' regionId,'' lotNo,'' locationWay,'' locationNo,a.eId,a.ItemID,b.OnHandQty,0.0 AS realQty
                FROM dbo.WMS_F10_IMS_CheckStock_V a
                    LEFT JOIN F10BMS.dbo.IMS_Ledger b ON a.warehouseID=b.WareHouse AND a.ItemID=b.ItemID
                WHERE a.pointId=@wmsOrder;
                SET @Errors=@Errors+@@ERROR;
                --生成盘点单号
		        EXEC F10BMS.dbo.sp_GetBillNo 'IMS80',@orderNo OUTPUT;
		        SET @Errors=@Errors+@@ERROR;
		        --写入盘点表主表
	            INSERT INTO F10BMS.dbo.IMS_Check(CheckNo,PointID,CreateDate,DeptNo,WareHouse,LotNo,BillSts,AuditDate,AuditID,CreatorID,Remarks,CreateTime) 
	            VALUES(@orderNo,@wmsOrder,CONVERT(VARCHAR(10),GETDATE(),23),@DeptNo,@WareHouse,@wmsBillNo,'20',CONVERT(VARCHAR(10),GETDATE(),23),99,99,'WMS盘点单，期号:' + @wmsBillNo,GETDATE());
		        SET @Errors=@Errors+@@ERROR;
		        --写入盘点表明细表
	            INSERT INTO F10BMS.dbo.IMS_CheckDtl(CheckNo,LotNo,WareHouse,Location,ItemID,CurQty,SQty)
	            SELECT @orderNo,@wmsBillNo,a.warehouse,'',a.itemId,b.OnHandQty,ISNULL(b.OnHandQty,0.0)+ISNULL(a.diffQty,0.0) 
	            FROM (SELECT warehouse,itemId,SUM(ISNULL(SQty,0.0)) AS diffQty
		              FROM dbo.WMS_F10_IMS_AdjustDtl_V
		              WHERE pointId=@wmsOrder
		              GROUP BY warehouse,itemId
		              HAVING SUM(ISNULL(SQty,0.0))!=0.0) a
		             LEFT JOIN F10BMS.dbo.IMS_Ledger b ON a.warehouse=b.WareHouse AND a.itemId=b.ItemID; 
		        SET @Errors=@Errors+@@ERROR;
                --盘点批次盘点完成
		        EXEC F10BMS.dbo.sp_Audit_InvCheckFinished @wmsOrder,99; 
		        SET @Errors=@Errors+@@ERROR;
                --更新当前WMS入库单同步状态
                UPDATE dbo.IMS_Adjust SET thirdSyncFlag=1,thirdSyncTime=GETDATE() WHERE pointId=@wmsOrder;
                SET @Errors=@Errors+@@ERROR;
                IF (@Errors=0)
                BEGIN
                    COMMIT;
                END
                ELSE
                BEGIN
                    IF @@TRANCOUNT > 0
                        ROLLBACK;
                    INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','单号[' + @wmsBillNo + '][' + @wmsOrder + ']'+ @ErrMsg,@wmsOrder,@wmsBillNo); 
                END
		    END TRY
		    BEGIN CATCH
		        IF @@TRANCOUNT > 0
                    ROLLBACK;
                INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','单号[' + @wmsBillNo + '][' + @wmsOrder + ']'+ @ErrMsg,@wmsOrder,@wmsBillNo); 
		    END CATCH
		    --清除数据，继续
		    DELETE FROM @tmpStock WHERE wmsOrder=@wmsOrder AND deptNo=@deptNo AND warehouse=@warehouse;
	    END
		/*
		--9盘点数据同步到盘点单(盘点期号、分部、仓库)
		INSERT INTO @tmpStock(wmsOrder,wmsBillNo,deptNo,warehouse,printNum)
		SELECT pointId,pointNo,deptNo,warehouse,COUNT(1)
		FROM dbo.WMS_F10_IMS_Adjust_V
		WHERE ISNULL(pointId,'')!=''
		GROUP BY pointId,pointNo,deptNo,warehouse;
		--循环同步
		WHILE (EXISTS(SELECT * FROM @tmpStock))
		BEGIN
		    SET @Errors=0;
			--获取第一个盘点设置
			SELECT TOP 1 @wmsOrder=wmsOrder,@wmsBillNo=wmsBillNo,@warehouse=warehouse,@DeptNo=deptNo FROM @tmpStock ORDER BY wmsBillNo,deptNo,warehouse;
			BEGIN TRY
			    BEGIN TRAN
			    --生成盘点单号
			    EXEC F10BMS.dbo.sp_GetBillNo 'IMS80',@orderNo OUTPUT;
			    SET @Errors=@Errors+@@ERROR;
			    --写入盘点表主表
			    INSERT INTO F10BMS.dbo.IMS_Check(CheckNo,CreateDate,DeptNo,WareHouse,LotNo,BillSts,AuditDate,AuditID,CreatorID,Remarks,CreateTime) 
			    VALUES(@orderNo,CONVERT(VARCHAR(10),GETDATE(),23),@DeptNo,@WareHouse,@wmsBillNo,'20',CONVERT(VARCHAR(10),GETDATE(),23),99,99,'WMS盘点单，期号:' + @wmsBillNo,GETDATE());
			    SET @Errors=@Errors+@@ERROR;
			    --写入盘点表明细表
			    INSERT INTO F10BMS.dbo.IMS_CheckDtl(CheckNo,LotNo,WareHouse,Location,ItemID,CurQty,SQty)
			    SELECT @orderNo,@wmsBillNo,a.warehouse,'',a.itemId,b.OnHandQty,ISNULL(b.OnHandQty,0.0)+ISNULL(a.diffQty,0.0) 
			    FROM (SELECT warehouse,itemId,SUM(ISNULL(SQty,0.0)) AS diffQty
				      FROM dbo.WMS_F10_IMS_AdjustDtl_V
				      WHERE pointNo=@wmsBillNo AND warehouse=@warehouse
				      GROUP BY warehouse,itemId
				      HAVING SUM(ISNULL(SQty,0.0))!=0.0) a
				     INNER JOIN F10BMS.dbo.IMS_Ledger b ON a.warehouse=b.WareHouse AND a.itemId=b.ItemID;
				SET @Errors=@Errors+@@ERROR;
			    --写入F10盘点临时表
			    Insert Into F10BMS.dbo.IMS_Audit(LotNo,CreateDate,DeptNo,WareHouse,ItemID,OnHandQty,SQty,ActQty,Locked)
			    Select t.LotNo,t.CreateDate,t.DeptNo,t.WareHouse,t.ItemID,x.CurQty,ISNULL(t.SQty,0.0)-ISNULL(x.CurQty,0.0),t.SQty,1
			    From (SELECT a.LotNo,a.WareHouse,a.DeptNo,b.ItemId,Sum(b.SQty) As SQty,MAX(b.CheckID) AS CheckID,MIN(a.CreateDate) AS CreateDate
				      FROM F10BMS.dbo.IMS_Check a 
					      INNER JOIN F10BMS.dbo.IMS_CheckDtl b ON a.CheckNo=b.CheckNo
				      WHERE a.BillSts='20' AND a.LotNo=@wmsBillNo AND a.WareHouse=@WareHouse
				      Group By a.LotNo,a.WareHouse,a.DeptNo,b.ItemID
				      ) t INNER JOIN F10BMS.dbo.IMS_CheckDtl x ON t.CheckID=x.CheckId;
				SET @Errors=@Errors+@@ERROR;
			    --盘点批次盘点完成
			    EXEC F10BMS.dbo.sp_IMSChecked @wmsBillNo,@warehouse,'20'; 
			    SET @Errors=@Errors+@@ERROR;
			    --获取仓库与盘点设置Id
			    SELECT @warehouseId=warehouseId FROM dbo.BAS_Warehouse WHERE companyId=@companyId AND warehouseNo=@warehouse;
			    SET @Errors=@Errors+@@ERROR;
			    --更新当前WMS入库单同步状态
			    UPDATE dbo.IMS_Adjust SET thirdSyncFlag=1,thirdSyncTime=GETDATE() WHERE pointId=@wmsOrder AND warehouseId=@warehouseId;
			    SET @Errors=@Errors+@@ERROR;
			    IF (@Errors=0)
			    BEGIN
			        COMMIT;
			    END
			    ELSE
			    BEGIN
                    IF @@TRANCOUNT > 0
	                    ROLLBACK;
	                INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','盘点单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo);
                END
			END TRY
			BEGIN CATCH
                IF @@TRANCOUNT > 0
	                ROLLBACK;
	            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','盘点单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo);
			END CATCH
			--清除数据，继续
			DELETE FROM @tmpStock WHERE wmsOrder=@wmsOrder AND deptNo=@deptNo AND warehouse=@warehouse;
		END
		*/
		--10.同步包装材料进其他出库单
		INSERT INTO @tmpStock(wmsOrder,wmsBillNo)
		SELECT wmsOrder,otherNo
		FROM WMS_PACK_F10_IMS_Other_V
		ORDER BY otherNo;
		WHILE (EXISTS(SELECT * FROM @tmpStock))
		BEGIN
		    SET @Errors=0;
			--获取第一条数据
			SELECT TOP 1 @wmsOrder=wmsOrder,@wmsBillNo=wmsBillNo
			FROM @tmpStock
			ORDER BY wmsBillNo;
			BEGIN TRY
			    BEGIN TRAN
			    --如果存在明细（避免包装材料与商品资料不同步）
			    IF EXISTS(SELECT 1 FROM WMS_PACK_F10_IMS_OtherDtl_V WHERE wmsStockId=@wmsOrder)
			    BEGIN
				    --写入其他出库单主表
				    INSERT INTO F10BMS.dbo.IMS_Other(OtherNo,CreateDate,DeptNo,Warehouse,BillType,IOObject,DepartNo,
					    BillSts,PFlag,AuditDate,AuditID,CreatorID,editTime,wmsOrder,wmsBillNo,syncFlag,Remarks)
				    SELECT OtherNo,CreateDate,DeptNo,Warehouse,BillType,IOObject,DepartNo,
					    '20' AS BillSts,PFlag,AuditDate,AuditID,CreatorID,editTime,wmsOrder,wmsBillNo,syncFlag,Remarks
				    FROM WMS_PACK_F10_IMS_Other_V
				    WHERE wmsOrder=@wmsOrder;
				    SET @Errors=@Errors+@@ERROR;
				    --写入其他出库单明细表
				    INSERT INTO F10BMS.dbo.IMS_OtherDtl(OtherNo,WareHouse,ItemID,Location,PkgQty,SQty,Price,Amt,wmsStockId)
				    SELECT OtherNo,WareHouse,ItemID,Location,PkgQty,SQty,PPrice,Amt,wmsStockId
				    FROM WMS_PACK_F10_IMS_OtherDtl_V 
				    WHERE wmsStockId=@wmsOrder;
				    SET @Errors=@Errors+@@ERROR;
				    --审核其他出库单（扣减库存等操作）
				    EXEC F10BMS.dbo.sp_IMSOtherAudit @wmsBillNo,'20';
				    SET @Errors=@Errors+@@ERROR;
				    --更新当前WMS入库单同步状态
				    UPDATE dbo.WMS_Packing SET syncFlag=1,syncTime=GETDATE() WHERE packNo=@wmsOrder;
				    SET @Errors=@Errors+@@ERROR;
			    END
			    IF (@Errors=0)
			    BEGIN
			        COMMIT;
			    END
			    ELSE
			    BEGIN
                    IF @@TRANCOUNT > 0
	                    ROLLBACK;
	                INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','盘点单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo);
			    END
			END TRY
			BEGIN CATCH
                IF @@TRANCOUNT > 0
	                ROLLBACK;
	            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','盘点单[' + @stockNo + ']未能同步到F10',@wmsOrder,@stockNo);
			END CATCH
			DELETE FROM @tmpStock WHERE wmsOrder=@wmsOrder;
		END
		--11.同步发车单到F10发车单
		INSERT INTO @tmpStock(wmsOrder,wmsBillNo)
		SELECT shipNo,carNumberNo
		FROM WMS_F10_Ship_V
		ORDER BY carNumberNo;
		WHILE (EXISTS(SELECT * FROM @tmpStock))
		BEGIN
		    SET @Errors=0;
			--获取第一条数据
			SELECT TOP 1 @wmsOrder=wmsOrder,@wmsBillNo=wmsBillNo
			FROM @tmpStock
			ORDER BY wmsBillNo;
			BEGIN TRY
			    BEGIN TRAN
			    INSERT INTO F10BMS.dbo.SMS_CarNumber(CarNumberNo,CreateDate,BillSts,PFlag,CarRenID,CarNo,CarDate,Delivery,
			        LineID,CreatorID,AuditDate,AuditID)			    
			    SELECT CarNumberNo,CreateDate,BillSts,PFlag,CarRenID,CarNo,CarDate,Delivery,LineID,CreatorID,AuditDate,AuditID
			    FROM WMS_F10_Ship_V
			    WHERE shipNo=@wmsOrder;
			    SET @Errors=@Errors+@@ERROR;
			    INSERT INTO F10BMS.dbo.SMS_CarNumberDtl(CarNumberNo,CustID,SendAddr,StockNo,ZQty,ZAmt,BoxupNo,remarks,IndexXH,
			        PartQty,AllotNo,BillNo,BillType,LinkMan,Phone,ExpressNo,PostFee)
			    SELECT CarNumberNo,CustID,SendAddr,StockNo,ZQty,ZAmt,BoxupNo,remarks,IndexXH,PartQty,AllotNo,
			        BillNo,BillType,LinkMan,Phone,ExpressNo,PostFee
			    FROM WMS_F10_ShipDtl_V
			    WHERE shipNo=@wmsOrder;
			    SET @Errors=@Errors+@@ERROR;
			    --审核其他出库单（扣减库存等操作）
                EXEC F10BMS.dbo.sp_AfterSMS42Audit @wmsBillNo,'20';
                SET @Errors=@Errors+@@ERROR;
			    UPDATE YiWms.dbo.WMS_Ship SET syncFlag=1,syncTime=GETDATE() WHERE shipNo=@wmsOrder;
			    SET @Errors=@Errors+@@ERROR;
			    IF (@Errors=0)
			    BEGIN
			        COMMIT;
			    END
			    ELSE
			    BEGIN
                    IF @@TRANCOUNT > 0
	                    ROLLBACK;
	                INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                    VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','发车单[' + @stockNo + ']未能同步到F10',@wmsOrder,@wmsBillNo);
			    END
			END TRY
			BEGIN CATCH
                IF @@TRANCOUNT > 0
	                ROLLBACK;
	            INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
                VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'up_SyncProcessToF10','YI_WMS_TO_F10_SYNC_ERROR','发车单[' + @stockNo + ']未能同步到F10',@wmsOrder,@wmsBillNo);			
			END CATCH
			DELETE FROM @tmpStock WHERE wmsOrder=@wmsOrder;
		END
	END
	--释放同步作业锁定
	UPDATE dbo.SAM_Store SET isLocked=0 WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncProcessToF10';
END








go

