
/*==============================================================*/
/* View: WMS_Putaway_V                                          */
/*==============================================================*/
CREATE view [dbo].[WMS_Putaway_V] as
SELECT p.putawayNo,p.billType,CASE p.billType WHEN 'S200' THEN '退货上架' 
                                              WHEN 'P100' THEN '采购上架' 
                                              WHEN 'D100' THEN '调拨上架' 
                                              WHEN 'G100' THEN '赠品上架'
                                              WHEN 'O200' THEN '其他上架' END AS billTypeDesc,
    CASE p.billType WHEN 'S200' THEN (SELECT TOP 1 thirdPartyNo FROM dbo.SAD_Return WHERE returnNo=p.stockNo)
					ELSE (SELECT TOP 1 mergeNo FROM dbo.PMS_Stock WHERE stockNo=p.stockNo) END AS orderBillNo,
	p.stockNo,p.billNo,p.partnerId,pr.partnerNo,pr.partnerName,pr.partnerSpell,pr.shortName,
	p.companyId,p.ownerId,p.warehouseId,w.warehouseNo,w.warehouseName,p.regionId,r.regionNo,r.regionDesc,
	p.unitLevel,CASE p.unitLevel WHEN 'CS' THEN '整箱' WHEN 'EA' THEN '散件' END AS unitDesc,p.ioState,
	CASE p.ioState WHEN 20 THEN '待上架' WHEN 25 THEN '部分上架' WHEN 30 THEN '全部上架' END AS ioStateName,
	p.putawayId,u1.userNick AS putawayName,CONVERT(VARCHAR(20),p.putawayTime,120) AS putawayTime,p.isLocked,
	p.lockerId,u2.userNick AS lockerName,CONVERT(VARCHAR(20),p.lockedTime,120) AS lockedTime,p.createTime,
	p.creatorId,u3.userNick AS creatorName
FROM dbo.WMS_Putaway p 
	INNER JOIN dbo.BAS_Warehouse w ON p.warehouseId=w.warehouseId
	LEFT JOIN dbo.BAS_Region r ON p.regionId=r.regionId
	LEFT JOIN dbo.BAS_Partner pr ON p.partnerId=pr.partnerId
	LEFT JOIN dbo.SAM_User u1 ON p.putawayId=u1.userId
	LEFT JOIN dbo.SAM_User u2 ON p.lockerId=u2.userId
	LEFT JOIN dbo.SAM_User u3 ON p.creatorId=u3.userId

go

