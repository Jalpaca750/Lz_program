

/* content:上架
  persion:wJ
  date 2016-10-24 
  
  ----------------------------------------------------------------
  修改时间:2017-02-14 10:24
  修改内容:1,加入审核成功后 删除预分配表中的数据,IMS_BOOK  
           2,不插入VIEWORDER 列
           3,状态值
  修改人员:ZDY
  ----------------------------------------------------------------
  修改时间:2017-02-27
  修改内容:上架时候第一次新增时候 把货位的库区regionid 插入
  修改人员:ZDY
  ----------------------------------------------------------------
*/

CREATE PROC [dbo].[proc_Audit_Shelves]
(
    @StockList dbo.Shelves_Type READONLY,
    @operatorId varchar(32),
    @putawayTime DATETIME
)
AS BEGIN TRAN
DECLARE @StockId VARCHAR(32),@eId VARCHAR(32),@itemId VARCHAR(32),@receiveQty DECIMAL(20,6),@warehouseId VARCHAR(32),@companyId VARCHAR(32),@lotNo VARCHAR(32),@locationNo VARCHAR(32),@StockNew INT
DECLARE @onhandQty DECIMAL(20,6)
DECLARE @price DECIMAL(20,6),@totalFee DECIMAL(20,6)
DECLARE @taxrate DECIMAL(20,6),@taxPrice DECIMAL(20,6),@fee DECIMAL(20,6),@IMSStockID VARCHAR(32)
DECLARE @errorSun int =0,@viewOrder INT=0
-------库区参数
DECLARE @regionId varchar(32)=''
---------更新货位批次------
UPDATE a SET a.locationNo=isnull(b.locationNo,'') FROM PMS_StockDetail a
INNER JOIN @StockList b ON a.stockId=b.stockId 
WHERE a.stockId IN(SELECT stockId FROM @StockList)
SET @errorSun=@errorSun+@@ERROR
---------更新货位------
DECLARE cursor1 cursor FOR 
SELECT  b.price,b.taxrate,b.price,b.fee,b.totalFee,b.companyId, b.stockId,b.eId,
b.ItemId,b.receiveQty,b.warehouseId,b.lotNo,b.locationNo,
CASE WHEN s.itemId IS NULL THEN 1 ELSE 0 END AS StockNew,isnull(s.onhandQty,0.0),
s.stockId AS IMSStockID
FROM @StockList a 
LEFT JOIN PMS_StockDetail b ON a.stockId=b.stockId
LEFT JOIN IMS_Stock s ON b.companyId=s.companyId And b.eId=s.eId AND b.itemId=s.itemId AND isnull(b.locationNo,'')=isnull(s.locationNo,'') AND isnull(b.lotNo,'')=isnull(s.lotNo,'') 
OPEN cursor1
FETCH next from cursor1 INTO @price,@taxrate,@taxPrice,@fee,@totalFee,@companyId,@StockId,@eId,@itemId,@receiveQty,@warehouseId,@lotNo,@locationNo,@StockNew,@onhandQty,@IMSStockID
WHILE @@fetch_status=0 
BEGIN
     --获取库区
    select @regionId=regionId from BAS_Location where companyId=@companyId and warehouseId=@warehouseId and locationNo=@locationNo
	SET @viewOrder=@viewOrder+1
	----写入流水账开始-----
	INSERT INTO IMS_Book(
	[bookId],[ioType],[companyId],[billId],[billNo],[billCode],[objectId],[warehouseId],
	[lotNo],[locationNo],[eId],[itemId],[befQty],[taxFlag],
	[discount],[discountFee],[ioQty],[price],[fee],[taxFee],[afterQty],[handlerId],[deptId],[createTime],
	[creatorId],[auditorId],[auditTime],[memo])
	select  REPLACE(NEWID(),'-',''),[ioType],a.companyId,a.stockId AS billId,a.stockno AS billNo,a.billNo AS billCode,supplierId as objectId,a.warehouseId,
	isnull(a.lotNo,''),isnull(a.locationNo,''),a.eId,a.itemId,@onhandQty AS befQty,a.taxFlag,
	a.discount,a.discountFee,a.receiveQty,a.price,a.fee,a.taxFee,Isnull(a.receiveQty,0.0)+isnull(@onhandQty,0.0) AS afterQty,a.handlerId,a.deptId,GETDATE(),
	@operatorId AS creatorId,@operatorId AS auditorId, GETDATE() as auditTime,''
	FROM PMS_StockDetail_V a
	where a.stockId=@stockId;
	set @errorSun=@errorSun+@@ERROR
	----写入流水账结束-----
	IF @StockNew=1
		BEGIN
			----------------新增数据-----------------------
			INSERT INTO IMS_Stock(
				    stockId,
				    onhandQty,
				    companyId,
				    warehouseId,
				    lotNo,
				    locationNo,
				    eId,itemId,price,taxrate,taxPrice,fee,totalFee,lastITime,lastIPrice,lastITaxPrice,regionId)
			VALUES( LOWER(REPLACE(NEWID(),'-','')),
					@onhandQty+@receiveQty,
					@companyId,
					@warehouseId,
					@lotNo,
					@locationNo,
					@eId,@itemId,@price,@taxrate,@taxPrice,@fee,@totalFee,GETDATE(),@price,@taxPrice,@regionId);
		SET @errorSun=@errorSun+@@ERROR
		----------------新增数据结束-----------------------
		END
	ELSE
		BEGIN
			UPDATE IMS_Stock SET onhandQty =@onhandQty+@receiveQty,lastITime=GETDATE(),lastIPrice=@price,lastITaxPrice=@taxPrice  WHERE stockId=@IMSStockID
			SET @errorSun=@errorSun+@@ERROR
		END
		
----库房总帐-----
UPDATE a SET a.onhandQty=ISNULL(a.onhandQty,0.0)+ISNULL(b.receiveQty,0.0),
             a.taxPrice=CASE WHEN isnull(a.onhandQty,0)+ISNULL(b.receiveQty,0.0)=0 THEN a.taxPrice ELSE (ISNULL(a.totalFee,0.0)+ISNULL(b.totalFee,0.0))/((isnull(a.onhandQty,0)+ISNULL(b.receiveQty,0.0))) END,
             a.totalFee=ISNULL(a.totalFee,0.0)+ISNULL(b.totalFee,0.0),
             a.price=CASE WHEN isnull(a.onhandQty,0)+ISNULL(b.receiveQty,0.0)=0 THEN a.price ELSE (ISNULL(a.Fee,0.0)+ISNULL(b.Fee,0.0))/((isnull(a.onhandQty,0)+ISNULL(b.receiveQty,0.0))) END,
             a.fee =ISNULL(a.fee,0.0) + ISNULL(b.fee,0.0),
             a.lastITime=GETDATE(),
             a.lastITaxPrice= b.Price,
             a.lastIPrice=b.price
FROM IMS_Ledger a INNER JOIN PMS_StockDetail b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId
WHERE b.stockId=@stockId
set @errorSun=@errorSun+@@ERROR
-----不存在则插入-------
INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,price,taxrate,taxPrice,fee,totalFee,maxDays,minDays,maxQty,minQty,stabilityRate,lastITime,lastIPrice,lastITaxPrice)
SELECT replace(NEWID(),'-','') ,a.companyId,a.warehouseId,a.eId,a.itemId,a.receiveQty,0,
       price,a.taxrate,
       a.price,
       a.fee,a.totalFee,0,0,0,0,0,GETDATE(),
       a.price,
       a.Price
FROM PMS_StockDetail a WHERE a.stockId=@stockId AND NOT EXISTS(SELECT 1 FROM IMS_Ledger b WHERE a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId)
set @errorSun=@errorSun+@@ERROR
----库房总帐结束-----

-------更新主库存-------
UPDATE a SET onhandQty=@onhandQty+@receiveQty FROM BAS_Item AS a WHERE companyId=@companyId AND itemId=@itemId
SET @errorSun=@errorSun+@@ERROR

FETCH NEXT from cursor1 INTO @price,@taxrate,@taxPrice,@fee,@totalFee,@companyId,@StockId,@eId,@itemId,@receiveQty,@warehouseId,@lotNo,@locationNo,@StockNew,@onhandQty,@IMSStockID
END
CLOSE  cursor1
DEALLOCATE  cursor1
/*
CASE a.ioState WHEN 0 THEN '已作废' 
                     WHEN 10 THEN '待审核' 
                     WHEN 20 THEN '已审核' 
                     WHEN 25 THEN '部分上架'
                     WHEN 30 THEN '全部上架' END AS stateName, 
*/
UPDATE PMS_StockDetail SET ioState=30,
putawayId=@operatorId,putawayTime=@putawayTime WHERE stockId IN(SELECT stockId FROM @StockList)
SET @errorSun=@errorSun+@@ERROR

UPDATE PMS_Stock SET ioState=(
	SELECT CASE WHEN SUM(temp.isfinnish) > 0 THEN 25 ELSE 30 END  FROM
	(
		SELECT CASE WHEN ioState=20 THEN 1 ELSE 0 END AS isfinnish 
		FROM PMS_StockDetail 
	    WHERE stockNo=PMS_Stock.stockNo 
	)temp WHERE stockNo=PMS_Stock.stockNo
) 
WHERE stockNo IN(SELECT DISTINCT stockNo FROM PMS_StockDetail WHERE stockId IN(SELECT stockId FROM @StockList))

SET @errorSun=@errorSun+@@ERROR
------删除预分配表中的数据
delete  IMS_Allocate where stockId in (select stockId from @StockList)
---报错回滚----
IF @errorSun<>0  ROLLBACK TRAN;
ELSE COMMIT TRAN;







go

