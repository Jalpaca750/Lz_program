-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-02-06>
-- Description:	<Description:审核销售退货单>
--      Wang_jun 2017-05-14日发现销售退货PC端上架数据没有更新WMS_Putaway状态，
--      从而找到前面退货重复上架的真正原因；Frank.He修正
-- =============================================

CREATE PROCEDURE [dbo].[up_Audit_SalesReturn]
(
    @returnNo VARCHAR(32),		--退货单号
	@operatorId VARCHAR(32)		--操作员
)
AS
BEGIN
	DECLARE @companyId VARCHAR(32),			--公司Id
			@billNo VARCHAR(32),			--退货单号
			@warehouseId VARCHAR(32),		--仓库Id
			@customerId VARCHAR(32),		--客户Id
			@createTime DATETIME,			--制单时间
			@creatorId VARCHAR(32),			--制单人Id
			@handlerId VARCHAR(32),			--经办人Id
			@deptId VARCHAR(32),			--经办部门Id
			@memo VARCHAR(2000),			--主表备注
			@ioType VARCHAR(32),			--入出库类型（S200-销售退货单）
			@taxFlag INT,					--是否含税（默认含税）
			@returnId VARCHAR(32),			--明细Id
			@eId VARCHAR(32),				--主商品Id
			@itemId VARCHAR(32),			--SkuId			
			@returnQty DECIMAL(20,6),		--退货数量
			@regionId VARCHAR(32),			--库区
			@lotNo VARCHAR(32),				--批次号
			@locationNo VARCHAR(32)			--库位			
	--此处可用于计算成本
	DECLARE @befQty DECIMAL(20,6),			--出入库前数量
			@flowId VARCHAR(32),			--上架清单Id
			@auditTime DATETIME				--审核时间
	--审核时间
	SET @auditTime=GETDATE();
	BEGIN TRY
		BEGIN TRANSACTION
		--主表信息		
		SELECT @billNo=billNo,@companyId=companyId,@warehouseId=warehouseId,@customerId=customerId,@ioType=ioType,
			@taxFlag=taxFlag,@createTime=createTime,@creatorId=creatorId,@handlerId=handlerId,@deptId=deptId,@memo=memo
		FROM SAD_Return 
		WHERE returnNo=@returnNo
	
		DECLARE myCursor CURSOR
		FOR SELECT b.flowId,a.returnId,a.eId,a.itemId,b.lotNo,b.locationNo,
				CASE b.unitLevel WHEN 'EA' THEN b.putQty WHEN 'CS' THEN b.putQty*b.pkgRatio END
			FROM SAD_ReturnDetail a INNER JOIN WMS_PutawayDetail b ON a.returnId=b.stockId
			WHERE a.returnNo=@returnNo
			ORDER BY a.viewOrder	
		OPEN myCursor
		FETCH NEXT FROM myCursor INTO @flowId,@returnId,@eId,@itemId,@lotNo,@locationNo,@returnQty
		WHILE @@FETCH_STATUS=0
		BEGIN	
			--处理商品库存
			UPDATE BAS_Item SET onhandQty=ISNULL(onhandQty,0.0)+@returnQty WHERE itemId=@itemId;
			--处理IMS_Ledger表
			--如果表中没有数据，则新增一条记录
			IF EXISTS(SELECT 1 FROM IMS_Ledger WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId)
				UPDATE IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)+@returnQty,lastITime=@auditTime
				WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
			ELSE
				INSERT INTO IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastITime)
				VALUES(REPLACE(NEWID(),'-',''),@companyId,@warehouseId,@eId,@itemId,@returnQty,0.0,@auditTime);
			--处理IMS_Stock表
			--如果表中没有数据，则直接新增一条
			IF EXISTS(SELECT 1 FROM IMS_Stock WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId)
				BEGIN
					SELECT @befQty=onhandQty
					FROM IMS_Stock
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId;							
					UPDATE IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)+@returnQty,lastITime=@auditTime
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND ISNULL(lotNo,'')=ISNULL(@lotNo,'') AND ISNULL(locationNo,'')=ISNULL(@locationNo,'') AND itemId=@itemId;
				END
			ELSE
				BEGIN
					SET @befQty=0.0;
					SELECT @regionId=regionId
					FROM BAS_Location 
					WHERE companyId=@companyId AND warehouseId=@warehouseId AND locationNo=@locationNo;							
					INSERT INTO IMS_Stock(stockId,companyId,warehouseId,regionId,locationNo,lotNo,eId,itemId,onhandQty,allocQty,lastITime)
					VALUES(REPLACE(NEWID(),'-',''),@companyId,@warehouseId,@regionId,@locationNo,@lotNo,@eId,@itemId,@returnQty,0.0,@auditTime);							
				END				
			--处理IMS_Book表
			INSERT INTO IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,eId,itemId,
				befQty,ioQty,afterQty,handlerId,deptId,createTime,creatorId,auditTime,auditorId,memo)
			VALUES(REPLACE(NEWID(),'-',''),@ioType,@companyId,@returnId,@returnNo,@billNo,@customerId,@warehouseId,ISNULL(@lotNo,''),ISNULL(@locationNo,''),@eId,@itemId,
				@befQty,@returnQty,ISNULL(@befQty,0.0)+ISNULL(@returnQty,0.0),@handlerId,@deptId,@createTime,@creatorId,@auditTime,@operatorId,@memo);
			--删除预分配表
			DELETE FROM IMS_Allocate WHERE allocId=@flowId;
			--上架完成  上架单状态更改
			UPDATE WMS_PutawayDetail SET ioState=30,putawayId=@operatorId,putawayTime=GETDATE() WHERE flowId=@flowId;
			FETCH NEXT FROM myCursor INTO @flowId,@returnId,@eId,@itemId,@lotNo,@locationNo,@returnQty
		END
		CLOSE myCursor
		DEALLOCATE myCursor
		
		--更新上架单主单
		UPDATE WMS_Putaway set putawayId=@operatorId,putawayTime=GETDATE(),ioState=30 WHERE stockNo=@returnNo
		--更新退货单状态
		UPDATE SAD_Return SET ioState=30,editTime=@auditTime,editorId=@operatorId 
		WHERE returnNo=@returnNo
		COMMIT
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END CATCH
END
go

