-- =============================================
-- Author:		<Author: 王军>
-- Create date: <Create Date:2017-09-29 17:27>
-- Description:	<Description:生成复盘计划> 
--      1.更新盘点时刻表的盘点数量(realQty)
--      2.如果盘点时刻表存在盈亏数据，则生成复盘计划                        
--      3.盘点单与盘点录入表状态更新为已完成
-- =============================================
CREATE PROCEDURE [dbo].[proc_CreateCheckPoint_Again]
(
    @opointId VARCHAR(32),						--盘点单Id
    @companyId VARCHAR(32),						--公司Id
    @operatorId varchar(32)						--操作员Id
)
AS 
BEGIN
	DECLARE @pointNo VARCHAR(32),				--盘点期号
	        @parentId VARCHAR(32),              --原始盘点Id
			@warehouseId VARCHAR(32),			--仓库Id
			@regionId VARCHAR(32),				--库区Id
			@locationWay VARCHAR(10),			--通道
			@inventory INT,						--未盘点到商品处理方式 0,保持原值;1,库存归零
			@checkState INT;					--当前盘点设置状态 0-已作废；10-待盘点；20-盘点中；30-已完成
	DECLARE @tmpStock TABLE(stockId VARCHAR(32),pointId VARCHAR(32),companyId VARCHAR(32),ownerId VARCHAR(32),warehouseId VARCHAR(32),regionId VARCHAR(32),locationWay VARCHAR(10),lotNo VARCHAR(32),locationNo VARCHAR(32),eId VARCHAR(32),itemId VARCHAR(32),onhandQty DECIMAL(20,6),plQty DECIMAL(20,6),realQty DECIMAL(20,6),pkgRatio INT,YKFlag INT)
	DECLARE @npointId VARCHAR(32)=LOWER(REPLACE(NEWID(),'-',''));
	DECLARE @createTime DATETIME=GETDATE();
	--清除当前操作过程中的错误信息
	DELETE FROM SAM_Error WHERE companyId=@companyId AND creatorId=@operatorId AND funCode='proc_CreateCheckPoint_Again';
	--盘点设置
	SELECT @pointNo=pointNo,@warehouseId=warehouseId,@inventory=inventory,@checkState=checkState,@parentId=ISNULL(parentId,'-1')
	FROM IMS_CheckPoint
	WHERE pointId=@opointId;
	IF (ISNULL(@parentId,'')='-1' OR ISNULL(@parentId,'')='')
	    SET @parentId=@opointId;	    
	--盘点录入单据状态
	IF EXISTS(SELECT 1 FROM IMS_Check WHERE pointId=@opointId AND billState=10) 
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'proc_CreateCheckPoint_Again','YI_INV_CHECK_WAITING_COUNT','盘点尚未完成，操作无效！',@opointId,@pointNo);
		RETURN;
	END
	--未盘点
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@opointId AND checkState=10) OR (NOT EXISTS(SELECT 1 FROM IMS_Check WHERE pointId=@opointId))
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'proc_CreateCheckPoint_Again','YI_INV_CHECK_WAITING_COUNT','盘点尚未进行，操作无效！',@opointId,@pointNo);
		RETURN;
	END
	--已盘点
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@opointId AND checkState=30)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'proc_CreateCheckPoint_Again','YI_INV_CHECK_AUDITED','盘点计划已经盘点完成，操作无效！',@opointId,@pointNo);
		RETURN;
	END
	--已盘点
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@opointId AND checkState=0)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'proc_CreateCheckPoint_Again','YI_INV_CHECK_CLOSED','盘点计划已经作废，操作无效！',@opointId,@pointNo);
		RETURN;
	END
	BEGIN TRY
		BEGIN TRANSACTION
		--盘点完成自己签出的计划（防止并发）
		UPDATE IMS_CheckPoint SET checkState=30,editTime=@createTime,editorId=@operatorId WHERE pointId=@opointId AND checkState=20 AND lockerId=@operatorId;
		if (@@ROWCOUNT>0)
		BEGIN
			--统计盘点数据(@inventory:0,保持原值;1,库存归零)
			UPDATE cs SET cs.realQty = CASE @inventory WHEN 0 THEN ISNULL(tmp.realQty,ISNULL(cs.onhandQty,0.0)) ELSE ISNULL(tmp.realQty,0.0) END
			FROM dbo.IMS_CheckStock cs LEFT JOIN
				(SELECT a.companyId,a.warehouseId,b.lotNo,b.locationNo,b.itemId,SUM(b.actQty) AS realQty
				 FROM dbo.IMS_Check a 
					INNER JOIN dbo.IMS_CheckDetail b ON a.checkNo=b.checkNo 
				 WHERE (a.pointId=@opointId) AND (a.billState=20)
				 GROUP BY a.companyId,a.warehouseId,b.lotNo,b.locationNo,b.itemId
				) tmp ON cs.companyId=tmp.companyId AND cs.warehouseId=tmp.warehouseId AND ISNULL(cs.lotNo,'')=ISNULL(tmp.lotNo,'') AND ISNULL(cs.locationNo,'')=ISNULL(tmp.locationNo,'') AND cs.itemId=tmp.itemId
			WHERE cs.pointId=@opointId;
			--盈亏数据
			INSERT INTO @tmpStock(stockId,pointId,companyId,warehouseId,ownerId,regionId,locationWay,lotNo,locationNo,eId,itemId,onhandQty,plQty,realQty,pkgRatio,YKFlag)
			SELECT cs.stockId,cs.pointId,cs.companyId,cs.warehouseId,bi.ownerId,cs.regionId,loc.locationWay,ISNULL(cs.lotNo,''),ISNULL(cs.locationNo,''),cs.eId,cs.itemId,
				cs.onhandQty,ISNULL(cs.realQty,0.0)-ISNULL(cs.onhandQty,0.0) AS plQty,ISNULL(cs.realQty,0.0) AS realQty,bi.pkgRatio,
				CASE WHEN ISNULL(cs.realQty,0.0)-ISNULL(cs.onhandQty,0.0)>0 THEN 1 ELSE 0 END
			FROM dbo.IMS_CheckStock cs 
				INNER JOIN dbo.BAS_Item bi ON cs.itemId=bi.itemId 
				INNER JOIN dbo.BAS_Location loc ON cs.companyId=loc.companyId AND cs.warehouseId=loc.warehouseId AND cs.locationNo=loc.locationNo
			WHERE (cs.pointId=@opointId) AND (ISNULL(cs.realQty,0.0)-ISNULL(cs.onhandQty,0.0)!=0.0);
			--更新盘点单状态
			UPDATE IMS_Check SET billState=30,auditTime=@createTime,auditorId=@operatorId,editTime=@createTime,editorId=@operatorId,
				thirdSyncFlag=-1,memo='生成复盘计划，当前盘点单无需同步    ' + ISNULL(memo,'')
			WHERE pointId=@opointId;
			--如果没有盘点盈亏数据,则退出
			IF EXISTS(SELECT 1 FROM @tmpStock)
			BEGIN
				----------------生成盘点计划----------
				INSERT INTO IMS_CheckPoint(pointId,pointNo,companyId,warehouseId,startArea,endArea,startOwner,endOwner,startNo,endNo,startItem,endItem,pointDate,startTime,endTime,printNum,inventory,checkData,checkState,parentId,createTime,creatorId,editTime)
				SELECT @npointId,pointNo+'-1',companyId,warehouseId,startArea,endArea,startOwner,endOwner,startNo,endNo,startItem,endItem,pointDate,startItem,endTime,0 AS printNum,inventory,checkData,10,@parentId,GETDATE()AS createTime,@operatorId AS creatorId,GETDATE()
				FROM IMS_CheckPoint 
				WHERE pointId=@opointId;
				--------------生成盘点明细------------------
				INSERT INTO IMS_CheckStock(stockId,pointId,companyId,warehouseId,regionId,lotNo,locationWay,locationNo,eId,itemId,onhandQty,realQty)
				SELECT LOWER(REPLACE(NEWID(),'-','')),@npointId,companyId,warehouseId,regionId,lotNo,locationWay,locationNo,eId,itemId,onhandQty,0
				FROM @tmpStock;
				---------------生成盘点任务------------
				INSERT INTO IMS_CheckTask(taskId,pointId,companyId,warehouseId,regionId,locationWay,taskState)
				SELECT LOWER(REPLACE(NEWID(),'-','')),pointId,companyId,warehouseId,regionId,locationWay,0 
				FROM IMS_CheckStock 
				WHERE pointId=@npointId 
				GROUP BY pointId,companyId,warehouseId,regionId,locationWay;
			END
			ELSE
			BEGIN
				INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
				VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'proc_CreateCheckPoint_Again','YI_INV_CHECK_AGAIN_NOT_DATA','没有需要生成复盘计划的数据！',@opointId,@pointNo);
				RETURN;
			END			
		END
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000),@ErrSeverity int;
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'proc_CreateCheckPoint_Again','YI_INV_CHECK_ERROR',LEFT(@ErrMsg,2000),@opointId,@pointNo);
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END CATCH
END
go

