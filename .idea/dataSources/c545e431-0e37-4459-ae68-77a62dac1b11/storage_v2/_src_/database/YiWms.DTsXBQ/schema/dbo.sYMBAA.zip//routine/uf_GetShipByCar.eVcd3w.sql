
CREATE FUNCTION [dbo].[uf_GetShipByCar]
(
    @companyId VARCHAR(32),
    @deliveryId VARCHAR(32),
    @driverId VARCHAR(32),
    @startDate DATE,
    @endDate DATE    
)
RETURNS TABLE
RETURN
(
    SELECT d.thirdFlag,CASE d.thirdFlag WHEN 0 THEN '自有物流' WHEN 1 THEN '第三方物流' WHEN 2 THEN '虚拟车辆' END AS thirdFlagDesc, 
        a.carId,d.carNumber,a.lineId,l.lineName,
		COUNT(DISTINCT a.shipDate) AS workDays,
    	AVG(t.totalVolumn) AS totalVolumn,
    	AVG(t.totalWeight) AS totalWeight,
    	SUM(t.totalQty) AS totalQty,
    	SUM(t.achieveQty) AS achieveQty,
    	SUM(t.fileQty) AS fileQty,
    	SUM(t.billCount) AS billCount,
    	SUM(t.custCount) AS custCount,
    	AVG(d.maxVolume) AS maxVolume,
    	AVG(CASE d.maxVolume WHEN 0.0 THEN 0.0 ELSE t.totalVolumn/d.maxVolume END) AS useRate
    FROM dbo.WMS_Ship a
    	INNER JOIN (SELECT shipNo,SUM(ISNULL(pkgVolumn,0.0)+ISNULL(lclVolumn,0.0)) AS totalVolumn,
    					SUM(grossWeight) AS totalWeight,COUNT(1) AS billCount,COUNT(DISTINCT customerId) AS custCount,
    					SUM(CASE isInvalid WHEN 0 THEN ISNULL(lclQty,0.0)+ISNULL(pkgQty,0.0) END) AS totalQty,
    					SUM(CASE isInvalid WHEN 0 THEN ISNULL(fileQty,0.0) ELSE 0 END) AS fileQty,
    					SUM(CASE isInvalid WHEN 0 THEN ISNULL(fclQty,0.0) ELSE 0 END) AS achieveQty
    				FROM dbo.WMS_ShipDetail
    				GROUP BY shipNo) t ON a.shipNo=t.shipNo
    	INNER JOIN dbo.BAS_Car d ON a.carId=d.carId
    	LEFT  JOIN dbo.BAS_AddressLine l ON a.lineId=l.lineId
	WHERE (a.companyId=@companyId)
		AND (a.shipDate BETWEEN @startDate AND @endDate)
		AND (@deliveryId='' OR a.deliveryId=@deliveryId)
		AND (@driverId='' OR a.driverId=@driverId)
	GROUP BY d.thirdFlag,a.carId,d.carNumber,a.lineId,l.lineName
)
go

