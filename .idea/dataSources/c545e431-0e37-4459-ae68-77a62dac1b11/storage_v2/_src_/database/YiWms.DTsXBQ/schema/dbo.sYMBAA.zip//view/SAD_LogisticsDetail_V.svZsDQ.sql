

/*==============================================================*/
/* View: BAS_Owner_V                                            */
/*==============================================================*/
--creator：        WJ
--create time：  2020-04-26 日整理 
--快递
CREATE  view [dbo].[SAD_LogisticsDetail_V] as
SELECT a.editTime,d.reportCode,a.editorId, a.expressId, a.expressNo,a.viewOrder,b.stockBillNo,b.createTime,a.boxBillNum,b.stockBillNo+'-'+CAST(a.boxBillNum AS VARCHAR(23)) AS expressOrder,a.packageWeight,c.logisticsName,a.billNo,a.parentNo, b.receiverState,b.receiverCity,b.receiverDistrict,b.receiverAddress,b.receiverState+b.receiverCity+b.receiverDistrict+b.receiverAddress AS fullAddress
,(SELECT '['+c1.itemNo+']'+c1.itemName+'['+CONVERT(nvarchar(20),   CAST(b1.realQty AS INT))+']'+c1.unitName+','

FROM WMS_PickingOrder a1
LEFT JOIN WMS_PickingDetail b1 ON a1.pickingNo=b1.pickingNo AND a1.pickId=b1.pickId
LEFT JOIN BAS_Item c1 ON b1.itemId=c1.itemId
WHERE a1.boxBillNum=a.boxBillNum FOR XML PATH('')) AS allItem
FROM SAD_LogisticsDetail a
LEFT JOIN SAD_Logistics b ON b.expressNo=a.expressNo
LEFT JOIN BAS_Logistics c ON b.logisticsId=c.logisticsId
LEFT JOIN BAS_LogisticsConfig d ON b.logisticsId=d.logisticsId



go

