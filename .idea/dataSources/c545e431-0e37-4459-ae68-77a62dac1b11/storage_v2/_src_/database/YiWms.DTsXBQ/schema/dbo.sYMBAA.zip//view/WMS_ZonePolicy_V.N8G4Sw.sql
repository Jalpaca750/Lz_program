/*==============================================================*/
/* View: WMS_ZonePolicy_V                                       */
/*==============================================================*/
CREATE view [dbo].[WMS_ZonePolicy_V] as
SELECT a.policyId,a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,a.categoryId,
    cat.categoryNo,cat.categoryCName,a.pcsPutRegion,r1.regionNo AS pcsPutRegionNo,
    r1.regionDesc AS pcsPutRegionDesc,a.pcsPutZone,z1.zoneNo AS pcsPutZoneNo,
    z1.zoneDesc AS pcsPutZoneDesc,a.csPutRegion,r2.regionNo AS csPutRegionNo,
    r2.regionDesc AS csPutRegionDesc,a.csPutZone,z2.zoneNo AS csPutZoneNo,
    z2.zoneDesc AS csPutZoneDesc,a.pcsPickRegion,r3.regionNo AS pcsPickRegionNo,
    r3.regionDesc AS pcsPickRegionDesc,a.pcsPickZone,z3.zoneNo AS pcsPickZoneNo,
    z3.zoneDesc AS pcsPickZoneDesc,a.csPickRegion,r4.regionNo AS csPickRegionNo,
    r4.regionDesc AS csPickRegionDesc,a.csPickZone,z1.zoneNo AS csPickZoneNo,
    z1.zoneDesc AS csPickZoneDesc,a.isLocked,a.lockerId,u1.userNick AS lockerName,
    CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,a.creatorID,
    u2.userNick AS creatorName,a.editTime,a.editorId,u3.userNick AS editorName,a.isSelected
FROM WMS_ZonePolicy a
    LEFT JOIN BAS_Category cat ON a.categoryId=cat.categoryId
    LEFT JOIN BAS_Warehouse w ON a.warehouseId=w.warehouseId
    LEFT JOIN BAS_Region r1 ON a.pcsPutRegion=r1.regionId
    LEFT JOIN BAS_Zone z1 ON a.pcsPutZone=z1.zoneId
    LEFT JOIN BAS_Region r2 ON a.csPutRegion=r2.regionId
    LEFT JOIN BAS_Zone z2 ON a.csPutZone=z2.zoneId
    LEFT JOIN BAS_Region r3 ON a.pcsPickRegion=r3.regionId
    LEFT JOIN BAS_Zone z3 ON a.pcsPickZone=z3.zoneId
    LEFT JOIN BAS_Region r4 ON a.csPickRegion=r4.regionId
    LEFT JOIN BAS_Zone z4 ON a.csPickZone=z4.zoneId
    LEFT JOIN SAM_User u1 ON a.lockerId=u1.userId
    LEFT JOIN SAM_User u2 ON a.creatorId=u2.userId
    LEFT JOIN SAM_User u3 ON a.editorId=u3.userId

go

