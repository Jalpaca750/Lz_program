-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-09-20>
-- Description:	<Description:订单复核，并生成装箱清单>       
-- =============================================
CREATE PROCEDURE [dbo].[up_OrderCheck] 
(
	@companyId VARCHAR(32),					--公司Id 
	@isPackage INT,							--1-整件;0-散件
	@pickId VARCHAR(32),					--任务Id
	@pickingNo VARCHAR(32),					--任务No
	@materialFlag INT,						--包装材质
	@cartonId VARCHAR(32),					--包装材料Id
	@deskCode VARCHAR(32),					--工作台
	@operatorId VARCHAR(32)					--操作员Id	
)
AS
BEGIN
	DECLARE @checkAndPackage VARCHAR(200),			--复核打包同时完成1-是;0-否
			@stockNo VARCHAR(32),					--出库单号
			@stockBillNo VARCHAR(32),				--出库单编号
			@customerId VARCHAR(32),				--客户Id
			@lineId VARCHAR(32),					--送货线路
			@regionId VARCHAR(32),					--集货区
			@fclQty DECIMAL(20,6),					--整箱数
			@lclQty DECIMAL(20,6),					--拼箱数
			@packNo VARCHAR(32),					--装箱单No
			@packBillNo VARCHAR(32),				--装箱单编号
			@boxBillNum BIGINT,						--箱码
			@boxNum INT,							--序号	
			@pickerId VARCHAR(32),		            --拣货人
			@pickTime DATETIME;                     --拣货完成时间
	DECLARE @stock TABLE(stockNo VARCHAR(32),stockBillNo VARCHAR(32),lineId VARCHAR(32),cargoArea VARCHAR(32));	
	DECLARE @tmpOrder TABLE(ownerId VARCHAR(32),orderNo VARCHAR(32),orderBillNo VARCHAR(32),boneOrdNo VARCHAR(32)); 
	DECLARE @ownerId VARCHAR(32),@orderNo VARCHAR(32),@orderBillNo VARCHAR(32),@boneOrdNo VARCHAR(32);
	--处理包装材料
	DECLARE @eId VARCHAR(32),@itemId VARCHAR(32),@itemName VARCHAR(200),@locationNo VARCHAR(32),@regId VARCHAR(32),@warehouseId VARCHAR(32),@afterQty DECIMAL(20,6),@ioQty DECIMAL(20,6);
	--复核打包同步进行 ORDER_CHECK_AND_PACKAGE:1-是;0-否；
	SELECT @checkAndPackage=configValue FROM SAM_Config WHERE companyId=@companyId AND configCode='ORDER_CHECK_AND_PACKAGE'; 
	SET @checkAndPackage=CASE ISNULL(@checkAndPackage,'') WHEN '' THEN '1' ELSE ISNULL(@checkAndPackage,'1') END;
	--如果任务复核完成，则直接退出
	IF (@isPackage=1)
	BEGIN
		IF EXISTS(SELECT 1 FROM dbo.WMS_Picking WHERE pickingNo=@pickingNo AND taskState>2)
			RETURN;
	END
	ELSE
	BEGIN
		IF EXISTS(SELECT 1 FROM dbo.WMS_PickingOrder WHERE pickId=@pickId AND taskState>2)
			RETURN;
	END
	BEGIN TRY
		BEGIN TRANSACTION
		--整件验货
		IF (@isPackage=1)
		BEGIN
			--整件任务全部为已打包状态
			UPDATE dbo.WMS_PickingDetail SET pickState=4,actualQty=pickQty WHERE pickingNo=@pickingNo;
			UPDATE dbo.WMS_PickingOrder SET taskState=4,checkerId=@operatorId,checkTime=GETDATE() WHERE pickingNo=@pickingNo;
			UPDATE dbo.WMS_Picking SET taskState=9 WHERE pickingNo=@pickingNo;
			--拣货人员 
			SELECT TOP 1 @pickerId=pickerId,@pickTime=pickTime FROM dbo.WMS_PickingOrder WHERE pickingNo=@pickingNo;
			--当前整件任务对应的出库单
			INSERT INTO @stock(stockNo,stockBillNo,lineId)
			SELECT DISTINCT stockNo,stockBillNo,lineId
			FROM dbo.WMS_PickingOrder
			WHERE pickingNo=@pickingNo;
			--如果出库单只有整件任务，且在一个托盘复核，则集货区域为对应集货区，如果发现出库单还有商品在其他任务，则放带待发区
			WHILE(EXISTS(SELECT 1 FROM @stock))
			BEGIN				
				SELECT TOP 1 @stockNo=stockNo,@lineId=lineId,@stockBillNo=stockBillNo FROM @stock ORDER BY stockBillNo;				
				--获取送货线路对应的集货区(出库单不在当前任务以外的任务中,则单据全部在本任务中出来，直接放集货区）
				IF NOT EXISTS(SELECT 1 FROM dbo.WMS_PickingOrder WHERE stockNo=@stockNo AND pickingNo!=@pickingNo)
					SELECT TOP 1 @regionId=regionId FROM BAS_LineRegion WHERE lineId=@lineId;
				ELSE
					SELECT @regionId='DFQ'; 
				--判断当前出库单是否已经完全复核
				IF NOT EXISTS(SELECT 1 FROM dbo.WMS_PickingOrder WHERE stockNo=@stockNo AND taskState<3)
				BEGIN
					UPDATE dbo.SAD_Stock SET taskState=60,auditTime=GETDATE(),auditorId=@operatorId,
					                         reviewTime=GETDATE(),reviewerId=@operatorId,
					                         pickingId=@pickerId,pickingTime=@pickTime 
					WHERE stockNo=@stockNo;
					--2018-01-18日增加对F10状态的更新以及分拣数量的处理 V1.2.1 开始
					--如果出库单中的分拣数量小于了出库数量，则需要更新订单数据
					IF EXISTS(SELECT 1 FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo AND ISNULL(StockQty,0.0)-ISNULL(pickQty,0.0)>0.0)
					BEGIN
						UPDATE a SET a.shipQty=b.pickQty
						FROM dbo.SAD_OrderDetail a 
							INNER JOIN dbo.SAD_StockDetail b ON a.orderId=b.orderId
						WHERE b.stockNo=@stockNo AND ISNULL(b.StockQty,0.0)-ISNULL(b.pickQty,0.0)>0.0;
						--更新对应订单为部分下达状态（启用合并订单功能时，此处需修改）
						UPDATE dbo.SAD_Order SEt sdState=25,msgText='实际分拣数量小于订单下达数量，请核对库存并重新下达任务'
						WHERE orderNo IN(SELECT orderNo FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo AND ISNULL(StockQty,0.0)-ISNULL(pickQty,0.0)>0.0); 
					END
					--2018-01-18日增加对F10状态的更新以及分拣数量的处理 V1.2.1 结束
					--出库单对应订单
					INSERT INTO @tmpOrder(ownerId,orderNo,orderBillNo,boneOrdNo)
					SELECT ownerId,orderNo,billNo,ISNULL(ordField2,'')
					FROM dbo.SAD_Order
					WHERE orderNo IN(SELECT orderNo FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo);
					WHILE EXISTS(SELECT 1 FROM @tmpOrder)
					BEGIN
						SELECT TOP 1 @ownerId=ownerId,@orderNo=orderNo,@orderBillNo=orderBillNo,@boneOrdNo=boneOrdNo
						FROM @tmpOrder
						ORDER BY orderBillNo;
						--更新F10订单的状态（启用合并订单功能时，此处需修改）
						UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='已复核' WHERE OrderNo=@orderBillNo;					
						--写入订单配送节点表(和Bone平台表对应）（启用合并订单功能时，此处需修改）
						INSERT INTO SAD_OrderAction(stepId,orderNo,orderBillNo,stockNo,wmsStockNo,stockBillNo,[action],actionDesc,actionTime,companyId,ownerId,thirdSyncFlag)
						SELECT LOWER(REPLACE(NEWID(),'-','')),@boneOrdNo,@orderBillNo,@orderNo,@stockNo,@stockBillNo,5,'您的订单已经拣货完成。',GETDATE(),@companyId,@ownerId,0
						WHERE NOT EXISTS(SELECT 1 FROM dbo.SAD_OrderAction WHERE orderNo=@boneOrdNo AND stockNo=@orderNo AND wmsStockNo=@stockNo AND [action]=5);
						--下一个循环
						DELETE FROM @tmpOrder WHERE orderNo=@orderNo;
					END
				END
				--判断当前出库单是否已经完全打包
				IF NOT EXISTS(SELECT 1 FROM dbo.WMS_PickingOrder WHERE stockNo=@stockNo AND taskState<4)
				BEGIN					
					--出库单对应整箱数
					SELECT @fclQty=SUM(pickQty) FROM dbo.WMS_PickingDetail WHERE stockNo=@stockNo AND isPackage=1;
					--出库单对应的拼箱数
					SELECT @lclQty=COUNT(1) FROM dbo.WMS_Packing WHERE stockNo=@stockNo;
					UPDATE dbo.SAD_Stock SET fclCount=CAST(@fclQty AS INT),lclCount=CAST(@lclQty AS INT),taskState=70 WHERE stockNo=@stockNo;						
					--出库单对应订单
					INSERT INTO @tmpOrder(ownerId,orderNo,orderBillNo,boneOrdNo)
					SELECT ownerId,orderNo,billNo,ISNULL(ordField2,'')
					FROM dbo.SAD_Order
					WHERE orderNo IN(SELECT orderNo FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo);
					WHILE EXISTS(SELECT 1 FROM @tmpOrder)
					BEGIN
						SELECT TOP 1 @ownerId=ownerId,@orderNo=orderNo,@orderBillNo=orderBillNo,@boneOrdNo=boneOrdNo
						FROM @tmpOrder
						ORDER BY orderBillNo;
						--更新F10订单的状态（启用合并订单功能时，此处需修改）
						UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='已打包' WHERE OrderNo=@orderBillNo;						
						--写入订单配送节点表(和Bone平台表对应）（启用合并订单功能时，此处需修改）
						INSERT INTO SAD_OrderAction(stepId,orderNo,orderBillNo,stockNo,wmsStockNo,stockBillNo,[action],actionDesc,actionTime,companyId,ownerId,thirdSyncFlag)
						SELECT LOWER(REPLACE(NEWID(),'-','')),@boneOrdNo,@orderBillNo,@orderNo,@stockNo,@stockBillNo,6,'您的订单已经复核打包完成。',GETDATE(),@companyId,@ownerId,0
						WHERE NOT EXISTS(SELECT 1 FROM dbo.SAD_OrderAction WHERE orderNo=@boneOrdNo AND stockNo=@orderNo AND wmsStockNo=@stockNo AND action=6);
						--删除，下一个
						DELETE FROM @tmpOrder WHERE orderNo=@orderNo;
					END
				END
				--更新送货线路
				UPDATE dbo.WMS_PickingOrder SET lineId=@lineId,cargoArea=@regionId WHERE stockNo=@stockNo AND pickingNo=@pickingNo;
				DELETE FROM @stock WHERE stockNo=@stockNo;
			END
			--释放托盘
			UPDATE dbo.WMS_Box SET isFrozen=0 WHERE boxId=ANY(SELECT boxId FROM WMS_PickingOrder WHERE pickingNo=@pickingNo);
		END
		--散件验货
		IF (@isPackage=0)
		BEGIN
			--获取周转箱对应的出库单
			SELECT @stockNo=stockNo,@stockBillNo=stockBillNo,@pickingNo=pickingNo,@boxBillNum=boxBillNum,@pickerId=pickerId,@pickTime=pickTime 
			FROM dbo.WMS_PickingOrder 
			WHERE pickId=@pickId;	
			--客户Id,送货线路，集货区
			SELECT @customerId=customerId,@lineId=lineId FROM dbo.SAD_Stock WHERE stockNo=@stockNo;		
			--获取送货线路对应的集货区(出库单不在当前任务以外的任务中,则单据全部在本任务中出来，直接放集货区）
			IF NOT EXISTS(SELECT 1 FROM dbo.WMS_PickingOrder WHERE stockNo=@stockNo AND pickingNo!=@pickingNo)
				SELECT TOP 1 @regionId=regionId FROM BAS_LineRegion WHERE lineId=@lineId;
			ELSE
				SELECT @regionId='DFQ'; 
			--验货，更新明细为已复核状态
			UPDATE dbo.WMS_PickingDetail SET pickState=3,actualQty=pickQty WHERE pickId=@pickId;
			--更新分拣任务为已复核
			UPDATE dbo.WMS_PickingOrder SET taskState=3,checkerId=@operatorId,checkTime=GETDATE() WHERE pickId=@pickId;				
			--更新出库单状态为已复核（待打包）
			IF NOT EXISTS(SELECT 1 FROM dbo.WMS_PickingOrder WHERE stockNo=@stockNo AND taskState<3)
			BEGIN	
				UPDATE dbo.SAD_Stock SET taskState=60,auditTime=GETDATE(),auditorId=@operatorId,
				                         reviewTime=GETDATE(),reviewerId=@operatorId,
				                         pickingId=@pickerId,pickingTime=@pickTime 
				WHERE stockNo=@stockNo;
				--2018-01-18日增加对F10状态的更新以及分拣数量的处理 V1.2.1 开始
				--如果出库单中的分拣数量小于了出库数量，则需要更新订单数据
				IF EXISTS(SELECT 1 FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo AND ISNULL(StockQty,0.0)-ISNULL(pickQty,0.0)>0.0)
				BEGIN
					UPDATE a SET a.shipQty=b.pickQty
					FROM dbo.SAD_OrderDetail a 
						INNER JOIN dbo.SAD_StockDetail b ON a.orderId=b.orderId
					WHERE b.stockNo=@stockNo AND ISNULL(b.StockQty,0.0)-ISNULL(b.pickQty,0.0)>0.0;
					--更新对应订单为部分下达状态（启用合并订单功能时，此处需修改）
					UPDATE dbo.SAD_Order SEt sdState=25,msgText='实际分拣数量小于订单下达数量，请核对库存并重新下达任务'
					WHERE orderNo IN(SELECT orderNo FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo AND ISNULL(StockQty,0.0)-ISNULL(pickQty,0.0)>0.0); 
				END
				--2018-01-18日增加对F10状态的更新以及分拣数量的处理 V1.2.1 结束
				--出库单对应订单
				INSERT INTO @tmpOrder(ownerId,orderNo,orderBillNo,boneOrdNo)
				SELECT ownerId,orderNo,billNo,ISNULL(ordField2,'')
				FROM dbo.SAD_Order
				WHERE orderNo IN(SELECT orderNo FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo);
				--更新订单状态，写入订单复核节点操作描述
				WHILE EXISTS(SELECT 1 FROM @tmpOrder)
				BEGIN
					SELECT TOP 1 @ownerId=ownerId,@orderNo=orderNo,@orderBillNo=orderBillNo,@boneOrdNo=boneOrdNo
					FROM @tmpOrder
					ORDER BY orderBillNo;
					--更新F10订单的状态（启用合并订单功能时，此处需修改）
					UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='已复核' WHERE OrderNo=@orderBillNo;						
					--写入订单配送节点表(和Bone平台表对应）
					INSERT INTO SAD_OrderAction(stepId,orderNo,orderBillNo,stockNo,wmsStockNo,stockBillNo,[action],actionDesc,actionTime,companyId,ownerId,thirdSyncFlag)
					SELECT LOWER(REPLACE(NEWID(),'-','')),@boneOrdNo,@orderBillNo,@orderNo,@stockNo,@stockBillNo,5,'您的订单已经拣货完成。',GETDATE(),@companyId,@ownerId,0
					WHERE NOT EXISTS(SELECT 1 FROM dbo.SAD_OrderAction WHERE orderNo=@boneOrdNo AND stockNo=@orderNo AND wmsStockNo=@stockNo AND [action]=5);
					--下一个循环
					DELETE FROM @tmpOrder WHERE orderNo=@orderNo;
				END
			END						
			--如果验货打包同时进行
			IF (@checkAndPackage=1)
			BEGIN
				--更新明细为已打包状态
				UPDATE dbo.WMS_PickingDetail SET pickState=4 WHERE pickId=@pickId;
				--更新任务为已打包状态
				UPDATE dbo.WMS_PickingOrder SET taskState=4,packingId=@operatorId,packingTime=GETDATE(),materialFlag=@materialFlag,cartonId=@cartonId WHERE pickId=@pickId;
				--获取当前出库单拼箱数量
				SELECT @lclQty=SUM(CASE isPackage WHEN 0 THEN 1 ELSE 0 END)
				FROM dbo.WMS_PickingOrder
				WHERE stockNo=@stockNo;
				--获取当前出库单整箱数量
				SELECT @fclQty=SUM(pickQty)
				FROM dbo.WMS_PickingDetail
				WHERE stockNo=@stockNo AND isPackage=1;
				--生成装箱单
				SELECT @boxNum=MAX(boxNum) FROM dbo.WMS_Packing WHERE companyId=@companyId AND stockNo=@stockNo;
				SET @boxNum=ISNULL(@boxNum,0)+1;				
				--注释掉下面两行代码，同步打包直接取原始箱号
				SET @packNo=LOWER(REPLACE(NEWID(),'-',''));
				--生成装箱单编号
				EXEC up_CreateCode @companyId,'WMS_Packing',@operatorId,@packBillNo OUTPUT;				
				--写入装箱清单主表
				INSERT INTO dbo.WMS_Packing(packNo,billNo,boxBillNum,companyId,pickId,stockNo,stockBillNo,customerId,lineId,regionId,boxNum,lclCount,fclCount,materialFlag,cartonId,deskCode,packState,packingId,packingTime,printNum,printId,printTime,createTime,creatorId,editTime,editorId)
				VALUES(@packNo,@packBillNo,@boxBillNum,@companyId,@pickId,@stockNo,@stockBillNo,@customerId,@lineId,@regionId,@boxNum,@lclQty,@fclQty,@materialFlag,@cartonId,@deskCode,10,@operatorId,GETDATE(),0,'',NULL,GETDATE(),@operatorId,GETDATE(),@operatorId)
				--写入装箱单明细表
				INSERT INTO dbo.WMS_PackingDetail(packId,packNo,pickingId,pickId,pickingNo,companyId,warehouseId,regionId,lotNo,locationNo,eId,itemId,isPackage,pickQty,packQty,stockId,stockNo,stockBillNo)
				SELECT LOWER(REPLACE(NEWID(),'-','')),@packNo,pickingId,pickId,pickingNo,companyId,warehouseId,regionId,batchNo,locationNo,eId,itemId,isPackage,pickQty,pickQty,stockId,stockNo,stockBillNo
				FROM dbo.WMS_PickingDetail
				WHERE pickId=@pickId;
				--扣减包装材料库存
				if (@materialFlag=10)
				BEGIN
					--包装材料对应扣减临时库位、库区、仓库
					SELECT @warehouseId=warehouseId,@regId=regionId,@locationNo=locationNo FROM dbo.BAS_Worktable WHERE worktableId=@deskCode;
					SET @ioQty=-1.0;
					--包装材料对应商品Id
					SELECT @eId=eId,@itemId=itemId,@itemName=itemName FROM dbo.BAS_Goods_V WHERE itemNo=(SELECT sizeNo FROM dbo.WMS_BoxSize WHERE sizeId=@cartonId);					
					--更新商品库存
					UPDATE dbo.BAS_Item SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty WHERE itemId=@itemId;
					--更新仓库商品库存
					IF EXISTS(SELECT 1 FROM dbo.IMS_Ledger WHERE warehouseId=@warehouseId AND itemId=@itemId)
						UPDATE dbo.IMS_Ledger SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty WHERE warehouseId=@warehouseId AND itemId=@itemId;
					ELSE
						INSERT INTO dbo.IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,allocQty,lastOTime)
						VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@eId,@itemId,@ioQty,0,GETDATE());
					--更新库位商品库存
					IF EXISTS(SELECT 1 FROM dbo.IMS_Stock WHERE warehouseId=@warehouseId AND locationNo=@locationNo AND itemId=@itemId)
						UPDATE dbo.IMS_Stock SET onhandQty=ISNULL(onhandQty,0.0)+@ioQty WHERE warehouseId=@warehouseId AND locationNo=@locationNo AND itemId=@itemId;
					ELSE
						INSERT INTO dbo.IMS_Stock(stockId,companyId,warehouseId,regionId,locationNo,lotNo,eId,itemId,onhandQty,allocQty,onWayQty,lastOTime)
						VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@warehouseId,@regId,@locationNo,'',@eId,@itemId,@ioQty,0,0,GETDATE());
					--更新后库存
					SELECT @afterQty=ISNULL(onhandQty,0.0) FROM dbo.IMS_Stock WHERE warehouseId=@warehouseId AND locationNo=@locationNo AND itemId=@itemId;
					--写入流水账(领用出库)
					INSERT INTO dbo.IMS_Book(bookId,ioType,companyId,billId,billNo,billCode,objectId,warehouseId,lotNo,locationNo,eId,itemId,befQty,ioQty,afterQty,createTime,creatorId,auditTime,auditorId,memo)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),'L100',@companyId,@packNo,@packNo,@packBillNo,@operatorId,@warehouseId,'',@locationNo,@eId,@itemId,@afterQty-@ioQty,@ioQty,@afterQty,GETDATE(),@operatorId,GETDATE(),@operatorId,'出库单['+@stockBillNo+']对应['+@packBillNo+']箱号使用周转箱:'+@itemName);
				END
				--更新出库单状态为已打包（待装车）
				IF NOT EXISTS(SELECT 1 FROM dbo.WMS_PickingOrder WHERE stockNo=@stockNo AND taskState<4)
				BEGIN
					--出库单对应整箱数
					SELECT @fclQty=SUM(pickQty) FROM dbo.WMS_PickingDetail WHERE stockNo=@stockNo AND isPackage=1;
					--出库单对应的拼箱数
					SELECT @lclQty=COUNT(1) FROM dbo.WMS_Packing WHERE stockNo=@stockNo;
					UPDATE dbo.SAD_Stock SET fclCount=CAST(@fclQty AS INT),lclCount=CAST(@lclQty AS INT),taskState=70,
						auditTime=GETDATE(),auditorId=@operatorId,reviewTime=GETDATE(),reviewerId=@operatorId 
					WHERE stockNo=@stockNo;
					--出库单对应订单
					INSERT INTO @tmpOrder(ownerId,orderNo,orderBillNo,boneOrdNo)
					SELECT ownerId,orderNo,billNo,ISNULL(ordField2,'')
					FROM dbo.SAD_Order
					WHERE orderNo IN(SELECT orderNo FROM dbo.SAD_StockDetail WHERE stockNo=@stockNo);
					--更新订单状态，写入订单复核节点操作描述
					WHILE EXISTS(SELECT 1 FROM @tmpOrder)
					BEGIN
						SELECT TOP 1 @ownerId=ownerId,@orderNo=orderNo,@orderBillNo=orderBillNo,@boneOrdNo=boneOrdNo
						FROM @tmpOrder
						ORDER BY orderBillNo;
						--更新F10订单的状态（启用合并订单功能时，此处需修改）
						UPDATE F10BMS.dbo.SMS_Order SET WmsFlag='已打包' WHERE OrderNo=@orderBillNo;						
						--写入订单配送节点表(和Bone平台表对应）
						INSERT INTO SAD_OrderAction(stepId,orderNo,orderBillNo,stockNo,wmsStockNo,stockBillNo,[action],actionDesc,actionTime,companyId,ownerId,thirdSyncFlag)
						SELECT LOWER(REPLACE(NEWID(),'-','')),@boneOrdNo,@orderBillNo,@orderNo,@stockNo,@stockBillNo,6,'您的订单已经复核打包完成。',GETDATE(),@companyId,@ownerId,0
						WHERE NOT EXISTS(SELECT 1 FROM dbo.SAD_OrderAction WHERE orderNo=@boneOrdNo AND stockNo=@orderNo AND wmsStockNo=@stockNo AND [action]=6);
						--下一个循环
						DELETE FROM @tmpOrder WHERE orderNo=@orderNo;
					END
				END
				--释放周转箱
				UPDATE WMS_Box SET isFrozen=0 WHERE boxId=ANY(SELECT boxId FROM WMS_PickingOrder WHERE pickId=@pickId);
			END
			--更新送货线路
			UPDATE dbo.WMS_PickingOrder SET lineId=@lineId,cargoArea=@regionId WHERE pickId=@pickId;
			--更新分拣任务主表状态
			UPDATE dbo.WMS_Picking SET taskState=9 
			WHERE pickingNo=@pickingNo 
				AND NOT EXISTS(SELECT 1 FROM dbo.WMS_PickingOrder WHERE pickingNo=@pickingNo AND taskState<3)
		END
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		--写入错误日志
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()		
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'up_OrderCheck','YI_ORDER_CHECK_ERROR',LEFT(@ErrMsg,2000),'','');
		RAISERROR(@ErrMsg, @ErrSeverity, 1)					
	END CATCH
END


go

