
/*==============================================================*/
/* View: BAS_StaffSize_V                                        */
/*==============================================================*/
create view BAS_StaffSize_V as
--2016-09-19 企业人员规模视图统一修正
SELECT a.staffSizeId,a.staffSizeNo,a.staffSizeName,a.companyId,u1.userNick AS lockerName,
      a.lockerId,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,u2.userNick AS creatorName,
      a.creatorId,a.createTime,u3.userNick AS editorName,a.editorId,a.editTime,a.isSelected
FROM dbo.BAS_StaffSize a LEFT JOIN
      dbo.SAM_User u1 ON a.lockerId=u1.userId LEFT JOIN
      dbo.SAM_User u2 ON a.creatorId=u2.userId LEFT JOIN
      dbo.SAM_User u3 ON a.editorId=u3.userId
go

