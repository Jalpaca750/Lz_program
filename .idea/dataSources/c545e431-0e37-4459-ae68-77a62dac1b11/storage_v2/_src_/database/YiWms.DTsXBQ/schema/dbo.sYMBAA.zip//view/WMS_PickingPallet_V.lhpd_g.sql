/*==============================================================*/
/* View: WMS_PickingPallet_V                                    */
/*==============================================================*/
create view WMS_PickingPallet_V as
SELECT a.pickingNo,SUM(CASE ISNULL(b.palletRatio,0) WHEN 0 THEN 0 ELSE FLOOR(a.fclQty/b.palletRatio) END) AS pclQty
FROM (
        SELECT pickingNo,locationNo,itemId,SUM(pickQty*pkgRatio) AS fclQty
        FROM dbo.WMS_PickingDetail 
        WHERE isPackage=1
        GROUP BY pickingNo,locationNo,itemId
    ) a INNER JOIN BAS_Item b ON a.itemId=b.itemId
GROUP BY a.pickingNo    
go

