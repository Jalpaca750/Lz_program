

CREATE PROCEDURE up_F10OrderPreemption
(    
    @wmsOrder VARCHAR(32),				            --订单单号(WMS系统)
    @companyId VARCHAR(32),	                        --公司Id
    @operatorId VARCHAR(32),				        --WMS用户Id
    @errMsg VARCHAR(2000) OUTPUT                    --错误消息
)
AS
BEGIN
    DECLARE @preFlag INT;                               --预占类型(预占订单处理模式,前台控制:0-只允许预占有库存的商品;1-预占有库存的商品，并为没有库存的商品分配临时储位)
    DECLARE @details Type_SAD_OrderDetail;	            --订单明细(预占)
	--自动化处理预占方式
    SELECT @preFlag=configValue FROM YiWms.dbo.SAM_Config WHERE companyId=@companyId AND configCode='PRE_EMPTION_ORDER_DEAL';
    --预占明细数据
    INSERT INTO @details(orderId,orderNo,warehouseId,itemId,orderQty)
    SELECT a.orderId,a.orderNo,a.warehouseId,a.itemId,a.orderQty
    FROM SAD_OrderDetail AS a
        INNER JOIN F10BMS.dbo.IMS_advance AS b ON CAST(a.contractId AS BIGINT)=b.OrderId
    WHERE a.orderNo=@wmsOrder;    
    --预占库存
    EXEC up_OrderPreemption @preFlag,@wmsOrder,@details,@companyId,@operatorId,@errMsg OUTPUT;
END
go

