
/*==============================================================*/
/* View: WMS_PickingPolicy_V                                    */
/*==============================================================*/
create view WMS_PickingPolicy_V as
SELECT p.policyId,p.policyDesc,p.companyId,p.warehouseId,w.warehouseNo,w.warehouseName,p.ownerId,o.ownerNo,
	o.ownerName,o.shortName,p.viewOrder,p.pickPolicy,s.policyDesc AS pickPolicyDesc,p.targRegion,
	r.regionNo AS targRegionNo,r.regionDesc AS targRegionDesc,p.targLocation,
	p.isPackage,CASE p.isPackage WHEN 10 THEN '件拣货库位' 
								 WHEN 20 THEN '箱拣货库位' 
								 WHEN 30 THEN '混合拣库位' 
								 WHEN 40 THEN '储货位库位' 
								 WHEN 50 THEN '过渡库位' END AS packageDesc,
	p.replenishMode,CASE p.replenishMode WHEN 0 THEN '查找下一个库位' WHEN 1 THEN '生成补货任务' END AS replenishModeDesc, 
	p.pickMode,CASE p.pickMode WHEN 1 THEN '满足优先' WHEN 2 THEN '清仓优先' WHEN 3 THEN '按拣货顺序' END pickModeDesc,
	p.fifoFlag,CASE p.fifoFlag WHEN 1 THEN '先进先出' WHEN 2 THEN '后进先出' END AS fifoFlagDesc,
	p.fifoBy,CASE p.fifoBy WHEN 0 THEN '入库时间' WHEN 1 THEN '过期日期' WHEN 2 THEN '生产日期' ELSE '批次号' END AS fifoByDesc,
	p.orderSource,p.unitLevel,CASE p.unitLevel WHEN 'EA' THEN '散件' WHEN 'CS' THEN '整箱' WHEN 'PL' THEN '整托' ELSE '其他' END AS unitLevelDesc,
	p.isDisable,CASE p.isDisable WHEN 1 THEN '是' ELSE '否' END AS disableName,p.isLocked,p.lockerId,
	u1.userNick AS lockerName,CONVERT(VARCHAR(20),p.lockedTime,120) AS lockedTime,p.createTime,
	p.creatorId,u2.userNick AS creatorName,p.editTime,p.editorId,u3.userNick AS editorName,p.isSelected
FROM dbo.WMS_PickingPolicy AS p 
    INNER JOIN dbo.BAS_Warehouse AS w ON w.warehouseId = p.warehouseId 
    INNER JOIN dbo.BAS_Owner_V AS o ON p.ownerId = o.ownerId 
    LEFT JOIN dbo.BAS_Region AS r ON p.targRegion=r.regionId  
    LEFT JOIN dbo.SAM_Policy AS s ON p.pickPolicy=s.policyId 
    LEFT JOIN dbo.SAM_User AS u1 ON p.lockerId=u1.userId
    LEFT JOIN dbo.SAM_User AS u2 ON p.creatorId=u2.userId 
    LEFT JOIN dbo.SAM_User AS u3 ON p.editorId = u3.userId
go

