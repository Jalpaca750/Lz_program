



--=============================
  -- @创建人: zdy  
  -- @日期:  2016-03-30
  -- @描述:  PDA 补货上架
  -- @最后修改:2017-04-18
--=============================
CREATE Proc  [dbo].[Pda_Proc_Replenish]
(
    @boxBillNum   numeric(10,0),--箱子条码
    @operatorId  varchar(32),--补货人ID
    @companyId   varchar(32)  --公司
)
as 
DECLARE @Flag int ,@errorSum int
DECLARE @locationNo  varchar(100),--货位
        @lotNo varchar(100),      --批次
        @warehouseId varchar(32),  --仓库
        @stockQty   decimal(20,6),  --数量
        @itemId     varchar(32), --商品ID
        @regionId   varchar(32),  --区域ID
        @eId     varchar(32),      --主商品
        @billNo  varchar(32),       --补货任务码
        @replenishId varchar(32),--补货任务ID
        @isPkg      int   ,---是否是整箱
        @pkgQty   decimal(10,2),--整包装数量
        @bulkQty  decimal(10,2), --散包装数量
        @pkgRatio decimal(10,2),  --商品转换率
        @pickingmode int,          --商品拣货方式  0:整箱散件转换，1：散件拣货，2整箱拣货
        @pickId   varchar(32),     --拣货任务主键
        @_PNO VARCHAR(32)=''
begin  tran

---找到关联的补货任务
select @replenishId=stockNo,@pickId=pickId,@_PNO=pickingNo  
from  wms_pickingorder 
where companyId=@companyId and  boxBillNum=@boxBillNum
--补货件数
select  @stockQty=realQty,@itemId=itemId,@eId=eId,@isPkg=isPackage
from   WMS_PickingDetail 
where pickId= @pickId

---==================================================更新补货人==
UPDATE  WMS_PickingOrder SET taskState=6,loadingId=@operatorId,loadingTime=GETDATE()
where pickId=@pickId
---=================================================================
----================================查看数量是否需要转换
select @pickingmode=pickingMode,@pkgRatio=pkgRatio 
from bas_item where itemId=@itemId

/*
if   @isPkg>0 and @pickingmode=0
begin  --如果是按整箱拣货 这个数量必须转变成整件数量
    set @stockQty=@stockQty*@pkgRatio   --转换成整包装
end */
----====================================================
if not exists(select * from IMS_Replenish where replenishId=@replenishId)
begin
   ---如果找不到数据
   set @errorSum=1
end
else if not exists(select * from IMS_Replenish where replenishId=@replenishId and ioState=20)
begin
      ---如果不符合更新条件
    set @errorSum=1
end
else  begin
----=======================================修改上架状态
      
      DECLARE @HadBoxCount int   ---总的没有上架箱子数量
      DECLARE @TASK_PUTWAY_BOX_COUNT INT=0  --任务中的箱子是否都已经上架了
     
       
      ---判断没有上架的箱子的数量
      SELECT   @HadBoxCount=COUNT(pickId) from  WMS_PickingOrder 
      where stockNo=@replenishId and isnull(loadingId,'')=''
     
     if  @HadBoxCount=0  --这里其实不用判断 
     begin   --如果所有的箱子都已经上架了 更新状态
		 update  IMS_Replenish set  ioState=30,putawayId=@operatorId,putawayTime=GETDATE()
		 where replenishId=@replenishId  
		 set @errorSum=@errorSum+@@ERROR
		 ---删除上架预分配表
		 DELETE  IMS_Allocate WHERE allocId=@replenishId
		 set @errorSum=@errorSum+@@ERROR
		 ----把任务状态更新成  9 
     end  
     
      ---如果任务状态都大于20了 那就是都上架了
      SELECT @TASK_PUTWAY_BOX_COUNT=COUNT(replenishId) 
      FROM IMS_Replenish WHERE  replenishId in 
      (
         select stockNo from  WMS_PickingOrder where pickingNo=@_PNO
      )   and  ioState<30
      
     if    @TASK_PUTWAY_BOX_COUNT=0   --如果全部都上架了
     begin
         UPDATE  WMS_Picking SET taskState=9 WHERE pickingNo=@_PNO
		 set @errorSum=@errorSum+@@ERROR
	  END
     /*--------------------------------------------------------------*/
     select   @locationNo=targetLocNo,    --货位
              @lotNo=lotNo,               --批次
              @warehouseId=targetWhId,    --仓库
              @itemId=itemId,              --商品ID 
              @regionId=targetRegId,       --区域
              @eId=eId,                     --主商品ID
              @billNo=billNo        
     from  IMS_Replenish where replenishId=@replenishId  
--===================修改库存Y100==================================    

/*--------------------------------------找库存中商品是否存在---------------------------------------------------------*/  

DECLARE  @IsHad int =1
if not exists(select * from IMS_Stock where  companyId=@companyId and warehouseId=@warehouseId and  itemId=@itemId and isnull(lotNo,'')=isnull(@lotNo,'') and isnull(locationNo,'')=isnull(@locationNo,''))
begin
			---如果库里面没有 进行插入
			insert into  IMS_Stock(stockId,companyId,warehouseId,lotNo,locationNo,eId,itemId,onhandQty,
			allocQty,price,taxrate,taxPrice,fee,totalFee,lastITime,lastIPrice,
			lastITaxPrice,lastOTime,lastOPrice,lastOTaxPrice,regionId,onWayQty)
			values
			(
			   REPLACE(NEWID(),'-',''),@companyId,@warehouseId,@lotNo,@locationNo,@eId,@itemId,
			   0,0,0,17,0,0,0,GETDATE(),0,0,null,0,0,@regionId,0
			)
			 set @errorSum=@errorSum+@@ERROR
			 set @IsHad=0
end 


		    ----如果主表里面没有的
if not exists(select * from IMS_Ledger where companyId=@companyId and warehouseId=@warehouseId and  itemId=@itemId)
begin 
	insert into IMS_Ledger(ledgerId,companyId,warehouseId,eId,itemId,onhandQty,
	allocQty,price,taxrate,taxPrice,
	fee,totalFee,maxDays,minDays,maxQty,
	minQty,stabilityRate,lastITime,lastIPrice,lastITaxPrice,lastOTime,lastOPrice,lastOTaxPrice)
	values(replace(NEWID(),'-',''),@companyId,@warehouseId,@eId,@itemId,0,0,0,17,0,
	0,0,0,0,0,0,0,GETDATE(),0,0,null,0,0)
	 set @errorSum=@errorSum+@@ERROR
end 
-----修改库存
declare @IMS_STOCKID varchar(32),@hadQty decimal(20,6),@resultQty decimal(20,6)

select @IMS_STOCKID=stockId,@hadQty=onhandQty  from IMS_Stock 
where  companyId=@companyId 
and warehouseId=@warehouseId 
and  itemId=@itemId 
and isnull(lotNo,'')=isnull(@lotNo,'') 
and isnull(locationNo,'')=isnull(@locationNo,'')
--赋值
set @resultQty=@hadQty+@stockQty
INSERT INTO IMS_Book(
[bookId],[ioType],[companyId],[billId],[billNo],[billCode],[objectId],[warehouseId],
[lotNo],[locationNo],[eId],[itemId],[befQty],[taxFlag],
[discount],[discountFee],[ioQty],[price],[fee],[taxFee],[afterQty],[handlerId],[deptId],[createTime],
[creatorId],[auditorId],[auditTime],[memo])
values(REPLACE(NEWID(),'-',''),'B100',@companyId,@replenishId,@replenishId,@billNo,@replenishId,
@warehouseId,@lotNo,@locationNo,@eId,@itemId,@hadQty,null,null,null,@stockQty,null,null,null,@resultQty,@operatorId,
null,GETDATE(),@operatorId,@operatorId,GETDATE(),'PDA')
set @errorSum=@errorSum+@@ERROR
----修改库存 onWayQty==补货 @IsHad 1  存在占用 0 不存在占用
update  IMS_Stock set  onWayQty=( case @IsHad when 1 then (onWayQty-@stockQty) else 0 end),
						onhandQty=(onhandQty+@stockQty),
						lastOTime=GETDATE(),
						lastITime=GETDATE()
where  stockId=@IMS_STOCKID

set @errorSum=@errorSum+@@ERROR
---修改总库存
update  IMS_Ledger set  onhandQty=onhandQty+@stockQty,lastOTime=GETDATE(),lastITime=GETDATE()
where   companyId=@companyId and warehouseId=@warehouseId and itemId=@itemId
set @errorSum=@errorSum+@@ERROR


end
if @errorSum>0  
begin
Rollback
end
else begin
commit;
end















go

