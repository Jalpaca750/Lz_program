
/*==============================================================*/
/* View: WMS_Wave_V                                             */
/*==============================================================*/
create view WMS_Wave_V as
SELECT a.waveNo,a.companyId,a.billNo,a.taskState,
    CASE ISNULL(a.taskState,10) WHEN 10 THEN '待拣选' WHEN 20 THEN '已配货' WHEN 30 THEN '已复核' END AS taskStateName,
    a.pickerId,u1.userNick AS pickerName,CONVERT(VARCHAR(20),a.pickerTime,120) AS pickerTime,
    a.checkerId,u2.userNick AS checkerName,CONVERT(VARCHAR(20),a.checkTime,120) AS checkTime,
    a.autoFlag,a.waveFlag,a.isLocked,a.lockerId,u3.userNick AS lockerName,
    CASE ISNULL(a.isLocked,0) WHEN 0 THEN '否' ELSE '是' END AS lockedFlag,
    CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,a.createTime,a.creatorId,
    u4.userNick AS creatorName
FROM WMS_Wave a
    LEFT JOIN SAM_User u1 ON a.pickerId=u1.userId
    LEFT JOIN SAM_User u2 ON a.checkerId=u2.userId
    LEFT JOIN SAM_User u3 ON a.lockerId=u3.userId
    LEFT JOIN SAM_User u4 ON a.creatorId=u4.userId
go

