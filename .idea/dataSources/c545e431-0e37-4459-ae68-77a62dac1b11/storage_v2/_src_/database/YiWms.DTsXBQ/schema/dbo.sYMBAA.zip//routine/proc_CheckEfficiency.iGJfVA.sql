

CREATE Proc  [dbo].[proc_CheckEfficiency](@pointId  varchar(32))
AS
BEGIN
DECLARE @yp INT=1,@sp INT =1,@bl DECIMAL(8,2)=0,@def FLOAT=1,@item int = 0,@aditem int =0,@btime DATETIME=GETDATE(),@etime DATETIME=GETDATE()
DECLARE @pintNo VARCHAR(50),@CheckState INT=10
SELECT @pintNo=pointNo,@checkState=CheckState FROM IMS_CheckPoint WHERE pointId=@pointId
SELECT @etime=MAX(editTime),@btime=MIN(createTime) FROM IMS_Check WHERE pointId=@pointId
IF(LEN(@pintNo)>0) 
BEGIN
 SELECT @yp=COUNT(1) FROM IMS_CheckStock WHERE pointId=@pointId
 SELECT @sp=COUNT(1) FROM IMS_CheckDetail WHERE pointId=@pointId
 SET @bl=CASE WHEN @sp=0 OR @yp=0 THEN 0 ELSE (CAST(@sp as decimal)/CAST(@yp as decimal))*100 END
 SET @def=DATEDIFF(Minute, @btime,@etime)
 SELECT @item= count(1) from(SELECT COUNT(1) r FROM IMS_CheckDetail WHERE pointId=@pointId AND actQty>0 GROUP BY itemId)t
 SELECT @aditem= COUNT(1) FROM(SELECT b.itemId FROM IMS_Adjust a  LEFT JOIN IMS_AdjustDetail b ON a.adjustNo=b.adjustNo WHERE a.pointId=@pointId GROUP BY b.itemId)t
 SELECT @pintNo AS PointNo,                                 ---盘点计划
        @btime AS BeginTime ,                               ---开始时间
        @yp AS Should,                                      ---应盘货位
        @sp AS Actual,                                      ---实盘货位
        @bl AS Percentage,                                  ---完成进度
        CASE WHEN @sp=0 OR @def=0 THEN 0 ELSE CAST(@sp as decimal)/@def END AS Efficiency,            ---盘点效率
        @def UseMinutes ,                                   ---使用分钟
        CASE WHEN @sp=0 OR @def=0 THEN GETDATE() ELSE DATEADD(mi,((@yp-@sp)/(CAST(@sp as decimal)/@def)),GETDATE()) END AS Estimate, ---预计完成
        @item as item,                                      ---盘点商品
        @aditem as aditem,                                  ---差异商品
        @etime AS endTime                                  ---际完成时间                               
END
ELSE
SELECT @pintNo AS PointNo,@btime AS BeginTime ,0 AS Should,0 AS Actual,100 AS Percentage,0 AS Efficiency,0 UseMinutes ,GETDATE() AS Estimate,@item as item,@aditem as aditem
END



go

