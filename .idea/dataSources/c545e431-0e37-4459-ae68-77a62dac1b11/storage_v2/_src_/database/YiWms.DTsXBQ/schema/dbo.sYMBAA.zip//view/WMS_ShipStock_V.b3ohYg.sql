

/*==============================================================*/
/* View: WMS_ShipStock_V                                        */
/*==============================================================*/
CREATE view [dbo].[WMS_ShipStock_V] as
--特殊销售出库单代送货（实施时修改）
SELECT a.StockNo AS billNo,a.StockNo AS stockBillNo,c.customerId,'' AS receiverState,
	'' AS receiverCity,'' AS receiverDistrict,a.SendAddr AS receiverAddress,ISNULL(a.LinkMan,c.LinkMan) AS receiverName,
	ISNULL(a.Phone,c.Phone) AS receiverTel,'' AS receiverMobile,0 AS pkgQty,0 AS fclQty,0.0 AS pkgVolumn,
	a.PartQty AS lclQty,0.0 AS lclVolumn,0 AS fileQty,a.CreateDate,0.0 AS netWeight,0.0 AS grossWeight,
	b.Amt AS TotalFee,a.StockNo AS mergeNo,80 AS billType,0 AS isInvalid,a.remarks,d.EmployeeName AS ServiceName,
	addr.viewOrder AS lineOrder
FROM F10BMS.dbo.SMS_Stock a
    INNER JOIN (SELECT StockNo,SUM(Amt) AS Amt FROM F10BMS.dbo.SMS_StockDtl GROUP BY StockNo) b ON a.StockNo=b.StockNo
	LEFT JOIN F10BMS.dbo.BDM_SendAddress addr ON a.CustID=addr.CustID AND a.SendAddr=addr.SendAddr AND a.LinkMan=addr.LinkMan
	INNER JOIN F10BMS.dbo.WMS_F10_Customer_V c ON a.CustID=c.CustID
	LEFT  JOIN F10BMS.dbo.BDM_Employee d ON a.CreatorID=d.EmployeeID 
WHERE (a.DeptNo='1573' OR a.DeptNo='1363')
	AND (a.BillSts='20' or a.BillSts='25' or a.BillSts='30')
	AND (a.BillType='10') 
	AND (ISNULL(a.CarNumberSts,'')='')
go

