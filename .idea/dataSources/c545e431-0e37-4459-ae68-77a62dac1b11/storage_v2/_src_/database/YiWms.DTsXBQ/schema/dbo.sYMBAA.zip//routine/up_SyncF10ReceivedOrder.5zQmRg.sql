-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-08-22>
-- Description:	<Description:同步F10入库类单据到WMS>
--      @companyId：公司Id
--      @ownerId：业主Id
--      @creatorId：操作员Id
--      @startTime：同步开始时间 yyyy-MM-dd HH:mm:ss格式
--      @endTime：同步截至时间 yyyy-MM-dd HH:mm:ss格式
-- 同步2分钟前未同步过入库类单据
-- =============================================
CREATE Proc  [dbo].[up_SyncF10ReceivedOrder]
(
    @companyId VARCHAR(32),		--公司Id,如果前台调用，需传值，为空时，手动修改这个值
	@ownerId VARCHAR(32),		--业主Id
	@creatorId VARCHAR(32),		--操作员，前天调用的当前用户，后台执行时，可赋值
	@startTime DATETIME,		--同步产品的开始时间（修改时间）
	@endTime DATETIME			--同步产品的截至时间（修改时间）
)
AS
BEGIN
	DECLARE @userId BIGINT;
	DECLARE @purchase TABLE(orderNo VARCHAR(32),orderType INT);	
	DECLARE @orderNo VARCHAR(32),					--采购订单号
			@orderType INT							--采购类单据 11-普通订单；12-应急订单；13-零星采购；14-转场订单；21-调拨申请单;31-赠品入库单;41-其他入库单
	SET @endTime=GETDATE();
	SELECT @userId=employeeId FROM F10BMS.dbo.WMS_F10_User_V WHERE userId=@creatorId;
	--如果接口正在同步中或者接口失效，直接退出
	IF EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10ReceivedOrder' AND isDisable=1)
		RETURN;	
	--开始同步
	BEGIN TRY 	
		BEGIN TRANSACTION
		--如果接口正在同步中，则直接退出
		IF EXISTS(SELECT 1 FROM dbo.SAM_Store WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10ReceivedOrder' AND isLocked=1)
		BEGIN
			COMMIT;
			RETURN;
		END
		--1.锁定同步接口
		UPDATE dbo.SAM_Store SET isLocked=1,lockerId=@creatorId,lockedTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10ReceivedOrder' AND isLocked=0;
		IF (@@ROWCOUNT>0)
		BEGIN
			--1.1获取需要同步的采购订单
			INSERT INTO @purchase(orderNo,orderType)
			SELECT orderNo,OType 
			FROM F10BMS.dbo.PMS_Order 
			WHERE (BillType='采购订单') 
				AND (DeptNo IN(SELECT DeptNo FROM F10BMS.dbo.WMS_Config)) 
				AND (syncFlag=0)
				AND (BillSts='20' OR BillSts='25')
				--AND (DATEDIFF(MI,editTime,GETDATE())>2);		--2分钟前的数据
			--1.2获取调拨入库单数据
			INSERT INTO @purchase(orderNo,orderType)
			SELECT AllotNo,21
			FROM F10BMS.dbo.IMS_Allot
			WHERE (DeptNo_I IN(SELECT DeptNo FROM F10BMS.dbo.WMS_Config))
				AND (BillSts='20' OR BillSts='25')
				AND (syncFlag=0)
				--AND (DATEDIFF(MI,editTime,GETDATE())>2);		--2分钟前的数据				
			--1.3获取赠品入库单
			INSERT INTO @purchase(orderNo,orderType)
			SELECT PresentNo,31
			FROM F10BMS.dbo.IMS_Present
			WHERE (DeptNo IN(SELECT DeptNo FROM F10BMS.dbo.WMS_Config)) 
				AND (BillType='10')
				AND (syncFlag=0)
				AND (BillSts='15')
				--AND (DATEDIFF(MI,editTime,GETDATE())>2);		--2分钟前的数据
			--1.4获取其他入库单
			INSERT INTO @purchase(orderNo,orderType)
			SELECT OtherNo,41
			FROM F10BMS.dbo.IMS_Other 
			WHERE (DeptNo IN(SELECT DeptNo FROM F10BMS.dbo.WMS_Config)) 
				AND (BillType='10')
				AND (syncFlag=0)
				AND (BillSts='15')
				--AND (DATEDIFF(MI,editTime,GETDATE())>2);		--2分钟前的数据
			--2.同步采购类订单数据
			WHILE EXISTS(SELECT 1 FROM @purchase)
			BEGIN
				--取第一个商品
				SELECT TOP 1 @orderNo=orderNo,@orderType=orderType FROM @purchase ORDER BY orderType,orderNo; 
				--删除单据对应的错误数据
				DELETE FROM SAM_Error WHERE companyId=@companyId AND billId=@orderNo;
				--同步
				IF (@orderType=11 OR @orderType=12 OR @orderType=13)
					EXEC F10BMS.dbo.sp_AfterPMS40Audit @orderNo,'20',@userId;
				ELSE IF(@orderType=21)
					EXEC F10BMS.dbo.sp_AfterIMS20Audit @orderNo,'20',@userId;
				ELSE IF(@orderType=31)
					EXEC F10BMS.dbo.sp_AfterIMS60Audit @orderNo,'20',@userId;
				ELSE IF(@orderType=41)
					EXEC F10BMS.dbo.sp_AfterIMS90Audit @orderNo,'20',@userId;
				--删除同步成功的临时单据
				DELETE FROM @purchase WHERE orderNo=@orderNo AND orderType=@orderType;
			END
			--3.释放同步接口
			UPDATE dbo.SAM_Store SET isLocked=0,lockerId='',syncTime=GETDATE() WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10ReceivedOrder';
		END
		COMMIT;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		--释放同步接口
		UPDATE dbo.SAM_Store SET isLocked=0,lockerId='' WHERE companyId=@companyId AND ownerId=@ownerId AND appUrl='up_SyncF10ReceivedOrder';
		SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY();
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END CATCH
END

go

