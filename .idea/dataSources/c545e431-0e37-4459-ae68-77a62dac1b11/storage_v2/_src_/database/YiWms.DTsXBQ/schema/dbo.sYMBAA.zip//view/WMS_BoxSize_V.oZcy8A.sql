
/*==============================================================*/
/* View: WMS_BoxSize_V                                          */
/*==============================================================*/
CREATE view [dbo].[WMS_BoxSize_V] as
SELECT bs.sizeId, bs.companyId, bs.sizeNo, bs.sizeName, bs.boxLength, bs.boxWidth, bs.boxHeight, 
      bs.boxVolume, bs.stdVolume, bs.useRate, bs.boxBearing, bs.boxType, 
      CASE bs.boxType WHEN 1 THEN '周转箱' WHEN 2 THEN '纸箱' WHEN 3 THEN '托盘' END AS boxTypeName,
      bs.boxNumber, bs.onhandQty, bs.isLocked, bs.lockerId, u1.userNick AS lockerName, 
      CONVERT(VARCHAR(20),bs.lockedTime,120) AS lockedTime, bs.createTime, bs.creatorId, 
      u2.userNick AS creatorName, bs.editTime, bs.editorId, u3.userNick AS editorName, 
      bs.isSelected 
FROM dbo.WMS_BoxSize AS bs LEFT OUTER JOIN
      dbo.SAM_User AS u1 ON bs.lockerId = u1.userId LEFT OUTER JOIN
      dbo.SAM_User AS u2 ON bs.creatorId = u2.userId LEFT OUTER JOIN
      dbo.SAM_User AS u3 ON bs.editorId = u3.userId


go

