
/*==============================================================*/
/* View: BAS_Owner_V                                            */
/*==============================================================*/
--creator：        Frank
--create time：  2016-11-18日整理 
--业主视图
create view BAS_Owner_V as
SELECT p.partnerId AS ownerId, p.companyId, p.partnerNo AS ownerNo, p.partnerName AS ownerName, 
      p.shortName, p.partnerSpell AS ownerSpell, p.companyState, a1.areaName AS stateName, p.companyCity, 
      a2.areaName AS cityName,p.companyDistrict, a3.areaName AS districtName, p.companyAddress, p.zip,
      p.parentId, f.invoiceDay, f.affterDelivery, f.payTermLimited, f.payTerm, f.creditLimited, f.creditFee,
      f.priceLimited, f.rebate1, f.rebate2, f.rebate3, f.defPrice, f.befPrice, f.salesId, f.salesName, f.taxFlag,
      f.isTogether, f.currencyId, f.arFee, f.preFee, f.integral, f.assistantId, f.outerId, p.icoUrl, p.logoUrl, 
      p.isRecommend, c.contactName,c.contactTitle,c.officeTel,c.mobileNo,c.email, p.partnerState, p.remarks, 
      p.isSelected
FROM dbo.BAS_Partner AS p LEFT OUTER JOIN
      dbo.BAS_PartnerFinancial_V f ON p.partnerId=f.partnerId LEFT OUTER JOIN
      dbo.BAS_Area AS a1 ON p.companyState = a1.areaId LEFT OUTER JOIN
      dbo.BAS_Area AS a2 ON p.companyCity = a2.areaId LEFT OUTER JOIN
      dbo.BAS_Area AS a3 ON p.companyDistrict = a3.areaId LEFT OUTER JOIN
      (SELECT companyId,partnerId,contactName,contactTitle,officeTel,mobileNo,email,sex
       FROM BAS_Contact 
       WHERE isDefault=1) c ON p.partnerId=c.partnerId
WHERE (p.partnerType = 3)
go

