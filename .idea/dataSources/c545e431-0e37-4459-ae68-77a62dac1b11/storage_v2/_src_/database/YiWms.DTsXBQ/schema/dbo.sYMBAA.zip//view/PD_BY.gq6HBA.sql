




/*==============================================================*/
/* View: PD_BY                                                  */
/*       @editor:张东彦 @at:2017-07-07     @content:添加仓库编码返回 */
/*==============================================================*/
create view [dbo].[PD_BY] as
SELECT o.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,a.adjustDate AS docdate,a.memo AS comments,
	u.userNo AS U_opcode,u.userNick AS U_OPNAME,bi.itemNo AS itemcode,b.viewOrder AS linenum,
	b.ioQty AS quantity,isnull(a.by_thirdSyncFlag,0) AS SC_FLG,'盘盈表' AS YEW_TYPE , W.warehouseNo AS WHNO
FROM dbo.IMS_Adjust a INNER JOIN 
      dbo.IMS_AdjustDetail b ON a.adjustNo=b.adjustNo INNER JOIN
      dbo.BAS_Item bi ON b.itemId=bi.itemId LEFT JOIN 
      dbo.BAS_Owner_V o ON b.ownerId=o.ownerId LEFT JOIN
      dbo.SAM_User u ON a.creatorId=u.userId 
      INNER JOIN BAS_Warehouse W on a.warehouseId=W.warehouseId
WHERE (a.ioState=20) AND (isnull(a.by_thirdSyncFlag,0)=0 or  
isnull(a.by_thirdSyncFlag,0)=2) AND (b.ioQty>0.0)









go

