
/*==============================================================*/
/* View: IMS_Advance_V                                          */
/*==============================================================*/
create view IMS_Advance_V as
SELECT a.advanceId,a.companyId,a.viewOrder,a.orderNo,a.orderBillNo,a.orderId,
    a.customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,p.shortName,
    a.deptId,dept.deptNo,dept.deptName,a.warehouseId,w.warehouseNo,w.warehouseName,
    a.locationNo,a.itemId,bi.itemNo,bi.itemName,bi.itemSpec,bi.colorName,bi.sizeName,
    bi.unitName,a.advQty,b.onhandQty,a.realQty,a.purQty,
    ISNULL(a.advQty,0.0)-ISNULL(a.realQty,0.0)-ISNULL(a.purQty,0.0) AS needPurQty,a.advType,a.creatorId,
    u1.userNick AS creatorName,a.createTime,a.fieldEx01,a.fieldEx02,a.fieldEx03,
    a.fieldEx04,a.fieldEx05,p.ownerId
FROM IMS_Advance a
    INNER JOIN IMS_Ledger b ON a.warehouseId=b.warehouseId AND a.itemId=b.itemId
    INNER JOIN BAS_Partner p ON a.customerId=p.partnerId
    INNER JOIN BAS_Item bi ON a.itemId=bi.itemId
    INNER JOIN BAS_Warehouse w ON a.warehouseId=w.warehouseId
    LEFT  JOIN SAM_User u1 ON a.creatorId=u1.userId
    LEFT  JOIN BAS_Department dept ON a.deptId=dept.deptId
WHERE a.advQty>0.0
go

