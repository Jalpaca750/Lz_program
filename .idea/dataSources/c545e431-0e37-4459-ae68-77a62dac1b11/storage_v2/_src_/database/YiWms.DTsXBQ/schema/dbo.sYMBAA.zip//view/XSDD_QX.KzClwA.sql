
/*==============================================================*/
/* View: XSDD_QX                                                */
/*==============================================================*/
create view XSDD_QX as
SELECT billNo,CASE orderType WHEN 10 THEN '普通订单' 
							 WHEN 20 THEN '调拨申请' 
						     WHEN 30 THEN '经营领用' 
							 WHEN 31 THEN '管理领用' 
							 WHEN 40 THEN '赠品出库' 
							 WHEN 50 THEN '报损报废' END AS orderType
FROM SAD_Order
WHERE sdState=0 AND thirdSyncFlag=0
go

