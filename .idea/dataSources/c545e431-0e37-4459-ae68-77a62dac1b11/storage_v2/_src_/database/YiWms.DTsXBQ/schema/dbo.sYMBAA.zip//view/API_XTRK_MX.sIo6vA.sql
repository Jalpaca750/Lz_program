

/*==============================================================*/
/* View: API_XTRK_MX                                              */
/*      @editor:张东彦 Script Date: 07/13/2020 14:42:54  zdy                              */
/*==============================================================*/
CREATE view [dbo].[API_XTRK_MX] as
SELECT a.returnNo AS PKID,a.ownerId,w.warehouseId,a.ownerNo AS YEZ_ID,a.billNo AS DANJ_NO,a.thirdPartyNo AS SHANGJ_DANJ_NO,dtl.viewOrder AS linenum,
	bi.itemNo AS itemcode,dtl.returnQty AS quantity,dtl.price,dtl.taxrate,dtl.totalFee AS linetotal,
	dtl.stockBillNo AS SAPdocnum,sd.viewOrder AS baseline, W.warehouseNo AS WHNO,isnull(dtl.stockBillNo,'')  billNo,
	dtl.befPrice,dtl.ordDtlEx01,dtl.ordDtlEx02,dtl.ordDtlEx03,dtl.ordDtlEx04,dtl.ordDtlEx05
FROM dbo.SAD_ReturnDetail dtl INNER JOIN
      (SELECT m.returnNo,m.billNo,m.thirdPartyNo,n.ownerNo,m.ownerId
       FROM dbo.SAD_Return m LEFT JOIN 
             dbo.BAS_Owner_V n ON m.ownerId=n.ownerId
       WHERE m.ioState=30 AND (m.thirdSyncFlag=0 OR m.thirdSyncFlag=2)) a 
       ON dtl.returnNo=a.returnNo INNER JOIN
      dbo.BAS_Item bi ON dtl.itemId=bi.itemId LEFT JOIN
      dbo.SAD_StockDetail sd ON dtl.stockId=sd.stockId
      INNER JOIN BAS_Warehouse W on dtl.warehouseId=W.warehouseId
      where dtl.returnQty>0

go

