
/*==============================================================*/
/* View: BAS_Region_V                                           */
/*==============================================================*/
--creator：        Frank
--create time：  2016-09-22
--仓库区域代码视图
create view BAS_Region_V as
SELECT r.regionId,r.companyId,r.warehouseId,w.warehouseNo,w.warehouseName,r.regionNo,r.regionDesc,
	r.regionType, CASE r.regionType WHEN 0 THEN '散装' WHEN 1 THEN '整件' WHEN 2 THEN '混合' END AS typeName,
	r.isPicking, CASE r.isPicking WHEN 1 THEN '是' ELSE '否' END AS pickingName,
	r.isPutaway, CASE r.isPutaway WHEN 1 THEN '是' ELSE '否' END AS putawayName,
	r.isReturn, CASE r.isReturn WHEN 1 THEN '是' ELSE '否' END AS returnName,
	r.isQCArea, CASE r.isQCArea WHEN 1 THEN '是' ELSE '否' END AS qcAreaName,
	r.isCargo, CASE r.isCargo WHEN 1 THEN '是' ELSE '否' END AS cargoName,
	r.isTemporary, CASE r.isTemporary WHEN 1 THEN '是' ELSE '否' END AS temporaryName,
	r.isReplenished, CASE r.isReplenished WHEN 1 THEN '是' ELSE '否' END AS replenishedName,
	r.isDisable,CASE r.isDisable WHEN 1 THEN '是' ELSE '否' END AS disableName,
	r.isLocked,r.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),r.lockedTime,120) AS lockedTime,
	r.createTime,r.creatorId,u2.userNick AS creatorName,r.editTime,r.editorId,
	u3.userNick AS editorName,r.isSelected
FROM dbo.BAS_Region r 
	INNER JOIN dbo.BAS_Warehouse w ON r.warehouseId=w.warehouseId 
	LEFT JOIN dbo.SAM_User u1 ON r.lockerId=u1.userId 
	LEFT JOIN dbo.SAM_User u2 ON r.creatorId=u2.userId 
	LEFT JOIN dbo.SAM_User u3 ON r.editorId=u3.userId
go

