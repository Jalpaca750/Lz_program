
/*==============================================================*/
/* View: BAS_Zone_V                                             */
/*==============================================================*/
--creator：Frank
--create time：2018-12-11
--仓库区域代码视图
create view BAS_Zone_V as
SELECT a.zoneId,a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,a.regionId,
    r.regionNo,r.regionDesc,a.zoneNo,a.zoneDesc,a.isDisable,
    CASE a.isDisable WHEN 1 THEN '是' ELSE '否' END AS disableFlag,a.isLocked,
    a.lockerId,u1.userNick AS lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) AS lockedTime,
    a.creatorId,u2.userNick AS creatorName,a.createTime,a.editorId,u3.userNick AS editorName,
    a.editTime,a.isSelected
FROM dbo.BAS_Zone a
    INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
    INNER JOIN dbo.BAS_Region r ON a.regionId=r.regionId
    LEFT JOIN dbo.SAM_User u1 ON a.lockerId=u1.userId
    LEFT JOIN dbo.SAM_User u2 ON a.creatorId=u2.userId
    LEFT JOIN dbo.SAM_User u3 ON a.editorId=u3.userId
go

