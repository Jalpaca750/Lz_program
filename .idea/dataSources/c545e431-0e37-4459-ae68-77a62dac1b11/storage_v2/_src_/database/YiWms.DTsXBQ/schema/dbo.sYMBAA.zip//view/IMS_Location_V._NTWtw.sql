
/*==============================================================*/
/* View: IMS_Location_V                                         */
/*==============================================================*/
create view IMS_Location_V as
SELECT a.locationId,a.companyId,a.warehouseId,w.warehouseNo,w.warehouseName,a.regionId,r.regionNo,r.regionDesc, 
      a.locationNo,t.stockId,t.lotNo,t.eId,t.itemId,t.itemNo,t.itemCTitle,t.itemETitle,t.sellingPoint,t.itemName, 
      t.itemSpec,t.itemSpell,t.barcode,t.pkgBarcode,t.brandId,t.brandNo,t.brandCName,t.categoryId,t.categoryNo, 
      t.categoryCName,t.colorName,t.sizeName,t.unitName,t.packageId,t.isIrregular,t.isSafety,t.safetyMonth,
      t.safetyDays,t.onhandQty,t.pkgQty,t.bulkQty,t.allocQty,t.onWayQty,t.price,t.taxrate,t.taxPrice,t.fee,
      t.totalFee,t.lastITime,t.lastIPrice,t.lastITaxPrice,t.lastOTime,t.lastOPrice,t.lastOTaxPrice,t.pkgUnit, 
      t.pkgRatio,t.itemState,t.isUnsalable,t.isStop,t.isVirtual,t.inventoryMode,t.inputDate,t.productDate, 
      t.expiryDate,t.batchNo,t.attribute01,t.attribute02,t.attribute03,t.attribute04,t.attribute05,t.remarks, 
      a.pickingOrder,a.putawayOrder,a.locationDesc,a.locationWay,a.locationRow,a.locationCol,a.locationLayer, 
      a.isPackage,a.maxQty,a.maxVolume,a.maxWeight,a.multItem,a.multBatch,a.isDisable
FROM dbo.BAS_Location a 
      INNER JOIN dbo.BAS_Warehouse w ON a.warehouseId=w.warehouseId
      LEFT JOIN dbo.BAS_Region r ON a.regionId=r.regionId
      LEFT JOIN (SELECT x.stockId,x.companyId,x.warehouseId,x.locationNo,x.lotNo,x.eId,x.itemId,
                       sku.itemNo,sku.itemCTitle,sku.itemETitle,sku.sellingPoint,sku.itemName,
                       sku.itemSpec,sku.itemSpell,sku.barcode,sku.pkgBarcode,sku.brandId,sku.brandNo,
                       sku.brandCName,sku.categoryId,sku.categoryNo,sku.categoryCName,sku.colorName,
                       sku.sizeName,sku.unitName,sku.packageId,sku.isIrregular,sku.isSafety,
                       sku.safetyMonth,sku.safetyDays,x.onhandQty,
					   CASE sku.pickingMode WHEN 2 THEN x.onhandQty
										    WHEN 1 THEN 0.0
										    WHEN 0 THEN CASE ISNULL(sku.pkgRatio,0) WHEN 0 THEN 0.0 ELSE FLOOR(ISNULL(x.onhandQty,0.0)/sku.pkgRatio) END END pkgQty,
					   CASE sku.pickingMode WHEN 2 THEN 0.0 
										    WHEN 1 THEN x.onhandQty
										    WHEN 0 THEN CASE ISNULL(sku.pkgRatio,0) WHEN 0 THEN 0.0 ELSE ISNULL(x.onhandQty,0.0) % sku.pkgRatio END END bulkQty,
                       x.allocQty,x.onWayQty,x.price,x.taxrate,x.taxPrice,x.fee,x.totalFee,x.lastITime,
                       x.lastIPrice,x.lastITaxPrice,x.lastOTime,x.lastOPrice,x.lastOTaxPrice,sku.pkgUnit,
                       sku.pkgRatio,sku.itemState,sku.isUnsalable,sku.isStop,sku.isVirtual,sku.inventoryMode,
                       b.inputDate,b.productDate,b.expiryDate,b.batchNo,b.attribute01,b.attribute02,
                       b.attribute03,b.attribute04,b.attribute05,sku.remarks
                 FROM dbo.IMS_Stock x 
                       INNER JOIN dbo.BAS_Item_V sku ON x.itemId=sku.itemId
                       LEFT JOIN dbo.IMS_Batch b ON x.companyId=b.companyId AND x.lotNo=b.lotNo
                ) t on a.companyId=t.companyId AND a.warehouseId=t.warehouseId AND a.locationNo=t.locationNo
go

