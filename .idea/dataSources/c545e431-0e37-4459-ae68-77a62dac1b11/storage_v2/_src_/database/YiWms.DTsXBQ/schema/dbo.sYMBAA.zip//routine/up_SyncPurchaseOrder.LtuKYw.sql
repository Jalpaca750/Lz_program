





/*
declare @ownerId varchar(32)='0b4a6d1ec9bc4aaa8cdd996ece08441c'
declare @companyId varchar(32)='1707AED3C85145CB92763B6FA619A438'
exec up_SyncPurchaseOrder @companyId,@ownerId,'zdy','2017-03-25','2017-03-25'
*/
-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-01-15>
-- Description:	<Description:通过数据库方式同步采购订单>
-- 依赖：
--      供应商资料     
--      产品资料
--		仓库资料
-- =============================================
CREATE PROCEDURE [dbo].[up_SyncPurchaseOrder] 
(
	@companyId VARCHAR(32),		--公司Id,如果前台调用，需传值，为空时，手动修改这个值
	@ownerId VARCHAR(32),		--业主Id
	@creatorId VARCHAR(32),		--操作员，前天调用的当前用户，后台执行时，可赋值
	@startTime DATETIME,		--同步客户的开始时间（修改时间）
	@endTime DATETIME			--同步客户的截至时间（修改时间）
)
AS
create table  #tab 
(
  pmid int identity(0,1),
  pmno varchar(32),
  billNo int primary key,
  orderDate  datetime,
  customerNo varchar(100),
  customerName varchar(200),
  shipDate  date,
  shipTime  varchar(30),
  creatorName varchar(50),
  memo varchar(2000),
  spid  varchar(32),
  totalFee decimal(20,6),
  WHNO  VARCHAR(100),
  OrderSource int   --来源   11 普通采购单  21，调拨入库单
)
declare    @billNo int,
           @orderDate datetime,
           @customerNo varchar(100),
           @customerName varchar(100),
           @shipDate  date,
           @shipTime  varchar(30),
           @creatorName varchar(50),
           @memo varchar(2000),
           @pmid int,
           @pmno varchar(32),
           @spid varchar(32),
           @totalFee decimal(20,6),
           @whno varchar(100),
           @orderType   int --订单类型
---------------------仓库
declare @warehouseId varchar(32)=''
declare @defWarehouseId varchar(32)
declare @BIT_FLAG int=0 
declare @count int=0
declare @sumCount int 
BEGIN	
    -----------------------------------------仓库--------------------------------------------
    select @defWarehouseId=warehouseid from SAM_Store 
    where companyId=@companyId and ownerId=@ownerId and  interfaceType=30 
    and storeSource=0
    
    
    ----------------------------------插入采购单-------------------------------------------------------
    insert into #tab(pmno,billNo,orderDate,customerNo,customerName,shipDate,shipTime,creatorName,memo,spid,totalFee,WHNO,OrderSource)
	select   REPLACE(NEWID(),'-',''),a.billno,a.orderdate,a.customerno,a.customerName,a.shipdate,a.shiptime,
	a.creatorname,a.memo,b.partnerId,a.totalFee,
	(select top 1 b.whno from DBVIP.WMSSystem.dbo.SAP_Order_detail_CG b where b.billno=a.billno) whno,
	11
	from  DBVIP.WMSSystem.dbo.SAP_Order_CG a  
	left join BAS_Partner b on b.partnerType=2 and  b.ownerId= @ownerId and
	                           a.customerNo=b.partnerNo 
	                           and b.companyId=@companyId
	where   a.zt=0 
	
	
	---------------------------------插入入库单
	insert into #tab(pmno,billNo,orderDate,customerNo,customerName,shipDate,shipTime,creatorName,memo,spid,totalFee,WHNO,OrderSource)
	select   REPLACE(NEWID(),'-',''),a.billno,a.orderdate,a.customerno,a.customerName,a.shipdate,a.shiptime,
	a.creatorname,a.memo,b.partnerId,
	(select isnull(SUM(b.totalFee),0) from  DBVIP.WMSSystem.dbo.SAP_PSRK_detail b
     where b.billno=a.billno) totalFee,
	null whno,21
	from  DBVIP.WMSSystem.dbo.SAP_PSRK a  
	left join BAS_Partner b on b.partnerType=1 and  b.ownerId= @ownerId and
	                           a.customerNo=b.partnerNo 
	                           and b.companyId=@companyId               
	where   a.zt=0 
	
------------------------------过滤掉没有匹配的数据-------------------------------------------------------------
declare @NoExistsCustomer  table(billno int,CustomerNo varchar(100),flag int)
-------------------找不到供应商ID的匹配不上的
insert into @NoExistsCustomer(billno,CustomerNo,flag)
select billno,customerNo,OrderSource from #tab 
where spid is null
-------------------主订单
UPDATE DBVIP.WMSSystem.dbo.SAP_Order_CG_update SET zt=-1 
WHERE billNo in (select  billno  from @NoExistsCustomer where flag=11)
/*****************************************************************************************/
delete a   from #tab a  where  
exists(select billNo from @NoExistsCustomer where billNo=a.billNo and flag=a.OrderSource )
/*****************************************************************************************/

------------------------------插入详细数据---------------------------------------------------------------
create  table #tab_Detail (pmno varchar(32),billno varchar(50),vieworder int,
itemno varchar(50),price decimal(20,6),quantity decimal(20,6),totalfee  decimal(20,6),
itemName varchar(200),pkgRatio decimal,eid varchar(32),
itemid varchar(32),WHNO VARCHAR(100),pkgQty decimal(20,6),bulkQty decimal(20,6),OrderSource int)
------------------------------插入采购单详细
insert into #tab_Detail(pmno,billno,vieworder,itemno,price,quantity,totalfee,itemName,pkgRatio,eId,itemId,WHNO,pkgQty,bulkQty,OrderSource)
select h.pmno,a.billno,a.vieworder,a.itemno,a.price,a.quantity,a.totalfee,b.itemName,isnull(b.pkgRatio,0),
c.eId,b.itemId,a.whno,
--****************************************包装换算****************************************************
(case isnull(b.pickingMode,0) when 0 
 then  (case  when pkgRatio<=1 then 0 else Floor(a.quantity/b.pkgRatio) end) --计算
 when  2 then a.quantity 
 else 0 end),---整包装
( case  isnull(b.pickingMode,0) when 0  then (case  when pkgRatio<=1 then  a.quantity else (a.quantity%b.pkgRatio) end)--散包装
  when   1 then a.quantity  else  0 end),11
--********************************************************************
from 
DBVIP.WMSSystem.dbo.SAP_Order_detail_CG a 
inner join  #tab h on  a.billno=h.billNo and h.OrderSource=11
left join bas_item b 
on   a.itemno=b.itemno  and b.ownerId=@ownerId 
left join ecm_itemsku c on c.itemid=b.itemid
------------------------------插入入库单申请单详细
insert into #tab_Detail(pmno,billno,vieworder,itemno,price,quantity,totalfee,itemName,pkgRatio,eId,itemId,WHNO,pkgQty,bulkQty,OrderSource)
select h.pmno,a.billno,a.vieworder,a.itemno,a.price,a.quantity,a.totalfee,b.itemName,isnull(b.pkgRatio,0),c.eId,
b.itemId,h.WHNO,
--****************************************包装换算****************************************************
(case isnull(b.pickingMode,0) when 0 
 then  (case  when pkgRatio<=1 then 0 else Floor(a.quantity/b.pkgRatio) end) --计算
 when  2 then a.quantity 
 else 0 end),---整包装
( case  isnull(b.pickingMode,0) when 0  then (case  when pkgRatio<=1 then  a.quantity else (a.quantity%b.pkgRatio) end)--散包装
  when   1 then a.quantity  else  0 end),21
--*****************************************************************************************************
from 
DBVIP.WMSSystem.dbo.SAP_PSRK_detail a 
inner join  #tab h on  a.billno=h.billNo and h.OrderSource=21
left join bas_item b 
on   a.itemno=b.itemno  and b.ownerId=@ownerId 
left join ecm_itemsku c on c.itemid=b.itemid
--------------------过滤掉找不到商品的------------------------------------------------------------------------





--------------------------------------------------------------------------------------------------------------
declare @NoExistsCustomerDetail  table(billno int,flag int,itemno varchar(100))
---查到没有客户匹配上的单子
Insert  Into @NoExistsCustomerDetail(billno,flag,itemno)
select  billno,OrderSource,itemno from #tab_Detail 
where itemid is null 

---更新订单的
UPDATE DBVIP.WMSSystem.dbo.SAP_Order_CG_update SET zt=-1 
WHERE zt=0 and  billNo in (select distinct  billno  from @NoExistsCustomerDetail where flag=11) 

/**********************************************************用游标更新********************/
declare @temp_billno int
declare   F_SAP_PSRK    cursor  local  scroll   FOR
select  billno  from @NoExistsCustomer where flag=21  --客户不匹配
union  
select  distinct billno  from @NoExistsCustomerDetail where flag=21
------
OPEN  F_SAP_PSRK ---打开游标
Fetch  NEXT   FROM F_SAP_PSRK  into  @temp_billno     --商品部匹配
WHILE @@fetch_status=0 
BEGIN  
  UPDATE  DBVIP.WMSSystem.dbo.SAP_PSRK SET zt=-1  where billno=@temp_billno 
  Fetch  NEXT   FROM F_SAP_PSRK  into  @temp_billno 
END
CLOSE F_SAP_PSRK
Deallocate F_SAP_PSRK

/**********************************************************用游标更新********************/
--删除主表
delete a   from #tab a  where  
exists(select billNo from @NoExistsCustomerDetail where billNo=a.billNo and flag=a.OrderSource )
---删除详细表
delete a  from #tab_Detail a 
where exists(select billno  from @NoExistsCustomerDetail where billno=a.billno and OrderSource=a.OrderSource)

print   '日志完成----------------------------------------------'
----------------------------------------写日志----------------------------------------------------

insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncPurchaseOrder',billno,'采购订单-找不到供应商',GETDATE()   
from @NoExistsCustomer where flag=11

insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncPurchaseOrder',billno,'调拨入库单-找不到客户',GETDATE()   
from @NoExistsCustomer where flag=21

insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncPurchaseOrder',billno,'采购订单-'+(cast (billno as varchar(100)))+'-'+itemno+'-找不到商品',GETDATE()   
from @NoExistsCustomerDetail where flag=11

insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncPurchaseOrder',billno,'调拨入库单-'+(cast (billno as varchar(100)))+'-'+itemno+'-找不到商品',GETDATE()   
from @NoExistsCustomerDetail where flag=21

-------------------------------------------------------------------------------------------------
/*
Begin TRY
         BEGIN TRAN BIT_TRAN
         -------------------------------批量插入
            insert into PMS_ORDER(orderNo,billNo,orderDate,createTime,companyId,
			ownerId,supplierId,supplierNo,supplierName,requireDate,warehouseId,
			currencyId,exchangeRate,taxFlag,poState,apState,orderSource,totalFee,
			auditTime,auditorId,poNo,memo,creatorId,editTime)
			select 
			pmno,billNo,orderDate,GETDATE(),@companyId,@ownerId,spid,customerNo,customerName,orderDate,
			isnull(B.warehouseId,@defWarehouseId),
			--@warehouseId,
			-1,
			1,1,2,0,a.OrderSource,totalFee,
			orderDate,@creatorId,billNo,memo,@creatorId,GETDATE()
			from  #tab a  LEFT JOIN   BAS_Warehouse b 
			on  a.whno=b.warehouseNo and b.companyId=@companyId 
			 ----------------------------------------插入详细
             insert into  PMS_OrderDetail(orderId,orderNo,companyId,viewOrder,warehouseId,eId,itemId,
			 itemNo,itemName,orderQty,pkgQty,bulkQty,befPrice,discount,discountFee,price,taxrate,
			 fee,taxFee,totalFee,rebate,
			 receiveQty,invoiceQty,invoiceFee,payQty,payFee,updPrice)
			 select  REPLACE(NEWID(),'-',''),pmno,@companyId,a.ViewOrder,isnull(B.warehouseId,@defWarehouseId),a.eId,a.itemId,
			 a.itemno,a.itemName,a.quantity,a.pkgQty,a.bulkQty,
			 a.price,100,0,a.price,17,0,0,a.totalfee,0,0,0,0,0,0,1
			 from #tab_Detail a  LEFT JOIN   BAS_Warehouse b 
			on  a.whno=b.warehouseNo and b.companyId=@companyId 
		     ----------------------------------------------------------------------------------------
              set @BIT_FLAG=1
             COMMIT TRAN BIT_TRAN
             ----------------------------------更改状态---------------------------------------------------
             declare @maxOrder int 
             select @maxOrder=isnull(max(billno),-10) from  #tab where OrderSource=11 
             update   DBVIP.WMSSystem.dbo.SAP_Order_CG_update set zt=1 where billno<(@maxOrder+1)  and zt=0
             select @maxOrder=isnull(max(billno),-10) from  #tab where OrderSource=21 
             update   DBVIP.WMSSystem.dbo.SAP_PSRK set zt=1 where billno<(@maxOrder+1)   and zt=0
             --------------------------------------------------------------------------------------
END TRY 
       BEGIN CATCH
       set @BIT_FLAG =0
         IF @@TRANCOUNT > 0
			BEGIN
			   ROLLBACK  tran BIT_TRAN
			    DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
				SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
				RAISERROR(@ErrMsg, @ErrSeverity, 1)
			   print '批量失败'
			END  
END CATCH
*/
----------------------------------------------------------------------
IF  @BIT_FLAG=0
BEGIN  

		select @sumCount=count(pmid) from  #tab
		WHILE(@count<@sumCount)
		BEGIN
		 print '开始循环'
		set @whno=''
		
			 ----查出来数据
			 select  @pmno=pmno,@billNo=billNo,@orderDate=orderDate,
					 @customerNo=customerNo,@customerName=customerName,
					 @shipDate=shipDate,@shipTime=shipTime,@creatorName=creatorName,@memo=memo,
					 @spid=spid,@totalFee=totalFee,@whno=WHNO,@orderType=OrderSource
			 from #tab
			 where   pmid=@count
			 set @count=@count+1
			BEGIN TRY
				BEGIN TRANSACTION TEMP_TRAN
			 ----插入
			        set  @warehouseId=null
			        SELECT @warehouseId=warehouseId FROM BAS_Warehouse WHERE companyId=@companyId AND  warehouseNo=@whno
					set @warehouseId=isnull(@warehouseId,@defWarehouseId)
					-------------------------------------------------------------
					insert into PMS_ORDER(orderNo,billNo,orderDate,createTime,companyId,
					ownerId,supplierId,supplierNo,supplierName,requireDate,warehouseId,
					currencyId,exchangeRate,taxFlag,poState,apState,orderSource,totalFee,
					auditTime,auditorId,poNo,memo,creatorId,editTime,printNum)
					values(@pmno,@billNo,@orderDate,GETDATE(),@companyId,@ownerId,@spid,@customerNo,@customerName,@orderDate,@warehouseId,-1,
					 1,1,2,0,@orderType,@totalFee,@orderDate,@creatorName,@billNo,@memo,@creatorId,GETDATE(),0)
					 
					  insert into  PMS_OrderDetail(orderId,orderNo,companyId,viewOrder,warehouseId,eId,itemId,
					 itemNo,itemName,orderQty,pkgQty,bulkQty,befPrice,discount,discountFee,price,taxrate,
					 fee,taxFee,totalFee,rebate,
					 receiveQty,invoiceQty,invoiceFee,payQty,payFee,updPrice)
					 select  REPLACE(NEWID(),'-',''),@pmno,@companyId,a.ViewOrder,ISNULL(b.warehouseId,@defWarehouseId),a.eId,a.itemId,
					 a.itemno,a.itemName,a.quantity,a.pkgQty,a.bulkQty,
					--(case  when a.pkgRatio<1.1 then a.quantity else Floor(a.quantity/a.pkgRatio) end),--整包装
                    --(case  when a.pkgRatio<1.1 then 0 else (a.quantity%a.pkgRatio) end),--散包装
					 a.price,100,0,a.price,17,0,0,a.totalfee,0,0,0,0,0,0,1
					 from #tab_Detail a  left join BAS_Warehouse b on a.WHNO=b.warehouseNo and b.companyId=@companyId
					 where a.billno=@billNo
					COMMIT TRAN TEMP_TRAN
					
					if @orderType=11
					begin
					  update DBVIP.WMSSystem.dbo.SAP_Order_CG_update set zt=1 where billno=@billNo
					  
					end
					else if @orderType=21
					begin
					  update DBVIP.WMSSystem.dbo.SAP_PSRK set zt=1 where billno=@billNo
					end
			END TRY
			BEGIN CATCH
				--错误处理，抛出错误
				IF @@TRANCOUNT > 0
				ROLLBACK  TRAN TEMP_TRAN
				/*DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
				SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
				RAISERROR(@ErrMsg, @ErrSeverity, 1)*/
				if @orderType=11
					begin
					  update DBVIP.WMSSystem.dbo.SAP_Order_CG_update set zt=-1 where billno=@billNo
					  insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
select                REPLACE(NEWID(),'-',''),@companyId,'up_SyncPurchaseOrder',@billNo,'采购订单-同步失败、数据不完整',GETDATE()   
					end
					else if @orderType=21
					begin
					  update DBVIP.WMSSystem.dbo.SAP_PSRK set zt=-1 where billno=@billNo
					  insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
select                REPLACE(NEWID(),'-',''),@companyId,'up_SyncPurchaseOrder',@billNo,'调拨入库单-同步失败、数据不完整',GETDATE()   
					end
			END CATCH
		  END
		End
END



































go

