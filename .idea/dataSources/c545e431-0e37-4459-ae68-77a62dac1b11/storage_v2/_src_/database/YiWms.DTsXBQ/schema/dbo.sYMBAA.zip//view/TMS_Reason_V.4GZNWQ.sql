
/*==============================================================*/
/* View: TMS_Reason_V                                           */
/*==============================================================*/
create view TMS_Reason_V as
SELECT a.reasonId,a.reasonNo,a.reasonDesc,a.typeId,b.typeName,a.companyId,a.exReason01,
	a.exReason02,a.exReason03,a.exReason04,a.exReason05,
	a.isDisable,CASE a.isDisable WHEN 0 THEN '否' WHEN 1 THEN '是' END AS disableDesc,
    a.recount,CASE a.recount WHEN 0 THEN '否' WHEN 1 THEN '是' END AS recountDesc,
	a.isLocked,a.lockerId,u1.userNick as lockerName,CONVERT(VARCHAR(20),a.lockedTime,120) as lockedTime,
	a.createTime,a.creatorId,u2.userNick as creatorName,a.editTime,a.editorId,u3.userNick as editorName,
	a.isSelected
FROM dbo.TMS_Reason a 
   INNER JOIN dbo.TMS_ReasonType b on  a.typeId = b.typeId
   LEFT  JOIN dbo.SAM_User u1 on  a.lockerId = u1.userId
   LEFT  JOIN dbo.SAM_User u2 on  a.creatorId = u2.userId
   LEFT  JOIN dbo.SAM_User u3 on  a.editorId = u3.userId
go

