



CREATE PROCEDURE [dbo].[up_SyncErpSalesOrder] 
(
	@companyId VARCHAR(32),		--公司Id,如果前台调用，需传值，为空时，手动修改这个值
	@ownerId VARCHAR(32),		--业主Id
	@creatorId VARCHAR(32),		--操作员，前天调用的当前用户，后台执行时，可赋值
	@startTime DATETIME,		--同步订单的开始时间（修改时间）
	@endTime DATETIME			--同步订单的截至时间（修改时间）
)
AS
declare @parentId varchar(32)='',
        @orderNo  varchar(32)='',
        @billNo   varchar(32)='',
        @orderDate date,
        @customerNo varchar(100),
        @customerName varchar(100),
        @receiverState varchar(100),
        @receiverCity  varchar(100),
        @receiverDistrict varchar(100),
        @receiverAddress varchar(100),
        @receiverName  varchar(40),
        @receiverTel   varchar(40),
        @receiverMobile varchar(40),
        @shipDate     date,
        @shipTime   varchar(40),
        @creatorName varchar(40),  --下单人
        @memo        varchar(1000),
        @TotalFee    decimal(20,6)=0,
        @WhNo        varchar(100), --仓库编码
        @orderType   int, --订单类型
        @defWarehouseId varchar(32),
        ----------------------------------新加字段
        @PartName  varchar(100), --部门
        @slpname   varchar(100), --销售员名称
        @pymntgroup varchar(100),--结算方式
        @DiscSum    Decimal(20,6), --折扣
        @TrnspName  varchar(100),  --装运类型
        @noPrintPrice varchar(100) --不打印价格
  DECLARE @BIT_FLAG INT =0  --批量的
  declare @warehouseId varchar(32)='仓库'  ---仓库的ID
  declare @flag int =0  --标识
  --declare @details table(billno varchar(100),vieworder int ,itemno varchar(100),price decimal(20,6),totalfee decimal(20,6))
BEGIN  
---------------------仓库---------------------------------
 select @defWarehouseId=warehouseid from SAM_Store 
 where companyId=@companyId and ownerId=@ownerId and  interfaceType=30 
 and storeSource=0
/*-------------------------订单、调拨出库没有匹配到客户的、详细没有匹配到商品的不用---------------------*/
 
/*-- 自动拉取供客户、商品详细 避免出现匹配不上的情况 ---*/
---同步客户
--exec  up_SyncBasicCustomer @companyId,@ownerId,@creatorId,0,@startTime,@endTime
---同步商品
---exec  up_SyncBasicItem @companyId,@ownerId,@creatorId,@startTime,@endTime
---修改商品的数据
UPDATE   DBVIP.WMSSystem.dbo.SAP_Order_update set zt=-1 where billno is null
UPDATE   DBVIP.WMSSystem.dbo.SAP_PSCK SET  ZT=-1 WHERE billno is null
-----------------------------------------数据--------------------------------------------------------

select orderno,billno,orderDate,customerNo,customerName,
receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,
receiverMobile,shipDate,shipTime,creatorName,
memo,totalFee,whno,b.partnerId,a.orderType,
a.PartName,--销售部门
a.slpname, --销售代表
a.pymntgroup,  --结算方式
isnull(shbm,'') shbm,DiscSum,TrnspName,noPrintPrice
into   #tabs from (
select REPLACE(NEWID(),'-','') orderno,a.billNo,a.orderDate,a.customerNo,a.customerName,a.receiverState,a.receiverCity,
a.receiverDistrict,a.receiverAddress,a.receiverName,a.receiverTel,a.receiverMobile,a.shipDate,a.shipTime,a.creatorName,a.memo,a.totalFee,
(select top 1 b.whno from DBVIP.WMSSystem.dbo.SAP_Order_detail b 
where b.billno=a.billno) whno,(case billtype when '经营领用' then 30 when '管理领用' then 31 when '赠品出库' then 40  when '报废报损' then 50  else 10 end) orderType,
----30-领用单;40-赠品单
a.DiscSum,a.PartName,a.slpname,a.pymntgroup,shbm,a.TrnspName,a.noPrintPrice
from DBVIP.WMSSystem.dbo.SAP_Order a
where a.zt=0
UNION     -----------------链接-----------------------------------------------------------------------
select REPLACE(NEWID(),'-','') orderno,a.billNo,a.orderDate,a.customerNo,a.customerName,
a.receiverState,a.receiverCity,a.receiverDistrict,a.receiverAddress,a.receiverName,a.receiverTel,
a.receiverMobile,a.shipDate,a.shipTime,a.creatorName,a.memo,
(select isnull(SUM(b.totalFee),0) from  DBVIP.WMSSystem.dbo.SAP_PSCK_detail b
     where b.billno=a.billno) totalFee
,null whno,20 OrderType,a.DiscSum,a.PartName,a.slpname,a.pymntgroup,'','',null
from DBVIP.WMSSystem.dbo.SAP_PSCK a 
where  a.zt=0
) a  left join  BAS_Partner b 
on    a.customerno=b.partnerNo  and b.partnerType=1  and b.ownerId=@ownerId
order by billno

-----过滤表中匹配不到客户的单子---订单----------------------------------------------------------
declare @NoExistsCustomer  table(billno int,CustomerNo varchar(100),flag int)
-------------------查到没有客户匹配上的单子-----------------------------------------------------
Insert  Into @NoExistsCustomer(billno,CustomerNo,flag)
select billno,customerNo,orderType from #tabs 
where partnerId is null
-------------------更新订单的-------------------------------------------------------------------
UPDATE DBVIP.WMSSystem.dbo.SAP_Order_update SET zt=-1 
WHERE billNo in (select  billno  from @NoExistsCustomer where flag!=20)
-----------删除临时表中不符合条件的
delete  a   from #tabs a  where  
exists(select billNo from @NoExistsCustomer where billNo=a.billno and  flag=a.orderType )
--------------------------------------详细---------------------------------------------------------------------
declare @tab_Detail table(orderno varchar(32),billno varchar(50),vieworder int,itemno varchar(50),price decimal(20,6)
,quantity decimal(20,6),totalfee  decimal(20,6),itemName varchar(200),pkgRatio decimal,eid varchar(32),
itemid varchar(32),whno varchar(100),OrderType int, pkgQty decimal(20,6),bulkQty decimal(20,6),befPrice decimal(20,6),LineNotes varchar(200))

insert into @tab_Detail(orderno,billno,vieworder,itemno,price,quantity,totalfee,
itemName,pkgRatio,eId,itemId,whno,OrderType,pkgQty,bulkQty,befPrice,LineNotes)
select dt.orderno,a.billno,a.vieworder,a.itemno,a.price,a.quantity,a.totalfee,
b.itemName,b.pkgRatio,c.eId,b.itemId,a.whno,dt.orderType,
--****************************************包装换算****************************************************
(case isnull(b.pickingMode,0) when 0 
 then  (case  when pkgRatio<=1 then 0 else Floor(a.quantity/b.pkgRatio) end) --计算
 when  2 then a.quantity 
 else 0 end),---整包装
( case  isnull(b.pickingMode,0) when 0  then (case  when pkgRatio<=1 then  a.quantity else (a.quantity%b.pkgRatio) end)--散包装
  when   1 then a.quantity  else  0 end),a.befPrice,a.linenotes
--*****************************************************************************************************
from 
DBVIP.WMSSystem.dbo.SAP_Order_detail a 
inner join   #tabs dt on a.billno=dt.billno 
and dt.ordertype!=20  --不是调拨单
left join bas_item b 
on    b.ownerId=@ownerId   and  a.itemno=b.itemno
left join ecm_itemsku c on c.itemid=b.itemid
---调拨类型的
print '插入详细'
insert into @tab_Detail(orderno,billno,vieworder,itemno,price,quantity,totalfee,
itemName,pkgRatio,eId,itemId,whno,OrderType,pkgQty,bulkQty,befPrice,LineNotes)
select dt.orderno,a.billno,a.vieworder,a.itemno,a.price,a.quantity,a.totalfee,
b.itemName,b.pkgRatio,c.eId,b.itemId,'',20,
--****************************************包装换算****************************************************
(case isnull(b.pickingMode,0) when 0 
 then  (case  when pkgRatio<=1 then 0 else Floor(a.quantity/b.pkgRatio) end) --计算
 when  2 then a.quantity 
 else 0 end),---整包装
( case  isnull(b.pickingMode,0) when 0  
 then (case  when pkgRatio<=1 then  a.quantity else (a.quantity%b.pkgRatio) end)--散包装
  when   1 then a.quantity  else  0 end),a.befPrice,''
--*****************************************************************************************************
from 
DBVIP.WMSSystem.dbo.SAP_PSCK_detail a 
inner join   #tabs dt on a.billno=dt.billno and dt.ordertype=20
left join bas_item b 
on    b.ownerId=@ownerId   and  a.itemno=b.itemno
left join ecm_itemsku c on c.itemid=b.itemid



-----------------------------过滤匹配不到商品的情况-------------------------------------------------

-----过滤表中匹配不到客户的单子---订单
declare @NoExistsCustomerDetail  table(billno int,flag int,itemno varchar(100))
---查到没有客户匹配上的单子
Insert  Into @NoExistsCustomerDetail(billno,flag,itemno)
select   billno,orderType,itemno from @tab_Detail 
where itemid is null 
---更新订单的

UPDATE DBVIP.WMSSystem.dbo.SAP_Order_update SET zt=-1 
WHERE zt=0 and  billNo in (select distinct  billno  from @NoExistsCustomerDetail where flag!=20) 

/**********************************************************用游标更新********************/
declare @temp_billno int
declare   F_SAP_PSCK    cursor  local  scroll   FOR
select  billno  from @NoExistsCustomer where flag=20  --客户不匹配
union  
select  distinct billno  from @NoExistsCustomerDetail where flag=20
OPEN  F_SAP_PSCK ---打开游标
Fetch  NEXT   FROM F_SAP_PSCK  into  @temp_billno     --商品部匹配
WHILE @@fetch_status=0 
BEGIN  
  UPDATE  DBVIP.WMSSystem.dbo.SAP_PSCK SET zt=-1  where billno=@temp_billno 
  Fetch  NEXT   FROM F_SAP_PSCK  into  @temp_billno 
END
CLOSE F_SAP_PSCK
Deallocate F_SAP_PSCK
/**********************************************************用游标更新--end********************/

--删除主表
delete  a   from #tabs a  where  
exists(select distinct billNo from @NoExistsCustomerDetail 
        where billNo=a.billno and  flag=a.orderType )
---删除详细表
delete a  from @tab_Detail a 
where exists(select distinct billno  from @NoExistsCustomerDetail where billno=a.billno and OrderType=a.OrderType)
----------------------------------------写日志----------------------------------------------------
insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncErpSalesOrder',billno,'订单-找不到客户',GETDATE()   
from @NoExistsCustomer where flag!=20

insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncErpSalesOrder',billno,'调拨出库单-找不到客户',GETDATE()   
from @NoExistsCustomer where flag=20

insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncErpSalesOrder',billno,'订单-'+'-'+itemno+'-找不到商品',GETDATE()   
from @NoExistsCustomerDetail where flag!=20

insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncErpSalesOrder',billno,'调拨出库单-'+(cast (billno as varchar(100))) +'-'+itemno+'-找不到商品',GETDATE()   
from @NoExistsCustomerDetail where flag=20
-----------------------------------------------------------------------------------------------------
print  '来这里了1'
/* BEGIN TRY  
     BEGIN TRAN BIT_TRAN  --批量的事物
-------------------插入销售单
INSERT INTO SAD_Order(orderNo,companyId,ownerId,billNo,createTime,orderDate,customerId,customerNo,
			customerName,receiverState,receiverCity,receiverDistrict,receiverAddress,
			lineId,groupId,
			receiverName,receiverTel,receiverMobile,warehouseId,orderType,isTogether,shipDate,shipTime,
			currencyId,exchangeRate,taxFlag,sdState,arState,taskState,totalFee,postFee,payFee,orderSource,
			flag,expressNo,logisticsId,logisticsFee,buyerMessage,memo,isLocked,lockerId,lockedTime,creatorId,
			editTime,editorId,salesId,deptId,settlementId,organizeId)
SELECT      a.orderno,@companyId,@ownerId,a.billNo,GETDATE(),a.orderdate,a.partnerid,a.customerNo,
			a.customerName,a.receiverState,a.receiverCity,a.receiverDistrict,a.receiverAddress,
			(
			     (select  top 1 ISNULL(lineId,'') 
			      from  BAS_ReceiveAddress 
			      where customerId=a.partnerId and receiverAddress=a.receiverAddress) 
			)
			,null,
			a.receiverName,a.receiverTel,a.receiverMobile,isnull(b.warehouseId,@defWarehouseId),  --@warehouseId,
			a.ordertype,
			1,--默认都是货齐一起送
			a.shipDate,a.shipTime,'-',1,1,10,0,10,a.totalFee,
			0.0,0 --已付款金额默认为0
			,10,
			1,'',null,0.0,@creatorName,a.memo,
			0,'',NULL,@creatorId,GETDATE(),@creatorId,
			a.slpname,a.PartName,a.pymntgroup,shbm ---新增字段同步
from  #tabs a left join  BAS_Warehouse b 
on  a.whno=b.warehouseNo 
and b.companyId=@companyId 

-------------------插入销售单的详细


INSERT INTO SAD_OrderDetail(orderId,orderNo,companyId,viewOrder,warehouseId,eId,itemId,itemNo,itemName,
			orderQty,pkgQty,bulkQty,befPrice,discount,
			discountFee,price,taxRate,fee,taxFee,
			totalFee,remarks)
			select REPLACE(NEWID(),'-',''),orderno,@companyId,
			vieworder,isnull(b.warehouseId,@defWarehouseId),
			eId,itemid,itemno,itemName,
			quantity,a.pkgQty,a.bulkQty,
			befPrice,100,0,price,17,0,0,totalFee,''
			from @tab_Detail a left join  BAS_Warehouse b 
			on  a.whno=b.warehouseNo and b.companyId=@companyId 
			
		   print  '批量的OK'
		   COMMIT  TRAN BIT_TRAN
		   set @BIT_FLAG=1
		   declare @maxBillNo int 
		   --=====订单，领用单，赠品单
		   select @maxBillNo=isnull(MAX(billno),-10) from   
		   #tabs  where ordertype!=20 
		   
		   update  DBVIP.WMSSystem.dbo.SAP_Order_update set zt=1 
		   where billno<(@maxBillNo+1) and zt=0 
		   --=====调拨单
		   select @maxBillNo=isnull(MAX(billno),-10) from   #tabs where   ordertype=20
		   update  DBVIP.WMSSystem.dbo.SAP_PSCK set zt=1 
		   where billno<(@maxBillNo+1) and zt=0 
		   
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
			BEGIN
			   ROLLBACK  tran BIT_TRAN
			   set @BIT_FLAG =0
			   print '批量失败'+ERROR_MESSAGE()
			END
END CATCH */

------------------------------------------------------------------------------------------
IF   @BIT_FLAG=0
BEGIN
-----------------------------定义游标
DECLARE @BillType varchar(100)='',@shbm varchar(100)=''
DECLARE @LINE_ID varchar(32)
declare   FMyCursor    cursor  local  scroll       FOR
select  orderno, partnerid,billNo,orderDate,customerNo,customerName,
receiverState,receiverCity,
receiverDistrict,receiverAddress,receiverName,receiverTel,
receiverMobile,shipDate,shipTime,creatorName,memo,totalfee,
whno,ordertype,PartName,slpname,pymntgroup,shbm,DiscSum,TrnspName,noPrintPrice
from  #tabs for read only


---详细表
OPEN  FMyCursor ---打开游标
		Fetch  NEXT   FROM FMyCursor  into    
		@orderNo,@parentId,@billNo,@orderDate,@customerNo,@customerName,@receiverState,
		@receiverCity,@receiverDistrict,@receiverAddress,@receiverName,@receiverTel,
		@receiverMobile,@shipDate,@shipTime,@creatorName,@memo,@TotalFee,@WhNo,@orderType,
		@PartName,@slpname,@pymntgroup,@shbm,@DiscSum,@TrnspName,@noPrintPrice
	WHILE @@fetch_status=0 
	BEGIN  
-------------------------业务开始
BEGIN TRY
  begin tran  temp_tran
            set   @warehouseId=null
            SELECT @warehouseId=warehouseId FROM BAS_Warehouse WHERE companyId=@companyId AND  warehouseNo=@WhNo
            set @warehouseId=ISNULL(@warehouseId,@defWarehouseId)
            --找线路
             select @LINE_ID=ISNULL(lineId,'') 
			      from  BAS_ReceiveAddress 
			      where customerId=@parentId and receiverAddress=@receiverAddress
            
			INSERT INTO SAD_Order(orderNo,companyId,ownerId,billNo,createTime,orderDate,customerId,customerNo,
			customerName,receiverState,receiverCity,receiverDistrict,receiverAddress,lineId,
			groupId,
			receiverName,receiverTel,receiverMobile,warehouseId,orderType,isTogether,
			shipDate,shipTime,
			currencyId,exchangeRate,taxFlag,sdState,arState,
			taskState,totalFee,postFee,payFee,orderSource,
			flag,expressNo,logisticsId,logisticsFee,
			buyerMessage,memo,
			isLocked,lockerId,lockedTime,creatorId,
			editTime,editorId,salesId,deptId,settlementId,organizeId,totalDiscount)
			---写入订单
			SELECT @orderNo,@companyId,@ownerId,@billNo,GETDATE(),@orderDate,@parentId,@customerNo,
			@customerName,@receiverState,@receiverCity,@receiverDistrict,@receiverAddress,
			@LINE_ID,
			@noPrintPrice,-- 对应group Id 用来存储是否打印的
			@receiverName,@receiverTel,@receiverMobile,@warehouseId,
			@orderType,
			1,--默认都是货齐一起送
			@shipDate,@shipTime,'-',1,1,10,0,10,@TotalFee,
			0.0,0 ----已付款金额默认为0
			,10,
			1,'',@TrnspName,0.0,'',@memo,
			0,'',NULL,@creatorName,GETDATE(),@creatorId,@slpname,@PartName,@pymntgroup,
			@shbm,@DiscSum
			---写入订单详细
			INSERT INTO SAD_OrderDetail(orderId,orderNo,companyId,viewOrder,warehouseId,eId,itemId,itemNo,itemName,
						orderQty,stockqty,pkgQty,bulkQty,befPrice,discount,
						discountFee,price,taxRate,fee,taxFee,
						totalFee,remarks)
						
			select REPLACE(NEWID(),'-',''),@orderNo,@companyId,
			vieworder,isnull(b.warehouseId,@defWarehouseId),eId,itemid,itemno,itemName,
			quantity, quantity,pkgQty,bulkQty,
			befPrice,100,0,price,17,0,0,totalFee,isnull(LineNotes,'')
			from @tab_Detail a left join BAS_Warehouse b  
			on a.whno=b.warehouseNo and b.companyId=@companyId
			where  billno=@billNo	
			
				 
            set @flag=1
            commit
              if @orderType!=20  --如果不是调拨单
              begin
               update  DBVIP.WMSSystem.dbo.SAP_Order_update set zt=1 where billno=@billNo
              end
              else begin
                 update  DBVIP.WMSSystem.dbo.SAP_PSCK set zt=1 where billno=@billNo
              end
         END TRY
           BEGIN CATCH
           set  @flag=0
			--错误处理，抛出错误
			print '异常了'+ERROR_MESSAGE()
			--DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
			---SELECT @ErrMsg = ERROR_MESSAGE(),@ErrSeverity = ERROR_SEVERITY()
			---RAISERROR(@ErrMsg, @ErrSeverity, 1)
			IF @@TRANCOUNT > 0
			   ROLLBACK tran temp_tran ;
			  ----处理异常状态
			  if @orderType!=20 begin
			  update  DBVIP.WMSSystem.dbo.SAP_Order_update set zt=-1 where billno=@billNo
			  insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
              select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncErpSalesOrder',@billNo,'订单-'+@billNo+'同步失败、信息不完整'+ERROR_MESSAGE(),GETDATE()   
			  end
			  else begin
			    update  DBVIP.WMSSystem.dbo.SAP_PSCK set zt=-1 where billno=@billNo
			    insert into   WMS_Log(logId,companyId,InterfaceName,billNo,logDescription,createTime)  
                select  REPLACE(NEWID(),'-',''),@companyId,'up_SyncErpSalesOrder',@billNo,'调拨出库单-'+@billNo+'同步失败、信息不完整'+ERROR_MESSAGE(),GETDATE()   
			  end
            END CATCH
				Fetch  NEXT   FROM FMyCursor  into    
		@orderNo,@parentId,@billNo,@orderDate,@customerNo,@customerName,@receiverState,
		@receiverCity,@receiverDistrict,@receiverAddress,@receiverName,@receiverTel,
		@receiverMobile,@shipDate,@shipTime,@creatorName,@memo,@TotalFee,@WhNo,@orderType,
		@PartName,@slpname,@pymntgroup,@shbm,@DiscSum,@TrnspName,@noPrintPrice
		
end
      --关闭游标 
      CLOSE FMyCursor
	  Deallocate FMyCursor
	  ---更新状态
end

END




























































go

