-- =============================================
-- Author:		<Author:Frank.He>
-- Create date: <Create Date:2019-01-07>
-- Description:	<Description:通过采购上架策略取得商品上架建议库位  V1.0.0>
--              211-上架到目标库位	
--              212-上架到商品指定的件拣货库位（库位资料维护中指定）
--              213-上架到商品指定的箱拣货库位（库位资料维护中指定）
--              221-上架到目标区域(合适的库位)
--              222-上架到商品指定的散件上架区域(合适的库位)
--              223-上架到商品指定的整件上架区域(合适的库位)
--              224-上架到目标库区（新增）
--              225-上架到商品指定的散件上架库区（新增）
--              226-上架到商品指定的整件上架库区（新增）
-- Modify:      2019-05-22 日修正Bug Frank
--              <Frank.He 2020-10-09 允许产品混放时，历史库位Bug修正>
-- =============================================
CREATE FUNCTION [dbo].[uf_GetPurchaseLocation] 
(
	@companyId VARCHAR(32),			--公司Id
	@ownerId VARCHAR(32),			--业主Id
	@warehouseId VARCHAR(32),		--仓库Id
	@itemId VARCHAR(32),			--商品Id
	@recBin VARCHAR(32),			--收货库位
	@receiveQty DECIMAL(20,6),		--入库数量
	@lotNo VARCHAR(32),				--批次号
	@orderSource INT,				--订单类型 0,所有单据；11,普通订单;12,应急订单;13,零星采购;14,转场订单;21,调拨入库单,允许不参与控制
	@unitLevel VARCHAR(10)			--单位级别：预留字段，分别对应EA-件CS-箱PL-托盘OT-其他
)
RETURNS @uTable TABLE
(
	viewOrder INT IDENTITY(1,1),
	warehouseId VARCHAR(32),
	regionId VARCHAR(32),
	itemId VARCHAR(32),
	locationNo VARCHAR(32),
	lotNo VARCHAR(32),
	SQty DECIMAL(20,6)
)
AS
BEGIN
    DECLARE @putPolicy INT;					--规则代码
	DECLARE	@targRegion VARCHAR(32);		--目标区域
	DECLARE	@targZone VARCHAR(32);          --目标库区（逻辑库区）
	DECLARE @targLocation VARCHAR(32);		--目标库位
	DECLARE @allowVolumed INT;				--允许超过库位体积，1-允许;0-限制
	DECLARE @itemMix INT;					--允许产品混放,1-允许;0-不允许
	DECLARE @lotMix INT;					--允许批次混放,1-允许;0-不允许
	DECLARE @isPackage INT;					--库位使用：10-件捡货库位；20-箱捡货库位;30-混合拣库位; 40-储货位库位；50-过渡库位
	DECLARE @putMode INT;					--优先模式：1-储位放满优先;2-空货位优先;	
	DECLARE @result VARCHAR(32);			--返回结果
    DECLARE @viewOrder INT;					--序号
    DECLARE @locationNo VARCHAR(32);		--库位编码
    DECLARE @itemVolume DECIMAL(20,3);		--单位体积（暂时无用）
    DECLARE @pkgRatio INT;                  --整件数量（整件上架时，用整件体积匹配）
    DECLARE @tmpQty DECIMAL(20,6);          --临时数量
    DECLARE @pkgVolume DECIMAL(20,3);       --整件体积
    DECLARE @inventoryMode INT;				--0-无;1-批次
    DECLARE @eachRegion VARCHAR(32);		--散件上架区域
    DECLARE @eachZone VARCHAR(32);          --散件上架库区
    DECLARE @caseRegion VARCHAR(32);		--整件上架区域
    DECLARE @caseZone VARCHAR(32);          --整件上架库区
	DECLARE @regionId VARCHAR(32);          --区域
    DECLARE @locationWay VARCHAR(10);       --通道
    DECLARE @locationRow VARCHAR(10);       --货架组
    DECLARE @locationLayer VARCHAR(10);     --层
    DECLARE @availVolume DECIMAL(20,3);     --层的可用空间
    DECLARE @minOrder INT;                  --最小序号
	--存放商品历史库位
	DECLARE @hisLocation TABLE(viewOrder INT IDENTITY(1,1),companyId VARCHAR(32),warehouseId VARCHAR(32),locationNo VARCHAR(32),onhandQty DECIMAL(20,6),putawayOrder INT);
	--参数临时表
    DECLARE @tbParas TABLE(warehouseId VARCHAR(32),itemId VARCHAR(32),lotNo VARCHAR(32),SQty DECIMAL(20,6));
    --写入参数临时表
    INSERT INTO @tbParas(warehouseId,itemId,lotNo,SQty)VALUES(@warehouseId,@itemId,@lotNo,@receiveQty);
    --临时库位周转表
    DECLARE @tmpLocation TABLE(viewOrder INT IDENTITY(1,1),warehouseId VARCHAR(32),locationNo VARCHAR(32),putPolicy INT);
    --临时可用库位层表
    DECLARE @tmpLayer TABLE(viewOrder INT IDENTITY(1,1),warehouseId VARCHAR(32),regionId VARCHAR(32),locationWay VARCHAR(10),locationRow VARCHAR(10),locationLayer VARCHAR(10),minOrder INT);
	--当前商品批次管理，整件体积与整件数量;
	SELECT @inventoryMode=inventoryMode,@pkgRatio=pkgRatio,@pkgVolume=pkgVolume,@itemVolume=itemVolume,
	    @eachRegion=putRegion,@caseRegion=csPutRegion,@eachZone=putZone,@caseZone=csPutZone
	FROM BAS_Item 
	WHERE itemId=@itemId;
    --散件上架区域，散件上架库区，整件上架区域，整件上架库区;
	--SELECT @eachRegion=putRegion,@caseRegion=csPutRegion,@eachZone=putZone,@caseZone=csPutZone
	--FROM BAS_ItemZone
	--WHERE companyId=@companyId AND warehouseId=@warehouseId AND itemId=@itemId;
	--策略游标(policyType:1-采购上架策略)
	DECLARE myPlicy CURSOR
	FOR 
		SELECT putPolicy,ISNULL(targRegion,''),ISNULL(targLocation,''),ISNULL(targZone,''),allowVolumed,itemMix,lotMix,isPackage,putMode
		FROM WMS_PutawayPolicy
		WHERE (companyId=@companyId)								--公司Id
			AND (warehouseId=@warehouseId)							--仓库Id
			AND (ownerId=@ownerId)									--业主Id
			AND (isDisable=0)										--有效的
			AND (orderSource=0 OR orderSource=@orderSource)		    --订单类型
			AND (unitLevel=@unitLevel)								--包装规格：EA-散件;CS-整箱
			AND (policyType)=1                                      --策略类型
		ORDER BY viewOrder;
	OPEN myPlicy;
	FETCH NEXT FROM myPlicy INTO @putPolicy,@targRegion,@targLocation,@targZone,@allowVolumed,@itemMix,@lotMix,@isPackage,@putMode;
	WHILE @@FETCH_STATUS=0
	BEGIN
		--1.上架到指定库位(固定库位，不限制体积)
		--1.1.上架到目标库位(211)
		IF (@putPolicy=211)
		BEGIN
			INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
			SELECT warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
			FROM BAS_Location
			WHERE warehouseId=@warehouseId AND locationNo=@targLocation;
			IF EXISTS(SELECT * FROM @uTable)
			    BREAK;
		END
		--1.2. 上架到商品指定的拣货库位(212-件拣货库位；213-箱拣货库位)(库位资料维护中指定)
		ELSE IF (@putPolicy=212 OR @putPolicy=213)
		BEGIN
		    INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
			SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
			FROM dbo.BAS_Location
			WHERE (companyId=@companyId)						            --公司Id
				AND (warehouseId=@warehouseId)					            --仓库Id
				AND (itemId=@itemId)							            --商品Id
				AND (isFixed=1)									            --固定库位
				AND (isDisable=0)								            --有效库位
				AND (isPackage=@isPackage)						            --库位使用
			ORDER BY putawayOrder;
			IF EXISTS(SELECT * FROM @uTable)
				BREAK;
		END
		--2.上架到指定区域		
		ELSE IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223 OR @putPolicy=231 OR @putPolicy=232 OR @putPolicy=233)
		BEGIN
		    --222-指定商品散件上架区域为目标区域
		    IF (@putPolicy=222 OR @putPolicy=232)
			    SET @targRegion=@eachRegion;
		    --223-指定商品整件上架区域为目标区域
		    IF (@putPolicy=223 OR @putPolicy=233)
			    SET @targRegion=@caseRegion;
		    --2.1.指定区域空库位(空库位)
			IF (@putMode=2)
			BEGIN
			    --2.1.1.不限制体积/数量
				IF (ISNULL(@allowVolumed,1)=1)
				BEGIN
                    --2.1.1.1.指定区域历史空库位
			        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                    SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
			        FROM (
					        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
					            SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
					        FROM dbo.BAS_Location a 
						        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					        WHERE (a.companyId=@companyId)						                    --公司Id
						        AND (a.warehouseId=@warehouseId)				                    --仓库Id
						        AND (a.regionId=@targRegion)					                    --目标区域						        
						        AND (a.isDisable=0)								                    --有效库位
						        AND (a.isFixed=0)								                    --非固定库位
						        AND (a.isPackage=@isPackage)					                    --库位使用						        
						        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
						        AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo))
					        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
				        ) t 
			        WHERE t.onhandQty=0.0 
			        ORDER BY hisFlag DESC,putawayOrder;
			        IF EXISTS(SELECT * FROM @uTable)
                        BREAK;
                    --2.1.1.2指定区域其他合适的空库位			        
			        IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
				    BEGIN
				        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						            SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						        FROM dbo.BAS_Location a 
							        LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id
							        AND (a.regionId=@targRegion)					                    --目标区域
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        WHERE t.onhandQty=0.0
				        ORDER BY hisFlag DESC,putawayOrder;
				        IF EXISTS(SELECT * FROM @uTable)
                            BREAK;
				    END
				END
				--2.1.2.限制体积/数量
				ELSE
				BEGIN
				    --2.1.2.1.指定区域历史空库位
				    INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
			        SELECT TOP 100 warehouseId,locationNo,@putPolicy
			        FROM (
					        SELECT a.warehouseId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
					            SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
					        FROM dbo.BAS_Location a 
						        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					        WHERE (a.companyId=@companyId)						                    --公司Id
						        AND (a.warehouseId=@warehouseId)				                    --仓库Id
						        AND (a.regionId=@targRegion)					                    --目标区域
						        AND (a.isDisable=0)                                                 --有效库位
						        AND (a.isFixed=0)								                    --非固定库位
						        AND (a.isPackage=@isPackage)					                    --库位使用
						        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
						        AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo))
					        GROUP BY a.warehouseId,a.locationNo,a.putawayOrder
				        ) t 
			        WHERE t.onhandQty=0.0 
			        ORDER BY hisFlag DESC,putawayOrder;
			        --2.1.2.2指定区域其他合适的空库位
			        IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
				    BEGIN
			            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
				        SELECT TOP 100 warehouseId,locationNo,@putPolicy
				        FROM (
						        SELECT a.warehouseId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						            SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						        FROM dbo.BAS_Location a 
							        LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id
							        AND (a.regionId=@targRegion)					                    --目标区域
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo))
						        GROUP BY a.warehouseId,a.locationNo,a.putawayOrder
					        ) t 
				        WHERE t.onhandQty=0.0 
				        ORDER BY hisFlag DESC,putawayOrder;
				    END
				END
			END
			--2.2.指定区域库位(储满优先)
			ELSE IF (@putMode=1)
			BEGIN
		        --2.2.1.批次管理，不允许产品、批次混放(排除法)
		        IF (@inventoryMode=1 AND @lotMix=0 AND @itemMix=0)
		        BEGIN
		            --2.2.1.1.排除非当前产品、当前批次的其他任何有库存的商品所在的库位
		            INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.regionId=@targRegion)						                            --目标区域
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
                        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo=t.lotNo))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.regionId=@targRegion)						                            --目标区域
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
				        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo=t.lotNo))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
                    --2.2.1.2.不限制体积/数量
			        IF (ISNULL(@allowVolumed,1)=1)
			        BEGIN
			            --历史预分配库位
			            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.regionId=@targRegion)				                        --目标区域
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (b.lotNo=@lotNo)                                                --当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
                        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
				        --历史可用库位
				        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.regionId=@targRegion)				                        --目标区域
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (b.lotNo=@lotNo)                                                --当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
				        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
                        --其他合适的可用库位(策略221，222，223)
                        IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
                        BEGIN
                            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                            SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.regionId=@targRegion)				                    --目标区域
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				            IF EXISTS(SELECT * FROM @uTable)
                                RETURN;
                        END
				    END
				    --2.2.1.3.限制体积/数量
				    ELSE
				    BEGIN
				        --历史预分配库位
			            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.regionId=@targRegion)				                        --目标区域
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (b.lotNo=@lotNo)                                                --当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
				        --历史可用库位
				        INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.regionId=@targRegion)				                        --目标区域
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (b.lotNo=@lotNo)                                                --当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
                        --其他合适的可用库位(策略221，222，223)
                        IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
                        BEGIN
                            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                            SELECT TOP 100 warehouseId,locationNo,@putPolicy
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.regionId=@targRegion)				                    --目标区域
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
                        END
			        END
			    END
		        --2.2.2.批次管理，允许混放批次(不允许产品混放)；非批次管理(不允许产品混放)(排除法)
		        ELSE IF (@inventoryMode=1 AND @lotMix=1 AND @itemMix=0) OR (@inventoryMode=0 AND @itemMix=0) 
		        BEGIN
		            --2.2.2.1.排除其他任何有库存的商品所在的库位
			        INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.regionId=@targRegion)						                            --目标区域
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
                        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.regionId=@targRegion)						                            --目标区域
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
				        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
                    --2.2.2.2.不限制体积/数量
			        IF (ISNULL(@allowVolumed,1)=1)
			        BEGIN
			            --历史预分配库位
			            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.regionId=@targRegion)				                        --目标区域
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
                        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
                        --历史可用库位
				        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.regionId=@targRegion)				                        --目标区域
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
				        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
                        --其他合适的可用库位(策略221，222，223)
                        IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
                        BEGIN
                            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                            SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.regionId=@targRegion)				                    --目标区域
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				            IF EXISTS(SELECT * FROM @uTable)
                                RETURN;
                        END
			        END
			        --2.2.2.3.不限制体积/数量
			        ELSE
			        BEGIN
                        --历史预分配库位
			            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.regionId=@targRegion)				                        --目标区域
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
				        --历史可用库位
				        INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.regionId=@targRegion)				                        --目标区域
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
                        --其他合适的可用库位(策略221，222，223)
                        IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
                        BEGIN
                            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                            SELECT TOP 100 warehouseId,locationNo,@putPolicy
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.regionId=@targRegion)				                    --目标区域
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
                        END
                    END
		        END
		        --2.2.3.批次管理，不允许批次混放，允许产品混放(排除法)
		        ELSE IF (@inventoryMode=1 AND @lotMix=0 AND @itemMix=1)
		        BEGIN
		            --2.2.3.1.不允许放在当前商品其他批次有库存的库位
			        INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.regionId=@targRegion)						                            --目标区域
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
				        AND (b.ioFlag='+')                                                              --预分配
                        AND (EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo!=t.lotNo))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.regionId=@targRegion)						                            --目标区域
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
				        AND (EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo!=t.lotNo))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
                    --2.2.3.2.不限制体积/数量
			        IF (ISNULL(@allowVolumed,1)=1)
			        BEGIN
			            --历史预分配库位
			            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.regionId=@targRegion)				                        --目标区域
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (b.lotNo=@lotNo)                                                --当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
                        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
				        --历史可用库位
				        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.regionId=@targRegion)				                        --目标区域
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (b.lotNo=@lotNo)                                                --当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
				        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
                        --其他合适的可用库位(策略221，222，223)
                        IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
                        BEGIN
                            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                            SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.regionId=@targRegion)				                    --目标区域
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				            IF EXISTS(SELECT * FROM @uTable)
                                RETURN;
                        END
			        END
			        --2.2.3.3.不限制体积/数量
			        ELSE
			        BEGIN
		                --历史预分配库位
			            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.regionId=@targRegion)				                        --目标区域
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (b.lotNo=@lotNo)                                                --当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
				        --历史可用库位
				        INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.regionId=@targRegion)				                        --目标区域
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (b.lotNo=@lotNo)                                                --当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
                        --其他合适的可用库位(策略221，222，223)
                        IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
                        BEGIN
                            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                            SELECT TOP 100 warehouseId,locationNo,@putPolicy
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.regionId=@targRegion)				                    --目标区域
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
                        END
			        END
		        END
			    --2.2.4.批次管理，允许批次、产品混放；非批次管理(允许产品混放)(历史库位优先，其他任何库位都可)
			    ELSE IF (@inventoryMode=1 AND @lotMix=1 AND @itemMix=1) OR (@inventoryMode=0 AND @itemMix=1) 
			    BEGIN
				    --2.2.4.1.不限制体积/数量
			        IF (ISNULL(@allowVolumed,1)=1)
			        BEGIN
		                --历史预分配库位
		                INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
		                SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
			            FROM (
					            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
					            FROM BAS_Location a
						            INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					            WHERE (a.companyId=@companyId)							                --公司Id
						            AND (a.warehouseId=@warehouseId)					                --目标仓库
						            AND (a.regionId=@targRegion)						                --目标区域
						            AND (a.isDisable=0)									                --有效库位
						            AND (a.isFixed=0)									                --非固定库位
						            AND (a.isPackage=@isPackage)						                --库位使用
						            AND (b.ioFlag='+')									                --预分配
						            AND (b.itemId=@itemId)							                    --历史商品
						            AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
				            ) t
			            ORDER BY onhandQty DESC,putawayOrder;
			            IF EXISTS(SELECT * FROM @uTable)
			                BREAK;
			            --历史可用库位(当前存货库位优先，少量库位优先，上架顺序优先)
			            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
		                SELECT TOP 1 @warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
			            FROM (
					            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
					                SUM(CASE WHEN ISNULL(b.onhandQty,0.0)>0.0 OR ISNULL(b.onwayQty,0.0)>0.0 THEN 1 ELSE 0 END) AS hasFlag
					            FROM BAS_Location a 
						            INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					            WHERE (a.companyId=@companyId)							                --公司Id
						            AND (a.warehouseId=@warehouseId)					                --目标仓库
						            AND (a.regionId=@targRegion)						                --目标区域
						            AND (a.isDisable=0)									                --有效库位
						            AND (a.isFixed=0)									                --非固定库位
						            AND (a.isPackage=@isPackage)						                --库位使用
						            AND (b.itemId=@itemId)							                    --历史商品
						            AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
				            ) t
			            ORDER BY hasFlag DESC,onhandQty DESC,putawayOrder;
				        IF EXISTS(SELECT * FROM @uTable)
			                BREAK;
			            --其他合适的可用库位(策略221，222，223)
                        IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
			            BEGIN					    
				            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
			                SELECT TOP 1 @warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty, 
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)							            --公司Id
							            AND (a.warehouseId=@warehouseId)					            --目标仓库
							            AND (a.regionId=@targRegion)						            --目标区域
							            AND (a.isDisable=0)									            --有效库位
							            AND (a.isFixed=0)									            --非固定库位
							            AND (a.isPackage=@isPackage)						            --库位使用
							        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				            IF EXISTS(SELECT * FROM @uTable)
				                BREAK;
				        END
			        END
			        --2.2.4.2.限制体积/数量
			        ELSE
			        BEGIN
			            --历史预分配库位
				        INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
				        SELECT TOP 100 warehouseId,locationNo,@putPolicy
			            FROM (
					            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
					            FROM BAS_Location a
						            INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					            WHERE (a.companyId=@companyId)							                --公司Id
						            AND (a.warehouseId=@warehouseId)					                --目标仓库
						            AND (a.regionId=@targRegion)						                --目标区域
						            AND (a.isDisable=0)									                --有效库位
						            AND (a.isFixed=0)									                --非固定库位
						            AND (a.isPackage=@isPackage)						                --库位使用
						            AND (b.ioFlag='+')									                --预分配
						            AND (b.itemId=@itemId)							                    --历史商品
						            AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
				            ) t
			            ORDER BY onhandQty DESC,putawayOrder;
				        --历史可用库位(当前存货库位优先，少量库位优先，上架顺序优先)
				        INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
				        SELECT TOP 100 warehouseId,locationNo,@putPolicy				        
			            FROM (
					            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
					                SUM(CASE WHEN ISNULL(b.onhandQty,0.0)>0.0 OR ISNULL(b.onwayQty,0.0)>0.0 THEN 1 ELSE 0 END) AS hasFlag
					            FROM BAS_Location a 
						            INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					            WHERE (a.companyId=@companyId)							                --公司Id
						            AND (a.warehouseId=@warehouseId)					                --目标仓库
						            AND (a.regionId=@targRegion)						                --目标区域
						            AND (a.isDisable=0)									                --有效库位
						            AND (a.isFixed=0)									                --非固定库位
						            AND (a.isPackage=@isPackage)						                --库位使用
						            AND (b.itemId=@itemId)							                    --历史商品
						            AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
				            ) t
			            ORDER BY hasFlag DESC,onhandQty DESC,putawayOrder;
				        --其他合适的可用库位(策略221，222，223)
                        IF (@putPolicy=221 OR @putPolicy=222 OR @putPolicy=223)
			            BEGIN
				            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
				            SELECT TOP 100 warehouseId,locationNo,@putPolicy
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty, 
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)							            --公司Id
							            AND (a.warehouseId=@warehouseId)					            --目标仓库
							            AND (a.regionId=@targRegion)						            --目标区域
							            AND (a.isDisable=0)									            --有效库位
							            AND (a.isFixed=0)									            --非固定库位
							            AND (a.isPackage=@isPackage)						            --库位使用
							        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				        END
				    END
			    END	
			END
		END
		--3.上架到指定库区(比区域更小的范围，分类存储用该策略)
		ELSE IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226 OR @putPolicy=234 OR @putPolicy=235 OR @putPolicy=236)
        BEGIN
            --225-指定商品散件上架库区为目标库区
		    IF (@putPolicy=225 OR @putPolicy=235)
		        SET @targZone =@eachZone;
		    --226-指定商品整件上架库区为目标库区
		    IF (@putPolicy=226 OR @putPolicy=236)
		        SET @targZone =@caseZone;
		    --3.1.指定库区库位(空库位)
			IF (@putMode=2)
			BEGIN
			    --3.1.1.不限制体积/数量
			    IF (ISNULL(@allowVolumed,1)=1)
			    BEGIN
				    --3.1.1.1.上架到指定库区(历史库位)
			        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                    SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
			        FROM (
					        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
					            SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
					        FROM dbo.BAS_Location a 
						        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					        WHERE (a.companyId=@companyId)						                        --公司Id
						        AND (a.warehouseId=@warehouseId)				                        --仓库Id
						        AND (a.zoneId=@targZone)					                            --目标库区							        
						        AND (a.isDisable=0)								                        --有效库位
						        AND (a.isFixed=0)								                        --非固定库位
						        AND (a.isPackage=@isPackage)					                        --库位使用
						        AND (@inventoryMode=0 OR (@inventoryMode=1 OR b.lotNo=@lotNo))          --非批次或者当前批次
						        AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo))
					        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
				        ) t 
			        WHERE t.onhandQty=0.0 
			        ORDER BY hisFlag DESC,putawayOrder;
			        IF EXISTS(SELECT * FROM @uTable)
			            BREAK;
			        --3.1.1.2.上架到指定库区(其他库区)
				    IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
				    BEGIN
			            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
							        SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						        FROM dbo.BAS_Location a 
							        LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id
							        AND (a.zoneId=@targZone)					                        --目标库区
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        WHERE t.onhandQty=0.0
				        ORDER BY hisFlag DESC,putawayOrder;
				        IF EXISTS(SELECT * FROM @uTable)
			                BREAK;
				    END
			    END
			    --3.1.2.限制体积/数量
			    ELSE
			    BEGIN
			        --3.1.2.1.上架到指定库区(历史库位)
		            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
			        SELECT TOP 100 warehouseId,locationNo,@putPolicy
			        FROM (
					        SELECT a.warehouseId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
					            SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
					        FROM dbo.BAS_Location a 
						        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					        WHERE (a.companyId=@companyId)						                        --公司Id
						        AND (a.warehouseId=@warehouseId)				                        --仓库Id
						        AND (a.zoneId=@targZone)					                            --目标库区
						        AND (a.isDisable=0)								                        --有效库位
						        AND (a.isFixed=0)								                        --非固定库位
						        AND (a.isPackage=@isPackage)					                        --库位使用
						        AND (b.itemId=@itemId)                                                  --历史库位
						        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))         --非批次或者历史批次
						        AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo))
					        GROUP BY a.warehouseId,a.locationNo,a.putawayOrder
				        ) t 
			        WHERE t.onhandQty=0.0 
			        ORDER BY hisFlag DESC,putawayOrder;
				    --3.1.2.2.上架到指定库区(其他库区)
				    IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
			        BEGIN
			            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
				        SELECT TOP 100 warehouseId,locationNo,@putPolicy
				        FROM (
						        SELECT a.warehouseId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
							        SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						        FROM dbo.BAS_Location a 
							        LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id
							        AND (a.zoneId=@targZone)					                        --目标库区
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (NOT EXISTS(SELECT * FROM dbo.IMS_Allocate c WHERE a.companyId=c.companyId AND a.warehouseId=c.warehouseId AND a.locationNo=c.locationNo))
						        GROUP BY a.warehouseId,a.locationNo,a.putawayOrder
					        ) t 
				        WHERE t.onhandQty=0.0 
				        ORDER BY hisFlag DESC,putawayOrder;
				    END
				END
			END
			--3.2.指定库区库位(储满优先)
			ELSE
			BEGIN
		        --3.2.1.批次管理，不允许产品、批次混放(排除法)
		        IF (@inventoryMode=1 AND @lotMix=0 AND @itemMix=0)
		        BEGIN
		            --3.2.1.1.排除非当前产品和批次的其他任何有库存的商品所在的库位
			        INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.zoneId=@targzone)						                                --目标库区
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
                        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo=t.lotNo))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.zoneId=@targZone)						                                --目标库区
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
				        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo=t.lotNo))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
			        --3.2.1.2.不限制体积/数量
			        IF (ISNULL(@allowVolumed,1)=1)
			        BEGIN
			            --历史预分配库位
			            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.zoneId=@targZone)						                    --目标库区
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (b.lotNo=@lotNo)                                                --当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
                        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
                        --历史可用库位
                        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.zoneId=@targZone)					                        --目标库区
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (b.lotNo=@lotNo)                                                --当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
				        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
                        --其他合适的可用库位(策略224，225，226)
                        IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
                        BEGIN
                            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                            SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.zoneId=@targZone)					                    --目标库区
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				            IF EXISTS(SELECT * FROM @uTable)
                                RETURN;
                        END
                    END
                    --3.2.1.3.限制体积/数量
                    ELSE
                    BEGIN
                        --历史预分配库位
			            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.zoneId=@targZone)						                    --目标库区
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (b.lotNo=@lotNo)                                                --当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
                        --历史可用库位                        
                        INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.zoneId=@targZone)					                        --目标库区
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (b.lotNo=@lotNo)                                                --当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
				        --其他合适的可用库位(策略224，225，226)
                        IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
                        BEGIN
                            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                            SELECT TOP 100 warehouseId,locationNo,@putPolicy
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.zoneId=@targZone)					                    --目标库区
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
                        END
			        END
		        END
		        --3.2.2.批次管理允许混放批次(不允许产品混放)；非批次管理(不允许产品混放)(排除法)
		        ELSE IF (@inventoryMode=1 AND @lotMix=1 AND @itemMix=0) OR (@inventoryMode=0 AND @itemMix=0) 
		        BEGIN
		            --3.2.2.1.排除其他任何有库存的商品所在的库位
			        INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.zoneId=@targZone)						                                --目标库区
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
                        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.zoneId=@targZone)						                                --目标库区	
				        AND (a.isDisable=0)									                            --有效库位	
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
				        AND (NOT EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
                    --3.2.2.2.不限制体积/数量
		            IF (ISNULL(@allowVolumed,1)=1)
		            BEGIN
                        --历史预分配库位
			            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.zoneId=@targZone)						                    --目标库区
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
                        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
                        --历史可用库位
                        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.zoneId=@targZone)					                        --目标库区
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
				        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
                        --其他可用库位
                        IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
                        BEGIN
                            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                            SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.zoneId=@targZone)					                    --目标库区
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				            IF EXISTS(SELECT * FROM @uTable)
                                RETURN;
                        END
		            END
		            --3.2.2.3.限制体积/数量
		            ELSE
		            BEGIN
	                    --历史预分配库位
			            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.zoneId=@targZone)						                    --目标库区
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
                        --历史可用库位
                        INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.zoneId=@targZone)					                        --目标库区
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
				        --其他可用库位
                        IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
                        BEGIN
                            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                            SELECT TOP 100 warehouseId,locationNo,@putPolicy
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.zoneId=@targZone)					                    --目标库区
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
                        END
                    END
		        END
		        --3.2.3.批次管理，不允许批次混放，允许产品混放(排除法)
		        ELSE IF (@inventoryMode=1 AND @lotMix=0 AND @itemMix=1)
		        BEGIN
		            --3.2.3.1.不允许放在当前商品其他批次有库存的库位
			        INSERT INTO @hisLocation(warehouseId,locationNo)
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.zoneId=@targZone)						                                --目标库区
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
                        AND (EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo!=t.lotNo))
                        AND (b.allocQty>0.0)
                    UNION ALL
                    SELECT a.warehouseId,a.locationNo
                    FROM dbo.BAS_Location a 
				        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                    WHERE (a.companyId=@companyId)							                            --公司Id
                        AND (a.warehouseId=@warehouseId)					                            --目标仓库
				        AND (a.zoneId=@targZone)						                                --目标库区
				        AND (a.isDisable=0)									                            --有效库位
				        AND (a.isFixed=0)									                            --非固定库位
				        AND (a.isPackage=@isPackage)						                            --库位使用
				        AND (EXISTS(SELECT * FROM @tbParas t WHERE b.warehouseId=t.warehouseId AND b.itemId=t.itemId AND b.lotNo!=t.lotNo))
                        AND (ISNULL(onhandQty,0.0)>0.0 OR ISNULL(onWayQty,0.0)>0.0);
                    --3.2.3.2.不限制体积/数量
		            IF (ISNULL(@allowVolumed,1)=1)
		            BEGIN
	                    --历史预分配库位
			            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.zoneId=@targZone)						                    --目标库区
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (b.lotNo=@lotNo)                                                --当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
                        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
                        --历史可用库位
                        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.zoneId=@targZone)					                        --目标库区
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (b.lotNo=@lotNo)                                                --非批次或者当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
				        IF EXISTS(SELECT * FROM @uTable)
                            RETURN;
                        --其他合适的可用库位(策略224，225，226)
                        IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
                        BEGIN
                            INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                            SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.zoneId=@targZone)					                    --目标库区
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
				            IF EXISTS(SELECT * FROM @uTable)
                                RETURN;
                        END
		            END
		            --3.2.3.3.不限制体积/数量
		            ELSE
		            BEGIN
                        --历史预分配库位
			            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
                        FROM (
                                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
                                FROM BAS_Location a
                                    INNER JOIN IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
                                WHERE (a.companyId=@companyId)							                --公司Id
			                        AND (a.warehouseId=@warehouseId)					                --目标仓库
			                        AND (a.zoneId=@targZone)						                    --目标库区
			                        AND (a.isDisable=0)									                --有效库位
			                        AND (a.isFixed=0)									                --非固定库位
			                        AND (a.isPackage=@isPackage)						                --库位使用
			                        AND (b.itemId=@itemId)                                              --当前商品
			                        AND (b.lotNo=@lotNo)                                                --当前批次
			                        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
                                GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
                              ) t
                        ORDER BY onhandQty DESC,putawayOrder;
                        --历史可用库位                        
                        INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                        SELECT TOP 100 warehouseId,locationNo,@putPolicy
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty
						        FROM dbo.BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)						                    --公司Id
							        AND (a.warehouseId=@warehouseId)				                    --仓库Id				    
							        AND (a.zoneId=@targZone)					                        --目标库区
							        AND (a.isDisable=0)								                    --有效库位
							        AND (a.isFixed=0)								                    --非固定库位
							        AND (a.isPackage=@isPackage)					                    --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (b.lotNo=@lotNo)                                                --非批次或者当前批次
							        AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						        GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
				        --其他合适的可用库位(策略224，225，226)
                        IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
                        BEGIN
                            INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
                            SELECT TOP 100 warehouseId,locationNo,@putPolicy
				            FROM (
						            SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onwayQty,0.0)) AS onhandQty,
						                SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag
						            FROM dbo.BAS_Location a 
							            LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						            WHERE (a.companyId=@companyId)						                --公司Id
							            AND (a.warehouseId=@warehouseId)				                --仓库Id				    
							            AND (a.zoneId=@targZone)					                    --目标库区
							            AND (a.isDisable=0)								                --有效库位
							            AND (a.isFixed=0)								                --非固定库位
							            AND (a.isPackage=@isPackage)					                --库位使用
							            AND (NOT EXISTS(SELECT * FROM @hisLocation t2 WHERE a.warehouseId=t2.warehouseId AND a.locationNo=t2.locationNo))
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					            ) t
				            ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
                        END
			        END
		        END
			    --3.2.4.批次管理允许批次、产品混放;非批次管理允许产品混放(历史库位优先，其他任何库位都可)
			    ELSE IF (@inventoryMode=1 AND @lotMix=1 AND @itemMix=1) OR (@inventoryMode=0 AND @itemMix=1) 
			    BEGIN
                    --3.2.4.1.不限制体积/数量
		            IF (ISNULL(@allowVolumed,1)=1)
		            BEGIN
				        --历史预分配库位
				        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
						        FROM BAS_Location a 
							        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)							                --公司Id
							        AND (a.warehouseId=@warehouseId)					                --目标仓库
							        AND (a.zoneId=@targZone)						                    --目标库区
							        AND (a.isDisable=0)									                --有效库位
							        AND (a.isFixed=0)									                --非固定库位
							        AND (a.isPackage=@isPackage)						                --库位使用
							        AND (b.ioFlag='+')									                --预分配
							        AND (b.itemId=@itemId)							                    --历史商品
							        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
							    GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
				        IF EXISTS(SELECT * FROM @uTable)
				            BREAK;
				        --历史可用库位(有库存的,库存少的，上架顺序)
				        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty,
						            SUM(CASE WHEN ISNULL(b.onhandQty,0.0)>0.0 OR ISNULL(b.onWayQty,0.0)>0.0 THEN 1 ELSE 0 END) AS hasFlag
						        FROM BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)							                --公司Id
							        AND (a.warehouseId=@warehouseId)					                --目标仓库
							        AND (a.zoneId=@targZone)						                    --目标库区								        
							        AND (a.isDisable=0)									                --有效库位
							        AND (a.isFixed=0)									                --非固定库位
							        AND (a.isPackage=@isPackage)						                --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
							    GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY hasFlag DESC,onhandQty DESC,putawayOrder;
					    IF EXISTS(SELECT * FROM @uTable)
				            BREAK;
				        --其他合适的可用库位(策略224，225，226)
                        IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
                        BEGIN
			                INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                            SELECT TOP 1 warehouseId,regionId,locationNo,@itemId,@lotNo,@receiveQty
			                FROM (
					                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty,
					                    SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag 
					                FROM BAS_Location a 
						                LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					                WHERE (a.companyId=@companyId)							                --公司Id
						                AND (a.warehouseId=@warehouseId)					                --目标仓库
						                AND (a.zoneId=@targZone)						                    --目标库区
						                AND (a.isDisable=0)									                --有效库位
						                AND (a.isFixed=0)									                --非固定库位
						                AND (a.isPackage=@isPackage)						                --库位使用
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
				                ) t
			                ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
			                IF EXISTS(SELECT * FROM @uTable)
			                    BREAK;
			            END
				    END
				    --3.2.4.2.限制体积/数量
				    ELSE
				    BEGIN
				        --历史预分配库位
				        INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
				        SELECT TOP 100 warehouseId,locationNo,@putPolicy
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.allocQty,0.0)) AS onhandQty
						        FROM BAS_Location a 
							        INNER JOIN dbo.IMS_Allocate b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)							                --公司Id
							        AND (a.warehouseId=@warehouseId)					                --目标仓库
							        AND (a.zoneId=@targZone)						                    --目标库区
							        AND (a.isDisable=0)									                --有效库位
							        AND (a.isFixed=0)									                --非固定库位
							        AND (a.isPackage=@isPackage)						                --库位使用
							        AND (b.ioFlag='+')									                --预分配
							        AND (b.itemId=@itemId)							                    --历史商品
							        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
							    GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY onhandQty DESC,putawayOrder;
			            --历史可用库位(有库存的,库存少的，上架顺序)
				        INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
				        SELECT TOP 100 warehouseId,locationNo,@putPolicy
				        FROM (
						        SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty,
						            SUM(CASE WHEN ISNULL(b.onhandQty,0.0)>0.0 OR ISNULL(b.onWayQty,0.0)>0.0 THEN 1 ELSE 0 END) AS hasFlag
						        FROM BAS_Location a 
							        INNER JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
						        WHERE (a.companyId=@companyId)							                --公司Id
							        AND (a.warehouseId=@warehouseId)					                --目标仓库
							        AND (a.zoneId=@targZone)						                    --目标库区								        
							        AND (a.isDisable=0)									                --有效库位
							        AND (a.isFixed=0)									                --非固定库位
							        AND (a.isPackage=@isPackage)						                --库位使用
							        AND (b.itemId=@itemId)                                              --历史商品
							        AND (@inventoryMode=0 OR (@inventoryMode=1 AND b.lotNo=@lotNo))     --非批次或者当前批次
							    GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
					        ) t
				        ORDER BY hasFlag DESC,onhandQty DESC,putawayOrder;				
				        --其他合适的可用库位(策略224，225，226)
                        IF (@putPolicy=224 OR @putPolicy=225 OR @putPolicy=226)
                        BEGIN
			                INSERT INTO @tmpLocation(warehouseId,locationNo,putPolicy)
			                SELECT TOP 100 warehouseId,locationNo,@putPolicy
			                FROM (
					                SELECT a.warehouseId,a.regionId,a.locationNo,a.putawayOrder,SUM(ISNULL(b.onhandQty,0.0)+ISNULL(b.onWayQty,0.0)) AS onhandQty,
					                    SUM(CASE b.itemId WHEN @itemId THEN 1 ELSE 0 END) AS hisFlag 
					                FROM BAS_Location a 
						                LEFT JOIN dbo.IMS_Stock b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
					                WHERE (a.companyId=@companyId)							                --公司Id
						                AND (a.warehouseId=@warehouseId)					                --目标仓库
						                AND (a.zoneId=@targZone)						                    --目标库区
						                AND (a.isDisable=0)									                --有效库位
						                AND (a.isFixed=0)									                --非固定库位
						                AND (a.isPackage=@isPackage)						                --库位使用
						            GROUP BY a.warehouseId,a.regionId,a.locationNo,a.putawayOrder
				                ) t
			                ORDER BY hisFlag DESC,onhandQty DESC,putawayOrder;
			            END
				    END
			    END
			END
		END
	    --4.体积/数量限制过滤
	    IF (ISNULL(@allowVolumed,1)=0)
	    BEGIN
	        INSERT INTO @tmpLayer(warehouseId,regionId,locationWay,locationRow,locationLayer,minOrder)
	        SELECT *
	        FROM (
	                SELECT a.warehouseId,b.regionId,b.locationWay,b.locationRow,b.locationLayer,MIN(a.viewOrder) viewOrder  
	                FROM @tmpLocation a
	                    INNER JOIN BAS_Location b ON a.warehouseId=b.warehouseId AND a.locationNo=b.locationNo
	                GROUP BY a.warehouseId,b.regionId,b.locationWay,b.locationRow,b.locationLayer
	                ) t
	        ORDER BY viewOrder;
            WHILE EXISTS(SELECT * FROM @tmpLayer)
            BEGIN
	            SELECT TOP 1 @viewOrder=viewOrder,@regionId=regionId,@locationWay=locationWay,@locationRow=locationRow,
	                @locationLayer=locationLayer,@minOrder=minOrder 
	            FROM @tmpLayer 
	            ORDER BY viewOrder;
	            --获取第一个库位所在的层的可用空间
	            SELECT @availVolume=ISNULL(maxVolume,0.0)-ISNULL(onhandVolume,0.0)-ISNULL(onwayVolume,0.0)
	            FROM BAS_LocationVolumn_V
	            WHERE warehouseId=@warehouseId AND locationWay=@locationWay AND locationRow=@locationRow AND locationLayer=@locationLayer;
		        --如果当前层能放，则放再当前层第一推荐库位
		        IF (@availVolume-@receiveQty*ISNULL(@itemVolume,0.0)>0.0)
                BEGIN
                    INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                    SELECT @warehouseId,@regionId,locationNo,@itemId,@lotNo,@receiveQty
                    FROM @tmpLocation a
                    WHERE warehouseId=@warehouseId AND viewOrder=@minOrder;   
                    SET @receiveQty=0;
                    BREAK;
                END 
                ELSE
                BEGIN
		            --散件体积
		            IF (@unitLevel='EA')
                    BEGIN
                        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT @warehouseId,@regionId,locationNo,@itemId,@lotNo,FLOOR(@availVolume/@itemVolume)
                        FROM @tmpLocation a
                        WHERE warehouseId=@warehouseId AND viewOrder=@minOrder;           
                        SET @receiveQty=@receiveQty-FLOOR(@availVolume/@itemVolume);
                        IF (@receiveQty<0.0)
                            BREAK;
	                END
                    ELSE        
                    BEGIN
                        INSERT INTO @uTable(warehouseId,regionId,locationNo,itemId,lotNo,SQty)
                        SELECT @warehouseId,@regionId,locationNo,@itemId,@lotNo,FLOOR(@availVolume/@pkgVolume)*@pkgRatio
                        FROM @tmpLocation a
                        WHERE warehouseId=@warehouseId AND viewOrder=@minOrder;           
                        SET @receiveQty=@receiveQty-FLOOR(@availVolume/@pkgVolume)*@pkgRatio;
                        IF (@receiveQty<0.0)
                            BREAK;
                     END
	            END
	            DELETE FROM @tmpLayer WHERE viewOrder=@viewOrder;
	        END
	        --清除临时数据表
	        DELETE FROM @tmpLocation;
	        --数量分配完毕跳出函数
	        IF (@receiveQty<=0.0)
	            BREAK;    
	    END
		FETCH NEXT FROM myPlicy INTO @putPolicy,@targRegion,@targLocation,@targZone,@allowVolumed,@itemMix,@lotMix,@isPackage,@putMode
	END
	CLOSE myPlicy;
	DEALLOCATE myPlicy;
	DELETE FROM @tmpLayer;
	DELETE FROM @tmpLocation;
	DELETE FROM @hisLocation;
	DELETE FROM @tbParas;
    RETURN;
END
go

