
--库房代码
CREATE VIEW dbo.BDM_WareHouse_V
AS
SELECT CodeID, CodeNo, CHName, ENName, Flag,Classify, DeptNo,CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL16')
go

