--说明：采购收票汇总分析
--作者：Devil.H
--创建：2007.11.26
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:标识
CREATE Function dbo.fn_AnalPMS6A
(
	@StartDate char(10)='0000-01-01',
	@EndDate char(10)='9999-12-31',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	IType varchar(20),
	ITypeName varchar(100),
	VendorID bigint,
	VendorNo varchar(20),
	VendorName varchar(200),
	NameSpell varchar(200),
	BuyerID bigint,
	Buyer varchar(100),
	IAmt decimal(18,6),
	DAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40)
)
As
Begin
	--退出
	if @Flag=0 
		Return
	--初始化变量
	Set @StartDate=Convert(Char(10),Cast(@StartDate as datetime),120)
	Set @EndDate=Convert(Char(10),Cast(@EndDate as datetime),120) 
	--按客户汇总
	if isnull(@CorpNo,'')='' And isnull(@DeptNo,'')=''
		Insert Into @uTable(IType,VendorID,IAmt,DAmt)
		Select IType,VendorID,Sum(IAmt),Sum(DAmt)
		From PMS_Invoice 
		Where (BillSts='20' Or BillSts='25' Or BillSts='30') 
			And (Convert(Char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
		Group by IType,VendorID
	--按部门汇总
	if isnull(@CorpNo,'')='' And (Not isnull(@DeptNo,'')='')
		Insert Into @uTable(IType,VendorID,IAmt,DAmt)
		Select IType,VendorID,Sum(IAmt),Sum(DAmt)
		From PMS_Invoice 
		Where (BillSts='20' Or BillSts='25' Or BillSts='30') 
			And DeptNo=@DeptNo
			And (Convert(Char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
		Group by IType,VendorID
	--按公司客户汇总
	if (Not isnull(@CorpNo,'')='') And isnull(@DeptNo,'')=''
		Insert Into @uTable(IType,VendorID,IAmt,DAmt)
		Select IType,VendorID,Sum(IAmt),Sum(DAmt)
		From PMS_Invoice a
		Where (BillSts='20' Or BillSts='25' Or BillSts='30')
			And (Convert(Char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
			And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And d.DeptNo=@CorpNo)
		Group by IType,VendorID
	--按公司部门汇总
	if (Not isnull(@CorpNo,'')='') And (Not isnull(@DeptNo,'')='')
		Insert Into @uTable(IType,VendorID,IAmt,DAmt)
		Select IType,VendorID,Sum(IAmt),Sum(DAmt)
		From PMS_Invoice a
		Where (BillSts='20' Or BillSts='25' Or BillSts='30') 
			And (Convert(Char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
			And DeptNo=@DeptNo
			And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And d.DeptNo=@CorpNo)
		Group by IType,VendorID
	--更新供应商信息
	Update a Set a.VendorNo=b.VendorNo,a.VendorName=b.VendorName,a.NameSpell=b.NameSpell,
		a.BuyerID=b.BuyerID,a.Buyer=b.Buyer,a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes
	From @uTable a inner join BDM_Vendor_V b on a.VendorID=b.VendorID	--返回
	--更新发票类型
	Update a Set a.ITypeName=b.CHName
	From @uTable a inner join BDM_InvoiceType_V b On a.IType=b.CodeID
	return 
End
go

