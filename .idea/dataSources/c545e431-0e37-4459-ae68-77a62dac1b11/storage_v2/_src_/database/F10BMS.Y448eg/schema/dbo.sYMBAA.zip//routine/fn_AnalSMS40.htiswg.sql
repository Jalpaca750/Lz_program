--说明：客户商品销售汇总分析
--作者：Devil.H
--创建：2010.06.01
--参数：
--	@StartDate:起始日期
--	@EndDate:截止日期
--	@CorpNo:公司No
--	@DeptNo:部门
--修改：2021-03-17 增加销售员维度(原销售员跟随客户资料，改为跟随单据）
CREATE FUNCTION [dbo].[fn_AnalSMS40]
(	
	@StartDate CHAR(10)='0000-01-01',
	@EndDate CHAR(10)='9999-12-31',
	@DeptNo VARCHAR(20)=''
) 
RETURNS TABLE
As
RETURN(	
    SELECT t.CustID,c.CustNo,c.CustName,c.NameSpell AS CustSpell,c.LinkMan,c.Phone,c.Faxes,t.SalesID,e.EmployeeName AS Sales,
        t.ItemID,g.ItemNo,g.ItemName,g.ItemAlias,g.NameSpell AS ItemSpell,g.ItemSpec,g.BarCode,g.MidBarcode,
        g.BigBarcode,g.PkgBarcode,g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,g.UnitName,t.SQty,
        t.Amt,ROUND(t.Amt*ISNULL(c.Rebate,0.0)/100.0,2) AS RebateAmt,ROUND(t.Amt*ISNULL(c.PlatformFee,0.0)/100.0,2) AS PlatformFee,
        t.Amt-ROUND(t.Amt*ISNULL(c.Rebate,0.0)/100.0,2)-ROUND(t.Amt*ISNULL(c.PlatformFee,0.0)/100.0,2) AS RealAmt,c.CustType,c.TypeName,
        c.MemberID,c.Member,c.AreaCode,c.AreaName,c.PopedomID,c.PopedomName,c.KindName,c.TradeName,g.PkgSpec,
        CASE ISNULL(g.PkgRatio,0.0) WHEN 0.0 THEN NULL ELSE ROUND(ISNULL(t.SQty,0.0)/g.PkgRatio,4) END PkgQty,
        t.DepartId,dc.CHName AS DepartName
    FROM (SELECT a.CustID,a.SalesID,a.DepartId,b.ItemID,SUM(ISNULL(b.Amt,0.0)) AS Amt,SUM(ISNULL(b.SQty,0.0)) AS SQty
    	  FROM SMS_Stock a 
              INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
          WHERE (a.BillSts='20' Or a.BillSts='30' Or a.BillSts='25')
    		AND (CONVERT(CHAR(10),CAST(a.CreateDate AS DATETIME),23) BETWEEN @StartDate AND @EndDate)
    		AND (a.DeptNo Like @DeptNo + '%')
    	  GROUP BY a.CustID,a.SalesID,a.DepartId,b.ItemID) t 
        INNER JOIN BAS_Customer_V c ON t.CustID=c.CustID
        INNER JOIN BAS_Goods_V g ON t.ItemID=g.ItemID
        LEFT JOIN BDM_DeptCode_V dc ON t.DepartId=dc.CodeID
        LEFT JOIN BDM_Employee e ON t.SalesID=e.EmployeeID
)
go

