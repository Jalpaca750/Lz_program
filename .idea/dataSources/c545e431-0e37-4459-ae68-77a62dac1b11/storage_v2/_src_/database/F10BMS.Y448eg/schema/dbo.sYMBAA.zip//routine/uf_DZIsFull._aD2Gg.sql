

--说明：判断定制是否回来
--作者：Devil.H
--创建：2007.11.04
--参数：@Period:会计月份
CREATE Function uf_DZIsFull
(
	@StockNo AS VARCHAR(20)
)
RETURNS @uTable TABLE
(
    StockNo VARCHAR(20),
    DZQty DECIMAL(28,6)
)
AS
BEGIN
    --如果计划中存在对应出库订单Id,则对应入库单入库才允许出库
    IF EXISTS(SELECT * FROM PMS_PlanDtl WHERE XS_OrderID In(SELECT OrderID FROM SMS_StockDtl WHERE StockNo=@StockNo))
        INSERT INTO @uTable(StockNo,DZQty)
        SELECT @StockNo,ISNULL(y.SQty, 0) - ISNULL(x.SQty, 0) AS DZQty
    	FROM dbo.SMS_StockDtl x 
            LEFT JOIN(SELECT b.XS_OrderID, SUM(b.SQty) AS SQty
                      FROM PMS_Stock a 
                          INNER JOIN PMS_StockDtl b ON a.StockNo = b.StockNo
                      WHERE a.BillSts NOT IN ('00', '10') 
    			          AND b.XS_OrderID In(SELECT OrderID FROM SMS_StockDtl WHERE StockNo=@StockNo)
    		          GROUP BY b.XS_OrderID) y ON x.OrderID = y.XS_OrderID
    	Where x.StockNo=@StockNo
    ELSE
        INSERT INTO @uTable(StockNo,DZQty)
        SELECT @StockNo,1 AS DZQty
    RETURN;
END

go

