
CREATE VIEW [dbo].[PMS_PaymentDtl_V]
AS
SELECT b.PaymentID, b.PaymentNo, c.CreateDate, c.DeptNo, c.VendorID, c.Credence, 
    b.InvoiceID, b.InvoiceNo, b.Invoice, b.IAmt, b.DAmt, 
    ISNULL(a.IAmt, 0) - ISNULL(a.PAmt, 0) AS RemAmt, b.FAmt, b.PayAmt, 
    b.Remarks, b.CheckBox,a.CreateDate As InvoiceDate,
    b.BillType,'采购发票' AS BillTypeDesc
FROM dbo.PMS_PaymentDtl b 
    INNER JOIN dbo.PMS_Payment c ON b.PaymentNo = c.PaymentNo 
    LEFT JOIN dbo.PMS_Invoice a ON b.InvoiceID = a.InvoiceID
WHERE b.BillType=10
UNION ALL
SELECT a.PaymentID, a.PaymentNo, c.CreateDate, c.DeptNo, c.VendorID, c.Credence,
    a.InvoiceID,CASE ISNULL(a.InvoiceNo, '')  WHEN '' THEN b.StockNo ELSE a.InvoiceNo END AS InvoiceNo, 
    a.Invoice, a.IAmt, a.DAmt, ISNULL(b.Amt, 0) - ISNULL(b.NewPAmt, 0) AS RemAmt, a.FAmt, a.PayAmt,
    a.Remarks,a.CheckBox,b.CreateDate As InvoiceDate,  a.BillType,
    CASE a.BillType WHEN 20 THEN  '采购入库单' WHEN 30 THEN '采购退货单' WHEN 40 THEN '采购调价单' END AS BillTypeDesc
FROM dbo.PMS_PaymentDtl a 
    INNER JOIN dbo.PMS_Payment c ON a.PaymentNo = c.PaymentNo 
    LEFT JOIN (SELECT x.StockNo,x.CreateDate,x.NewPAmt,SUM(y.Amt) AS Amt
               FROM dbo.PMS_Stock x
                    INNER JOIN dbo.PMS_StockDtl y ON x.StockNo=y.StockNo
               GROUP BY x.StockNo,x.CreateDate,x.NewPAmt) b ON a.InvoiceNo = b.StockNo
WHERE a.BillType IN(20,30,40)
go

