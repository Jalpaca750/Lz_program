CREATE VIEW dbo.IMS_RectifyDtl_V
AS
SELECT a.RectifyID, a.RectifyNo, b.CreateDate, a.DeptNo, b.BillSts, a.ItemID, c.ItemNo, 
      c.ItemName, c.ItemAlias, c.NameSpell, c.ItemSpec, c.BarCode, c.ClassID, 
      c.ClassName, c.LabelID, c.LabelName, c.ColorName, c.UnitName, a.OnHandQty, 
      a.Price, ROUND(ISNULL(a.OnHandQty, 0) * ISNULL(a.Price, 0), 2) AS OnAmt, a.MPrice, 
      a.Amt, c.PPrice, c.SPrice, c.SPrice1, c.SPrice3, c.SPrice2, a.Remarks, 
      a.CheckBox
FROM dbo.BAS_Goods_V c INNER JOIN
      dbo.IMS_RectifyDtl a ON c.ItemID = a.ItemID LEFT OUTER JOIN
      dbo.IMS_Rectify b ON a.RectifyNo = b.RectifyNo
go

