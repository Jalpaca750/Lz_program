--修改原零售业务主表视图
CREATE VIEW dbo.POS_Retail_V
AS
SELECT a.RetailNo, a.CreateDate, a.CreateTime, a.DeptNo, b.CHName AS DeptName, 
	a.WareHouse, c.CHName AS WHName, a.PCNo, a.CustID, f.CustNo, f.CustName, 
      	f.NameSpell, f.CustType, f.TypeName, f.MemberID, f.Member, f.AreaCode, 
      	f.AreaName, f.PopedomID, f.PopedomName, a.SalesID, h.EmployeeName AS Sales, 
      	f.LinkMan, f.Phone, f.Faxes, a.Invoice, 
      	CASE a.BillType WHEN '40' THEN g.Amt 
			WHEN '50' THEN - g.Amt END AS Amt, 
      	g.DiscAmtHJ, a.DiscRate, 
      	CASE a.BillType WHEN '40' THEN g.Amt - a.DiscAmt 
			WHEN '50' THEN - g.Amt - (- a.DiscAmt) END AS SSAmt, 
      	CASE a.BillType WHEN '40' THEN a.DiscAmt 
			WHEN '50' THEN - a.DiscAmt END AS DiscAmt,
      	CASE a.BillType WHEN '40' THEN a.PaymentXJ 
			WHEN '50' THEN - a.PaymentXJ END AS PaymentXJ, 
      	CASE a.BillType WHEN '40' THEN a.PaymentSK 
			WHEN '50' THEN - a.PaymentSK END AS PaymentSK, 
      	CASE a.BillType WHEN '40' THEN a.PaymentZP 
			WHEN '50' THEN - a.PaymentZP END AS PaymentZP, 
      	CASE a.BillType WHEN '40' THEN a.PaymentDD 
			WHEN '50' THEN - a.PaymentDD END AS PaymentDD, 
	CASE a.BillType WHEN '40' THEN a.PaymentCZ 
			WHEN '50' THEN - a.PaymentCZ END AS PaymentCZ,
	CASE a.BillType WHEN '40' THEN a.Receive1Amt 
			WHEN '50' THEN - a.Receive1Amt END AS Receive1Amt, 
      	CASE a.BillType WHEN '40' THEN a.Receive2Amt 
			WHEN '50' THEN - a.Receive2Amt END AS Receive2Amt, 
	CASE a.BillType WHEN '40' THEN a.Receive3Amt 
			WHEN '50' THEN - a.Receive3Amt END AS Receive3Amt,

	a.PaymentIntegralDD, a.PaymentDtlSK, a.PaymentDtlZP, a.DiscountCardNo, a.CardDiscRate, 
      	CASE a.CashFlag WHEN 'A' THEN '现金' 
			WHEN 'B' THEN '支票' 
			WHEN 'C' THEN '刷卡' 
			WHEN 'D' THEN '抵用券' 
			WHEN 'E' THEN '其他' 
			WHEN 'Z' THEN '转配送' END AS CashFlag, 
      	a.BillSts, (SELECT StsName
         	    FROM BillStatus sts
         	    WHERE a.BillSts = sts.BillSts AND BillType = 'SMSA0') AS StsName, a.PFlag, 
      	a.FFlag, a.BillType AS IOType, 
      	CASE a.BillType WHEN '40' THEN '零售出库单' 
			WHEN '50' THEN '零售退货单' END AS BillType,
       a.AuditDate, a.AuditID, e.EmployeeName AS Auditer, a.CreatorID, 
      	d.EmployeeName AS Creator, a.PrintNum,a.ShiftNo, a.Remarks, a.CheckBox
FROM dbo.BDM_Employee h RIGHT OUTER JOIN
      dbo.SMS_Retail a ON h.EmployeeID = a.SalesID LEFT OUTER JOIN
      dbo.BAS_Customer_V f ON a.CustID = f.CustID LEFT OUTER JOIN
      dbo.BDM_Employee d ON a.CreatorID = d.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee e ON a.AuditID = e.EmployeeID LEFT OUTER JOIN
      dbo.BDM_WareHouse_V c ON a.WareHouse = c.CodeID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID LEFT OUTER JOIN
          (SELECT RetailNo, SUM(Amt) AS Amt, SUM(DiscAmt) AS DiscAmtHJ
           FROM SMS_RetailDtl
           GROUP BY RetailNo) g ON a.RetailNo = g.RetailNo
go

