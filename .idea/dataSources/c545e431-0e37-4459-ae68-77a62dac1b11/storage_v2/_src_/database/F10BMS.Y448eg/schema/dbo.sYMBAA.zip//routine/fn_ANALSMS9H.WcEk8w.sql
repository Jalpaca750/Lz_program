CREATE FUNCTION fn_ANALSMS9H()
RETURNS TABLE
AS
RETURN
SELECT a.CreateDate,a.OrderNo,a.DeptNo,d.CHName AS DeptName,a.CustID,c.CustNo,c.CustName,
    c.NameSpell AS CustSpell,a.SendAddr,a.LinkMan,a.Phone,a.PoNo,a.SalesID,e1.EmployeeName AS SalesName,
    cc.CHName AS Costcenter,a.orderreninfo,dtl.Amt,t.CKAmt,t.IAmt,t.ArAmt,
    (SELECT StsName FROM BillStatus bs WHERE a.BillSts=bs.BillSts AND bs.BillType='SMS30') AS BillStsDesc,
    a.CreatorID,e2.EmployeeName AS CreatorName,e3.EmployeeName AS AuditorName,WmsFlag,
    CONVERT(VARCHAR(20),a.AuditTime,120) AS AuditTime,t.Outtime,
    t.PHDate,t.CarNumberDate,t.DeliveryDate,t.BackDate,a.Remarks AS Memo
FROM SMS_Order a
    INNER JOIN BAS_Customer_V c ON a.CustID=c.CustID
    INNER JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
    INNER JOIN BDM_Employee e1 ON a.SalesID=e1.EmployeeID
    INNER JOIN (SELECT OrderNo,SUM(Amt) Amt FROM SMS_OrderDtl GROUP BY OrderNo) dtl ON a.OrderNo=dtl.OrderNo
    LEFT JOIN BDM_Employee e2 ON a.CreatorID=e2.EmployeeID
    LEFT JOIN BDM_Employee e3 ON a.AuditId=e3.EmployeeID
    LEFT JOIN Web_Costs_Class cc ON a.CostsID=cc.CostsID
    LEFT JOIN (SELECT b.OrderNo,CONVERT(VARCHAR(20),MAX(a.CreateTime),120) AS Outtime,
                    MAX(CONVERT(VARCHAR(20),a.DeliveryTime,120)) AS DeliveryDate,
                    MAX(CONVERT(VARCHAR(20),a.PH_DateTime,120)) PHDate,
                    MAX(CONVERT(VARCHAR(20),a.CarNumberDate,120)) CarNumberDate,
                    MAX(a.BackDate) AS BackDate,
                    SUM(b.Amt) AS CKAmt,SUM(b.IAmt) AS IAmt,SUM(c.ArAmt) AS ARAmt
                FROM SMS_Stock a
                    INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
                    LEFT JOIN (SELECT StockID,SUM(ARAmt) ARAmt FROM SMS_PaymentEx GROUP BY StockID) c ON b.StockID=c.StockID
                WHERE (a.BillType='10')
                    AND (a.BillSts IN('20','25','30'))
                GROUP BY b.OrderNo) t ON a.OrderNo=t.OrderNo
WHERE a.BillSts IN('05','10','20','25','30')
go

