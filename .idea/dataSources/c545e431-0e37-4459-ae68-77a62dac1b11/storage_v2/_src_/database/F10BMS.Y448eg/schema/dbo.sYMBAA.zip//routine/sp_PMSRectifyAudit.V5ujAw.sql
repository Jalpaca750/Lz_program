



--采购调价单审核操作（Update BillSts)
--2007-10-15
--Devil.H
--当上述操作发生时：
--更新库房总帐数量，同时更商品资料、入出库流水帐单状态
CREATE Proc sp_PMSRectifyAudit
(
	@RectifyNo varchar(20),
	@Flag char(2)
)
As
Begin
	declare @VendorID bigint
	declare @DeptNo varchar(20)
	declare @Amt decimal(18,6)
	declare @warehouse varchar(20)
	select @DeptNo=DeptNo,@VendorID=VendorID from PMS_Rectify Where @RectifyNo=@RectifyNo
	select @Amt =Sum(Amt) from PMS_RectifyDtl Where @RectifyNo=@RectifyNo
    select Top 1 @warehouse=warehouse FROM PMS_Stock Where StockNo IN(Select StockNo From PMS_RectifyDtl Where RectifyNo=@RectifyNo)
	--审核通过
	if @Flag='20'
		begin
			--写入供应商欠款
			Update BDM_Vendor Set ArgAmt=isnull(ArgAmt,0)+isnull(@Amt,0) Where VendorID=@VendorID
			--写入采购入库单
			Insert Into PMS_Stock(StockNo,DeptNo,Warehouse,CreateDate,VendorID,BillType,BillSts,CreatorID,
				AuditDate,AuditID,Remarks)
			Select RectifyNo,DeptNo,@Warehouse,CreateDate,VendorID,'30','20',CreatorID,AuditDate,AuditID,Remarks 
			From PMS_Rectify
			Where RectifyNo=@RectifyNo And Not Exists(Select 1 From PMS_Stock Where StockNo=@RectifyNo)
			--写入采购入库明细
			Insert Into PMS_StockDtl(StockNo,ItemID,WareHouse,SQty,Price,Amt,TaxFlag)
			Select RectifyNo,ItemID,WareHouse,0,MPrice,Amt,TaxFlag
			From PMS_RectifyDtl_V
			Where RectifyNo=@RectifyNo And Not Exists(Select 1 From PMS_StockDtl Where StockNo=@RectifyNo)
			--调整进价
			if exists(select 1 from PMS_Rectify Where RectifyNo=@RectifyNo And Effect=1)
				begin
					--更新进价设置
					Update a Set a.Price=b.MPrice,a.TaxFlag=b.TaxFlag
					From PMS_Price a,PMS_RectifyDtl b
					Where b.RectifyNo=@RectifyNo And a.VendorID=@VendorID And a.ItemID=b.ItemID
						And a.DeptNo=@DeptNo	
					--更新默认供应商进价设置
					Update a Set a.Price=b.MPrice
					From IMS_Subdepot a,PMS_RectifyDtl b
					Where a.ItemID=b.ItemID And a.VendorID=@VendorID And b.RectifyNo=@RectifyNo
						And a.DeptNo=@DeptNo	
				end				
		end
	--取消审核
	if @Flag='10' 
		begin
			--写入供应商欠款
			Update BDM_Vendor Set ArgAmt=isnull(ArgAmt,0)-isnull(@Amt,0) where VendorID=@VendorID
			--删除明细数据
			Delete From PMS_StockDtl WHere StockNo=@RectifyNo 
			--删除入库单数据
			Delete From PMS_Stock Where StockNo=@RectifyNo
		End
	if @Flag='00'	
		Return
End
go

