
CREATE PROCEDURE [dbo].[sp_AfterItemSaved]
(
	@itemNo VARCHAR(20)
)
AS
BEGIN
	DECLARE @companyId VARCHAR(32),			--公司Id
			@ownerId VARCHAR(32),			--业主Id
			@operatorId VARCHAR(32),		--操作员Id	
			@curTime DATETIME,				--操作时间
			@url VARCHAR(100);				--Bone地址
    DECLARE @itemId VARCHAR(32),			--商品Id
			@eId VARCHAR(32),				--主商品Id
			@brandId VARCHAR(32),			--品牌Id
			@brandNo VARCHAR(32),			--品牌No
			@categoryId VARCHAR(32),		--分类Id
			@categoryNo VARCHAR(32),		--分类No
			@colorName VARCHAR(40),			--颜色
			@unitName VARCHAR(40),			--单位
			@regionId VARCHAR(32),			--Wms区域编码ID
			@regionNo VARCHAR(32),			--区域编码(F10的自定义4）
			@tmpNo VARCHAR(32),
			@len INT,
            @startShop BIT,                  --接口VIP等网站
            @errors BIGINT;                 --错误Id
    SET @curTime=GETDATE();
    SET @errors=0;
    --如果WMS接口未开启，直接退出
	IF NOT EXISTS(SELECT * FROM dbo.SYS_Config WHERE ISNULL(startWMS,0)=1)
	    RETURN;
    IF EXISTS(SELECT 1 FROM dbo.BDM_ItemInfo WHERE ItemNo=@itemNo AND syncFlag=1)
		RETURN;
    --固定公司Id,业主Id和操作员Id
	SELECT TOP 1 @companyId=companyId,@operatorId=IOperatorId,@url=VipUrl,@ownerId=OwnerId,@startShop=ISNULL(StartShop,'') FROM dbo.SYS_Config;	
	--取商品品牌和商品分类,颜色，单位
	SELECT @brandNo=b.CodeNo,@tmpNo=a.LabelID,@categoryNo=a.ClassID,@colorName=a.colorName,@unitName=a.unitName,@regionNo=a.Defined4
	FROM dbo.BDM_ItemInfo a 
		LEFT JOIN dbo.BDM_LabelCode_V b ON a.labelId=b.codeID
	WHERE itemNo=@itemNo;
	--清除当前商品错误资料
	DELETE FROM YiWms.dbo.SAM_Error WHERE companyId=@companyId AND funCode='sp_AfterItemSaved' AND creatorId=@operatorId AND billNo=@itemNo;
	SET @errors=@errors+@@ERROR;
	BEGIN TRANSACTION
	--1.处理品牌资料
	IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Brand WHERE companyId=@companyId AND brandNo=@brandNo)
		EXEC sp_AfterCodeSaved @tmpNo;
    SET @errors=@errors+@@ERROR;
	--取贵重物品或者水果的存放区域
	SELECT @regionId=regionId
	FROM YiWms.dbo.BAS_Region
	WHERE companyId=@companyId AND regionNo=@regionNo;	
	--直接取当前设置过的品牌Id
	SELECT @brandId=brandId
	FROM YiWms.dbo.BAS_Brand
	WHERE companyId=@companyId AND brandNo=@brandNo;		
	--2.处理分类资料
	IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Category WHERE companyId=@companyId AND categoryNo=@categoryNo)
		EXEC sp_AfterCodeSaved @categoryNo;
    SET @errors=@errors+@@ERROR;
	--直接获取分类Id
	SELECT @categoryId=categoryId 
	FROM YiWms.dbo.BAS_Category 
	WHERE companyId=@companyId AND categoryNo=@categoryNo		
	--新增商品资料
	IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Item WHERE companyId=@companyId AND ownerId=@ownerId AND itemNo=@itemNo)
	BEGIN
		--查看Bone库数据
		IF (@startShop=1)
        BEGIN
		    IF EXISTS(SELECT 1 FROM Bone.dbo.BAS_Item WHERE companyId=@companyId AND itemNo=@itemNo)
		    BEGIN
			    ----取Bone商品Id
			    SELECT @itemId=LOWER(itemId) FROM Bone.dbo.BAS_Item WHERE companyId=@companyId AND itemNo=@itemNo;
			    --取Bone商品Sku数据
			    INSERT INTO YiWms.dbo.ECM_ItemSku(itemId,eId,colorId,colorName,sizeId,sizeName,unitId,unitName,companyId)
			    SELECT itemId,eId,colorId,colorName,sizeId,sizeName,unitId,unitName,@companyId
			    FROM Bone.dbo.ECM_ItemSku
			    WHERE itemId=@itemId;
                SET @errors=@errors+@@ERROR;
			    --取Bone商品图片
			    INSERT INTO YiWms.dbo.BAS_ItemImage(imageId,eId,itemId,imageType,largeUrl,middleUrl,smallUrl,littleUrl,viewOrder,companyId) 
			    SELECT imageId,eId,itemId,imageType,@url + largeUrl,@url + middleUrl,@url + smallUrl,@url + littleUrl,viewOrder,@companyId
			    FROM Bone.dbo.BAS_ItemImage
			    WHERE itemId=@itemId AND imageType=1;
                SET @errors=@errors+@@ERROR;
		    END
            ELSE
            BEGIN
                SET @itemId=LOWER(REPLACE(NEWID(),'-',''));
			    INSERT INTO YiWms.dbo.ECM_ItemSku(itemId,eId,colorId,colorName,sizeId,sizeName,unitId,unitName,companyId)
			    VALUES(@itemId,LOWER(REPLACE(NEWID(),'-','')),'c999',@colorName,'s99','无','EA',@unitName,@companyId);
                SET @errors=@errors+@@ERROR;
            END
        END
		ELSE
		BEGIN
			SET @itemId=LOWER(REPLACE(NEWID(),'-',''));
			INSERT INTO YiWms.dbo.ECM_ItemSku(itemId,eId,colorId,colorName,sizeId,sizeName,unitId,unitName,companyId)
			VALUES(@itemId,LOWER(REPLACE(NEWID(),'-','')),'c999',@colorName,'s99','无','EA',@unitName,@companyId);
            SET @errors=@errors+@@ERROR;
		END
		--商品资料库
		INSERT INTO YiWms.dbo.BAS_Item(itemId,companyId,itemNo,itemCTitle,itemETitle,itemName,
			itemSpec,itemSpell,barcode,brandId,categoryId,colorName,sizeName,packageId,unitName,
			itemLong,itemWidth,itemHeight,itemWeight,itemVolume,midBarcode,middleRatio,middleUnit,
			middleVolume,middleWeight,bigBarcode,bigRatio,bigUnit,bigVolume,bigWeight,pkgUnit,pkgRatio,
			pkgBarcode,pkgLong,pkgWidth,pkgHeight,pkgWeight,pkgVolume,allowExcess,excessRate,purLeadTime,
			inventoryMode,isSafety,safetyMonth,safetyDays,isUnsalable,isStop,isVirtual,allowSplit,splitRatio,
			printControl,usage,itemState,commodityId,ownerId,remarks,isLocked,lockerId,lockedTime,createTime,
			creatorId,editTime,editorId,putRegion,csPutRegion,pickRegion,csPickRegion)
		SELECT @itemId,@companyId,@itemNo,itemName,itemName,itemName,
			itemSpec,NameSpell,barcode,@brandId,@categoryId,colorName,'无',PkgSpec,unitName,
			itemLong,itemWidth,itemHeight,itemWeight,itemVolume,midBarcode,middleRatio,middleUnit,
			middleVolume,middleWeight,bigBarcode,bigRatio,bigUnit,bigVolume,bigWeight,pkgUnit,pkgRatio,
			pkgBarcode,pkgLong,pkgWidth,pkgHeight,pkgWeight,pkgVolume,0,0,purDays,
			--CASE ItemPHFlag WHEN 'F' THEN 0 ELSE 1 END,CASE ItemPHFlag WHEN 'F' THEN 0 ELSE 1 END,safetyDays,AdvancedDays,
			0,0,safetyDays,AdvancedDays,--2018-01-11日，不采用批次管理，等待开启
			isUnsalable,isStop,isVirtual,allowSplit,splitRatio,printControl,0,flag,itemId,
			@ownerId,remarks,0,'',NULL,@curTime,@operatorId,@curTime,@operatorId,@regionId,@regionId,@regionId,@regionId
		FROM BDM_ItemInfo
		WHERE itemNo=@itemNo;
        SET @errors=@errors+@@ERROR;
		--写入操作日志
		INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
		SELECT LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterItemSaved','通过接口同步商品资料，商品:[' + @itemNo + ']',@itemId,@itemNo
        SET @errors=@errors+@@ERROR;
	END
	ELSE
	BEGIN
		UPDATE a SET a.itemCTitle=b.itemName,
					 a.itemETitle=b.itemName,
					 a.itemName=b.itemName,
					 a.itemSpec=b.itemSpec,
					 a.itemSpell=b.NameSpell,
					 a.barcode=b.barcode,
					 a.brandId=@brandId,
					 a.categoryId=@categoryId,
					 a.colorName=b.colorName,
					 a.sizeName=ISNULL(a.sizeName,'无'),
					 a.packageId=b.PkgSpec,
					 a.unitName=b.unitName,
					 --a.itemLong=b.itemLong,
					 --a.itemWidth=b.itemWidth,
					 --a.itemHeight=b.itemHeight,
					 --a.itemWeight=b.itemWeight,
					 --a.itemVolume=b.itemVolume,
					 a.midBarcode=b.midBarcode,
					 a.middleRatio=b.middleRatio,
					 a.middleUnit=b.middleUnit,						 
					 a.middleVolume=b.middleVolume,
					 a.middleWeight=b.middleWeight, 
					 a.bigBarcode=b.bigBarcode,
					 a.bigRatio=b.bigRatio,
					 a.bigUnit=b.bigUnit,
					 a.bigVolume=b.bigVolume,
					 a.bigWeight=b.bigWeight,
					 a.pkgBarcode=b.pkgBarcode,
					 --a.pkgUnit=b.pkgUnit,
					 --a.pkgRatio=b.pkgRatio,						 
					 --a.pkgLong=b.pkgLong,
					 --a.pkgWidth=b.pkgWidth,
					 --a.pkgHeight=b.pkgHeight,
					 --a.pkgWeight=b.pkgWeight,
					 --a.pkgVolume=b.pkgVolume,
					 a.purLeadTime=b.purDays,
					 a.inventoryMode=0,--CASE b.ItemPHFlag WHEN 'F' THEN 0 ELSE 1 END,
					 a.isSafety=0,--CASE b.ItemPHFlag WHEN 'F' THEN 0 ELSE 1 END,
					 a.safetyMonth=b.safetyDays,
					 a.safetyDays=b.AdvancedDays,
					 a.isUnsalable=b.isUnsalable,
					 a.isStop=b.isStop,
					 a.isVirtual=b.isVirtual,
					 a.allowSplit=b.allowSplit,
					 a.splitRatio=b.splitRatio,
					 a.printControl=a.printControl,
					 a.usage=0,
					 a.itemState=b.flag,
					 a.commodityId=b.itemId,
					 a.ownerId=@ownerId,
					 a.remarks=b.remarks,
					 a.putRegion=@regionId,
					 a.csPutRegion=@regionId,
					 a.pickRegion=@regionId,
					 a.csPickRegion=@regionId,
					 a.isLocked=0,
					 a.lockerId='',
					 a.lockedTime=NULL,
					 a.editTime=@curTime,
					 a.editorId=@operatorId
		FROM YiWms.dbo.BAS_Item a 
			INNER JOIN dbo.BDM_ItemInfo b ON a.itemNo=b.ItemNo
		WHERE a.companyId=@companyId AND a.ownerId=@ownerId AND a.ItemNo=@itemNo;
        SET @errors=@errors+@@ERROR;
        IF (@startShop=1)
        BEGIN
    		--查看Bone库数据(更新图片数据）
    		IF EXISTS(SELECT 1 FROM Bone.dbo.BAS_Item WHERE companyId=@companyId AND itemNo=@itemNo)
    		BEGIN
    			----取YiWms商品Id
    			SELECT @itemId=LOWER(itemId) FROM YiWms.dbo.BAS_Item WHERE companyId=@companyId AND ownerId=@ownerId AND itemNo=@itemNo;
    			SELECT TOP 1 @eId=eId FROM YiWms.dbo.ECM_ItemSku WHERE itemId=@itemId; 
    			--取Bone商品图片
    			--删除源主图
    			DELETE FROM YiWms.dbo.BAS_ItemImage WHERE itemId=@itemId AND imageType=1;
                SET @errors=@errors+@@ERROR;
    			INSERT INTO YiWms.dbo.BAS_ItemImage(imageId,eId,itemId,imageType,largeUrl,middleUrl,smallUrl,littleUrl,viewOrder,companyId) 
    			SELECT imageId,@eId,@itemId,imageType,@url + largeUrl,@url + middleUrl,@url + smallUrl,@url + littleUrl,viewOrder,@companyId
    			FROM Bone.dbo.BAS_ItemImage a 
    			WHERE itemId=@itemId AND imageType=1;
                SET @errors=@errors+@@ERROR;
    		END
        END
        --写入操作日志
		INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
		SELECT LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterItemSaved','通过接口同步修改商品资料，商品:[' + @itemNo + ']',@itemId,@itemNo
        SET @errors=@errors+@@ERROR;

		--写入操作日志
		--INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
		--SELECT LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterItemSaved',
		--	'通过接口修改商品资料[' + @itemNo + ']，关键属性修改:原单位' + ISNULL(a.unitName,'') + '修改为[' + ISNULL(b.unitName,'') + ']' + 
		--	';原整箱长' + ISNULL(CAST(a.pkgLong AS VARCHAR(20)),'') + '修改为[' + ISNULL(CAST(b.pkgLong AS VARCHAR(20)),'') + ']' +
		--	';原整箱宽' + ISNULL(CAST(a.pkgWidth AS VARCHAR(20)),'') + '修改为[' + ISNULL(CAST(b.pkgWidth AS VARCHAR(20)),'') + ']' +
		--	';原整箱高' + ISNULL(CAST(a.pkgHeight AS VARCHAR(20)),'') + '修改为[' + ISNULL(CAST(b.pkgHeight AS VARCHAR(20)),'') + ']' +
		--	';原整箱重量' + ISNULL(CAST(a.pkgWeight AS VARCHAR(20)),'') + '修改为[' + ISNULL(CAST(b.pkgWeight AS VARCHAR(20)),'') + '];',
		--	a.itemId,@itemNo
		--FROM YiWms.dbo.BAS_Item a 
		--	INNER JOIN dbo.BDM_ItemInfo b ON a.itemNo=b.ItemNo
		--WHERE a.companyId=@companyId AND a.ownerId=@ownerId AND a.ItemNo=@itemNo
	END
	UPDATE dbo.BDM_ItemInfo SET syncFlag=1 WHERE itemNo=@itemNo;
    SET @errors=@errors+@@ERROR;
	IF (@errors=0)
    BEGIN
        COMMIT;
    END
    ELSE
	BEGIN
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;
        
		RAISERROR(@ErrMsg, @ErrSeverity, 1)			
		--写入操作日志
		INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)	
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@curTime,@operatorId,'sp_AfterItemSaved','SYNC_ITEM_ERROR','商品['+ @itemNo + ']资料同步失败，错误：'+ @ErrMsg,@itemNo,@itemNo);
	END
END

go

