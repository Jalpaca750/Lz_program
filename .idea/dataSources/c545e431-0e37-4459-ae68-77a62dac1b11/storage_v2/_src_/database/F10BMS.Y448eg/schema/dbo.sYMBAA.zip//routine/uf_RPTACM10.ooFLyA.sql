--说明：系统报表之销售收款单
--作者：Devil.H
--创建：2007.10.31
--参数：
--	@BillNo	 :单据编号
--	@Row	 :每页打印行数
CREATE Function dbo.uf_RPTACM10
(
	@BillNo varchar(20),
	@Row bigint,
	@ByField varchar(30)
)
Returns @uTable Table(
	BillID bigint identity(1,1),
	BillNo varchar(20),
	InvoiceNo varchar(20),
    InvoiceDate varchar(10),
	Invoice varchar(200),
	IAmt decimal(18,6),
	DAmt decimal(18,6),
	FAmt decimal(18,6),
	PayAmt decimal(18,6),
	Remarks varchar(2000)
)
As
Begin	
	declare @Rows bigint
	declare @NullRow bigint
	declare @i bigint
	--初始化变量
	Set @i=0
	--如果没有传递行数，默认9行
	Set @Row=isnull(@Row,9)
	if isnull(@BillNo,'')=''
		Return
	Insert Into @uTable(BillNo,InvoiceNo,InvoiceDate,Invoice,IAmt,DAmt,FAmt,PayAmt)
	Select PaymentNo,InvoiceNo,InvoiceDate,Invoice,IAmt,DAmt,FAmt,PayAmt
	From SMS_PaymentDtl_V
	Where PaymentNo=@BillNo
	Order By PaymentID
	--总的行数
	Select @Rows=Count(1) From @uTable
	if @Rows=0 
		return
	Set @NullRow=@Row-@Rows%@Row
	if @NullRow=@Row 
		Return
	while @i<@NullRow
		Begin
			Insert Into @uTable(BillNo)
			Values(@BillNo)
			Set @i=@i+1
		End
	--返回
	return
End
go

