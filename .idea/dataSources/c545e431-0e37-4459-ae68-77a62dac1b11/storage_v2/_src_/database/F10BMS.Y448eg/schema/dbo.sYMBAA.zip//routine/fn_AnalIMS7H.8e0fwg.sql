--说明：入出库数量月报表
--作者：Devil.H
--创建：2007.11.04
--参数：@Period:会计月份
CREATE function dbo.fn_AnalIMS7H
(
	@OldPeriod char(6),
	@StartDate varchar(10),
	@EndDate varchar(10)
)
Returns Table 
As 
Return(Select DeptNo,WareHouse,ItemID,Sum(QCQty) As QCQty,Sum(QCAmt) As QCAmt,Sum(CGRK) As CGRK,
		Sum(DBRK) As DBRK,Sum(ZPRK) As ZPRK,Sum(QTRK) As QTRK,
		Sum(ZZRK) As ZZRK,Sum(CXRK) As CXRK,Sum(PDRK) As PDRK,Sum(XSCK) As XSCK,
		Sum(LSCK) As LSCK,Sum(DBCK) As DBCK,Sum(ZPCK) As ZPCK,Sum(QTCK) As QTCK,
		Sum(ZZCK) As ZZCK,Sum(CXCK) As CXCK,Sum(QMQty) As QMQty,
		Sum(YCDQty) As YCDQty
	From (Select DeptNo,WareHouse,ItemID,0.0 As QCQty,0.0 as QCAmt,
			CGRK=Sum(Case BillType when '采购入库单' then Isnull(SQty,0.0) else 0.0 end)
				+Sum(Case BillType when '采购退货单' then Isnull(SQty,0.0) else 0.0 end),
			DBRK=Sum(Case BillType when '调拨入库单' then Isnull(SQty,0.0) else 0.0 end),
			ZPRK=Sum(Case BillType when '赠品入库单' then Isnull(SQty,0.0) else 0.0 end),
			QTRK=Sum(Case BillType when '其他入库单' then Isnull(SQty,0.0) else 0.0 end)
				+Sum(Case BillType when '库存初始化' then Isnull(SQty,0.0) else 0.0 end),
			ZZRK=Sum(Case BillType when '组装入库单' then Isnull(SQty,0.0) else 0.0 end),
			CXRK=Sum(Case BillType when '拆卸入库单' then Isnull(SQty,0.0) else 0.0 end),
			PDRK=Sum(Case BillType when '盘存清单' then Isnull(SQty,0.0) else 0.0 end),
			XSCK=Sum(Case BillType when '销售出库单' then Isnull(SQty,0.0) else 0.0 end)
				+Sum(Case BillType when '销售退货单' then Isnull(SQty,0.0) else 0.0 end),
			LSCK=Sum(Case BillType when '零售出库单' then Isnull(SQty,0.0) else 0.0 end)
				+Sum(Case BillType when '零售退货单' then Isnull(SQty,0.0) else 0.0 end),
			DBCK=Sum(Case BillType when '调拨出库单' then Isnull(SQty,0.0) else 0.0 end),
			ZPCK=Sum(Case BillType when '赠品出库单' then Isnull(SQty,0.0) else 0.0 end),
			QTCK=Sum(Case BillType when '其他出库单' then Isnull(SQty,0.0) else 0.0 end)
				+Sum(Case BillType when '报损出库单' then Isnull(SQty,0.0) else 0.0 end),
			ZZCK=Sum(Case BillType when '组装出库单' then Isnull(SQty,0.0) else 0.0 end),
			CXCK=Sum(Case BillType when '拆卸出库单' then Isnull(SQty,0.0) else 0.0 end),0.0 as QMQty,
			YCDQty=Sum(Case BillType when '移仓单' then Isnull(SQty,0.0) else 0.0 end)
		From IMS_Flow
		Where CreateDate Between @StartDate And @EndDate
		Group By DeptNo,WareHouse,ItemID
		Union All
		Select DeptNo,WareHouse,ItemID,QMQty,QMAmt,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0
		From ANAL_IMS7H
		Where Period=@OldPeriod) a
	Group By DeptNo,WareHouse,ItemID
)
go

