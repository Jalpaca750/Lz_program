--说明：采购入库未开票年度分析
--作者：Devil.H
--创建：2007.11.26
--参数：
--	@Year:月份
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:标识
CREATE Function dbo.fn_AnalPMS60
(
	@Year int=0,
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	VendorID bigint,
	VendorNo varchar(20),
	VendorName varchar(200),
	NameSpell varchar(200),
	BuyerID bigint,
	Buyer varchar(100),
	Month01Amt decimal(18,6),
	Month02Amt decimal(18,6),
	Month03Amt decimal(18,6),
	Month04Amt decimal(18,6),
	Month05Amt decimal(18,6),
	Month06Amt decimal(18,6),
	Month07Amt decimal(18,6),
	Month08Amt decimal(18,6),
	Month09Amt decimal(18,6),
	Month10Amt decimal(18,6),
	Month11Amt decimal(18,6),
	Month12Amt decimal(18,6),
	TotalAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40)
)
As
Begin
	if @Flag=0
		Return
	--没有过滤条件
	if isnull(@CorpNo,'')='' And isnull(@DeptNo,'')=''
		INSERT INTO @uTable(VendorID,Month01Amt,Month02Amt,Month03Amt,Month04Amt,
					     Month05Amt,Month06Amt,Month07Amt,Month08Amt,
					     Month09Amt,Month10Amt,Month11Amt,Month12Amt,TotalAmt)
		SELECT a.VendorID,
			Month01Amt = SUM(CASE MONTH(a.CreateDate) WHEN  1 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END), 
			Month02Amt = SUM(CASE MONTH(a.CreateDate) WHEN  2 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month03Amt = SUM(CASE MONTH(a.CreateDate) WHEN  3 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month04Amt = SUM(CASE MONTH(a.CreateDate) WHEN  4 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month05Amt = SUM(CASE MONTH(a.CreateDate) WHEN  5 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month06Amt = SUM(CASE MONTH(a.CreateDate) WHEN  6 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month07Amt = SUM(CASE MONTH(a.CreateDate) WHEN  7 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month08Amt = SUM(CASE MONTH(a.CreateDate) WHEN  8 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month09Amt = SUM(CASE MONTH(a.CreateDate) WHEN  9 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month10Amt = SUM(CASE MONTH(a.CreateDate) WHEN 10 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month11Amt = SUM(CASE MONTH(a.CreateDate) WHEN 11 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month12Amt = SUM(CASE MONTH(a.CreateDate) WHEN 12 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	TotalAmt   = SUM(ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0))
		FROM PMS_Stock a inner join PMS_StockDtl b On a.StockNo = b.StockNo
		WHERE Year(a.CreateDate)=@Year And (a.BillSts='20' Or a.BillSts='25')
		GROUP BY a.VendorID
	--按部门过滤
	if isnull(@CorpNo,'')='' And (Not isnull(@DeptNo,'')='')
		INSERT INTO @uTable(VendorID,Month01Amt,Month02Amt,Month03Amt,Month04Amt,
					     Month05Amt,Month06Amt,Month07Amt,Month08Amt,
					     Month09Amt,Month10Amt,Month11Amt,Month12Amt,TotalAmt)
		SELECT a.VendorID,
			Month01Amt = SUM(CASE MONTH(a.CreateDate) WHEN  1 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END), 
			Month02Amt = SUM(CASE MONTH(a.CreateDate) WHEN  2 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month03Amt = SUM(CASE MONTH(a.CreateDate) WHEN  3 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month04Amt = SUM(CASE MONTH(a.CreateDate) WHEN  4 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month05Amt = SUM(CASE MONTH(a.CreateDate) WHEN  5 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month06Amt = SUM(CASE MONTH(a.CreateDate) WHEN  6 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month07Amt = SUM(CASE MONTH(a.CreateDate) WHEN  7 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month08Amt = SUM(CASE MONTH(a.CreateDate) WHEN  8 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month09Amt = SUM(CASE MONTH(a.CreateDate) WHEN  9 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month10Amt = SUM(CASE MONTH(a.CreateDate) WHEN 10 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month11Amt = SUM(CASE MONTH(a.CreateDate) WHEN 11 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month12Amt = SUM(CASE MONTH(a.CreateDate) WHEN 12 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	TotalAmt   = SUM(ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0))
		FROM PMS_Stock a inner join PMS_StockDtl b On a.StockNo = b.StockNo
		WHERE Year(a.CreateDate)=@Year And (a.BillSts='20' Or a.BillSts='25') And (a.DeptNo=@DeptNo) 
		GROUP BY a.VendorID
	--按公司过滤
	if (Not isnull(@CorpNo,'')='') And isnull(@DeptNo,'')=''
		INSERT INTO @uTable(VendorID,Month01Amt,Month02Amt,Month03Amt,Month04Amt,
					     Month05Amt,Month06Amt,Month07Amt,Month08Amt,
					     Month09Amt,Month10Amt,Month11Amt,Month12Amt,TotalAmt)
		SELECT a.VendorID,
			Month01Amt = SUM(CASE MONTH(a.CreateDate) WHEN  1 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END), 
			Month02Amt = SUM(CASE MONTH(a.CreateDate) WHEN  2 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
   			Month03Amt = SUM(CASE MONTH(a.CreateDate) WHEN  3 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month04Amt = SUM(CASE MONTH(a.CreateDate) WHEN  4 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month05Amt = SUM(CASE MONTH(a.CreateDate) WHEN  5 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month06Amt = SUM(CASE MONTH(a.CreateDate) WHEN  6 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month07Amt = SUM(CASE MONTH(a.CreateDate) WHEN  7 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month08Amt = SUM(CASE MONTH(a.CreateDate) WHEN  8 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month09Amt = SUM(CASE MONTH(a.CreateDate) WHEN  9 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month10Amt = SUM(CASE MONTH(a.CreateDate) WHEN 10 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month11Amt = SUM(CASE MONTH(a.CreateDate) WHEN 11 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month12Amt = SUM(CASE MONTH(a.CreateDate) WHEN 12 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	TotalAmt   = SUM(ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0))
		FROM PMS_Stock a inner join PMS_StockDtl b On a.StockNo = b.StockNo
		WHERE Year(a.CreateDate)=@Year And (a.BillSts='20' Or a.BillSts='25')
			And Exists(SELECT 1 FROM BDM_DeptCode_V d WHERE a.DeptNo=d.CodeID And d.DeptNo=@CorpNo)
		GROUP BY a.VendorID
	--按公司部门过滤
	if (Not isnull(@CorpNo,'')='') And (Not isnull(@DeptNo,'')='')
		INSERT INTO @uTable(VendorID,Month01Amt,Month02Amt,Month03Amt,Month04Amt,
					     Month05Amt,Month06Amt,Month07Amt,Month08Amt,
					     Month09Amt,Month10Amt,Month11Amt,Month12Amt,TotalAmt)
		SELECT a.VendorID,
			Month01Amt = SUM(CASE MONTH(a.CreateDate) WHEN  1 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END), 
			Month02Amt = SUM(CASE MONTH(a.CreateDate) WHEN  2 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month03Amt = SUM(CASE MONTH(a.CreateDate) WHEN  3 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month04Amt = SUM(CASE MONTH(a.CreateDate) WHEN  4 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month05Amt = SUM(CASE MONTH(a.CreateDate) WHEN  5 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month06Amt = SUM(CASE MONTH(a.CreateDate) WHEN  6 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month07Amt = SUM(CASE MONTH(a.CreateDate) WHEN  7 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month08Amt = SUM(CASE MONTH(a.CreateDate) WHEN  8 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month09Amt = SUM(CASE MONTH(a.CreateDate) WHEN  9 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month10Amt = SUM(CASE MONTH(a.CreateDate) WHEN 10 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month11Amt = SUM(CASE MONTH(a.CreateDate) WHEN 11 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	Month12Amt = SUM(CASE MONTH(a.CreateDate) WHEN 12 THEN ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) ELSE 0.0 END),
		    	TotalAmt   = SUM(ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0))
		FROM PMS_Stock a inner join PMS_StockDtl b On a.StockNo = b.StockNo
		WHERE Year(a.CreateDate)=@Year And (a.BillSts='20' Or a.BillSts='25') And a.DeptNo=@DeptNo
			And Exists(SELECT 1 FROM BDM_DeptCode_V d WHERE a.DeptNo=d.CodeID And d.DeptNo=@CorpNo)
		GROUP BY a.VendorID
	--更新供应商信息
	Update a Set a.VendorNo=b.VendorNo,a.VendorName=b.VendorName,a.NameSpell=b.NameSpell,
		a.BuyerID=b.BuyerID,a.Buyer=b.Buyer,a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes
	FROM @uTable a inner join BDM_Vendor_V b on a.VendorID=b.VendorID
	--返回
	Return
End
go

