
--销售订单明细插入操作（Insert)
--2008-12-09
--wujinfeng
--当上述操作发生时：
--当前合同的已执行数量减少
CREATE Trigger Trig_SMS_OrderDtl_Ins
On dbo.SMS_OrderDtl
For Insert
As
Begin
	declare @BillNo varchar(20),@BillID bigint,@OrderID bigint,@orderAmt decimal(18,6),@conAmt decimal(18,6); 
	--已执行数量更新
	Update a Set a.SQty=Isnull(a.SQty,0)+Isnull(b.OQty,0) 
    From CON_SmsDtl a 
        Inner Join Inserted b On a.BillID=b.BillID;	
    --获取写入订单金额
    Select @orderAmt=Sum(Amt) 
    From SMS_OrderDtl 
    Where OrderNo IN(Select OrderNo From Inserted);
    --获取写入合同单号
    Select @BillNo=BillNo From Inserted;
    if (Isnull(@billNo,'')<>'')
	Begin
        Select @conAmt=Round(Sum(Isnull(Qty, 0)* Isnull(Price, 0)), 2) 
        From CON_SmsDtl
        Where BillNo=@BillNo;
        --存在未执行的记录
    	if exists(Select * from CON_SmsDtl_V Where Isnull(ExecQty,0)>0 And BillNo=@BillNo)
    		Update CON_Sms Set BillSts='25' Where BillNo=@BillNo And BillSts<>'05'
    	else
    		Update CON_Sms Set BillSts='30' Where BillNo=@BillNo And BillSts<>'05'
		--如果合同未执行完成，但订单金额大于等于合同金额，则合同自动完成
        if (Isnull(@orderAmt,0.0)-Isnull(@conAmt,0.0)>=0.0)
            Update CON_Sms Set BillSts='30' Where BillNo=@BillNo And BillSts<>'05'
    end
End
go

