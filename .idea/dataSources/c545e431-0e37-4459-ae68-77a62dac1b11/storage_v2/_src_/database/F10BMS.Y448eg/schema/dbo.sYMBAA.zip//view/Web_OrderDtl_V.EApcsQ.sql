CREATE VIEW dbo.Web_OrderDtl_V
AS
SELECT a.OrderID,c.CustID,a.DeptNo,a.OrderNo,a.ItemID,b.ItemNo,b.ItemName,b.ItemSpec,b.ColorName,b.UnitName,a.OQty,a.OQty As RemsQty,a.Price, 
      a.Amt,b.PkgRatio,CASE isnull(b.PkgRatio, 0) WHEN 0 THEN NULL ELSE round(Isnull(a.OQty,0)/isnull(b.pkgratio,0),4) END AS PkgQty, 
      a.ZQty, a.DiscRate, a.IsSpecial, a.IsEffect,a.SQty, a.SZQty, a.PQty, a.PresentNo, b.PkgSpec, b.PPrice, b.SPrice, b.SPrice1, 
      b.SPrice2, b.SPrice3, b.SafePPrice, b.SafeSPrice, b.OnHandQty, b.AllocQty, b.HotFlag, 
      b.NotDisc, b.IsWeb, b.BPackage, b.MPackage, b.Package, a.Remarks, a.CheckBox,a.RowGuid
FROM dbo.WEB_Order c RIGHT OUTER JOIN
      dbo.WEB_OrderDtl a ON c.OrderNo = a.OrderNo LEFT OUTER JOIN
      dbo.BDM_ItemInfo b ON a.ItemID = b.ItemID

go

