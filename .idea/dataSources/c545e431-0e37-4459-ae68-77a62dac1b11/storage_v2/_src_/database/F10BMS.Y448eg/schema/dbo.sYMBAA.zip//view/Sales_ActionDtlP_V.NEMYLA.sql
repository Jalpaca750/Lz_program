----下一工作计划
CREATE VIEW dbo.Sales_ActionDtlP_V
AS

SELECT a.BillID, a.BillNo,'计划内' As PlanXZ, C.CHName As PlanType,a.Object,a.Content,a.RQ
,a.ExecuteSts
,a.BillID As BillID_N
,a.CustID
FROM dbo.Sales_ActionDtl_N a 

LEFT OUTER JOIN      dbo.BDM_PlanType_V c ON a.PlanType = c.CodeID

/*
SELECT a.BillID, a.BillNo,a.PlanXZ, C.CHName As PlanType,a.Object,a.Content,a.RQ,a.ExecuteSts,a.BillID_P

FROM dbo.Sales_ActionDtl a 
--LEFT OUTER JOIN      dbo.Sales_Action b ON a.BillNo = b.BillNo
LEFT OUTER JOIN      dbo.BDM_PlanType_V c ON a.PlanType = c.CodeID
*/







go

