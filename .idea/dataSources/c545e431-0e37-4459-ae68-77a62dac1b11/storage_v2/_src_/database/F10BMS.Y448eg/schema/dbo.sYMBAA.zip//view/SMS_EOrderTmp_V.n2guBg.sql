CREATE VIEW dbo.SMS_EOrderTmp_V
AS
SELECT a.OrderNo, b.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, b.ItemSpec, 
      b.BarCode, b.ClassID, b.ClassName, b.LabelID, b.LabelName, b.ColorName, 
      b.UnitName, a.OQty, a.Price, a.Amt, b.BPackage, b.MPackage, b.Package, b.PPrice, 
      b.SPrice, b.SPrice1, b.SPrice2, b.SPrice3, b.SafePPrice, b.SafeSPrice, b.PkgRatio, 
      b.PkgSpec, b.HotFlag, b.NotDisc
FROM dbo.SMS_EOrderTmp a LEFT OUTER JOIN
      dbo.BDM_ItemInfo_V b ON a.ItemNo = b.ItemNo
go

