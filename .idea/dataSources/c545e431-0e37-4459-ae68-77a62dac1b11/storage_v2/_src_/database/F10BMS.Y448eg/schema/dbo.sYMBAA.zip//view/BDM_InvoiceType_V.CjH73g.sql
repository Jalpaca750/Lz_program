
--发票类型
CREATE VIEW dbo.BDM_InvoiceType_V
AS
SELECT CodeID, CodeNo, CHName, ENName,Flag,Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL07')
go

