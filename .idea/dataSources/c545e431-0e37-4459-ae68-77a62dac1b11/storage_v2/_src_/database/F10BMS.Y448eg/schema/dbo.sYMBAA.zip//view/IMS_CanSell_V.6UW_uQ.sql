CREATE VIEW dbo.IMS_CanSell_V
AS
SELECT a.DeptNo,c.CHName AS DeptName,a.ItemID,b.ItemNo,b.ItemName,b.ItemAlias,b.NameSpell,b.ItemSpec,b.BarCode,b.ClassID,
    b.ClassName,b.LabelID,b.LabelName,b.ColorName,b.UnitName,a.Location,a.OnHandQty,a.AllocQty,
    CASE ISNULL(b.PkgRatio,0.0) WHEN 0.0 THEN Null ELSE ROUND (ISNULL(a.OnHandQty,0)/ISNULL(b.PkgRatio,0.0),4) END AS PkgQty, 
    ISNULL(a.OnHandQty, 0) - ISNULL(a.AllocQty, 0) AS AvailQty
FROM IMS_Subdepot a
    INNER JOIN BAS_Goods_V b ON a.ItemID=b.ItemID
    INNER JOIN BDM_DeptCode_V c ON a.DeptNo=c.CodeID
go

