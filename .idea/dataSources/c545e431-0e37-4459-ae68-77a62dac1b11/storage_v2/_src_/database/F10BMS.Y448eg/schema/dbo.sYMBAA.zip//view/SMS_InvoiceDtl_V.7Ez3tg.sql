--发票明细增加发货单送货地址
CREATE VIEW dbo.SMS_InvoiceDtl_V
AS
SELECT a.InvoiceID, a.InvoiceNo, d.CreateDate, d.BillSts, a.StockID, a.StockNo, e.BillType, 
    a.ItemID, c.ItemNo, c.ItemName, c.ItemAlias, c.NameSpell, c.ItemSpec, c.BarCode, 
    c.ClassID, c.ClassName, c.LabelID, c.LabelName, c.ColorName, c.UnitName, 
    ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0)+ISNULL(a.Amt,0.0) AS RemAmt,
    ISNULL(b.SQty,0.0) - ISNULL(b.IQty,0.0)+ISNULL(a.IQty,0.0) AS RemIQty, a.IQty, a.Price, a.Amt, 
    a.IsSpecial, a.TaxFlag, ISNULL(b.PaidAmt, 0) - ISNULL(b.PAmt, 0)+ISNULL(a.PaidAmt,0.0) AS RemPAmt, 
    a.PaidAmt, a.CPrice, ROUND(ISNULL(a.IQty, 0) * ISNULL(a.CPrice, 0), 2) AS CAmt, a.OrderID, 
    a.OrderNo, c.Integral, c.BPackage, c.MPackage, c.Package, c.PPrice, c.SPrice, 
    c.SPrice1, c.SPrice2, c.SPrice3, a.Remarks, a.CheckBox, a.Integral AS DtlIntegral, 
    d.CustID, d.PaymentUnAuditingFlag, a.SMSAStockFlag, CB.CostsName,
    CASE ISNULL(c.ZPName,'') WHEN '' THEN c.ItemName ELSE c.ZPName END AS ZPName, 
    CASE ISNULL(c.ZPCode,'') WHEN '' THEN c.ItemNo ELSE c.ZPCode END AS ZPCode,
    E.OrderRenInfo,E.SendAddr,a.ARQty,a.ARAmt,a.ARDiscount
FROM dbo.SMS_InvoiceDtl a 
    LEFT JOIN dbo.BAS_Goods_V c ON a.ItemID = c.ItemID 
    LEFT JOIN dbo.SMS_Invoice d ON a.InvoiceNo = d.InvoiceNo 
    LEFT JOIN dbo.SMS_StockDtl b ON a.StockID = b.StockID 
    LEFT JOIN dbo.SMS_Stock E ON a.StockNo = E.StockNo 
    LEFT JOIN dbo.SMS_Order_V CB ON b.OrderNo = CB.OrderNo
go

