CREATE VIEW dbo.SMS_ChangeDtl_V
AS
SELECT a.ChangeID, a.ChangeNo, b.CreateDate, b.BillSts, a.EmployeeID, 
      c.EmployeeName, a.ChangeAmt, a.InkName, a.Remark, a.CheckBox
FROM dbo.SMS_ChangeDtl a INNER JOIN
      dbo.SMS_Change b ON a.ChangeNo = b.ChangeNo INNER JOIN
      dbo.BDM_Employee c ON a.EmployeeID = c.EmployeeID
go

