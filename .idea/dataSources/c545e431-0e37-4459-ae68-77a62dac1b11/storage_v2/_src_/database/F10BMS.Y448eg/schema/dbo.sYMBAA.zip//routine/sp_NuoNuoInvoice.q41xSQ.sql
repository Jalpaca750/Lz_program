

CREATE PROC sp_NuoNuoInvoice
(
    @serialNum VARCHAR(40),
    @Flag CHAR(2),
    @errCode BIGINT OUTPUT
)
AS
BEGIN   
    DECLARE @InvoiceNo VARCHAR(32);
    DECLARE @InvoiceBillNo VARCHAR(20);
    DECLARE @CustID BIGINT;
    DECLARE @DeptNo VARCHAR(20);
    DECLARE @IType VARCHAR(20);
    DECLARE @IAmt DECIMAL(18,6);
    DECLARE @SendAddr VARCHAR(200);
    DECLARE @LinkMan VARCHAR(40);
    DECLARE @Phone VARCHAR(80);
    DECLARE @Invoice VARCHAR(200);
    DECLARE @oldInvoiceNo VARCHAR(20);
    DECLARE @InvoiceNum VARCHAR(20);
    DECLARE @Paymode VARCHAR(20);
    DECLARE @IDays INT;
    DECLARE @ARDate VARCHAR(10);
    DECLARE @Remarks VARCHAR(2000);
    DECLARE @CurDate VARCHAR(10);
    DECLARE @SalesID BIGINT;
    DECLARE @RedFlag INT;
    DECLARE @errors BIGINT;
    --如果非标准版，则退出
    IF EXISTS(SELECT * FROM SYS_Config WHERE ISNULL(FPInterfaceBy,1)=1)
        RETURN;
    --获取开票数据对应的资料
    SELECT @InvoiceNo=a.invoiceNo,@DeptNo=b.DeptNo,@CustID=b.CustID,@SendAddr=b.SendAddr,
        @LinkMan=b.LinkMan,@Phone=b.Phone,@InvoiceBillNo=a.orderNo,@IType=ISNULL(t.CodeID,''),
        @SalesID=b.SalesID,@CurDate=CONVERT(VARCHAR(10),a.createTime,23),@IAmt=a.totalFee,
        @RedFlag=CASE a.invoiceType WHEN '1' THEN 0 ELSE 1 END,@InvoiceNum=invoiceNum
    FROM TCS_Order a
        INNER JOIN SMS_Stock b ON a.boneOrderBillNo=b.StockNo
        INNER JOIN BDM_Customer c ON b.CustID=c.CustID
        LEFT JOIN BDM_InvoiceType_V t ON a.invoiceLine=t.CodeNo
    WHERE a.invoiceSerialNum=@serialNum;
    --获取出库单备注
    SET @Remarks='';
    SELECT @Remarks=@Remarks+a.Remarks+';'
    FROM SMS_Stock a
        INNER JOIN TCS_InvoiceDetail b ON a.StockNo=b.orderNo
    WHERE b.invoiceNo=@InvoiceNo
        AND ISNULL(a.Remarks,'')<>'';
    --非已开票或者已作废的发票不执行
    IF NOT EXISTS(SELECT * FROM TCS_Invoice WHERE serialNo=@serialNum AND [status] IN('2','3'))
        RETURN;
    --发票号码
    SELECT @Invoice=invoiceNo
    FROM TCS_Invoice
    WHERE serialNo=@serialNum;
    SET @errors=0;
    BEGIN TRAN
    IF (@Flag='20')
    BEGIN
        --红字发票
        IF (@RedFlag=1)
        BEGIN
            --原始发票单号
            SELECT @oldInvoiceNo=orderNo FROM TCS_Invoice WHERE invoiceNo=@InvoiceNum;            
            --写入发票
            INSERT INTO SMS_Invoice(InvoiceNo,DeptNo,CreateDate,CustID,IType,Invoice,PayMode,IAmt,DAmt,PAmt,BillSts,
                PFlag,Integral,SalesID,AuditID,AuditDate,CreatorID,Remarks,PaymentUnAuditingFlag,ARDate,PrintNum,
                SendBill,RedFlag,SendAddr,LinkMan,Phone)
            VALUES(@InvoiceBillNo,@DeptNo,@CurDate,@CustID,@IType,@Invoice,'',@IAmt,0.0,0.0,'20',0,0,@SalesID,99,
                CONVERT(VARCHAR(10),GETDATE(),23),99,@Remarks,-1,@ARDate,0,'财务下账',0,@SendAddr,@LinkMan,@Phone);
            SET @errors=@errors+@@ERROR;
            --写入红冲对应表
            INSERT INTO RED_Bill(BillType,RedNo,BillNo) Values('SMS90',@InvoiceBillNo, @oldInvoiceNo);
            SET @errors=@errors+@@ERROR;
            --更新原单红字状态为被红冲
            UPDATE SMS_Invoice SET RedFlag=1 WHERE InvoiceNo=@oldInvoiceNo;
            SET @errors=@errors+@@ERROR;
        END
        ELSE
        BEGIN
            --写入发票
            INSERT INTO SMS_Invoice(InvoiceNo,DeptNo,CreateDate,CustID,IType,Invoice,PayMode,IAmt,DAmt,PAmt,BillSts,
                PFlag,Integral,SalesID,AuditID,AuditDate,CreatorID,Remarks,PaymentUnAuditingFlag,ARDate,PrintNum,
                SendBill,RedFlag,SendAddr,LinkMan,Phone)
            VALUES(@InvoiceBillNo,@DeptNo,@CurDate,@CustID,@IType,@Invoice,'',@IAmt,0.0,0.0,'20',0,0,@SalesID,99,
                CONVERT(VARCHAR(10),GETDATE(),23),99,@Remarks,0,@ARDate,0,'财务下账',0,@SendAddr,@LinkMan,@Phone);
            SET @errors=@errors+@@ERROR;
        END
        --写入销售发票明细
        INSERT INTO SMS_InvoiceDtl(InvoiceNo,StockID,StockNo,BillType,ItemID,IQty,Price,Amt,IsSpecial,TaxFlag,OrderID,
            OrderNo,Remarks,SMSAStockFlag,CreateDate,ARQty,ARAmt,ARDiscount)
        SELECT @invoiceBillNo,b.StockID,b.StockNo,c.BillType,b.ItemID,a.num,a.price,a.taxIncludedAmount,b.IsSpecial,b.TaxFlag,b.OrderID,
            b.OrderNo,b.Remarks,0,@CurDate,0.0,0.0,0.0
        FROM TCS_InvoiceDetail a
            INNER JOIN SMS_Stock c ON a.orderNo=c.StockNo
            INNER JOIN SMS_StockDtl b ON a.orderId=CAST(b.StockID AS VARCHAR(32))
        WHERE a.invoiceNo=@InvoiceNo;
        SET @errors=@errors+@@ERROR;
        --审核销售发票
        EXEC sp_SMSInvoiceAudit @InvoiceBillNo,'20';
        SET @errors=@errors+@@ERROR;
    END
    ELSE IF (@Flag='00')
    BEGIN
        --如果发票存在，则直接作废
        IF EXISTS(SELECT * FROM SMS_Invoice WHERE InvoiceNo=@InvoiceBillNo)
        BEGIN
            --更新发票状态
            UPDATE SMS_Invoice SET BillSts='00' WHERE InvoiceNo=@InvoiceBillNo;
            SET @errors=@errors+@@ERROR;
            EXEC sp_SMSInvoiceAudit @InvoiceBillNo,'00';
            SET @errors=@errors+@@ERROR;
        END
    END
    IF (@errors=0)
    BEGIN
        COMMIT;
        SET @errCode=0;
    END
    ELSE
    BEGIN
        ROLLBACK;
        SET @errCode=-1;
    END
END
go

