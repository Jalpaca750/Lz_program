
create view SMS_OrderInvoice_V as
SELECT c.OrderNo,c.PoNo,COUNT(*) AS invoiceCount
FROM SMS_Invoice a
    INNER JOIN SMS_InvoiceDtl b ON a.InvoiceNo=b.InvoiceNo
    INNER JOIN SMS_Order c ON b.OrderNo=c.OrderNo
WHERE a.BillSts IN('10','20','25','30')
	AND (a.RedFlag=0)
GROUP BY c.OrderNo,c.PoNo
go

