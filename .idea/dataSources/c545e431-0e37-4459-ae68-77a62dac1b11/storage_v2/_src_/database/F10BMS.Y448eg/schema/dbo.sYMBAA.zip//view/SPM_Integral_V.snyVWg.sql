--积分设置
CREATE VIEW dbo.SPM_Integral_V
--with encryption
AS
SELECT a.IntegID, a.MemberID, CASE isnull(a.MemberID, '') 
      WHEN '' THEN '所有客户' ELSE c.CHName END AS Member, a.AreaCode, 
      CASE isnull(a.AreaCode, '') 
      WHEN '' THEN '所有地区' ELSE d .CHName END AS AreaName, a.IntegAmt, 
      a.Integral,a.CreateDate,a.AmendDate
FROM dbo.SPM_Integral a LEFT OUTER JOIN
      dbo.BDM_AreaCode_V d ON a.AreaCode = d .CodeID LEFT OUTER JOIN
      dbo.BDM_MemberCode_V c ON a.MemberID = c.CodeID

go

