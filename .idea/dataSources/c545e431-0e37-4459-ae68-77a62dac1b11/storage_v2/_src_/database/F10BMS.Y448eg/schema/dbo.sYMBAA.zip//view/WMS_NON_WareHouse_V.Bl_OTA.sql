--仓库资料试图
--用于配置F10中选择仓库时不选择接口仓库的业务视图
CREATE VIEW [dbo].[WMS_NON_WareHouse_V]
AS
SELECT CodeID, CodeNo, CHName, ENName, Classify, DeptNo,Flag,CheckBox
FROM dbo.BDM_Code a
WHERE (Classify = 'FL16')
    AND NOT EXISTS(SELECT * 
                   FROM WMS_Config b 
                   WHERE a.CodeID=b.Warehouse 
                        OR a.CodeID=b.DclWarehouse 
                        OR a.CodeID=b.whId01
                        OR a.CodeID=b.whId02
                        OR a.CodeID=b.whId03
                        OR a.CodeID=b.whId04
                        OR a.CodeID=b.whId05
                        OR a.CodeID=b.DclId01
                        OR a.CodeID=b.DclId02
                        OR a.CodeID=b.DclId03)
go

