--说明：分部客户销售收款统计
--作者：Devil.H
--创建：2007.11.16
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@DeptNo:部门
--	@CorpNo:公司
--	@AddPay:包含付款单
--	@AddAdv:包含预付款
--	@AddCash:包含现金销售
--	@AddGather:包含交款单
--	@Flag:前台标识
CREATE Function [dbo].[fn_AnalACM25]
(
	@StartDate varchar(10),
	@EndDate varchar(10),
	@CorpNo varchar(20),
	@DeptNo varchar(20),
	@AddPay bit=0,
	@AddAdv bit=0,
	@AddCash bit=0,
	@AddGather bit=0,
	@Flag bit=0
)
Returns @uTable Table(
	BillNo varchar(20),
	BillType varchar(40),
	CreateDate varchar(10),
	DeptNo varchar(20),
	DeptName varchar(100),
	Credence varchar(20),
	PayMode varchar(20),
	PayName varchar(100),
	BankID varchar(20),
	BankName varchar(100),
	CustID bigint,
	CustNo varchar(20),
	CustName varchar(200),
	NameSpell varchar(200),
	CustType varchar(20),
	TypeName varchar(100),
	MemberID varchar(20),
	Member varchar(100),
	AreaCode varchar(20),
	AreaName varchar(100),
	PopedomID varchar(20),
	PopedomName varchar(100),
	TradeName varchar(100),
	KindName varchar(100),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40),
	SalesID bigint,
	Sales varchar(100),
	XJAmt decimal(18,6),
	JKAmt decimal(18,6),
	SKAmt decimal(18,6),
	YSAmt decimal(18,6),
	CXAmt decimal(18,6),
	PayAmt decimal(18,6),
	DepartId varchar(20),
	DepartName varchar(100)
)
As
begin
	If @Flag=0 
		Return
	
	if @AddPay=1	--包含付款单
		Insert Into @uTable(BillNo,BillType,CreateDate,DeptNo,DeptName,CustID,Credence,
			PayMode,PayName,BankID,BankName,SKAmt,CXAmt,PayAmt,CustNo,CustName,NameSpell,
			CustType,TypeName,MemberID,Member,AreaCode,AreaName,PopedomID,PopedomName,
			TradeName,KindName,Phone,LinkMan,Faxes,SalesID,Sales,DepartId,DepartName)
		Select a.PaymentNo,'应收款',a.CreateDate,a.DeptNo,d.CHName As DeptName,a.CustID,
			a.Credence,a.PayMode,p.CHName As PayName,a.BankID,b.CHName As BankName,
			a.Amt As SKAmt,a.AdvAmt,Isnull(a.Amt,0.0)-Isnull(a.AdvAmt,0.0) As PayAmt,
			c.CustNo,c.CustName,c.NameSpell,c.CustType,c.TypeName,c.MemberID,c.Member,
			c.AreaCode,c.AreaName,c.PopedomID,c.PopedomName,c.TradeName,c.KindName,
			c.Phone,c.LinkMan,c.Faxes,a.SalesID,e.EmployeeName,a.DepartId,dt.CHName
		From SMS_Payment a Left Outer Join BDM_PayMode_V p On a.PayMode=p.CodeID
				   Left Outer Join BDM_BankCode_V b On a.BankID=b.CodeID
				   Left Outer Join BDM_DeptCode_V d On a.DeptNo=d.CodeID
				   Left Outer Join BAS_Customer_V c On a.CustID=c.CustID
				   Left Outer Join BDM_DeptCode_V dt On a.DepartId=dt.CodeID
				   Left Outer Join BDM_Employee e ON a.SalesID=e.EmployeeID
		Where (a.BillSts=20) 
			And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
			And (a.DeptNo Like @DeptNo + '%')
			And (d.DeptNo Like @CorpNo + '%')
	If @AddAdv=1--包含预付款单据
		Insert Into @uTable(BillNo,BillType,CreateDate,DeptNo,DeptName,CustID,Credence,
			PayMode,PayName,BankID,BankName,YSAmt,PayAmt,CustNo,CustName,
			CustType,TypeName,MemberID,Member,AreaCode,AreaName,PopedomID,PopedomName,
			TradeName,KindName,Phone,LinkMan,Faxes,SalesID,Sales,DepartId,DepartName)
		Select a.AdvancesNo,'预收款',a.CreateDate,a.DeptNo,d.CHName As DeptName,b.CustID,a.Credence,
			a.PayMode,p.CHName As PayName,a.BankID,k.CHName As BankName,
			b.AdvAmt,b.AdvAmt,c.CustNo,c.CustName,c.CustType,c.TypeName,c.MemberID,c.Member,
			c.AreaCode,c.AreaName,c.PopedomID,c.PopedomName,c.TradeName,c.KindName,
			c.Phone,c.LinkMan,c.Faxes,a.SalesID,e.EmployeeName,a.DepartId,dt.CHName
		From SMS_Advances a Inner join SMS_AdvancesDtl b On a.AdvancesNo=b.AdvancesNo
				    Left Outer Join BDM_PayMode_V p On a.PayMode=p.CodeID
				    Left Outer Join BDM_BankCode_V k On a.BankID=k.CodeID
				    Left Outer Join BDM_DeptCode_V d On a.DeptNo=d.CodeID
				    Left Outer Join BAS_Customer_V c On b.CustID=c.CustID
				    Left Outer Join BDM_DeptCode_V dt On a.DepartId=dt.CodeID
				    Left Outer Join BDM_Employee e ON a.SalesID=e.EmployeeID
		Where (a.BillSts='20') 
			And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
			And (a.DeptNo Like @DeptNo + '%')
			And (d.DeptNo Like @CorpNo + '%')
	Return
End
go

