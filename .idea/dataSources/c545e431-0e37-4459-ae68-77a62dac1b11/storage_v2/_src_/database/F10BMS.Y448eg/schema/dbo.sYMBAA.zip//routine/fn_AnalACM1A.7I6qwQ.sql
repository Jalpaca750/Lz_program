--说明：客户预付款明细
--作者：Devil.H
--创建：2010.07.05
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag：标志
CREATE Function dbo.fn_AnalACM1A
(
	@StartDate char(10)='2000-01-01',
	@EndDate char(10)='2000-01-01',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	BillType varchar(40),
	BillNo varchar(20),
	CreateDate varchar(10),
	Credence varchar(20),
	CustID bigint,
	CustNo varchar(20),
	CustName varchar(200),
	NameSpell varchar(200),
	AreaCode varchar(20),
	AreaName varchar(100),
	MemberID varchar(20),
	Member varchar(100),
	PopedomID varchar(20),
	PopedomName varchar(100),
	CustType varchar(20),
	TypeName varchar(100),
	SalesID bigint,
	Sales varchar(100),
	KindName varchar(100),
	TradeName varchar(100),
	AdvAmt decimal(18,6),
	OffAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40),
	DepartId varchar(20),
	DepartName varchar(100)
)
As
Begin	
	if @Flag=0
		Return
	--初始化变量
	Set @StartDate=Convert(Char(10),Cast(@StartDate as datetime),120)
	Set @EndDate=Convert(Char(10),Cast(@EndDate as datetime),120)
	--临时表
	Insert Into @uTable(BillType,BillNo,CreateDate,Credence,CustID,DepartId,AdvAmt,OffAmt)
	Select '预收款单',a.AdvancesNo,a.CreateDate,a.Credence,b.CustID,a.DepartId,b.AdvAmt,0.0 As OffAmt
	From SMS_Advances a inner join SMS_AdvancesDtl b On a.AdvancesNo=b.AdvancesNo
	Where (a.BillSts='20') 
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Union All
	Select '应收款单',PaymentNo,CreateDate,Credence,CustID,a.DepartId,0.0,AdvAmt
	From SMS_Payment a
	Where (BillSts='20') And Isnull(AdvFlag,0)=1
		And (Convert(char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	--更新客户资料
	Update a Set a.CustNo=b.CustNo,a.CustName=b.CustName,a.NameSpell=b.NameSpell,a.AreaCode=b.AreaCode,
		a.AreaName=b.AreaName,a.MemberID=b.MemberID,a.Member=b.Member,a.PopedomID=b.PopedomID,
		a.PopedomName=b.PopedomName,a.CustType=b.CustType,a.TypeName=b.TypeName,a.KindName=b.KindName,
		a.TradeName=b.TradeName,a.SalesID=b.SalesID,a.Sales=b.Sales,a.LinkMan=b.LinkMan,a.Phone=b.Phone,
		a.Faxes=b.Faxes
	From @uTable a INNER JOIN BAS_Customer_V b ON a.CustID=b.CustID
	Update a Set a.DepartName=d.CHName From @uTable a Inner Join BDM_DeptCode_V d ON a.DepartId=d.CodeID
	Return
End
go

