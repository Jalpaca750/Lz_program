CREATE VIEW [dbo].[IMS_Incept_V]
AS
SELECT a.InceptNo, a.CreateDate, a.DeptNo, b.CHName AS DeptName, a.WareHouse, 
    c.CHName AS WHName, a.PrintNum, t.Amt,a.SyncFlag,a.WmsStock,a.Memo,a.BillSts, 
    (SELECT StsName FROM BillStatus f WHERE a.BillSts=f.BillSts AND f.BillType='IMS30') AS StsName, 
    a.AuditDate, a.AuditID, e.EmployeeName AS Auditer, a.PFlag, a.DeptNo_O, g.CHName AS DeptName_O, 
    a.CreatorID, d.EmployeeName AS Creator, a.PrinterID, p.EmployeeName AS Printer,
    a.RecieverId,e1.EmployeeName AS RecieverName,a.RecieverTime,a.shelvesId,e2.EmployeeName AS shelvesName,
    a.shelvesTime,a.shelvesFlag,a.Remarks, a.CheckBox
FROM dbo.IMS_Incept a
    LEFT JOIN dbo.BDM_DeptCode_V g ON a.DeptNo_O = g.CodeID 
    LEFT JOIN dbo.BDM_Employee e ON a.AuditID = e.EmployeeID 
    LEFT JOIN dbo.BDM_WareHouse_V c ON a.WareHouse = c.CodeID 
    LEFT JOIN dbo.BDM_Employee d ON a.CreatorID = d.EmployeeID 
    LEFT JOIN dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID =p.EmployeeID 
    LEFT JOIN (Select InceptNo,Sum(Amt) As Amt
               From IMS_InceptDtl 
               Group By InceptNo) t On a.InceptNo=t.InceptNo
    LEFT JOIN dbo.BDM_Employee e1 ON a.RecieverId = e1.EmployeeID
    LEFT JOIN dbo.BDM_Employee e2 ON a.shelvesId = e2.EmployeeID
go

