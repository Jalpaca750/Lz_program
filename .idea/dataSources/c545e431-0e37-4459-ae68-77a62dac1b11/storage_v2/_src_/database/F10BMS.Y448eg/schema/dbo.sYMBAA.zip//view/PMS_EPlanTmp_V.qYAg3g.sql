CREATE VIEW dbo.PMS_EPlanTmp_V
AS
SELECT a.PlanNo, b.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, b.ItemSpec, 
      b.BarCode, b.ClassName, b.LabelName, b.ColorName, b.UnitName, b.Cubage, 
       C.Price AS Price, b.PPrice, b.SafePPrice, b.OnHandQty, b.AvailQty, 
b.HotFlag,
      a.PQty, c.VendorID, c.VendorNo, c.VendorName, d.MaxStock, d.MinStock
,b.PkgSpec,b.PkgRatio
,b.Bpackage,b.Mpackage,b.Package

FROM dbo.BDM_ItemInfo_V b INNER JOIN
      dbo.PMS_EPlanTmp a ON b.ItemNo = a.ItemNo left JOIN
      dbo.IMS_Subdepot_V d ON b.ItemID = d.ItemID LEFT OUTER JOIN
      dbo.PMS_Price_V c ON b.ItemID = c.ItemID AND c.DefVendor = 1






go

