CREATE proc sp_BatchMemberPrice(@BatchMemberPrice Varchar(10))
As
Begin

	declare @IsSafeAuditing_Flag as bit
	declare @IsSafeAuditing1 as bit
	declare @IsSafeAuditing2 as bit

	declare @CustID as bigint
	declare @ItemID as bigint
	declare @Price decimal(18,6)
	--系统启用标识
	Select @IsSafeAuditing_Flag=isnull(IsSafeAuditing_Flag,0) From Sys_Config

	declare @ClassID Varchar(4000)
	set @ClassID='('',''1001'',''10010001'')'
	--select * from SPM_Price where 1=1 And MemberID In (select memberid from BDM_Customer where memberid in @ClassID) 
	print @ClassID

End
go

