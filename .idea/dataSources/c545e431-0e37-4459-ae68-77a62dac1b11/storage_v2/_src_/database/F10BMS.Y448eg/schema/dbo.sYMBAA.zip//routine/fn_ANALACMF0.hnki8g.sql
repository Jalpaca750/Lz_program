CREATE Function dbo.fn_ANALACMF0
(
	@ObjectId bigint,
	@StartDate char(10),
	@EndDate char(10),
	@Flag int=0
)
Returns @uTable Table(
	rowIndex bigint identity(1,1),
	feesNo varchar(20),
	createDate varchar(10),
	deptNo varchar(20),
	deptName varchar(100),
	objectType varchar(20),
	objectId bigint,
	objectNo varchar(20),
	objectName varchar(200),
	rpId varchar(40),
	rpName varchar(200),
	accountId varchar(40),
	accountName varchar(200),
	qcAmt decimal(18,6),
	ramt decimal(18,6),
	pamt decimal(18,6),
	qmAmt decimal(18,6),
	rpFlag char(1),
	remarks varchar(2000)
)
As
Begin
	declare @QCAmt decimal(18,6)
	declare @QMAmt decimal(18,6)
	declare @rowIndex bigint
	declare @rpFlag char(1) 
	declare @Seq bigint

	declare @feesTable Table
		(	
			rowIndex bigint identity(1,1),
			feesNo varchar(20),
			createDate varchar(10),
			deptNo varchar(20),
			objectType varchar(20),
			objectId bigint,
			objectNo varchar(20),
			objectName varchar(200),
			rpId varchar(40),
			accountId varchar(40),
			amt decimal(18,6),
			rpFlag char(1),
			remarks varchar(2000)
		)
		
	
	--当前日期前的数据之收款和付款
	--客户数据
	if @Flag=1
		Begin	
			Insert Into @feesTable(feesNo,createDate,deptNo,objectType,objectId,objectNo,objectName,rpId,accountId,amt,rpFlag,remarks)
			Select a.feesNo,a.createDate,a.deptNo,'客户',a.custId,c.custNo,c.CustName,a.rpId,a.raccountId,t.amt,'+',a.remarks
			From ACM_Fees a Inner Join 
				(SELECT feesNo, SUM(feesAmt) AS Amt 
				 FROM ACM_FeesDtl GROUP BY feesNo) t ON a.feesNo = t.feesNo Inner Join 
				BDM_RPType rp ON a.rpId=rp.rpId Inner Join
				BDM_Account ac On a.raccountId=ac.accountId Left Outer Join
				BDM_Customer c ON a.custId=c.CustID
			Where (a.BillSts='20') And (a.createDate<=@EndDate) 
				And (a.custId=@ObjectId)
			
			Insert Into @feesTable(feesNo,createDate,deptNo,objectType,objectId,objectNo,objectName,rpId,accountId,amt,rpFlag,remarks)
			Select a.feesNo,a.createDate,a.deptNo,'客户',a.custId,c.custNo,c.CustName,a.rpId,a.paccountId,-t.amt,'-',a.remarks
			From ACM_Fees a Inner Join 
				(SELECT feesNo, SUM(feesAmt) AS Amt 
				 FROM ACM_FeesDtl GROUP BY feesNo) t ON a.feesNo = t.feesNo Inner Join 
				BDM_RPType rp ON a.rpId=rp.rpId Inner Join
				BDM_Account ac On a.paccountId=ac.accountId Left Outer Join
				BDM_Customer c ON a.custId=c.CustID
			Where (a.BillSts='20') And (a.createDate<=@EndDate) 
				And (a.custId=@ObjectId)
			--起初金额
			Select @QCAmt=Sum(Amt)
			From @feesTable
			Where CreateDate<@StartDate
			Group By objectType,objectId,objectNo,objectName
			
			Insert Into @uTable(feesNo,createDate,deptNo,deptName,objectType,objectId,objectNo,objectName,rpId,accountId,qcAmt,ramt,pamt,qmAmt,rpFlag,remarks)
			Select 'QC-1000000',@StartDate,'','','客户',custId,custNo,custName,'','',Isnull(@QCAmt,0.0),0.0,0.0,Isnull(@QCAmt,0.0),'',''
			From BDM_Customer
			Where custId=@ObjectId
		End 	
	--供应商数据
	if @Flag=2
		Begin	
			Insert Into @feesTable(feesNo,createDate,deptNo,objectType,objectId,objectNo,objectName,rpId,accountId,amt,rpFlag,remarks)
			Select a.feesNo,a.createDate,a.deptNo,'供应商',a.vendorId,v.vendorNo,v.vendorName,a.rpId,a.raccountId,t.amt,'+',a.remarks
			From ACM_Fees a Inner Join 
				(SELECT feesNo, SUM(feesAmt) AS Amt 
				 FROM ACM_FeesDtl GROUP BY feesNo) t ON a.feesNo = t.feesNo Inner Join 
				BDM_RPType rp ON a.rpId=rp.rpId Inner Join
				BDM_Account ac On a.raccountId=ac.accountId Left Outer Join
				BDM_Vendor v ON a.vendorId=v.vendorId
			Where (a.BillSts='20') And (a.createDate<=@EndDate) 
				And (a.vendorId=@ObjectId)
			
			Insert Into @feesTable(feesNo,createDate,deptNo,objectType,objectId,objectNo,objectName,rpId,accountId,amt,rpFlag,remarks)
			Select a.feesNo,a.createDate,a.deptNo,'供应商',a.vendorId,v.vendorNo,v.vendorName,a.rpId,a.paccountId,-t.amt,'-',a.remarks
			From ACM_Fees a Inner Join 
				(SELECT feesNo, SUM(feesAmt) AS Amt 
				 FROM ACM_FeesDtl GROUP BY feesNo) t ON a.feesNo = t.feesNo Inner Join 
				BDM_RPType rp ON a.rpId=rp.rpId Inner Join
				BDM_Account ac On a.paccountId=ac.accountId Left Outer Join
				BDM_Vendor v ON a.vendorId=v.vendorId
			Where (a.BillSts='20') And (a.createDate<=@EndDate) 
				And (a.vendorId=@ObjectId)
			--起初金额
			Select @QCAmt=Sum(Amt)
			From @feesTable
			Where CreateDate<@StartDate
			Group By objectType,objectId,objectNo,objectName
			
			Insert Into @uTable(feesNo,createDate,deptNo,deptName,objectType,objectId,objectNo,objectName,rpId,accountId,qcAmt,ramt,pamt,qmAmt,rpFlag,remarks)
			Select 'QC-1000000',@StartDate,'','','供应商',vendorId,vendorNo,vendorName,'','',Isnull(@QCAmt,0.0),0.0,0.0,Isnull(@QCAmt,0.0),'',''
			From BDM_Vendor
			Where vendorId=@ObjectId
		End 

	Set @Seq=1
	Declare myCursor cursor
	For Select rowIndex,rpFlag From @feesTable where (createDate between @StartDate And @EndDate) Order By CreateDate,feesNo
	Open myCursor
	Fetch Next From myCursor Into @rowIndex,@rpFlag
	While @@Fetch_Status = 0
  	Begin
		Set @Seq=@Seq+1
		--期初欠款=上期期末

		if @rpFlag='+'	
			
			Insert Into @uTable(feesNo,createDate,deptNo,deptName,objectType,objectId,objectNo,objectName,rpId,rpName,
				accountId,accountName,qcAmt,ramt,pamt,qmAmt,rpFlag,remarks)
			select a.feesNo,a.createDate,a.deptNo,d.CHName,a.objectType,a.objectId,a.objectNo,a.objectName,a.rpId,rp.rpName,
				a.accountId,ac.accountName,Isnull(@QCAmt,0.0),a.amt,0.0,Isnull(@QCAmt,0.0)+Isnull(a.amt,0.0),a.rpFlag,a.remarks 
			From @feesTable a Inner Join BDM_DeptCode_V d On a.deptNo=d.CodeId
				Left Outer Join BDM_RPType rp On a.rpId=rp.rpId
				Left Outer Join BDM_Account ac On a.accountId=ac.accountId 
			Where rowIndex=@rowIndex
		Else
			Insert Into @uTable(feesNo,createDate,deptNo,deptName,objectType,objectId,objectNo,objectName,rpId,rpName,
				accountId,accountName,qcAmt,ramt,pamt,qmAmt,rpFlag,remarks)
			select a.feesNo,a.createDate,a.deptNo,d.CHName,a.objectType,a.objectId,a.objectNo,a.objectName,a.rpId,rp.rpName,
				a.accountId,ac.accountName,Isnull(@QCAmt,0.0),0.0,a.amt,Isnull(@QCAmt,0.0)+Isnull(a.amt,0.0),a.rpFlag,a.remarks 
			From @feesTable a Inner Join BDM_DeptCode_V d On a.deptNo=d.CodeId
				Left Outer Join BDM_RPType rp On a.rpId=rp.rpId
				Left Outer Join BDM_Account ac On a.accountId=ac.accountId 
			Where rowIndex=@rowIndex

		--期初欠款=上期期末
		Select @QCAmt=Isnull(@QCAmt,0.0)+Isnull(amt,0.0)
		From @feesTable Where rowIndex=@rowIndex
		Fetch Next From myCursor Into @rowIndex,@rpFlag
	End
   	Close myCursor
   	Deallocate myCursor
	
	return
End
go

