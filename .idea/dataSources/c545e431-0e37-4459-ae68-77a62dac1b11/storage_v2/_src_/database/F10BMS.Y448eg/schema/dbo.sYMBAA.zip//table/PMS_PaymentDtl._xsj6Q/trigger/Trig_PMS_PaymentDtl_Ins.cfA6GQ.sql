--采购付款明细插入操作（Insert)
--2005-01-25
--Devil.H
--当上述操作发生时：
--更新采购发票已付款金额……
CREATE Trigger Trig_PMS_PaymentDtl_Ins
On dbo.PMS_PaymentDtl
For Insert
As
Begin
	declare @InvoiceID bigint
	--更新发票的已付款金额
	Update a Set a.PAmt=Isnull(a.PAmt,0.0)+Isnull(b.PayAmt,0.0)+isnull(b.FAmt,0.0)
	From PMS_Invoice a Inner Join Inserted b ON a.InvoiceID=b.InvoiceID
	--计划单
	declare mycursor cursor
	for select Distinct InvoiceID From Inserted
	open mycursor
	fetch next from mycursor into @InvoiceID
	while @@fetch_Status=0
	begin
		--存在未执行的记录
		if exists(Select 1 from PMS_Invoice Where InvoiceID=@InvoiceID And Isnull(PAmt,0.0)<>0.0 And Isnull(PAmt,0.0)-Isnull(IAmt,0.0)<>0.0)
			Update PMS_Invoice Set BillSts='25' Where InvoiceID=@InvoiceID
		if exists(Select 1 from PMS_Invoice Where InvoiceID=@InvoiceID And Isnull(PAmt,0.0)<>0.0 And Isnull(PAmt,0.0)-Isnull(IAmt,0.0)=0.0)
			Update PMS_Invoice Set BillSts='30' Where InvoiceID=@InvoiceID
		if exists(Select 1 from PMS_Invoice Where InvoiceID=@InvoiceID And Isnull(PAmt,0.0)=0.0)
			Update PMS_Invoice Set BillSts='20' Where InvoiceID=@InvoiceID
		fetch next from mycursor into @InvoiceID
	end
	close mycursor
	deallocate mycursor

End
go

