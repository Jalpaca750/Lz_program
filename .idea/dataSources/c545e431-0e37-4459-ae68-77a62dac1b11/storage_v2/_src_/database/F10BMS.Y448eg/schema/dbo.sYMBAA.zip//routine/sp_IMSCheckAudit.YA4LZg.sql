--盘存清单审核操作（BillSts='20'审核/BillSts='10'取消审核)
--2007-10-22
--Devil.H
--当上述操作发生时：
--审核：库存数量增加，取消审核库存数量减少
CREATE PROC sp_IMSCheckAudit
(
	@CheckNo VARCHAR(20),
	@Flag CHAR(2)
)
AS
BEGIN
    DECLARE @WareHouse VARCHAR(20),@DeptNo VARCHAR(20);
    DECLARE @ErrMsg NVARCHAR(4000),@ErrSeverity INT,@errors BIGINT;
    DECLARE @Tmp TABLE(DeptNo VARCHAR(20),ItemID BIGINT,SPrice DECIMAL(18,6) PRIMARY KEY(DeptNo,ItemID));
    --当前盘存清单编号
    SELECT @WareHouse=WareHouse,@DeptNo=DeptNo 
    FROM IMS_Check 
    WHERE CheckNo=@CheckNo;
    SET @errors=0;
    BEGIN TRANSACTION
    --审核通过
    IF (@Flag='20')
    BEGIN
        --写入盘点清单中没有的商品
        INSERT INTO IMS_CheckStock(stockId,pointId,companyId,warehouseId,regionId,lotNo,locationWay,locationNo,eId,itemId,onhandQty,realQty)
        SELECT REPLACE(NEWID(),'-',''),pointId,'',Warehouse,'','','',Location,'',ItemID,0.0,realQty
        FROM (SELECT a.PointId,a.Warehouse,b.location,b.itemId,SUM(b.SQty) AS realQty
              FROM IMS_Check a
                  INNER JOIN IMS_CheckDtl b ON a.CheckNo=b.CheckNo
              WHERE a.CheckNo=@checkNo
                  AND NOT EXISTS(SELECT * FROM IMS_CheckStock c WHERE a.PointId=c.pointId AND a.WareHouse=c.warehouseId AND b.ItemID=c.itemId)
              GROUP BY a.PointId,a.WareHouse,b.Location,b.ItemID
              ) t


        INSERT INTO @Tmp(DeptNo,ItemID,SPrice)
        SELECT x.DeptNo,y.ItemID,y.SPrice
        FROM IMS_Check x 
            INNER JOIN IMS_CheckDtl y ON x.CheckNo=y.CheckNo
        WHERE x.CheckNo=@CheckNo;
        SET @errors=@errors+@@ERROR;
        --更新库房总账
        UPDATE a SET a.Location=ISNULL(b.Location,a.Location)
        FROM IMS_Ledger a
            INNER JOIN IMS_CheckDtl b ON a.Warehouse=b.Warehouse AND a.ItemId=b.ItemId
        WHERE b.CheckNo=@CheckNo;
        SET @errors=@errors+@@ERROR;
        --插入没有的总账
        INSERT INTO IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,Location)
        SELECT @DeptNo,@WareHouse,ItemID,0,Location
        FROM IMS_CheckDtl a
        WHERE CheckNo=@CheckNo 
            AND NOT EXISTS(SELECT * FROM IMS_Ledger b WHERE a.Warehouse=b.Warehouse AND a.ItemId=b.ItemId);
        SET @errors=@errors+@@ERROR;

        --更新零售价
        UPDATE a SET a.SPrice=CASE ISNULL(b.SPrice,0.0) WHEN 0.0 THEN a.SPrice ELSE b.SPrice END,
            a.LstDate=CONVERT(VARCHAR(10),GETDATE(),120),
            a.SourceDesc='盘点单',BillNo=@CheckNo
        FROM SMS_RetailPrice a     
            INNER JOIN @Tmp b ON a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID;
        SET @errors=@errors+@@ERROR;
        
        INSERT INTO SMS_RetailPrice(DeptNo,ItemID,SPrice,LstDate,SourceDesc,BillNo)
        SELECT DeptNo,ItemID,SPrice,CONVERT(VARCHAR(10),GETDATE(),120),'盘点单',@CheckNo
        FROM @Tmp a 
        WHERE NOT EXISTS(SELECT * FROM SMS_RetailPrice t WHERE a.DeptNo=t.DeptNo AND a.ItemID=t.ItemID)
            AND ISNULL(SPrice,0.0)>0.0;
        SET @errors=@errors+@@ERROR;
    END;
    DELETE FROM @Tmp;
    SET @errors=@errors+@@ERROR;
    IF (@errors=0)
    BEGIN
        COMMIT;
    END; 
    ELSE
    BEGIN
        IF @@TRANCOUNT > 0
            ROLLBACK;
        SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;	
        --写入同步错误日志	
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
        VALUES(LOWER(REPLACE(NEWID(),'-','')),'01',GETDATE(),'99','sp_IMSCheckAudit','IMS_CHECK_AUIDT_ERROR',LEFT(@ErrMsg,2000),@CheckNo,@CheckNo);
        RAISERROR(@ErrMsg, @ErrSeverity, 1);
    END;
END
go

