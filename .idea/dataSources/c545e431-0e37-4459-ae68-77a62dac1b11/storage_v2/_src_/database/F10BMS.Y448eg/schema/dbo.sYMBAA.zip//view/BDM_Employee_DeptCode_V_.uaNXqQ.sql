--员工部门代码试图
CREATE VIEW dbo.BDM_Employee_DeptCode_V
--with encryption
AS
SELECT a.CodeID, a.CodeNo, a.CHName, a.ENName, a.Classify, a.DeptNo, a.CheckBox, 
      b.CorpName, b.CorpLogo, a.DeptFlag, b.CorpPhone, b.CorpFaxes, b.CorpAddr, 
      b.PostalCode
FROM dbo.BDM_Code a LEFT OUTER JOIN
      dbo.SYS_Enterprise b ON a.DeptNo = b.CorpNo
WHERE (a.Classify = 'FL04')


go

