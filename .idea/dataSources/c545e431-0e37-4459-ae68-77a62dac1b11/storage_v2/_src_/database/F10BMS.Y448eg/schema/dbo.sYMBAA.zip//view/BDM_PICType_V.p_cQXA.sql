--盖章类型
CREATE VIEW dbo.BDM_PICType_V
AS
SELECT CodeID, CodeNo, CHName, ENName,Flag, Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL25')
go

