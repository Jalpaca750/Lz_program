Create Proc sp_CreateMigrateSQL
(
	@fromDb varchar(100),
	@tableName varchar(40),
	@OutSQL varchar(4000) Output
)
As
Begin
	declare @colList varchar(2000)
	declare @execSQL varchar(4000)
	Set @colList=''
	select @colList=@colList + ',' + c.name
	From syscolumns c inner join sysobjects o on c.id=o.id
	Where o.name=@tableName And colStat<>1
	Order by c.colId
	Set @colList = substring(@colList,2,len(@colList)-1)
	Set @execSQL = 'Insert Into ' + @tableName + '(' + @colList + ')'
	Set @execSQL = @execSQL+ char(13) + char(10) + 'Select ' + @colList 
	Set @execSQL = @execSQL+ char(13) + char(10) + 'From ' + @fromDb + '.dbo.' + @tableName
	Set @OutSQL = @execSQL 
End
go

