
CREATE view [dbo].[SAM_OrgInvoice_V] as
SELECT a.invoiceId,a.corpId,b.CorpNo,b.CorpName,a.orgId,b.CHName AS orgName,a.salerTaxNum,
    a.salerTel,a.salerAddress,a.salerBank,a.salerAccounts,a.deptId,a.payee,a.checker,a.clerk,
    a.extensionNumber,a.terminalNumber,a.MaxFee
FROM SAM_OrgInvoice a
    INNER JOIN BDM_DeptCode_V b ON a.orgId=b.CodeID
go

