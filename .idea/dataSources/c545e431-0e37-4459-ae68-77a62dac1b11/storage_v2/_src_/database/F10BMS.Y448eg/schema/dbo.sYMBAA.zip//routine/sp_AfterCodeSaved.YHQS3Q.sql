-- =============================================
-- Author:	    <Frank.He>
-- Create date: <2017-07-08>
-- Description:	<基础代码保存后同步到WMS对应的表>
-- Parameter:   
--      @CodeID 基础代码Id
-- =============================================
CREATE PROCEDURE [dbo].[sp_AfterCodeSaved]
(
	@CodeID VARCHAR(20)
)
AS
BEGIN
	--接口变量
	DECLARE @companyId VARCHAR(32),
			@operatorId VARCHAR(32),
			@guid VARCHAR(32),
			@curTime DATETIME
	DECLARE @CodeNo VARCHAR(20),
			@CHName VARCHAR(100),
			@NameSpell VARCHAR(100),			
			@ParentId VARCHAR(32),
			@ParentNo VARCHAR(32),
			@Classify VARCHAR(10),
			@isRecommend INT,
			@viewOrder INT,
			@tmpNo VARCHAR(32),
			@len INT,
            @errors BIGINT;
    SELECT TOP 1 @companyId=companyId,@operatorId=IOperatorId FROM dbo.SYS_Config;
	SET @curTime=GETDATE();
    --如果WMS接口未开启，直接退出
	IF NOT EXISTS(SELECT * FROM dbo.SYS_Config WHERE ISNULL(startWMS,0)=1)
	    RETURN;
    --已同步则退出
	IF EXISTS(SELECT 1 FROM dbo.BDM_Code WHERE CodeID=@CodeID AND syncFlag=1)
		RETURN;
	--编码，名称、分类
	SELECT @CodeNo=CodeNo,@CHName=CHName,@Classify=Classify,@isRecommend=LabelRecomm,@viewOrder=OrderID
	FROM BDM_Code
	WHERE CodeID=@CodeID
	SET @errors=0;
    BEGIN TRANSACTION
	--分类
	IF (@Classify='FL02')
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Category WHERE companyId=@companyId AND categoryNo=@CodeID)	
		BEGIN
			SET @len=4
			WHILE @len<=LEN(@CodeID)
			BEGIN
				SET @tmpNo=LEFT(@CodeID,@len)
				IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Category b WHERE b.companyId=@companyId AND b.categoryNo=@tmpNo)
				BEGIN
					--从F10写入Wms
					SET @guid=LOWER(REPLACE(NEWID(),'-',''));
					INSERT INTo YiWms.dbo.BAS_Category(categoryId,companyId,categoryNo,categoryCName,categoryEName,
						parentId,pictureUrl,usage,isHot,viewOrder,isDisable,isLocked,lockerId,lockedTime,createTime,
						creatorId,editTime,editorId)
					SELECT @guid,@companyId,@tmpNo,CHName,CHName,
						ISNULL((SELECT categoryId FROM YiWms.dbo.BAS_Category WHERE companyId=@companyId AND categoryNo=LEFT(@tmpNo,@len-4)),'0'),
						'',0,0,ISNULL(orderId,0),0,0,'',NULL,@curTime,@operatorId,@curTime,@operatorId
					FROM dbo.BDM_ItemClass_V a 
					WHERE (CodeId=@tmpNo);
                    SET @errors=+@errors+@@Error;
					--写入操作日志
					INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
					SELECT LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCodeSaved',
						'通过接口同步商品分类，分类:[' + @tmpNo + '],分类名称:[' + CHName + ']',@guid,''
					FROM dbo.BDM_ItemClass_V a 
					WHERE (CodeId=@tmpNo); 
                    SET @errors=+@errors+@@Error;
				END
				SET @len=@len+4;
			END
		END
		ELSE
		BEGIN
			SELECT @guid=categoryId 
			FROM YiWms.dbo.BAS_Category 
			WHERE companyId=@companyId AND categoryNo=@CodeID;
			--写入操作日志
			INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCodeSaved',
				'通过接口同步商品分类，分类:[' + @CodeID + '],分类名称:[' + @CHName + ']',@guid,'');		
            SET @errors=+@errors+@@Error;
			--修改分类名称，排序号
			UPDATE YiWms.dbo.BAS_Category SET categoryCName=@CHName,
												   viewOrder=@viewOrder,
												   editTime=@curTime,
												   editorId=@operatorId 
			WHERE categoryId=@guid;
            SET @errors=+@errors+@@Error;
		END
	END

	--部门
	IF (@Classify='FL04')
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Department WHERE companyId=@companyId AND deptNo=@CodeNo)	
		BEGIN
			SET @len=4
			WHILE @len<=LEN(@CodeID)
			BEGIN
				SELECT @tmpNo=CodeNo FROM dbo.BDM_Code WHERE CodeID=LEFT(@CodeID,@len);															
				IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Department WHERE companyId=@companyId AND deptNo=@tmpNo)
				BEGIN
					--从F10写入Wms
					SET @guid=LOWER(REPLACE(NEWID(),'-',''));						
					IF (@len=4)
					BEGIN
						INSERT INTo YiWms.dbo.BAS_Department(deptId,companyId,deptNo,deptName,parentId,isStore,
							viewOrder,isDisable,isLocked,lockerId,lockedTime,createTime,creatorId,editTime,editorId)
						SELECT @guid,@companyId,CodeNo,CHName,'0',1,0,0,0,'',NULL,@curTime,@operatorId,@curTime,@operatorId
						FROM dbo.BDM_DeptCode_V 
						WHERE CodeID=LEFT(@CodeID,@len);
					END
					ELSE
					BEGIN
						SELECT @ParentNo=CodeNo FROM dbo.BDM_Code WHERE CodeID=LEFT(@CodeID,@len-4);							
						INSERT INTo YiWms.dbo.BAS_Department(deptId,companyId,deptNo,deptName,parentId,isStore,
							viewOrder,isDisable,isLocked,lockerId,lockedTime,createTime,creatorId,editTime,editorId)
						SELECT @guid,@companyId,CodeNo,CHName,
							ISNULL((SELECT deptId FROM YiWms.dbo.BAS_Department WHERE companyId=@companyId AND deptNo=@ParentNo),'0'),
							0,0,0,0,'',NULL,@curTime,@operatorId,@curTime,@operatorId
						FROM dbo.BDM_DeptCode_V a 
						WHERE CodeID=LEFT(@CodeID,@len);
					END
                    SET @errors=+@errors+@@Error;
					--写入操作日志
					INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
					SELECT LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCodeSaved',
						'通过接口同步部门资料，部门编码:[' + CodeNo + '],部门名称:[' + CHName + ']',@guid,''
					FROM dbo.BDM_DeptCode_V a 
						WHERE CodeID=LEFT(@CodeID,@len);
                    SET @errors=+@errors+@@Error;
				END
				SET @len=@len+4;
			END			
		END
		ELSE
		BEGIN
			SELECT @guid=deptId 
			FROM YiWms.dbo.BAS_Department 
			WHERE companyId=@companyId AND deptNo=@CodeNo;
			--写入操作日志
			INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCodeSaved',
				'通过接口同步部门资料，部门编码:[' + @CodeNo + '],部门名称:[' + @CHName + ']',@guid,'');		
            SET @errors=+@errors+@@Error;						
			--修改分类名称，排序号
			UPDATE YiWms.dbo.BAS_Department SET deptName=@CHName,
												   editTime=@curTime,
												   editorId=@operatorId 
			WHERE deptId=@guid;		
            SET @errors=+@errors+@@Error;
		END
	END

	--品牌
	IF (@Classify='FL09')
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Brand WHERE companyId=@companyId AND brandNo=@CodeNo)	
		BEGIN
			SET @guid=LOWER(REPLACE(NEWID(),'-',''))
			--新建没有的品牌代码
			INSERT INTO YiWms.dbo.BAS_Brand(brandId,brandNo,brandCName,companyId,isRecommend,viewOrder,usage,
				isLocked,lockerId,lockedTime,createTime,creatorId,editTime,editorId)
			VALUES(@guid,@CodeNo,@CHName,@companyId,@isRecommend,@viewOrder,0,0,'',NULL,@curTime,@operatorId,@curTime,@operatorId);
            SET @errors=+@errors+@@Error;
			--写入操作日志
			INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCodeSaved',
				'通过接口同步商品品牌，品牌:[' + @CodeNo + '],品牌名称:[' + @CHName + ']',@guid,'');		
            SET @errors=+@errors+@@Error;	
		END
		ELSE
		BEGIN
			SELECT @guid=brandId FROM YiWms.dbo.BAS_Brand WHERE companyId=@companyId AND brandNo=@CodeNo;
			--写入操作日志
			INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCodeSaved',
				'通过接口商品品牌，品牌:[' + @CodeNo + '],品牌名称:[' + @CHName + ']',@guid,'');
            SET @errors=+@errors+@@Error;
			--修改已经存在的送货线路
			UPDATE YiWms.dbo.BAS_Brand SET brandCName=@CHName,
													  editTime=@curTime,
													  editorId=@operatorId
			WHERE brandId=@guid;	
            SET @errors=+@errors+@@Error;		
		END
	END
	--结算方式
	IF (@Classify='FL13')	
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Settlement WHERE companyId=@companyId AND settlementNo=@CodeID)	
		BEGIN
			SET @guid=LOWER(REPLACE(NEWID(),'-',''))
			--新建没有的送货线路
			INSERT INTO YiWms.dbo.BAS_Settlement(settlementId,settlementNo,settlementName,companyId,isDisable,isLocked,lockerId,lockedTime,
				createTime,creatorId,editTime,editorId)
			VALUES(@guid,@CodeID,@CHName,@companyId,0,0,'',NULL,@curTime,@operatorId,@curTime,@operatorId);
            SET @errors=+@errors+@@Error;
			--写入操作日志
			INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCodeSaved',
				'通过接口同步结算方式，结算方式:[' + @CodeID + '],结算方式描述:[' + @CHName + ']',@guid,'');
            SET @errors=+@errors+@@Error;
		END	
		ELSE
		BEGIN
			SELECT @guid=settlementId FROM YiWms.dbo.BAS_Settlement WHERE companyId=@companyId AND settlementNo=@CodeID;
			--写入操作日志
			INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCodeSaved',
				'通过接口同步结算方式，结算方式:[' + @CodeID + '],结算方式描述:[' + @CHName + ']',@guid,'');	
            SET @errors=+@errors+@@Error;				
			--修改已经存在的送货线路
			UPDATE YiWms.dbo.BAS_Settlement SET settlementName=@CHName,
													  editTime=@curTime,
													  editorId=@operatorId
			WHERE settlementId=@guid;		
            SET @errors=+@errors+@@Error;	
		END
	END
	--送货线路
	IF (@Classify='FL30')	
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_AddressLine WHERE companyId=@companyId AND lineCode=@CodeID)	
		BEGIN
			SET @guid=LOWER(REPLACE(NEWID(),'-',''))
			--新建没有的送货线路
			INSERT INTO YiWms.dbo.BAS_AddressLine(lineId,lineCode,lineName,companyId,isLocked,lockerId,lockedTime,
				createTime,creatorId,editTime,editorId)
			VALUES(@guid,@CodeID,@CHName,@companyId,0,'',NULL,@curTime,@operatorId,@curTime,@operatorId);
            SET @errors=+@errors+@@Error;
			--写入操作日志
			INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCodeSaved',
				'通过接口同步送货线路，线路:[' + @CodeID + '],线路名称:[' + @CHName + ']',@guid,'');
            SET @errors=+@errors+@@Error;
		END	
		ELSE
		BEGIN
			SELECT @guid=lineId FROM YiWms.dbo.BAS_AddressLine WHERE companyId=@companyId AND lineCode=@CodeID;
			--写入操作日志
			INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCodeSaved',
				'通过接口同步送货线路，线路:[' + @CodeID + '],线路名称:[' + @CHName + ']',@guid,'');	
            SET @errors=+@errors+@@Error;				
			--修改已经存在的送货线路
			UPDATE YiWms.dbo.BAS_AddressLine SET lineName=@CHName,
												 editTime=@curTime,
											     editorId=@operatorId
			WHERE lineId=@guid;		
            SET @errors=+@errors+@@Error;	
		END
	END
	--同步成功后同步标识更新为1
	UPDATE BDM_Code SET syncFlag=1 WHERE CodeID=@CodeID;
    SET @errors=+@errors+@@Error;
    IF @errors=0
    BEGIN
		COMMIT;
	END 
    ELSE
	BEGIN 
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;
		RAISERROR(@ErrMsg, @ErrSeverity, 1)	
		--写入同步错误日志	
		INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterCodeSaved','YI_BASIC_SYNC_ERROR',LEFT(@ErrMsg,2000),@CodeID,@CodeNo);
	END
END



go

