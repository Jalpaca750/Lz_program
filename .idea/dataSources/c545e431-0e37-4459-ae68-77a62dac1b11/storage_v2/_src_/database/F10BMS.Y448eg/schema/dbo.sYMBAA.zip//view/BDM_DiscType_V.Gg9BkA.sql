--折扣类型
CREATE VIEW dbo.BDM_DiscType_V
AS
SELECT CodeID, CodeNo, CHName, ENName,Flag, Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL26')
go

