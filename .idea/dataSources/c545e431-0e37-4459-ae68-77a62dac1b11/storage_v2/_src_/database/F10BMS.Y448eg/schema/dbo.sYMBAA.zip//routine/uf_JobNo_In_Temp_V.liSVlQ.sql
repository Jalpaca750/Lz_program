--说明：批号入库记录
--作者：wujinfeng
--创建：2008.07.18
--参数：
--	@BillType 处理批号类型

CREATE Function uf_JobNo_In_Temp_V
(
	@BillType as varchar(2)
)
Returns @uTable Table
(
	SID 		bigint,
	ItemID 		bigint,
	ItemName	varchar(100),
	WareHouseID 	bigint,
	PHNo 		varchar(50),
	SNNo 		varchar(50),
	QTY 		decimal(18,6),
	--AvailQty  	decimal(18,6),
	BeginDate	varchar(10),
	EndDate		varchar(10),
	YXQ 		decimal(18,6),
	BillType	varchar(2),
	BillNo		varchar(20),
	CreatorID 	bigint,
	BillSts		varchar(2)
)
As
Begin	
	declare @i bigint
	if isnull(@BillType,'')=''
	Return
	
	if @BillType='I1_'
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,BillSts)

	SELECT a.SID, a.ItemID,c.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY, a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID, 
		P.BillSts
		FROM dbo.JobNumberNo_In_Temp a 
		INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		Left JOIN  dbo.PMS_Stock_V P ON  A.BillNo=P.StockNo
	end
	--返回
	return
end



go

