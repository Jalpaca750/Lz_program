CREATE VIEW dbo.SMS_CON_Order_Diff_V
AS
SELECT a.DeptNo, a.ItemID, g.ItemNo, g.ItemName, g.ItemAlias, g.NameSpell, g.ItemSpec, 
      g.BarCode, g.ClassID, g.ClassName, g.LabelID, g.LabelName, g.ColorName, 
      g.UnitName, g.BigBarcode, g.MidBarcode, g.PkgBarcode, a.Qty, a.Price, 
      ROUND(a.Qty * a.Price, 2) AS Amt, ISNULL(b.OQty, 0.0) AS RealQty, ISNULL(b.Price, 
      0.0) AS RealPrice, ISNULL(b.Amt, 0.0) AS RealAmt, ISNULL(a.Qty, 0.0) 
      - ISNULL(b.OQty, 0.0) AS diffQty, ROUND(a.Qty * a.Price, 2) - ISNULL(b.Amt, 0.0) 
      AS diffAmt, c.BillNo, c.CreateDate, c.CustID, d.CustNo, d.CustName, c.SendAddr, 
      c.Phone, c.LinkMan, c.PoNo
FROM dbo.CON_SmsDtl a INNER JOIN
      dbo.BAS_Goods_V g ON a.ItemID = g.ItemID INNER JOIN
      dbo.CON_SMS c ON a.BillNo = c.BillNo INNER JOIN
      dbo.BDM_Customer d ON c.CustID = d.CustID LEFT OUTER JOIN
      dbo.SMS_OrderDtl b ON a.BillID = b.BillID
go

