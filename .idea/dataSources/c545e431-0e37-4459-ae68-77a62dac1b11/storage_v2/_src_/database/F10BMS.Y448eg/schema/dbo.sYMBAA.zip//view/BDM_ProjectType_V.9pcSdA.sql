
CREATE VIEW dbo.BDM_ProjectType_V
AS
SELECT CodeID, CodeNo, CHName, ENName,Flag, Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL31')
go

