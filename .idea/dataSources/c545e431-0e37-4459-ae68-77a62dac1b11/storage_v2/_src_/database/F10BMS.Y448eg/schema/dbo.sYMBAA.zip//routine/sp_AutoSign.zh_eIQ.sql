CREATE PROCEDURE sp_AutoSign
AS
BEGIN
	if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Web_CustAutoSignDate]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
		RETURN
	DECLARE @Tmp Table(StockNo varchar(20),AutoSign Datetime)
	INSERT INTO @Tmp(StockNo,AutoSign)
	SELECT a.StockNo,DateAdd(d,cs.AutoDate,a.AuditDate) As AutoSign
	FROM SMS_Stock a Inner Join Web_CustAutoSignDate cs ON a.CustID=cs.custId
	WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') AND (a.BillType='10')
		AND Isnull(a.SignName,'')=''
	UNION ALL
	SELECT a.StockNo,DateAdd(d,cs.AutoDate,a.SignDate) As AutoSign
	FROM SMS_Stock a Inner Join Web_CustAutoSignDate cs ON a.CustID=cs.custId
	WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') AND (a.BillType='10')
		AND Isnull(a.SignName,'')='延迟签收'
	UPDATE a SET a.SignName='自动签收'
	FROM SMS_Stock a Inner Join @Tmp b ON a.StockNo=b.StockNo
	WHERE DATEDIFF(d ,GETDATE(), b.AutoSign)<0
END
go

