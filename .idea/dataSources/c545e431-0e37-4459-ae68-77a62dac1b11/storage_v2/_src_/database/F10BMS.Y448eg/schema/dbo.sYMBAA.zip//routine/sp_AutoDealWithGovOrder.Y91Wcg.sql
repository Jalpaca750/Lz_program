CREATE PROCEDURE sp_AutoDealWithGovOrder
AS
BEGIN
    DECLARE @PlanNo VARCHAR(20);
    DECLARE @VendorId BIGINT;
    DECLARE @Warehouse VARCHAR(20);
    DECLARE @DeptNo VARCHAR(20);
    DECLARE @DeptFlag VARCHAR(2);
    DECLARE @OrderNo VARCHAR(20);
    DECLARE @StockNo VARCHAR(20);
    DECLARE @XS_OrderNo VARCHAR(20);
    DECLARE @XS_StockNo VARCHAR(20);
    DECLARE @UserID BIGINT;
    DECLARE @CurDate VARCHAR(10);
    DECLARE @errors BIGINT;
    DECLARE @plan TABLE(OrderNo VARCHAR(20),PlanNo VARCHAR(20),VendorId BIGINT,skuCount INT);
    --初始化分部、仓库、用户
    SET @DeptNo='9622';
    SET @Warehouse='9624';
    SET @UserID=99;    
    SET @CurDate=CONVERT(VARCHAR(10),GETDATE(),23);
    SELECT @DeptFlag=DeptFlag FROM BDM_DeptCode_V WHERE CodeID=@DeptNo    
    --需要自动化处理的计划单    
    INSERT INTO @plan(OrderNo,PlanNo,VendorId,skuCount)
    SELECT b.OrderNo,a.PlanNo,a.VendorId,COUNT(*)
    FROM PMS_PlanSel_V a
        INNER JOIN PMS_SalOrder b ON a.PlanNo=b.PlanNo
    WHERE a.DeptNo=@DeptNo 
        AND a.BillSts='20'
    GROUP BY b.OrderNo,a.PlanNo,a.VendorId;
    WHILE(EXISTS(SELECT * FROM @plan))
    BEGIN        
        SELECT TOP 1 @PlanNo=PlanNo,@VendorId=VendorId,@XS_OrderNo=OrderNo FROM @plan ORDER BY PlanNo;
        --循环事务
        SET @errors=0;
        BEGIN TRAN
        --生成采购订单号
        EXEC dbo.sp_CreateCode @DeptFlag,'PMS40',@UserID, @OrderNo OUTPUT;
        IF (@OrderNo!='')
        BEGIN
            --写入采购订单主表
            INSERT INTO PMS_Order(OrderNo,CreateDate,DeptNo_A,DeptNo,VendorID,SendDate,BillType,BillSts,CreatorID,
                Remarks,PFlag,SendID,PrintNum,PrinterID,lineId,auditId,wmsOrder,syncFlag,editTime,OType,logisticsId,
                Warehouse,AdvAmt,HandlerID)
            SELECT @OrderNo,@CurDate,DeptNo,DeptNo,VendorID,@CurDate,'采购订单','20',@UserID,
                Remarks,0,SendId,0,NULL,'',@UserID,'',0,GETDATE(),15,'','',0.00,NULL
            FROM PMS_PlanSel_V
            WHERE PlanNo=@PlanNo;
            SET @errors=@errors+@@ERROR;
            --写入采购订单明细表
            INSERT INTO PMS_OrderDtl(OrderNo,DeptNo,DeptNo_A,PlanID,PlanNo,ItemID,PkgQty,OQty,Price,Amt,IsSpecial,TaxFlag,
                XS_OrderID,XS_OrderNo,XS_CustNo,XS_CustName,IsPromotion,IsEffect)
            SELECT @OrderNo,DeptNo,DeptNo,PlanID,PlanNo,ItemID,PkgQty,PQty,Price,Amt,1,0,XS_OrderID,XS_OrderNo,XS_CustNo,XS_CustName,0,1
            FROM PMS_PlanDtl
            WHERE PlanNo=@PlanNo AND VendorID=@VendorId;
            SET @errors=@errors+@@ERROR;
            --写入采购入库
            EXEC dbo.sp_CreateCode @DeptFlag,'PMS50',@UserID, @StockNo OUTPUT;
            IF (@StockNo!='')
            BEGIN
                INSERT INTO PMS_Stock(StockNo,CreateDate,DeptNo,WareHouse,VendorID,SendNo,BillType,BillSts,AuditDate,AuditID,
                    CreatorID,Remarks,SendID,PrintNum,PrinterID,RecieverId,memo,wmsStock,RecieverTime,TaxRate,postFee,NewPAmt,
                    NewPDate,NewPState,HandlerID)
                SELECT @StockNo,@CurDate,DeptNo,@Warehouse,VendorID,'',10,'20',@CurDate,
                    auditId,CreatorID,Remarks,SendID,0,'','','','',NULL,13,0.0,0.0,NULL,10,NULL
                FROM PMS_Order
                WHERE OrderNo=@OrderNo;
                SET @errors=@errors+@@ERROR;
                --写入采购入库明细
                INSERT INTO PMS_StockDtl(StockNo,WareHouse,Location,OrderID,OrderNo,ItemID,PkgQty,SQty,Price,Amt,IQty,IAmt,RQty,
                    IsEffect,IsSpecial,TaxFlag,PlanID,PlanNo,XS_OrderID,XS_OrderNo,XS_CustNo,XS_CustName,PAmt,PIAmt,IsPromotion,
                    wmsStockId,isTemporary,isEmergency)
                SELECT @StockNo,@Warehouse,'',OrderID,OrderNo,ItemID,PkgQty,OQty,Price,Amt,0.0,0.0,0.0,
                    IsEffect,IsSpecial,TaxFlag,PlanID,PlanNo,XS_OrderID,XS_OrderNo,XS_CustNo,XS_CustName,
                    0.0,0.0,IsPromotion,'',0,0
                FROM PMS_OrderDtl
                WHERE OrderNo=@OrderNo;
                SET @errors=@errors+@@ERROR;  
                EXEC sp_PMSStockAudit @StockNo,'20';
            END
            ELSE
            BEGIN
                SET @errors=2;
            END
            --入库完成后生成销售出库单
            EXEC dbo.sp_CreateCode @DeptFlag,'SMS40',@UserID, @XS_StockNo OUTPUT;
            IF (@XS_StockNo!='')
            BEGIN
                INSERT INTO SMS_Stock(StockNo,CreateDate,DeptNo,WareHouse,CustID,BillType,SendAddr,SendID,SendDate,SendTime,BillSts,
                    BackDate,PaidUp,PFlag,SalesID,AuditDate,AuditID,CreatorID,Remarks,WLFlag,BoxupSts,CarNumberSts,SMSAStockFlag,
                    CostsID,orderreninfo,IsCreditAuditing,PrintNum,PrinterID,SignName,LinkMan,Phone,SourceFlag,LineId,
                    logisticsId,PoNo,boxNum,pickFlag,TaxRate,NeedWebOrder,PaidSts,ServiceID,CreateTime,ServicRate)
                SELECT @XS_StockNo,@CurDate,@DeptNo,@Warehouse,CustID,'10',SendAddr,SendID,SendDate,SendTime,'20',
                    '',0,0,SalesID,@CurDate,@UserID,@UserID,Remarks,'已配货','','',0,
                    CostsID,orderreninfo,0,0,NULL,'',LinkMan,Phone,SourceFlag,lineId,
                    logisticsId,PoNo,1,0,13,0,10,CreatorID,GETDATE(),ServicRate
                FROM SMS_Order
                WHERE OrderNo=@XS_OrderNo;
                SET @errors=@errors+@@ERROR;
                INSERT INTO SMS_StockDtl(StockNo,OrderID,OrderNo,WareHouse,ItemID,Location,PkgQty,SQty,Price,Amt,ZQty,
                    DiscRate,IsSpecial,IsEffect,TaxFlag,IQty,IAmt,RQty,RZQty,PaidAmt,PAmt,CPrice,Remarks,
                    IsPromotion,DiscountTemp,YZStockQty,Integral,IsSafeAuditing,PkgRatio,DiscType,boneOrdNo,
                    wmsStockId)
                SELECT @XS_StockNo,OrderID,OrderNo,@Warehouse,ItemID,'',PkgQty,OQty,Price,Amt,ZQty,
                    DiscRate,IsSpecial,IsEffect,0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,Remarks,
                    IsPromotion,DiscountTemp,0,0,0,0.0,DiscType,'',''
                FROM SMS_OrderDtl
                WHERE OrderNo=@XS_OrderNo;
                SET @errors=@errors+@@ERROR;
                EXEC sp_SMSStockAudit @XS_StockNo,'20';
            END
            ELSE
            BEGIN
                SET @errors=3;
            END
        END
        IF (@errors=0)
            COMMIT;
        ELSE
            ROLLBACK;
        DELETE FROM @plan WHERE PlanNo=@PlanNo;
        DELETE FROM PMS_SalOrder WHERE PlanNo=@PlanNo;
    END
END
go

