CREATE VIEW dbo.IMS_AssemblyDtl_V
AS
SELECT a.AssemblyID, a.AssemblyNo, b.CreateDate, b.BillSts, 
      ISNULL(c.Location, a.Location) AS Location, a.WareHouse_O, a.ItemID, 
      c.OnHandQty, d.ItemNo, d.ItemName, d.ItemAlias, d.NameSpell, d.ItemSpec, 
      d.BarCode, d.ClassID, d.ClassName, d.LabelID, d.LabelName, d.ColorName, 
      d.UnitName, d.BPackage, d.MPackage, d.Package, d.PkgRatio, d.PkgSpec, d.PPrice, 
      d.SPrice, d.SPrice1, d.SPrice2, d.SPrice3, a.PkgQty, a.OQty, a.Price, a.Amt, 
      a.CPrice, d.ItemPHFlag, d.ItemPHName, Y.QTY AS YZStockQty, a.Remarks, a.CheckBox
FROM dbo.BAS_Goods_V d RIGHT OUTER JOIN
      dbo.IMS_AssemblyDtl a ON d.ItemID = a.ItemID LEFT OUTER JOIN
      dbo.IMS_Ledger c ON a.WareHouse_O = c.WareHouse AND a.ItemID = c.ItemID LEFT OUTER JOIN
      dbo.IMS_Assembly b ON a.AssemblyNo = b.AssemblyNo LEFT OUTER JOIN
      dbo.IMS_YZStock_Sum_WareHouse_Sum_V Y ON a.ItemID = Y.ItemID AND  a.WareHouse_O = Y.WareHouseID
go

