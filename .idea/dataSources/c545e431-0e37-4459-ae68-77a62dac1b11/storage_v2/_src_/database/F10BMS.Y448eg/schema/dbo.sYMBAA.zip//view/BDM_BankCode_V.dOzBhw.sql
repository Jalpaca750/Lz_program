--银行代码
CREATE VIEW dbo.BDM_BankCode_V
AS
SELECT CodeID, CodeNo, CHName, ENName, Flag,Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL01')
go

