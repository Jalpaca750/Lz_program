
CREATE FUNCTION [dbo].[fn_miniGetItemImage]
(
    @itemNo VARCHAR(20)
)
RETURNS VARCHAR(400)
AS
BEGIN
    DECLARE @vipUrl VARCHAR(100),@startShop BIT,@result VARCHAR(200),@midUrl VARCHAR(200); 
    --获取F10参数设置
    SELECT @vipUrl=ISNULL(vipUrl,''),@startShop=ISNULL(startShop,0) FROM SYS_Config;
    SET @result='';
    IF (ISNULL(@startShop,0)=1)
    BEGIN
        SELECT @midUrl=ISNULL(img.middleUrl,'')
        FROM Bone.dbo.BAS_Item bi
            INNER JOIN Bone.dbo.BAS_ItemImage img ON bi.itemId=img.itemId AND img.imageType=1
        WHERE bi.itemNo=@itemNo;
        IF (ISNULL(@midUrl,'')!='')
        BEGIN
            IF (CHARINDEX('http',@midUrl)>0)
                SET @result=@midUrl;
            ELSE
                SET @result=@vipUrl+@midUrl;
        END
    END
    RETURN @result;
END
go

