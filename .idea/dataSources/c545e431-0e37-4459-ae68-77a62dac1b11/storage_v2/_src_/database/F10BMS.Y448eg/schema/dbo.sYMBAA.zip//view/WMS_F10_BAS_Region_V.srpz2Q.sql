/*==============================================================*/
/* View: WMS_F10_BAS_Region_V                                   */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_BAS_Region_V] as
SELECT r.regionNo, r.regionDesc,w.warehouse
FROM YiWms.dbo.BAS_Region r
    INNER JOIN WMS_F10_Warehouse_V w ON r.warehouseId=w.warehouseId 
WHERE (r.isCargo = 0)
go

