--说明：分部销售排行榜
--作者：Devil.H
--创建：2010.08.02
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@Flag：标志
CREATE FUNCTION dbo.fn_AnalSMS1H
(
	@StartDate VARCHAR(10)='0000-01-01',
	@EndDate VARCHAR(10)='9999-12-31',
	@ClassID VARCHAR(20),
	@LabelID VARCHAR(20),
	@Flag BIT=0
)
RETURNS @uTable Table(
	DeptNo VARCHAR(20),
	DeptName VARCHAR(100),
	SellQty decimal(18,6),
	SellAmt decimal(18,6),
    RealAmt DECIMAL(18,6),            --实际销售额(去掉返点，平台费)
    RebateAmt DECIMAL(18,6),          --返点
    PlatformFee DECIMAL(18,6),        --平台费
	DepartId VARCHAR(20),
	DepartName VARCHAR(100)
)
AS
BEGIN	
	IF (@Flag=0) 
		RETURN;
    DECLARE @AmtDec INT;
    SELECT @AmtDec=ISNULL(AmtDec,2) FROM SYS_Config;
	--初始化变量
	SET @StartDate=CONVERT(CHAR(10),CAST(@StartDate AS DATETIME),23);
	SET @EndDate=CONVERT(CHAR(10),CAST(@EndDate AS DATETIME),23);

	INSERT INTO @uTable(DeptNo,DeptName,DepartId,DepartName,SellQty,SellAmt,RebateAmt,PlatformFee,RealAmt)
	SELECT d.CodeNo,d.CHName,t.DepartId,dt.CHName,t.SQty,t.Amt,t.RebateAmt,t.PlatformFee,t.Amt-t.RebateAmt-t.PlatformFee
	FROM (SELECT a.DeptNo,a.DepartId,SUM(ISNULL(b.SQty,0.0)) AS SQty,SUM(ISNULL(b.Amt,0.0)) AS Amt,
                SUM(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0) AS RebateAmt,
                SUM(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0) AS PlatformFee   
		  FROM SMS_Stock a 
                INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
                INNER JOIN BDM_Customer c ON a.CustID=c.CustID
		  WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30') 
			    AND (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
			    AND EXISTS(SELECT 1
				           FROM BDM_ItemInfo g
				           WHERE (b.ItemID=g.ItemID) AND (g.ClassID Like @ClassID + '%') AND (g.LabelID Like @LabelID + '%'))
		  GROUP BY a.DeptNo,a.DepartId) t 
        LEFT JOIN BDM_DeptCode_V d ON t.DeptNo=d.CodeID
        LEFT JOIN BDM_DeptCode_V dt ON t.DepartId=dt.CodeID;
	RETURN
END
go

