CREATE VIEW dbo.SMS_AdvancesDtl_V
AS
SELECT a.AdvancesID, a.AdvancesNo, b.CreateDate, b.DeptNo, b.BillSts, a.CustID, 
      c.CustNo, c.CustName, c.NameSpell, c.CustType, c.TypeName, c.MemberID, 
      c.Member, c.AreaCode, c.AreaName, c.PopedomID, c.PopedomName, c.SalesID, 
      c.Sales, c.LinkMan, c.Phone, c.Faxes, 
      ISNULL(c.AdvAmt, 0.0) - ISNULL(a.AdvAmt, 0.0) AS JYAdvAmt, a.AdvAmt, 
      c.AdvAmt AS SYAdvAmt, a.Remarks, a.CheckBox
FROM dbo.BAS_Customer_V c RIGHT OUTER JOIN
      dbo.SMS_AdvancesDtl a ON c.CustID = a.CustID LEFT OUTER JOIN
      dbo.SMS_Advances b ON a.AdvancesNo = b.AdvancesNo
go

