CREATE VIEW dbo.SPM_EPriceTmp_V
AS
SELECT a.OrderNo, b.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, b.ItemSpec, 
      b.BarCode, b.ClassID, b.ClassName, b.LabelID, b.LabelName, b.ColorName, 
      b.UnitName, a.MPrice, b.PPrice,b.SPrice, b.SPrice1, b.SPrice2, b.SPrice3, a.SafeSPrice
FROM dbo.SPM_EPriceTmp a INNER JOIN
      dbo.BDM_ItemInfo_V b ON a.ItemNo = b.ItemNo
go

