--说明：分部销售毛利统计(指定成本法)
--作者：Devil.H
--创建：2010.09.10
--参数：
--	@Period:会计月份额
--	@StartDate:起始日期
--	@ENDDate:截至日期
--	@DeptNo:部门
--	@WareHouse:仓库
--	@CustType：客户类型
--	@AreaCode:地区代码
--	@PopedomID:辖区代码
--	@MemberID:会员级别
--	@CustID:客户ID
--	@ClassID:大类
--	@LabelID:品牌
--	@ItemID:商品ID
--	@Flag:前台标识
CREATE FUNCTION dbo.fn_AnalSMS6H3
(
	@Period CHAR(6),
	@StartDate VARCHAR(10),
	@ENDDate VARCHAR(10),
	@DeptNo VARCHAR(20),
	@WareHouse VARCHAR(20),
	@CustType VARCHAR(20),
	@AreaCode VARCHAR(20),
	@PopedomID VARCHAR(20),
	@MemberID VARCHAR(20),
	@CustID BIGINT,
	@ClassID VARCHAR(10),
	@LabelID VARCHAR(20),
	@ItemID BIGINT,
	@Flag INT=0
)
RETURNS @uTable TABLE(
	DeptID VARCHAR(20),
	DeptNo VARCHAR(20),
	DeptName VARCHAR(100),
	SQty DECIMAL(18,6),
	RebateAmt DECIMAL(18,6),            --返点
    PlatformFee DECIMAL(18,6),          --平台费  
	Amt DECIMAL(18,6),
    RealAmt DECIMAL(18,6),              --实际销售额
	CstAmt DECIMAL(18,6),
	GProAmt DECIMAL(18,6),
	GProfit DECIMAL(18,6),
	JHCstPrice DECIMAL(18,6), 	--参考成本价
	JHCstAmt DECIMAL(18,6), 	--参考成本
	JHGProAmt DECIMAL(18,6),	--参考毛利
	JHGProfit DECIMAL(18,6)		--参考毛利率
)
AS
BEGIN
	IF (@Flag=0) 
		RETURN;
	DECLARE	@Year INT,@Month INT,@AmtDec INT,@STaxFlag BIT;
	--定制成本
	DECLARE @Special Table(OrderID BIGINT,ItemID BIGINT,Price DECIMAL(18,10));
	--临时成本表
	DECLARE @CostTmp Table(DeptNo VARCHAR(20),ItemID BIGINT,Price DECIMAL(18,10) Primary Key(DeptNo,ItemID));
	--销售数据临时表
	DECLARE @Sales Table(RowID BIGINT Identity(1,1),DeptNo VARCHAR(20),ItemID BIGINT,SQty DECIMAL(18,6),Amt DECIMAL(18,6),CPrice DECIMAL(18,6),IsSpecial BIT,TaxFlag BIT,OrderID BIGINT,PlatformFee DECIMAL(10,6),Rebate DECIMAL(10,6),Taxrate DECIMAL(10,6) Primary Key(RowID));
	--初始化变量
	SELECT @AmtDec=ISNULL(AmtDec,2),@STaxFlag=ISNULL(STaxFlag,0) FROM Sys_Config;
	SET @AmtDec=ISNULL(@AmtDec,2);
	SET @Year=CAST(LEFT(@Period,4) AS INT);
	SET @Month=CAST(RIGHT(@Period,2) AS INT);

	--符合条件的销售数据到临时表 
	INSERT INTO @Sales(DeptNo,ItemID,SQty,Amt,IsSpecial,TaxFlag,OrderID,PlatformFee,Rebate,TaxRate)
	SELECT a.DeptNo,b.ItemID,CASE @Flag WHEN 1 THEN b.SQty ELSE ISNULL(b.SQty,0)+ISNULL(b.ZQty,0.0) END,b.Amt,
		ISNULL(b.IsSpecial,0),ISNULL(b.TaxFlag,0),b.OrderID,ISNULL(c.PlatformFee,0.0),ISNULL(c.Rebate,0.0),
        ISNULL(d.Taxrate,16)
	FROM SMS_Stock a 
        INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo 
        INNER JOIN BDM_Customer c ON a.CustID=c.CustID
        INNER JOIN BDM_ItemInfo d ON b.ItemID=d.ItemID
	Where (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30') 
		AND (a.CreateDate BETWEEN @StartDate AND @ENDDate)
		AND (a.DeptNo LIKE @DeptNo + '%')
		AND (b.WareHouse LIKE @WareHouse + '%')
		AND (@CustID=0 OR a.CustID=@CustID)
		AND (@ItemID=0 OR b.ItemID=@ItemID)
		AND (ISNULL(c.CustType,'') LIKE @CustType + '%')
        AND (ISNULL(c.AreaCode,'') LIKE @AreaCode + '%')
        AND (ISNULL(c.PopedomID,'') LIKE @PopedomID + '%')
        AND (ISNULL(c.MemberID,'') LIKE @MemberID + '%')
        AND (ISNULL(d.ClassID,'') LIKE @ClassID + '%')
        AND (ISNULL(d.LabelID,'') LIKE @LabelID + '%');
	IF NOT EXISTS(SELECT * From @Sales)
		RETURN;
    --获取临时成本
	INSERT INTO @CostTmp(DeptNo,ItemID,Price)
	SELECT DeptNo,ItemID,Price
	FROM CST_PlanPrice
	WHERE CstYear=@Year AND CstMonth=@Month;
    --更新成本
    UPDATE a SET a.CPrice=b.Price
    FROM @Sales a 
        INNER JOIN @CostTmp b ON a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID;

	--定制品入库单
    INSERT Into @Special(OrderID,ItemID,Price)
	SELECT y.XS_OrderID,y.ItemID,y.Price 
    FROM PMS_Stock x 
        INNER JOIN PMS_StockDtl y On x.StockNo=y.StockNo
    Where (x.BillSts='20' OR x.BillSts='30' OR x.BillSts='25') 
		AND EXISTS(SELECT * FROM @Sales t Where y.XS_OrderID=t.OrderID);
	--定制品成本	
	UPDATE a SET a.CPrice=b.Price 
	FROM @Sales a 
	    INNER JOIN @Special b ON a.OrderID=b.OrderID;

    --根据成本统计数据(可把1.16替换成实际税率)
	IF ISNULL(@STaxFlag,0)=1
        INSERT INTO @uTable(DeptID,SQty,RebateAmt,PlatformFee,Amt,CstAmt,GProAmt,JHCstAmt,JHGProAmt)
    	SELECT DeptNo,SUM(SQty) AS SQty,ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec) AS RebateAmt,
            ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec) AS PlatformFee,SUM(Amt) AS Amt,
            SUM(CstAmt),SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(CstAmt,0.0)),
    		SUM(JHCstAmt),SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(JHCstAmt,0.0))
    	FROM (
                SELECT a.DeptNo,a.SQty,a.Amt,a.PlatformFee,a.Rebate,
    			    ROUND(ISNULL(a.SQty,0.0)*(CASE a.TaxFlag WHEN 0 THEN ISNULL(a.CPrice,0.0) ELSE ISNULL(a.CPrice,0.0)/1.13 END),@AmtDec) AS CstAmt,
    			    ROUND(ISNULL(a.SQty,0.0)*(CASE a.TaxFlag WHEN 0 THEN ISNULL(jh.Cost,0.0) ELSE ISNULL(jh.Cost,0.0)/1.13 END),@AmtDec) AS JHCstAmt
                FROM @Sales a 
                    LEFT JOIN CST_Colligate_COST_Year jh On jh.Period=@Period And a.ItemID=jh.ItemID
             )t
    	GROUP BY DeptNo;
    ELSE
        INSERT INTO @uTable(DeptID,SQty,RebateAmt,PlatformFee,Amt,CstAmt,GProAmt,JHCstAmt,JHGProAmt)
		SELECT DeptNo,SUM(SQty),ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec) AS RebateAmt,
            ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec) AS PlatformFee,SUM(Amt) AS Amt,
            SUM(CstAmt) AS CstAmt,SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(CstAmt,0.0)) AS GProAmt,
			SUM(JHCstAmt) AS JHCstAmt,SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(JHCstAmt,0.0)) AS JHGProAmt
		FROM (
		        SELECT a.DeptNo,a.SQty,a.Amt,a.PlatformFee,a.Rebate,
				    ROUND(ISNULL(a.SQty,0.0)*ISNULL(a.CPrice,0.0),@AmtDec) AS CstAmt,
				    ROUND(ISNULL(a.SQty,0.0)*ISNULL(jh.Cost,0.0),@AmtDec) AS JHCstAmt
			    FROM @Sales a 
				    LEFT JOIN CST_Colligate_COST_Year jh ON jh.Period=@Period And a.ItemID=jh.ItemID
             )t
		GROUP BY DeptNo;
	--更新部门资料
	UPDATE a SET a.DeptNo=b.CodeNo,a.DeptName=b.CHName,
        RealAmt=ISNULL(Amt,0.0)-ISNULL(RebateAmt,0.0)-ISNULL(PlatformFee,0.0),
		GProfit=CASE ISNULL(a.Amt,0.0) WHEN 0.0 THEN 0.0 
					       ELSE Round(ISNULL(a.GProAmt,0.0)/a.Amt,2*@AmtDec) END,
		a.JHGProfit=CASE ISNULL(a.Amt,0.0) WHEN 0.0 THEN 0.0 
						   ELSE Round(ISNULL(a.JHGProAmt,0.0)/a.Amt,2*@AmtDec) END
	FROM @uTable a 
        INNER JOIN BDM_DeptCode_V b ON a.DeptID=b.CodeID;

	DELETE FROM @Sales;
	DELETE FROM @Special;
	DELETE FROM @CostTmp;
	--返回
	RETURN;
END
go

