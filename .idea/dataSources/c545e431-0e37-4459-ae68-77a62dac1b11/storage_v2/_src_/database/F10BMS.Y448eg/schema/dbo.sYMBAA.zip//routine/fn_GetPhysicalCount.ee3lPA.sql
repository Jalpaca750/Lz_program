-- =============================================
-- Author:		<Author:Frank.He>
-- Create date: <Create Date:2016-12-14>
-- Description:	<Description:盘点批次的盈亏分析表>
-- 2021-04-02日，去掉库位，批次的比较
-- =============================================
CREATE FUNCTION [dbo].[fn_GetPhysicalCount] 
(
	@PointId VARCHAR(32)
)
RETURNS TABLE
RETURN(
      SELECT cs.stockId,cs.companyId,cs.pointId,cp.pointNo,cs.warehouseId,w.CodeNo AS warehouseNo,w.CHName AS warehouseName,
        cs.lotNo,cs.locationNo,sku.itemNo,sku.itemName,sku.NameSpell,sku.itemSpec,sku.barcode,sku.LabelId,sku.LabelNo,
        sku.LabelName,sku.ClassId,sku.ClassNo,sku.ClassName,sku.colorName,sku.unitName,sku.pkgRatio,cs.onhandQty,
        CASE ISNULL(t.pcFlag,0) WHEN 0 THEN CASE cp.inventory WHEN 0 THEN cs.onhandQty WHEN 1 THEN 0.0 END 
                                ELSE t.actQty END AS actQty, 
        CASE ISNULL(t.pcFlag,0) WHEN 0 THEN CASE cp.inventory WHEN 0 THEN 0.0 WHEN 1 THEN -ISNULL(cs.onhandQty,0.0) END 
								ELSE ISNULL(t.actQty,0.0)-ISNULL(cs.onhandQty,0.0) END AS difQty,
        CASE ISNULL(t.pcFlag,0) WHEN 0 THEN '未盘点' ELSE '已盘点' END pcDesc,
        ISNULL(t.pcFlag,0) pcFlag
    FROM dbo.IMS_CheckStock cs
        LEFT JOIN(SELECT a.PointId,a.Warehouse,b.itemId,SUM(b.SQty) AS actQty,1 AS pcFlag
                  FROM dbo.IMS_Check a
                      INNER JOIN dbo.IMS_CheckDtl b ON a.checkNo=b.checkNo
                  WHERE (a.billSts='20' OR a.billSts='30') AND a.pointId=@pointId
                  GROUP BY a.PointId,a.Warehouse,b.itemId
                  ) t ON cs.pointId=t.pointId AND cs.warehouseId=t.warehouse AND cs.itemId=t.itemId
        INNER JOIN dbo.IMS_CheckPoint cp ON cs.pointId=cp.pointId
        INNER JOIN BAS_Goods_V sku ON cs.itemId=sku.itemId
        INNER JOIN BDM_Warehouse_V w ON cs.warehouseId=w.CodeID
    WHERE cs.pointId=@pointId  
)
go

