

/*==============================================================*/
/* View: WMS_F10_User_V                                         */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_User_V] as
SELECT x.employeeID,y.userId
FROM dbo.BDM_Employee x 
	INNER JOIN YiWms.dbo.SAM_User y ON x.EmployeeNo=y.userNo
WHERE EXISTS(SELECT * FROM SYS_Config z WHERE y.companyId=z.companyId) 
go

