--增加、修改、删除的触发器
CREATE TRIGGER TRIGGER_PRJ_Cost ON dbo.PRJ_Cost
FOR INSERT, UPDATE, DELETE 
AS
Begin
	Declare @InvoiceNo varchar(20)
	Declare @Invoice varchar(200)
	Declare @Amt decimal(18,6)
	--修改或者新增
	if exists(select * from inserted)
		--修改
		if exists(select * from deleted)
			Begin
				Select @Amt=Amt,@InvoiceNo='#'+Cast(BillNo as varchar(20)),@Invoice='##'+Cast(InvoiceNo as varchar(20)) from inserted
				if @Amt>0
					begin
						if Not exists(select 1 From SMS_Invoice a Where a.InvoiceNo=@InvoiceNo) 
							Insert Into SMS_Invoice(InvoiceNo,Invoice,DeptNo,CreateDate,CustID,IAmt,BillSts,Remarks,SalesID,CreatorID)
							Select @InvoiceNo,@Invoice,a.DeptNo,a.KPDate,a.CustID,a.Amt,'20',a.Remarks,b.SalesID,a.CreatorID
							From Inserted a Inner Join BDM_Customer b On a.CustID=b.CustID
						else
							update SMS_Invoice set IAmt=@Amt,Invoice=@Invoice where InvoiceNo=@InvoiceNo
					end
				else
					Delete From SMS_Invoice Where InvoiceNo=@InvoiceNo
			End
		else
			Begin
				--新增的处理
				Select @InvoiceNo='#'+Cast(BillNo as varchar(20)),@Invoice='##'+Cast(InvoiceNo as varchar(20)) from inserted
				Delete From SMS_Invoice Where InvoiceNo=@InvoiceNo
				Insert Into SMS_Invoice(InvoiceNo,Invoice,DeptNo,CreateDate,CustID,IAmt,BillSts,Remarks,SalesID,CreatorID)
				Select @InvoiceNo,@Invoice,a.DeptNo,a.KPDate,a.CustID,a.Amt,'20',a.Remarks,b.SalesID,a.CreatorID
				From Inserted a Inner Join BDM_Customer b On a.CustID=b.CustID
			End
	ElSE 
		Begin
			Select @InvoiceNo='#'+Cast(BillNo as varchar(20)) from deleted
			Delete From SMS_Invoice Where InvoiceNo=@InvoiceNo
		End 
End
go

