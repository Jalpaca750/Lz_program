

--说明：参与成本核算的单据的数量，金额统计
--作者：Devil.H
--创建：2009.08.20
--参数：
--		@@STaxFlag:采购不开票加税率计成本
--		@CW_Month_BDate:统计起始日期
--		@CW_Month_EDate:统计截止日期
CREATE function dbo.uf_Cost
(
	@STaxFlag char(6),
	@CW_Month_BDate varchar(10),
	@CW_Month_EDate varchar(10)
)
Returns table 
as 
return
	Select DeptNo,ItemID,Sum(CGRKQty) as CGRKQty,Sum(CGRKAmt) as CGRKAmt,
			Sum(DBRKQty) as DBRKQty,Sum(DBRKAmt) as DBRKAmt,
			Sum(ZPRKQty) as ZPRKQty,Sum(ZPRKAmt) as ZPRKAmt,
			Sum(ZZRKQty) as ZZRKQty,Sum(ZZRKAmt) as ZZRKAmt,
			Sum(CXRKQty) as CXRKQty,Sum(CXRKAmt) as CXRKAmt,
			Sum(QTRKQty) as QTRKQty,Sum(QTRKAmt) as QTRKAmt,
			Sum(CKTZAmt) as CKTZAmt
	From (	--采购入库
			Select a.DeptNo,b.ItemID,Sum(b.SQty) as CGRKQty,
					Sum(Case When Isnull(@STaxFlag,0)=1 And Isnull(b.TaxFlag,0)=1 then Isnull(b.Amt,0)*1.17 else b.Amt End) as CGRKAmt,
					0 as DBRKQty,0 as DBRKAmt,0 as ZPRKQty,0 as ZPRKAmt,0 as ZZRKQty,0 as ZZRKAmt,0 as CXRKQty,0 as CXRKAmt,0 as QTRKQty,
					0 as QTRKAmt,0 as CKTZAmt
			From PMS_Stock a Inner join PMS_StockDtl b On a.StockNo=b.StockNo
			Where a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
				And Isnull(b.IsSpecial,0)=0
			Group by a.DeptNo,b.ItemID
			Union All
			--调拨入库单
			Select a.DeptNo,b.ItemID,0,0,Sum(b.IQty) as DBRKQty,Sum(b.Amt) as DBRKAmt,0,0,0,0,0,0,0,0,0
			From IMS_Incept a inner join IMS_InceptDtl b on a.InceptNo=b.InceptNo
			Where (a.BillSts Not In('00','10')) And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
			Group By a.DeptNo,b.ItemID
			Union All
			--赠品入库单
			Select a.DeptNo,b.ItemID,0,0,0,0, Sum(b.SQty) as ZPRKQty, Sum(b.Amt) as ZPRKAmt,0,0,0,0,0,0,0
			From IMS_Present a Inner join IMS_PresentDtl b On a.PresentNo=b.PresentNo
			Where a.BillType='10' And (a.BillSts Not In('00','10'))
				And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
			Group by a.DeptNo,b.ItemID
			Union All
			--组装入库单
			Select DeptNo,ItemID,0,0,0,0,0,0,Sum(IQty) as ZZRKQty,Sum(Amt) as ZZRKAmt,0,0,0,0,0
			From IMS_Assembly
			Where (BillSts Not In('00','10')) And CreateDate Between @CW_Month_BDate And @CW_Month_EDate
			Group by DeptNo,ItemID
			Union All
			--拆卸入库单
			Select a.DeptNo,b.ItemID,0,0,0,0,0,0,0,0,Sum(b.IQty) as CXRKQty,Sum(b.Amt) as CXRKAmt,0,0,0 
			From IMS_Split a Inner join IMS_SplitDtl b On a.SplitNo=b.SplitNo
			Where (a.BillSts Not In('00','10')) And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
			Group by a.DeptNo,b.ItemID
			--其他入库单
			Union All
			Select a.DeptNo,b.ItemID,0,0,0,0,0,0,0,0,0,0,Sum(b.SQty) as QTRKQty,Sum(b.Amt) as QTRKAmt,0 
			From IMS_Other a Inner join IMS_OtherDtl b On a.OtherNo=b.OtherNo
			Where a.BillType='10' And (a.BillSts Not In('00','10'))
				And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
			Group by a.DeptNo,b.ItemID
			Union All
			Select a.DeptNo,b.ItemID,0,0,0,0,0,0,0,0,0,0,Sum(b.SQty) as QTRKQty,Sum(b.Amt) as QTRKAmt,0
			From IMS_Other a Inner join IMS_OtherDtl b On a.OtherNo=b.OtherNo
			Where a.BillType='60' And (a.BillSts Not In('00','10'))
				And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
			Group by a.DeptNo,b.ItemID
			Union All
			--库存调整损益
			Select a.DeptNo,b.ItemID,0,0,0,0,0,0,0,0,0,0,0,0,Sum(Amt) as CKTZAmt
			From IMS_Rectify a inner join IMS_RectifyDtl b on a.RectifyNo=b.RectifyNo
			Where (a.BillSts='20') And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
			Group By a.DeptNo,b.ItemID) x
	Group By DeptNo,ItemID
go

