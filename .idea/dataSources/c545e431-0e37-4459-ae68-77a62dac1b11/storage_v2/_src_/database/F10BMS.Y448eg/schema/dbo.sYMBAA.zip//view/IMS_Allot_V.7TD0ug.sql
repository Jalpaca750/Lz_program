
CREATE VIEW [dbo].[IMS_Allot_V]
AS
SELECT a.AllotNo, a.CreateDate, a.DeptNo, b.CodeNo AS DeptCode,b.CHName AS DeptName,  
    a.WareHouse, c.CHName AS WHName, a.DeptNo_I,d.CodeNo AS DeptCode_I, d.CHName AS DeptName_I, a.BillSts, 
    (SELECT StsName FROM BillStatus g WHERE a.BillSts=g.BillSts AND g.BillType='IMS20') AS StsName, 
    dtl.ZQty,dtl.ZAmt,a.SendDate,a.SendTime,a.logisticsId,lg.logisticsName,a.wmsOrder,a.WmsBillNo,a.wmsStock,
    a.memo,a.PostFee,a.syncFlag,a.EditTime,a.AuditDate, a.AuditID,f.EmployeeName AS Auditer, a.PFlag, a.CreatorID, 
    e.EmployeeName AS Creator,a.CarNumberSts,a.CarNumberDate,a.LineID,l.CHName AS LineName,a.PrintNum,
    a.PrinterID,p.EmployeeName AS Printer, a.PartQty, a.PH_OperatorID,ph.EmployeeName As PHOperator,
    a.PH_DateTime,a.WLFlag,a.Remarks, a.BoxupSts,a.BoxNum,a.WaveNo,a.pickFlag, a.checkerId,a.checkTime,
    ch.EmployeeName AS checkerName, a.CheckBox
FROM dbo.IMS_Allot a 
    LEFT JOIN dbo.BDM_WareHouse_V c ON a.WareHouse=c.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V d ON d.CodeID = a.DeptNo_I 
    LEFT JOIN dbo.BDM_Employee e ON e.EmployeeID = a.CreatorID 
    LEFT JOIN dbo.BDM_Employee f ON a.AuditID = f.EmployeeID 
    LEFT JOIN dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID=p.EmployeeID 
    LEFT JOIN dbo.BDM_Employee ph ON a.PH_OperatorID=ph.EmployeeID 
    LEFT JOIN dbo.BDM_DeliveryLine_V l ON a.LineID=l.CodeID 
    LEFT JOIN (Select AllotNo,Sum(SQty) as ZQty,Sum(Amt) as ZAmt
	           From dbo.IMS_AllotDtl 
	           Group By AllotNo) dtl On a.AllotNo=dtl.AllotNo
    LEFT JOIN dbo.BAS_Logistics lg ON a.logisticsId=lg.logisticsId
    LEFT JOIN dbo.BDM_Employee ch ON a.checkerId=ch.EmployeeID  
go

