--说明：采购贡献分析
--作者：Devil.H
--创建：2007.11.26
--参数：
--	@FXMonth:分析月份
--	@DBMonth:对比月份
--	@CorpNo:公司数据
--	@DeptNo:部门数据
--	@Flag:标识
CREATE Function dbo.fn_AnalPMSAA
(
	@DBMonth varchar(6)='200001',
	@FXMonth varchar(6)='200001',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	DeptNo varchar(20),
	DeptName varchar(100),
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemAlias varchar(200),
	NameSpell varchar(200),
	ItemSpec varchar(100),
	BarCode varchar(30),
	ClassID varchar(20),
	ClassName varchar(100),
	LabelID Varchar(20),
	LabelName varchar(100),
	ColorName varchar(40),
	UnitName varchar(20),
	DBPrice decimal(18,6),
	FXPrice decimal(18,6),
	CYPrice decimal(18,6),
	CYRate decimal(18,6),
	SQty decimal(18,6),
	CYAmt decimal(18,6)
)
As
Begin
	declare @Method varchar(1)
	if @Flag=0
		Return
	declare @FXNF int
	declare @FXYF int
	set @FXNF=Cast(Left(@FXMonth,4) as bigint)
	Set @FXYF=Cast(Right(@FXMonth,2) as bigint)
	Select @Method=Isnull(Method,'T') From Sys_Config
	declare @Tmp table(ItemID bigint,
			   DeptNo varchar(20),
			   SQty decimal(18,6),
			   DBPrice decimal(18,6),
			   FXPrice decimal(18,6)
			   Primary Key(ItemID,DeptNo) 
                          )
	declare @Tmp1 Table(ItemID bigint,
			    DeptNo varchar(20),
			    Price decimal(18,6)
			    Primary Key(ItemID,DeptNo) 
			   )
	declare @Tmp2 Table(ItemID bigint,
			    DeptNo varchar(20),
			    Price decimal(18,6)
			    Primary Key(ItemID,DeptNo) 
			   )
	--********增加会计月份时间处理***********************
	declare @CW_Month_BDate char(10)
	declare @CW_Month_EDate char(10)

	Set @CW_Month_BDate=(select CW_Month from dbo.uf_Get_CW_Month(1,@FXNF,@FXYF))
	Set @CW_Month_EDate=(select CW_Month from dbo.uf_Get_CW_Month(2,@FXNF,@FXYF))
	--**********************************************
	--没有过滤条件
	if isnull(@CorpNo,'')='' And isnull(@DeptNo,'')=''
		Insert Into @Tmp(DeptNo,ItemID,SQty)
		Select a.DeptNo,b.ItemID,Sum(SQty)
		From SMS_Stock a inner join SMS_StockDtl b on a.StockNo=b.StockNo
		Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
			And (a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate)
		Group By a.DeptNo,b.ItemID
	--按部门过滤
	if isnull(@CorpNo,'')='' And (Not isnull(@DeptNo,'')='')
		Insert Into @Tmp(DeptNo,ItemID,SQty)
		Select a.DeptNo,b.ItemID,Sum(SQty)
		From SMS_Stock a inner join SMS_StockDtl b on a.StockNo=b.StockNo
		Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
			And (a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate)
			And a.DeptNo=@DeptNo
		Group By a.DeptNo,b.ItemID
	--按公司过滤
	if (Not isnull(@CorpNo,'')='') And isnull(@DeptNo,'')=''
		Insert Into @Tmp(DeptNo,ItemID,SQty)
		Select a.DeptNo,b.ItemID,Sum(SQty)
		From SMS_Stock a inner join SMS_StockDtl b on a.StockNo=b.StockNo
		Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
			And (a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate)
			And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And d.DeptNo=@CorpNo)
		Group By a.DeptNo,b.ItemID
	--按公司部门过滤
	if (Not isnull(@CorpNo,'')='') And (Not isnull(@DeptNo,'')='')
		Insert Into @Tmp(DeptNo,ItemID,SQty)
		Select a.DeptNo,b.ItemID,Sum(SQty)
		From SMS_Stock a inner join SMS_StockDtl b on a.StockNo=b.StockNo
		Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
			And (a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate)
			And a.DeptNo=@DeptNo
			And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And d.DeptNo=@CorpNo)
		Group By a.DeptNo,b.ItemID
	--成本核算方式
	if Isnull(@Method,'T')='T'
		Begin
			Insert Into @Tmp1(DeptNo,ItemID,Price)
			Select '$$$$',ItemID,MEPrice
			From uf_CostPrice(@DBMonth)
			Insert Into @Tmp2(DeptNo,ItemID,Price)
			Select '$$$$',ItemID,MEPrice
			From uf_CostPrice(@FXMonth)
			Insert Into @uTable(DeptNo,DeptName,ItemID,SQty,DBPrice,FXPrice)
			Select '$$$$','总体统计',a.ItemID,a.SQty,b.Price,c.Price
			From (Select ItemID,Sum(SQty) AS SQty 
				From @Tmp
				Group By ItemID) a Inner Join @Tmp1 b On a.ItemID=b.ItemID
						   Inner Join @Tmp2 c On a.ItemID=c.ItemID
		End 
	if Isnull(@Method,'T')='S'
		Begin
			Insert Into @Tmp1(DeptNo,ItemID,Price)
			Select DeptNo,ItemID,MEPrice
			From uf_CostPrice(@DBMonth)
			Insert Into @Tmp2(DeptNo,ItemID,Price)
			Select DeptNo,ItemID,MEPrice
			From uf_CostPrice(@FXMonth)
			Insert Into @uTable(DeptNo,DeptName,ItemID,SQty,DBPrice,FXPrice)
			Select a.DeptNo,d.CHName,a.ItemID,a.SQty,b.Price,c.Price
			From @Tmp a Inner Join @Tmp1 b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
				    Inner Join @Tmp2 c On a.DeptNo=b.DeptNo And a.ItemID=c.ItemID
				    LEFT OUTER JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
		End 
	--更新商品资料
	Update a Set a.ItemNo=b.ItemNo,a.ItemName=b.ItemName,a.ItemSpec=b.ItemSpec,
		a.NameSpell=b.NameSpell,a.ItemAlias=b.ItemAlias,a.BarCode=b.BarCode,
		a.ClassID=b.ClassID,a.LabelID=b.LabelID,a.UnitName=b.UnitName,
		a.ClassName=b.ClassName,a.LabelName=b.LabelName,a.ColorName=b.ColorName,
		a.CYPrice=Case When (Isnull(a.FXPrice,0.0)=0.0 Or Isnull(a.DBPrice,0.0)=0.0) Then 0.0
			       Else Isnull(a.FXPrice,0.0)-Isnull(a.DBPrice,0.0) End
	From @uTable a inner join BDM_ItemInfo_V b on a.ItemID=b.ItemID 
	--更新率
	Update @uTable Set CYRate=Case Isnull(DBPrice,0.0) when 0.0 then 0.0 
					else Round(Isnull(CYPrice,0.0)/Isnull(DBPrice,0.0),6) End,
		CYAmt=Isnull(SQty,0.0)*Isnull(CYPrice,0.0)
	--返回
	Return
End
go

