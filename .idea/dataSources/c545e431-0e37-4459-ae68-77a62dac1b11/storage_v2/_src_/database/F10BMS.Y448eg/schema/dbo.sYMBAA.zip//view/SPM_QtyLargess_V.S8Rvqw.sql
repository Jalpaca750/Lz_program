--按数量设置赠品
CREATE View SPM_QtyLargess_V
--with encryption
as
SELECT a.LargessNo, a.StartDate, a.EndDate,a.MemberID, 
      case isnull(c.CHName,'') when '' then '所有客户' else c.CHName end as Member,
      a.AreaCode,case isnull(d.CHName,'') when '' then '所有地区' else d.CHName end  AS AreaName, 
      a.ItemID,b.ItemNo, b.ItemName,a.CreatorID, e.EmployeeName as Creator
FROM dbo.SPM_QtyLargess a LEFT OUTER JOIN
      dbo.BDM_ItemInfo b ON a.ItemID = b.ItemID LEFT OUTER JOIN
      dbo.BDM_MemberCode_V c ON a.MemberID = c.CodeID LEFT OUTER JOIN
      dbo.BDM_AreaCode_V d ON a.AreaCode = d.CodeID LEFT OUTER JOIN
      dbo.BDM_Employee e ON a.CreatorID = e.EmployeeID

go

