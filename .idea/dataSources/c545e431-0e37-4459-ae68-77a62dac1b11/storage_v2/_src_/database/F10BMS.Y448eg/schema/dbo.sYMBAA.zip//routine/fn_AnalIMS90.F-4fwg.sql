--说明：当月盘点盈亏分析
--作者：Devil.H
--创建：2007.11.24
--参数：
--	@Period:分析年月
--	@DeptNo:分部
--	@WareHouse：库房
--	@ClassID：分类
--	@LabelID：品牌
--	@ItemID：商品
--	@Flag：为前台设计
CREATE Function dbo.fn_AnalIMS90
(
	@Period varchar(6),
	@DeptNo varchar(20),
	@WareHouse varchar(20),
	@ClassID varchar(20),
	@LabelID varchar(20),
	@ItemID bigint=0,
	@Flag bit
)
returns @uTable Table(
	DeptNo varchar(20),
	DeptName varchar(100),
	WareHouse varchar(40),
	WHName varchar(100),
	SQty decimal(18,6),
	Amt decimal(18,6),
	SAmt decimal(18,6)
)
As
Begin
	declare @StartDate varchar(10)
	declare @EndDate varchar(10)
	if @Flag=0 
		Return
	Select @StartDate=StartDate,@EndDate=EndDate 
	From SYS_CW_MonthPeriod
	Where CW_Period=@Period
	--临时成本表
	Declare @CostTmp Table(DeptNo varchar(20),ItemID bigint,Price decimal(18,10) Primary Key(DeptNo,ItemID))
	Declare @PhyTmp Table(DeptNo varchar(20),WareHouse varchar(20),ItemID bigint,SQty decimal(18,6),Price decimal(18,10) Primary Key(DeptNo,WareHouse,ItemID))
	--临时成本
	Insert Into @CostTmp(DeptNo,ItemID,Price)
	Select Isnull(DeptNo,'$$$$'),ItemID,MEPrice
	From uf_CostPrice(@Period) 
	--盘点数据
	Insert Into @PhyTmp(DeptNo,WareHouse,ItemID,SQty)
	Select a.DeptNo,a.WareHouse,a.ItemID,SUM(a.SQty)
	From dbo.IMS_Audit a 
	Where (a.DeptNo Like @DeptNo + '%') And (a.WareHouse Like @WareHouse + '%')
		And (a.CreateDate Between @StartDate And @EndDate)
		And isnull(a.Locked,0)=1 And Isnull(a.SQty,0.0)<>0.0
		And (@ItemID=0 Or a.ItemID=@ItemID)
		And Exists(Select 1 From BDM_ItemInfo g 
			   Where a.ItemID=g.ItemID And (g.ClassID Like @ClassID + '%') And (g.LabelID Like @LabelID + '%')) 
	Group By DeptNo,WareHouse,ItemID
	--更新成本价，金额
	if Exists(Select 1 From SYS_Config Where Isnull(Method,'S')='S')
		Insert Into @uTable(DeptNo,DeptName,WareHouse,WHName,SQty,Amt,SAmt)
		Select d.CodeNo,d.CHName,t.WareHouse,w.CHName,SUM(t.SQty),SUM(t.Amt),SUM(t.SAmt)
		From (Select a.DeptNo,a.WareHouse,a.ItemID,a.SQty,
				Isnull(a.SQty,0.0)*Isnull(b.Price,0.0) AS Amt,
				Isnull(a.SQty,0.0)*Isnull(g.SPrice,0.0) AS SAmt
			From @PhyTmp a Left Outer Join @CostTmp b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
				       Left Outer Join BDM_ItemInfo g On a.ItemID=g.ItemID) t 
			Left Outer Join BDM_DeptCode_V d On t.DeptNo=d.CodeID
			Left Outer Join BDM_WareHouse_V w On t.WareHouse=w.CodeID
		Group By d.CodeNo,d.CHName,t.WareHouse,w.CHName
	Else
		Insert Into @uTable(DeptNo,DeptName,WareHouse,WHName,SQty,Amt,SAmt)
		Select d.CodeNo,d.CHName,t.WareHouse,w.CHName,SUM(t.SQty),SUM(t.Amt),SUM(t.SAmt)
		From (Select a.DeptNo,a.WareHouse,a.ItemID,a.SQty,
				Isnull(a.SQty,0.0)*Isnull(b.Price,0.0) AS Amt,
				Isnull(a.SQty,0.0)*Isnull(g.SPrice,0.0) AS SAmt
			From @PhyTmp a Left Outer Join @CostTmp b On b.DeptNo='$$$$' And a.ItemID=b.ItemID
				       Left Outer Join BDM_ItemInfo g On a.ItemID=g.ItemID) t 
			Left Outer Join BDM_DeptCode_V d On t.DeptNo=d.CodeID
			Left Outer Join BDM_WareHouse_V w On t.WareHouse=w.CodeID
		Group By d.CodeNo,d.CHName,t.WareHouse,w.CHName
	Return
End	
go

