
--修改当前试图，联系人，联系电话改为由订单提供
--2021-10-24 增加会员资料(紫迈)、自定义1、自定义2、自定义3

CREATE VIEW [dbo].[SMS_Order_V]
AS
SELECT a.OrderNo, a.CreateDate, a.DeptNo, e.CHName AS DeptName, a.CustID, b.CustNo, 
    b.CustName, b.NameSpell, b.CustType, b.TypeName, b.MemberID, b.Member, 
    b.AreaCode, b.AreaName, a.PopedomID, pc.CHName AS PopedomName, b.Faxes, a.SalesID, j.EmployeeName AS Sales, 
    a.SendDate, a.SendTime, a.SendAddr, a.LinkMan, a.Phone, a.SendID, f.CHName AS SendMode, 
    a.SendFlag, a.SourceFlag, a.DepartId,dt.CHName AS DepartName,a.BillSts, 
    (Select StsName From BillStatus g Where a.BillSts=g.BillSts And g.BillType='SMS30') As StsName, 
    a.CreatorID, c.EmployeeName AS Creator, a.PFlag, b.IsContract, a.IsCheck, 
    a.WebName, a.ContID, a.AuditingFlag,PrintNum,a.PrinterID,p.EmployeeName As Printer, 
    CASE a.AuditingFlag WHEN '0' THEN '否' WHEN '1' THEN '是' END AS ISAuditing, 
    CASE WHEN a.AuditingFlag = '0' THEN '' WHEN a.AuditingStatus = '0' THEN '未通过' WHEN a.AuditingStatus = '1' THEN '通过' ELSE '' END AS BillAuditing_Result, 
    a.PaidState,CASE a.PaidState WHEN 1 THEN '已付款' ELSE '待付款' END AS PStateName,
    a.AuditingPICFlag, a.CostsID, cb.CHName AS CostsName, a.orderreninfo, d.Amt, d.Qty, 
    a.AFlag,(SELECT AFlagDesc FROM BAS_OrderType t WHERE a.aFlag=t.aFlag AND t.OrderFlag='SO') AS AFlagDesc,
    a.AOrderNo,a.WmsFlag,a.WmsOrder,a.lineId,l.CHName AS lineName,a.PoNo,a.SyncFlag,a.logisticsId,lg.logisticsName, 
    a.IsCreditAuditing, a.IsCreditAuditResult, a.IsCreditAuditEmployeeID, a.HandlerID,
    h.EmployeeName As Handler, CA.EmployeeName AS IsCreditAuditEmployee, a.BImport,a.ConNo,a.TotalFee,a.NeedWebOrder,
    a.bonePkgId,a.boneOrdId,a.boneOrdNo,a.editTime,a.AuditId,e1.EmployeeName AS AuditName,a.AuditTime, a.Remarks, 
    CASE ISNULL(a.NeedWebOrder,0) WHEN 0 THEN '否' ELSE '是' END AS NeedWebOrderDesc,a.Platform,a.CardInfo,
    a.OrdField01,a.OrdField02,a.OrdField03,CONVERT(VARCHAR(20),a.CreateTime,120) AS CreateTime,a.ServicRate,
    ROUND(a.ServicRate*d.Amt/100.0,2) AS ServicAmt, a.CheckBox 
FROM dbo.SMS_Order a 
    INNER JOIN(SELECT OrderNo, SUM(Amt) AS Amt, SUM(OQty) AS Qty
               FROM SMS_OrderDtl
               GROUP BY OrderNo) d ON a.OrderNo = d.OrderNo 
    INNER JOIN dbo.BAS_Customer_V b ON a.CustID = b.CustID 
    LEFT JOIN dbo.BDM_Employee j ON a.SalesID = j.EmployeeID 
    LEFT JOIN dbo.BDM_SendMode_V f ON a.SendID = f.CodeID 
    LEFT JOIN dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID 
    LEFT JOIN dbo.BDM_DeptCode_V e ON a.DeptNo = e.CodeID 
    LEFT JOIN dbo.Web_Costs_Class cb ON a.CostsID = cb.CostsID 
    LEFT JOIN dbo.BDM_Employee CA ON a.IsCreditAuditEmployeeID = CA.EmployeeID 
    LEFT JOIN dbo.BDM_Employee p On a.PrinterID=p.EmployeeID 
    LEFT JOIN dbo.BDM_Employee h On a.HandlerID=h.EmployeeID 
    LEFT JOIN dbo.BDM_DeptCode_V dt ON a.departId=dt.CodeId
    LEFT JOIN dbo.BDM_Code l ON a.lineId=l.CodeID
    LEFT JOIN dbo.BDM_PopedomCode_V pc ON a.PopedomID=pc.CodeID
    LEFT JOIN dbo.BDM_Employee e1 ON a.AuditId=e1.EmployeeId
    LEFT JOIN dbo.BAS_Logistics lg ON a.logisticsId=lg.logisticsId
go

