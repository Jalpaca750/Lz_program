--说明：客户跟踪分析
--作者：Devil.H
--创建：2007.11.29
--参数：
--	无
CREATE FUNCTION dbo.uf_AnalDSS401
(
	@Flag bit
)
RETURNS TABLE
AS
RETURN (
	SELECT a.CustId,a.CustNo,a.CustName,a.NameSpell,a.LinkMan,a.Phone,a.Faxes,a.CustAddr,a.CreateDate,
		t.LstDate,t.Amt,a.SalesId,e.EmployeeName As Sales,a.MemberId,a.Custtype,a.AreaCode,a.PopedomId
	FROM BDM_Customer a LEFT OUTER JOIN
		(SELECT a.CustID,Max(a.CreateDate) As LstDate,SUM(b.Amt) As Amt
		 FROM SMS_Stock a INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
		 WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		 GROUP BY a.CustID) t ON a.CustID=t.CustID LEFT OUTER JOIN
		BDM_Employee e ON a.SalesID=e.EmployeeId
	WHERE a.Flag='1'
)
go

