
CREATE Function uf_WebNewPrice
(
@CustID bigint
)
Returns Table
as 
Return(
Select a.PicAmount,a.NTrue,a.AmendDate,a.CreateDate,a.origin,a.defined1,a.defined2,a.defined3,a.Defined4,
		a.ItemID,a.Weight,a.Sale,a.SaleOrder,a.LabelName,a.Cubage,a.Integral,a.OnHandQty,a.PurDays,a.PkgRatio, 
		a.Remarks, a.ItemNo,a.ItemName,a.NameSpell,a.ItemSpec,a.BarCode,a.ItemAlias,a.ClassID,a.ClassName, a.LabelID, 
		a.UnitName,a.PkgSpec,a.HotFlag,SPrice1,a.SPrice,a.SPrice3,a.ColorName, a.IsWeb,a.Flag,a.NOrder,a.HotOrder,
		Isnull(b.Price,a.SPrice) as SPrice2,Sprice2 as YPrice
	From BDM_ItemInfo_V a
	Left Outer Join 
	(SELECT ItemID,Price
	 FROM Web_Promotion_V WHERE (CustID = '' OR CustID IS NULL OR CustID = @CustID)
	) b On a.ItemID=b.ItemID
	WHERE 1=1 

	)

go

