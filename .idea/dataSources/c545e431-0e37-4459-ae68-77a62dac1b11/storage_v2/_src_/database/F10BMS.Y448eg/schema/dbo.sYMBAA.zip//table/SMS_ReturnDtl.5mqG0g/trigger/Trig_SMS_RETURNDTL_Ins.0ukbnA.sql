--销售退货单明细插入操作（Insert)
--2005-01-22
--Devil.H
--当上述操作发生时：
--销售出库单退货数量增加
CREATE Trigger Trig_SMS_RETURNDTL_Ins
On dbo.SMS_ReturnDtl
--加密
--with encryption
For Insert
As
Begin
	Update a Set a.RQty=Isnull(a.RQty,0.0)+Isnull(b.RQty,0.0),
		a.RZQty=isnull(a.RZQty,0.0)+isnull(b.ZQty,0.0)
	From SMS_StockDtl a,Inserted b
	Where a.StockID=b.StockID
End
go

