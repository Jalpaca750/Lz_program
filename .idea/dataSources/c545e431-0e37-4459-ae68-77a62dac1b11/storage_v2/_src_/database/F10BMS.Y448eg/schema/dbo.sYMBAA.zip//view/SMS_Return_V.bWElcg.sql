
CREATE VIEW dbo.SMS_Return_V
AS
SELECT a.ReturnNo, a.CreateDate, a.DeptNo, f.CHName AS DeptName, a.WareHouse, 
    g.CHName AS WHName, a.CustID, b.CustNo, b.CustName, b.NameSpell, b.CustType, 
    b.TypeName, b.MemberID, b.Member, b.AreaCode, b.AreaName, b.PopedomID, 
    b.PopedomName, a.SalesID, h.EmployeeName AS Sales, a.LinkMan, a.Phone, 
    b.Faxes, a.SendAddr, e.Amt,S.PaidAmt,a.CostsID, cb.CHName As CostsName,a.BillSts, 
    (SELECT StsName FROM BillStatus i WHERE a.BillSts=i.BillSts And i.BillType = 'SMS60') AS StsName, 
    a.AuditDate, a.AuditID, c.EmployeeName AS Auditer, a.PFlag, a.CreatorID, d.EmployeeName AS Creator, 
    a.HandlerID,h1.EmployeeName As Handler,a.PrintNum,a.PrinterID,p.EmployeeName AS Printer,
    a.CarNumberSts,a.CarNumberDate,a.BoneRefId,a.BoneRefNo,a.BoneOrdId,a.BoneOrdNo,
    a.SyncFlag,a.EditTime,a.wmsOrder,a.PoNo,a.reasonDesc,CONVERT(VARCHAR(20),a.CreateTime,120) AS CreateTime,a.ServicRate,
    ROUND(a.ServicRate*e.Amt/100.0,2) AS ServicAmt,a.DepartId,dt.CHName AS DepartName,a.Remarks, a.CheckBox
FROM dbo.SMS_Return a 
    LEFT JOIN dbo.BAS_Customer_V b ON a.CustID = b.CustID 
    LEFT JOIN dbo.BDM_WareHouse_V g ON a.WareHouse = g.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V f ON a.DeptNo = f.CodeID 
    LEFT JOIN dbo.Web_Costs_Class cb ON a.CostsID = cb.CostsID 
    LEFT JOIN dbo.BDM_Employee c ON a.AuditID = c.EmployeeID 
    LEFT JOIN dbo.BDM_Employee d ON a.CreatorID = d.EmployeeID 
    LEFT JOIN dbo.BDM_Employee h ON a.SalesID=h.EmployeeID 
    LEFT JOIN (SELECT ReturnNo, SUM(Amt) AS Amt
                FROM SMS_ReturnDtl
                GROUP BY ReturnNo) e ON a.ReturnNo = e.ReturnNo 
    LEFT JOIN dbo.BDM_Employee h1 ON a.HandlerID=h1.EmployeeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID=p.EmployeeID 
    LEFT JOIN dbo.SMS_Stock S ON a.ReturnNo = S.StockNo 
    LEFT JOIN dbo.BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
go

