--说明：超第储备分析
--作者：Devil.H
--创建：2010.07.25
--参数：
--	@LotNo:盘点批次
--	@WareHouse：库房
CREATE Function dbo.fn_AnalIMS502
(
	@DeptNo varchar(20),
	@ClassID varchar(20),
	@LabelID varchar(20)
)
Returns Table
As
Return(
	Select a.DeptNo,d.CHName As DeptName,a.ItemID,b.ItemNo,b.ItemName,b.ItemSpec,b.NameSpell,b.BarCode,
		b.ClassName,b.LabelName,b.ColorName,b.UnitName,b.PkgSpec,b.ItemAlias,
		Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null 
					    Else Round(Isnull(a.OnHandQty,0.0)/Isnull(b.PkgRatio,0.0),4) End as PkgQty,
		a.OnHandQty,a.MinStock,a.MaxStock,Isnull(a.MinStock,0.0)-Isnull(a.OnHandQty,0.0) As UnderQty,
		Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null 
					    Else Round(Isnull(a.MaxStock,0.0)/Isnull(b.PkgRatio,0.0),4) End as MaxPkg,
		Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null 
					    Else Round(Isnull(a.MinStock,0.0)/Isnull(b.PkgRatio,0.0),4) End as MinPkg
	From IMS_Subdepot a Inner Join BAS_Goods_V b On a.ItemID=b.ItemID
			    Left Outer Join BDM_DeptCode_V d On a.DeptNo=d.CodeID
	Where (a.DeptNo Like @DeptNo + '%')
		And (b.ClassID Like @ClassID + '%')
		And (b.LabelID Like @LabelID + '%')
		And (Isnull(a.MinStock,0.0)-Isnull(a.OnHandQty,0.0)>0.0)
)
go

