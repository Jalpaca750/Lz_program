--重新更改库存结转到新帐套的方式
--其他入出库单的“库存初始化”
CREATE Proc [dbo].[sp_CarryInventory]
(
	@FromDB varchar(100),
	@ToDB varchar(100),
	@Period varchar(6)
)
As
Begin
	Declare @DeptNo varchar(20)
	Declare @WareHouse varchar(20)
	Declare @DeptFlag varchar(2)
	Declare @FlowNo varchar(20)
	Declare @OtherNo varchar(20)
	Declare @Prefix varchar(20)
	Declare @execSQL varchar(4000)
	Declare @FirstDay varchar(10)
	--新帐套第一天
	Set @FirstDay = Convert(varchar(10),dateadd(m,1,Left(@Period,4) + '-' + Right(@Period,2) + '-01'),120)

	Truncate Table IMS_Flow
	Truncate Table IMS_Other
	Truncate Table IMS_OtherDtl

	declare mycursors cursor	
	for Select Distinct DeptNo,WareHouse From IMS_Ledger
	open mycursors
	fetch next from mycursors into @DeptNo,@WareHouse
	while @@fetch_Status=0
		begin
			Select @DeptFlag=DeptFlag From BDM_DeptCode_V Where CodeID=@DeptNo
			--编码前缀
			Set @Prefix=@DeptFlag + '-' + 'QT' + Convert(varchar(8),GetDate(),12)
			--获取最大编号
			Select @FlowNo=Max(OtherNo) From IMS_Other Where OtherNo Like @Prefix + '%'
			--其他入出库单号
			if Isnull(@FlowNo,'')=''
				Set @OtherNo=@Prefix + '0001'
			Else
				Set @OtherNo=@DeptFlag + '-' + 'QT' + Cast((Cast(Replace(@FlowNo,@DeptFlag + '-' + 'QT','') AS bigint) + 1) AS varchar(20))
			
			--写入其他入出库单头文件
			Insert Into IMS_Other(OtherNo,CreateDate,DeptNo,WareHouse,BillType,IOObject,BillSts,AuditDate,AuditID,CreatorID,Remarks)
			Values(@OtherNo,@FirstDay, @DeptNo,@WareHouse,'60','40','20',Convert(varchar(10),GetDate(),120),99,99,'帐套结转')
			--写入其他入出库单明细文件
			Insert Into IMS_OtherDtl(OtherNo,WareHouse,Location,ItemID,SQty,Price,Amt)
			Select @OtherNo,WareHouse,Location,ItemID,OnHandQty,0.0,0.0
			From IMS_Ledger
			Where DeptNo=@DeptNo And WareHouse=@WareHouse
			--写入流水账
			Insert Into IMS_Flow(BillNo,DeptNo,WareHouse,CreateDate,BillType,AuditDate,ItemID,SQty)
			Select @OtherNo,DeptNo,WareHouse,@FirstDay,'库存初始化',convert(char(10),getdate(),120),ItemID,OnhandQty
			From IMS_Ledger
			Where DeptNo=@DeptNo And WareHouse=@WareHouse
			fetch next from mycursors into @DeptNo,@WareHouse
		end
	close mycursors
	deallocate mycursors
	
	--更新期末成本和库存金额
	If Exists(Select 1 From SYS_Config Where Isnull(Method,'T')='T')
		Begin
			Set @execSQL='Update a Set a.Price=b.MEPrice,a.Amt=Round(Isnull(a.SQty,0.0)*Isnull(b.MEPrice,0.0),2)'
			Set @execSQL = @execSQL + char(13) + N'From IMS_Flow a Inner Join #FromDB#.dbo.CST_Price b ON ISNULL(b.DeptNo,''$$$$'')=''$$$$'' And a.ItemID=b.ItemID'
			Set @execSQL = @execSQL + char(13) + N'Where b.Period=''' + @Period + ''';'	
		End
	Else
		Begin
			Set @execSQL='Update a Set a.Price=b.MEPrice,a.Amt=Round(Isnull(a.SQty,0.0)*Isnull(b.MEPrice,0.0),2)'
			Set @execSQL = @execSQL + char(13) + N'From IMS_Flow a Inner Join #FromDB#.dbo.CST_Price b ON b.DeptNo=a.DeptNo And a.ItemID=b.ItemID'
			Set @execSQL = @execSQL + char(13) + N'Where b.Period=''' + @Period + ''';'	
		End
	Set @execSQL = @execSQL + char(13) + N'Update a Set a.Price=b.Price,a.Amt=b.Amt'
	Set @execSQL = @execSQL + char(13) + N'From IMS_OtherDtl a Inner Join IMS_Flow b ON a.OtherNo=b.BillNo And a.ItemID=b.ItemID;'
	Set @execSQL=Replace(@execSQL,'#ToDB#',@ToDB)
	Set @execSQL=Replace(@execSQL,'#FromDB#',@FromDB)
	execute(@execSQL)
	--更新货位
	Set @execSQL='Update a Set a.Location=b.Location From #ToDB#.dbo.IMS_Ledger a Inner Join #FromDB#.dbo.IMS_Ledger b On a.WareHouse=b.WareHouse And a.ItemID=b.ItemID;'
	Set @execSQL=Replace(@execSQL,'#ToDB#',@ToDB)
	Set @execSQL=Replace(@execSQL,'#FromDB#',@FromDB)
	execute(@execSQL)
	--更新高低储备
	Set @execSQL = 'Update a Set a.MaxHive=b.MaxHive,a.MinHive=b.MinHive,a.MaxStock=b.MaxStock,a.MinStock=b.MinStock,a.SafetyDays=b.SafetyDays'
	Set @execSQL = @execSQL + char(13) + N'From #ToDB#.dbo.IMS_Subdepot a inner join #FromDB#.dbo.IMS_Subdepot b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID;'
	Set @execSQL=Replace(@execSQL,'#ToDB#',@ToDB)
	Set @execSQL=Replace(@execSQL,'#FromDB#',@FromDB)
	execute(@execSQL)
End
go

