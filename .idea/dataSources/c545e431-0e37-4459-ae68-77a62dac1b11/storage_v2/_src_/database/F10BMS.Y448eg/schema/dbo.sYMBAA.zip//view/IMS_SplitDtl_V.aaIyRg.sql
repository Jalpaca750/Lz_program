CREATE VIEW dbo.IMS_SplitDtl_V
AS
SELECT a.SplitID, a.SplitNo, b.CreateDate, b.BillSts, ISNULL(c.Location, a.Location) 
      AS Location, a.WareHouse_I, a.ItemID, c.OnHandQty, d.ItemNo, d.ItemName, 
      d.ItemAlias, d.NameSpell, d.ItemSpec, d.BarCode, d.ClassID, d.ClassName, 
      d.LabelID, d.LabelName, d.ColorName, d.UnitName, d.BPackage, d.MPackage, 
      d.Package, d.PkgRatio, d.PkgSpec, d.PPrice, d.SPrice, d.SPrice1, d.SPrice2, 
      d.SPrice3, a.PkgQty, a.IQty, a.Price, a.Amt, a.CPrice, a.Remarks, a.CheckBox
	,d.ItemPHFlag, d.ItemPHName
FROM dbo.BAS_Goods_V d RIGHT OUTER JOIN
      dbo.IMS_SplitDtl a ON d.ItemID = a.ItemID LEFT OUTER JOIN
      dbo.IMS_Ledger c ON a.WareHouse_I = c.WareHouse AND a.ItemID = c.ItemID LEFT OUTER JOIN
      dbo.IMS_Split b ON a.SplitNo = b.SplitNo
go

