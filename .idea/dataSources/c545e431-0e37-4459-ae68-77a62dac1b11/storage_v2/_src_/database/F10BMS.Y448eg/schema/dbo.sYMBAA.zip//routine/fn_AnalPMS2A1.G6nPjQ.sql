--说明：商品月度采购分析明细
--作者：Devil.H
--创建：2007.11.22
--参数：
--	@ItemID:商品编号
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:计算标识
CREATE Function dbo.fn_AnalPMS2A1
(
	@ItemID bigint=0,
	@StartDate char(10)='2000-01-01',
	@EndDate char(10)='2000-01-01',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	VendorID bigint,
	VendorNo varchar(20),
	VendorName varchar(200),
	NameSpell varchar(200),
	BuyerID bigint,
	Buyer varchar(100),
	SQty decimal(18,6),
	RQty decimal(18,6),
	TQty decimal(18,6),
	AvgPrice decimal(18,6),
	PurAmt decimal(18,6),	--采购金额
	RetAmt decimal(18,6),	--退货金额
	TotalAmt decimal(18,6),
	PurPercent decimal(18,6),
	RetPercent decimal(18,6),
	R_PScale  decimal(16,6),
	R_PPercent decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40)
)
As
Begin
	declare @SumAmt decimal(18,6)
	declare @SumRAmt decimal(18,6)
	if @Flag=0
		Return
	--初始化变量
	Set @StartDate=Convert(Char(10),Cast(@StartDate as datetime),120)
	Set @EndDate=Convert(Char(10),Cast(@EndDate as datetime),120)
	
	Insert Into @uTable(VendorID,RQty,RetAmt,SQty,PurAmt,TQty,TotalAmt)	
	Select a.VendorID,
		RQty=abs(Sum(Case a.BillType When '20' then b.SQty else 0.0 end)),
		RetAmt=abs(Sum(Case a.BillType when '20' then b.Amt else 0.0 end)),
		SQty=abs(Sum(Case a.BillType When '10' then b.SQty else 0.0 end)),
		PurAmt=isnull(Sum(Case a.BillType when '10' then b.Amt else 0.0 end),0.0)
			+isnull(Sum(Case a.BillType when '30' then b.Amt else 0.0 end),0.0),
		Sum(b.SQty),Sum(b.Amt)
	From PMS_Stock a inner join PMS_StockDtl b On a.StockNo=b.StockNo
	Where b.ItemID=@ItemID And (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.DeptNo Like @DeptNo + '%')
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And Exists(Select 1 From BDM_DeptCode_V d Where (a.DeptNo=d.CodeID) And (d.DeptNo Like @CorpNo + '%'))
	Group By a.VendorID
	--更新供应商信息
	Update a Set a.VendorNo=b.VendorNo,a.VendorName=b.VendorName,a.BuyerID=b.BuyerID,a.Buyer=b.Buyer,
		a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes
	From @uTable a inner join BDM_Vendor_V b on a.VendorID=b.VendorID
	--获取以上供应商的总采购额
	Select @SumAmt=Sum(PurAmt),@SumRAmt=Sum(RetAmt) From @uTable
	--更新各个供应商采购百分比
	Update @uTable Set PurPercent=case Isnull(@SumAmt,0.0) 
				When 0.0 then 0.0
				Else Round(isnull(PurAmt,0.0)/@SumAmt,6) End,
		RetPercent=case Isnull(@SumRAmt,0.0)
				When 0.0 then 0.0
				Else Round(isnull(RetAmt,0.0)/@SumRAmt,6) End,
		R_PPercent=case Isnull(PurAmt,0.0)
				When 0.0 then 0.0
				Else round(Isnull(RetAmt,0.0)/Isnull(PurAmt,0.0),6) End,
		AvgPrice=case isnull(SQty,0.0)-isnull(RQty,0.0)
				when 0.0 then 0.0
				else round((isnull(PurAmt,0.0)-isnull(RetAmt,0.0))/(isnull(SQty,0.0)-isnull(RQty,0.0)),2) End 
	--更新权重
	Update @uTable Set R_PScale=case isnull(PurPercent,0.0)
				When 0.0 then 0.0
				Else Round(isnull(RetPercent,0.0)/Isnull(PurPercent,0.0),6) End
	--返回
	Return
End
go

