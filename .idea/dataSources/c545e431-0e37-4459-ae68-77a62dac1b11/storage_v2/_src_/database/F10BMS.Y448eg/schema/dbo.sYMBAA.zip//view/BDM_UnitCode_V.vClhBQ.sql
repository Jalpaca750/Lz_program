

--计量单位
CREATE VIEW dbo.BDM_UnitCode_V
AS
SELECT CodeID, CodeNo, CHName, ENName,Flag, Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL15')
go

