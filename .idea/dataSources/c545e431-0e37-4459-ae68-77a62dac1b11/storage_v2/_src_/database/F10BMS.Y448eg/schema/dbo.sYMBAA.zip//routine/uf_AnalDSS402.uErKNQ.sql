--说明：客户跟踪分析明细
--作者：Devil.H
--创建：2007.11.29
--参数：
--	无
CREATE FUNCTION dbo.uf_AnalDSS402
(
	@CustID bigint
)
RETURNS TABLE
AS
RETURN (
	Select g.ItemNo,g.ItemName,g.ItemSpec,g.ClassName,g.LabelName,g.ColorName,g.UnitName,
		Sum(b.SQty) as SQty,Sum(b.Amt) as Amt,Max(a.CreateDate) as LstDate
	FROM SMS_Stock a INNER JOIN 
		SMS_StockDtl b On a.StockNo=b.StockNo INNER JOIN
		BDM_ItemInfo_V g ON b.ItemID=g.ItemID
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') AND (a.CustID=@CustID)
	Group By g.ItemNo,g.ItemName,g.ItemSpec,g.ClassName,g.LabelName,g.ColorName,g.UnitName
)
go

