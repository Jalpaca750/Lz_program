

--年产值
CREATE VIEW dbo.BDM_OutValue_V
AS
SELECT CodeID, CodeNo, CHName, ENName, Flag,Classify, CheckBox
FROM dbo.BDM_CODE
WHERE (Classify = 'FL20')
go

