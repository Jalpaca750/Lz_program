

CREATE VIEW dbo.SMS_Stock_V
AS
SELECT a.StockNo, a.CreateDate, a.DeptNo, c.CHName AS DeptName, a.WareHouse, 
    g.CHName AS WHName, a.CustID, b.CustNo, b.CustName, b.NameSpell, b.CustType, 
    b.TypeName, b.MemberID, b.Member, b.AreaCode, b.AreaName, b.PopedomID, 
    b.PopedomName, a.LinkMan, a.Phone, b.Faxes, a.SalesID,j.EmployeeName AS Sales,  
    f.SQty, f.Amt, f.RemIAmt, a.PaidDate, a.PaidUp, a.PaidAmt, a.DiscAmt,a.BillType, a.BillSts,  
    (Select StsName From BillStatus k Where k.BillSts=a.BillSts And k.BillType='SMS40') AS StsName, 
    a.BackDate, a.SendDate, a.SendTime, a.SendAddr, a.SendID, i.CHName AS SendMode, 
    a.CreatorID, d.EmployeeName AS Creator, a.AuditDate, a.AuditID, e.EmployeeName AS Auditer, 
    a.Delivery, h.EmployeeName AS DeliveryMan, a.Integral, a.PFlag, a.Remarks, a.CheckBox,b.Defined1,
    F.SUMDtlIntegral,a.AuditingPICFlag, a.WLFlag, a.PH_OperatorID, PH.EmployeeName AS PH_Operator, 
    a.PH_DateTime,a.BoxupSts, f.SQty As ZQty, f.Amt As ZAmt,SMSAStockFlag, a.CostsID, cb.CHName As CostsName,
    a.orderreninfo,a.CarNumberSts,a.CarNumberDate,a.IsCreditAuditing,a.IsCreditAuditResult,
    a.IsCreditAuditEmployeeID,CA.EmployeeName As IsCreditAuditEmployee,a.PrintNum,a.PrinterID,
    p.EmployeeName AS Printer,a.SignName,a.DispatcherID,ed.EmployeeName As Dispatcher,
    a.HandlerID, hl.EmployeeName As Handler, a.DispatchTime,a.SourceFlag,a.Weight,a.DepartId,
    dt.CHName AS DepartName,a.logisticsId,lg.logisticsName, a.PoNo,a.WmsStock,a.PostFee,a.Memo,
    a.LineId,dl.CHName AS LineName,a.checkerId,e1.EmployeeName AS checkerName,a.checkTime,
    a.boxNum,a.WaveNo,a.PickFlag,a.PlatformFee,a.Rebate,a.TaxRate,a.expressNo,
    ISNULL(f.Amt,0.0)-ISNULL(a.PaidAmt,0.0) AS RemAmt,a.StockNo AS InvoiceNo,
    CONVERT(VARCHAR(20),a.editTime,120) AS editTime,a.NeedWebOrder,
    CASE ISNULL(a.NeedWebOrder,0) WHEN 0 THEN '否' ELSE '是' END AS NeedWebOrderDesc,a.PaidSts,
    CASE ISNULL(a.PaidSts,0) WHEN 10 THEN '待收款' WHEN 15 THEN '部分收款' WHEN 20 THEN '全部收款' END AS PaidStsName,
    a.ServiceID,e2.EmployeeName AS ServiceName,CONVERT(VARCHAR(20),a.CreateTime,120) AS CreateTime,a.ServicRate,
    ROUND(a.ServicRate*f.Amt/100.0,2) AS ServicAmt
FROM dbo.SMS_Stock a 
    LEFT JOIN dbo.BDM_Employee PH ON a.PH_OperatorID = PH.EmployeeID 
    LEFT JOIN dbo.BDM_Employee j ON a.SalesID = j.EmployeeID 
    LEFT JOIN dbo.BDM_SendMode_V i ON a.SendID = i.CodeID 
    LEFT JOIN dbo.BDM_Employee h ON a.Delivery = h.EmployeeID 
    LEFT JOIN dbo.BDM_WareHouse_V g ON a.WareHouse = g.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V c ON a.DeptNo = c.CodeID 
    LEFT JOIN dbo.BAS_Customer_V b ON a.CustID = b.CustID 
    LEFT JOIN dbo.BDM_Employee e ON a.AuditID = e.EmployeeID 
    LEFT JOIN dbo.BDM_Employee d ON a.CreatorID = d.EmployeeID 
    LEFT JOIN (SELECT StockNo, SUM(SQty) AS SQty, SUM(Amt) AS Amt,
                    SUM(Isnull(Amt,0.0)-Isnull(IAmt,0.0)) As RemIAmt,
                    SUM(ISNULL(SQty,0.0)*ISNULL(Integral,0.0)) AS SUMDtlIntegral
                FROM SMS_StockDtl    
                GROUP BY StockNo) f ON a.StockNo = f.StockNo 
    LEFT JOIN dbo.Web_Costs_Class cb ON a.CostsID = cb.CostsID 
    LEFT JOIN dbo.BDM_Employee ca ON a.IsCreditAuditEmployeeID = CA.EmployeeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID 
    LEFT JOIN dbo.BDM_Employee ed On a.DispatcherID=ed.EmployeeID 
    LEFT JOIN dbo.BDM_Employee hl On a.HandlerID=hl.EmployeeID 
    LEFT JOIN dbo.BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
    LEFT JOIN dbo.BAS_Logistics lg ON a.logisticsId=lg.logisticsId
    LEFT JOIN dbo.BDM_DeliveryLine_V dl ON a.LineId=dl.CodeID
    LEFT JOIN dbo.BDM_Employee e1 ON a.checkerId=e1.EmployeeID
    LEFT JOIN dbo.BDM_Employee e2 ON a.ServiceID=e2.EmployeeID
go

