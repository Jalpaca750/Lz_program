
/*==============================================================*/
/* View: SYS_JMConfig_V                                         */
/*==============================================================*/
create view SYS_JMConfig_V as
SELECT a.serverCode,CASE a.serverCode WHEN 'OM' THEN '办公伙伴' 
                                      WHEN 'STB' THEN '史泰博'
                                      WHEN 'COMIX' THEN '齐心'
                                      WHEN 'DELI' THEN '得力'
                                      WHEN 'LX' THEN '领先未来'
                                      WHEN 'TD' THEN '一线达通'
                                      WHEN 'BW' THEN '邦威' END AS serverName,
    a.jmId,a.jmSecret,a.jmSupplier,a.serverType,a.serverUrl,a.exField01,a.exField02,
    a.exField03,a.exField04,a.exField05,a.createTime,a.creatorID,a.editTime,a.editorID
FROM SYS_JMConfig a
go

