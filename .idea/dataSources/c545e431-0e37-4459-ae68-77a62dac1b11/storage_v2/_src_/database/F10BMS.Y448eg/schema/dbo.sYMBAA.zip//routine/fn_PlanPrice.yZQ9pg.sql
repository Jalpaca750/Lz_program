--说明：指定成本
--作者：Frank.H
--创建：2010.09.08
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@DeptNo:部门
--	@CorpNo:公司
--	@AddPay:包含付款单
--	@AddAdv:包含预付款
--	@AddCash:包含现金销售
--	@AddGather:包含交款单
--	@Flag:前台标识
CREATE Function dbo.fn_PlanPrice
(
	@Year bigint,
	@DeptNo varchar(20),
	@ClassID varchar(20),
	@LabelID varchar(20),
	@Flag bit=0
)
Returns @uTable Table
(
	DeptNo varchar(20),
	DeptName varchar(100),
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemAlias varchar(200),
	NameSpell varchar(200),
	ItemSpec varchar(100),
	BarCode varchar(100),
	ClassID varchar(20),
	ClassName varchar(100),
	LabelID varchar(20),
	LabelName varchar(100),
	ColorName varchar(40),
	UnitName varchar(40),
	Month01 decimal(18,6),
	Month02 decimal(18,6),
	Month03 decimal(18,6),
	Month04 decimal(18,6),
	Month05 decimal(18,6),
	Month06 decimal(18,6),
	Month07 decimal(18,6),
	Month08 decimal(18,6),
	Month09 decimal(18,6),
	Month10 decimal(18,6),
	Month11 decimal(18,6),
	Month12 decimal(18,6)
	Primary Key(DeptNo,ItemID)
)
As
Begin
	If @Flag=0 
		Return
	
	Insert Into @uTable(DeptNo,DeptName,ItemID,ItemNo,ItemName,ItemAlias,NameSpell,
		ItemSpec,BarCode,ClassID,ClassName,LabelID,LabelName,ColorName,UnitName,
		Month01,Month02,Month03,Month04,Month05,Month06,Month07,Month08,Month09,
		Month10,Month11,Month12)
	Select a.DeptNo,d.CHName As DeptName,a.ItemID,g.ItemNo,g.ItemName,g.ItemAlias,
		g.NameSpell,g.ItemSpec,g.BarCode,g.ClassID,g.ClassName,g.LabelID,g.LabelName,
		g.UnitName,g.ColorName,
		Month01=SUM(Case a.CstMonth When 1 Then a.Price Else 0.0 End),
		Month02=SUM(Case a.CstMonth When 2 Then a.Price Else 0.0 End),
		Month03=SUM(Case a.CstMonth When 3 Then a.Price Else 0.0 End),
		Month04=SUM(Case a.CstMonth When 4 Then a.Price Else 0.0 End),
		Month05=SUM(Case a.CstMonth When 5 Then a.Price Else 0.0 End),
		Month06=SUM(Case a.CstMonth When 6 Then a.Price Else 0.0 End),
		Month07=SUM(Case a.CstMonth When 7 Then a.Price Else 0.0 End),
		Month08=SUM(Case a.CstMonth When 8 Then a.Price Else 0.0 End),
		Month09=SUM(Case a.CstMonth When 9 Then a.Price Else 0.0 End),
		Month10=SUM(Case a.CstMonth When 10 Then a.Price Else 0.0 End),
		Month11=SUM(Case a.CstMonth When 11 Then a.Price Else 0.0 End),
		Month12=SUM(Case a.CstMonth When 12 Then a.Price Else 0.0 End)
	From CST_PlanPrice a Inner Join BDM_DeptCode_V d On a.DeptNo=d.CodeID
			     Inner Join BDM_ItemInfo_V g On a.ItemID=g.ItemID
	Where a.CstYear=@Year 
		And (a.DeptNo Like @DeptNo + '%')
		And (g.ClassID Like @ClassID + '%')
		And (g.LabelID Like @LabelID + '%')
	Group By a.DeptNo,d.CHName,a.ItemID,g.ItemNo,g.ItemName,g.ItemAlias,
		g.NameSpell,g.ItemSpec,g.BarCode,g.ClassID,g.ClassName,g.LabelID,g.LabelName,
		g.UnitName,g.ColorName
	Return
End
go

