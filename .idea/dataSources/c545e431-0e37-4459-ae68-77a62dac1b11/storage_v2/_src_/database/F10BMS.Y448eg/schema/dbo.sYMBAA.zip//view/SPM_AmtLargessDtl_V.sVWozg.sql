CREATE VIEW dbo.SPM_AmtLargessDtl_V
AS
SELECT a.LargessNo, a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, 
      b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, b.LabelID, b.LabelName, 
      b.ColorName, b.UnitName, b.OnHandQty, b.AvailQty, a.ZQty, a.SaleRoom, 
      a.CheckBox
FROM dbo.SPM_AmtLargessDtl a INNER JOIN
      dbo.BDM_ItemInfo_V b ON a.ItemID = b.ItemID
go

