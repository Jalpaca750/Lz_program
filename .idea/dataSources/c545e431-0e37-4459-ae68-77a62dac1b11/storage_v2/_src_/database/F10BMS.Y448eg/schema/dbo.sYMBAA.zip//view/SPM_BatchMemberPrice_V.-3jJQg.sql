--批量设置会员价
CREATE View SPM_BatchMemberPrice_V
--with encryption
As
SELECT a.BatchMemberPriceNo,a.MemberID
,CASE isnull(c.CHName,'') WHEN '' THEN '所有客户' ELSE c.CHName END AS Member
,a.ClassID,CASE isnull(e.CHName, '') WHEN '' THEN '所有大类' ELSE e.CHName END AS Class
,a.LabelID, CASE isnull(f.CHName, '') WHEN '' THEN '所有品牌' ELSE f.CHName END AS Label
,a.PriceType,a.DiscRate,a.CreatorID,b.EmployeeName AS Creator

,CASE isnull(a.PriceType,'')  WHEN 'Sprice' THEN '零售价' WHEN 'SPrice1' THEN '批发价'  WHEN 'SPrice2' THEN '直销价'  WHEN 'SPrice3' THEN '网站价' Else '' END AS Price

FROM dbo.SPM_BatchMemberPrice a 
LEFT OUTER JOIN      dbo.BDM_LabelCode_V f ON a.LabelID = f.CodeID 
LEFT OUTER JOIN      dbo.BDM_ItemClass_V e ON a.ClassID = e.CodeID 
LEFT OUTER JOIN      dbo.BDM_MemberCode_V c ON a.MemberID = c.CodeID 
LEFT OUTER JOIN      dbo.BDM_Employee b ON a.CreatorID = b.EmployeeID





go

