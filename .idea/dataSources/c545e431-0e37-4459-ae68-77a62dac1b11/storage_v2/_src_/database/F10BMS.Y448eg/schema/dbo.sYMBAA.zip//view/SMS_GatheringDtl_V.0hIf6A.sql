CREATE VIEW dbo.SMS_GatheringDtl_V
AS
SELECT a.GatheringID, a.GatheringNo, c.CreateDate, c.BillSts, a.ShiftNo, a.PCNo, 
      b.CreatorID, b.Creator, b.ReceiverID, b.Receiver, a.RestAmt, a.Amt, a.PAmt, a.PayAmt, 
      a.LAmt, a.SAmt, a.Remark, a.CheckBox
FROM dbo.SMS_GatheringDtl a LEFT OUTER JOIN
      dbo.SMS_Gathering c ON a.GatheringNo = c.GatheringNo LEFT OUTER JOIN
      dbo.SMS_Shift_V b ON a.ShiftNo = b.ShiftNo
go

