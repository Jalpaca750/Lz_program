--说明：分部客户销售汇总分析
--作者：Devil.H
--创建：2010.08.02
--参数：	
--	@StartDate:起始日期
--	@ENDDate:截至日期
--	@CorpNo:公司
--	@DeptNo:分部
--	@Flag :为前台设计
CREATE FUNCTION dbo.fn_AnalSMS3H1
(
	@StartDate CHAR(10)='0000-01-01',
	@ENDDate CHAR(10)='9999-12-31',
	@WareHouse VARCHAR(20)='',
	@DeptNo VARCHAR(20)='',
	@CustID BIGINT=0,
	@ItemID BIGINT=0,
	@Flag bit=0
)
RETURNS @uTable TABLE(
	CustID BIGINT,
	CustNo VARCHAR(20),
	CustName VARCHAR(200),
	NameSpell VARCHAR(200),
	LinkMan VARCHAR(40),
	Phone VARCHAR(80),
	Faxes VARCHAR(40),
	CustType VARCHAR(20),
	TypeName VARCHAR(100),
	MemberID VARCHAR(20),
	Member VARCHAR(100),
	AreaCode VARCHAR(20),
	AreaName VARCHAR(100),
	PopedomID VARCHAR(20),
	PopedomName VARCHAR(100),
	KindName VARCHAR(100),
	TradeName VARCHAR(100),
	SalesID BIGINT,
	Sales VARCHAR(100),
	SelAmt DECIMAL(18,6),
	RetAmt DECIMAL(18,6),
    RealAmt DECIMAL(18,6),            --实际销售额(去掉返点，平台费)
    RebateAmt DECIMAL(18,6),          --返点
    PlatformFee DECIMAL(18,6),        --平台费
	TotalAmt DECIMAL(18,6),
	SelPercent DECIMAL(18,6),
	RetPercent DECIMAL(18,6),
	R_SScale DECIMAL(18,6),
	R_SPercent DECIMAL(18,6)
)
AS
BEGIN
	IF (@Flag=0)
        RETURN;
	DECLARE @SUMAmt DECIMAL(18,6),@SUMRAmt DECIMAL(18,6),@AmtDec INT;
    DECLARE @Tmp TABLE(CustID BIGINT,RetAmt DECIMAL(18,6),SelAmt DECIMAL(18,6),RebateAmt DECIMAL(18,6),PlatformFee DECIMAL(18,6),TotalAmt DECIMAL(18,6));
    --初始化变量
	SET @StartDate=CONVERT(CHAR(10),CAST(@StartDate AS DATETIME),23);
	SET @ENDDate=CONVERT(CHAR(10),CAST(@ENDDate AS DATETIME),23);
    SELECT @AmtDec=ISNULL(AmtDec,2) FROM SYS_Config;
    --数据收集
	INSERT INTO @Tmp(CustID,RetAmt,SelAmt,RebateAmt,PlatformFee,TotalAmt)
	SELECT a.CustID,
		RAmt=ABS(ISNULL(SUM(CASE a.BillType WHEN '20' THEN b.Amt ELSE 0.0 END),0.0))
			+ABS(ISNULL(SUM(CASE a.BillType WHEN '50' THEN b.Amt ELSE 0.0 END),0.0)),
		SAmt=ISNULL(SUM(CASE a.BillType WHEN '10' THEN b.Amt ELSE 0.0 END),0.0)
			+ISNULL(SUM(CASE a.BillType WHEN '30' THEN b.Amt ELSE 0.0 END),0.0)
			+ISNULL(SUM(CASE a.BillType WHEN '40' THEN b.Amt ELSE 0.0 END),0.0),
        RebateAmt=ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0),@AmtDec),
        PlatformFee=ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0),@AmtDec),
		TAmt=SUM(b.Amt)
	FROM SMS_Stock a 
        INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
        INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		AND (CONVERT(CHAR(10),CAST(a.CreateDate AS DATETIME),23) BETWEEN @StartDate AND @ENDDate) 
		AND (a.DeptNo=@DeptNo)
		AND (b.WareHouse Like @WareHouse + '%')	
		AND (a.CustID=@CustID Or @CustID=0)
		AND (b.ItemID=@ItemID Or @ItemID=0)
	GROUP BY a.CustID;
	--获取以上客户的总销售额
	SELECT @SUMAmt=SUM(SelAmt),@SUMRAmt=SUM(RetAmt) FROM @Tmp;
    --汇总数据
	INSERT INTO @uTable(CustID,CustNo,CustName,NameSpell,CustType,TypeName,MemberID,Member,AreaCode,
        AreaName,PopedomID,PopedomName,SalesID,Sales,LinkMan,Phone,Faxes,KindName,TradeName,SelAmt,
        RetAmt,RebateAmt,PlatformFee,RealAmt,TotalAmt,SelPercent,RetPercent,R_SPercent,R_SScale)
	SELECT a.CustID,c.CustNo,c.CustName,c.NameSpell,c.CustType,c.TypeName,c.MemberID,c.Member,c.AreaCode,
		c.AreaName,c.PopedomID,c.PopedomName,c.SalesID,c.Sales,c.LinkMan,c.Phone,c.Faxes,c.KindName,c.TradeName,
        a.SelAmt,a.RetAmt,a.RebateAmt,a.PlatformFee,a.RealAmt,a.TotalAmt,a.SelPercent,a.RetPercent,a.R_SPercent,
		CASE ISNULL(a.SelPercent,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(a.RetPercent,0.0)/a.SelPercent,6) END
	FROM BAS_Customer_V c 
        INNER JOIN (SELECT CustID,SelAmt,RetAmt,TotalAmt,RebateAmt,PlatformFee,
                        ISNULL(TotalAmt,0.0)-ISNULL(RebateAmt,0.0)-ISNULL(PlatformFee,0.0) AS RealAmt,
                        CASE ISNULL(@SUMAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(SelAmt,0.0)/@SUMAmt,6) END AS SelPercent,
                        CASE ISNULL(@SUMRAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(RetAmt,0.0)/@SUMRAmt,6) END AS RetPercent,
                        CASE ISNULL(SelAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(RetAmt,0.0)/SelAmt,6) END AS R_SPercent
                    FROM @Tmp) a ON a.CustID=c.CustID;
    DELETE FROM @Tmp;
	--返回
	RETURN;
END
go

