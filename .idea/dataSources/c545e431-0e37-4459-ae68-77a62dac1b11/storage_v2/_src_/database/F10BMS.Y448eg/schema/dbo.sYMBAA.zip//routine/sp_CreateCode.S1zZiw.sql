-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2018-08-10>
-- Description:	<Description:根据编码策略生成系统编号>
-- 编码策略：目前支持以下编码策略
--		1 -分部标识 + 前缀 + 日期 + 5位流水
--		2 -分部标识 + 前缀 + 日期 + 4位流水 
--		3 -分部标识 + 前缀 + 起始编号 + 流水
--		8 -分部标识 + 起始编号 + 流水
--		9 -分部标识 + 前缀 + 8位流水
--		10-分部标识 + 前缀 + 7位流水
--		11-分部标识 + 前缀 + 6位流水
--		4 -前缀 + 起始编号 + 流水
--		5 -前缀 + 日期 + 5位流水
--		6 -前缀 + 日期 + 4位流水	
--		7 -起始编号 + 流水
-- =============================================
CREATE PROCEDURE [dbo].[sp_CreateCode] 
(
    @CorpNo VARCHAR(2),
	@billType VARCHAR(32),
	@creatorId VARCHAR(32),
	@billNo VARCHAR(32) OUT
)
AS
BEGIN
    DECLARE @companyNo VARCHAR(32),@codeRule INT,@prefix VARCHAR(40),@link VARCHAR(1),@startNum INT
	DECLARE @tmpPrefix VARCHAR(40),@flowId VARCHAR(32),@flowNum INT
    DECLARE @ErrMsg NVARCHAR(4000),@ErrSeverity INT,@errors BIGINT;	
    SET @errors=0;
	BEGIN TRAN
    --排队等待
	WHILE EXISTS(SELECT * FROM dbo.SYS_BillType WHERE billType=@billType AND ISNULL(Locked,0)=1)
	BEGIN
		SET @errors=0;
	END
    UPDATE dbo.SYS_BillType SET Locked=1 WHERE billType=@billType;
    SET @errors=@errors+@@ERROR;
    --GUID
	SET @flowId=REPLACE(NEWID(),'-','');
	--取得分部标识
	SELECT @companyNo=@CorpNo;
	--取得编码规则
	SELECT @codeRule=codeRule,@prefix=prefix,@link=link,@startNum=startNum
	FROM SYS_BillType
	WHERE billType=@billType;
    SET @errors=@errors+@@ERROR;
	--1 -分部标识 + 前缀 + 日期 + 5位流水
	--2 -分部标识 + 前缀 + 日期 + 4位流水 
    IF ISNULL(@codeRule,1)=1 OR ISNULL(@codeRule,1)=2
		SET @tmpPrefix=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+CONVERT(VARCHAR(6),GETDATE(),12)     
    --3 -分部标识 + 前缀 + 起始编号 + 流水
	IF ISNULL(@codeRule,1)=3
		SET @tmpPrefix=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+CAST(@startNum AS VARCHAR)
	--4 -前缀 + 起始编号 + 流水
    IF ISNULL(@codeRule,1)=4
		SET @tmpPrefix=ISNULL(@prefix,'')+ISNULL(@link,'')+CAST(@startNum AS VARCHAR)
	--5 -前缀 + 日期 + 5位流水
	--6 -前缀 + 日期 + 4位流水
    IF ISNULL(@codeRule,1)=5 OR ISNULL(@codeRule,1)=6
		SET @tmpPrefix=ISNULL(@prefix,'')+ISNULL(@link,'')+CONVERT(VARCHAR(6),GETDATE(),12)
	--7 -起始编号 + 流水
    IF ISNULL(@codeRule,1)=7
		SET @tmpPrefix=CAST(@startNum AS VARCHAR)
    --8 -分部标识 + 起始编号 + 流水
    IF ISNULL(@codeRule,1)=8
		SET @tmpPrefix=ISNULL(@companyNo,'')+ISNULL(@link,'')+CAST(@startNum AS VARCHAR)
	--9 -分部标识 + 前缀 + 8位流水
	--10-分部标识 + 前缀 + 7位流水
	--11-分部标识 + 前缀 + 6位流水
	IF ISNULL(@codeRule,1)=9 OR ISNULL(@codeRule,1)=10 OR ISNULL(@codeRule,1)=11
		SET @tmpPrefix=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')
	SET @errors=@errors+@@ERROR;
    --生成新编号
	INSERT INTO SYS_Coding(CodingId,prefix,flowNum,billType,creatorId,createTime)
	SELECT @flowId,@tmpPrefix,ISNULL(MAX(flowNum),0) + 1,@billType,@creatorId,GETDATE()
	FROM SYS_Coding
	WHERE billType=@billType AND prefix=@tmpPrefix;
    SET @errors=@errors+@@ERROR;
	--获取流水号
	SELECT @flowNum=flowNum FROM SYS_Coding WHERE CodingId=@flowId;
    SET @errors=@errors+@@ERROR;
	--生产新的编号
	--1 -分部标识 + 前缀 + 日期 + 5位流水
    IF ISNULL(@codeRule,1)=1
		SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+CONVERT(VARCHAR(6),GETDATE(),12)+RIGHT('00000' + CAST(@flowNum AS VARCHAR),5)   
	--2 -分部标识 + 前缀 + 日期 + 4位流水 
    IF ISNULL(@codeRule,1)=2
		SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+CONVERT(VARCHAR(6),GETDATE(),12)+RIGHT('0000' + CAST(@flowNum AS VARCHAR),4)
	--3 -分部标识 + 前缀 + 起始编号 + 流水
    IF ISNULL(@codeRule,1)=3
		SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+CAST((@startNum + @flowNum) AS VARCHAR)
    --4 -前缀 + 起始编号 + 流水
    IF ISNULL(@codeRule,1)=4
        SET @billNo=ISNULL(@prefix,'')+ISNULL(@link,'')+CAST((@startNum + @flowNum) AS VARCHAR)
    --5 -前缀 + 日期 + 5位流水
	IF ISNULL(@codeRule,1)=5
		SET @billNo=ISNULL(@prefix,'')+ISNULL(@link,'')+CONVERT(VARCHAR(6),GETDATE(),12)+RIGHT('00000' + CAST(@flowNum AS VARCHAR),5)
    --6 -前缀 + 日期 + 4位流水
	IF ISNULL(@codeRule,1)=6
		SET @billNo=ISNULL(@prefix,'')+ISNULL(@link,'')+CONVERT(VARCHAR(6),GETDATE(),12)+RIGHT('0000' + CAST(@flowNum AS VARCHAR),4)
    --7 -起始编号 + 流水
	IF ISNULL(@codeRule,1)=7
		SET @billNo=CAST((@startNum + @flowNum) AS VARCHAR) 
	--8 -分部标识 + 起始编号 + 流水
    IF ISNULL(@codeRule,1)=8
		SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+CAST((@startNum + @flowNum) AS VARCHAR)
	--9 -分部标识 + 前缀 + 8位流水
	IF ISNULL(@codeRule,1)=9 
		SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+RIGHT('00000000' + CAST(@flowNum AS VARCHAR),8)   
    --10-分部标识 + 前缀 + 7位流水   
	IF ISNULL(@codeRule,1)=10
		SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+RIGHT('0000000' + CAST(@flowNum AS VARCHAR),7)  
    --11-分部标识 + 前缀 + 6位流水    
	IF ISNULL(@codeRule,1)=11
		SET @billNo=ISNULL(@companyNo,'')+ISNULL(@link,'')+ISNULL(@prefix,'')+RIGHT('000000' + CAST(@flowNum AS VARCHAR),6)  
    SET @errors=@errors+@@ERROR;
	UPDATE dbo.SYS_BillType SET Locked=0 WHERE billType=@billType; 
    SET @errors=@errors+@@ERROR;
    IF (@errors=0)
    BEGIN
		COMMIT;
    END
    ELSE
	BEGIN
		IF @@TRANCOUNT>0
			ROLLBACK;
		SET @billNo=''
        SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;	
        UPDATE dbo.SYS_BillType SET Locked=0 WHERE billType=@billType; 
	END  
END
go

