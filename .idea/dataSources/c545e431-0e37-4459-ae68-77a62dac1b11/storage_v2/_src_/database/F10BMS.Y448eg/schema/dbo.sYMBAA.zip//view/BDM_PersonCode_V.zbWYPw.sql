--人员规模
CREATE VIEW dbo.BDM_PersonCode_V
AS
SELECT CodeID, CodeNo, CHName, ENName,Flag,Classify, CheckBox
FROM dbo.BDM_CODE
WHERE (Classify = 'FL19')
go

