--说明：营业员零售商品汇总分析
--作者：Devil.H
--创建：2014.04.04
--参数：
--	@StartDate:起始日期
--	@EndDate：截止日期
--	@DeptNo:分部
--	@CorpNo:公司
--	@Flag: 分析标识
CREATE Function dbo.fn_AnalRMS51
(
	@StartDate varchar(10),
	@EndDate varchar(10),
	@CorpNo varchar(2),
	@DeptNo varchar(20),
	@Flag bit
)
Returns Table
As
Return (SELECT c.CreatorID,d.EmployeeName AS CreatorName,c.ItemID,g.ItemNo,g.ItemName,g.ItemSpec,
		g.NameSpell,g.ItemAlias,g.BarCode,g.ClassID,g.ClassName,g.LabelID,
		g.LabelName,g.ColorName,g.UnitName,c.SQty,c.Amt,c.MaxPrice,c.MinPrice,
		c.AvgPrice
	FROM (SELECT a.CreatorID,b.ItemID,
			SUM(CASE a.BillType WHEN '40' THEN b.SQty WHEN '50' THEN -b.SQty END) AS SQty,
			SUM(CASE a.BillType WHEN '40' THEN b.Amt WHEN '50' THEN -b.Amt END) AS Amt,
			MAX(b.Price) AS MaxPrice,MIN(b.Price) AS MinPrice,AVG(b.Price) AS AvgPrice
		FROM SMS_Retail a INNER JOIN SMS_RetailDtl b ON a.RetailNo=b.RetailNo
		WHERE (a.BillSts='20' Or a.BillSts='30')
			And (CONVERT(CHAR(10),CAST(a.CreateDate AS DATETIME),120) between @StartDate And @EndDate)
			And (a.DeptNo Like @DeptNo + '%')
			And (Exists(SELECT 1 FROM BDM_DeptCode_V v WHERE (v.CodeID=a.DeptNo) And (v.DeptNo Like @CorpNo + '%')))
		GROUP BY a.CreatorID,b.ItemID) C INNER JOIN BAS_Goods_V g ON c.ItemID=g.ItemID
					         LEFT OUTER JOIN BDM_Employee d ON c.CreatorID=d.EmployeeID

)
go

