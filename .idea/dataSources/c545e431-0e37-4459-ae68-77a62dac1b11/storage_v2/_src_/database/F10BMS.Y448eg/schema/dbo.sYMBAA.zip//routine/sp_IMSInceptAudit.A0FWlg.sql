--调拨入库单审核操作（BillSts='20'审核/BillSts='10'取消审核)
--2007-09-11
--Devil.H
--当上述操作发生时：
--审核：商品资料中库存数量减少，库房总帐中库存数量、已分配量减少；
--     写入商品入出库流水帐
--取消审核：和审核操作相反
CREATE Proc sp_IMSInceptAudit
(
	@InceptNo varchar(20),
	@Flag char(2)
)
As
Begin
	declare @WareHouse varchar(20)
	declare @DeptNo varchar(20)
	declare @CreateDate char(10)
	declare @AuditDate char(10)
	declare @InceptID bigint
	declare @ItemID bigint
	declare @OrderNo varchar(20)
	declare @OrderID bigint
	declare @AllotID bigint
	declare @Location varchar(20)
	declare @IQty decimal(18,6)
	declare @AllotNo varchar(20)
	declare @Price decimal(18,6)
	--日期、出库单号
	Select @WareHouse=WareHouse,@DeptNo=DeptNo,@AuditDate=AuditDate,
		@CreateDate=CreateDate
	From IMS_Incept 
	Where InceptNo=@InceptNo
	--临时表
	Create Table #Tmp(DeptNo varchar(20),WareHouse varchar(20),ItemID bigint,SQty decimal(18,6))
	--汇总数据
	Insert Into #Tmp(DeptNo,WareHouse,ItemID,SQty)
	Select @DeptNo,@WareHouse,ItemID,isnull(Sum(IQty),0.0)
	From IMS_InceptDtl
	Where InceptNo=@InceptNo
	Group By ItemID

	declare @Tmp1 Table(
			DeptNo varchar(20),
			ItemID bigint,
			SPrice decimal(18,6)
			Primary Key(DeptNo,ItemID)
			)
	--审核
	if @Flag='20'
		Begin
			--写入流水帐
			Insert Into IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,CreateDate,AuditDate)
			Select InceptNo,'调拨入库单',@DeptNo,@WareHouse,ItemID,Isnull(IQty,0),Price,Amt,
				@CreateDate,@AuditDate
			From IMS_InceptDtl
			Where InceptNo=@InceptNo And Not Exists(Select 1 From IMS_Flow Where BillNo=@InceptNo)
			--更商品资料总库存
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0.0)+Isnull(b.SQty,0.0)
			From BDM_ItemInfo a Inner Join #Tmp b On a.ItemID=b.ItemID
			--更新分部库存总帐
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0.0)+Isnull(b.SQty,0.0)
			From IMS_Subdepot a Inner Join #Tmp b On a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
			Insert Into IMS_Subdepot(DeptNo,ItemID,OnHandQty)
			Select DeptNo,ItemID,SQty
			From #Tmp a
			Where Not Exists(Select 1 From IMS_Subdepot b Where a.ItemID=b.ItemID And a.DeptNo=b.DeptNo)
			--更新库房总帐
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0.0)+Isnull(b.SQty,0.0),a.LastTime=Getdate()
			From IMS_Ledger a Inner Join #Tmp b On a.ItemID=b.ItemID And a.WareHouse=b.WareHouse
			Insert Into IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastTime)
			Select DeptNo,WareHouse,ItemID,SQty,getdate()
			From #Tmp a
			Where Not Exists(Select 1 From IMS_Ledger b Where a.ItemID=b.ItemID And a.WareHouse=b.WareHouse)
			--更新库房总帐相关数据
			declare mycursor cursor
			for select OrderID,ItemID,Location,IQty,Price from IMS_InceptDtl Where InceptNo=@InceptNo
			open mycursor
			fetch next from mycursor into @OrderID,@ItemID,@Location,@IQty,@Price
			while @@fetch_status=0
			begin
				--更新订单已入库数量
				Update PMS_OrderDtl Set SQty=isnull(SQty,0)+isnull(@IQty,0) Where OrderID=@OrderID
				--更新分部最近价
				Update a Set a.PPrice=b.Price
				From IMS_Subdepot a,IMS_InceptDtl b
				Where a.ItemID=b.ItemID And a.DeptNo=@DeptNo
				--更新库房总帐
				if exists(Select 1 from IMS_Ledger Where ItemID=@ItemID And WareHouse=@WareHouse)
					Update a Set a.LastIPrice=Case when Isnull(b.Price,0)>0 then b.Price else a.LastIPrice End,
						a.Location=Case isnull(b.Location,'') When '' then a.Location else b.Location End,
						a.LastIDate=@CreateDate
					From IMS_Ledger a,IMS_InceptDtl b
					Where a.ItemID=b.ItemID And a.WareHouse=@WareHouse And b.InceptID=@InceptID
				fetch next from mycursor into @OrderID,@ItemID,@Location,@IQty,@Price
			end
			close mycursor
			deallocate mycursor 
			
			--零售价
			Insert Into @Tmp1(DeptNo,ItemID,SPrice)
			Select x.DeptNo,y.ItemID,Max(y.SPrice)
			From IMS_Incept x Inner Join IMS_InceptDtl y ON x.InceptNo=y.InceptNo
			Where x.InceptNo=@InceptNo
			Group By x.DeptNo,y.ItemID
 			--更新零售价
			Update a Set a.SPrice=Case ISNULL(b.SPrice,0.0) When 0.0 Then a.SPrice Else b.SPrice End,
				     a.LstDate=Convert(varchar(10),GetDate(),120),
				     a.SourceDesc='调拨入库单',BillNo=@InceptNo
			From SMS_RetailPrice a Inner Join @Tmp1 b ON a.DeptNo=b.DeptNo And a.ItemID=b.ItemID

			Insert Into SMS_RetailPrice(DeptNo,ItemID,SPrice,LstDate,SourceDesc,BillNo)
			Select DeptNo,ItemID,SPrice,Convert(varchar(10),GetDate(),120),'调拨入库单',@InceptNo
			From @Tmp1 a 
			Where Not Exists(Select 1 From SMS_RetailPrice t Where a.DeptNo=t.DeptNo And a.ItemID=t.ItemID)

		End
	if @Flag='10'
		Begin 
			--写入流水帐
			Delete From IMS_Flow Where BillNo=@InceptNo
			--更商品资料总库存
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.SQty,0)
			From BDM_ItemInfo a Inner Join #Tmp b On a.ItemID=b.ItemID
			--更新分部库存总帐
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.SQty,0)
			From IMS_Subdepot a Inner Join #Tmp b On a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
			--更新库房总帐
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.SQty,0),a.LastTime=getdate()
			From IMS_Ledger a Inner Join #Tmp b On a.ItemID=b.ItemID And a.WareHouse=b.WareHouse
			declare mycursors cursor
			for select OrderID,ItemID,Location,IQty,Price from IMS_InceptDtl Where InceptNo=@InceptNo
			open mycursors
			fetch next from mycursors into @OrderID,@ItemID,@Location,@IQty,@Price
			while @@fetch_status=0
			begin
				--更新订单已入库数量
				Update PMS_OrderDtl Set SQty=isnull(SQty,0)-isnull(@IQty,0) Where OrderID=@OrderID
				fetch next from mycursors into @OrderID,@ItemID,@Location,@IQty,@Price
			end
			close mycursors
			deallocate mycursors 
		End
	if @Flag='00'		--作废单据
		begin
			--已出库数量更新
			Update a Set a.IQty=Isnull(a.IQty,0)-Isnull(b.IQty,0)
			From IMS_AllotDtl a,IMS_InceptDtl b
			Where a.AllotID=b.AllotID And b.InceptNo=@InceptNo
			declare mycursor1 cursor
			for select Distinct AllotNo from IMS_AllotDtl Where AllotID In(Select AllotID From IMS_InceptDtl Where InceptNo=@InceptNo)
			open mycursor1
			fetch next from mycursor1 into @AllotNo
			while @@fetch_Status=0
			begin
				--存在未执行的记录
				if exists(Select 1 from IMS_AllotDtl Where Isnull(IQty,0)>0 And AllotNo=@AllotNo)
					Update IMS_Allot Set BillSts='25' Where AllotNo=@AllotNo
				else
					Update IMS_Allot Set BillSts='20' Where AllotNo=@AllotNo	
				fetch next from mycursor1 into @AllotNo
			end
			close mycursor1
			deallocate mycursor1
		end 
End
go

