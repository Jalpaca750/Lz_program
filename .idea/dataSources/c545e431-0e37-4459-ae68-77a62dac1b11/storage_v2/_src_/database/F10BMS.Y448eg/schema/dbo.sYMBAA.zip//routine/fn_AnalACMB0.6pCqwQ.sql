--说明：应付款汇总表
--作者：Devil.H
--创建：2010.12.16
--参数：
--	@Period:年度
--	@Flag:前台标识
CREATE Function dbo.fn_AnalACMB0
(
	@Period varchar(6),
	@Flag int=0
)
Returns @uTable Table(
	VendorID bigint,
	VendorNo varchar(20),
	VendorName varchar(200),
	NameSpell varchar(200),
	BuyerID bigint,
	BuyerName varchar(100),
	QCWSPAmt decimal(18,6),	--期初未开票
	QCWFKAmt decimal(18,6),	--期初未付款
	QCYFKAmt decimal(18,6),	--期初应付款
	BQWSPAmt decimal(18,6),	--本期未收票
	BQYSPAmt decimal(18,6),	--本期已收票
	BQCGEAmt decimal(18,6), --本期采购额	
	BQFKEAmt decimal(18,6),	--本期付款额(本期发票)	
	BQFKSAmt decimal(18,6),	--本期付款额(前期发票)
	BQFKTAmt decimal(18,6), --本期付款额(总)	
	BQYFKAmt decimal(18,6),	--本期预付款
	BQCXEAmt decimal(18,6), --本期冲预收款
	BQIZRAmt decimal(18,6), --本期发票折扣
	BQMFKAmt decimal(18,6),	--本期免收款
	BQTZRAmt decimal(18,6),	--本期折让合计
	QMWSPAmt decimal(18,6),	--期末未收票
	QMWFKAmt decimal(18,6),	--期末未付款
	QMYFKAmt decimal(18,6)	--期末应付款
)
As
begin
	if @Flag=0 
		Return
	declare @StartDate varchar(10)
	declare @EndDate varchar(10)
	--临时表
	declare @Tmp Table(
		VendorID bigint,
		QCWSPAmt decimal(18,6),	--期初未开票
		QCWFKAmt decimal(18,6),	--期初未付款
		QCYFKAmt decimal(18,6),	--期初应付款
		BQWSPAmt decimal(18,6),	--本期未收票
		BQYSPAmt decimal(18,6),	--本期已收票
		BQCGEAmt decimal(18,6), --本期采购额	
		BQFKEAmt decimal(18,6),	--本期付款额(本期发票)	
		BQFKSAmt decimal(18,6),	--本期付款额(前期发票)
		BQFKTAmt decimal(18,6), --本期付款额(总)	
		BQYFKAmt decimal(18,6),	--本期预付款
		BQCXEAmt decimal(18,6), --本期冲预收款
		BQIZRAmt decimal(18,6), --本期发票折扣
		BQMFKAmt decimal(18,6),	--本期免付款
		BQTZRAmt decimal(18,6),	--本期折让合计
		QMWSPAmt decimal(18,6),	--期末未收票
		QMWFKAmt decimal(18,6),	--期末未付款
		QMYFKAmt decimal(18,6)	--期末应付款
		)
	--起始日期和截止日期
	Select @StartDate=StartDate,@EndDate=EndDate From SYS_CW_MonthPeriod Where CW_Period=@Period
	
	--==================期初余额部分==================
	--期初采购未收票
	Insert Into @Tmp(VendorID,QCWSPAmt)
	Select a.VendorID,Sum(Isnull(b.Amt,0.0)-Isnull(b.IAmt,0.0))
	From PMS_Stock a Inner Join PMS_StockDtl b On a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25') 
		And a.CreateDate<@StartDate
	Group By a.VendorID
	Union All
	Select VendorID,Sum(Isnull(Amt,0.0))
	From PMS_Invoice a Inner Join PMS_InvoiceDtl b On a.InvoiceNo=b.InvoiceNo
	Where (a.BillSts='10') And a.CreateDate<@StartDate
	Group By VendorID
	--期初采购发票未付款
	Insert Into @Tmp(VendorID,QCWFKAmt)
	Select VendorID,Sum(Isnull(IAmt,0.0)-Isnull(PAmt,0.0))
	From PMS_Invoice 
	Where (BillSts='20' Or BillSts='25') 
		And CreateDate<@StartDate
	Group By VendorID

	--==================本期采购==================
	Insert Into @Tmp(VendorID,BQCGEAmt,BQWSPAmt)
	Select a.VendorID,SUM(Isnull(b.Amt,0.0)),SUM(Isnull(b.Amt,0.0)-Isnull(b.IAmt,0.0))
	From PMS_Stock a Inner Join PMS_StockDtl b On a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.VendorID
	
	--==================本期付款==================
	--本期付款额(总)，本期免付款，本期冲预付款
	Insert Into @Tmp(VendorID,BQFKTAmt,BQMFKAmt,BQCXEAmt)
	Select a.VendorID,SUM(b.PayAmt),SUM(b.FAmt),SUM(Case a.AdvFlag When 1 Then a.AdvAmt Else 0.0 End)
	From PMS_Payment a Inner Join (Select PaymentNo,Sum(PayAmt) as PayAmt,Sum(FAmt) As FAmt
				       From PMS_PaymentDtl
				       Group By PaymentNo) b On a.PaymentNo=b.PaymentNo
	Where a.BillSts='20' 
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.VendorID
	--本期发票付款
	Insert Into @Tmp(VendorID,BQFKEAmt)
	Select a.VendorID,SUM(b.PayAmt)
	From PMS_Payment a Inner Join PMS_PaymentDtl b On a.PaymentNo=b.PaymentNo
			   Inner Join PMS_Invoice c On b.InvoiceID=c.InvoiceID
	Where a.BillSts='20' 
		And (c.CreateDate Between @StartDate And @EndDate)
	Group By a.VendorID	

	--==================本期预付款==================
	Insert Into @Tmp(VendorID,BQYFKAmt)
	Select b.VendorID,SUM(b.AdvAmt)
	From PMS_Advances a Inner Join PMS_AdvancesDtl b On a.AdvancesNo=b.AdvancesNo
	Where a.BillSts='20' 
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By b.VendorID
	
	--==================本期发票折扣==================
	Insert Into @Tmp(VendorID,BQIZRAmt)
	Select VendorID,Sum(DAmt)
	From PMS_Invoice
	Where InvoiceID=Any(Select b.InvoiceID 
			    From PMS_Payment a Inner Join PMS_PaymentDtl b On a.PaymentNo=b.PaymentNo
			    Where a.BillSts='20' And (a.CreateDate Between @StartDate And @EndDate))
	Group By VendorID
	--==================期末余额部分==================
	--期末采购未收票
	Insert Into @Tmp(VendorID,QMWSPAmt)
	Select a.VendorID,Sum(Isnull(b.Amt,0.0)-Isnull(b.IAmt,0.0))
	From PMS_Stock a Inner Join PMS_StockDtl b On a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25') 
		And a.CreateDate<=@EndDate
	Group By a.VendorID
	Union All
	Select VendorID,Sum(Isnull(Amt,0.0))
	From PMS_Invoice a Inner Join PMS_InvoiceDtl b On a.InvoiceNo=b.InvoiceNo
	Where (a.BillSts='10') And a.CreateDate<@EndDate
	Group By VendorID
	--期末采购发票未付款
	Insert Into @Tmp(VendorID,QMWFKAmt)
	Select VendorID,Sum(Isnull(IAmt,0.0)-Isnull(PAmt,0.0))
	From PMS_Invoice 
	Where (BillSts='20' Or BillSts='25') 
		And CreateDate<=@EndDate
	Group By VendorID

	Insert Into @uTable(VendorID,VendorNo,VendorName,NameSpell,BuyerID,
			    QCWSPAmt,QCWFKAmt,QCYFKAmt,
			    BQWSPAmt,BQYSPAmt,BQCGEAmt,
		            BQFKEAmt,BQFKSAmt,BQFKTAmt,
		            BQYFKAmt,BQCXEAmt,
			    BQIZRAmt,BQMFKAmt,BQTZRAmt,
			    QMWSPAmt,QMWFKAmt,QMYFKAmt)
	Select a.VendorID,b.VendorNo,b.VendorName,b.NameSpell,b.BuyerID,
			Sum(a.QCWSPAmt),
			Sum(a.QCWFKAmt),
			Sum(Isnull(a.QCWSPAmt,0.0)+Isnull(a.QCWFKAmt,0.0)),
			Sum(a.BQWSPAmt),
			Sum(Isnull(a.BQCGEAmt,0.0)-Isnull(a.BQWSPAmt,0.0)),
			Sum(a.BQCGEAmt),
			Sum(a.BQFKEAmt),
			Sum(Isnull(a.BQFKTAmt,0.0)-Isnull(a.BQFKEAmt,0.0)),
			Sum(a.BQFKTAmt),
			Sum(a.BQYFKAmt),
			Sum(a.BQCXEAmt),
			Sum(a.BQIZRAmt),
			Sum(a.BQMFKAmt),
			Sum(Isnull(a.BQIZRAmt,0.0)+Isnull(a.BQMFKAmt,0.0)),
			Sum(a.QMWSPAmt),
			Sum(a.QMWFKAmt),
			Sum(Isnull(a.QMWSPAmt,0.0)+Isnull(a.QMWFKAmt,0.0))
	From @Tmp a Left Outer Join BDM_Vendor b On a.VendorID=b.VendorID
	Group By a.VendorID,b.VendorNo,b.VendorName,b.NameSpell,b.BuyerID
	Return
End
go

