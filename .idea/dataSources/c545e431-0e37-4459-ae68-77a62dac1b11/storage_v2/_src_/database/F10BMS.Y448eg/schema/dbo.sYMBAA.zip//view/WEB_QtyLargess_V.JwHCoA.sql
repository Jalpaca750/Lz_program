CREATE VIEW dbo.WEB_QtyLargess_V
AS
SELECT a.LargessNo, a.StartDate, a.EndDate, a.MemberID, a.AreaCode, a.ItemID, b.OQty, 
      b.ItemID AS ZPID, c.ItemNo AS ZPNo, c.ItemName AS ZPName, c.UnitName, b.ZQty, 
      c.SPrice3
FROM dbo.SPM_QtyLargess a INNER JOIN
      dbo.SPM_QtyLargessDtl b ON a.LargessNo = b.LargessNo INNER JOIN
      dbo.BDM_ItemInfo c ON b.ItemID = c.ItemID
go

