CREATE VIEW dbo.PMS_Rectify_V
AS
SELECT a.RectifyNo, a.CreateDate, a.DeptNo, f.CHName AS DeptName, a.VendorID, 
      b.VendorNo, b.VendorName, b.NameSpell, b.LinkMan, b.Phone, b.Faxes, b.BuyerID, 
      b.Buyer, e.Amt, a.Effect, a.BillSts, a.PrintNum, a.AuditDate, a.AuditID, 
      (SELECT StsName FROM BillStatus g WHERE a.BillSts=g.BillSts And g.BillType = 'PMS70') AS StsName,
      d.EmployeeName AS Auditer, a.PFlag, a.CreatorID, c.EmployeeName AS Creator, 
      a.PrinterID,p.EmployeeName AS Printer,a.Remarks, a.CheckBox
FROM dbo.PMS_Rectify a LEFT OUTER JOIN
      dbo.BDM_Vendor_V b ON b.VendorID = a.VendorID LEFT OUTER JOIN	 
      dbo.BDM_Employee d ON d.EmployeeID = a.AuditID LEFT OUTER JOIN
      dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V f ON a.DeptNo = f.CodeID LEFT OUTER JOIN
      (SELECT RectifyNo, SUM(Amt) AS Amt
       FROM PMS_RectifyDtl
       GROUP BY RectifyNo) e ON a.RectifyNo = e.RectifyNo
go

