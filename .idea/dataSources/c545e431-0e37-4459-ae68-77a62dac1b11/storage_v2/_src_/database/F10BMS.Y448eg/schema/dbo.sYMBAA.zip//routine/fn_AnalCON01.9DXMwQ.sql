CREATE  FUNCTION dbo.fn_AnalCON01()
RETURNS TABLE
AS
RETURN(
    SELECT b.BillId,a.BillNo,a.CreateDate,c.CustNo,c.CustName,a.ContractNo,a.PoNo,a.SendAddr,a.LinkMan,a.Phone,a.Remarks AS memo,
        g.ItemNo,g.ItemName,g.ItemSpec,g.LabelName,g.ClassName,g.UnitName,g.ColorName,g.BarCode, b.Qty,b.Price,
        ROUND(ISNULL(b.Qty,0.0)*ISNULL(b.Price,0.0),2) AS Amt,c.CustType,c.TypeName,c.PopedomID,c.PopedomName,
        c.AreaCode,c.AreaName,c.MemberId,c.Member,a.SalesId,e1.EmployeeName AS SalesName,a.Title,a.DeptNo,
        d.CHName AS DeptName,b.Remarks,a.CreatorID,e2.EmployeeName AS CreatorName,e3.EmployeeName AS AuditerName,
        a.ZT,(SELECT TOP 1 StsName FROM BillStatus sts WHERE a.BillSts=sts.BillSts AND sts.BillType='CON20') AS StsName
    FROM CON_SMS a
        INNER JOIN CON_SMSDtl b ON a.BillNo=b.BillNo
        INNER JOIN BAS_Customer_V c ON a.CustID=c.CustID
        INNER JOIN BAS_Goods_V g ON b.ItemId=g.ItemId
        LEFT JOIN BDM_Employee e1 ON a.SalesId=e1.EmployeeID
        LEFT JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
        LEFT JOIN BDM_Employee e2 ON a.CreatorID=e2.EmployeeID
        LEFT JOIN BDM_Employee e3 ON a.AuditID=e3.EmployeeID
    WHERE a.BillSts IN('20','25','30')
)
go

