CREATE VIEW dbo.IMS_CheckStock_V
AS
SELECT a.stockId, a.pointId, a.companyId, a.warehouseId, 
      w.CHName AS WarehouseName, a.regionId, a.lotNo, a.locationWay, a.locationNo, 
      a.eId, a.itemId, g.ItemNo, g.ItemName, g.ItemAlias, g.NameSpell, g.ItemSpec, 
      g.BarCode, g.UnitName, g.ColorName, g.ClassName, g.LabelName, a.onhandQty, 
      a.realQty, cp.pointNo, cp.createTime
FROM dbo.IMS_CheckStock a INNER JOIN
      dbo.BAS_Goods_V g ON a.itemId = g.ItemID INNER JOIN
      dbo.IMS_CheckPoint cp ON a.pointId = cp.pointId INNER JOIN
      dbo.BDM_WareHouse_V w ON a.warehouseId = w.CodeID
go

