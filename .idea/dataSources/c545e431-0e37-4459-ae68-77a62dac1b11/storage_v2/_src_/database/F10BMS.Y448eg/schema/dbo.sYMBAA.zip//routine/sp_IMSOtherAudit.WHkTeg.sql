


--其他入出库单审核操作（BillSts='20'审核/BillSts='10'取消审核)
--2007-10-22
--Devil.H
--当上述操作发生时：
--单据类型：10其他入库单
--         审核：库存数量增加，取消审核库存数量减少
--	   20其他出库单
--         审核：库存数量减少，取消审核库存数量增加
--Frank.He 2017-08-31 增加中间状态处理15(WMS中间中间)
CREATE Proc [dbo].[sp_IMSOtherAudit]
(
    @OtherNo VARCHAR(20),
    @Flag CHAR(2)
)
AS
BEGIN
    DECLARE @OtherID BIGINT,
            @ItemID BIGINT,
            @DeptNo VARCHAR(20),
            @WareHouse VARCHAR(20),
            @CreateDate CHAR(10),
            @AuditDate CHAR(10),
            @BillType CHAR(2),
            @wmsBillNo VARCHAR(40),
            @remarks VARCHAR(2000),
            @Location VARCHAR(20),
            @Tmp VARCHAR(20);
	DECLARE @ErrMsg NVARCHAR(4000),@ErrSeverity INT,@errors BIGINT;
	DECLARE @tmpTable TABLE (DeptNo VARCHAR(20),Warehouse VARCHAR(20),ItemId BIGINT,SQty DECIMAL(18,6));
	--如果单据处于中间状态，则跳出(WMS过度状态)
	IF EXISTS(SELECT 1 FROM IMS_Other WHERE OtherNo=@OtherNo AND billsts='15')
		RETURN;
	DELETE FROM SAM_Error WHERE funCode='sp_IMSOtherAudit' AND billNo=@OtherNo;
	--初始化错误代码
	SET @errors=0;
    BEGIN TRANSACTION
    WHILE EXISTS(SELECT * FROM dbo.SAM_Schedule WHERE jobCode='inv_posting_job' AND IsLocked=1)
    BEGIN
        SET @errors=0;
    END
    UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='sp_IMSOtherAudit' WHERE jobCode='inv_posting_job';


	--获取更新后的入出库单号，日期
	SELECT @DeptNo=DeptNo,@WareHouse=WareHouse,@CreateDate=CreateDate,
        @AuditDate=AuditDate,@BillType=BillType,@remarks=remarks,@wmsBillNo=wmsBillNo 
	FROM IMS_Other
	WHERE OtherNo=@OtherNo;
	SET @errors=@errors+@@ERROR;
	SET @Tmp=CASE @BillType WHEN '10' THEN '其他入库单' WHEN '20' THEN '其他出库单' WHEN '30' THEN '报损出库单' WHEN '50' THEN '盘点调整单' WHEN '60' THEN '库存初始化' END;
	--汇总明细(实物才扣减库存）
	INSERT INTO @tmpTable(DeptNo,Warehouse,ItemId,SQty)
	SELECT @DeptNo,@WareHouse,a.ItemId,SUM(a.SQty) AS SQty
	FROM IMS_OtherDtl a 
	    INNER JOIN BDM_ItemInfo b On a.ItemId=b.ItemId
	WHERE a.OtherNo=@OtherNo AND ISNULL(b.IsVirtual,0)=0
	GROUP BY a.ItemId;
	SET @errors=@errors+@@ERROR;
	--其他入库单审核
	IF (@Flag='20') AND (@BillType='10' OR @BillType='60' OR @BillType='50')	
	BEGIN
		--写入流水帐
		INSERT INTO IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,memo,wmsBillNo,remarks,CreateDate,AuditDate)
		SELECT OtherNo,@Tmp,@DeptNo,@WareHouse,ItemID,SQty,Price,Amt,remarks,@wmsBillNo,@remarks,@CreateDate,@AuditDate 
		FROM IMS_OtherDtl 
		WHERE OtherNo=@OtherNo 
		    AND NOT EXISTS(SELECT 1 FROM IMS_Flow WHERE BillNo=@OtherNo);
		SET @errors=@errors+@@ERROR;
		--写入商品资料文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM BDM_ItemInfo a 
		    INNER JOIN @tmpTable b ON a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;  
		--更新分部商品总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM IMS_Subdepot a 
		    INNER JOIN @tmpTable b ON a.DeptNo=b.DeptNo AND a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
		--插入没有的分部商品总帐
		INSERT INTO IMS_Subdepot(DeptNo,ItemID,OnHandQty)
		SELECT DeptNo,ItemID,SQty
		FROM @tmpTable a 
		WHERE NOT EXISTS(SELECT * FROM IMS_Subdepot b WHERE a.DeptNo=b.DeptNo AND a.ItemId=b.ItemId);
		SET @errors=@errors+@@ERROR;		
		--更新库房总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0),a.LastIDate=@CreateDate
		FROM IMS_Ledger a 
		    INNER JOIN @tmpTable b ON a.Warehouse=b.Warehouse AND a.itemId=b.itemId;
		SET @errors=@errors+@@ERROR;		 
		--插入没有的库房总帐	
		INSERT INTO IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastIDate)
		SELECT DeptNo,WareHouse,ItemID,SQty,@CreateDate 
		FROM @tmpTable a 
		WHERE NOT EXISTS(SELECT * FROM IMS_Ledger b WHERE a.Warehouse=b.Warehouse AND a.ItemId=b.ItemId);
		SET @errors=@errors+@@ERROR;
	END
	--其他入出库单取消审核
	IF (@Flag='10') AND (@BillType='10' OR @BillType='60' OR @BillType='50')	
	BEGIN
		--删除流水帐
		DELETE FROM IMS_Flow WHERE BillNo=@OtherNo;
		SET @errors=@errors+@@ERROR;
		--写入商品资料文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
		FROM BDM_ItemInfo a 
		    INNER JOIN @tmpTable b ON a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;   
		--更新分部商品总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
		FROM IMS_Subdepot a 
		    INNER JOIN @tmpTable b ON a.DeptNo=b.DeptNo AND a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
		--更新库房总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
		FROM IMS_Ledger a 
		    INNER JOIN @tmpTable b On a.Warehouse=b.Warehouse AND a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
	END
	--其他出库单审核操作
	IF (@Flag='20') AND (@BillType='20' OR @BillType='30')	
	BEGIN
		--写入流水帐
		INSERT INTO IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,memo,wmsBillNo,remarks,CreateDate,AuditDate)
		SELECT OtherNo,@Tmp,@DeptNo,@WareHouse,ItemID,-SQty,Price,-Amt,remarks,@wmsBillNo,@remarks,@CreateDate,@AuditDate 
		FROM IMS_OtherDtl 
		WHERE OtherNo=@OtherNo AND NOT EXISTS(SELECT * FROM IMS_Flow WHERE BillNo=@OtherNo);
		SET @errors=@errors+@@ERROR;
		--写入商品资料文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
		FROM BDM_ItemInfo a 
		    INNER JOIN @tmpTable b ON a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
		--更新分部商品总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
		FROM IMS_Subdepot a 
		    INNER JOIN @tmpTable b ON a.DeptNo=b.DeptNo AND a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;    
		--插入没有的分部商品总帐
		INSERT INTO IMS_Subdepot(DeptNo,ItemID,OnHandQty)
		SELECT DeptNo,ItemID,-ISNULL(SQty,0.0)
		FROM @tmpTable a 
		WHERE NOT EXISTS(SELECT * FROM IMS_Subdepot b WHERE a.DeptNo=b.DeptNo AND a.ItemId=b.ItemId);
		SET @errors=@errors+@@ERROR;
		--更新库房总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0),a.LastODate=@CreateDate 
		FROM IMS_Ledger a 
		    INNER JOIN @tmpTable b On a.Warehouse=b.Warehouse AND a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
		--插入没有的库房总帐	
		INSERT INTO IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastODate)
		SELECT DeptNo,WareHouse,ItemID,-ISNULL(SQty,0.0),@CreateDate
		FROM @tmpTable a 
		WHERE NOT EXISTS(SELECT * FROM IMS_Ledger b WHERE a.WareHouse=b.WareHouse AND a.ItemId=b.ItemId);
		SET @errors=@errors+@@ERROR;
	END
	--其他出库单取消审核
	IF (@Flag='10') AND (@BillType='20' OR @BillType='30')	
	BEGIN
		--删除流水帐
		DELETE FROM IMS_Flow WHERE BillNo=@OtherNo;
		SET @errors=@errors+@@ERROR;
		--写入商品资料文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM BDM_ItemInfo a 
		    INNER JOIN @tmpTable b On a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
		--更新分部商品总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM IMS_Subdepot a 
		    INNER JOIN @tmpTable b On a.DeptNo=b.DeptNo And a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
		--更新库房总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM IMS_Ledger a 
		    INNER JOIN @tmpTable b On a.Warehouse=b.Warehouse And a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
	END
    UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='inv_posting_job';
    SET @errors=@errors+@@ERROR;
	--错误处理
    IF (@errors=0)
    BEGIN
		COMMIT;
    END
    ELSE
	BEGIN
        IF @@TRANCOUNT > 0
            ROLLBACK;
        SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;	
        UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='inv_posting_job';
        --写入同步错误日志	
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
        VALUES(LOWER(REPLACE(NEWID(),'-','')),'01',GETDATE(),'99','sp_IMSOtherAudit','SMS_RETURN_AUIDT_ERROR',LEFT(@ErrMsg,2000),@OtherNo,@OtherNo);
        RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END
END

go

