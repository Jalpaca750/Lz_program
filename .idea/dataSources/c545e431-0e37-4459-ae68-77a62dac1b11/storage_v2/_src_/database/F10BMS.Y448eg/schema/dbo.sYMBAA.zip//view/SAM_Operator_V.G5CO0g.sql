CREATE VIEW dbo.SAM_Operator_V
AS
SELECT a.EmployeeID, b.EmployeeNo, b.EmployeeName, a.EmployeePsd, b.DiscFlag,b.DiscRate,
	a.PCName,a.PCID, a.TeamNo, c.TeamName, a.OnLine, a.LogIn, a.LogOut, a.Notes,
	a.Employee_Auditing_Flag,a.Employee_AuditingRigth
FROM dbo.BDM_Employee b INNER JOIN
	dbo.SAM_Operator a ON b.EmployeeID = a.EmployeeID LEFT OUTER JOIN
	dbo.SAM_Team c ON a.TeamNo = c.TeamNo
WHERE (b.Flag = '1')
go

