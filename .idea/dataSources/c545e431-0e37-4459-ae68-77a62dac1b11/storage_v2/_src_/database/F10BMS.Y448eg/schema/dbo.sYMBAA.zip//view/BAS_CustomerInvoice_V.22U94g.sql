
CREATE view [dbo].[BAS_CustomerInvoice_V] as
SELECT CAST(a.CustID AS VARCHAR(32)) AS customerId,a.CustNo AS customerNo,a.CustName AS customerName,
    b.invoiceId,b.invoiceCompany,b.invoiceTax,b.invoiceAddress,b.invoiceTel,b.invoiceBank,b.invoiceAccount,
    b.isDefault,b.invoiceFlag,
    (CASE b.invoiceflag WHEN 0 THEN '不开票' WHEN 1 THEN '普票(纸)' WHEN 2 THEN '专票(纸)' WHEN 3 THEN '普票(电)' WHEN 4 THEN '专票(电)' END) AS invoiceType
FROM BDM_Customer a
    INNER JOIN BAS_CustomerInvoice b ON CAST(a.CustID AS VARCHAR(32))=b.customerId
go

