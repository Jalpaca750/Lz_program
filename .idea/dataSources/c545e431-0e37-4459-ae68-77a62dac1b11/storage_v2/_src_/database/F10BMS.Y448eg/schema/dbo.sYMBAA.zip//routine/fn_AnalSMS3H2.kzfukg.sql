--说明：分部商品销售汇总分析
--作者：Devil.H
--创建：2010.08.02
--参数：	
--	@StartDate:起始日期
--	@ENDDate:截至日期
--	@CorpNo:公司
--	@DeptNo:分部
--	@Flag :为前台设计
CREATE FUNCTION dbo.fn_AnalSMS3H2
(
	@StartDate CHAR(10)='0000-01-01',
	@ENDDate CHAR(10)='9999-12-31',
	@WareHouse VARCHAR(20)='',
	@DeptNo VARCHAR(20)='',
	@CustID BIGINT=0,
	@ItemID BIGINT=0,
	@Flag BIT=0
)
RETURNS @uTable TABLE(
	ItemID BIGINT,
	ItemNo VARCHAR(20),
	ItemName VARCHAR(200),
	ItemSpec VARCHAR(100),
	BarCode VARCHAR(100),
	ClassID VARCHAR(20),
	ClassName VARCHAR(100),
	LabelID VARCHAR(20),
	LabelName VARCHAR(100),
	ColorName VARCHAR(40),
	UnitName VARCHAR(20),
	AvgPrice DECIMAL(18,6),
	SQty DECIMAL(18,6),
	RQty DECIMAL(18,6),
	SelAmt DECIMAL(18,6),
	RetAmt DECIMAL(18,6),
    RealAmt DECIMAL(18,6),            --实际销售额(去掉返点，平台费)
    RebateAmt DECIMAL(18,6),          --返点
    PlatformFee DECIMAL(18,6),        --平台费
	TotalAmt DECIMAL(18,6),
	SelPercent DECIMAL(18,6),
	RetPercent DECIMAL(18,6),
	R_SScale DECIMAL(18,6),
	R_SPercent DECIMAL(18,6)
)
AS
BEGIN
	IF (@Flag=0)
        RETURN;
	DECLARE @SUMAmt DECIMAL(18,6),@SUMRAmt DECIMAL(18,6),@AmtDec INT;
    DECLARE @Tmp TABLE(ItemID BIGINT,RQty DECIMAL(18,6),SQty DECIMAL(18,6),RetAmt DECIMAL(18,6),SelAmt DECIMAL(18,6),RebateAmt DECIMAL(18,6),PlatformFee DECIMAL(18,6),TotalAmt DECIMAL(18,6))
	--初始化变量
	SET @StartDate=CONVERT(CHAR(10),CAST(@StartDate AS DATETIME),23);
	SET @ENDDate=CONVERT(CHAR(10),CAST(@ENDDate AS DATETIME),23);
    SELECT @AmtDec=ISNULL(AmtDec,2) FROM SYS_Config;
    --数据收集
	INSERT INTO @Tmp(ItemID,RQty,SQty,RetAmt,SelAmt,RebateAmt,PlatformFee,TotalAmt)
	SELECT b.ItemID,
		RQty=ABS(ISNULL(SUM(CASE a.BillType WHEN '20' THEN b.SQty ELSE 0.0 END),0.0))
			+ABS(ISNULL(SUM(CASE a.BillType WHEN '50' THEN b.SQty ELSE 0.0 END),0.0)),
		SQty=ISNULL(SUM(CASE a.BillType WHEN '10' THEN b.SQty ELSE 0.0 END),0.0)
			+ISNULL(SUM(CASE a.BillType WHEN '40' THEN b.SQty ELSE 0.0 END),0.0),
		RAmt=ABS(ISNULL(SUM(CASE a.BillType WHEN '20' THEN b.Amt ELSE 0.0 END),0.0))
			+ABS(ISNULL(SUM(CASE a.BillType WHEN '50' THEN b.Amt ELSE 0.0 END),0.0)),
		SAmt=ISNULL(SUM(CASE a.BillType WHEN '10' THEN b.Amt ELSE 0.0 END),0.0)
			+ISNULL(SUM(CASE a.BillType WHEN '30' THEN b.Amt ELSE 0.0 END),0.0)
			+ISNULL(SUM(CASE a.BillType WHEN '40' THEN b.Amt ELSE 0.0 END),0.0),
        RebateAmt=ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0),@AmtDec),
        PlatformFee=ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0),@AmtDec),
		TAmt=SUM(b.Amt)
	FROM SMS_Stock a 
        INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
        INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		AND (CONVERT(CHAR(10),CAST(a.CreateDate AS DATETIME),23) BETWEEN @StartDate AND @ENDDate) 
		AND (a.DeptNo=@DeptNo )
		AND (b.WareHouse Like @WareHouse + '%')	
		AND (a.CustID=@CustID Or @CustID=0)
		AND (b.ItemID=@ItemID Or @ItemID=0)
	GROUP BY b.ItemID;
	--获取商品总销售额
	SELECT @SUMAmt=SUM(SelAmt),@SUMRAmt=SUM(RetAmt) FROM @Tmp;
	INSERT INTO @uTable(ItemID,ItemNo,ItemName,ItemSpec,UnitName,ColorName,ClassID,ClassName,
		LabelID,LabelName,BarCode,RQty,SQty,RetAmt,SelAmt,RebateAmt,PlatformFee,RealAmt,TotalAmt,
		SelPercent,RetPercent,R_SPercent,AvgPrice,R_SScale)
	SELECT t.ItemID,g.ItemNo,g.ItemName,g.ItemSpec,g.UnitName,g.ColorName,g.ClassID,g.ClassName,
        g.LabelID,g.LabelName,g.BarCode,t.RQty,t.SQty,t.RetAmt,t.SelAmt,t.RebateAmt,t.PlatformFee,
        t.RealAmt,t.TotalAmt,t.SelPercent,t.RetPercent,t.R_SPercent,t.AvgPrice,
        CASE ISNULL(t.SelPercent,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(t.RetPercent,0.0)/t.SelPercent,6) END		
	FROM BAS_Goods_V g 
        INNER JOIN (SELECT ItemID,RQty,SQty,SelAmt,RetAmt,TotalAmt,RebateAmt,PlatformFee,
                        ISNULL(TotalAmt,0.0)-ISNULL(RebateAmt,0.0)-ISNULL(PlatformFee,0.0) AS RealAmt,
                        CASE ISNULL(@SUMAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(SelAmt,0.0)/@SUMAmt,6) END AS SelPercent,
                        CASE ISNULL(@SUMRAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(RetAmt,0.0)/@SUMRAmt,6) END AS RetPercent,
                        CASE ISNULL(SelAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(RetAmt,0.0)/SelAmt,6) END AS R_SPercent,
                        CASE ISNULL(SQty,0.0)-ISNULL(RQty,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND((ISNULL(SelAmt,0.0)-ISNULL(RetAmt,0.0))/(ISNULL(SQty,0.0)-ISNULL(RQty,0.0)),2) END AS AvgPrice 
                    FROM @Tmp) t ON t.ItemID=g.ItemID;
    DELETE FROM @Tmp;
	--返回
	RETURN;
END
go

