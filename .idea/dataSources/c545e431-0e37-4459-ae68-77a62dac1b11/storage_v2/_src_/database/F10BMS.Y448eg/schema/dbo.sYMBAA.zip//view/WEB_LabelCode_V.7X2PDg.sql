CREATE VIEW dbo.WEB_LabelCode_V
AS
SELECT CodeID, CodeNo, CHName, ENName, CheckBox, NameSpell
FROM dbo.BDM_Code
WHERE (Classify = 'FL09')
go

