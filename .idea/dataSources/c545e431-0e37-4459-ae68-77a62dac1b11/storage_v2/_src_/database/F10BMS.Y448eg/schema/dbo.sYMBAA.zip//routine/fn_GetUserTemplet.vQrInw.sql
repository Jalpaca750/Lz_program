
CREATE FUNCTION dbo.fn_GetUserTemplet
(
	@UserID BIGINT
)
RETURNS TABLE
AS
RETURN
(
    SELECT TplCode,TblCode,ViewOrder,FldCode,CtrlType,Alignment,DisplayColumn,BoundColumn,DSource,
        DField,DFilter,AllowEdit,AllowDisplay,IsNecessary,IsEditable,IsDisplay,ColWidth,ExcelFunc,Version
    FROM SYS_UserTemplet
    WHERE EmployeeID=@UserID
    UNION ALL
    SELECT TplCode,TblCode,ViewOrder,FldCode,CtrlType,Alignment,DisplayColumn,BoundColumn,DSource,
        DField,DFilter,AllowEdit,AllowDisplay,IsNecessary,IsEditable,IsDisplay,ColWidth,ExcelFunc,Version
    FROM SYS_Templet a
    WHERE NOT EXISTS(SELECT * FROM SYS_UserTemplet b WHERE a.TplCode=b.TplCode AND a.TblCode=b.TblCode AND a.FldCode=b.FldCode AND b.EmployeeID=@UserID)
)
go

