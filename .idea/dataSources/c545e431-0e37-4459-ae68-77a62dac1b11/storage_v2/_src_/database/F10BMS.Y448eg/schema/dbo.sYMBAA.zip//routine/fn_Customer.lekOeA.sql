CREATE FUNCTION fn_Customer(@IsLatency int)
RETURNS TABLE
AS
RETURN (SELECT a.CustID, a.CustNo, a.CustName, a.NameSpell, a.CustAddr, a.PostalCode, 
	      a.CustType, b.CHName AS TypeName, a.MemberID, c.CHName AS Member, 
	      a.AreaCode, d.CHName AS AreaName, a.PopedomID, e.CHName AS PopedomName, 
	      a.SalesID, f.EmployeeName AS Sales, a.DeptNo, g.CHName AS DeptName, a.Phone, 
	      a.Faxes, a.EMail, a.ADays, a.ADayFlag, a.CreditAmt, a.CreditFlag, a.SendID, 
	      a.SendFlag, a.PriceFlag, a.DiscRate, a.LinkMan, a.Defined1, a.Defined2, a.Defined3, 
	      a.Flag, a.Remarks, a.CheckBox
	FROM (SELECT CustID, CustNo, CustName, NameSpell, CustAddr, PostalCode, CustType, 
		      MemberID, AreaCode, PopedomID, SalesID, DeptNo, Phone, Faxes, EMail, ADays, 
		      ADayFlag, CreditAmt, CreditFlag, SendID, SendFlag, PriceFlag, DiscRate, LinkMan, 
		      Defined1, Defined2, Defined3, Flag, Remarks, CheckBox
		FROM dbo.BDM_Customer 
		Where Flag='1'
		Union All
		SELECT CustID, CustNo, CustName, NameSpell, CustAddr, PostalCode, CustType, 
		      MemberID, AreaCode, PopedomID, SalesID, DeptNo, Phone, Faxes, EMail, ADays, 
		      ADayFlag, CreditAmt, CreditFlag, SendID, SendFlag, PriceFlag, DiscRate, LinkMan, 
		      Defined1, Defined2, Defined3, Flag, Remarks, CheckBox
		FROM dbo.BDM_Cust_Latency 
		Where Flag='1' And @IsLatency=1) a LEFT OUTER JOIN
	      dbo.BDM_DeptCode_V g ON a.DeptNo = g.CodeID LEFT OUTER JOIN
	      dbo.BDM_PopedomCode_V e ON a.PopedomID = e.CodeID LEFT OUTER JOIN
	      dbo.BDM_AreaCode_V d ON a.AreaCode = d.CodeID LEFT OUTER JOIN
	      dbo.BDM_MemberCode_V c ON a.MemberID = c.CodeID LEFT OUTER JOIN
	      dbo.BDM_CustType_V b ON a.CustType = b.CodeID LEFT OUTER JOIN
	      dbo.BDM_Employee f ON a.SalesID = f.EmployeeID
)
go

