--说明：批号入库记录
--作者：wujinfeng
--创建：2008.07.18
--参数：
--	@BillType 处理批号类型

CREATE Function uf_JobNo_Out_Temp_V
(
	@BillType as varchar(2)
)
Returns @uTable Table
(
	SID 		bigint,
	ItemID 		bigint,
	ItemName	varchar(100),
	WareHouseID 	bigint,
	PHNo 		varchar(50),
	SNNo 		varchar(50),
	QTY 		decimal(18,6),
	BillType		varchar(2),
	BillNo		varchar(20),
	CreatorID 	bigint,
	JobNumberNo_In_SID 	bigint
)
As
Begin	
	declare @i bigint
	if isnull(@BillType,'')=''
	Return
	
	if @BillType='C1' or @BillType='R1_'
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,BillType,BillNo,CreatorID,JobNumberNo_In_SID)
	SELECT a.SID, a.ItemID,c.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,BillType, a.BillNo, a.CreatorID,JobNumberNo_In_SID	
		FROM dbo.JobNumberNo_Out_Temp a 
		INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
	end

	--返回
	return
end






go

