--说明：未发货订单分析
--作者：Devil.H
--创建：2010.05.31
--参数：
--	无
CREATE Function dbo.fn_AnalSMSA0() 
Returns Table
As
Return(
	Select a.OrderNo,a.CreateDate,a.CustID,c.CustNo,c.CustName,c.NameSpell As CustSepll,
		c.CustType,c.MemberID,c.AreaCode,c.PopedomID,a.DeptNo,d.CHName as DeptName,
		a.SalesID,es.EmployeeName As Sales,b.OrderID,b.ItemID,g.ItemNo,g.ItemName,
		g.ItemAlias,g.NameSpell As ItemSpell,g.BarCode,g.ItemSpec,g.ClassID,g.ClassName,
		g.LabelID,g.LabelName,g.ColorName,g.UnitName,g.PkgSpec,w.OnHandQty,b.PkgQty,b.OQty,
		b.Price,b.Amt,Isnull(b.OQty,0.0)-Isnull(b.SQty,0.0) As RemSQty,
                CASE ISNULL(g.PkgRatio,0) WHEN 0 THEN (ISNULL(b.OQty, 0) - ISNULL(b.SQty, 0)) 
                                          ELSE ROUND((ISNULL(b.OQty, 0) - ISNULL(b.SQty, 0))/g.PkgRatio,4) END AS RemPkgQty,
		Isnull(b.ZQty,0.0)-Isnull(b.SZQty,0.0) As RemZSQty,
		ISNULL(w.OnHandQty, 0) - ISNULL(b.OQty, 0) + ISNULL(b.SQty, 0) - ISNULL(b.ZQty, 0) + ISNULL(b.SZQty, 0) As YJQty,
		Isnull(a.SendDate,'')+Isnull(a.SendTime,'') As SendDate,f.CHName as SendMode,
		(Select StsName From BillStatus s Where a.BillSts=s.BillSts And s.BillType='SMS30') As StsName,
		a.DepartId,dt.CHName AS DepartName,a.LinkMan,a.Phone,g.PurLineName,
		a.SendAddr,a.SendID,a.SendFlag,a.CreatorID,ec.EmployeeName as Creator,a.Remarks
	From SMS_Order a Inner Join SMS_OrderDtl b On a.OrderNo=b.OrderNo
		         Inner Join BDM_Customer c On a.CustID=c.CustID
			 Inner Join BAS_Goods_V g On b.ItemID=g.ItemID
			 Left Outer Join BDM_Employee es On a.SalesID=es.EmployeeID
			 Left Outer Join BDM_Employee ec On a.CreatorID=ec.EmployeeID
			 Left Outer Join BDM_DeptCode_V d On a.DeptNo=d.CodeID
			 Left Outer Join IMS_Subdepot w On b.DeptNo=w.DeptNo And b.ItemID=w.ItemID
			 Left Outer Join BDM_SendMode_V f On a.SendID = f.CodeID 
			 Left Outer Join BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
	Where (a.BillSts='20' Or a.BillSts='25') And Isnull(b.OQty,0.0)-Isnull(b.SQty,0.0) >0.0
)
go

