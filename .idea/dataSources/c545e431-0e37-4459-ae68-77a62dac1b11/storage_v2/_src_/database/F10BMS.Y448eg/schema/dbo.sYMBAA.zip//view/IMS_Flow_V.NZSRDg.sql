


CREATE VIEW dbo.IMS_Flow_V
AS
SELECT a.FlowID,a.BillNo,a.CreateDate,a.BillType,a.AuditDate,a.DeptNo,d.CHName AS DeptName, 
    a.WareHouse, c.CHName AS WHName, a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, 
    b.ItemSpec, b.BarCode, b.MidBarcode,b.BigBarcode,b.PkgBarcode, b.ClassID,b.ClassName,  
    b.LabelID, b.LabelName, b.ColorName, b.UnitName, a.SQty, a.Price, a.Amt, 
    CASE ISNULL(b.PkgRatio,0.0) WHEN 0.0 THEN NULL ELSE ROUND(ISNULL(a.SQty,0.0)/b.PkgRatio,4) END AS PkgQty, 
    b.PkgSpec,a.DepartId,dt.CHName AS DepartName,a.CPrice,a.WmsBillNo,a.Memo,a.Remarks, a.CheckBox
FROM dbo.IMS_Flow a 
    INNER JOIN dbo.BDM_ItemInfo_V b ON a.ItemID = b.ItemID
    LEFT JOIN dbo.BDM_DeptCode_V d ON a.DeptNo = d.CodeID 
    LEFT JOIN dbo.BDM_WareHouse_V c ON a.WareHouse = c.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
go

