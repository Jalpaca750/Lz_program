--说明：业务员销售毛利统计
--作者：Devil.H
--创建：2008.03.20
--参数：
--	@Year:年度
--	@Month:自然月分
--	@CorpNo：公司
--	@DeptNo:部门
--	@Flag:前台标识
CREATE FUNCTION [dbo].[fn_AnalSMS7F]
(
	@Period VARCHAR(6),
	@StartDate VARCHAR(10),
	@EndDate VARCHAR(10),
	@CorpNo VARCHAR(2)='',
	@DeptNo VARCHAR(20)='',
	@WithGift INT=0,
	@Flag BIT=0
)
RETURNS @uTable TABLE(
	SalesID BIGINT,
	SalesNo VARCHAR(20),
	Sales VARCHAR(100),
	SQty DECIMAL(18,6),
	RebateAmt DECIMAL(18,6),            --返点
    PlatformFee DECIMAL(18,6),          --平台费  
	Amt DECIMAL(18,6),
    RealAmt DECIMAL(18,6),              --实际销售额
	CstAmt DECIMAL(18,6),
	GProAmt DECIMAL(18,6),
	GProfit DECIMAL(18,6),
	JHCstAmt DECIMAL(18,6), 	--参考成本
	JHGProAmt DECIMAL(18,6),	--参考毛利
	JHGProfit DECIMAL(18,6)		--参考毛利率
)
AS
BEGIN
	IF (@Flag=0) 
		RETURN;
	DECLARE @AmtDec INT,@STaxFlag BIT,@Year INT,@Month INT;
	--临时成本
	DECLARE @CostTmp Table(DeptNo VARCHAR(20),ItemID BIGINT,Price DECIMAL(18,10) Primary Key(DeptNo,ItemID));
	--定制成本
	DECLARE @Special Table(OrderID BIGINT,ItemID BIGINT,Price DECIMAL(18,10));
    --销售数据临时表
	DECLARE @Sales TABLE(RowID BIGINT Identity(1,1),DeptNo VARCHAR(20),ItemID BIGINT,SalesID BIGINT,SQty DECIMAL(18,6),Amt DECIMAL(18,6),CPrice DECIMAL(18,6),IsSpecial BIT,TaxFlag BIT,OrderID BIGINT,PlatfORmFee DECIMAL(10,6),Rebate DECIMAL(10,6),Taxrate DECIMAL(10,6) PRIMARY KEY(RowID));
	--初始化变量
	SELECT @AmtDec=ISNULL(AmtDec,2),@STaxFlag=ISNULL(STaxFlag,0) FROM Sys_CONfig;
	SET @AmtDec=ISNULL(@AmtDec,2);
	SET @Year=CAST(LEFT(@Period,4) AS INT);
	SET @Month=CAST(RIGHT(@Period,2) AS INT);
    --符合条件的销售数据到临时表 
	INSERT INTO @Sales(DeptNo,SalesID,ItemID,SQty,Amt,IsSpecial,TaxFlag,OrderID,PlatformFee,Rebate,TaxRate)
	SELECT a.DeptNo,ISNULL(a.SalesID,99),b.ItemID,CASE @Flag WHEN 1 THEN b.SQty ELSE ISNULL(b.SQty,0)+ISNULL(b.ZQty,0.0) END,
	    b.Amt,ISNULL(b.IsSpecial,0),ISNULL(b.TaxFlag,0),b.OrderID,ISNULL(c.PlatformFee,0.0),ISNULL(c.Rebate,0.0),
        ISNULL(d.Taxrate,16)
	FROM SMS_Stock a 
        INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo 
        INNER JOIN BDM_Customer c ON a.CustID=c.CustID
        INNER JOIN BDM_ItemInfo d ON b.ItemID=d.ItemID
	WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30') 
		AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
		AND (a.DeptNo LIKE @DeptNo + '%')
        AND (a.DeptNo IN(SELECT CodeID FROM BDM_DeptCode_V WHERE DeptNo LIKE @CorpNo + '%'));        
	IF NOT EXISTS(SELECT 1 FROM @Sales)
		RETURN;
    IF (@Flag=1)
		INSERT INTO @CostTmp(DeptNo,ItemID,Price)
		SELECT ISNULL(DeptNo,'$$$$'),ItemID,MEPrice
		FROM uf_CostPrice(@Period); 
	--临时成本(指定成本)
    IF (@Flag=2)
		INSERT INTO @CostTmp(DeptNo,ItemID,Price)
		SELECT DeptNo,ItemID,Price
		FROM CST_PlanPrice
		WHERE CstYear=@Year AND CstMonth=@Month; 
	--根据成本统计数据
	IF (@Flag=2) OR EXISTS(SELECT * FROM SYS_CONfig WHERE ISNULL(Method,'S')='S')
		UPDATE a SET a.CPrice=b.Price
		FROM @Sales a 
		    INNER JOIN @CostTmp b ON a.DeptNo=b.DeptNo And a.ItemID=b.ItemID;	
	Else
		UPDATE a SET a.CPrice=b.Price
		FROM @Sales a 
            INNER JOIN @CostTmp b ON b.DeptNo='$$$$' And a.ItemID=b.ItemID;
    --定制品入库单
    INSERT INTO @Special(OrderID,ItemID,Price)
	SELECT y.XS_OrderID,y.ItemID,y.Price 
    FROM PMS_Stock x 
        INNER JOIN PMS_StockDtl y ON x.StockNo=y.StockNo
    Where (x.BillSts='20' OR x.BillSts='30' OR x.BillSts='25') 
		AND EXISTS(SELECT * FROM @Sales t WHERE y.XS_OrderID=t.OrderID);
	--定制品成本	
	UPDATE a SET a.CPrice=b.Price 
	FROM @Sales a 
	    INNER JOIN @Special b ON a.OrderID=b.OrderID;
    --根据成本统计数据
	IF ISNULL(@STaxFlag,0)=1
		INSERT INTO @uTable(SalesID,SQty,RebateAmt,PlatformFee,Amt,CstAmt,GProAmt,JHCstAmt,JHGProAmt)
		SELECT SalesID,SUM(SQty),ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec) AS RebateAmt,
            ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec) AS PlatformFee,SUM(Amt) AS Amt,
            SUM(CstAmt),SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(CstAmt,0.0)),
			SUM(JHCstAmt),SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(JHCstAmt,0.0))
		FROM (
                SELECT a.SalesID,a.SQty,a.Amt,a.PlatformFee,a.Rebate,
				    ROUND(ISNULL(a.SQty,0.0)*(CASE a.TaxFlag WHEN 0 THEN ISNULL(a.CPrice,0.0) ELSE ISNULL(a.CPrice,0.0)/1.13 END),@AmtDec) As CstAmt,
				    ROUND(ISNULL(a.SQty,0.0)*(CASE a.TaxFlag WHEN 0 THEN ISNULL(jh.Cost,0.0) ELSE ISNULL(jh.Cost,0.0)/1.13 END),@AmtDec) As JHCstAmt
                FROM @Sales a 
                    LEFT JOIN CST_Colligate_COST_Year jh On jh.Period=@Period AND a.ItemID=jh.ItemID
            ) t
		GROUP BY SalesID;
	Else
		INSERT INTO @uTable(SalesID,SQty,RebateAmt,PlatformFee,Amt,CstAmt,GProAmt,JHCstAmt,JHGProAmt)
		SELECT SalesID,SUM(SQty),ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec) AS RebateAmt,
            ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec) AS PlatformFee,SUM(Amt) AS Amt,
            SUM(CstAmt) AS CstAmt,SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(CstAmt,0.0)) AS GProAmt,
			SUM(JHCstAmt) AS JHCstAmt,SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(JHCstAmt,0.0)) AS JHGProAmt
		FROM (
		        SELECT a.SalesID,a.SQty,a.Amt,a.PlatformFee,a.Rebate,
				    ROUND(ISNULL(a.SQty,0.0)*ISNULL(a.CPrice,0.0),@AmtDec) As CstAmt,
				    ROUND(ISNULL(a.SQty,0.0)*ISNULL(jh.Cost,0.0),@AmtDec) As JHCstAmt
			    FROM @Sales a 
				    LEFT JOIN CST_Colligate_COST_Year jh On jh.Period=@Period AND a.ItemID=jh.ItemID
            ) t
		GROUP BY SalesID;
	
	Update a Set a.SalesNo=b.EmployeeNo,a.Sales=b.EmployeeName,
        a.RealAmt=ISNULL(a.Amt,0.0)-ISNULL(a.RebateAmt,0.0)-ISNULL(a.PlatformFee,0.0),
		a.GProfit=CASE ISNULL(a.Amt,0.0) WHEN 0.0 THEN 0.0 
					       ELSE ROUND(ISNULL(a.GProAmt,0.0)/a.Amt,2*@AmtDec) END,
		a.JHGProfit=CASE ISNULL(a.Amt,0.0) WHEN 0.0 THEN 0.0 
						   ELSE ROUND(ISNULL(a.JHGProAmt,0.0)/a.Amt,2*@AmtDec) END
	FROM @uTable a 
        LEFT JOIN BDM_Employee b ON a.SalesID=b.EmployeeID;

    DELETE FROM @Sales;
	DELETE FROM @Special;
	DELETE FROM @CostTmp;
	--返回
	RETURN;
END
go

