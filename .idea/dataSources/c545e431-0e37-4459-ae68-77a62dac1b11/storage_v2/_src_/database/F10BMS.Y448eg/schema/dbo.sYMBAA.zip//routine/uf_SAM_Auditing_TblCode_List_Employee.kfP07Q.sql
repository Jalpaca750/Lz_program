--说明：当前能查看XX销售员/操作员/采购员的权限
--作者：Devil.H
--创建：2007.04.29
--参数：
--	@UserNo:	当前用户
CREATE Function dbo.uf_SAM_Auditing_TblCode_List_Employee
(
	@Employeeid bigint
)
Returns @uTable Table(
	TblCode varchar(10),
	TblName varchar(30),
	Flag varchar(20)
)
--with encryption
As
Begin	
	Insert Into @uTable(TblCode,TblName,Flag)
	Select Distinct A.TblCode,A.TblName,CASE isnull(B.TblCode, '') WHEN '' THEN '(未设置)' ELSE '(已设置)' END AS Flag
	FROM Sys_AuditParm A 
	Left join SAM_Auditing_Operator B on A.TblCode=B.TblCode and B.employeeid=@Employeeid where A.AuditingFlag='1'  And AutoCheck=0 Order By A.TblName

	Return
End








go

