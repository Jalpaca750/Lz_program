
CREATE VIEW dbo.PMS_OrderDtl_V
AS
SELECT a.OrderID, a.OrderNo, a.DeptNo, a.DeptNo_A, d.CreateDate, d.BillType, d.BillSts, 
    a.PlanID, a.PlanNo, a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, 
    b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, b.LabelID, b.LabelName, 
    b.ColorName, b.UnitName, ISNULL(c.PQty, 0.0) - ISNULL(c.OQty, 0.0) AS RemOQty, 
    b.PkgSpec, a.PkgQty, a.OQty, a.Price, a.Amt, a.TaxFlag, a.IsSpecial, a.XS_OrderID, 
    a.XS_OrderNo, a.SQty, ISNULL(a.OQty, 0.0) - ISNULL(a.SQty, 0.0) AS RemSQty, 
    ISNULL(a.OQty, 0.0) - ISNULL(a.DQty, 0.0) AS RemDQty, e.OnHandQty, e.AvailQty, 
    f.OnHandQty AS OnHandQty_A, f.AvailQty AS AvailQty_A, e.MaxStock, e.MinStock, 
    b.PPrice, b.SafePPrice, b.SPrice, b.SPrice1, b.SPrice2, b.SPrice3, b.BPackage, 
    b.MPackage, b.Package, b.PkgRatio, b.HotFlag, b.NotDisc, a.Remarks, a.CheckBox, 
    a.IsEffect,b.ItemPHFlag, b.ItemPHName, d.YZStockWareHouseID AS WareHouseID, 
    Y.QTY AS YZStockQty, a.BillID, a.BillNo, T.ExecQty, T.FH AS ContractFH, 
    a.OQty AS ConExportQty, a.XS_CustNo, a.XS_CustName,a.IsPromotion, 
    NULL AS Sales01,NULL AS Sales02,NULL AS Sales03,NULL AS Sales04,NULL AS OnwayQty
FROM dbo.PMS_OrderDtl a 
    INNER JOIN dbo.PMS_Order d ON a.OrderNo = d.OrderNo 
    INNER JOIN dbo.BAS_Goods_V b ON a.ItemID = b.ItemID 
    LEFT JOIN dbo.IMS_Store_V f ON a.DeptNo_A = f.DeptNo AND a.ItemID = f.ItemID
    LEFT JOIN dbo.IMS_Store_V e ON a.DeptNo = e.DeptNo AND a.ItemID = e.ItemID 
    LEFT JOIN dbo.PMS_PlanDtl c ON a.PlanID = c.PlanID 
    LEFT JOIN dbo.IMS_YZStock_Sum_DeptID_V Y ON a.DeptNo_A = Y.DeptNo AND a.ItemID = Y.ItemID 
    LEFT JOIN dbo.CON_PMSDtl_V T ON a.BillID = T.BillID
go

