-- =============================================
-- Author:		<Frank.He>
-- Create date: <2018-04-17>
-- Description:	<系统登陆用户保存后同步到WMS对应的表>
-- Parameter:   
--      @employeeId员工资料Id
-- =============================================
CREATE PROCEDURE [dbo].[sp_AfterUserSaved]
(
	@employeeId BIGINT
)
AS
BEGIN
	--接口变量
	DECLARE @companyId VARCHAR(32),
			@operatorId VARCHAR(32),
			@guid VARCHAR(32),
			@curTime DATETIME
	DECLARE @userPwd VARCHAR(100),
	        @userState INT,
	        @userType INT,
	        @regionId VARCHAR(32),
	        @isOnline INT;
	--获取接口公司、用户、网点资料
	SELECT TOP 1 @companyId=companyId,@regionId=siteId,@operatorId=IOperatorId FROM dbo.SYS_Config 
	SET @curTime=GETDATE();
	SET @userPwd='E10ADC3949BA59ABBE56E057F20F883E';        --初始密码:123456
	SET @userState=1;                                       
	SET @isonline=0;
	SET @userType=0
	--如果WMS接口未开启，直接退出
	IF NOT EXISTS(SELECT * FROM dbo.SYS_Config WHERE ISNULL(startWMS,0)=1)
	    RETURN
	SET @guid=LOWER(REPLACE(NEWID(),'-',''));
	--F10登陆用户同步到WMS
    INSERT INTO YiWms.dbo.SAM_User(userId,userNo,userNick,userPwd,userMail,userMobile,officeTel,
        userState,companyId,userType,regionId,isOnline,isLocked,lockerId,lockedTime,createTime,
        creatorId,editTime,editorId)
    SELECT @guid,EmployeeNo,EmployeeName,@userPwd,EMail,Phone,Phone,@userState,@companyId,@userType,
        @regionId,@isOnline,0,'',NULL,GETDATE(),@operatorId,GETDATE(),@operatorId
    FROM dbo.BDM_Employee a
    WHERE a.EmployeeID=@employeeId 
        AND NOT EXISTS(SELECT * FROM YiWms.dbo.SAM_User b WHERE a.EmployeeNo=b.userNo);
END
go

