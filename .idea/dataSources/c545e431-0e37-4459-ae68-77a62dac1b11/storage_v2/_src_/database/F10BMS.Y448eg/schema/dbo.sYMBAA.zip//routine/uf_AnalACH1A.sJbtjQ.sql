
--说明：销售员项目统计
--作者：Devil.H
--创建：2007.11.15
--参数：
--	@Period:年月
--	@Flag:标识
CREATE  function dbo.uf_AnalACH1A
(	
	@Period char(6)='200001',
	@Flag bit=0
)
Returns @uTable Table(
	Period char(6),
	SalesID bigint,
	Sales varchar(20),
	DeptNo varchar(20),
	DeptName varchar(40),
	OrdAmt decimal(18,6),
	OrdQty decimal(18,6),
	InvAmt decimal(18,6),
	InvQty decimal(18,6),
	CstAmt decimal(18,6),
	InvoiceAmt decimal(18,6),
	GProAmt decimal(18,6),
	GProfit decimal(18,6),
	PayAmt decimal(18,6),
	PAmt decimal(18,6),
	PCstAmt decimal(18,6),
	PGProAmt decimal(18,6),
	PGProfit decimal(18,6)
)
--with encryption
As
begin
	declare @Year int
	declare @Month int
	declare @AmtDec int
	if @Flag=0
		Return
	declare @Tmp Table(
		SalesID bigint,
		OrdAmt decimal(18,6),
		OrdQty decimal(18,6),
		InvAmt decimal(18,6),
		InvQty decimal(18,6),
		CstAmt decimal(18,6),
		InvoiceAmt decimal(18,6),
		GProAmt decimal(18,6),
		GProfit decimal(18,6),
		PayAmt decimal(18,6),
		PAmt decimal(18,6),
		PCstAmt decimal(18,6),
		PGProAmt decimal(18,6),
		LSMSAmt decimal(18,6))
	Select @AmtDec=AmtDec From Sys_Config
	--当前月起始、截至日期
	Set @Year=Cast(Left(@Period,4) as int)
	set @Month=Cast(right(@Period,2) as int)


	--********增加会计月份时间处理***********************
	declare @CW_Month_BDate char(10)
	declare @CW_Month_EDate char(10)

	Set @CW_Month_BDate=(select CW_Month from dbo.uf_Get_CW_Month(1,@Year,@Month))
	Set @CW_Month_EDate=(select CW_Month from dbo.uf_Get_CW_Month(2,@Year,@Month))
	--**********************************************

	--统计项目金额
	Insert Into @Tmp(SalesID,OrdAmt,InvAmt,CstAmt)
	Select a.SalesID,Sum(a.ProjectAmt) As OrdAmt,Sum(a.ProjectJSAmt) As InvAmt,Sum(a.CostAmtSum) As CstAmt
	From PRJ_Cost_V a 
	Where (a.BillSts Not In('00','10')) 
		--And Year(a.CreateDate)=@Year And Month(a.CreateDate)=@Month
		And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
	Group By a.SalesID



	--统计已收完款的发票金额
	Insert Into @Tmp(SalesID,InvoiceAmt,PayAmt)
	Select SalesID,Isnull(Sum(IAmt),0) As InvoiceAmt,Sum(PAmt) As PayAmt
	From SMS_Invoice_V
	Where BillSts Not In('00','10') 
		--And Year(PDate)=@Year And Month(PDate)=@Month
		And CreateDate Between @CW_Month_BDate And @CW_Month_EDate
		And Left(InvoiceNo,1)='#'
	Group By SalesID

	--汇总
	Insert Into @uTable(SalesID,OrdAmt,OrdQty,InvAmt,InvQty,CstAmt,               InvoiceAmt,GProAmt,PayAmt,PAmt,PCstAmt,PGProAmt)
	Select SalesID,Sum(OrdAmt),Sum(OrdQty),Sum(InvAmt),Sum(InvQty),Sum(CstAmt),   Sum(InvoiceAmt),  
		isnull(Sum(InvAmt),0)-isnull(Sum(CstAmt),0),Sum(PayAmt),Sum(PAmt),Sum(PCstAmt),
		Isnull(Sum(PAmt),0)-Isnull(Sum(PCstAmt),0)
	From @Tmp
	Group By SalesID
	--更新毛利、毛利率
	Update @uTable Set GProfit=case Isnull(InvAmt,0) 
				when 0 then 0 
				else Round((Isnull(InvAmt,0)-Isnull(CstAmt,0))/Isnull(InvAmt,0),@AmtDec*2) end,
			PGProfit=Case Isnull(PAmt,0)
				When 0 then 0
				else	Round((Isnull(PAmt,0)-Isnull(PCstAmt,0))/Isnull(PAmt,0),@AmtDec*2) End
	--更新销售员ming
	Update a Set a.Sales=b.EmployeeName,a.DeptNo=left(b.DeptCode,4)	From @uTable a,BDM_Employee b	Where a.SalesID=b.EmployeeID
	--更新销售员所在部门
	Update a Set a.DeptName=CHName	From @uTable a,BDM_DeptCode_V b	Where a.DeptNo=b.CodeID
	--返回
	Return
End

go

