--说明：未收票采购入库单分析
--作者：Devil.H
--创建：2007.11.23
--参数：
--	@Flag：标志
CREATE Function dbo.fn_AnalPMS5A
(
	@Flag bit=0
)
Returns Table
As
Return (SELECT b.StockID,a.StockNo,CASE a.BillType WHEN '10' THEN '入库单'
					   	   WHEN '20' THEN '退货单'
					   	   WHEN '30' THEN '调价单' END AS BillType,
		a.CreateDate,a.DeptNo,d.CHName AS DeptName,a.WareHouse,w.CHName AS WHName,a.VendorID,
		v.VendorNo,v.VendorName,v.NameSpell AS VendorSpell,v.BuyerID,v.Buyer,a.SendNo,
		b.Location,b.ItemID,g.ItemNo,g.ItemName,g.ItemAlias,g.NameSpell AS ItemSpell,
		g.ItemSpec,g.BarCode,g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,
		g.UnitName,g.PkgSpec,b.PkgQty,b.SQty,b.Price,b.Amt,ISNULL(b.SQty,0.0)-ISNULL(b.IQty,0.0) AS RemIQty,
		ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0) AS RemAmt,v.LinkMan,v.Phone,v.Faxes,
		a.CreatorID,e1.EmployeeName AS Creator,a.AuditID,e2.EmployeeName AS Auditer,
		a.BillSts,a.Remarks,(Select StsName 
				     From BillStatus s 
	                             Where a.BillSts=s.BillSts And s.BillType='PMS50') AS StsName
	FROM PMS_Stock a INNER JOIN PMS_StockDtl b ON a.StockNo=b.StockNo
		INNER JOIN BDM_ItemInfo_V g ON b.ItemID=g.ItemID
		INNER JOIN BDM_Vendor_V v ON a.VendorID=v.VendorID
		LEFT OUTER JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
		LEFT OUTER JOIN BDM_Employee e1 ON a.CreatorID=e1.EmployeeID
		LEFT OUTER JOIN BDM_Employee e2 ON a.AuditID=e2.EmployeeID
		LEFT OUTER JOIN BDM_WareHouse_V w ON a.WareHouse=w.CodeID
	WHERE (a.BillSts='20' Or a.BillSts='25') 
		And (ISNULL(b.SQty,0.0)-ISNULL(b.IQty,0.0)<>0.0 Or ISNULL(b.Amt,0.0)-ISNULL(b.IAmt,0.0)<>0.0)
)
go

