CREATE VIEW dbo.IMS_OtherDtl_V
AS
SELECT a.OtherID, a.OtherNo, d.DeptNo, d.CreateDate, d.BillSts, a.WareHouse, 
      ISNULL(f.Location, a.Location) AS Location, a.ItemID, b.ItemNo, b.ItemName, 
      b.ItemAlias, b.NameSpell, b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, 
      b.LabelID, b.LabelName, b.ColorName, b.UnitName, b.PkgSpec, a.PkgQty, a.SQty, 
      a.Price, a.Amt, f.OnHandQty, b.PPrice, b.SPrice, b.SPrice1, b.SPrice2, b.SPrice3, 
      b.BPackage, b.MPackage, b.Package, b.PkgRatio, a.CPrice,b.ItemPHFlag,b.ItemPHName, 
      d.CustID,a.YZStockQty,Y.Qty As YZQty,a.CheckBox,a.Remarks
FROM dbo.IMS_OtherDtl a LEFT OUTER JOIN
      dbo.BAS_Goods_V b ON a.ItemID = b.ItemID LEFT OUTER JOIN
      dbo.IMS_Other d ON a.OtherNo = d.OtherNo LEFT OUTER JOIN
      dbo.IMS_Ledger f ON a.WareHouse = f.WareHouse AND a.ItemID = f.ItemID Left Outer join 
      dbo.IMS_YZStock_Sum_WareHouse_Sum_V Y on a.ItemID=Y.ItemID And a.WareHouse=Y.WareHouseID
go

