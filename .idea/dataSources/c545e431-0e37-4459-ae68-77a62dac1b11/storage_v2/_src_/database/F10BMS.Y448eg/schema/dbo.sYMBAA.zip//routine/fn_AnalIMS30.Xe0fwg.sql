
--说明：其他入出库单统计分析
--作者：Devil.H
--创建：2010.08.03
--参数：
--	@DeptNo:部门
--	@WareHouse:仓库
--	@ClassID:商品大类
--	@LabelID:商品品牌
--	@ItemID:商品ID
--	@Flag:0-无需执行;1-加权平均;2-指定成本
CREATE FUNCTION dbo.fn_AnalIMS30
(
	@DeptNo VARCHAR(20),
	@WareHouse VARCHAR(20),
	@ClassID VARCHAR(20),
	@LabelID VARCHAR(20),
	@ItemID BIGINT,
	@Flag INT
)
RETURNS @uTable TABLE(
	DeptID VARCHAR(20),
	DeptNo VARCHAR(20),
	DeptName VARCHAR(100),
	WareHouse VARCHAR(20),
	WHName VARCHAR(100),
	OnHandQty DECIMAL(18,6),
	Amt DECIMAL(18,6),
	WAmt DECIMAL(18,6),
	IMSPercent DECIMAL(18,6),
	JHCstAmt DECIMAL(18,6)
	PRIMARY KEY(DeptID,WareHouse)
)
AS
BEGIN
	IF (@Flag=0) 
		RETURN;
    DECLARE @Period VARCHAR(6),@WAmt DECIMAL(18,6),@Year INT,@Month INT;
	DECLARE @CostTmp TABLE(DeptNo VARCHAR(20),ItemID BIGINT,Price DECIMAL(18,10) PRIMARY KEY(DeptNo,ItemID));
	DECLARE @StoreTmp TABLE(DeptNo VARCHAR(20),WareHouse VARCHAR(20),ItemID BIGINT,OnHandQty DECIMAL(18,6) PRIMARY KEY(DeptNo,WareHouse,ItemID));
	--会计期间
	SELECT @Period=CW_Period 
	FROM SYS_CW_MonthPeriod a
	WHERE EXISTS(SELECT * FROM SYS_GetDate_V b WHERE  b.Today BETWEEN a.StartDate AND a.EndDate);
    SET @Year=CAST(LEFT(@Period,4) AS INT);
	SET @Month=CAST(RIGHT(@Period,2) AS INT);
	--临时成本
    IF (@Flag=1)
    	INSERT INTO @CostTmp(DeptNo,ItemID,Price)
    	SELECT ISNULL(DeptNo,'$$$$'),ItemID,MEPrice
    	FROM uf_CostPrice(@Period) 
    IF (@Flag=2)
        INSERT INTO @CostTmp(DeptNo,ItemID,Price)
		SELECT DeptNo,ItemID,Price
		FROM CST_PlanPrice
		WHERE CstYear=@Year AND CstMonth=@Month; 
	--仓库数量
	INSERT INTO @StoreTmp(DeptNo,WareHouse,ItemID,OnHandQty)
	SELECT l.DeptNo,l.WareHouse,l.ItemID,l.OnHandQty
	FROM IMS_Ledger l
        INNER JOIN BDM_ItemInfo g ON l.ItemID=g.ItemID
	WHERE (l.WareHouse LIKE @WareHouse + '%')
		AND (l.DeptNo LIKE @DeptNo + '%')
		AND (@ItemID=0 OR l.ItemID=@ItemID)
		AND (ABS(ISNULL(l.OnHandQty,0.0))>0.0)
		AND (ISNULL(g.ClassID,'') LIKE @ClassID + '%')
		AND (ISNULL(g.LabelID,'') LIKE @LabelID + '%');
	--总体成本法
	IF EXISTS(SELECT * FROM SYS_Config WHERE ISNULL(Method,'S')='T')
		INSERT INTO @uTable(DeptID,DeptNo,DeptName,WareHouse,WHName,OnHandQty,Amt,JHCstAmt)
		SELECT d.CodeID,d.CodeNo,d.CHName,t.WareHouse,w.CHName As WHName,SUM(t.OnHandQty),SUM(t.Amt),SUM(t.JHAmt)
		FROM (SELECT l.DeptNo,l.WareHouse,l.ItemID,l.OnHandQty,
				  ISNULL(l.OnHandQty,0.0)*ISNULL(cb.Price,0.0) As Amt,
				  ISNULL(l.OnHandQty,0.0)*ISNULL(jh.Cost,0.0) AS JHAmt
              FROM @StoreTmp l 
                  LEFT JOIN @CostTmp cb ON cb.DeptNo='$$$$' AND l.ItemID=cb.ItemID
			      LEFT JOIN CST_Colligate_COST_Year jh ON l.ItemID=jh.ItemID AND jh.Period=@Period
             ) t
			LEFT JOIN BDM_DeptCode_V d ON t.DeptNo=d.CodeID
			LEFT JOIN BDM_WareHouse_V w ON t.WareHouse=w.CodeID
		GROUP BY d.CodeID,d.CodeNo,d.CHName,t.WareHouse,w.CHName
	Else
		INSERT INTO @uTable(DeptID,DeptNo,DeptName,WareHouse,WHName,OnHandQty,Amt,JHCstAmt)
		SELECT d.CodeID,d.CodeNo,d.CHName,t.WareHouse,w.CHName As WHName,
		       SUM(t.OnHandQty),SUM(t.Amt),SUM(t.JHAmt)
		FROM (SELECT l.DeptNo,l.WareHouse,l.ItemID,l.OnHandQty,
				  ISNULL(l.OnHandQty,0.0)*ISNULL(cb.Price,0.0) As Amt,
				  ISNULL(l.OnHandQty,0.0)*ISNULL(jh.Cost,0.0) AS JHAmt
              FROM @StoreTmp l 
                  LEFT JOIN @CostTmp cb ON cb.DeptNo=l.DeptNo AND l.ItemID=cb.ItemID
			      LEFT JOIN CST_Colligate_COST_Year jh ON l.ItemID=jh.ItemID AND jh.Period=@Period
             ) t
			LEFT JOIN BDM_DeptCode_V d ON t.DeptNo=d.CodeID
			LEFT JOIN BDM_WareHouse_V w ON t.WareHouse=w.CodeID
		GROUP BY d.CodeID,d.CodeNo,d.CHName,t.WareHouse,w.CHName
	--获取商品总金额
	SELECT @WAmt=SUM(Amt) FROM @uTable 	
	--更新库房总金额
	UPDATE @uTable SET WAmt=ISNULL(@WAmt,0.0),
                       IMSPercent=CASE ISNULL(@WAmt,0.0) WHEN 0.0 THEN 0.0  ELSE ROUND(ISNULL(Amt,0.0)/@WAmt,6) END;
    DELETE FROM @CostTmp;
    DELETE FROM @StoreTmp;
	--返回
	RETURN;
END
go

