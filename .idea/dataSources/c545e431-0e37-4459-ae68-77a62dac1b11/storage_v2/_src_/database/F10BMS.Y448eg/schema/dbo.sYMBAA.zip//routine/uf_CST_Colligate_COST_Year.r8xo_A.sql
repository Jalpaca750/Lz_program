CREATE function dbo.uf_CST_Colligate_COST_Year
(
	@Year char(4),
	@Flag bit
)
Returns @uTable Table(
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(80),
	ItemAlias varchar(80),
	NameSpell varchar(80),
	ItemSpec varchar(80),
	BarCode varchar(30),
	ClassID varchar(20),
	ClassName varchar(40),
	LabelID varchar(20),
	labelName varchar(40),
	ColorName varchar(40),
	UnitName varchar(40),
	CST01Price decimal(18,6),
	CST02Price decimal(18,6),
	CST03Price decimal(18,6),
	CST04Price decimal(18,6),
	CST05Price decimal(18,6),
	CST06Price decimal(18,6),
	CST07Price decimal(18,6),
	CST08Price decimal(18,6),
	CST09Price decimal(18,6),
	CST10Price decimal(18,6),
	CST11Price decimal(18,6),
	CST12Price decimal(18,6)
)
--with encryption
As
Begin
	if @Flag=0
		Return
	Insert Into @uTable(ItemID,ItemNo,ItemName,ItemAlias,NameSpell,ItemSpec,ClassName,
		LabelName,BarCode,ClassID,LabelID,ColorName,UnitName,CST01Price,CST02Price,CST03Price,CST04Price,
		CST05Price,CST06Price,CST07Price,CST08Price,CST09Price,CST10Price,CST11Price,CST12Price)
	Select ItemID,ItemNo,ItemName,ItemAlias,NameSpell,ItemSpec,ClassName,LabelName,
		BarCode,ClassID,LabelID,ColorName,UnitName,
		CST01Price=Sum(case Right(Period,2) when '01' then COST else 0 end),
		CST02Price=Sum(case Right(Period,2) when '02' then COST else 0 end),
		CST03Price=Sum(case Right(Period,2) when '03' then COST else 0 end),
		CST04Price=Sum(case Right(Period,2) when '04' then COST else 0 end),
		CST05Price=Sum(case Right(Period,2) when '05' then COST else 0 end),
		CST06Price=Sum(case Right(Period,2) when '06' then COST else 0 end),
		CST07Price=Sum(case Right(Period,2) when '07' then COST else 0 end),
		CST08Price=Sum(case Right(Period,2) when '08' then COST else 0 end),
		CST09Price=Sum(case Right(Period,2) when '09' then COST else 0 end),
		CST10Price=Sum(case Right(Period,2) when '10' then COST else 0 end),
		CST11Price=Sum(case Right(Period,2) when '11' then COST else 0 end),
		CST12Price=Sum(case Right(Period,2) when '12' then COST else 0 end)
	From CST_Colligate_COST_Year_V
	Where Left(Period,4)=@Year
	Group By ItemID,ItemNo,ItemName,ItemAlias,NameSpell,ItemSpec,
		BarCode,ClassID,LabelID,ColorName,UnitName,ClassName,LabelName
	--返回
	Return
End

go

