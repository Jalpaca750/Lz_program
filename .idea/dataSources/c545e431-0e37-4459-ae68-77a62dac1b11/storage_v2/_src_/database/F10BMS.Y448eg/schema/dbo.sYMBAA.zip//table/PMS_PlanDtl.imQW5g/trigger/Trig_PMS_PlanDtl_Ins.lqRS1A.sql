--采购计划单明细插入操作（Insert)
--2007-08-21
--Devil.H
--当上述操作发生时：
--更新定制订单的已执行计划采购数量
CREATE Trigger Trig_PMS_PlanDtl_Ins
On dbo.PMS_PlanDtl
For Insert
As
Begin
	Update a Set a.PQty=Isnull(a.PQty,0)+Isnull(b.PQty,0)
	From SMS_OrderDtl a,Inserted b
	Where a.OrderID=b.XS_OrderID
End
go

