--说明：未盘点完成的盘点单提醒
--作者：Devil.H
--创建：2010.03.24
--参数：
--	无
CREATE FUNCTION fn_Alert11
(
)
RETURNS TABLE
AS
RETURN (
    SELECT a.LotNo,a.CreateDate,a.CheckNo,w.CHName AS WHName,
		g.ItemNo,g.ItemName,g.ItemSpec,g.ColorName,g.UnitName,
		b.CurQty,b.SQty
	FROM IMS_Check a INNER JOIN IMS_CheckDtl b ON a.CheckNo=b.CheckNo
		INNER JOIN BDM_ItemInfo_V g ON b.ItemID=g.ItemID
		LEFT OUTER JOIN BDM_WareHouse_V w ON a.WareHouse=w.CodeID
	WHERE (a.BillSts='20' Or a.BillSts='10') 
		And Not Exists(SELECT 1 
				FROM IMS_Audit c 
				WHERE a.LotNo=c.LotNo And a.DeptNo=c.DeptNo 
					And a.WareHouse=c.WareHouse And c.Locked=1)
)
go

