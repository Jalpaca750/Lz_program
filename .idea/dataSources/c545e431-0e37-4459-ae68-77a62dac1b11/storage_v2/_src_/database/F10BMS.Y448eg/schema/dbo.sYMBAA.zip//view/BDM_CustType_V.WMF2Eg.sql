--客户类别
CREATE VIEW dbo.BDM_CustType_V
AS
SELECT CodeID, CodeNo, CHName, ENName, Flag,Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL03')
go

