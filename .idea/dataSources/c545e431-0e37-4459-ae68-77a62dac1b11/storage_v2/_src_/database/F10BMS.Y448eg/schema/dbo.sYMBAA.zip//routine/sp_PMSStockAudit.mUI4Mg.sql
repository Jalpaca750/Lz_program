CREATE PROC sp_PMSStockAudit
(
	@StockNo VARCHAR(20),
	@Flag CHAR(2)
)
AS
BEGIN
    DECLARE @OrderNo VARCHAR(20),
            @DeptNo VARCHAR(20),
            @WareHouse  VARCHAR(20),
            @ItemID  BIGINT,
            @StockID BIGINT,
            @CreateDate CHAR(10),
            @AuditDate CHAR(10),
            @Amt DECIMAL(18,6),
            @VendorID BIGINT,
            @UpPPrice BIT,
            @PriceDec INT,
            @CreatorId BIGINT,
            @remarks VARCHAR(2000),
            @errors BIGINT;
    DECLARE @ErrMsg VARCHAR(4000),@ErrSeverity INT;
	--更新参考进价
	SELECT @UpPPrice=ISNULL(UpPPrice,1),@PriceDec=ISNULL(PriceDec,2) FROM Sys_Config;
	--当前入库单
	SELECT @VendorID=VendorID,@CreateDate=CreateDate,@AuditDate=CONVERT(VARCHAR(10),GETDATE(),23),
        @DeptNo=DeptNo,@WareHouse=WareHouse,@CreatorId=CreatorId,@remarks=Remarks
    FROM PMS_Stock 
    WHERE StockNo=@StockNo;
	--总金额
	SELECT @Amt=SUM(Amt) FROM PMS_StockDtl WHERE StockNo=@StockNo;
	--创建临时表
	CREATE TABLE #Tmp(DeptNo VARCHAR(20),WareHouse VARCHAR(20),ItemID BIGINT,SQty DECIMAL(18,6),Amt DECIMAL(18,6));
	
	SET @errors=0;
	BEGIN TRANSACTION;
    --排队等待
    WHILE EXISTS(SELECT * FROM dbo.SAM_Schedule WHERE jobCode='inv_posting_job' AND IsLocked=1)
    BEGIN
        SET @errors=0;
    END
    UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='sp_PMSStockAudit' WHERE jobCode='inv_posting_job';

	--写入临时表(服务不记库存)
	INSERT INTO #Tmp(DeptNo,WareHouse,ItemID,SQty,Amt)
	SELECT @DeptNo,@WareHouse,a.ItemID,SUM(a.SQty),SUM(Amt)
	FROM PMS_StockDtl a
	    INNER JOIN BDM_ItemInfo b ON a.ItemID=b.ItemID
	WHERE a.StockNo=@StockNo
	    AND ISNULL(b.IsVirtual,0)=0
	GROUP BY a.ItemID;
	SET @errors=@errors+@@ERROR;
	--审核通过
	IF (@Flag='20')
	BEGIN
		--写入供应商欠款
		UPDATE BDM_Vendor SET ArgAmt=ISNULL(ArgAmt,0.0)+ISNULL(@Amt,0.0) WHERE VendorID=@VendorID;
		SET @errors=@errors+@@ERROR;
		--写入流水帐中		
	    INSERT INTO IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,CreateDate,AuditDate,wmsBillNo,memo,remarks)
	    SELECT a.StockNo,'采购入库单',@DeptNo,@WareHouse,a.ItemID,a.SQty,a.Price,a.Amt,@CreateDate,@AuditDate,@StockNo,a.Remarks,@remarks
	    FROM PMS_StockDtl a
            INNER JOIN BDM_ItemInfo b ON a.ItemId=b.ItemId
	    WHERE StockNo=@StockNo AND b.IsVirtual=0
        SET @errors=@errors+@@ERROR;
		--更新商品资料文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM BDM_ItemInfo a
		    INNER JOIN #Tmp b ON a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;		
		--更新分部商品资料文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM IMS_Subdepot a 
		    INNER JOIN #Tmp b ON a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;
		INSERT INTO IMS_Subdepot(DeptNo,ItemID,OnHandQty)
		SELECT DeptNo,ItemID,SQty
		FROM #Tmp a
		WHERE NOT EXISTS(SELECT 1 FROM IMS_Subdepot b WHERE a.DeptNo=b.DeptNo And a.ItemID=b.ItemID);
		SET @errors=@errors+@@ERROR;
		--写入库房总帐(移动加权平均价计算）
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0),a.LastTime=GETDATE(),
                     a.LastIDate=CONVERT(VARCHAR(10),GETDATE(),23),
                     a.CstPrice=CASE ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0) WHEN 0.0 THEN a.CstPrice ELSE (a.OnhandQty*a.CstPrice+b.Amt)/(ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)) END
		FROM IMS_Ledger a 
		    INNER JOIN #Tmp b ON a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;     
		INSERT INTO IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastTime,LastIDate,CstPrice)
		SELECT DeptNo,WareHouse,ItemID,SQty,GETDATE(),CONVERT(VARCHAR(10),GETDATE(),23),Amt/SQty
		FROM #Tmp a
		WHERE NOT EXISTS(SELECT 1 FROM IMS_Ledger b WHERE a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID);
		SET @errors=@errors+@@ERROR;
		
		--入库相关信息
		DECLARE myCursor CURSOR
		FOR SELECT StockID,ItemID FROM PMS_StockDtl WHERE StockNo=@StockNo ORDER BY StockID;
		OPEN myCursor;
		FETCH NEXT FROM myCursor INTO @StockID,@ItemID;
		WHILE @@FETCH_STATUS=0
		BEGIN
			IF (ISNULL(@UpPPrice,1)=1)--更新商品参考进价
			BEGIN
				UPDATE a SET a.PPrice=CASE ISNULL(b.TaxFlag,0) WHEN 0 THEN b.Price ELSE ROUND(b.Price*1.13,@PriceDec) END 
				FROM BDM_ItemInfo a 
				    INNER JOIN PMS_StockDtl b ON a.ItemID=b.ItemID
				WHERE b.StockID=@StockID 
				    AND ISNULL(b.IsEffect,1)=1 
				    AND ISNULL(b.IsSpecial,0)=0 
				    AND ISNULL(b.IsPromotion,0)=0;
				SET @errors=@errors+@@ERROR;
	        END
			--更新最近进价,默认供应商进价
			UPDATE a SET a.PPrice=CASE ISNULL(b.TaxFlag,0) WHEN 0 THEN b.Price ELSE ROUND(b.Price*1.13,2) END,
				         a.Price=CASE ISNULL(a.VendorID,'') WHEN ISNULL(@VendorID,'') THEN b.Price ELSE a.Price END 
			FROM IMS_Subdepot a
			    INNER JOIN PMS_StockDtl b ON a.DeptNo=@DeptNo AND a.ItemID=b.ItemID
			WHERE b.StockID=@StockID 
			    AND ISNULL(b.IsEffect,1)=1 
			    AND ISNULL(b.IsSpecial,0)=0 
			    AND ISNULL(b.IsPromotion,0)=0;
		    SET @errors=@errors+@@ERROR;
		    --当前库房总帐中不存在该条商品记录
			UPDATE a SET a.LastIDate=@CreateDate,a.LastIPrice=b.Price,
			    a.Location=CASE ISNULL(b.Location,'') WHEN '' THEN a.Location ELSE b.Location END
			FROM IMS_Ledger a
			    INNER JOIN PMS_StockDtl b ON a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID
			WHERE b.StockID=@StockID;
			SET @errors=@errors+@@ERROR;				
			--更新进价
			IF EXISTS(SELECT 1 FROM PMS_Price WHERE DeptNo=@DeptNo AND VendorID=@VendorID AND ItemID=@ItemID)
				UPDATE a SET a.Price=b.Price,a.TaxFlag=ISNULL(b.TaxFlag,0),LastDate=@CreateDate
				FROM PMS_Price a 
				    INNER JOIN PMS_StockDtl b ON a.DeptNo=@DeptNo AND a.VendorID=@VendorID AND a.ItemID=b.ItemID
				WHERE b.StockID=@StockID 
					AND ISNULL(b.Price,0.0)>0.0 
					AND ISNULL(b.IsEffect,1)=1 
					AND ISNULL(b.IsSpecial,0)=0 
					AND ISNULL(b.IsPromotion,0)=0;
			ELSE
				INSERT INTO PMS_Price(VendorID,ItemID,Price,TaxFlag,DeptNo,LastDate)
				SELECT @VendorID,ItemID,Price,ISNULL(TaxFlag,0),@DeptNo,@CreateDate
				FROM PMS_StockDtl
				WHERE StockID=@StockID 
				    AND ISNULL(Price,0.0)>0.0 
					AND ISNULL(IsEffect,1)=1 
					AND ISNULL(IsSpecial,0)=0 
					AND ISNULL(IsPromotion,0)=0;
		    SET @errors=@errors+@@ERROR;			
			FETCH NEXT FROM myCursor INTO @StockID,@ItemID; 		
		END
		CLOSE myCursor;
		DEALLOCATE myCursor;
	END
	--取消审核
	ELSE IF (@Flag='10')
	BEGIN
		--写入供应商欠款
		UPDATE BDM_Vendor SET ArgAmt=ISNULL(ArgAmt,0.0)-ISNULL(@Amt,0.0) WHERE VendorID=@VendorID;
		SET @errors=@errors+@@ERROR;
		--删除流水帐中的记录
		DELETE FROM IMS_Flow WHERE BillNo=@StockNo;
		SET @errors=@errors+@@ERROR;
		--更新商品资料文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
		FROM BDM_ItemInfo a 
		    INNER JOIN #Tmp b ON a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;
		--更新分部商品资料文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
		FROM IMS_Subdepot a 
		    INNER JOIN #Tmp b ON a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR; 	
		--更新库房文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0),a.LastTime=GETDATE()
		FROM IMS_Ledger a 
		    INNER JOIN #Tmp b ON a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;
	END 
	--作废
	ELSE IF (@Flag='00')
	BEGIN
		--更新订单的已入库数量
		UPDATE a SET a.SQty=ISNULL(a.SQty,0.0)-ISNULL(b.SQty,0.0)
		FROM PMS_OrderDtl a 
		    INNER JOIN PMS_StockDtl b On a.OrderID=b.OrderID 
		WHERE b.StockNo=@StockNo;
		SET @errors=@errors+@@ERROR;
		--计划单
		DECLARE myCursor CURSOR
		FOR SELECT DISTINCT OrderNo 
		    FROM PMS_StockDtl 
		    WHERE StockNo=@StockNo;
		OPEN myCursor;
		FETCH NEXT FROM myCursor INTO @OrderNo;
		WHILE @@FETCH_STATUS=0
		BEGIN
			--不存在已入库数量的记录
			IF NOT EXISTS(SELECT 1 FROM PMS_OrderDtl WHERE OrderNo=@OrderNo AND ISNULL(SQty,0.0)>0.0)
				UPDATE PMS_Order SET BillSts='20' WHERE OrderNo=@OrderNo AND BillSts<>'05';
			ELSE
				UPDATE PMS_Order SET BillSts='25' WHERE OrderNo=@OrderNo AND BillSts<>'05';
		    SET @errors=@errors+@@ERROR;
			FETCH NEXT FROM myCursor INTO @OrderNo;
		END
		CLOSE myCursor;
		DEALLOCATE myCursor;
	END
	UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='inv_posting_job';
    SET @errors=@errors+@@ERROR;
	--错误处理
	IF (@errors=0)
	BEGIN
	    COMMIT;
	END
	ELSE
	BEGIN
	    IF @@TRANCOUNT > 0
			 ROLLBACK;
		SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;	
        UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='inv_posting_job';
		--写入同步错误日志	
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),'01',GETDATE(),'99','sp_PMSStockAudit','PMS_STOCK_AUIDT_ERROR',LEFT(@ErrMsg,2000),@StockNo,@StockNo);
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END	
END
go

