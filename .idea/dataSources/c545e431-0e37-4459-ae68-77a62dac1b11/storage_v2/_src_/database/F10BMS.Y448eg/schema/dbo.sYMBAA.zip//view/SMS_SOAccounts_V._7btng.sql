CREATE VIEW dbo.SMS_SOAccounts_V
AS
SELECT a.StockNo, a.CreateDate, a.DeptNo, d .CHName AS DeptName, a.WareHouse,w.CHName AS WHName,  
    a.CustID, c.CustNo, c.CustName, a.LinkMan, a.Phone, c.Faxes,a.BillType,c.IDays,dtl.Amt,
    dtl.RemIAmt, a.SendAddr, a.SendDate, a.SendTime, m.CHName AS SendMode, a.PaidAmt, a.DiscAmt, 
    a.PaidDate, a.BackDate, a.PFlag, a.SalesID, e.EmployeeName AS SalesName,a.PoNo,
    (SELECT StsName FROM BillStatus s WHERE s.BillType = 'SMS40' AND s.BillSts = a.BillSts) AS StsName, 
    c.CustType, c.TypeName, c.AreaCode, c.AreaName, c.PopedomID, c.PopedomName, c.MemberID, c.Member, 
    a.CreatorID, o.EmployeeName AS Creator, a.AuditID, u.EmployeeName AS Auditer, a.OrderRenInfo, a.CostsID,
    (SELECT CHName FROM Web_Costs_Class cb WHERE a.CostsID = cb.CostsID) AS CostsName,a.SignName,
    a.Remarks,'原单' AS BTName,a.DepartId,dt.CHName AS DepartName
FROM SMS_Stock a 
    LEFT JOIN BDM_DeptCode_V d ON a.DeptNo = d .CodeID 
    INNER JOIN BAS_Customer_V c ON a.CustID = c.CustID 
    LEFT JOIN BDM_WareHouse_V w ON a.WareHouse = w.CodeID 
    LEFT JOIN BDM_SendMode_V m ON a.SendID = m.CodeID 
    LEFT JOIN BDM_Employee e ON a.SalesID = e.EmployeeID 
    LEFT JOIN BDM_Employee o ON a.CreatorID = o.EmployeeID 
    LEFT JOIN BDM_Employee u ON a.AuditID = u.EmployeeID 
    LEFT JOIN (SELECT StockNo,SUM(Amt) AS Amt,SUM(Isnull(Amt,0.0)-Isnull(IAmt,0.0)) AS RemIAmt
                FROM SMS_StockDtl
                GROUP BY StockNo) dtl On a.StockNo=dtl.StockNo 
    LEFT JOIN BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
WHERE (a.BillSts = '20' OR a.BillSts = '25') 
    AND (a.SMSAStockFlag = '0') 
    AND (Isnull(dtl.RemIAmt,0.0)<>0.0)
UNION ALL
SELECT a.StockNo, a.CreateDate, a.DeptNo, d .CHName AS DeptName, a.WareHouse, w.CHName AS WHName, 
    a.CustID, c.CustNo, c.CustName, c.LinkMan, c.Phone, c.Faxes,'70' As BillType,c.IDays,dtl.Amt, 
    dtl.RemIAmt,a.SendAddr, a.SendDate, a.SendTime, m.CHName AS SendMode, a.PaidAmt, a.DiscAmt, 
    a.PaidDate, a.BackDate, a.PFlag, a.SalesID, e.EmployeeName AS SalesName,a.PoNo,
    (SELECT StsName FROM BillStatus s WHERE s.BillType = 'SMS4A' AND s.BillSts = a.BillSts) AS StsName, 
    c.CustType, c.TypeName, c.AreaCode, c.AreaName, c.PopedomID, c.PopedomName, c.MemberID,c.Member,  
    a.CreatorID, o.EmployeeName AS Creator, a.AuditID, u.EmployeeName AS Auditer, a.OrderRenInfo, a.CostsID,
    (SELECT CHName FROM Web_Costs_Class cb WHERE a.CostsID = cb.CostsID) AS CostsName,Null As SignName,
    a.Remarks,'A单' As BTName,a.DepartId,dt.CHName AS DepartName
FROM SMS_AStock a 
    LEFT JOIN BDM_DeptCode_V d ON a.DeptNo = d .CodeID 
    INNER JOIN BAS_Customer_V c ON a.CustID = c.CustID 
    LEFT JOIN BDM_WareHouse_V w ON a.WareHouse = w.CodeID 
    LEFT JOIN BDM_SendMode_V m ON a.SendID = m.CodeID 
    LEFT JOIN BDM_Employee e ON a.SalesID = e.EmployeeID 
    LEFT JOIN BDM_Employee o ON a.CreatorID = o.EmployeeID 
    LEFT JOIN BDM_Employee u ON a.AuditID = u.EmployeeID 
    LEFT JOIN(SELECT StockNo,SUM(Amt) AS Amt,SUM(Isnull(Amt,0.0)-Isnull(IAmt,0.0)) AS RemIAmt
                FROM SMS_AStockDtl
                GROUP BY StockNo) dtl On a.StockNo=dtl.StockNo 
    LEFT JOIN BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
WHERE (a.BillSts = '20' OR a.BillSts = '25')
go

