CREATE VIEW dbo.IMS_Ledger_V
AS
SELECT a.WareHouse, c.CHName AS WHName, c.DeptNo, a.Location, a.ItemID, b.ItemNo, 
      b.ItemName, b.ItemAlias, b.NameSpell, b.ItemSpec, b.BarCode, b.ClassID, 
      b.ClassName, b.LabelID, b.LabelName, b.ColorName, b.UnitName, a.OnHandQty, 
      a.AvailQty, a.Price, a.Amt, b.TaxRate, a.LastIDate, a.LastIPrice, a.LastODate, b.PkgSpec,
      Case Isnull(b.PkgRatio,0) When 0 then Null else Round(Isnull(a.OnHandQty,0)/Isnull(b.PkgRatio,0),4) End as PkgQty,
      b.BPackage,b.MPackage,b.Package,a.LastOPrice, a.FirstIDate,Y.Qty As YZStockQty
,ZCB.COST As ItemCOST
FROM dbo.IMS_Ledger a 
INNER JOIN      dbo.BDM_ItemInfo_V b ON a.ItemID = b.ItemID 
LEFT OUTER JOIN      dbo.BDM_WareHouse_V c ON a.WareHouse = c.CodeID
Left Outer join IMS_YZStock_Sum_WareHouse_Sum_V Y on a.ItemID=Y.ItemID And a.WareHouse=Y.WareHouseID
LEFT OUTER JOIN      dbo.CST_Colligate_COST_LstMonth_V  Zcb ON a.ItemID = Zcb.ItemID



go

