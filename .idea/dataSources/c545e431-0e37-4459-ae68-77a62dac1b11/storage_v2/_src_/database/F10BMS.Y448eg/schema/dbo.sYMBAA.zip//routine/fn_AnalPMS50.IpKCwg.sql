--说明：采购未入库订单分析
--作者：Devil.H
--创建：2007.11.23
--参数：
--	@Year:年分
--	@Month：月份
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:标识
CREATE Function fn_AnalPMS50
(
	@DeptNo varchar(20)
)
Returns table
As
Return(
	SELECT b.OrderID,a.OrderNo,a.CreateDate,a.SendDate,a.DeptNo,d.CHName AS DeptName,
		b.ItemID,g.ItemNo,g.ItemName,g.ItemAlias,g.BarCode,g.NameSpell,g.ItemSpec,
		g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,g.UnitName,b.OQty,
		Isnull(b.OQty,0.0)-Isnull(b.SQty,0.0) AS RemSQty,v.VendorNo,v.VendorName,
		a.CreatorID,e.EmployeeName AS Creator,a.BillSts,a.Remarks,g.PkgSpec,b.PkgQty,
		(SELECT StsName FROM BillStatus s WHERE s.BillSts=a.BillSts And s.BillType='PMS40')  AS StsName
	FROM PMS_Order a INNER JOIN PMS_OrderDtl b ON a.OrderNo=b.OrderNo
		INNER JOIN BDM_Vendor_V v ON a.VendorID=v.VendorID
		INNER JOIN BDM_ItemInfo_V g On b.ItemID=g.ItemID
		LEFT OUTER JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
		LEFT OUTER JOIN BDM_Employee_V e ON a.CreatorID=e.EmployeeID
	WHERE (a.BillSts='10' Or a.BillSts='20' Or a.BillSts='25') 
		And (a.DeptNo like @DeptNo + '%')
		And a.BillType='采购订单' And Isnull(b.OQty,0.0)-Isnull(b.SQty,0.0)>0.0
)
go

