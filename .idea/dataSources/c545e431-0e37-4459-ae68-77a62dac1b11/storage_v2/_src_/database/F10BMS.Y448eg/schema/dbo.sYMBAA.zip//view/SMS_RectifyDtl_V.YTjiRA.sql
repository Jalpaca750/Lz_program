CREATE VIEW dbo.SMS_RectifyDtl_V
AS
SELECT a.RectifyID, a.RectifyNo, e.CreateDate, e.BillSts, a.StockID, a.StockNo, 
      b.WareHouse, a.ItemID, c.ItemNo, c.ItemName, c.ItemAlias, c.NameSpell, c.ItemSpec, 
      c.BarCode, c.ClassID, c.ClassName, c.LabelID, c.LabelName, c.ColorName, 
      c.UnitName, a.RemRQty, a.MQty, a.Price, a.MPrice, a.Amt, a.TaxFlag, c.PPrice,
      cb.CHName As CostsName,a.IsSafeAuditing,a.IsSafeAuditResult,a.IsSafeAuditEmployeeID,
      SA.EmployeeName As IsSafeAuditEmployee,c.SPrice, c.SPrice1, c.SPrice2, c.SPrice3, 
      c.SafeSPrice, a.Remarks, a.CheckBox
FROM dbo.SMS_RectifyDtl a LEFT OUTER JOIN
      dbo.BAS_Goods_V c ON a.ItemID = c.ItemID LEFT OUTER JOIN
      dbo.SMS_Rectify e ON a.RectifyNo = e.RectifyNo LEFT OUTER JOIN
      dbo.SMS_StockDtl b ON a.StockID = b.StockID LEFT OUTER JOIN  
      dbo.Web_Costs_Class cb ON e.CostsID = cb.CostsID LEFT OUTER JOIN      
      dbo.BDM_Employee SA ON a.IsSafeAuditEmployeeID = SA.EmployeeID
go

