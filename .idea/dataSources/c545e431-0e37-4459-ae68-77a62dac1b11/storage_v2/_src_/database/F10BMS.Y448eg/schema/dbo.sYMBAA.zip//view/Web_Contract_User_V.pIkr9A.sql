CREATE VIEW dbo.Web_Contract_User_V
AS
SELECT a.CustID, b.CustName, a.WebName, a.WebCHName, a.WebPassword, a.KJMM, 
      a.CheckMan, a.IsPower, CASE isnull(a.NeedCheck, '0') 
      WHEN '0' THEN '无需控制' WHEN '1' THEN '金额控制' WHEN '2' THEN '普通控制' END AS
       CheckCtrl, a.NeedCheck, a.Flag, CASE ISNULL(a.Flag, '0') 
      WHEN '0' THEN '禁用' ELSE '有效' END AS FlagName
FROM dbo.Web_Contract_User a INNER JOIN
      dbo.BDM_Customer b ON a.CustID = b.CustID
go

