CREATE VIEW dbo.IMS_CheckDtl_V
AS
SELECT a.CheckID, a.CheckNo, d.CreateDate, d.DeptNo, a.LotNo, d.BillSts, a.WareHouse, 
	ISNULL(f.Location, a.Location) AS Location, a.ItemID, b.ItemNo, b.ItemName, 
	b.ItemAlias, b.NameSpell, b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, 
	b.LabelID, b.LabelName, b.ColorName, b.UnitName, a.CurQty, a.SQty,a.SPrice, 
	ISNULL(a.CurQty,0.0) - ISNULL(a.SQty,0.0) AS DifQty,b.PkgSpec,a.PkgQty, 
	a.Price, a.Amt, a.PkgShow, b.BPackage, b.MPackage, b.Package, 
	CASE ISNULL(a.PkgRatio,0.0) WHEN 0.0 THEN b.PkgRatio ELSE a.PkgRatio END AS PkgRatio,
	b.Defined1,b.Defined2,b.Defined3,b.Defined4,b.Defined5,a.Remarks, a.CheckBox
FROM dbo.IMS_CheckDtl a LEFT OUTER JOIN
	dbo.BAS_Goods_V b ON a.ItemID = b.ItemID LEFT OUTER JOIN
	dbo.IMS_Check d ON a.CheckNo = d.CheckNo LEFT OUTER JOIN
	dbo.IMS_Ledger f ON a.WareHouse = f.WareHouse AND a.ItemID = f.ItemID
go

