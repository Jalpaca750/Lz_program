CREATE proc sp_Integral_Clear_Recount(@CreatorID bigint,@ClearDate char(10),@CustID bigint)
As
Begin
	declare @Integral decimal(18,6)
	declare @SJInteg decimal(18,6)
	declare @Deduct decimal(18,6)
	declare @LastDeductl decimal(18,6)

	declare @IntegralTemp decimal(18,6)
	declare @IsSYSIntegral as bit
	--系统积分启用标识
	Select @IsSYSIntegral=isnull(IsSYSIntegral,0) From Sys_Config

			if Isnull(@IsSYSIntegral,0)=1
				Begin
				Update a Set a.Integralbk=b.Integral From BDM_Customer a,BDM_Customer_V b where a.CustID=b.CustID And a.CustID=@CustID
				--Update a Set a.Integralbk=a.Integral From BDM_Customer_V a where a.CustID=@CustID

				Update BDM_Customer Set Integral=0,Deduct=0,SJInteg=0,qlInteg=0,zj_ql_CreatorID=@CreatorID,zj_ql_Date=@ClearDate Where CustID=@CustID
				
				--预计累计积分
				--出库		
				Select @Integral=0
				select @IntegralTemp=0
				Select @IntegralTemp=Sum(Isnull(a.SQty,0)*isnull(a.DtlIntegral,0)) From SMS_StockDtl_V a,BDM_Customer_V b,SMS_StockDtl C
					Where A.CustID=B.CustID And A.StockID=C.StockID 
					And a.CustID=@CustID And Isnull(a.SQty,0)>0 And A.BillSts not in ('00','10')
					And convert(varchar(10),C.CreateDate,120)>convert(varchar(10),b.zj_ql_Date,120)
				Select @Integral=@Integral+isnull(@IntegralTemp,0)
				--Update BDM_Customer Set Integral=isnull(@Integral,0) Where CustID=@CustID and isnull(IsIntegral,1)=1
				--退货
				Select @IntegralTemp=Sum(Isnull(a.RQty,0)*isnull(a.DtlIntegral,0)) From SMS_ReturnDtl_V a,BDM_Customer_V b ,SMS_ReturnDtl C
					Where  A.CustID=B.CustID   And A.ReturnID=C.ReturnID 
					And a.CustID=@CustID  And A.BillSts not in ('00','10')
					And convert(varchar(10),C.CreateDate,120)>convert(varchar(10),b.zj_ql_Date,120)
				Select @Integral=@Integral-isnull(@IntegralTemp,0)
				Update BDM_Customer Set Integral=isnull(@Integral,0) Where CustID=@CustID and isnull(IsIntegral,1)=1
				--Update BDM_Customer Set Integral=isnull(Integral,0)-isnull(@Integral,0) Where CustID=@CustID and isnull(IsIntegral,1)=1

				
				--收款累计积分
				--出库单直接收现
				Select @Integral=0
				select @IntegralTemp=0
				Select @IntegralTemp=Sum(Isnull(a.SQty,0)*isnull(a.DtlIntegral,0)) From SMS_StockDtl_V a,BDM_Customer_V b,SMS_StockDtl C
					Where A.BillSts not in ('00','10') 
					And Isnull(a.PaidAmt,0)>0 
					And A.CustID=B.CustID  And A.StockID=C.StockID 
					And A.CustID=@CustID
					And convert(varchar(10),C.CreateDate,120)>convert(varchar(10),B.zj_ql_Date,120)	
				Select @Integral=isnull(@IntegralTemp,0)
				--Update BDM_Customer Set SJInteg=Isnull(SJInteg,0)+Isnull(@Integral,0) Where CustID=@CustID And isnull(IsIntegral,1)=1

				/*	Select @Integral=Sum(Isnull(a.IQty,0)*isnull(a.DtlIntegral,0)) 
					From SMS_InvoiceDtl_V a,SMS_PaymentDtl b,BDM_Customer_V C ,SMS_Invoice d 
					Where  a.InvoiceNo=d.InvoiceNo And d.InvoiceID=b.InvoiceID And a.BillSts='30'
					And A.CustID=C.CustID And A.CustID=@CustID And convert(varchar(10),a.CreateDate,120)>convert(varchar(10),C.zj_ql_Date,120)	*/
				--正常清零日期后的收款累计积分
				select @IntegralTemp=0
				Select @IntegralTemp=Sum(Isnull(a.IQty,0)*isnull(a.DtlIntegral,0)) 
					From SMS_InvoiceDtl_V a,BDM_Customer_V C,SMS_InvoiceDtl d
					Where a.BillSts='30'   And a.PaymentUnAuditingFlag='1'
					And Isnull(a.PaidAmt,0)=0 --And a.Iqty>0 
					And A.CustID=C.CustID  And A.InvoiceID=d.InvoiceID  
					And A.CustID=@CustID
					And convert(varchar(10),d.CreateDate,120)>convert(varchar(10),C.zj_ql_Date,120)	
				--更表收款累计积分
				Select @Integral=@Integral+isnull(@IntegralTemp,0)
				--Update BDM_Customer Set SJInteg=Isnull(SJInteg,0)+Isnull(@Integral,0) Where CustID=@CustID And isnull(IsIntegral,1)=1


				--退货收现
				select @IntegralTemp=0
				Select @IntegralTemp=Sum(Isnull(a.RQty,0)*isnull(a.DtlIntegral,0)) From SMS_ReturnDtl_V a,BDM_Customer_V b ,SMS_ReturnDtl C,SMS_Return_V d
					Where  A.CustID=B.CustID   And A.ReturnID=C.ReturnID 
					And a.ReturnNo=d.ReturnNo And isnull(D.PaidAmt,0)<>0
					And a.CustID=@CustID  And A.BillSts not in ('00','10')
					And convert(varchar(10),c.CreateDate,120)>convert(varchar(10),b.zj_ql_Date,120)
				Select @Integral=@Integral-isnull(@IntegralTemp,0)
				--Update BDM_Customer Set SJInteg=isnull(SJInteg,0)-isnull(@Integral,0) Where CustID=@CustID and isnull(IsIntegral,1)=1


				--计算发票累计金额（应收金额）为零情况，处理发票金额=已收款金额情况，需要计算积分，否则收不了款，积分处理不了
				select @IntegralTemp=0
				select @IntegralTemp=Sum(Isnull(a.IQty,0)*isnull(a.Integral,0))
					From SMS_InvoiceDtl a,BDM_Customer_V C ,SMS_Invoice d
					Where a.InvoiceNo=d.InvoiceNo And d.BillSts='20' And Isnull(d.IAmt,0)=Isnull(d.PAmt,0)
					And Isnull(a.PaidAmt,0)=0 --And a.Iqty>0 
					And D.CustID=C.CustID 
					And D.CustID=@CustID
					And convert(varchar(10),a.CreateDate,120)>convert(varchar(10),C.zj_ql_Date,120)
				Select @Integral=@Integral+isnull(@IntegralTemp,0)
				Update BDM_Customer Set SJInteg=Isnull(@Integral,0) Where CustID=@CustID And isnull(IsIntegral,1)=1
				--Update BDM_Customer Set SJInteg=isnull(SJInteg,0)+isnull(@Integral,0) Where CustID=@CustID and isnull(IsIntegral,1)=1

				
				--重新计算已用分
				--Integral  累计可用积分
				--SJInteg  收款积分
				--Deduct  累计已用积分
				select @Integral=Integralbk,@SJInteg=SJInteg,@Deduct=Deduct from BDM_Customer_V where  CustID=@CustID
				
				if isnull(@Integral,0)>isnull(@SJInteg,0) or isnull(@Integral,0)=isnull(@SJInteg,0) 
					set @LastDeductl=0
				else
					set @LastDeductl=isnull(@SJInteg,0)-isnull(@Integral,0)
				Update BDM_Customer Set Deduct=@LastDeductl Where CustID=@CustID
				End
End
go

