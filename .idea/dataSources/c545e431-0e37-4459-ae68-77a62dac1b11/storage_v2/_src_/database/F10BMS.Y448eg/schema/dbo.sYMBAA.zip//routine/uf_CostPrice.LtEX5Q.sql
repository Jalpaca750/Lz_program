
--说明：计算月末加权平均价
--作者：Devil.H
--创建：2007.11.04
--参数：@Period:会计月份
--Frank.He 2018-05-03 采购不开票加税计成本改为1.16
--         2018-09-30 增加采购返点是否扣除成本
CREATE FUNCTION dbo.uf_CostPrice
(
	@Period CHAR(6)
)
RETURNs @uTable TABLE(
	Period CHAR(6),
	DeptNo	VARCHAR(20),
	ItemID BIGINT,
	MSQty DECIMAL(18,6),
	MSPrice DECIMAL(18,6),
	MSAmt DECIMAL(18,6),
	MIQty DECIMAL(18,6),
	MIAmt DECIMAL(18,6),
	MEPrice DECIMAL(18,6)
)
AS
BEGIN
	DECLARE @Year INT,				    --年
            @MONth INT,				    --月
	        @OPeriod CHAR(6),			--上一个会计期
	        @SPeriod CHAR(6),			--起始会计月
	        @Method CHAR(1),
	        @IsPur BIT,
	        @IsZPRK BIT,
	        @IsDBRK BIT,
	        @IsZZRK BIT,
	        @IsCXRK BIT,
	        @IsQTRK BIT,
	        @CTaxFlag BIT;
    --创建临时表
	DECLARE @Tmp1 TABLE(DeptNo VARCHAR(20),ItemID BIGINT,SQty DECIMAL(18,6),Amt DECIMAL(18,6));
	DECLARE @Tmp2 TABLE(DeptNo VARCHAR(20),ItemID BIGINT,MSQty DECIMAL(18,6),MSPrice DECIMAL(18,6),MSAmt DECIMAL(18,6),MIQty DECIMAL(18,6),MIAmt DECIMAL(18,6),MEPrice DECIMAL(18,6));
	DECLARE @Tmp3 Table(DeptNo VARCHAR(20),ItemID BIGINT,RectifyID BIGINT,Price DECIMAL(18,6));
    --会计期起始与截至日期
    DECLARE @StartDate VARCHAR(10),@EndDate VARCHAR(10);
    SELECT @StartDate=StartDate,@EndDate=EndDate FROM Sys_Period WHERE Period=@Period;
    --起始会计月
	IF (@SPeriod>@Period) 
		RETURN;
    
    --获取当前成本核算方式
	--建帐套日期
	SELECT @SPeriod=LEFT(CONVERT(CHAR(8),CAST(BuildDate AS DATETIME),112),6),
		    @Method=ISNULL(Method,'T'),@IsPur=ISNULL(IsPur,1),@IsZPRK=ISNULL(IsZPRK,1),@CTaxFlag=ISNULL(CTaxFlag,0),
		    @IsDBRK=ISNULL(IsDBRK,1),@IsZZRK=ISNULL(IsZZRK,1),@IsCXRK=ISNULL(IsCXRK,1),@IsQTRK=ISNULL(IsQTRK,1)
	FROM Sys_CONfig;
	
	--判断是否进行封帐处理
	IF EXISTS(SELECT * FROM Sys_Period WHERE ISNULL(SealFlag,0)=1 And Period=@Period)
		INSERT INTO @uTable(Period,DeptNo,ItemID,MSQty,MSPrice,MSAmt,MEPrice)
		SELECT Period,DeptNo,ItemID,MSQty,MSPrice,MSAmt,MEPrice
		FROM Cst_Price
		WHERE Period=@Period;
	ELSE
		BEGIN
			--获取前一个会计期
			SET @OPeriod=LEFT(CONVERT(CHAR(8),DATEADD(mm,-1,CAST(@Period+'01' AS DATETIME)),112),6)	
			--本期所有入库数量（采购入库（包含退货、调价）＋调拨入库＋其他入库＋赠品入库）
			IF (ISNULL(@IsPur,1)=1)--含采购入库/退货/调价）
			BEGIN
				IF (ISNULL(@CTaxFlag,0)=1)
					INSERT INTO @Tmp1(DeptNo,ItemID,SQty,Amt)
					SELECT a.DeptNo,b.ItemID,SUM(b.SQty) AS SQty,
						SUM(CASE ISNULL(b.TaxFlag,0) WHEN 0 THEN b.Amt*(100-ISNULL(c.Rebate,0.0))/100.0 
                                                     ELSE ISNULL(b.Amt,0)*1.13*(100-ISNULL(c.Rebate,0.0))/100.0 END) AS Amt 
					FROM PMS_Stock a 
                        INNER JOIN PMS_StockDtl b ON a.StockNo=b.StockNo
                        INNER JOIN BDM_VENDor c ON a.VENDorID=c.VENDorID
					WHERE (a.BillSts IN('20','25','30')) 
                        AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
						AND (ISNULL(b.IsSpecial,0)=0) 
					GROUP BY a.DeptNo,b.ItemID
				ELSE
					INSERT INTO @Tmp1(DeptNo,ItemID,SQty,Amt)
					SELECT a.DeptNo,b.ItemID,SUM(b.SQty) AS SQty,SUM(ISNULL(b.Amt,0.0)*(100-ISNULL(c.Rebate,0.0))/100.0) AS Amt 
					FROM PMS_Stock a 
                        INNER JOIN PMS_StockDtl b ON a.StockNo=b.StockNo
                        INNER JOIN BDM_VENDor c ON a.VENDorID=c.VENDorID
					WHERE (a.BillSts IN('20','25','30'))  
                        AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
						AND (ISNULL(b.IsSpecial,0)=0) 
					GROUP BY a.DeptNo,b.ItemID
			END
			IF (ISNULL(@IsQTRK,1)=1)--其他入库单
				INSERT INTO @Tmp1(DeptNo,ItemID,SQty,Amt)
				SELECT a.DeptNo,b.ItemID,SUM(b.SQty) AS SQty,SUM(b.Amt) AS Amt 
				FROM IMS_Other a 
                    INNER JOIN IMS_OtherDtl b ON a.OtherNo=b.OtherNo
				WHERE (a.BillType='10') 
                    AND (a.BillSts='20')
					AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
				GROUP BY a.DeptNo,b.ItemID
				UNION ALL
				SELECT a.DeptNo,b.ItemID,SUM(b.SQty) AS SQty,SUM(b.Amt) AS Amt 
				FROM IMS_Other a 
                    INNER JOIN IMS_OtherDtl b ON a.OtherNo=b.OtherNo
				WHERE (a.BillType='60') 
                    AND (a.BillSts='20')
					AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
				GROUP BY a.DeptNo,b.ItemID
			IF (ISNULL(@IsZPRK,1)=1)--赠品入库单
				INSERT INTO @Tmp1(DeptNo,ItemID,SQty,Amt)
				SELECT a.DeptNo,b.ItemID,SUM(b.SQty) AS SQty,SUM(b.Amt) AS Amt 
				FROM IMS_Present a 
                    INNER JOIN IMS_PresentDtl b ON a.PresentNo=b.PresentNo
				WHERE (a.BillType='10')
                    AND (a.BillSts='20')
					AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
				GROUP BY a.DeptNo,b.ItemID
			IF (ISNULL(@IsZZRK,1)=1)--组装入库单
				INSERT INTO @Tmp1(DeptNo,ItemID,SQty,Amt)
				SELECT DeptNo,ItemID,SUM(IQty) AS IQty,SUM(Amt) AS Amt 
				FROM IMS_Assembly
				WHERE (BillSts='20')
                    AND (CreateDate BETWEEN @StartDate AND @EndDate)
				GROUP BY DeptNo,ItemID
			IF (ISNULL(@IsCXRK,1)=1)--拆卸入库单
				INSERT INTO @Tmp1(DeptNo,ItemID,SQty,Amt)
				SELECT a.DeptNo,b.ItemID,SUM(b.IQty) AS SQty,SUM(b.Amt) AS Amt 
				FROM IMS_Split a 
                    INNER JOIN IMS_SplitDtl b ON a.SplitNo=b.SplitNo
				WHERE (a.BillSts='20') 
                    AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
				GROUP BY a.DeptNo,b.ItemID
			--库存调价价差
			INSERT INTO @Tmp1(DeptNo,ItemID,SQty,Amt)
			SELECT a.DeptNo,b.ItemID,0,SUM(Amt)
			FROM IMS_Rectify a 
                INNER JOIN IMS_RectifyDtl b ON a.RectifyNo=b.RectifyNo
			WHERE (a.BillSts='20') 
                AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
			GROUP BY a.DeptNo,b.ItemID
			--分部成本发
			IF (@Method='S')
				BEGIN
					IF (ISNULL(@IsDBRK,1)=1)--调拨入库单
						INSERT INTO @Tmp1(DeptNo,ItemID,SQty,Amt)
						SELECT a.DeptNo,b.ItemID,SUM(b.IQty) AS SQty,SUM(b.Amt) AS Amt
						FROM IMS_Incept a 
                            INNER JOIN IMS_InceptDtl b ON a.InceptNo=b.InceptNo
						WHERE (a.BillSts='20') 
                            AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
						GROUP BY a.DeptNo,b.ItemID
					--插入分部商品
					INSERT INTO @Tmp2(DeptNo,ItemID,MSQty,MSPrice,MSAmt,MIQty,MIAmt,MEPrice)
					SELECT DeptNo,ItemID,0,0,0,0,0,0
					FROM IMS_Subdepot
					UNION ALL--插入期初
					SELECT DeptNo,ItemID,MEQty,MEPrice,MEAmt,0,0,0
					FROM CST_Price 
					WHERE Period=@OPeriod
					--合计本期入库数量、金额
					INSERT INTO @Tmp2(DeptNo,ItemID,MSQty,MSPrice,MSAmt,MIQty,MIAmt,MEPrice)
					SELECT DeptNo,ItemID,0,0,0,SUM(SQty),SUM(Amt),0
					FROM @Tmp1
					GROUP BY DeptNo,ItemID
					--删除@Tmp1
					DELETE FROM @Tmp1
					--更新本期入库数量、金额
					INSERT INTO @uTable(Period,DeptNo,ItemID,MSQty,MSPrice,MSAmt,MIQty,MIAmt)
					SELECT @Period,DeptNo,ItemID,SUM(MSQty),SUM(MSPrice),SUM(MSAmt),SUM(MIQty),SUM(MIAmt)
					FROM @Tmp2
					GROUP BY DeptNo,ItemID
					--删除@Tmp2
					DELETE FROM @Tmp2
					--更新成本单价
					UPDATE @uTable SET MEPrice=CASE ISNULL(MSQty,0)+ISNULL(MIQty,0) WHEN 0 THEN 0
						                                                            ELSE ROUND((ISNULL(MSAmt,0)+ISNULL(MIAmt,0))/(ISNULL(MSQty,0)+ISNULL(MIQty,0)),6) END
					--获取最后一次库存调价单价
					INSERT INTO @Tmp3(DeptNo,ItemID,RectifyID)
					SELECT a.DeptNo,b.ItemID,MAX(b.RectifyID)
					FROM IMS_Rectify a 
                        INNER JOIN IMS_RectifyDtl b ON a.RectifyNo=b.RectifyNo
					WHERE (a.BillSts='20') 
                        AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
					GROUP BY a.DeptNo,b.ItemID
					UPDATE a SET a.Price=b.MPrice
					FROM @Tmp3 a,IMS_RectifyDtl b
					WHERE a.RectifyID=b.RectifyID
					--更新单价
					UPDATE a SET a.MEPrice=b.Price 
					FROM @uTable a,@Tmp3 b
					WHERE a.ItemID=b.ItemID AND ISNULL(a.MEPrice,0)<=0
					--更新成本单价为零的为上期成本
					UPDATE @uTable SET MEPrice=MSPrice WHERE ISNULL(MEPrice,0)<=0
					--更新成本单价为零的为参考进价
					UPDATE a SET a.MEPrice=ISNULL(b.PPrice,0)
					FROM @uTable a,BDM_ItemInfo b
					WHERE a.ItemID=b.ItemID AND ISNULL(a.MEPrice,0)<=0
				END	
			IF (@Method='T')
				BEGIN
					INSERT INTO @Tmp2(ItemID,MSQty,MSPrice,MSAmt,MIQty,MIAmt,MEPrice)
					SELECT ItemID,0,0,0,0,0,0
					FROM BDM_ItemInfo
					UNION ALL--插入期初
					SELECT ItemID,MEQty,MEPrice,MEAmt,0,0,0
					FROM CST_Price 
					WHERE Period=@OPeriod
					--合计本期入库数量、金额
					INSERT INTO @Tmp2(ItemID,MSQty,MSPrice,MSAmt,MIQty,MIAmt,MEPrice)
					SELECT ItemID,0,0,0,SUM(SQty),SUM(Amt),0
					FROM @Tmp1
					GROUP BY ItemID
					--删除@Tmp1
					DELETE FROM @Tmp1
					--更新本期入库数量、金额
					INSERT INTO @uTable(Period,ItemID,MSQty,MSPrice,MSAmt,MIQty,MIAmt)
					SELECT @Period,ItemID,SUM(MSQty),SUM(MSPrice),SUM(MSAmt),SUM(MIQty),SUM(MIAmt)
					FROM @Tmp2
					GROUP BY ItemID
					--删除@Tmp2
					DELETE FROM @Tmp2
					--更新成本单价
					UPDATE @uTable SET MEPrice=CASE ISNULL(MSQty,0)+ISNULL(MIQty,0) WHEN 0 THEN 0
						                                                            ELSE round((ISNULL(MSAmt,0)+ISNULL(MIAmt,0))/(ISNULL(MSQty,0)+ISNULL(MIQty,0)),6) END
					--获取最后一次库存调价单价
					INSERT INTO @Tmp3(ItemID,RectifyID)
					SELECT b.ItemID,MAX(b.RectifyID)
					FROM IMS_Rectify a 
                        INNER JOIN IMS_RectifyDtl b ON a.RectifyNo=b.RectifyNo
					WHERE (a.BillSts='20') 
                        AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
					GROUP BY b.ItemID
					UPDATE a SET a.Price=b.MPrice
					FROM @Tmp3 a INNER JOIN IMS_RectifyDtl b ON a.RectifyID=b.RectifyID
					--更新单价
					UPDATE a SET a.MEPrice=b.Price 
					FROM @uTable a,@Tmp3 b
					WHERE a.ItemID=b.ItemID AND ISNULL(a.MEPrice,0)<=0
					--更新成本单价为零的为上期成本
					UPDATE @uTable SET MEPrice=MSPrice WHERE ISNULL(MEPrice,0)<=0
					--更新成本单价为零的为参考进价
					UPDATE a SET a.MEPrice=ISNULL(b.PPrice,0)
					FROM @uTable a,BDM_ItemInfo b
					WHERE a.ItemID=b.ItemID AND ISNULL(a.MEPrice,0)<=0
				END
		END
    DELETE FROM @Tmp1;
    DELETE FROM @Tmp2;
    DELETE FROM @Tmp3;
	RETURN;	--返回
END
go

