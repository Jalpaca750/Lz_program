--说明：调整高低储备
--作者：Devil.H
--创建：2005.03.22
--参数：
--	@Month:汇总月份数据
--	@Coefficient:稳定系数
--参与运算：
--当前月起的设定月销售出库数据
--计算公式：
--	稳定系数=(Month1+Month2+…+MonthN)^/N/(Month1^+Month2^+…+MonthN^)
--	最高储备=(Month1+Month2+…+MonthN)/N*30*Days(最大储备天数)
CREATE Proc sp_ComputeHeightHive
(
	@Coefficient decimal(18,6),
	@DeptNo varchar(20),
	@TblName varchar(10)=''
)	
As
Begin
	set nocount on
	declare @Days bigint
	declare @StartDate char(10)
	declare @EndDate char(10)
	declare @SQL varchar(2000)
	--获取起始日期，截止日期
	Set @StartDate=Left(Convert(char(10),dateadd(mm,-3,GetDate()),120),7) + '-01'
	Set @EndDate=Left(Convert(char(10),dateadd(mm,-1,GetDate()),120),7) + '-31'
	--临时表	
	create table #Tmp(DeptNo varchar(20),
			  ItemID bigint,
			  TotalQty decimal(18,6),
			  Qty01 decimal(18,6),
			  Qty02 decimal(18,6),
			  Qty03 decimal(18,6),
			  Rate decimal(18,6),
			  Diff12 decimal(18,6)
			  Primary Key(DeptNo,ItemID))
	Create Table #SalesTmp(DeptNo varchar(20),
			       	ItemID bigint,
				CreateDate varchar(10),
				DiffMonth int,
				SQty decimal(18,6))
	--获取近三个月的销售数据
	INSERT INTO #SalesTmp(DeptNo,ItemID,CreateDate,DiffMonth,SQty)
	SELECT a.DeptNo,b.ItemID,a.CreateDate,DATEDIFF(m,a.CreateDate,(Select SysDate From Getsystemdate_V)) As DiffMonth,b.SQty
	FROM dbo.SMS_Stock a INNER JOIN dbo.SMS_StockDtl b ON a.StockNo=b.StockNo
	WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		AND (a.CreateDate Between @StartDate And @EndDate)
		AND (a.DeptNo=@DeptNo)
	Insert Into #Tmp(DeptNo,ItemID,Qty01,Qty02,Qty03,TotalQty)
	SELECT DeptNo,ItemID,
		SUM(CASE DiffMonth WHEN 1 THEN SQty ELSE 0.0 END) AS Qty01,
		SUM(CASE DiffMonth WHEN 2 THEN SQty ELSE 0.0 END) AS Qty02,
		SUM(CASE DiffMonth WHEN 3 THEN SQty ELSE 0.0 END) AS Qty03,
		SUM(SQty) AS TotalQty
	FROM #SalesTmp
	GROUP BY DeptNo,ItemID
	--获取天数
	Select @Days=Count(1)
	From (Select CreateDate,Count(1) as iCount From #SalesTmp Group By CreateDate) t
	--更新总量
	Update #Tmp Set TotalQty=Case When Isnull(TotalQty,0.0)<0.0 Then 0.0 Else Isnull(TotalQty,0.0) End,
			Diff12=Isnull(Qty01,0.0) - Isnull(Qty02,0.0)
	--计算稳定系数
	Update #Tmp Set Rate=Case (Square(Case When Isnull(Qty01,0.0)<0.0 Then 0.0 Else Isnull(Qty01,0.0) End) + Square(Case When Isnull(Qty02,0.0)<0.0 Then 0.0 Else isnull(Qty02,0.0) End) + Square(Case When isnull(Qty03,0.0)<0.0 Then 0.0 Else isnull(Qty03,0.0) End)) 
				When 0.0 Then 0.0 
				Else Square(Isnull(TotalQty,0.0))/3/(Square(Case When Isnull(Qty01,0.0)<0.0 Then 0.0 Else Isnull(Qty01,0.0) End) + Square(Case When Isnull(Qty02,0.0)<0.0 Then 0.0 Else isnull(Qty02,0.0) End) + Square(Case When isnull(Qty03,0.0)<0.0 Then 0.0 Else isnull(Qty03,0.0) End)) End
	--稳定系数
	Update a Set a.Stability = Isnull(b.Rate,0.0)
	From IMS_Subdepot a Inner Join #Tmp b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
	--选择稳定系数大于等于给定的稳定系数的商品
	Update a Set a.MaxStock=cast(isnull(a.MaxHive,10)*isnull(b.TotalQty,0)/@Days as bigint),
		     a.MinStock=cast(isnull(a.MinHive,3)*isnull(b.TotalQty,0)/@Days as bigint)
	From IMS_Subdepot a Inner Join #Tmp b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
	Where a.Stability-@Coefficient >= 0.0 And a.Stability < 1.0
	--稳定系数小于给定的商品
	Update a Set a.MaxStock=0.0,a.MinStock=0.0
	From IMS_Subdepot a Inner Join #Tmp b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
	Where a.Stability-@Coefficient < 0.0 And (Isnull(b.Diff12,0.0)<0.0 Or (Isnull(Qty01,0.0)=0.0 And isnull(Qty02,0.0)=0.0))
	if isnull(@TblName,'')<>''
		begin
			set @SQL='Select a.ItemID,a.ItemNo,a.ItemName,b.Qty01,b.Qty02,b.Qty03,a.MaxHive,'
			set @SQL=@SQL +'a.MinHive,a.SafetyDays,a.MaxStock,a.MinStock,a.Stability,'
			set @SQL=@SQL+'a.ClassID,a.LabelID  Into ' + @TblName +' From IMS_Subdepot_V '
			set @SQL=@SQL+'a inner join #Tmp b on a.ItemID=b.ItemID Where a.DeptNo=''' +@DeptNo +''''
			exec (@SQL)
		End
	--删除临时表
	Drop Table #Tmp
	Drop Table #SalesTmp
End
go

