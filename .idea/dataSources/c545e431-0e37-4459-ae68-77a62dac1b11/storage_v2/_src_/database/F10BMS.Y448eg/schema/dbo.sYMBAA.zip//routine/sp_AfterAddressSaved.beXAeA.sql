CREATE PROCEDURE [dbo].[sp_AfterAddressSaved]
(
	@CustID BIGINT,
	@receiverAddress VARCHAR(100)
)
AS
BEGIN	
	DECLARE @partnerId VARCHAR(32),			--客户Id
			@companyId VARCHAR(32),			--公司Id
			@ownerId VARCHAR(32),			--业主Id
			@operatorId VARCHAR(32),		--操作员Id	
			@curTime DATETIME,				--当前日期
			@partnerType INT;				--类型
	--送货地址
	DECLARE @CustNo VARCHAR(32),			--客户编码		
			@addressId VARCHAR(32),			--送货地址Id
			@receiverName VARCHAR(40),		--收货人
			@receiverTel VARCHAR(100),		--联系电话
			@isDefault INT,					--默认地址
			@lineCode VARCHAR(32),			--线路代码
			@LineID VARCHAR(32),			--线路Id
			@viewOrder INT,					--送货序号
			@postFee DECIMAL(20,10),		--运费
            @errors BIGINT;

    --如果WMS接口未开启，直接退出
	IF NOT EXISTS(SELECT * FROM dbo.SYS_Config WHERE ISNULL(startWMS,0)=1)
	    RETURN;
    SELECT TOP 1 @companyId=companyId,@operatorId=IOperatorId,@ownerId=OwnerId FROM dbo.SYS_Config;
	SET @curTime=GETDATE();
	SET @partnerType=1;
    SET @errors=0;
	--获取客户编号
	SELECT @CustNo=CustNo FROM dbo.BDM_Customer WHERE CustID=@CustID;
	--获取客户送货地址
	SELECT @receiverName=LinkMan,@receiverTel=Phone,@isDefault=DefAddr,@lineCode=LineID,@viewOrder=viewOrder,@postFee=0.0
	FROM dbo.BDM_SendAddress
	WHERE CustID=@CustID AND SendAddr=@receiverAddress;
	
	BEGIN TRANSACTION
	--客户编码
	IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Partner WHERE companyId=@companyId AND partnerType=@partnerType AND ownerId=@ownerId AND partnerNo=@custNo)
	BEGIN
		INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterAddressSaved','YI_ADDRESS_SYNC_ERROR',
			'客户资料尚未同步，客户地址同步失败',@CustID,@CustNo);
        SET @errors=@errors+@@ERROR;
	END	    
	ELSE
	BEGIN
		--取得WMS客户ID
		SELECT @partnerId=partnerId 
		FROM YiWms.dbo.BAS_Partner 
		WHERE companyId=@companyId AND partnerType=@partnerType AND ownerId=@ownerId AND partnerNo=@CustNo;		
		--送货线路
		SELECT @LineID=lineId
		FROM YiWms.dbo.BAS_AddressLine
		WHERE companyId=@companyId AND lineCode=@lineCode;
		IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_ReceiveAddress WHERE companyId=@companyId AND customerId=@partnerId AND receiverAddress=@receiverAddress AND receiverName=@receiverName)
		BEGIN
			SET @addressId=LOWER(REPLACE(NEWID(),'-',''));
			--写入没有的送货地址
			INSERT INTO YiWms.dbo.BAS_ReceiveAddress(addressId,companyId,customerId,receiverState,receiverCity,
				receiverDistrict,receiverAddress,zip,receiverName,receiverTel,receiverMobile,isDefault,logisticsId,
				logisticsMode,postFee,lineId,lineOrder,groupId,isDisable,isLocked,lockerId,lockedTime,createTime,
				creatorId,editTime,editorId)
			VALUES(@addressId,@companyId,@partnerId,'','','',@receiverAddress,'',@receiverName,@receiverTel,'',
				@isDefault,'',0,@postFee,@LineID,@viewOrder,'',0,0,'',NULL,@curTime,@operatorId,@curTime,@operatorId);
            SET @errors=@errors+@@ERROR;
			--写入操作日志
			INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterAddressSaved',
				'通过接口同步送货地址，客户编码:[' + @custNo + '],送货地址[' + @receiverAddress + '],收货人:[' + @receiverName + '],联系电话:[' + @receiverTel + ']',
				@addressId,@CustNo);		
            SET @errors=@errors+@@ERROR;
		END	
		ELSE
		BEGIN
			SELECT @addressId=addressId
			FROM YiWms.dbo.BAS_ReceiveAddress
			WHERE companyId=@companyId AND customerId=@partnerId AND receiverAddress=@receiverAddress AND receiverName=@receiverName;
			--更新送货地址
			UPDATE YiWms.dbo.BAS_ReceiveAddress SET receiverTel=@receiverTel,
														 receiverMobile='',
														 isDefault=@isDefault,
														 postFee=@postFee,
														 lineId=@LineID,
														 lineOrder=@viewOrder,
														 editTime=@curTime,
														 editorId=@operatorId
			WHERE addressId=@addressId;
            SET @errors=@errors+@@ERROR;
			--写入操作日志
			INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterAddressSaved',
				'通过接口同步送货地址，客户编码:[' + @custNo + '],送货地址[' + @receiverAddress + '],收货人:[' + @receiverName + '],联系电话:[' + @receiverTel + ']',
				@addressId,@CustNo);	
            SET @errors=@errors+@@ERROR;		
		END
	END		    
    IF (@errors=0)
    BEGIN
        COMMIT;
    END
    ELSE
	BEGIN 
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;
		RAISERROR(@ErrMsg, @ErrSeverity, 1)	
		--写入同步错误日志	
		INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterAddressSaved','YI_ADDRESS_SYNC_ERROR',LEFT(@ErrMsg,2000),@CustID,@CustNo);
	END
END
go

