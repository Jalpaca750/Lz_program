CREATE VIEW dbo.IMS_TransferDtl_V
AS
SELECT a.TransferID, a.TransferNo, e.DeptNo, e.CreateDate, e.BillSts, a.WareHouse_O, 
      a.WareHouse_I, a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, 
      b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, b.LabelID, b.LabelName, 
      b.ColorName, b.UnitName, b.PkgSpec, a.PkgQty, d.Location AS Location_I, 
      c.Location AS Location_O, a.TQty, a.Price, a.Amt, b.BPackage, b.MPackage, 
      b.Package, c.OnHandQty AS OnHandQty_O, d.OnHandQty AS OnHandQty_I, 
      b.PkgRatio, a.Remarks, a.CheckBox, b.ItemPHFlag, b.ItemPHName, 
      Y.QTY AS YZQty
FROM dbo.IMS_TransferDtl a LEFT OUTER JOIN
      dbo.IMS_Transfer e ON a.TransferNo = e.TransferNo LEFT OUTER JOIN
      dbo.IMS_Ledger d ON a.WareHouse_I = d.WareHouse AND a.ItemID = d.ItemID LEFT OUTER JOIN
      dbo.BAS_Goods_V b ON a.ItemID = b.ItemID LEFT OUTER JOIN
      dbo.IMS_Ledger c ON a.WareHouse_O = c.WareHouse AND a.ItemID = c.ItemID LEFT OUTER JOIN
      dbo.IMS_YZStock_Sum_WareHouse_Sum_V Y ON a.ItemID = Y.ItemID AND a.WareHouse_O = Y.WareHouseID
go

