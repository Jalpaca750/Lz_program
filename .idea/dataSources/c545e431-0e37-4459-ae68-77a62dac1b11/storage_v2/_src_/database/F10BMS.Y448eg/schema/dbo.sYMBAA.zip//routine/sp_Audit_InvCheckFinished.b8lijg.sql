
-- =============================================
-- Author:		<Author: Frank.He>
-- Create date: <Create Date:2017-02-06>
-- Description:	<Description:盘点单盘点完成> 
--      盘点完后更新盘点时刻表的盘点数量(realQty)
--      把盈亏数量写入IMS_Adjust表（调整表）和IMS_AdjustDetail                        
--      操作影响商品库存(BAS_Item表onhandQty)
--      仓库库存(IMS_Ledger表的onhandQty)，成本处理忽略不计
--      库位库存(IMS_Stock表) 
--      入出库流水帐(IMS_Book)
-- 2021-04-02日，去掉库位，批次的比较
-- =============================================
CREATE PROCEDURE [dbo].[sp_Audit_InvCheckFinished]
(
    @pointId VARCHAR(32),		--盘点设置Id
	@operatorId VARCHAR(32)		--操作员
)
AS
BEGIN	
	DECLARE @companyId VARCHAR(32),				--公司Id
			@pointNo VARCHAR(32),				--盘点期号
			@warehouseId VARCHAR(32),			--仓库Id
            @DeptNo VARCHAR(20),                --部门Id
			@regionId VARCHAR(32),				--库区Id
			@locationWay VARCHAR(10),			--通道
			@inventory INT,						--未盘点到商品处理方式 0,保持原值;1,库存归零
			@checkState INT,					--当前盘点设置状态 0-已作废；10-待盘点；20-盘点中；30-已完成
			@YKFlag INT,						--盈亏标识
			@billNo VARCHAR(32),				--调整单编号
			@adjustNo VARCHAR(32),				--调整单No
			@billType INT,						--10-盘亏调整单;11-盘盈调整单;20-手工调亏单;21-手工调盈单
			@count INT,						
            @errors BIGINT,                     --错误代码
			@memo VARCHAR(200),					--备注
			@syncFlag INT,						--同步状态；0-待同步;-1无需同步;
			@pcsMode VARCHAR(200);				--盘点单同步模式：0,通过调整单同步；1,盘点单直接同步						
	DECLARE @createTime DATETIME				--过账时间
	SET @createTime=GETDATE();	
    SET @companyId='01';

	DECLARE @tmpStock TABLE(Warehouse VARCHAR(32),DeptNo VARCHAR(32),itemId VARCHAR(32),plQty DECIMAL(20,6),realQty DECIMAL(20,6))
	--获取盘点设置
	SELECT @warehouseId=warehouseId,@DeptNo=DeptNo, @inventory=inventory,@checkState=checkState,@pointNo=pointNo
	FROM IMS_CheckPoint_V
	WHERE pointId=@pointId;
	--清除当前操作过程中的错误信息
	DELETE FROM SAM_Error WHERE creatorId=@operatorId AND funCode='sp_Audit_InvCheckFinished';
    --数据检查
	--盘点录入单据状态
	IF EXISTS(SELECT 1 FROM IMS_Check WHERE pointId=@pointId AND billSts='10')
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'sp_Audit_InvCheckFinished','YI_INV_CHECK_WAITING_COUNT','盘点尚未完成，操作无效！',@pointId,@pointNo);
		RETURN;
	END
	--未盘点
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@pointId AND checkState=10) OR (NOT EXISTS(SELECT * FROM IMS_Check WHERE pointId=@pointId))
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'sp_Audit_InvCheckFinished','YI_INV_CHECK_WAITING_COUNT','盘点尚未进行，操作无效！',@pointId,@pointNo);
		RETURN;
	END
	--已盘点
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@pointId AND checkState=30)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'sp_Audit_InvCheckFinished','YI_INV_CHECK_AUDITED','盘点计划已经盘点完成，操作无效！',@pointId,@pointNo);
		RETURN;
	END
	--已盘点
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@pointId AND checkState=0)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,@createTime,@operatorId,'sp_Audit_InvCheckFinished','YI_INV_CHECK_CLOSED','盘点计划已经作废，操作无效！',@pointId,@pointNo);
		RETURN;
	END
	SET @errors=0;
	BEGIN TRANSACTION		
    --盘点完成自己签出的计划（防止并发）
    UPDATE IMS_CheckPoint SET checkState=30,editTime=@createTime,editorId=@operatorId WHERE pointId=@pointId AND checkState=20 AND lockerId=@operatorId;
	if (@@ROWCOUNT>0)
	BEGIN
        SET @errors=@errors+@@ERROR;
		--统计盘点数据(@inventory:0,保持原值;1,库存归零)
		UPDATE cs SET cs.realQty = CASE @inventory WHEN 0 THEN ISNULL(tmp.realQty,ISNULL(cs.onhandQty,0.0)) ELSE ISNULL(tmp.realQty,0.0) END
		FROM dbo.IMS_CheckStock cs LEFT JOIN
			(SELECT a.Warehouse,b.itemId,SUM(b.SQty) AS realQty
			 FROM dbo.IMS_Check a 
				INNER JOIN dbo.IMS_CheckDtl b ON a.checkNo=b.checkNo 
			 WHERE (a.pointId=@pointId) AND (a.billSts=20)
			 GROUP BY a.Warehouse,b.itemId
			) tmp ON cs.warehouseId=tmp.warehouse AND cs.itemId=tmp.itemId
		WHERE cs.pointId=@pointId;
        SET @errors=@errors+@@ERROR;

		--盈亏数据
		INSERT INTO @tmpStock(Warehouse,DeptNo,itemId,plQty)
		SELECT cs.warehouseId,@DeptNo,cs.itemId,SUM(ISNULL(cs.realQty,0.0)-ISNULL(cs.onhandQty,0.0)) AS plQty
		FROM dbo.IMS_CheckStock cs 
		WHERE (cs.pointId=@pointId) 
            AND (ISNULL(cs.realQty,0.0)-ISNULL(cs.onhandQty,0.0)!=0.0)
        GROUP BY warehouseId,itemId

        SET @errors=@errors+@@ERROR;
		--通过调整单同步，盘点单无需同步
		UPDATE IMS_Check SET billSts='30',auditDate=CONVERT(VARCHAR(10),GETDATE(),23),auditId=@operatorId,createTime=@createTime,CheckTime=@createTime 
        WHERE pointId=@pointId;
        SET @errors=@errors+@@ERROR;
		--如果有盘点盈亏数据
		IF EXISTS(SELECT 1 FROM @tmpStock)
		BEGIN
			--写入流水账
            INSERT INTO IMS_Flow(BillNo,DeptNo,WareHouse,CreateDate,BillType,AuditDate,ItemID,SQty)
    	    SELECT @pointNo,@DeptNo,WareHouse,CONVERT(CHAR(10),GETDATE(),23),'盘存清单',CONVERT(CHAR(10),GETDATE(),23),ItemID,plQty
		    FROM @tmpStock;
            SET @errors=@errors+@@ERROR;
            
            --更新商品资料文件
        	UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.plQty,0.0)
        	FROM BDM_ItemInfo a 
                INNER JOIN @tmpStock b ON a.ItemID=b.ItemID;
            SET @errors=@errors+@@ERROR;

        	--更新分部库存！
        	UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0)+ISNULL(b.plQty,0.0)
        	FROM IMS_Subdepot a 
                INNER JOIN @tmpStock b ON a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID;
            SET @errors=@errors+@@ERROR;

        	--插入没有的分部库存
        	INSERT INTO IMS_Subdepot(DeptNo,ItemID,OnHandQty)
        	SELECT DeptNo,ItemID,ISNULL(plQty,0.0)
        	FROM @tmpStock a 
        	WHERE NOT EXISTS(SELECT * FROM IMS_Subdepot b WHERE a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID);
        	SET @errors=@errors+@@ERROR;	

        	--更新库房
        	UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.plQty,0.0),a.LastTime=GETDATE()
        	FROM IMS_Ledger a 
                INNER JOIN @tmpStock b ON a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID;
        	SET @errors=@errors+@@ERROR;

            --插入没有的
        	INSERT INTO IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastTime)
        	SELECT DeptNo,WareHouse,ItemID,ISNULL(plQty,0.0),GETDATE()
        	FROM @tmpStock a
        	WHERE NOT EXISTS(SELECT * FROM IMS_Ledger b WHERE a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID);
            SET @errors=@errors+@@ERROR;
            --插入IMS_Audit表
            INSERT INTO IMS_Audit(LotNo,CreateDate,DeptNo,Warehouse,ItemID,OnhandQty,ActQty,SQty,locked)  
            SELECT b.pointNo,CONVERT(VARCHAR(10),b.createTime,23),c.DeptNo,a.warehouseId,a.itemId,
                a.onhandQty,a.realQty,ISNULL(a.realQty,0.0)-ISNULL(a.onhandQty,0.0),1
            FROM IMS_CheckStock a
                INNER JOIN IMS_CheckPoint b ON a.pointId=b.pointId
                INNER JOIN BDM_Code c ON a.warehouseId=c.CodeID
            WHERE a.pointId=@pointId;
            SET @errors=@errors+@@ERROR;
		END
	END
    IF (@errors=0)
	BEGIN
    	COMMIT;
	END
    ELSE
	BEGIN
		IF @@TRANCOUNT > 0
			 ROLLBACK;
        DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
        SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;
		--写入同步错误日志	
		INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),'01',GETDATE(),@operatorId,'sp_Audit_InvCheckFinished','YI_INV_CHECK_ERROR',LEFT(@ErrMsg,2000),@pointId,@pointNo);
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END
END
go

