--说明：系统报表之采购发票
--作者：Devil.H
--创建：2007.10.29
--参数：
--	@BillNo	 :单据编号
--	@Row	 :每页打印行数
--修改: 2021-08-07 商品名称等数据长度增长，并增加商品简称字段
CREATE FUNCTION dbo.uf_RPTPMS90
(
    @BillNo VARCHAR(20),
    @Row BIGINT,
    @OrderBy VARCHAR(30)
)
RETURNS @uTable TABLE(
    BillID BIGINT IDENTITY(1,1),
    BillNo VARCHAR(20),
    StockNo VARCHAR(20),
    ItemNo VARCHAR(20),
    ItemName VARCHAR(200),
    ItemAlias VARCHAR(200),
    ItemSpec VARCHAR(100),
    ClassName VARCHAR(100),
    LabelName VARCHAR(100),
    ColorName VARCHAR(40),
    UnitName VARCHAR(40),
    Price DECIMAL(18,6),
    IQty DECIMAL(18,6),
    Amt DECIMAL(18,6),
    PPrice DECIMAL(18,6),
    BPackage VARCHAR(40),
    MPackage VARCHAR(40),
    Package VARCHAR(40),
    Remarks VARCHAR(2000)
)
AS
BEGIN	
	DECLARE @Rows BIGINT;
	DECLARE @NullRow BIGINT;
	DECLARE @i BIGINT;
	--初始化变量
	SET @i=0
	--如果没有传递行数，默认9行
	SET @Row=ISNULL(@Row,9);
	IF ISNULL(@BillNo,'')=''
		RETURN;
    IF UPPER(@OrderBy)='INVOICEID'
        INSERT INTO @uTable(BillNo,StockNo,ItemNo,ItemName,ItemAlias,ItemSpec,ClassName,LabelName,
            ColorName,UnitName,Price,IQty,Amt,PPrice,Remarks)
        SELECT InvoiceNo,StockNo,ItemNo,ItemName,ItemAlias,ItemSpec,ClassName,LabelName,ColorName,
            UnitName,Price,IQty,Amt,PPrice,Remarks
        FROM PMS_InvoiceDtl_V
        WHERE InvoiceNo=@BillNo
        ORDER BY InvoiceID;
    IF UPPER(@OrderBy)='ITEMNO'
        INSERT INTO @uTable(BillNo,StockNo,ItemNo,ItemName,ItemAlias,ItemSpec,ClassName,LabelName,
            ColorName,UnitName,Price,IQty,Amt,PPrice,Remarks)
        SELECT InvoiceNo,StockNo,ItemNo,ItemName,ItemSpec,ItemAlias,ClassName,LabelName,ColorName,
            UnitName,Price,IQty,Amt,PPrice,Remarks
        FROM PMS_InvoiceDtl_V
        WHERE InvoiceNo=@BillNo
        ORDER BY ItemNo;
    --总的行数
    SELECT @Rows=COUNT(*) FROM @uTable
    IF @Rows=0 
        RETURN;
    SET @NullRow=@Row-@Rows%@Row;
    IF @NullRow=@Row 
        RETURN;
    WHILE @i<@NullRow
    BEGIN
        INSERT INTO @uTable(BillNo)
        VALUES(@BillNo);
        SET @i=@i+1;
    END
    --返回
    RETURN;
END
go

