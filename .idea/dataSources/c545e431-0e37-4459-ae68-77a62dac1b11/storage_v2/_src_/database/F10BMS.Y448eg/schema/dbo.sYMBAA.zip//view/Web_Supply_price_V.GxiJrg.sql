CREATE VIEW dbo.Web_Supply_price_V
AS
SELECT a.PriceID, a.DeptNo, d.CHName AS DeptName, a.VendorID, b.VendorNo, 
      b.VendorName, b.NameSpell AS VNameSpell, a.ItemID, C.ItemNo, C.ItemName, 
      C.ItemAlias, C.NameSpell AS INameSpell, C.ItemSpec, C.BarCode, C.ClassID, 
      C.ClassName, C.LabelID, C.LabelName, C.ColorName, C.UnitName, a.Price, 
      a.TaxFlag, C.PPrice, C.SafePPrice, C.BPackage, C.MPackage, C.Package, C.PkgRatio, 
      C.PkgSpec, C.HotFlag, C.NotDisc, C.Integral, C.Defined1, C.Defined2, C.Defined3, 
      C.Defined4, C.Defined5, a.DefVendor, Q.OnHandQty
FROM PMS_Price a LEFT OUTER JOIN
      uf_AnalIMS1A(1) Q ON a.DeptNo = Q.DeptNo AND 
      a.ItemID = Q.ItemID LEFT OUTER JOIN
      BDM_DeptCode_V d ON a.DeptNo = d.CodeID LEFT OUTER JOIN
      BDM_Vendor b ON a.VendorID = b.VendorID LEFT OUTER JOIN
      BDM_ItemInfo_V C ON a.ItemID = C.ItemID
WHERE (a.DefVendor = '1')
go

