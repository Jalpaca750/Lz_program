CREATE VIEW dbo.IMS_InceptDtl_V
AS
SELECT a.InceptID, a.InceptNo, b.CreateDate, b.BillSts, a.AllotID, a.AllotNo, a.OrderID, 
    ISNULL(c.Location, a.Location) AS Location, a.WareHouse, a.ItemID, d.ItemNo, 
    d.ItemName, d.ItemAlias, d.NameSpell, d.ItemSpec, d.BarCode, d.ClassID, d.ClassName, 
    d.LabelID, d.LabelName, d.ColorName, d.UnitName,c.AvailQty, 
    ISNULL(e.SQty, 0.0) - ISNULL(e.IQty, 0.0) AS RemIQty, d.PkgSpec, a.PkgQty, a.IQty, 
    a.Price, a.Amt, d.PPrice, 
    CASE ISNULL(a.SPrice,0.0) WHEN 0.0 THEN d.SPrice ELSE a.SPrice END AS SPrice, 
    d.SPrice1, d.SPrice2, d.SPrice3, c.OnHandQty, d.BPackage, d.MPackage, d.Package, 
    d.PkgRatio, a.DeptNo, f.CHName AS DeptName, e.OrderNo, d.ItemPHFlag, d.ItemPHName, 
    d.Defined1,d.Defined2,d.Defined3,d.Defined4,d.Defined5,a.WmsStockId,a.Remarks,
    a.shelvesFlag,a.shelvesTime,a.CheckBox
FROM dbo.IMS_InceptDtl a 
    LEFT JOIN dbo.BDM_DeptCode_V f ON f.CodeID = a.DeptNo 
    LEFT JOIN dbo.IMS_AllotDtl e ON a.AllotID = e.AllotID 
    LEFT JOIN dbo.IMS_Incept b ON a.InceptNo = b.InceptNo 
    LEFT JOIN dbo.BAS_Goods_V d ON a.ItemID = d.ItemID 
    LEFT JOIN dbo.IMS_Ledger c ON a.WareHouse = c.WareHouse AND a.ItemID = c.ItemID
go

