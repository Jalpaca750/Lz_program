CREATE Function dbo.fn_AnalACMFA
(
	@DeptNo VARCHAR(20),
	@StartDate char(10),
	@EndDate char(10),
    @UserID BIGINT
)
RETURNS TABLE
AS
RETURN(
    SELECT a.CreateDate,a.FeesNo, a.deptNo,d.CHName AS DeptName, a.CustId,e.CustNo,e.CustName,e.NameSpell,
        e.CustType,e.TypeName,e.AreaCode,e.AreaName,e.MemberId,e.Member,e.PopedomId,e.popedomName,e.TradeName,
        e.KindName,a.employeeId,e1.employeeName,b.rpId,rt.rpName, a.PAccountId,c.accountName, b.feesAmt,b.notes,
        CONVERT(VARCHAR(20),a.createTime,120) AS createTime,a.CreatorId,e2.EmployeeName AS CreatorName, a.remarks
    FROM ACM_Fees a
        INNER JOIN ACM_FeesDtl b ON a.FeesNo=b.FeesNo
        INNER JOIN BDM_Account c ON a.paccountId=c.accountId
        INNER JOIN BDM_RpType rt ON b.rpId=rt.rpId
        LEFT JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
        LEFT JOIN BAS_Customer_V e ON a.CustID=e.CustID
        LEFT JOIN BDM_Employee e1 ON a.employeeId=e1.employeeId
        LEFT JOIN BDM_Employee e2 ON a.CreatorId=e2.employeeId
    WHERE rt.rpType=3
        AND a.createDate BETWEEN @StartDate AND @EndDate
        AND a.DeptNo LIKE @DeptNo + '%'
        AND LEFT(a.DeptNo,4) IN(SELECT CodeID FROM fn_GetDepartment(@UserID))
)    
go

