
/*==============================================================*/
/* View: WMS_F10_Item_V                                         */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_Item_V] as
SELECT a.itemId AS f10Id,b.itemId,b.eId,b.itemNo,b.itemName,b.pkgRatio,
	a.SPrice,a.SPrice1,a.SPrice2,a.SPrice3,a.PPrice,a.Integral,b.itemVolume,
	b.itemWeight,b.pkgVolume,b.pkgWeight,b.isVirtual
FROM dbo.BDM_ItemInfo a
	INNER JOIN (SELECT y.eId,y.itemId,x.itemNo,x.itemName,x.pkgRatio,
					x.itemVolume,x.pkgVolume,x.itemWeight,x.pkgWeight,x.isVirtual
				FROM YiWms.dbo.BAS_Item x 
					INNER JOIN YiWms.dbo.ECM_ItemSku y ON x.itemId=y.itemId
				WHERE EXISTS(SELECT * FROM dbo.SYS_Config z WHERE x.companyId=z.companyId AND x.ownerId=z.OwnerId)
				)  b ON a.ItemNo=b.itemNo
go

