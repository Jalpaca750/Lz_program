--说明：系统报表
--作者：Devil.H
--创建：2006.06.13
--参数：
--	@BillNo	 :单据编号
--	@Row	 :每页打印行数
CREATE Function dbo.uf_RPTACM04
(
	@BillNo varchar(20),
	@Row bigint
)
Returns @uTable Table(
	BillID bigint identity(1,1),
	BillNo varchar(20),
	ShiftNo varchar(20),
	PCNo varchar(2),
	Creator varchar(20),
	Receiver varchar(20),
	PAmt decimal(18,6),
	PayAmt decimal(18,6),
	LAmt decimal(18,6),
	SAmt decimal(18,6),
	Remark varchar(200)
)
--加密
--with encryption
As
Begin	
	declare @Rows bigint
	declare @NullRow bigint
	declare @i bigint
	--初始化变量
	Set @i=0
	--如果没有传递行数，默认9行
	Set @Row=isnull(@Row,9)
	if isnull(@BillNo,'')=''
		Return
	Insert Into @uTable(BillNo,ShiftNo,PCNo,Creator,Receiver,PAmt,PayAmt,LAmt,SAmt,Remark)
	Select GatheringNo,ShiftNo,PCNo,Creator,Receiver,PAmt,PayAmt,LAmt,SAmt,Remark
	From SMS_GatheringDtl_V
	Where GatheringNo=@BillNo
	Order By GatheringID
	--总的行数
	Select @Rows=Count(*) From @uTable
	if @Rows=0 
		return
	Set @NullRow=@Row-@Rows%@Row
	if @NullRow=@Row 
		Return
	while @i<@NullRow
		Begin
			Insert Into @uTable(BillNo)
			Values(@BillNo)
			Set @i=@i+1
		End
	--返回
	return
End












go

