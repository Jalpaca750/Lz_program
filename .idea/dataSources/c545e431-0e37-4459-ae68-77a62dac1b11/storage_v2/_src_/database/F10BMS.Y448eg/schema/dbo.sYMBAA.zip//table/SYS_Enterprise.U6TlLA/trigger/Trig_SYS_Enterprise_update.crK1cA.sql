

CREATE TRIGGER Trig_SYS_Enterprise_update ON dbo.SYS_Enterprise
FOR UPDATE
AS
declare @CorpNo1 varchar(20)
declare @CorpNo2 varchar(20)
set @CorpNo1 = (select CorpNo from deleted)
set @CorpNo2 = (select CorpNo from inserted)
update dbo.SYS_Enterprise_Bill set CorpNo=@CorpNo2 where CorpNo=@CorpNo1
update dbo.SYS_Enterprise_PIC set CorpNo=@CorpNo2 where CorpNo=@CorpNo1
--update a set CorpNo=i.CorpNo from dbo.SYS_Enterprise_Bill a,inserted i where a.CorpNo=i.CorpNo
--update a set CorpNo=i.CorpNo from dbo.SYS_Enterprise_PIC a,inserted i where a.CorpNo=i.CorpNo

go

