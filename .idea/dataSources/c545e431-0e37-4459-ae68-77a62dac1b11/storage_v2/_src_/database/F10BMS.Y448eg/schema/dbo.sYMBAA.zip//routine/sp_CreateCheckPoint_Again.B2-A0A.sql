

-- =============================================
-- Author:		<Author: 王军>
-- Create date: <Create Date:2017-09-29 17:27>
-- Description:	<Description:生成复盘计划> 
--      1.更新盘点时刻表的盘点数量(realQty)
--      2.如果盘点时刻表存在盈亏数据，则生成复盘计划                        
--      3.盘点单与盘点录入表状态更新为已完成
-- Modify: 2018-11-14 Frank 修正复盘Bug
-- =============================================
CREATE PROCEDURE [dbo].[sp_CreateCheckPoint_Again]
(
    @opointId VARCHAR(32),						--盘点单Id
    @operatorId varchar(32)						--操作员Id
)
AS 
BEGIN
	DECLARE @pointNo VARCHAR(32),				--盘点期号
	        @parentId VARCHAR(32),              --原始盘点Id
			@warehouseId VARCHAR(32),			--仓库Id
			@regionId VARCHAR(32),				--库区Id
			@locationWay VARCHAR(10),			--通道
            @errors BIGINT,
			@inventory INT,						--未盘点到商品处理方式 0,保持原值;1,库存归零
			@checkState INT;					--当前盘点设置状态 0-已作废；10-待盘点；20-盘点中；30-已完成
	DECLARE @tmpStock TABLE(stockId VARCHAR(32),pointId VARCHAR(32),companyId VARCHAR(32),warehouseId VARCHAR(32),regionId VARCHAR(32),locationWay VARCHAR(10),lotNo VARCHAR(32),locationNo VARCHAR(32),eId VARCHAR(32),itemId VARCHAR(32),onhandQty DECIMAL(20,6),plQty DECIMAL(20,6),realQty DECIMAL(20,6),pkgRatio INT,YKFlag INT)
	DECLARE @npointId VARCHAR(32);
	DECLARE @createTime DATETIME;    
    
    SET @npointId=LOWER(REPLACE(NEWID(),'-',''));
    SET @createTime=GETDATE();

	--清除当前操作过程中的错误信息
	DELETE FROM SAM_Error WHERE creatorId=@operatorId AND funCode='sp_CreateCheckPoint_Again';

	--盘点设置
	SELECT @pointNo=pointNo,@warehouseId=warehouseId,@inventory=inventory,@checkState=checkState,@parentId=ISNULL(parentId,'-1')
	FROM IMS_CheckPoint
	WHERE pointId=@opointId;

	IF (ISNULL(@parentId,'')='-1' OR ISNULL(@parentId,'')='')
	    SET @parentId=@opointId;

	--盘点录入单据状态
	IF EXISTS(SELECT 1 FROM IMS_Check WHERE pointId=@opointId AND billSts='10') 
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),'01',@createTime,@operatorId,'sp_CreateCheckPoint_Again','YI_INV_CHECK_WAITING_COUNT','盘点尚未完成，操作无效！',@opointId,@pointNo);
		RETURN;
	END
	--未盘点
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@opointId AND checkState=10) OR (NOT EXISTS(SELECT 1 FROM IMS_Check WHERE pointId=@opointId))
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),'01',@createTime,@operatorId,'sp_CreateCheckPoint_Again','YI_INV_CHECK_WAITING_COUNT','盘点尚未进行，操作无效！',@opointId,@pointNo);
		RETURN;
	END
	--已盘点
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@opointId AND checkState=30)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),'01',@createTime,@operatorId,'sp_CreateCheckPoint_Again','YI_INV_CHECK_AUDITED','盘点计划已经盘点完成，操作无效！',@opointId,@pointNo);
		RETURN;
	END
	--已作废
	IF EXISTS(SELECT 1 FROM IMS_CheckPoint WHERE pointId=@opointId AND checkState=0)
	BEGIN
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),'01',@createTime,@operatorId,'sp_CreateCheckPoint_Again','YI_INV_CHECK_CLOSED','盘点计划已经作废，操作无效！',@opointId,@pointNo);
		RETURN;
	END
	SET @errors=0;
    BEGIN TRANSACTION
    --盘点完成自己签出的计划（防止并发）
    UPDATE IMS_CheckPoint SET checkState=30,editTime=@createTime,editorId=@operatorId WHERE pointId=@opointId AND checkState=20 AND lockerId=@operatorId;
    IF (@@ROWCOUNT>0)
    BEGIN
        --统计盘点数据(@inventory:0,保持原值;1,库存归零)
        UPDATE cs SET cs.realQty = CASE @inventory WHEN 0 THEN ISNULL(tmp.realQty,ISNULL(cs.onhandQty,0.0)) ELSE ISNULL(tmp.realQty,0.0) END
        FROM dbo.IMS_CheckStock cs LEFT JOIN
        	(SELECT a.warehouse,'' lotNo,b.location,b.itemId,SUM(b.SQty) AS realQty
        	 FROM dbo.IMS_Check a 
        		INNER JOIN dbo.IMS_CheckDtl b ON a.checkNo=b.checkNo 
        	 WHERE (a.pointId=@opointId) AND (a.billSts='20')
        	 GROUP BY a.warehouse,b.lotNo,b.location,b.itemId
        	) tmp ON cs.warehouseId=tmp.warehouse AND ISNULL(cs.lotNo,'')=ISNULL(tmp.lotNo,'') AND ISNULL(cs.locationNo,'')=ISNULL(tmp.location,'') AND cs.itemId=tmp.itemId
        WHERE cs.pointId=@opointId;
        SET @errors=@errors+@@ERROR;
		--盈亏数据
		INSERT INTO @tmpStock(stockId,pointId,companyId,warehouseId,regionId,locationWay,lotNo,locationNo,eId,itemId,onhandQty,plQty,realQty,YKFlag)
		SELECT stockId,pointId,companyId,warehouseId,regionId,locationWay,ISNULL(lotNo,''),ISNULL(locationNo,''),eId,itemId,
			onhandQty,ISNULL(realQty,0.0)-ISNULL(onhandQty,0.0) AS plQty,ISNULL(realQty,0.0) AS realQty,
			CASE WHEN ISNULL(realQty,0.0)-ISNULL(onhandQty,0.0)>0 THEN 1 ELSE 0 END
		FROM dbo.IMS_CheckStock 
		WHERE (pointId=@opointId) AND (ISNULL(realQty,0.0)-ISNULL(onhandQty,0.0)!=0.0);
        SET @errors=@errors+@@ERROR;

    	--更新盘点单状态
		UPDATE IMS_Check SET billSts='30',auditDate=CONVERT(VARCHAR(10),GETDATE(),23),auditId=@operatorId,remarks='生成复盘计划，当前盘点单无需同步    ' + ISNULL(remarks,'')
		WHERE pointId=@opointId;
        SET @errors=@errors+@@ERROR;

		--如果没有盘点盈亏数据,则退出
		IF EXISTS(SELECT 1 FROM @tmpStock)
		BEGIN
			----------------生成盘点计划----------
			INSERT INTO IMS_CheckPoint(pointId,pointNo,companyId,warehouseId,startArea,endArea,startOwner,endOwner,startNo,endNo,startItem,endItem,pointDate,startTime,endTime,printNum,inventory,checkData,checkState,parentId,createTime,creatorId,editTime)
			SELECT @npointId,pointNo+'-1',companyId,warehouseId,startArea,endArea,startOwner,endOwner,startNo,endNo,startItem,endItem,pointDate,startItem,endTime,0 AS printNum,inventory,checkData,10,@parentId,GETDATE()AS createTime,@operatorId AS creatorId,GETDATE()
			FROM IMS_CheckPoint 
			WHERE pointId=@opointId;
            SET @errors=@errors+@@ERROR;
			--------------生成盘点明细------------------
			INSERT INTO IMS_CheckStock(stockId,pointId,companyId,warehouseId,regionId,lotNo,locationWay,locationNo,eId,itemId,onhandQty,realQty)
			SELECT LOWER(REPLACE(NEWID(),'-','')),@npointId,companyId,warehouseId,regionId,lotNo,locationWay,locationNo,eId,itemId,onhandQty,0
			FROM @tmpStock;
			SET @errors=@errors+@@ERROR;    
		END
		ELSE
		BEGIN
			INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(REPLACE(NEWID(),'-',''),'01',@createTime,@operatorId,'sp_CreateCheckPoint_Again','YI_INV_CHECK_AGAIN_NOT_DATA','没有需要生成复盘计划的数据！',@opointId,@pointNo);
			SET @errors=@errors+@@ERROR;
            RETURN;
		END			
    END
    IF (@errors=0)
	BEGIN
    	COMMIT;
	END
    ELSE
	BEGIN
		IF @@TRANCOUNT > 0
			 ROLLBACK;
        DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
        SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;
		--写入同步错误日志	
		INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),'01',GETDATE(),@operatorId,'sp_CreateCheckPoint_Again','YI_INV_CHECK_ERROR',LEFT(@ErrMsg,2000),@opointId,@pointNo);
		RAISERROR(@ErrMsg, @ErrSeverity, 1)
	END
END
go

