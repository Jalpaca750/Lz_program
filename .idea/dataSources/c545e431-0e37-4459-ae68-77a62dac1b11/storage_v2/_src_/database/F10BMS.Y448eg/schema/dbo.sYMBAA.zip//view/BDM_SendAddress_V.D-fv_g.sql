CREATE VIEW [dbo].[BDM_SendAddress_V]
AS
SELECT a.SendID, a.CustID, c.CustNo, c.CustName, a.SendAddr, a.LinkMan, a.Phone, 
    a.LineID, d.CHName AS LineName, a.viewOrder, a.DefAddr, c.CheckBox, a.WebName, 
    a.WebPassword, a.KJMM, a.IsPower, a.NeedCheck, a.CheckMan, a.Flag,c.DeptNo,
    a.KmNum,a.PostFee,a.DeptName,
    CASE ISNULL(a.logisticsId,'') WHEN '' THEN c.logisticsId ELSE a.logisticsId END AS logisticsId,
    lg.logisticsCode,lg.logisticsName 
FROM dbo.BDM_SendAddress a 
    INNER JOIN dbo.BDM_Customer c ON a.CustID = c.CustID 
    LEFT JOIN dbo.BDM_DeliveryLine_V d ON a.LineID = d.CodeID
    LEFT JOIN dbo.BAS_Logistics lg ON a.logisticsId=lg.logisticsId
go

