--拆卸入库单审核(Update)
--2007-10-27
--Devil.H
--当上述操作发生时：
--更新库存……
CREATE Proc sp_IMSSplitAudit
(
	@SplitNo varchar(20),
	@Flag char(2)
)
As
Begin
	declare @WareHouse_I varchar(20)
	declare @WareHouse_O varchar(20)
	declare @CreateDate varchar(10)
	declare @AuditDate varchar(10)
	declare @DeptNo varchar(20)
	declare @ItemID bigint
	--获取拆卸产品出库库房，日期
	Select @DeptNo=DeptNo,@WareHouse_O=WareHouse_O,@WareHouse_I=WareHouse_I,
		@AuditDate=AuditDate,@CreateDate=CreateDate,@ItemID=ItemID 
	From IMS_Split
	Where SplitNo=@SplitNo
	--审核 拆卸库存减少，部件库存增加
	If Isnull(@Flag,'10')='20'
		Begin
			--领料出库
			--更新商品资料表
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.OQty,0)
			From BDM_ItemInfo a inner join IMS_Split b On a.ItemID=b.ItemID
			Where b.SplitNo=@SplitNo
			--更新分部库存
			if exists(Select 1 From IMS_Subdepot Where DeptNo=@DeptNo And ItemID=@ItemID)
				Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.OQty,0)
				From IMS_Subdepot a inner join IMS_Split b On a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
				Where b.SplitNo=@SplitNo
			Else
				Insert Into IMS_Subdepot(DeptNo,ItemID,OnHandQty)
				Select DeptNo,ItemID,-OQty
				From IMS_Split
				Where SplitNo=@SplitNo
			--判断库房是否存在该商品(拆卸出库)
			if exists(Select 1 From IMS_Ledger Where WareHouse=@WareHouse_O And ItemID=@ItemID)
				Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.OQty,0),
					a.LastODate=@CreateDate,a.LastOPrice=b.Price,a.DeptNo=b.DeptNo,a.LastTime=getdate()
				From IMS_Ledger a inner join IMS_Split b on a.ItemID=b.ItemID And a.WareHouse=b.WareHouse_O
				Where b.SplitNo=@SplitNo
			else
				Insert Into IMS_Ledger(WareHouse,ItemID,OnHandQty,LastODate,LastOPrice,DeptNo,LastTime)
				Select WareHouse_O,ItemID,-OQty,CreateDate,Price,DeptNo,Getdate()
				From IMS_Split
				Where SplitNo=@SplitNo
			--部件入库
			--更新商品资料表
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.IQty,0)
			From BDM_ItemInfo a inner join IMS_SplitDtl b On a.ItemID=b.ItemID
			Where b.SplitNo=@SplitNo
			--分部库存
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.IQty,0)
			From IMS_Subdepot a,IMS_SplitDtl b 
			Where a.ItemID=b.ItemID And b.SplitNo=@SplitNo		
			Insert Into IMS_Subdepot(DeptNo,ItemID,OnHandQty)
			Select @DeptNo,ItemID,IQty
			From IMS_SplitDtl
			Where SplitNo=@SplitNo And ItemID Not In(Select ItemID From IMS_Subdepot Where DeptNo=@DeptNo)
			--库房库存
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.IQty,0),
				a.LastIDate=@CreateDate,a.LastIPrice=b.Price,a.DeptNo=@DeptNo,a.LastTime=getdate()
			From IMS_Ledger a inner join IMS_SplitDtl b on a.ItemID=b.ItemID And a.WareHouse=b.WareHouse_I
			Where b.SplitNo=@SplitNo
			Insert Into IMS_Ledger(WareHouse,ItemID,OnHandQty,LastIDate,LastIPrice,DeptNo,lastTime)
			Select WareHouse_I,ItemID,IQty,@CreateDate,Price,@DeptNo,getdate()
			From IMS_SplitDtl
			Where SplitNo=@SplitNo And ItemID Not In(Select ItemID From IMS_Ledger Where WareHouse=@WareHouse_I)
			--写入流水账
			Insert Into IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,CreateDate,AuditDate)
			Select SplitNo,'拆卸出库单',DeptNo,WareHouse_O,ItemID,-OQty,Price,-Amt,CreateDate,AuditDate
			From IMS_Split
			Where SplitNo=@SplitNo
			Insert Into IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,CreateDate,AuditDate)
			Select SplitNo,'拆卸入库单',@DeptNo,@WareHouse_I,ItemID,IQty,Price,Amt,@CreateDate,@AuditDate
			From IMS_SplitDtl
			Where SplitNo=@SplitNo
		End
	--取消审核，拆卸库存减少，部件库存增加
	If Isnull(@Flag,'10')='10'
		Begin
			--拆卸出库
			--商品资料
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.OQty,0)
			From BDM_ItemInfo a inner join IMS_Split b On a.ItemID=b.ItemID
			Where b.SplitNo=@SplitNo
			--分部
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.OQty,0)
			From IMS_Subdepot a inner join IMS_Split b On a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
			Where b.SplitNo=@SplitNo
			--库房
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.OQty,0),a.LastTime=getdate()
			From IMS_Ledger a inner join IMS_Split b on a.ItemID=b.ItemID And a.WareHouse=b.WareHouse_O
			Where b.SplitNo=@SplitNo
			--部件出库
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.IQty,0)
			From BDM_ItemInfo a inner join IMS_SplitDtl b On a.ItemID=b.ItemID
			Where b.SplitNo=@SplitNo
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.IQty,0)
			From IMS_Subdepot a,IMS_SplitDtl b 
			Where a.ItemID=b.ItemID And b.SplitNo=@SplitNo		
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.IQty,0),a.LastTime=getdate()
			From IMS_Ledger a inner join IMS_SplitDtl b on a.ItemID=b.ItemID And a.WareHouse=b.WareHouse_I
			Where b.SplitNo=@SplitNo
			--删除流水账
			Delete From IMS_Flow Where BillNo=@SplitNo
		End
End
go

