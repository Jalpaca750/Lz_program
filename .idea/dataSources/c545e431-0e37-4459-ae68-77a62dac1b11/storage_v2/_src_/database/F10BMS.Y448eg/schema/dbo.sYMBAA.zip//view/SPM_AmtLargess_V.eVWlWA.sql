CREATE View SPM_AmtLargess_V
As
SELECT a.LargessNo, a.StartDate, a.EndDate, 
	a.MemberID, CASE isnull(c.CHName,'') WHEN '' THEN '所有客户' ELSE c.CHName END AS Member, 
	a.AreaCode, CASE isnull(d.CHName, '') WHEN '' THEN '所有地区' ELSE d .CHName END AS AreaName, 
	a.ClassID, CASE isnull(e.CHName, '') WHEN '' THEN '所有大类' ELSE e.CHName END AS Class, 
      	a.LabelID, CASE isnull(f.CHName, '') WHEN '' THEN '所有品牌' ELSE f.CHName END AS Label, 
	a.ItemID, g.ItemNo, CASE isnull(g.ItemName, '') WHEN '' THEN '所有商品' ELSE g.ItemName END AS ItemName, 
	a.CreatorID,b.EmployeeName AS Creator
FROM dbo.SPM_AmtLargess a LEFT OUTER JOIN
      dbo.BDM_LabelCode_V f ON a.LabelID = f.CodeID LEFT OUTER JOIN
      dbo.BDM_ItemInfo g ON a.ItemID = g.ItemID LEFT OUTER JOIN
      dbo.BDM_ItemClass_V e ON a.ClassID = e.CodeID LEFT OUTER JOIN
      dbo.BDM_MemberCode_V c ON a.MemberID = c.CodeID LEFT OUTER JOIN
      dbo.BDM_AreaCode_V d ON a.AreaCode = d .CodeID LEFT OUTER JOIN
      dbo.BDM_Employee b ON a.CreatorID = b.EmployeeID
go

