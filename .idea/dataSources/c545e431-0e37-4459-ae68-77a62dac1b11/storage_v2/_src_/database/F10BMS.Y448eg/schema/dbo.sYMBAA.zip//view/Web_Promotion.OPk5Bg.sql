CREATE VIEW dbo.Web_Promotion
AS
SELECT P.PromotionPriceNo, P.StartDate, P.EndDate, P.MemberID, C.CustID, P.AreaCode, 
      D.ItemID, D.Price
FROM dbo.SPM_PromotionPriceDtl D RIGHT OUTER JOIN
      dbo.SPM_PromotionPrice_V P ON 
      D.PromotionPriceNo = P.PromotionPriceNo FULL OUTER JOIN
      dbo.SPM_PromotionPriceCustomer C ON 
      P.PromotionPriceNo = C.PromotionPriceNo
WHERE (NOT (P.PromotionPriceNo IS NULL)) AND (CONVERT(varchar(10), GETDATE(), 120) BETWEEN P.StartDate AND 
      P.EndDate)
go

