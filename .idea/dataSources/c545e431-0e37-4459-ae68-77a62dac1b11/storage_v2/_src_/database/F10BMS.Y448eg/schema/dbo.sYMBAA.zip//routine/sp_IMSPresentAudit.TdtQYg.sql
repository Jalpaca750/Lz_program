




--赠品入出库单审核操作（BillSts='20'审核/BillSts='10'取消审核)
--2007-09-19
--Devil.H
--当上述操作发生时：
--单据类型：10赠品入库单
--         审核：库存数量增加，取消审核库存数量减少
--	   20赠品出库单
--         审核：库存数量减少，取消审核库存数量增加
--2017-08-30 日修改，增加了审核时WMS状态的处理
CREATE Proc [dbo].[sp_IMSPresentAudit]
(
    @PresentNo VARCHAR(20),
    @Flag CHAR(2)
)
AS
BEGIN
    DECLARE @wmsBillNo VARCHAR(40),
            @remarks VARCHAR(2000),
            @DeptNo VARCHAR(20),
            @WareHouse VARCHAR(20),	
            @CreateDate CHAR(10),
            @AuditDate  CHAR(10),
            @Integral INT,
            @CustID BIGINT,
            @BillType CHAR(2),
            @IntegFlag BIT,
            @IsSYSIntegral BIT,
            @errors BIGINT;
    DECLARE @tmpTable TABLE(DeptNo VARCHAR(20),Warehouse VARCHAR(20),ItemId BIGINT,SQty DECIMAL(18,6));
	--如果单据处于中间状态，则跳出(WMS过度状态)
    IF EXISTS(SELECT 1 FROM IMS_Present WHERE PresentNo=@PresentNo AND billsts='15')
        RETURN;
    SET @errors=0;
    BEGIN TRANSACTION
    WHILE EXISTS(SELECT * FROM dbo.SAM_Schedule WHERE jobCode='inv_posting_job' AND IsLocked=1)
    BEGIN
        SET @errors=0;
    END
    UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='sp_IMSPresentAudit' WHERE jobCode='inv_posting_job';

	--系统积分启用标识
    SELECT @IsSYSIntegral=ISNULL(IsSYSIntegral,0) FROM Sys_Config;
	--获取更新后的入出库单号，日期
    SELECT @CustID=ISNULL(CustID,0),@IntegFlag=ISNULL(IntegFlag,0),@CreateDate=CreateDate,
        @AuditDate=AuditDate,@BillType=BillType,@WareHouse=WareHouse,@DeptNo=DeptNo,
        @wmsBillNo=wmsBillNo,@remarks=remarks 
    FROM IMS_Present 
    WHERE PresentNo=@PresentNo;
    SET @errors=@errors+@@ERROR;
	--总的积分
	SELECT @Integral=SUM(ISNULL(Integral,0.0)*ISNULL(SQty,0)) 
	FROM IMS_PresentDtl
	WHERE PresentNo=@PresentNo;
	SET @errors=@errors+@@ERROR;
	--临时库存数据(实物才扣减库存）
	INSERT INTO @tmpTable(DeptNo,Warehouse,ItemId,SQty)
	SELECT @DeptNo,@WareHouse,a.ItemId,SUM(a.SQty) AS SQty
	FROM IMS_PresentDtl a 
	    INNER JOIN BDM_ItemInfo b ON a.ItemId=b.ItemId
	WHERE a.PresentNo=@PresentNo AND b.IsVirtual=0
	GROUP BY a.ItemId;
	SET @errors=@errors+@@ERROR;
	--赠品入库单审核
	IF @Flag='20' And (@BillType='10')
	BEGIN
		--写入流水帐
        INSERT INTO IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,memo,wmsBillNo,remarks,CreateDate,AuditDate,editTime)
        SELECT PresentNo,'赠品入库单',@DeptNo,@WareHouse,ItemID,SQty,Price,Amt,remarks,@wmsBillNo,@remarks,@CreateDate,@AuditDate,GETDATE()
        FROM IMS_PresentDtl
        WHERE PresentNo=@PresentNo 
            AND NOT EXISTS(SELECT 1 FROM IMS_Flow WHERE BillNo=@PresentNo);
        SET @errors=@errors+@@ERROR;    
		--更新商品资料文件
		UPDATE a SET a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.SQty,0)
		FROM BDM_ItemInfo a 
		    INNER JOIN @tmpTable b On a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;    
		--更新分部库存文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM IMS_Subdepot a 
		    INNER JOIN @tmpTable b ON a.DeptNo=b.DeptNo AND a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;		
		--插入没有的分部库存商品
		INSERT INTO IMS_Subdepot(DeptNo,ItemID,OnHandQty)
		SELECT DeptNo,ItemID,ISNULL(SQty,0.0)
		FROM @tmpTable a
		WHERE NOT EXISTS(SELECT 1 FROM IMS_Subdepot b WHERE a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID);
		SET @errors=@errors+@@ERROR;
		
		--更新库房总帐文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0),a.LastIDate=@CreateDate
		FROM IMS_Ledger a 
		    INNER JOIN @tmpTable b ON a.warehouse=b.warehouse AND a.itemId=b.itemId;
		SET @errors=@errors+@@ERROR;
		--插入没有的文件
		INSERT INTO IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastIDate)
		SELECT DeptNo,WareHouse,ItemID,SQty,@CreateDate
		FROM @tmpTable a
		WHERE NOT EXISTS(SELECT 1 FROM IMS_Ledger b WHERE a.WareHouse=b.WareHouse And a.ItemID=b.ItemID);
		SET @errors=@errors+@@ERROR;
	END
	--赠品入出库单取消审核
	IF @Flag='10' And (@BillType='10')
	BEGIN
		--删除流水帐
		DELETE FROM IMS_Flow WHERE BillNo=@PresentNo;
		SET @errors=@errors+@@ERROR;
		--更新商品资料文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0)-ISNULL(b.SQty,0)
		FROM BDM_ItemInfo a 
		    INNER JOIN @tmpTable b ON a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;    
		--更新分部库存文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0)-ISNULL(b.SQty,0)
		FROM IMS_Subdepot a 
		    INNER JOIN @tmpTable b ON a.DeptNo=b.DeptNo AND a.itemId=b.itemid;
		SET @errors=@errors+@@ERROR;
		--更新库房总帐文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0)-ISNULL(b.SQty,0)
		FROM IMS_Ledger a 
		    INNER JOIN @tmpTable b On a.warehouse=b.warehouse AND a.itemId=b.itemId
		SET @errors=@errors+@@ERROR;
	END
	--赠品出库单审核操作
	IF @Flag='20' And (@BillType='20')
	BEGIN
		--如果扣减积分
		IF (@IntegFlag=1 and @CustID>0)
		BEGIN
			UPDATE BDM_Customer SET Deduct=ISNULL(Deduct,0.0)+@Integral WHERE CustID=@CustID; 
			SET @errors=@errors+@@ERROR;
		END
		--写入流水帐
		INSERT INTO IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,memo,wmsBillNo,remarks,CreateDate,AuditDate)
		SELECT PresentNo,'赠品出库单',@DeptNo,@WareHouse,ItemID,-SQty,Price,-Amt,remarks,@wmsBillNo,@remarks,@CreateDate,@AuditDate 
		FROM IMS_PresentDtl 
		WHERE PresentNo=@PresentNo 
			AND NOT EXISTS(SELECT 1 FROM IMS_Flow WHERE BillNo=@PresentNo);
		SET @errors=@errors+@@ERROR;
			
		--更新商品资料文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
		FROM BDM_ItemInfo a 
		    INNER JOIN @tmpTable b ON a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
				
		--更新分部库存文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
		FROM IMS_Subdepot a 
		    INNER JOIN @tmpTable b ON a.DeptNo=b.DeptNo AND a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
		  
		--更新库房总帐文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0),a.LastODate=@CreateDate
		FROM IMS_Ledger a 
		    INNER JOIN @tmpTable b ON a.Warehouse=b.Warehouse AND a.ItemId=b.ItemId;
	    SET @errors=@errors+@@ERROR;		    
		--插入没有的文件
		INSERT INTO IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastIDate)
		SELECT DeptNo,WareHouse,ItemID,-SQty,@CreateDate
		FROM @tmpTable a
		Where NOT EXISTS(SELECT 1 FROM IMS_Ledger b WHERE a.WareHouse=b.WareHouse And a.ItemID=b.ItemID);
		SET @errors=@errors+@@ERROR;
	End
	--赠品出库单取消审核
	IF @Flag='10' And (@BillType='20')
	BEGIN
		--删除流水帐
		DELETE FROM IMS_Flow WHERE BillNo=@PresentNo;
		--如果扣减积分
		IF @IntegFlag=1 and @CustID>0
		BEGIN
			UPDATE BDM_Customer SET Deduct=ISNULL(Deduct,0.0)-@Integral WHERE CustID=@CustID;
			SET @errors=@errors+@@ERROR;
	    END
		--更新商品资料文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM BDM_ItemInfo a 
		    INNER JOIN @tmpTable b ON a.itemId=b.itemId;
		SET @errors=@errors+@@ERROR;
		 
		--更新分部库存文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM IMS_Subdepot a 
		    INNER JOIN @tmpTable b ON a.DeptNo=b.DeptNo AND a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
		   
		--更新库房总帐文件
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM IMS_Ledger a 
		    INNER JOIN @tmpTable b On a.Warehouse=b.Warehouse AND a.ItemId=b.ItemId;
		SET @errors=@errors+@@ERROR;
	END
    UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='inv_posting_job';
    SET @errors=@errors+@@ERROR;
	IF (@errors=0)
	BEGIN
	    COMMIT;
	END
	ELSE
	BEGIN
	    IF @@TRANCOUNT > 0
            ROLLBACK;
        UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='inv_posting_job';
	END
END

go

