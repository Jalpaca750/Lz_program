--说明：客户销售排行榜
--作者：Devil.H
--创建：2010.05.31
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:分部
--	@Flag：标志
CREATE FUNCTION dbo.fn_AnalSMS10
(
	@StartDate VARCHAR(10)='0000-01-01',
	@EndDate VARCHAR(10)='9999-12-31',
	@CorpNo VARCHAR(2)='',
	@DeptNo VARCHAR(20)='',
	@ClASsID VARCHAR(20),
	@LabelID VARCHAR(20),
	@Flag BIT=0
)
RETURNS @uTABLE TABLE(
	CustID BIGINT,
	CustNo VARCHAR(20),
	CustName VARCHAR(200),
	NameSpell VARCHAR(200),
	LinkMan VARCHAR(40),
	Phone VARCHAR(80),
	Faxes VARCHAR(80),
	AreaCode VARCHAR(20),
	AreaName VARCHAR(100),
	MemberID VARCHAR(20),
	Member VARCHAR(100),
	PopedomID VARCHAR(20),
	PopedomName VARCHAR(100),
	CustType VARCHAR(20),
	TypeName VARCHAR(100),
	TradeName VARCHAR(100),
	KindName VARCHAR(100),
	SalesID BIGINT,
	Sales VARCHAR(100),
	SellQty DECIMAL(18,6),            --销售数量不带赠品
	SellAmt DECIMAL(18,6),            --总销售额
    RealAmt DECIMAL(18,6),            --实际销售额(去掉返点，平台费)
    RebateAmt DECIMAL(18,6),          --返点
    PlatformFee DECIMAL(18,6),        --平台费
	DepartId VARCHAR(20),
	DepartName VARCHAR(40)
)
AS
BEGIN	
	IF (@Flag=0) 
		RETURN;
    DECLARE @AmtDec INT;
    SELECT @AmtDec=ISNULL(AmtDec,2) FROM SYS_Config;
	--初始化变量
	SET @StartDate=CONVERT(CHAR(10),CAST(@StartDate AS DATETIME),23);
	SET @EndDate=CONVERT(CHAR(10),CAST(@EndDate AS DATETIME),23);

	INSERT INTO @uTABLE(CustID,CustNo,CustName,NameSpell,AreaCode,AreaName,MemberID,Member,
        PopedomID,PopedomName,CustType,TypeName,KindName,TradeName,SalesID,Sales,
        LinkMan,Phone,Faxes,SellQty,SellAmt,DepartId,DepartName,RebateAmt,PlatformFee,RealAmt)
	SELECT t.CustID,p.CustNo,p.CustName,p.NameSpell,p.AreaCode,p.AreaName,p.MemberID,p.Member,
		p.PopedomID,p.PopedomName,p.CustType,p.TypeName,p.KindName,p.TradeName,p.SalesID,
		p.Sales,p.LinkMan,p.Phone,p.Faxes,t.SQty,t.Amt,t.DepartId,d.CHName,t.RebateAmt,
        t.PlatformFee,t.Amt-t.PlatformFee-t.RebateAmt
	FROM (SELECT a.CustID,a.DepartId,SUM(ISNULL(b.SQty,0.0)) AS SQty,SUM(ISNULL(b.Amt,0.0)) AS Amt,
                ROUND(SUM(ISNULL(b.Amt,0.0)*c.Rebate/100.0),@AmtDec) RebateAmt,
                ROUND(SUM(ISNULL(b.Amt,0.0)*c.PlatformFee/100.0),@AmtDec) PlatformFee
		  FROM SMS_Stock a 
                INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
                INNER JOIN BDM_Customer c ON a.CustID=c.CustID
		  WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30') 
                AND (CONVERT(CHAR(10),CAST(a.CreateDate AS DATETIME),23) Between @StartDate And @EndDate)
			    AND (a.DeptNo Like @DeptNo + '%')
			    AND Exists(SELECT 1 
				           FROM BDM_DeptCode_V d 
				           WHERE (d.CodeID=a.DeptNo) AND (d.DeptNo Like @CorpNo + '%'))
			    AND Exists(SELECT 1
				           FROM BDM_ItemInfo g
				           WHERE (b.ItemID=g.ItemID) AND (g.ClASsID Like @ClASsID + '%') AND (g.LabelID Like @LabelID + '%'))
            GROUP BY a.CustID,a.DepartId) t 
        INNER JOIN BAS_Customer_V p ON t.CustID=p.CustID
        LEFT JOIN BDM_DeptCode_V d ON t.DepartId=d.CodeID
	--返回
 	RETURN
END
go

