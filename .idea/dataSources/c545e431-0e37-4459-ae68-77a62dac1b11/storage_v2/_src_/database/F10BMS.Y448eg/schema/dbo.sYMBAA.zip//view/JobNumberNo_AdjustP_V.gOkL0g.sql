CREATE VIEW dbo.JobNumberNo_AdjustP_V AS
--显示出可供调整商品的批号主列表
SELECT a.WareHouseID,sum(A.QTY+A.TQTY-ISNULL(a.OQty,0)) As AvailQty,T.OnHandQty,
b.CHName As WareHouseName, 
C.ItemID,c.ItemNo, c.ItemName, c.NameSpell,c.ItemSpec,c.ItemAlias,c.BarCode,c.ItemPHFlag,c.ItemPHName 
FROM dbo.JobNumberNo_In a
INNER JOIN  dbo.IMS_Ledger_V T           ON a.WareHouseID=T.WareHouse and a.itemid=T.itemid
INNER JOIN  dbo.BDM_WareHouse_V b ON a.WareHouseID = b.CodeID 
INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
group by c.ItemID, a.WareHouseID,b.CHName, 
c.ItemNo, c.ItemName, c.NameSpell,c.ItemSpec,c.ItemAlias,c.BarCode,c.ItemPHFlag,c.ItemPHName ,T.OnHandQty

go

