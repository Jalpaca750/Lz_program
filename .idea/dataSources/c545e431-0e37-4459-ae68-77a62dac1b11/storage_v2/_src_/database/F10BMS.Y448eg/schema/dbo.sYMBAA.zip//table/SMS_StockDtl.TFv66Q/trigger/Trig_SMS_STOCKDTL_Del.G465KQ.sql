--销售出库单细删除操作（BillSts='20'审核/BillSts='10'取消审核)
--2005-01-22
--Devil.H
--当上述操作发生时：
--当前订单已出库数量减少
CREATE Trigger Trig_SMS_STOCKDTL_Del
On dbo.SMS_StockDtl
--with encryption
For Delete
As
Begin
	declare @OrderNo varchar(20)
	declare @StockID bigint
	declare @OrderID bigint
	--已出库数量更新
	Update a Set a.SQty=Isnull(a.SQty,0)-Isnull(b.SQty,0),
		a.SZQty=isnull(a.SZQty,0)-Isnull(b.ZQty,0)
	From SMS_OrderDtl a,Deleted b
	Where a.OrderID=b.OrderID
	--已分配数量减少
	declare mycursors cursor
	for Select StockID,isnull(OrderID,'') from Deleted 
	open mycursors
	fetch next from mycursors into @StockID,@OrderID
	while @@fetch_Status=0
	begin
			--订单编号
			Select @OrderNo=OrderNo From SMS_OrderDtl Where OrderID=@OrderID
			--存在未执行的记录
			if exists(Select * from SMS_OrderDtl_V Where Isnull(SQty,0)>0 And OrderNo=@OrderNo)
				Update SMS_Order Set BillSts='25' Where OrderNo=@OrderNo And BillSts<>'05'
			else
				Update SMS_Order Set BillSts='20' Where OrderNo=@OrderNo And BillSts<>'05'

		fetch next from mycursors into @StockID,@OrderID
	end
	close mycursors
	deallocate mycursors
	
End
go

