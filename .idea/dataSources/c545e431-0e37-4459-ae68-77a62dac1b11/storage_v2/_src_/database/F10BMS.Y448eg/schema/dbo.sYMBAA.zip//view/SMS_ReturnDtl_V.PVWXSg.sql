CREATE VIEW dbo.SMS_ReturnDtl_V
AS
SELECT a.ReturnID, a.ReturnNo, e.CreateDate, e.BillSts, a.StockID, a.StockNo, 
    a.WareHouse, ISNULL(f.Location, a.Location) AS Location, a.ItemID, c.ItemNo, 
    c.ItemName, c.ItemAlias, c.NameSpell, c.ItemSpec, c.BarCode, c.ClassID, 
    c.ClassName, c.LabelID, c.LabelName, c.ColorName, c.UnitName, 
    ISNULL(b.SQty, 0.0) - ISNULL(b.RQty, 0.0) AS RemRQty, 
    ISNULL(b.ZQty, 0.0) - ISNULL(b.RZQty, 0.0) 
    AS RemRZQty, c.PkgSpec, a.PkgQty, a.RQty, a.Price, a.Amt, a.ZQty, a.IsSpecial, 
    a.TaxFlag, c.PPrice, c.SPrice, c.SPrice1, c.SPrice2, c.Package, c.MPackage, 
    c.BPackage, c.SPrice3, f.OnHandQty, c.PkgRatio, c.Integral, a.Remarks, a.CheckBox, 
    c.ItemPHFlag, c.ItemPHName, a.Integral AS DtlIntegral, e.CustID,v.CustNo,v.CustName,
    cb.CHName AS CostsName,e.poNo,e.SendAddr,e.LinkMan,e.Phone,e.SalesID,
    s.EmployeeName AS SalesName
FROM SMS_ReturnDtl a 
    INNER JOIN SMS_Return e ON a.ReturnNo = e.ReturnNo 
    INNER JOIN BAS_Goods_V c ON a.ItemID = c.ItemID
    INNER JOIN BDM_Customer_V v ON e.CustID=v.CustID
    LEFT JOIN IMS_Ledger f ON a.WareHouse = f.WareHouse AND a.ItemID = f.ItemID 
    LEFT JOIN SMS_StockDtl b ON a.StockID = b.StockID 
    LEFT JOIN Web_Costs_Class cb ON e.CostsID = cb.CostsID
    LEFT JOIN BDM_Employee s ON e.SalesID=s.EmployeeID
go

