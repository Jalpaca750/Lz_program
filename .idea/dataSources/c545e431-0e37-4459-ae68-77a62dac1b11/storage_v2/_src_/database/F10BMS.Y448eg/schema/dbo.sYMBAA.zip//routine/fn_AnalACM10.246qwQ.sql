--说明：客户预付款分析
--作者：Devil.H
--创建：2010.07.05
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag：标志
CREATE Function dbo.fn_AnalACM10
(
	@StartDate char(10)='2000-01-01',
	@EndDate char(10)='2000-01-01',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	CustID bigint,
	CustNo varchar(20),
	CustName varchar(200),
	NameSpell varchar(200),
	AreaCode varchar(20),
	AreaName varchar(100),
	MemberID varchar(20),
	Member varchar(100),
	PopedomID varchar(20),
	PopedomName varchar(100),
	CustType varchar(20),
	TypeName varchar(100),
	SalesID bigint,
	Sales varchar(100),
	KindName varchar(100),
	TradeName varchar(100),
	AdvAmt decimal(18,6),
	OffAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40),
	DepartId varchar(20),
	DepartName varchar(100)	
)
As
Begin	
	if @Flag=0
		Return
	--初始化变量
	Set @StartDate=Convert(Char(10),Cast(@StartDate as datetime),120)
	Set @EndDate=Convert(Char(10),Cast(@EndDate as datetime),120)
	--临时表
	declare @Tmp Table(CustID bigint,DepartId varchar(20),AdvAmt decimal(18,6),OffAmt decimal(18,6))
	Insert Into @Tmp(CustID,DepartId,AdvAmt,OffAmt)
	Select b.CustID,a.DepartId,Sum(AdvAmt),0.0 as OffAmt
	From SMS_Advances a inner join SMS_AdvancesDtl b On a.AdvancesNo=b.AdvancesNo
	Where (a.BillSts='20') 
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By b.CustID,a.DepartId
	Union All
	Select CustID,DepartId,0.0 as AdvAmt,Sum(AdvAmt)
	From SMS_Payment a
	Where (BillSts='20') And Isnull(AdvFlag,0)=1
		And (Convert(char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By CustID,DepartId
	
	--写入表值函数	
	Insert Into @uTable(CustID,AdvAmt,OffAmt,CustNo,CustName,NameSpell,AreaCode,AreaName,SalesID,Sales,
			MemberID,Member,PopedomID,PopedomName,CustType,TypeName,KindName,TradeName,LinkMan,
			Phone,Faxes,DepartId,DepartName)
	Select a.CustID,a.AdvAmt,a.OffAmt,b.CustNo,b.CustName,b.NameSpell,b.AreaCode,b.AreaName,b.SalesID,
			b.Sales,b.MemberID,b.Member,b.PopedomID,b.PopedomName,b.CustType,b.TypeName,b.KindName,
			b.TradeName,b.LinkMan,b.Phone,b.Faxes,a.DepartId,d.CHName
	From (Select DepartId,CustID,SUM(ISNULL(AdvAmt,0.0)) As AdvAmt,SUM(ISNULL(OffAmt,0.0)) AS OffAmt 
		From @Tmp
		Group By DepartId,CustID) a INNER JOIN BAS_Customer_V b On a.CustID=b.CustID
              LEFT JOIN BDM_DeptCode_V d ON a.DepartId=d.CodeID
	Return
End
go

