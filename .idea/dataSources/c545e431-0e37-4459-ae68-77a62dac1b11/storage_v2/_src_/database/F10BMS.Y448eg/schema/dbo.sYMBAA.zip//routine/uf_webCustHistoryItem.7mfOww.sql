
CREATE  Function [dbo].[uf_webCustHistoryItem]
(
@DeptNo varchar(20),
@CustID varchar(20),
@Flag bit
)
Returns @uTable Table(
ItemID bigint,
ItemNo varchar(20),
ItemName varchar(80),
ItemSpec varchar(80),
ItemAlias varchar(80),
NameSpell varchar(80),
ColorName varchar(40),
BarCode varchar(30),
Defined1 varchar(80),
Defined2 varchar(80),
Defined3 varchar(80),
Defined4 varchar(80),
Defined5 varchar(80),
ClassID varchar(20),
ClassName varchar(40),
LabelID varchar(20),
LabelName varchar(40),
UnitName varchar(40),
Price decimal(18,6),
OQty decimal(18,6),
AvailQty decimal(18,6),
OnHandQty decimal(18,6),
YZStockQty decimal(18,6),--预占数量
YZStock_Qty decimal(18,6),--排除预占数量
BD_AvailQty decimal(18,6),
BD_OnHandQty decimal(18,6),
LstDate char(10),
BPackage varchar(40),
MPackage varchar(40),
Package varchar(40),
PurDays varchar(40),
SPrice decimal(18,6),
SPrice1 decimal(18,6),
SPrice2 decimal(18,6),
SPrice3 decimal(18,6),
PPrice decimal(18,6),
HotFlag bit,
Remarks varchar(2000),
ITEMPHFLAG varchar(1),
ITEMPHName varchar(20),
ScClassName varchar(100),
ScClassId varchar(20)
)
As
Begin 
if @Flag=0 
return
--获取商品、单价
Insert Into @uTable(ItemID,ItemNo,ItemName,ItemSpec,ColorName,UnitName,ClassID,
ClassName,LabelID,LabelName,ItemAlias,BarCode,NameSpell,Defined1,Defined2,
Defined3,Defined4,Defined5,BPackage,MPackage,Package,SPrice,SPrice1,
SPrice2,SPrice3,PPrice,Price,PurDays,HotFlag,ItemPHFlag,ItemPHName,ScClassName,ScClassId,
OnHandQty,AvailQty,BD_OnHandQty,BD_AvailQty,YZStockQty,YZStock_Qty,Remarks)
Select a.ItemID,b.ItemNo,b.ItemName,b.ItemSpec,b.ColorName,b.UnitName,b.ClassID,
b.ClassName,b.LabelID,b.LabelName,b.ItemAlias,b.BarCode,b.NameSpell,
b.Defined1,b.Defined2,b.Defined3,b.Defined4,b.Defined5,b.BPackage,
b.MPackage,b.Package,b.SPrice,b.SPrice1,b.SPrice2,b.SPrice3,b.PPrice,
a.Price,b.PurDays,b.HotFlag,b.ItemPHFlag,b.ItemPHName,tm.ScClassName,tm.ScClassId,b.OnhandQty,
0.0 As AvailQty,t.BD_OnHandQty,t.BD_AvailQty,t.YZStockQty,
Isnull(t.BD_OnHandQty,0.0)-Isnull(t.YZStockQty,0.0) As YZStock_Qty,
b.Remarks

From SMS_Price a 
 inner join BAS_Goods_V b on a.ItemID=b.ItemID
 Left Outer Join (Select m.ItemID,m.OnHandQty As BD_OnHandQty,
 m.AvailQty As BD_AvailQty,n.Qty As YZStockQty
  From IMS_Store_V m Left Outer Join IMS_YZStock_Sum_DeptID_V n On m.DeptNo=n.DeptNo And m.ItemID=n.ItemID
  Where m.DeptNo=@DeptNo) t On a.ItemID=t.ItemID
 left join (
Select sc.ClassName as ScClassName,sc.ClassId as ScClassId,us.ProductID
From WEB_User_SC us left Join WEB_SC_Class sc on (us.Sc_Class = sc.ClassId)
where us.CustId=@CustID and sc.UserType='cust') tm on a.ItemId = tm.ProductID
Where a.CustID=@CustID 
AND b.Flag=1
--删除无效数据
Delete From @uTable Where isnull(ItemNo,'')=''
return
End


go

