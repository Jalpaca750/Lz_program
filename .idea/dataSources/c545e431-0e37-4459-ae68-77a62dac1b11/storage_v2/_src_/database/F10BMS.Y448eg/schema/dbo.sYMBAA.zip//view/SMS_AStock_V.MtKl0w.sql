CREATE VIEW dbo.SMS_AStock_V
AS
SELECT a.StockNo, a.CreateDate, a.DeptNo, c.CHName AS DeptName, a.WareHouse, 
      g.CHName AS WHName, a.CustID, b.CustNo, b.CustName, b.NameSpell, b.CustType, 
      b.TypeName, b.MemberID, b.Member, b.AreaCode, b.AreaName, b.PopedomID, 
      b.PopedomName, b.LinkMan, b.Phone, b.Faxes, a.SalesID,j.EmployeeName AS Sales, 
      f.SQty, f.Amt, a.PaidDate, a.PaidUp, a.PaidAmt, a.DiscAmt, a.BillType, a.BillSts, 
      (SELECT StsName FROM BillStatus k WHERE a.BillSts=k.BillSts And k.BillType = 'SMS4A') AS StsName, 
      a.BackDate, a.SendDate, a.SendTime, a.SendAddr,a.SendID, i.CHName AS SendMode, 
      a.CreatorID, d.EmployeeName AS Creator,a.PrintNum,a.PrinterID,p.EmployeeName As Printer, 
      a.AuditDate, a.AuditID, e.EmployeeName AS Auditer, a.Delivery, h.EmployeeName AS DeliveryMan, 
      a.Integral, a.PFlag, a.Remarks, a.CheckBox,b.Defined1,F.SUMDtlIntegral,a.AuditingPICFlag, 
      a.WLFlag, a.PH_OperatorID, PH.EmployeeName AS PH_Operator, a.PH_DateTime,a.BoxupSts,StockNo_O,
      a.CarNumberSts, f.SQty As ZQty, f.Amt As ZAmt, a.CostsID, cb.CHName As CostsName,a.orderreninfo
FROM dbo.SMS_AStock a LEFT OUTER JOIN      
      dbo.BDM_Employee PH ON a.PH_OperatorID = PH.EmployeeID LEFT OUTER JOIN      
      dbo.BDM_Employee j ON a.SalesID = j.EmployeeID LEFT OUTER JOIN      
      dbo.BDM_SendMode_V i ON a.SendID = i.CodeID LEFT OUTER JOIN
      dbo.BDM_Employee h ON a.Delivery = h.EmployeeID LEFT OUTER JOIN
      dbo.BDM_WareHouse_V g ON a.WareHouse = g.CodeID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V c ON a.DeptNo = c.CodeID LEFT OUTER JOIN
      dbo.BAS_Customer_V b ON a.CustID = b.CustID LEFT OUTER JOIN
      dbo.BDM_Employee e ON a.AuditID = e.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee d ON a.CreatorID = d.EmployeeID LEFT OUTER JOIN
      dbo.Web_Costs_Class cb ON a.CostsID = cb.CostsID LEFT OUTER JOIN
      dbo.BDM_Employee p ON a.PrinterID=p.EmployeeID LEFT OUTER JOIN
      (SELECT StockNo, SUM(SQty) AS SQty, SUM(Amt) AS Amt, 
		SUM(Isnull(SQty, 0.0) * isnull(Integral, 0.0)) AS SUMDtlIntegral
       FROM SMS_AStockDtl
       GROUP BY StockNo) f ON a.StockNo = f.StockNo 
go

