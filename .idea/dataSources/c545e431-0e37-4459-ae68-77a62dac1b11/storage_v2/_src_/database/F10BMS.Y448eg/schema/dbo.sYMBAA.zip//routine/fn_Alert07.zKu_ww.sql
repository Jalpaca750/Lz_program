--说明：未调拨申请提醒
--作者：Devil.H
--创建：2010.03.24
--参数：
--	无
CREATE FUNCTION fn_Alert07
(
)
RETURNS TABLE
AS
RETURN (
    SELECT a.OrderNo,a.CreateDate,g.ItemNo,g.ItemName,g.ItemSpec,g.ColorName,
		g.UnitName,b.OQty,ISNULL(OQty,0.0)-ISNULL(DQty,0.0) AS RemDQty,
		do.CHName AS DeptName_A,di.CHName AS DeptName,
		e.EmployeeName AS Creator,a.Remarks
	FROM PMS_Order a INNER JOIN PMS_OrderDtl b ON a.OrderNo=b.OrderNo
		INNER JOIN BDM_ItemInfo_V g ON b.ItemID=g.ItemID
		LEFT OUTER JOIN BDM_DeptCode_V do ON do.CodeID=a.DeptNo_A
		LEFT OUTER JOIN BDM_DeptCode_V di ON di.CodeID=a.DeptNo
		LEFT OUTER JOIN BDM_Employee e ON a.CreatorID=e.EmployeeID
	WHERE (a.BillSts='20' Or a.BillSts='25') And a.BillType='调拨申请单'
		And (ISNULL(OQty,0.0)-ISNULL(DQty,0.0)<>0.0)
)
go

