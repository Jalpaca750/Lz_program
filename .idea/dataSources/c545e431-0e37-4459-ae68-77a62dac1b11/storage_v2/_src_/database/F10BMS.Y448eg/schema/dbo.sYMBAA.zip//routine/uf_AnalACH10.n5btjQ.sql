
--说明：销售员业绩统计
--作者：Devil.H
--创建：2007.11.15
--参数：
--	@Period:年月
--	@Flag:标识
CREATE function dbo.uf_AnalACH10
(	
	@Period char(6)='200001',
	@Flag bit=0
)
Returns @uTable Table(
	Period char(6),
	SalesID bigint,
	Sales varchar(20),
	DeptNo varchar(20),
	DeptName varchar(40),
	OrdAmt decimal(18,6),
	OrdQty decimal(18,6),
	InvAmt decimal(18,6),
	InvQty decimal(18,6),
	CstAmt decimal(18,6),
	GProAmt decimal(18,6),
	GProfit decimal(18,6),
	PayAmt decimal(18,6),
	PAmt decimal(18,6),
	PCstAmt decimal(18,6),
	PGProAmt decimal(18,6),
	PGProfit decimal(18,6)
)
--with encryption
As
begin
	declare @Year int
	declare @Month int
	declare @AmtDec int
	if @Flag=0
		Return
	declare @Tmp Table(
		SalesID bigint,
		OrdAmt decimal(18,6),
		OrdQty decimal(18,6),
		InvAmt decimal(18,6),
		InvQty decimal(18,6),
		CstAmt decimal(18,6),
		GProAmt decimal(18,6),
		GProfit decimal(18,6),
		PayAmt decimal(18,6),
		PAmt decimal(18,6),
		PCstAmt decimal(18,6),
		PGProAmt decimal(18,6),
		LSMSAmt decimal(18,6))
	Select @AmtDec=AmtDec From Sys_Config
	--当前月起始、截至日期
	Set @Year=Cast(Left(@Period,4) as int)
	set @Month=Cast(right(@Period,2) as int)


	--********增加会计月份时间处理***********************
	declare @CW_Month_BDate char(10)
	declare @CW_Month_EDate char(10)

	Set @CW_Month_BDate=(select CW_Month from dbo.uf_Get_CW_Month(1,@Year,@Month))
	Set @CW_Month_EDate=(select CW_Month from dbo.uf_Get_CW_Month(2,@Year,@Month))
	--**********************************************



	--统计销售订单金额
	Insert Into @Tmp(SalesID,OrdAmt,OrdQty)
	Select a.SalesID,Sum(Round(Isnull(b.Price,0)*Isnull(b.SQty,0),@AmtDec)) as OrdAmt,Sum(b.SQty) as OrdQty
	From SMS_Order a inner join SMS_OrderDtl b on a.OrderNo=b.OrderNo 
	Where (a.BillSts Not In('00')) 
		--And Year(a.CreateDate)=@Year And Month(a.CreateDate)=@Month
		And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
	Group By a.SalesID
	--统计销售出库单
	Insert Into @Tmp(a.SalesID,InvAmt,InvQty,CstAmt)
	Select a.SalesID,Sum(b.Amt) as Amt,Sum(b.SQty) as SQty,Sum(round(isnull(b.SQty,0)*isnull(b.CPrice,0),@AmtDec))
	From SMS_Stock a inner join SMS_StockDtl b on a.StockNo=b.StockNo
	Where (a.BillSts Not In('00','10')) 
		--And Year(a.CreateDate)=@Year And Month(a.CreateDate)=@Month
		And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
	Group By a.SalesID
	--统计当前月收款
	Insert Into @Tmp(SalesID,PayAmt)
	Select a.SalesID,Sum(b.PayAmt) as PayAmt 
	From SMS_Payment a inner join SMS_PaymentDtl b on a.PaymentNo=b.PaymentNo
	Where (a.BillSts Not in('00','10')) 
		--And Year(a.CreateDate)=@Year And Month(a.CreateDate)=@Month
		And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
	Group By a.SalesID
	--统计销售收现金
	Insert Into @Tmp(SalesID,PayAmt)
	Select SalesID,Sum(PaidAmt)
	From SMS_Stock
	Where BillSts Not In('00','10') And (Not Isnull(PaidAmt,0)=0)
		--And Year(PaidDate)=@Year And Month(PaidDate)=@Month
		And PaidDate Between @CW_Month_BDate And @CW_Month_EDate
		
	Group By SalesID
	--统计零售收现金
	Insert Into @Tmp(SalesID,PayAmt,PAmt)
	Select SalesID,Sum(Isnull(Amt,0)-isnull(DiscAmt,0)),Sum(Isnull(Amt,0)-isnull(DiscAmt,0))
	From SMS_Retail_V
	Where BillSts Not In('00','10') 
		--And Year(CreateDate)=@Year And Month(CreateDate)=@Month
		And CreateDate Between @CW_Month_BDate And @CW_Month_EDate
	Group By SalesID
	--统计已收完款的发票金额/成本金额
	Insert Into @Tmp(SalesID,PAmt,PCstAmt)
	Select SalesID,Isnull(Sum(PAmt),0)-Isnull(Sum(FAmt),0),Sum(CAmt)
	From SMS_Invoice_V
	Where BillSts Not In('00','10') 
		--And Year(PDate)=@Year And Month(PDate)=@Month
		And PDate Between @CW_Month_BDate And @CW_Month_EDate
		And Isnull(RemAmt,0)<=0 And Left(Invoice,2)<>'$$'
	Group By SalesID
	--统计零售部分成本
	Insert Into @Tmp(SalesID,PCstAmt)
	Select a.SalesID,Sum(round(isnull(b.SQty,0)*isnull(b.CPrice,0),@AmtDec))
	From SMS_Stock a inner join SMS_StockDtl b on a.StockNo=b.StockNo
	Where (a.BillSts Not In('00','10')) And a.BillType In('40','50')
		--And Year(a.CreateDate)=@Year And Month(a.CreateDate)=@Month
		And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
	Group By a.SalesID
	--汇总
	Insert Into @uTable(SalesID,OrdAmt,OrdQty,InvAmt,InvQty,CstAmt,GProAmt,PayAmt,PAmt,PCstAmt,PGProAmt)
	Select SalesID,Sum(OrdAmt),Sum(OrdQty),Sum(InvAmt),Sum(InvQty),Sum(CstAmt),
		isnull(Sum(InvAmt),0)-isnull(Sum(CstAmt),0),Sum(PayAmt),Sum(PAmt),Sum(PCstAmt),
		Isnull(Sum(PAmt),0)-Isnull(Sum(PCstAmt),0)
	From @Tmp
	Group By SalesID
	--更新毛利、毛利率
	Update @uTable Set GProfit=case Isnull(InvAmt,0) 
				when 0 then 0 
				else Round((Isnull(InvAmt,0)-Isnull(CstAmt,0))/Isnull(InvAmt,0),@AmtDec*2) end,
			PGProfit=Case Isnull(PAmt,0)
				When 0 then 0
				else	Round((Isnull(PAmt,0)-Isnull(PCstAmt,0))/Isnull(PAmt,0),@AmtDec*2) End
	--更新销售员ming
	Update a Set a.Sales=b.EmployeeName,a.DeptNo=left(b.DeptCode,4)
	From @uTable a,BDM_Employee b
	Where a.SalesID=b.EmployeeID
	--更新销售员所在部门
	Update a Set a.DeptName=CHName
	From @uTable a,BDM_DeptCode_V b
	Where a.DeptNo=b.CodeID
	--返回
	Return
End


go

