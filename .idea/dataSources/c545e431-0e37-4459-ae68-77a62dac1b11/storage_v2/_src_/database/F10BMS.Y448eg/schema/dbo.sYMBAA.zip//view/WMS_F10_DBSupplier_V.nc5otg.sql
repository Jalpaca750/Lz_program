
/*==============================================================*/
/* View: WMS_F10_DBSupplier_V                                   */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_DBSupplier_V] as
SELECT a.CodeID AS deptId,a.CHName AS deptName,p.partnerId AS supplierId,p.partnerNo AS supplierNo,p.partnerName AS supplierName
FROM dbo.BDM_DeptCode_V a
	INNER JOIN YiWms.dbo.BAS_Partner p ON a.CodeID=p.partnerNo
WHERE EXISTS (SELECT * FROM dbo.SYS_Config b WHERE p.companyId=b.companyId AND p.ownerId=b.ownerId AND p.partnerType=2)
go

