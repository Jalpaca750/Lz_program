CREATE VIEW Sales_Salary_Dtl_100
AS
SELECT
	dbo.Stock_Invoice_Payment.StockNo,
	dbo.Stock_Invoice_Payment.InvoiceNo,
	dbo.Stock_Invoice_Payment.PaymentNo,
	ROUND(dbo.Stock_Invoice_Payment.销售金额, 4) AS Expr1,
	ROUND(dbo.Stock_Invoice_Payment.发票金额, 4) AS 发票金额,
	ROUND(dbo.Stock_Invoice_Payment.回款金额, 4) AS Expr2,
	dbo.Stock_Invoice_Payment.销售成本,
	dbo.Stock_Invoice_Payment.销售毛利,
	ss.CreateDate AS 销售日期,
	dbo.SMS_Payment.CreateDate AS 回款日期,
	DATEDIFF(day, ss.CreateDate, dbo.SMS_Payment.CreateDate) AS 回款周期,
	DATEDIFF(day, ss.CreateDate, dbo.SMS_Payment.CreateDate) - dbo.BDM_Customer.ADays AS 超期天数,
	dbo.BDM_Customer.CustName AS 客户名称,
--	dbo.BDM_Employee.EmployeeName AS 业务员名称,
	(SELECT be.EmployeeName  from BDM_Employee be where be.EmployeeID = ss.SalesID) as 业务员名称,
	ROUND({ fn IFNULL(dbo.Stock_Invoice_Payment.免收金额, 0) }, 4) AS 免收金额
FROM
	dbo.Stock_Invoice_Payment
INNER JOIN
    dbo.SMS_Payment ON
	dbo.Stock_Invoice_Payment.PaymentNo = dbo.SMS_Payment.PaymentNo
INNER JOIN
    dbo.SMS_Stock ss ON
	dbo.Stock_Invoice_Payment.StockNo = ss.StockNo
INNER JOIN
    dbo.BDM_Customer ON
	ss.CustID = BDM_Customer.CustID
WHERE
	(dbo.SMS_Payment.BillSts = 20)
go

