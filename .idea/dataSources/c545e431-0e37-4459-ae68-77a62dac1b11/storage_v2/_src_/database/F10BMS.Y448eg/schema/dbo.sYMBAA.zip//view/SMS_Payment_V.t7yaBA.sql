CREATE VIEW dbo.SMS_Payment_V
AS
SELECT a.PaymentNo, a.CreateDate, a.DeptNo, g.CHName AS DeptName, a.CustID, b.CustNo,  
      b.CustName, b.NameSpell, b.CustType, b.TypeName, b.MemberID, b.Member, b.AreaCode,  
      b.AreaName, b.PopedomID, b.PopedomName, b.LinkMan, b.Phone, b.Faxes, a.SalesID,  
      s.EmployeeName AS Sales, a.Credence, a.PayMode,f.CHName AS PayName, a.Amt,a.AdvAmt,   
      a.HandlerID,h.EmployeeName As Handler, a.BillSts,a.AccountId,k.AccountNo,k.AccountName,a.AccountAmt, 
      (SELECT StsName FROM BillStatus i WHERE a.BillSts=i.BillSts And i.BillType='ACM10') AS StsName, 
      a.RedFlag,CASE a.RedFlag WHEN -1 THEN '红字' WHEN 0 THEN '蓝字' WHEN 1 THEN '冲红' END AS RedBill,
      a.AdvFlag, a.PFlag, a.AuditDate, a.AuditID, d.EmployeeName AS Auditer, a.CreatorID, 
      c.EmployeeName AS Creator,a.AuditingFlag,a.PrintNum,a.PrinterID,p.EmployeeName AS Printer,
      CASE a.AuditingFlag WHEN '0' THEN '否' 
                          WHEN '1' THEN '是' END AS ISAuditing,
      CASE WHEN a.AuditingFlag='0' THEN '' 
	   WHEN a.AuditingStatus='0' THEN '未通过' 
           WHEN a.AuditingStatus='1' THEN '通过' 
           ELSE '' END AS BillAuditing_Result,a.PayBank,a.PayAccount,a.PayMan, a.Remarks,a.SendBill, 
      a.CarNumberSts,a.CarNumberDate,a.DepartId,dt.CHName AS DepartName,a.CheckBox
FROM dbo.SMS_Payment a LEFT OUTER JOIN
	dbo.BDM_Employee s ON a.SalesID = s.EmployeeID LEFT OUTER JOIN
	dbo.BDM_DeptCode_V g ON a.DeptNo = g.CodeID LEFT OUTER JOIN
	dbo.BAS_Customer_V b ON a.CustID = b.CustID LEFT OUTER JOIN
	dbo.BDM_PayMode_V f ON a.PayMode = f.CodeID LEFT OUTER JOIN
	dbo.BDM_Employee d ON a.AuditID = d.EmployeeID LEFT OUTER JOIN
	dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID LEFT OUTER JOIN
	dbo.BDM_Employee p ON a.PrinterID=p.EmployeeID LEFT OUTER JOIN
	dbo.BDM_Employee h ON a.HandlerID=h.EmployeeID LEFT OUTER JOIN
	dbo.BDM_Account k ON a.AccountId=k.AccountId LEFT OUTER JOIN
	dbo.BDM_DeptCode_V dt ON a.DepartId=dt.CodeID

go

