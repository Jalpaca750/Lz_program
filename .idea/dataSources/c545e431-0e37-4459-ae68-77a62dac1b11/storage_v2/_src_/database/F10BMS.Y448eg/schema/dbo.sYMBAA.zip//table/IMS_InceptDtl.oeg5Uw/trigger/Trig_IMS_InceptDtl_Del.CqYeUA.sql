--调拨出库单单明细插入操作（Insert)
--2005-01-25
--Devil.H
--当上述操作发生时：
--更新订单的已入库数量，同时更新订单状态
CREATE Trigger Trig_IMS_InceptDtl_Del
On dbo.IMS_InceptDtl
--with encryption
For Delete
As
Begin
	declare @AllotNo varchar(20)
	--更新订单的已入库数量
	Update a Set a.IQty=Isnull(a.IQty,0)-Isnull(b.IQty,0)
	From IMS_AllotDtl a,Deleted b
	Where a.AllotID=b.AllotID
	--计划单
	declare mycursor cursor
	for select Distinct AllotNo from IMS_AllotDtl Where AllotID In(Select AllotID From Deleted)
	open mycursor
	fetch next from mycursor into @AllotNo
	while @@fetch_Status=0
	begin
		--存在未执行的记录
		if exists(Select 1 from IMS_AllotDtl Where Isnull(IQty,0)>0 And AllotNo=@AllotNo)
			Update IMS_Allot Set BillSts='25' Where AllotNo=@AllotNo
		else
			Update IMS_Allot Set BillSts='20' Where AllotNo=@AllotNo	
		fetch next from mycursor into @AllotNo
		
	end
	close mycursor
	deallocate mycursor
End
go

