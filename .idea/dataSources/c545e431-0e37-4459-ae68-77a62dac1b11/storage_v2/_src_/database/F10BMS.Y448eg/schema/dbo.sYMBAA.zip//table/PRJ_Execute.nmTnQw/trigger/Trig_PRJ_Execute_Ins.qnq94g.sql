CREATE Trigger Trig_PRJ_Execute_Ins
On dbo.PRJ_Execute
--with encryption
For Insert
As
Begin

	Update a Set a.ExecSts='正在执行' From PRJ_Order a,Inserted b Where a.BillNo=b.OrderNo
End
go

