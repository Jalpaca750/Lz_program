
CREATE VIEW dbo.SMS_Boxup_V
AS
SELECT a.BoxupNo, a.CreateDate, a.DeptNo, f.CHName AS DeptName, a.CustID, b.CustNo, 
      b.CustName, b.NameSpell, b.CustType, b.TypeName, b.MemberID, b.Member, 
      b.AreaCode, b.AreaName, b.PopedomID, b.PopedomName, a.BoxupRenID, a.BillType,
      Case a.BillType When '10' Then '销售出库单' When 20 Then '调拨出库单' End As BTName,
      h.EmployeeName AS BoxupRen, b.LinkMan, b.Phone, b.Faxes, a.SendAddr, e.HQty, 
      e.HAmt, a.BillSts, i.StsName, a.PFlag, a.CreatorID, d.EmployeeName AS Creator, 
      a.Remarks, a.CheckBox
FROM dbo.BDM_Employee h RIGHT OUTER JOIN
      dbo.SMS_Boxup a LEFT OUTER JOIN
      dbo.BillStatus i ON a.BillSts = i.BillSts ON 
      h.EmployeeID = a.BoxupRenID INNER JOIN
          (SELECT BoxupNo, SUM(ZAmt) AS HAmt, SUM(ZQty) AS HQty
         FROM SMS_BoxupDtl
         GROUP BY BoxupNo) e ON a.BoxupNo = e.BoxupNo LEFT OUTER JOIN
      dbo.BDM_Customer_V b ON a.CustID = b.CustID LEFT OUTER JOIN
      dbo.BDM_Employee d ON a.CreatorID = d.EmployeeID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V f ON a.DeptNo = f.CodeID
WHERE (i.BillType = 'SMS41')
go

