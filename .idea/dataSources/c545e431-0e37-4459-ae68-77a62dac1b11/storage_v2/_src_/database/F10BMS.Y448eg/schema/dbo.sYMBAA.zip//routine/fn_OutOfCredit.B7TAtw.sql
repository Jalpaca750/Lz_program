CREATE FUNCTION fn_OutOfCredit(@Flag bit)
RETURNS TABLE
AS
RETURN (Select CustID,CustNo,CustName,AreaCode,AreaName,PopedomID,PopedomName,
		CustType,TypeName,MemberID,Member,LinkMan,Phone,Faxes,SalesID,Sales,
		CreditAmt,ArgAmt,-isnull(CreditAmt,0)+isnull(ArgAmt,0) AS ExceedAmt 
	From BAS_Customer_V
	Where isnull(CreditAmt,0.0)>0.0 And (isnull(CreditAmt,0.0)-isnull(ArgAmt,0.0)<0.0)
)
go

