--企业性质
CREATE VIEW dbo.BDM_EKind_V
--with encryption
AS
SELECT CodeID, CodeNo, CHName, ENName, Flag,Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL05')
go

