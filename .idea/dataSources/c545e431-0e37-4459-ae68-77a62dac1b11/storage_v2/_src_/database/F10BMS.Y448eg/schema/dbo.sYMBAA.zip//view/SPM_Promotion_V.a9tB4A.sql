CREATE VIEW dbo.SPM_Promotion_V
AS
SELECT a.PromotionID, a.StartDate, a.EndDate, a.AreaCode, ISNULL(c.CHName, '所有地区') 
      AS AreaName, a.PopedomID, ISNULL(d.CHName, '所有辖区') AS PopedomName, 
      a.CustType, ISNULL(e.CHName, '所有类别') AS TypeName, a.MemberID, 
      ISNULL(f.CHName, '所有会员') AS Member, a.ItemID, b.ItemNo, b.ItemName, 
      b.ItemAlias, b.NameSpell, b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, 
      b.LabelID, b.LabelName, b.ColorName, b.UnitName, a.Price, b.BPackage, 
      b.MPackage, b.Package, b.PkgRatio, b.PkgSpec, b.PurDays, b.Origin, b.PPrice, 
      b.SPrice, b.SPrice1, b.SPrice2, b.SPrice3, b.SafePPrice, b.SafeSPrice, b.HotFlag, 
      b.NotDisc, b.Remarks
FROM dbo.SPM_Promotion a LEFT OUTER JOIN
      dbo.BDM_MemberCode_V f ON a.MemberID = f.CodeID LEFT OUTER JOIN
      dbo.BDM_CustType_V e ON a.CustType = e.CodeID LEFT OUTER JOIN
      dbo.BDM_PopedomCode_V d ON a.PopedomID = d.CodeID LEFT OUTER JOIN
      dbo.BDM_AreaCode_V c ON a.AreaCode = c.CodeID LEFT OUTER JOIN
      dbo.BDM_ItemInfo_V b ON a.ItemID = b.ItemID
go

