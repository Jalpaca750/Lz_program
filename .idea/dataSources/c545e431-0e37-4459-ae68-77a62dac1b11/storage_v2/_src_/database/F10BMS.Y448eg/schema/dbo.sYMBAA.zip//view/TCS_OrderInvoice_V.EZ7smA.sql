
create view TCS_OrderInvoice_V as
/*
--带Bone平台，按订单开票
SELECT a.orderNo,a.billNo AS orderBillNo,b.packageId AS boneOrderPkgId,b.billNo AS boneOrderPkgBillNo,
    a.companyId AS corpId,o.DeptNo AS orgId,o.DeptNo AS orgNo,d.CHName AS orgName,a.poNo,
    CAST(o.CustID AS VARCHAR(32)) AS customerId,c.CustNo AS customerNo,c.CustName AS customerName,
    a.receiverAddress,a.receiverName,ISNULL(a.receiverMobile,'')+ISNULL(a.receiverTel,'') AS fullPhone,
    a.invoiceFlag,(CASE invoiceflag WHEN 0 THEN '不开票' WHEN 1 THEN '普票(纸)' WHEN 2 THEN '专票(纸)' WHEN 3 THEN '普票(电)' WHEN 4 THEN '专票(电)' END) AS invoiceType,
    a.invoiceCompany,a.invoiceTax,a.invoiceAddress,a.invoiceTel,a.invoiceAccount,a.invoiceBank,
    ISNULL(a.totalFee,0.0)-ISNULL(t.totalFee,0.0) AS totalFee,ISNULL(t.totalFee,0.0) AS invFee,v.partnerNo AS vendorNo,
    v.partnerName AS vendorName,CASE ISNULL(v.partnerId,'') WHEN '' THEN '我方' ELSE '服务商' END AS deliverFlag,
    o.billSts AS orderState,(SELECT StsName FROM dbo.BillStatus WHERE BillType='SMS30' AND BillSts=o.BillSts) AS stateDesc,
    ISNULL(t.invoiceState,'10') AS invoiceState,
    CASE ISNULL(t.invoiceState,'10') WHEN '10' THEN '待开票' WHEN '20' THEN '开票中' WHEN '30' THEN '已开票' ELSE '已作废' END AS invoiceStateDesc,
    CONVERT(VARCHAR(10),a.orderDate,23) AS orderDate,CONVERT(VARCHAR(20),a.createTime,120) AS createTime,o.Remarks AS memo
FROM Bone.dbo.ECM_Order a
    INNER JOIN Bone.dbo.ECM_OrderEx b ON a.orderNo=b.orderNo
    INNER JOIN Bone.dbo.TP_Platform p ON a.orderSource=p.platformId
    INNER JOIN dbo.SMS_Order o ON a.billNo=o.OrderNo
    INNER JOIN dbo.BDM_Customer c ON o.CustID=c.CustID
    INNER JOIN dbo.BDM_DeptCode_V d ON o.DeptNo=d.CodeID
    INNER JOIN Bone.dbo.BAS_Partner c1 ON a.oCustomerId=c1.partnerId
    LEFT JOIN Bone.dbo.BAS_Partner v ON c1.refSupplierId=v.partnerId
    LEFT JOIN (SELECT boneOrderNo,SUM(totalFee) AS totalFee,MIN(invoiceState) AS invoiceState
               FROM dbo.TCS_Order
               WHERE invoiceState IN('10','20','30','-1')
               GROUP BY boneOrderNo
               --HAVING SUM(totalFee)>0.0
               ) t ON a.orderNo=t.boneOrderNo
WHERE (o.BillSts IN('00','10','20','25','30'))
    AND ISNULL(a.totalFee,0.0)-ISNULL(t.totalFee,0.0)>0.0
    AND NOT EXISTS(SELECT * FROM SMS_OrderInvoice_V inv WHERE inv.PoNo=a.poNo)
UNION ALL
*/
SELECT a.StockNo AS orderNo,a.StockNo AS orderBillNo,a.StockNo AS boneOrderPkgId,a.StockNo AS boneOrderPkgBillNo,
    d.corpId,a.DeptNo AS orgId,a.DeptNo AS orgNo,d.CHName AS orgName,a.poNo,a.CustID AS CustomerId,c.CustNo AS CustomerNo,
    c.CustName AS customerName,a.SendAddr AS receiverAddress,a.LinkMan AS receiverName,a.Phone AS fullPhone,ex.invoiceFlag,
    CASE ex.invoiceFlag WHEN 1 THEN '普票(纸)' WHEN 2 THEN '专票(纸)' WHEN 3 THEN '普票(电)' WHEN 4 THEN '专票(电)' ELSE '不开票' END AS invoiceType,
    ex.invoiceCompany,ex.invoiceTax,ex.invoiceAddress,ex.invoiceTel,ex.invoiceAccount,ex.invoiceBank,
    ISNULL(dtl.totalFee,0.0)-ISNULL(t.totalFee,0.0) AS totalFee,ISNULL(t.totalFee,0.0) AS invFee,
    '' AS vendorNo,'' AS vendorName,'我方' AS deliverFlag,a.billSts AS orderState,
    (SELECT StsName FROM dbo.BillStatus WHERE BillType='SMS40' AND BillSts=a.BillSts) AS stateDesc,
    ISNULL(t.invoiceState,'10') AS invoiceState,
    CASE ISNULL(t.invoiceState,'10') WHEN '10' THEN '待开票' WHEN '20' THEN '开票中' WHEN '30' THEN '已开票' ELSE '已作废' END AS invoiceStateDesc,
    a.CreateDate AS orderDate,CONVERT(VARCHAR(20),a.editTime,120) AS createTime,a.Remarks AS memo
FROM SMS_Stock a
    INNER JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
    INNER JOIN BAS_Customer_V c ON a.CustID=c.CustID
    INNER JOIN (SELECT StockNo,SUM(Amt) AS totalFee FROM SMS_StockDtl GROUP BY StockNo) dtl ON a.StockNo=dtl.StockNo
    LEFT JOIN SMS_StockEx ex ON a.StockNo=ex.StockNo
    LEFT JOIN (SELECT y.orderNo,SUM(CAST(y.taxIncludedAmount AS DECIMAL(20,2))) AS totalFee,MIN(x.invoiceState) AS invoiceState
               FROM dbo.TCS_Order x
                   INNER JOIN TCS_InvoiceDetail y ON x.invoiceNo=y.invoiceNo
               WHERE x.invoiceState IN('10','20','30','-1')
               GROUP BY y.orderNo
               ) t ON a.StockNo=t.orderNo
WHERE (a.BillSts='20' OR a.BillSts='25')
    AND ISNULL(dtl.totalFee,0.0)-ISNULL(t.totalFee,0.0)>0.0
go

