

/*==============================================================*/
/* View: WMS_F10_Employee_V                                     */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_Employee_V] as
SELECT a.employeeId AS f10Id,b.employeeId,b.officeTel,b.mobileNo
FROM dbo.BDM_Employee a 
	INNER JOIN YiWms.dbo.BAS_Employee b ON a.EmployeeNo=b.employeeNo
WHERE EXISTS(SELECT * FROM SYS_Config c WHERE b.companyId=c.companyId)
go

