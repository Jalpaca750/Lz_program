
--说明：客户商品销售汇总分析
--作者：Devil.H
--创建：2010.06.01
--参数：
--	@StartDate:起始日期
--	@EndDate:截止日期
--	@CorpNo:公司No
--	@DeptNo:部门
CREATE FUNCTION dbo.fn_AnalSMS42
(	
	@StartDate CHAR(10)='0000-01-01',
	@EndDate CHAR(10)='9999-12-31',
	@DeptNo VARCHAR(20)=''
) 
RETURNS TABLE
AS
RETURN(	
	SELECT cust.CustNo AS ParentNo,cust.CustName As ParentName,t.CustID,c.CustNo,c.CustName,c.NameSpell AS CustSpell,
        c.LinkMan,c.Phone,c.Faxes,c.SalesID,c.Sales,t.ItemID,g.ItemNo,g.ItemName,g.ItemAlias,g.NameSpell AS ItemSpell,
		g.ItemSpec,g.BarCode,g.MidBarcode,g.BigBarcode,g.PkgBarcode,g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,
		g.UnitName,t.SQty,t.Amt,t.RebateAmt,t.PlatformFee,ISNULL(t.Amt,0.0)-ISNULL(t.RebateAmt,0.0)-ISNULL(t.PlatformFee,0.0) AS RealAmt,
        c.CustType,c.TypeName,c.MemberID,c.Member,c.AreaCode,c.AreaName,c.PopedomID,c.PopedomName,c.KindName,c.TradeName,
        g.PkgSpec,CASE ISNULL(g.PkgRatio,0.0) WHEN 0.0 THEN NULL ELSE ROUND(ISNULL(t.SQty,0.0)/g.PkgRatio,4) END PkgQty,
		t.DepartId,dt.CHName AS DepartName
	FROM (SELECT a.CustID,a.DepartId,b.ItemID,SUM(ISNULL(b.Amt,0.0)) AS Amt,SUM(ISNULL(b.SQty,0.0)) AS SQty,
              ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0),2) AS RebateAmt,
              ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0),2) AS PlatformFee
		  FROM SMS_Stock a 
              INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
              INNER JOIN BDM_Customer c ON a.CustID=c.CustID
		  WHERE (a.BillSts='20' Or a.BillSts='30' Or a.BillSts='25')
			  AND (Convert(char(10),cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
			  AND (a.DeptNo Like @DeptNo + '%')
		  GROUP BY a.CustID,a.DepartId,b.ItemID) t 
        INNER JOIN BAS_Customer_V c ON t.CustID=c.CustID
		INNER JOIN BAS_Goods_V g ON t.ItemID=g.ItemID
		LEFT JOIN BDM_Customer cust ON ISNULL(c.ParentID,c.CustID)=cust.CustID
        LEFT JOIN BDM_DeptCode_V dt ON t.DepartId=dt.CodeID
)
go

