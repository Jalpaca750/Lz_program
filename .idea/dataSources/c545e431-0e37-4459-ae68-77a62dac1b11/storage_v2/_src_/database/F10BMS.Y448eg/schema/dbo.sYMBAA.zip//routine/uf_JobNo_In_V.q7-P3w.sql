--说明：批号入库记录
--作者：wujinfeng
--创建：2008.07.18
--参数：
--	@Year 年
--批号类型说明
--I1<采购入库 ；I2<调拨入库  ；I3<组装入库(上) ；I4<拆卸入库(下)  ；I5<赠品入库； I6<其他入库  ； I7<移仓入库 ； I8<库存初始化 ； I9<库存调整入库
--C1<销售出库；C2<调拨出库；C3<组装出库(下)；C4<拆卸出库(上) ；C5<赠品出库；C6<其他出库；C7<移仓出库 ；C8<报损出库
--R1:采购退货(出库)；R2:销售退货(入库)

CREATE Function uf_JobNo_In_V
(
	@BillType as varchar(2)
)
Returns @uTable Table
(
	SID 		bigint,
	ItemID 		bigint,
	ItemName	varchar(100),
	WareHouseID 	bigint,
	PHNo 		varchar(50),
	SNNo 		varchar(50),
	QTY 		decimal(18,6),
	AvailQty  	decimal(18,6),
	BeginDate	varchar(10),
	EndDate	varchar(10),
	YXQ 		decimal(18,6),
	BillType		varchar(2),
	BillNo		varchar(20),
	CreatorID 	bigint,
	BillSts		varchar(2),
	CustNo		varchar(50),
	CustName	varchar(100),
	CreateDate	varchar(10)
)
As
Begin	
	declare @i bigint
	if isnull(@BillType,'')=''
	Return
	if @BillType='IA'	--显示所有入库记录(供出库使用)
	begin
		Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,AvailQty,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,BillSts,CustNo,CustName,CreateDate)
		SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
			a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
			P.BillSts,P.VendorNo, P.VendorName,P.CreateDate
			FROM dbo.JobNumberNo_In a 
			INNER JOIN  dbo.PMS_Stock_V P ON  A.BillNo=P.StockNo
			--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		union
		SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
			a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
			P.BillSts,P.CustNo, P.CustName,P.CreateDate
			FROM dbo.JobNumberNo_In a 
			INNER JOIN  dbo.SMS_Return_V P ON  A.BillNo=P.ReturnNo
			--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		union
		SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
			a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
			P.BillSts,P.DeptNo_O, P.DeptName_O,P.CreateDate
			FROM dbo.JobNumberNo_In a 
			INNER JOIN  dbo.IMS_Incept_V P ON  A.BillNo=P.InceptNo
			--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		union
		SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
			a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
			P.BillSts,P.WareHouse_O, P.WHName_O,P.CreateDate
			FROM dbo.JobNumberNo_In a 
			INNER JOIN  dbo.IMS_Assembly_V P ON  A.BillNo=P.AssemblyNo
			--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		union
		SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
			a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
			P.BillSts,P.WareHouse_I, P.WHName_I,P.CreateDate
			FROM dbo.JobNumberNo_In a 
			INNER JOIN  dbo.IMS_Split_V P ON  A.BillNo=P.SplitNo
			--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		union
		SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
			a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
			P.BillSts,P.ObjectNo, P.ObjectName,P.CreateDate
			FROM dbo.JobNumberNo_In a 
			INNER JOIN  dbo.IMS_Present_V P ON  A.BillNo=P.PresentNo
			--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		union
		SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
			a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
			P.BillSts,P.ObjectNo, P.ObjectName,P.CreateDate
			FROM dbo.JobNumberNo_In a 
			INNER JOIN  dbo.IMS_Other_V P ON  A.BillNo=P.OtherNo
			--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		union
		SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
			a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
			P.BillSts,P.WareHouse_O, P.WHName_O,P.CreateDate
			FROM dbo.JobNumberNo_In a 
			INNER JOIN  dbo.IMS_Transfer_V P ON  A.BillNo=P.TransferNo
			--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		union
		SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
			a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
			'' As BillSts,'' As CustNo, '' As CustName,convert(varchar(10),a.CreateDate,120) As CreateDate
			FROM dbo.JobNumberNo_In a where billtype='I9'
			--INNER JOIN  dbo.SMS_Return_V P ON  A.BillNo=P.ReturnNo
			--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
	End

	if @BillType='I1'	--采购入库记录(入库处理)
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,AvailQty,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
		a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
		P.BillSts,P.VendorNo, P.VendorName,P.CreateDate
		FROM dbo.JobNumberNo_In a 
		INNER JOIN  dbo.PMS_Stock_V P ON  A.BillNo=P.StockNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
	End

	if @BillType='R2'	--销售退货记录(入库处理)
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,AvailQty,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
		a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
		P.BillSts,P.CustNo, P.CustName,P.CreateDate
		FROM dbo.JobNumberNo_In a 
		INNER JOIN  dbo.SMS_Return_V P ON  A.BillNo=P.ReturnNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
	End

	if @BillType='I2'	--调拨入库记录(入库处理)
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,AvailQty,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
		a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
		P.BillSts,P.DeptNo_O, P.DeptName_O,P.CreateDate
		FROM dbo.JobNumberNo_In a 
		INNER JOIN  dbo.IMS_Incept_V P ON  A.BillNo=P.InceptNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
	End

	if @BillType='I3'	--组装入库记录(入库处理)
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,AvailQty,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
		a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
		P.BillSts,P.WareHouse_O, P.WHName_O,P.CreateDate
		FROM dbo.JobNumberNo_In a 
		INNER JOIN  dbo.IMS_Assembly_V P ON  A.BillNo=P.AssemblyNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
	End

	if @BillType='I4'	--拆卸入库记录(入库处理)
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,AvailQty,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
		a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
		P.BillSts,P.WareHouse_I, P.WHName_I,P.CreateDate
		FROM dbo.JobNumberNo_In a 
		INNER JOIN  dbo.IMS_Split_V P ON  A.BillNo=P.SplitNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
	End

	if @BillType='I5'	--赠品入库记录(入库处理)
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,AvailQty,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
		a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
		P.BillSts,P.ObjectNo, P.ObjectName,P.CreateDate
		FROM dbo.JobNumberNo_In a 
		INNER JOIN  dbo.IMS_Present_V P ON  A.BillNo=P.PresentNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
	End

	if @BillType='I6'	or @BillType='I8'	--其它入库、库存初始化记录(入库处理)
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,AvailQty,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
		a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
		P.BillSts,P.ObjectNo, P.ObjectName,P.CreateDate
		FROM dbo.JobNumberNo_In a 
		INNER JOIN  dbo.IMS_Other_V P ON  A.BillNo=P.OtherNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
	End
	if @BillType='I7'	--移仓入库(入库处理)
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,AvailQty,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
		a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
		P.BillSts,P.WareHouse_O, P.WHName_O,P.CreateDate
		FROM dbo.JobNumberNo_In a 
		INNER JOIN  dbo.IMS_Transfer_V P ON  A.BillNo=P.TransferNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
	End
	if @BillType='I9'	--库存调整入库(入库处理)
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,AvailQty,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,a.QTY+a.Tqty-ISNULL(a.OQty,0) AS AvailQty,  
		a.BeginDate, a.EndDate, a.YXQ,a.BillType, a.BillNo, a.CreatorID,	
		'' As BillSts,'' As CustNo, '' As CustName,convert(varchar(10),a.CreateDate,120) As CreateDate
		FROM dbo.JobNumberNo_In a where billtype='I9'
		--INNER JOIN  dbo.SMS_Return_V P ON  A.BillNo=P.ReturnNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
	End

	--返回
	return
end























go

