CREATE VIEW dbo.Aging
AS
SELECT   TOP (100) PERCENT dbo.BDM_Customer.CustName, dbo.BDM_Employee.EmployeeName, dbo.SMS_Stock.CreateDate, 
                dbo.BDM_Customer.ADays AS 账期, SUM(dbo.SMS_StockDtl.Amt) AS 应收款, 
                dbo.SMS_StockDtl.StockNo AS 出库单号
FROM      dbo.SMS_StockDtl INNER JOIN
                dbo.SMS_Stock ON dbo.SMS_StockDtl.StockNo = dbo.SMS_Stock.StockNo INNER JOIN
                dbo.BDM_Customer ON dbo.SMS_Stock.CustID = dbo.BDM_Customer.CustID INNER JOIN
                dbo.BDM_Employee ON dbo.SMS_Stock.SalesID = dbo.BDM_Employee.EmployeeID
WHERE   (dbo.SMS_Stock.BillSts >= '20') AND (dbo.BDM_Customer.CustName NOT IN ('公司员工', '信义旗舰店', '会员', '促销'))
GROUP BY dbo.BDM_Customer.CustName, dbo.SMS_Stock.CreateDate, dbo.BDM_Employee.EmployeeName, 
                dbo.BDM_Customer.ADays, dbo.SMS_StockDtl.StockNo, dbo.SMS_Stock.BillSts
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[29] 4[21] 2[18] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "SMS_StockDtl"
            Begin Extent = 
               Top = 6
               Left = 545
               Bottom = 293
               Right = 820
            End
            DisplayFlags = 280
            TopColumn = 6
         End
         Begin Table = "SMS_Stock"
            Begin Extent = 
               Top = 6
               Left = 273
               Bottom = 295
               Right = 507
            End
            DisplayFlags = 280
            TopColumn = 9
         End
         Begin Table = "BDM_Customer"
            Begin Extent = 
               Top = 30
               Left = 876
               Bottom = 237
               Right = 1073
            End
            DisplayFlags = 280
            TopColumn = 26
         End
         Begin Table = "BDM_Employee"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 146
               Right = 219
            End
            DisplayFlags = 280
            TopColumn = 1
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 5550
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 2475
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 12
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 13', 'SCHEMA', 'dbo', 'VIEW', 'Aging'
go

exec sp_addextendedproperty 'MS_DiagramPane2', N'50
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'Aging'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 2, 'SCHEMA', 'dbo', 'VIEW', 'Aging'
go

