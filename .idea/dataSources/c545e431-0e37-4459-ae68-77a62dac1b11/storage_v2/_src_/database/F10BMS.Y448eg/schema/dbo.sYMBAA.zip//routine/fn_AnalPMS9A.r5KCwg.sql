CREATE Function dbo.fn_AnalPMS9A
(
	@Today char(10)='2000-01-01',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@IType varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	VendorID bigint,
	VendorNo varchar(20),
	VendorName varchar(200),
	NameSpell varchar(200),
	BuyerID bigint,
	Buyer varchar(100),
	InvoiceNo varchar(20),
	CreateDate varchar(10),
	IType varchar(20),
	ITName varchar(100),
	Invoice varchar(2000),
	APDate varchar(10),
	ADays int,
	EDays int,
	IAmt decimal(18,6),
	DAmt decimal(18,6),
	PAmt decimal(18,6),
	RemAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40)
)
As
Begin
	if @Flag=0
		Return
	Insert Into @uTable(VendorID,VendorNo,VendorName,NameSpell,BuyerID,Buyer,InvoiceNo,
		CreateDate,IType,ITName,Invoice,IAmt,DAmt,PAmt,RemAmt,LinkMan,Phone,EDays,
		Faxes,ADays,APDate)
	SELECT a.VendorID, b.VendorNo, b.VendorName, b.NameSpell, b.BuyerID, b.Buyer, 
	      	a.InvoiceNo, a.CreateDate, a.IType, c.CHName AS ITName, a.Invoice, a.IAmt, 
	   	a.DAmt,a.PAmt,ISNULL(a.IAmt, 0.0) - ISNULL(a.PAmt, 0.0) AS RemAmt, b.LinkMan, b.Phone, 
		datediff(dd,Cast(a.APDate as datetime),Cast(@ToDay as Datetime)) as EDays,
		b.Faxes,b.ADays,a.APDate
	FROM dbo.PMS_Invoice a LEFT OUTER JOIN
	      	dbo.BDM_DeptCode_V d ON a.DeptNo = d.CodeID LEFT OUTER JOIN
	      	dbo.BDM_Vendor_V b ON a.VendorID = b.VendorID LEFT OUTER JOIN
	      	dbo.BDM_InvoiceType_V c ON a.IType = c.CodeID
	Where (a.BillSts='20' Or a.BillSts='25')
		And a.APDate<@ToDay
		And (Isnull(a.IType,'') Like @IType + '%')
		And (Isnull(a.DeptNo,'') like @DeptNo + '%')
		And (Isnull(d.DeptNo,'') like @CorpNo + '%')
		And (ISNULL(a.IAmt,0.0) - ISNULL(a.PAmt,0.0)<>0.0)
	--返回
	Return
End
go

