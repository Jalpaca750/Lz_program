
--品牌代码
CREATE VIEW dbo.BDM_LabelCode_V
AS
SELECT CodeID, CodeNo, CHName, ENName, Flag, Classify,CheckBox
,IsWeb, OrderID,LabelRecomm
FROM dbo.BDM_Code
WHERE (Classify = 'FL09')
go

