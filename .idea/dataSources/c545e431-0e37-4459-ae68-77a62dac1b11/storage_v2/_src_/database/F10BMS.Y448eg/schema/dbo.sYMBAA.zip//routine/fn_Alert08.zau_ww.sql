--说明：未执行计划提醒
--作者：Devil.H
--创建：2010.03.24
--参数：
--	无
CREATE FUNCTION fn_Alert08
(
)
RETURNS TABLE
AS
RETURN (
    SELECT a.PlanNo,a.CreateDate,dp.CHName AS DeptName,g.ItemNo,
		g.ItemName,g.ItemSpec,g.ColorName,g.UnitName,b.PQty,
		ISNULL(b.PQty,0.0)-ISNULL(b.OQty,0.0) AS RemOQty,
		v.VendorNo,v.VendorName,e.EmployeeName AS Creator,a.Remarks
	FROM PMS_Plan a INNER JOIN PMS_PlanDtl b ON a.PlanNo=b.PlanNo
		INNER JOIN BDM_ItemInfo_V g ON g.ItemID=b.ItemID
		LEFT OUTER JOIN BDM_DeptCode_V dp ON dp.CodeID=a.DeptNo
		LEFT OUTER JOIN BDM_Vendor v ON v.VendorID=b.VendorID
		LEFT OUTER JOIN BDM_Employee e ON e.EmployeeID=a.CreatorID
	Where (a.BillSts='10' Or a.BillSts='20' Or a.BillSts='25') 
		And (ISNULL(b.PQty,0.0)-ISNULL(b.OQty,0.0)<>0.0)
)
go

