--说明：批号入库记录
--作者：wujinfeng
--创建：2008.07.18
--参数：
--	@BillType 批号类型

CREATE Function uf_JobNo_Out_V
(
	@BillType as varchar(2)
)
Returns @uTable Table
(
	SID 		bigint,
	ItemID 		bigint,
	ItemName	varchar(100),
	WareHouseID 	bigint,
	PHNo 		varchar(50),
	SNNo 		varchar(50),
	QTY 		decimal(18,6),
	--AvailQty  	decimal(18,6),
	BeginDate	varchar(10),
	EndDate		varchar(10),
	YXQ 		decimal(18,6),
	BillType	varchar(2),
	BillNo		varchar(20),
	CreatorID 	bigint,
	JobNumberNo_In_SID 	bigint,
	BillSts		varchar(2),
	CustNo		varchar(50),
	CustName	varchar(100),
	CreateDate	varchar(10)
)
As
Begin	
	declare @i bigint
	if isnull(@BillType,'')=''
	Return
	if @BillType='CA'--显示所有出库批号序列记录
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,JobNumberNo_In_SID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.CustNo, S.CustName,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.SMS_Stock_V S ON  A.BillNo=S.StockNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	union
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.VendorNo, S.VendorName,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.PMS_Return_V S ON  A.BillNo=S.ReturnNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	union
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.DeptNo_I, S.DeptName_I,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Allot_V S ON  A.BillNo=S.AllotNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	union
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.WareHouse_I, S.WHName_I,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Assembly_V S ON  A.BillNo=S.AssemblyNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	union
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.WareHouse_O, S.WHName_O,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Split_V S ON  A.BillNo=S.SplitNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	union
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.ObjectNo, S.ObjectName,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Present_V S ON  A.BillNo=S.PresentNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	union
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.ObjectNo, S.ObjectName,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Other_V S ON  A.BillNo=S.OtherNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	union
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.WareHouse_I, S.WHName_I,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Transfer_V S ON  A.BillNo=S.TransferNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	end

	if @BillType='C1'--销售出库
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,JobNumberNo_In_SID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.CustNo, S.CustName,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.SMS_Stock_V S ON  A.BillNo=S.StockNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	end

	if @BillType='R1'--采购退货
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,JobNumberNo_In_SID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.VendorNo, S.VendorName,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.PMS_Return_V S ON  A.BillNo=S.ReturnNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	end

	if @BillType='C2'--调拨出库
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,JobNumberNo_In_SID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.DeptNo_I, S.DeptName_I,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Allot_V S ON  A.BillNo=S.AllotNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	end

	if @BillType='C3'--组装出库
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,JobNumberNo_In_SID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.WareHouse_I, S.WHName_I,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Assembly_V S ON  A.BillNo=S.AssemblyNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	End

	if @BillType='C4'--拆卸出库
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,JobNumberNo_In_SID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.WareHouse_O, S.WHName_O,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Split_V S ON  A.BillNo=S.SplitNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	End

	if @BillType='C5'--赠品出库
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,JobNumberNo_In_SID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.ObjectNo, S.ObjectName,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Present_V S ON  A.BillNo=S.PresentNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	end

	if @BillType='C6' or @BillType='C8'--其他出库单、报损出库单
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,JobNumberNo_In_SID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.ObjectNo, S.ObjectName,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Other_V S ON  A.BillNo=S.OtherNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	end
	if @BillType='C7'--移仓出库单
	begin
	Insert Into @uTable(SID,ItemID,ItemName,WareHouseID,PHNo,SNNo,QTY,BeginDate,EndDate,YXQ,BillType,BillNo,CreatorID,JobNumberNo_In_SID,BillSts,CustNo,CustName,CreateDate)
	SELECT a.SID, a.ItemID,a.ItemName, a.WareHouseID,a.PHNo, a.SNNo, a.QTY,d.BeginDate, d.EndDate, d.YXQ,a.BillType, a.BillNo, a.CreatorID,a.JobNumberNo_In_SID
		,S.BillSts,S.WareHouse_I, S.WHName_I,S.CreateDate	
		FROM dbo.JobNumberNo_Out a 
		INNER JOIN  dbo.IMS_Transfer_V S ON  A.BillNo=S.TransferNo
		--INNER JOIN  dbo.BDM_ItemInfo_V       c ON a.ItemID = c.ItemID 
		INNER JOIN   dbo.uf_JobNo_In_V('IA') d ON a.JobNumberNo_In_SID = d.SID
	end

	--返回
	return
end



















go

