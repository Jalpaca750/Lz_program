

CREATE Proc [dbo].[sp_SMSRectifyAudit]
(
	@RectifyNo varchar(20),
	@Flag char(2)
)
As
Begin

	declare @CustID bigint
	declare @Amt decimal(18,6)
	declare @RectifyID bigint
	declare @DeptNo varchar(20)
	declare @warehouse varchar(20)
    declare @ServicRate decimal(10,6)
	--2011.11.24增加积分模式和金额积分标准,会员自动升级积分和级别
	declare @Integral decimal(18,6)
	declare @IsSYSIntegral bit
	declare @IntegralMode int
	declare @UnitIntegral decimal(18,6)
	declare @MemberID varchar(20)
	declare @TotalAmt decimal(18,6)
	--当前调价单
	Select @CustID=CustID,@DeptNo=DeptNo From SMS_Rectify Where RectifyNo=@RectifyNo
	Select @Amt=Sum(Amt) From SMS_RectifyDtl Where RectifyNo=@RectifyNo
	Select Top 1 @warehouse=warehouse,@ServicRate=ISNULL(ServicRate,0.0) FROM SMS_Stock Where StockNo IN(Select StockNo From SMS_RectifyDtl Where RectifyNo=@RectifyNo)
	----2011.11.24
	Select @IsSYSIntegral=isnull(IsSYSIntegral,0),@IntegralMode=Isnull(IntegralMode,1),@UnitIntegral=Isnull(UnitIntegral,0.0) From Sys_Config
	--系统启用了积分功能,且客户参与积分功能	
	if Exists(Select 1 From BDM_Customer Where CustID=@CustID And Isnull(IsIntegral,1)=1 And Isnull(@IsSYSIntegral,0)=1)
		Begin
			--按销售额积分
			If Isnull(@IntegralMode,1)=2
				Select @Integral=Isnull(@Amt,0.0)/@UnitIntegral
				From SMS_Rectify a Inner Join BDM_Customer c On a.CustID=c.CustID
				Where (a.RectifyNo=@RectifyNo) And (Convert(varchar(10),a.CreateDate,120)>Convert(varchar(10),c.zj_ql_Date,120)) 
			--按数量积分
			If Isnull(@IntegralMode,1)=1 Or Isnull(@IntegralMode,1)=3
				Set @Integral=0.0
		End
	Else
		Set @Integral=0.0
	--审核通过
	if @Flag='20'
		begin
			--更新客户欠款
			Update BDM_Customer Set ArgAmt=isnull(ArgAmt,0.0)+Isnull(@Amt,0.0),Integral=isnull(Integral,0.0)+isnull(@Integral,0.0)
			Where CustID=@CustID
			--如果设置了会员自动升级，则升级会员级别
			If Isnull(@IntegralMode,1)=3
				Begin
					--审核前的销售额
					Select @TotalAmt=Sum(b.Amt)
					From SMS_Stock a Inner Join SMS_StockDtl b On a.StockNo=b.StockNo
					Where a.CustID=@CustID And (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
					--获取当前金额下的最高级会员
					Select @MemberID=MemberID
					From (Select Top 1 MemberID From SPM_Integral Where UpAmt<=Isnull(@TotalAmt,0.0)+Isnull(@Amt,0.0) Order By UpAmt desc) t					
					--更新会员级别
					Update BDM_Customer Set MemberID=@MemberID
					Where CustID=@CustID And Isnull(@MemberID,'')<>''
				End	

			--写入销售出库单
			Insert Into SMS_Stock(StockNo,CreateDate,DeptNo,CustID,BillType,BillSts,SendAddr,LinkMan,Phone,
				CreatorID,AuditDate,AuditID,Remarks,SalesID,HandlerID,DepartId,CostsId,warehouse,ServicRate)
			Select RectifyNo,CreateDate,DeptNo,CustID,'30','20',SendAddr,LinkMan,Phone,CreatorID,AuditDate,
                AuditID,Remarks,SalesID,HandlerID,DepartId,CostsId,@warehouse,@ServicRate
			From SMS_Rectify
			Where RectifyNo=@RectifyNo And Not Exists(Select 1 From SMS_Stock Where StockNo=@RectifyNo)
			--写入采购入库明细
			Insert Into SMS_StockDtl(StockNo,WareHouse,ItemID,SQty,Price,Amt,TaxFlag)
			Select RectifyNo,WareHouse,ItemID,0,MPrice,Amt,Isnull(TaxFlag,0)
			From SMS_RectifyDtl_V
			Where RectifyNo=@RectifyNo And Not Exists(Select 1 From SMS_StockDtl Where StockNo=@RectifyNo)
			--调整进价
			if exists(select 1 from SMS_Rectify Where RectifyNo=@RectifyNo And Effect=1)
				begin
					--更新进价设置
					Update a Set a.Price=b.MPrice
					From SMS_Price a,SMS_RectifyDtl b
					Where b.RectifyNo=@RectifyNo And a.CustID=@CustID And a.ItemID=b.ItemID	
				end				
		end
	--取消审核
	if @Flag='10' 
		begin
			--更新客户欠款
			Update BDM_Customer Set ArgAmt=isnull(ArgAmt,0.0)-Isnull(@Amt,0.0),Integral=isnull(Integral,0.0)-isnull(@Integral,0.0)
			Where CustID=@CustID	
			--如果设置了会员自动升级，则升级会员级别
			If Isnull(@IntegralMode,1)=3
				Begin
					--审核前的销售额
					Select @TotalAmt=Sum(b.Amt)
					From SMS_Stock a Inner Join SMS_StockDtl b On a.StockNo=b.StockNo
					Where a.CustID=@CustID And (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
					--获取当前金额下的最高级会员
					Select @MemberID=MemberID
					From (Select Top 1 MemberID From SPM_Integral Where UpAmt<=Isnull(@TotalAmt,0.0)-Isnull(@Amt,0.0) Order By UpAmt desc) t					
					--更新会员级别
					Update BDM_Customer Set MemberID=@MemberID
					Where CustID=@CustID And Isnull(@MemberID,'')<>''
				End	
			--删除明细数据
			Delete From SMS_StockDtl WHere StockNo=@RectifyNo 
			--删除入库单数据
			Delete From SMS_Stock Where StockNo=@RectifyNo
		End
	if @Flag='00'
		--更新进价设置
		Return	
End
go

