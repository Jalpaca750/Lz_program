CREATE VIEW dbo.PRJ_Execute_V
AS
SELECT a.BillNo, a.CreateDate, a.DeptNo, a.CustID, a.BillSts, a.ExecSts, a.ProjectXZ, 
      a.ProjectSubject, a.Remarks, a.JBRenID, a.ExecRenID,a.ExecRen, a.ExecAddress, 
      a.ExecBegin, a.TimeBegin, a.TimeEnd, a.OrderNo, a.ExecContent, a.PFlag, a.AuditDate, 
      a.AuditID, a.CreatorID, f.EmployeeName AS Creator, H.EmployeeName AS Auditer, 
      a.AuditingFlag, a.AuditingStatus, a.PayType,
      (Select StsName From BillStatus g Where g.BillType = 'PRJ20' And a.BillSts=g.BillSts) As StsName,
      a.Opinion, a.Feedback, a.Evaluate, c.CustNo, c.CustName, c.NameSpell, c.CustType, c.TypeName, 
      c.MemberID, c.Member, c.AreaCode, c.AreaName, c.PopedomID, c.PopedomName, 
      c.LinkMan, c.Phone, c.Faxes, a.SendAddr, d.EmployeeName AS JBRen, b.CHName AS DeptName, b.CodeNo, 
      CASE a.AuditingFlag WHEN '0' THEN '否' WHEN '1' THEN '是' END AS ISAuditing, 
      CASE WHEN a.AuditingFlag = '0' THEN '' WHEN a.AuditingStatus = '0' THEN '未通过' WHEN
       a.AuditingStatus = '1' THEN '通过' ELSE '' END AS BillAuditing_Result, a.CostFlag, 
      a.ProjectAmt, a.ProjectJSAmt, a.ProjectContent, a.ExecTime,a.CheckBox 
FROM dbo.PRJ_Execute a LEFT OUTER JOIN
      dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID LEFT OUTER JOIN
      dbo.BDM_Customer_V c ON a.CustID = c.CustID LEFT OUTER JOIN
      dbo.BDM_Employee d ON a.JBRenID = d.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee f ON a.CreatorID = f.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee H ON a.AuditID = H.EmployeeID LEFT OUTER JOIN
      dbo.PRJ_Order I ON a.OrderNo = I.BillNo
go

