--说明：分部销售毛利统计(按分部汇总)
--作者：Devil.H
--创建：2007.11.16
--参数：
--	@Period:会计月份额
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@DeptNo:部门
--	@WareHouse:仓库
--	@CustType：
--	@AreaCode:
--	@PopedomID:
--	@MemberID:
--	@CustID:
--	@ClassID:
--	@LabelID:
--	@ItemID:
--	@Flag:前台标识
CREATE FUNCTION [dbo].[fn_AnalSMS6H]
(
	@Period VARCHAR(6),
	@StartDate VARCHAR(10),
	@EndDate VARCHAR(10),
	@DeptNo VARCHAR(20),
	@WareHouse VARCHAR(20),
	@CustType VARCHAR(20),
	@AreaCode VARCHAR(20),
	@PopedomID VARCHAR(20),
	@MemberID VARCHAR(20),
	@CustID BIGINT,
	@ClassID VARCHAR(10),
	@LabelID VARCHAR(20),
	@ItemID BIGINT,
	@Flag INT=0
)
RETURNS @uTable TABLE(
	DeptID VARCHAR(20),
	DeptNo VARCHAR(20),
	DeptName VARCHAR(100),
	SQty DECIMAL(18,6),
    RebateAmt DECIMAL(18,6),            --返点
    PlatformFee DECIMAL(18,6),          --平台费  
	Amt DECIMAL(18,6),
    RealAmt DECIMAL(18,6),              --实际销售额  
	CstAmt DECIMAL(18,6),
	GProAmt DECIMAL(18,6),
	GProfit DECIMAL(18,6),
	JHCstPrice DECIMAL(18,6), 	        --参考成本价
	JHCstAmt DECIMAL(18,6), 	        --参考成本
	JHGProAmt DECIMAL(18,6),	        --参考毛利
	JHGProfit DECIMAL(18,6)		        --参考毛利率
)
AS
BEGIN
	IF (@Flag=0) 
		RETURN;
	DECLARE @AmtDec INT,@STaxFlag BIT;
    --临时成本表
	DECLARE @CostTmp TABLE(DeptNo VARCHAR(20),ItemID BIGINT,Price DECIMAL(18,10) Primary Key(DeptNo,ItemID));
    --定制成本
	DECLARE @Special TABLE(OrderID BIGINT,ItemID BIGINT,Price DECIMAL(18,10));
	--销售数据临时表
	DECLARE @Sales TABLE(RowID BIGINT Identity(1,1),DeptNo VARCHAR(20),ItemID BIGINT,SQty DECIMAL(18,6),Amt DECIMAL(18,6),CPrice DECIMAL(18,6),IsSpecial BIT,TaxFlag BIT,OrderID BIGINT,PlatformFee DECIMAL(10,6),Rebate DECIMAL(10,6),Taxrate DECIMAL(10,6) PRIMARY KEY(RowID));
	--初始化参数
    SET @StartDate=CONVERT(CHAR(10),CAST(@StartDate AS DATETIME),23);
	SET @EndDate=CONVERT(CHAR(10),CAST(@EndDate AS DATETIME),23);
	SELECT @AmtDec=ISNULL(AmtDec,2),@STaxFlag=ISNULL(STaxFlag,0) FROM Sys_Config;
	SET @AmtDec=ISNULL(@AmtDec,2);	

	--销售数据收集
	INSERT INTO @Sales(DeptNo,ItemID,SQty,Amt,IsSpecial,TaxFlag,OrderID,PlatformFee,Rebate,TaxRate)
	SELECT a.DeptNo,b.ItemID,CASE @Flag WHEN 1 THEN b.SQty ELSE ISNULL(b.SQty,0)+ISNULL(b.ZQty,0.0) END,
	    b.Amt,ISNULL(b.IsSpecial,0),ISNULL(b.TaxFlag,0),b.OrderID,ISNULL(c.PlatformFee,0.0),ISNULL(c.Rebate,0.0),
        ISNULL(d.Taxrate,16)
	FROM SMS_Stock a 
        INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo 
        INNER JOIN BDM_Customer c ON a.CustID=c.CustID
        INNER JOIN BDM_ItemInfo d ON b.ItemID=d.ItemID
	WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30') 
		AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
		AND (a.DeptNo LIKE @DeptNo + '%')
		AND (b.WareHouse LIKE @WareHouse + '%')
		AND (@CustID=0 OR a.CustID=@CustID)
		AND (@ItemID=0 OR b.ItemID=@ItemID)
        AND (ISNULL(c.CustType,'') LIKE @CustType + '%')
        AND (ISNULL(c.AreaCode,'') LIKE @AreaCode + '%')
        AND (ISNULL(c.PopedomID,'') LIKE @PopedomID + '%')
        AND (ISNULL(c.MemberID,'') LIKE @MemberID + '%')
        AND (ISNULL(d.ClassID,'') LIKE @ClassID + '%')
        AND (ISNULL(d.LabelID,'') LIKE @LabelID + '%');
	IF NOT EXISTS(SELECT 1 FROM @Sales)
		RETURN;
	--获取临时成本
	INSERT INTO @CostTmp(DeptNo,ItemID,Price)
	SELECT ISNULL(DeptNo,'$$$$'),ItemID,MEPrice
	FROM uf_CostPrice(@Period);
	
	--成本统计（分部成本法）
	IF Exists(SELECT 1 FROM SYS_Config WHERE ISNULL(Method,'S')='S')
		UPDATE a SET a.CPrice=b.Price
		FROM @Sales a 
		    INNER JOIN @CostTmp b ON a.DeptNo=b.DeptNo And a.ItemID=b.ItemID;
	ELSE
		UPDATE a SET a.CPrice=b.Price
		FROM @Sales a 
            INNER JOIN @CostTmp b On b.DeptNo='$$$$' AND a.ItemID=b.ItemID;	
	--定制品入库单(包含一对一采购)
    INSERT INTO @Special(OrderID,ItemID,Price)
	SELECT y.XS_OrderID,y.ItemID,y.Price 
    FROM PMS_Stock x 
        INNER JOIN PMS_StockDtl y ON x.StockNo=y.StockNo
    WHERE (x.BillSts='20' Or x.BillSts='30' Or x.BillSts='25') 
		AND EXISTS(SELECT * FROM @Sales t WHERE y.XS_OrderID=t.OrderID);
	--定制品成本	
	UPDATE a SET a.CPrice=b.Price 
	FROM @Sales a 
	    INNER JOIN @Special b ON a.OrderID=b.OrderID;
 
	--根据成本统计数据(可把1.16替换成实际税率)
	IF ISNULL(@STaxFlag,0)=1
		INSERT INTO @uTable(DeptID,SQty,RebateAmt,PlatformFee,Amt,CstAmt,GProAmt,JHCstAmt,JHGProAmt)
		SELECT DeptNo,SUM(SQty) AS SQty,ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec) AS RebateAmt,
            ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec) AS PlatformFee,SUM(Amt) AS Amt,
            SUM(CstAmt),SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(CstAmt,0.0)),
			SUM(JHCstAmt),SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(JHCstAmt,0.0))
		FROM (
                SELECT a.DeptNo,a.SQty,a.Amt,a.PlatformFee,a.Rebate,
				    ROUND(ISNULL(a.SQty,0.0)*(CASE a.TaxFlag WHEN 0 THEN ISNULL(a.CPrice,0.0) ELSE ISNULL(a.CPrice,0.0)/1.13 END),@AmtDec) AS CstAmt,
				    ROUND(ISNULL(a.SQty,0.0)*(CASE a.TaxFlag WHEN 0 THEN ISNULL(jh.Cost,0.0) ELSE ISNULL(jh.Cost,0.0)/1.13 END),@AmtDec) AS JHCstAmt
                FROM @Sales a 
                    LEFT JOIN CST_Colligate_COST_Year jh On jh.Period=@Period And a.ItemID=jh.ItemID
             )t
		GROUP BY DeptNo;
	ELSE
		INSERT INTO @uTable(DeptID,SQty,RebateAmt,PlatformFee,Amt,CstAmt,GProAmt,JHCstAmt,JHGProAmt)
		SELECT DeptNo,SUM(SQty),ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec) AS RebateAmt,
            ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec) AS PlatformFee,SUM(Amt) AS Amt,
            SUM(CstAmt) AS CstAmt,SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(CstAmt,0.0)) AS GProAmt,
			SUM(JHCstAmt) AS JHCstAmt,SUM(Amt)-ROUND(SUM(ISNULL(Amt,0.0)*Rebate/100.0),@AmtDec)-ROUND(SUM(ISNULL(Amt,0.0)*PlatformFee/100.0),@AmtDec)-SUM(ISNULL(JHCstAmt,0.0)) AS JHGProAmt
		FROM (
		        SELECT a.DeptNo,a.SQty,a.Amt,a.PlatformFee,a.Rebate,
				    ROUND(ISNULL(a.SQty,0.0)*ISNULL(a.CPrice,0.0),@AmtDec) AS CstAmt,
				    ROUND(ISNULL(a.SQty,0.0)*ISNULL(jh.Cost,0.0),@AmtDec) AS JHCstAmt
			    FROM @Sales a 
				    LEFT JOIN CST_Colligate_COST_Year jh ON jh.Period=@Period And a.ItemID=jh.ItemID
             )t
		GROUP BY DeptNo;
  
	--更新部门资料
	UPDATE a SET a.DeptNo=b.CodeNo,a.DeptName=b.CHName,
        RealAmt=ISNULL(Amt,0.0)-ISNULL(RebateAmt,0.0)-ISNULL(PlatformFee,0.0),
		a.GProfit=CASE ISNULL(Amt,0.0) WHEN 0.0 THEN 0.0 
					       ELSE ROUND(ISNULL(a.GProAmt,0.0)/(ISNULL(Amt,0.0)),2*@AmtDec) END,
		a.JHGProfit=CASE ISNULL(Amt,0.0) WHEN 0.0 THEN 0.0 
						   ELSE ROUND(ISNULL(a.JHGProAmt,0.0)/(ISNULL(Amt,0.0)),2*@AmtDec) END
	FROM @uTable a 
        LEFT JOIN BDM_DeptCode_V b ON a.DeptID=b.CodeID;
    
    DELETE FROM @Sales;
	DELETE FROM @Special;
	DELETE FROM @CostTmp;
	--返回
	RETURN;
END
go

