
--2018-07-22 日
--创建单据编号
CREATE PROC [dbo].[sp_GetBillNo]
(
	@billType VARCHAR(32),
	@billNo VARCHAR(20) OUT
)
AS
BEGIN
	DECLARE @prefix VARCHAR(10),@maxNum BIGINT,@errors BIGINT;
	SET @errors=0;
    BEGIN TRAN
	SELECT @prefix=prefix FROM SYS_BillType WHERE billType=@billType;
	SET @errors=@errors+@@ERROR;
	SET @prefix=@prefix+CONVERT(VARCHAR(10),GETDATE(),12);
	SET @errors=@errors+@@ERROR;
	WHILE EXISTS(SELECT 1 FROM SYS_BillType WHERE billType=@billType AND locked=0)
	BEGIN
		UPDATE SYS_BillType SET locked=1 WHERE billType=@billType;
		SET @errors=@errors+@@ERROR;
	END
	SELECT @maxNum=MAX(flowNum)
	FROM SYS_Coding
	WHERE BillType=@billType AND Prefix=@prefix;
	SET @errors=@errors+@@ERROR;
	
	SET @maxNum=ISNULL(@maxNum,0)+1;
	INSERT INTO SYS_Coding(CodingId,BillType,Prefix,FlowNum,CreatorId,CreateTime)
	VALUES(LOWER(REPLACE(NEWID(),'-','')),@billType,@prefix,@maxNum,99,GETDATE());
	SET @billNo=@prefix+RIGHT('0000'+CAST(@maxNum AS VARCHAR(4)),4);
	SET @errors=@errors+@@ERROR;
	UPDATE SYS_BillType SET locked=0 WHERE billType=@billType
	SET @errors=@errors+@@ERROR;
	IF (@errors=0)
	BEGIN
	    COMMIT;
	END
	ELSE
	BEGIN
	    IF @@TRANCOUNT>0
			ROLLBACK;
		SET @billNo=''
	END
END

go

