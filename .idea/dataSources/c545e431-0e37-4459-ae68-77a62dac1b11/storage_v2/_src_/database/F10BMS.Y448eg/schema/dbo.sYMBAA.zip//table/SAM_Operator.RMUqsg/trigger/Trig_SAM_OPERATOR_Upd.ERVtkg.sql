--操作员新增&修改操作触发
--2005-01-22
--Devil.H
--当上述操作发生时：
--系统自动检测是否授权，If授权－将不改变原来的授权；Else没有，系统检测成员所在组是否授权；
--If组已授权，读入组授权；Else不作任何处理
CREATE Trigger Trig_SAM_OPERATOR_Upd
On dbo.SAM_Operator
--with encryption
For Update
As 
Begin
	declare @EmployeeID bigint
	declare @TeamNo varchar(10)
	Select @EmployeeID=EmployeeID,@TeamNo=isnull(TeamNo,'') From Inserted
	if exists(Select 1 From Deleted Where TeamNo=@TeamNo)
		Return
	if exists(Select * From SAM_TPower Where TeamNo=@TeamNo)
		begin
			Delete From SAM_Power Where EmployeeID=@EmployeeID
			Insert Into SAM_Power(EmployeeID,Menu,IsImpower,IsAdd,IsQuery,IsModify,IsDeleted,IsPrint,IsExport,IsCheck,IsUncheck,IsSetting)
			Select @EmployeeID,Menu,IsImpower,IsAdd,IsQuery,IsModify,IsDeleted,IsPrint,IsExport,IsCheck,IsUncheck,IsSetting
			From SAM_TPower Where TeamNo=@TeamNo
			
		end 

End
go

