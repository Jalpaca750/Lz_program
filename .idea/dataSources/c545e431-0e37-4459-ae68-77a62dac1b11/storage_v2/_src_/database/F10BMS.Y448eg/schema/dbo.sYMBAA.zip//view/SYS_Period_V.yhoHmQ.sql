create view SYS_Period_V as
Select a.CW_Period As Period,a.StartDate,a.EndDate,b.SealFlag
From SYS_CW_MonthPeriod a Left Outer Join SYS_Period b On a.CW_Period=b.Period
go

