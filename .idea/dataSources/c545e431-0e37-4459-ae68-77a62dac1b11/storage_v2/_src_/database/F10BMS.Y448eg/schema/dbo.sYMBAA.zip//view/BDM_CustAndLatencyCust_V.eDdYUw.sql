CREATE VIEW dbo.BDM_CustAndLatencyCust_V
AS
SELECT '当前客户' As CustLatencyType,a.CustID, a.CustNo, a.CustName, a.NameSpell, a.CustAddr, a.SendAddr, 
      a.PostalCode, a.CustType, e.CHName AS TypeName, a.MemberID, 
      j.CHName AS Member, a.AreaCode, f.CHName AS AreaName, a.PopedomID, 
      i.CHName AS PopedomName, a.SalesID, b.EmployeeName AS Sales, a.DeptNo, 
      g.CHName AS DeptName, a.Phone, a.Faxes, a.EMail,a.Webs, a.WebName,a.WebPassword, 
      a.ShowQty,a.IsContract,a.TradeID, l.CHName AS TradeName, a.KindID, k.CHName AS KindName,  
      a.LegalPerson,a.AccountNo, a.TaxNo, a.ADays, a.ADayFlag, a.IDays, a.CreditAmt, a.CreditFlag, 
      a.Invoice, a.Finance, a.FPhone, a.AdvAmt, a.ArgAmt, a.SendID, 
      m.CHName AS SendMode,a.SendFlag, a.PriceFlag,a.DiscRate
,a.Integral AS SumInteg, a.SJInteg, 
ISNULL(a.Integral, 0) - ISNULL(a.SJInteg, 0) AS WJInteg, a.Deduct, 
--CAST(ISNULL(a.SJInteg, 0) - ISNULL(a.Deduct, 0) AS bigint) AS Integral
CAST(ISNULL(a.SJInteg, 0) - ISNULL(a.Deduct, 0)-isnull(a.qlInteg,0) AS bigint) AS Integral
, a.LinkMan, 
      a.OutValue, a.SalesAmt, a.Persons, a.CurrencyID,a.DeptName as DName,a.Jobname,a.PerPhone,
      CASE a.Sex WHEN '1' THEN '男' WHEN '0' THEN '女' END AS Sex, 
      CASE a.Ages WHEN '10' THEN '20-29' WHEN '20' THEN '30-39' WHEN '30' THEN '40-49'
       WHEN '40' THEN '50-59' END AS Ages, a.Defined1, a.Defined2, a.Defined3, 
      CASE isnull(a.Flag, '1') WHEN '1' THEN '有效' ELSE '失效' END AS Flag, a.CreatorID, 
      c.EmployeeName AS Creator, a.CreateDate, a.MenderID, d.EmployeeName AS Mender,
       a.AmendDate, a.Remarks, a.CheckBox

,a.IsIntegral,a.qlInteg,a.zj_qlInteg,a.zj_ql_Date,q.EmployeeName as zj_ql_Creator
,Integralbk
,isnull(cc.ADays,0) As cc_ADays,isnull(cc.Amt,0)  As cc_Amt
FROM dbo.BDM_PopedomCode_V i RIGHT OUTER JOIN
      dbo.BDM_SendMode_V m RIGHT OUTER JOIN
      dbo.BDM_Customer a ON m.CodeID = a.SendID LEFT OUTER JOIN
      dbo.BDM_EKind_V k ON a.KindID = k.CodeID LEFT OUTER JOIN
      dbo.BDM_TradeCode_V l ON a.TradeID = l.CodeID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V g ON a.DeptNo = g.CodeID LEFT OUTER JOIN
      dbo.BDM_MemberCode_V j ON a.MemberID = j.CodeID ON 
      i.CodeID = a.PopedomID LEFT OUTER JOIN
      dbo.BDM_Employee d ON a.MenderID = d.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee b ON a.SalesID = b.EmployeeID LEFT OUTER JOIN

      dbo.BDM_Employee q ON a.zj_ql_CreatorID = q.EmployeeID LEFT OUTER JOIN

      dbo.BDM_CustType_V e ON a.CustType = e.CodeID LEFT OUTER JOIN
      dbo.BDM_AreaCode_V f ON a.AreaCode = f.CodeID
LEFT OUTER JOIN uf_BDM_CustCredit('') cc on a.CustID=cc.CustID
union
SELECT '潜在客户' As CustLatencyType,a.CustID, a.CustNo, a.CustName, a.NameSpell, a.CustAddr, a.SendAddr, 
      a.PostalCode, a.CustType, e.CHName AS TypeName, a.MemberID, 
      j.CHName AS Member, a.AreaCode, f.CHName AS AreaName, a.PopedomID, 
      i.CHName AS PopedomName, a.SalesID, b.EmployeeName AS Sales, a.DeptNo, 
      g.CHName AS DeptName, a.Phone, a.Faxes, a.EMail,a.Webs, a.WebName,a.WebPassword, 
      a.ShowQty,a.IsContract,a.TradeID, l.CHName AS TradeName, a.KindID, k.CHName AS KindName,  
      a.LegalPerson,a.AccountNo, a.TaxNo, a.ADays, a.ADayFlag, a.IDays, a.CreditAmt, a.CreditFlag, 
      a.Invoice, a.Finance, a.FPhone, a.AdvAmt, a.ArgAmt, a.SendID, 
      m.CHName AS SendMode,a.SendFlag, a.PriceFlag,a.DiscRate
,a.Integral AS SumInteg, a.SJInteg, 
ISNULL(a.Integral, 0) - ISNULL(a.SJInteg, 0) AS WJInteg, a.Deduct, 
--CAST(ISNULL(a.SJInteg, 0) - ISNULL(a.Deduct, 0) AS bigint) AS Integral
CAST(ISNULL(a.SJInteg, 0) - ISNULL(a.Deduct, 0)-isnull(a.qlInteg,0) AS bigint) AS Integral
, a.LinkMan, 
      a.OutValue, a.SalesAmt, a.Persons, a.CurrencyID,a.DeptName as DName,a.Jobname,a.PerPhone,
      CASE a.Sex WHEN '1' THEN '男' WHEN '0' THEN '女' END AS Sex, 
      CASE a.Ages WHEN '10' THEN '20-29' WHEN '20' THEN '30-39' WHEN '30' THEN '40-49'
       WHEN '40' THEN '50-59' END AS Ages, a.Defined1, a.Defined2, a.Defined3, 
      CASE isnull(a.Flag, '1') WHEN '1' THEN '有效' ELSE '失效' END AS Flag, a.CreatorID, 
      c.EmployeeName AS Creator, a.CreateDate, a.MenderID, d.EmployeeName AS Mender,
       a.AmendDate, a.Remarks, a.CheckBox

,a.IsIntegral,a.qlInteg,a.zj_qlInteg,a.zj_ql_Date,q.EmployeeName as zj_ql_Creator
,Integralbk
,0 As cc_ADays,0 As cc_Amt
FROM dbo.BDM_PopedomCode_V i RIGHT OUTER JOIN
      dbo.BDM_SendMode_V m RIGHT OUTER JOIN
      dbo.BDM_Cust_Latency a ON m.CodeID = a.SendID LEFT OUTER JOIN
      dbo.BDM_EKind_V k ON a.KindID = k.CodeID LEFT OUTER JOIN
      dbo.BDM_TradeCode_V l ON a.TradeID = l.CodeID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V g ON a.DeptNo = g.CodeID LEFT OUTER JOIN
      dbo.BDM_MemberCode_V j ON a.MemberID = j.CodeID ON 
      i.CodeID = a.PopedomID LEFT OUTER JOIN
      dbo.BDM_Employee d ON a.MenderID = d.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee b ON a.SalesID = b.EmployeeID LEFT OUTER JOIN

      dbo.BDM_Employee q ON a.zj_ql_CreatorID = q.EmployeeID LEFT OUTER JOIN

      dbo.BDM_CustType_V e ON a.CustType = e.CodeID LEFT OUTER JOIN
      dbo.BDM_AreaCode_V f ON a.AreaCode = f.CodeID






go

