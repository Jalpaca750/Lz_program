



--说明：当前盘点单盘点完毕
--作者：Devil.H
--创建：2005.04.25
--参数：
--	    @LotNo:      批次号(盘点期号)
--      @Warehouse:  盘点仓库
--      @Flag:       20-盘点完成;10-取消盘点
--修改：
--      Frank.He   2018-07-07日，增加存储过程中出错后的错误处理机制。
CREATE PROC sp_IMSChecked
(
	@LotNo VARCHAR(20),
	@WareHouse VARCHAR(20),
	@Flag CHAR(2)
)
As
BEGIN
    DECLARE @DeptNo VARCHAR(20);
    DECLARE @ErrMsg NVARCHAR(4000),@ErrSeverity INT,@errors BIGINT;
    DECLARE @uTmp TABLE(DeptNo VARCHAR(20),WareHouse VARCHAR(20),ItemID BIGINT,SQty DECIMAL(18,6) PRIMARY KEY (DeptNo,WareHouse,ItemID));
    --分部
    SELECT @DeptNo=DeptNo 
    FROM BDM_WareHouse_V 
    WHERE CodeID=@WareHouse;
    SET @errors=0;
    BEGIN TRANSACTION
    --获取最后盘点差异数据
    INSERT INTO @uTmp(DeptNo,WareHouse,ItemID,SQty)
    SELECT @DeptNo,@WareHouse,t1.ItemID,ISNULL(t1.SQty,0.0)-ISNULL(t2.CurQty,0.0)
	FROM (SELECT b.ItemID,SUM(ISNULL(b.SQty,0.0)) AS SQty,MAX(b.checkId) AS checkId
		  FROM dbo.IMS_Check a
          INNER JOIN dbo.IMS_CheckDtl b ON a.CheckNo=b.CheckNo
		  WHERE a.LotNo=@LotNo AND a.WareHouse=@WareHouse 
              AND a.BillSts NOT IN('00','10')
		  GROUP BY b.ItemID
		) t1 INNER JOIN dbo.IMS_CheckDtl t2 ON t1.checkId=t2.CheckID
	WHERE t2.LotNo=@LotNo AND t2.WareHouse=@WareHouse 
		AND ISNULL(t1.SQty,0.0)-ISNULL(t2.CurQty,0.0)!=0.0;
    SET @errors=@errors+@@ERROR;
       
    IF (@Flag='20')
    BEGIN
        --更新盘点单状态
        UPDATE dbo.IMS_Check SET BillSts='30',CancelFlag='',CheckTime=GETDATE() WHERE LotNo=@LotNo AND WareHouse=@WareHouse AND BillSts='20';
        IF (@@ROWCOUNT>0)    
        BEGIN
            --写入流水账
            INSERT INTO IMS_Flow(BillNo,DeptNo,WareHouse,CreateDate,BillType,AuditDate,ItemID,SQty)
    	    SELECT @LotNo,@DeptNo,@WareHouse,CONVERT(CHAR(10),GETDATE(),23),'盘存清单',CONVERT(CHAR(10),GETDATE(),23),ItemID,SQty
		    FROM @uTmp;
            SET @errors=@errors+@@ERROR;

        	--更新商品资料文件
        	UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
        	FROM BDM_ItemInfo a 
                INNER JOIN @uTmp b ON a.ItemID=b.ItemID;
            SET @errors=@errors+@@ERROR;

        	--更新分部库存！
        	UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0)+ISNULL(b.SQty,0.0)
        	FROM IMS_Subdepot a 
                INNER JOIN @uTmp b ON a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID;
            SET @errors=@errors+@@ERROR;
        	--插入没有的分部库存
        	INSERT INTO IMS_Subdepot(DeptNo,ItemID,OnHandQty)
        	SELECT DeptNo,ItemID,ISNULL(SQty,0.0)
        	FROM @uTmp a 
        	WHERE NOT EXISTS(SELECT * FROM IMS_Subdepot b WHERE a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID);

        	SET @errors=@errors+@@ERROR;	
        	--更新库房
        	UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0),a.LastTime=GETDATE()
        	FROM IMS_Ledger a 
                INNER JOIN @uTmp b ON a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID;
        	SET @errors=@errors+@@ERROR;
            --插入没有的
        	INSERT INTO IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastTime)
        	SELECT DeptNo,WareHouse,ItemID,ISNULL(SQty,0.0),GETDATE()
        	FROM @uTmp a
        	WHERE NOT EXISTS(SELECT * FROM IMS_Ledger b WHERE a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID);
            SET @errors=@errors+@@ERROR;
        END
    END
	ELSE IF (@Flag='10')
    BEGIN
        UPDATE dbo.IMS_Check SET BillSts='20',CancelFlag='T',CheckTime=NULL WHERE LotNo=@LotNo And WareHouse=@WareHouse AND BillSts='30';
        IF (@@ROWCOUNT>0)
        BEGIN
            --从流水帐删除
            DELETE FROM IMS_Flow WHERE BillNo=@LotNo AND WareHouse=@WareHouse;
            --更新商品资料文件
            UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
            FROM BDM_ItemInfo a 
                INNER JOIN @uTmp b ON a.ItemID=b.ItemID;
            --更新分部库存！
            UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
            FROM IMS_Subdepot a 
                INNER JOIN @uTmp b ON a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID;
            --更新库房
            UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
            FROM IMS_Ledger a 
                INNER JOIN @uTmp b ON a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID;
        END
    END
    --清除内存，并处理错误
    DELETE FROM @uTmp;
    SET @errors=@errors+@@ERROR;
    IF (@errors=0)
    BEGIN
        COMMIT;
    END; 
    ELSE
    BEGIN
        IF @@TRANCOUNT > 0
            ROLLBACK;
        SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;	
        --写入同步错误日志	
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
        VALUES(LOWER(REPLACE(NEWID(),'-','')),'01',GETDATE(),'99','sp_IMSChecked','IMS_CHECK_FINISHED_ERROR',LEFT(@ErrMsg,2000),@LotNo,@LotNo);
        RAISERROR(@ErrMsg, @ErrSeverity, 1);
    END;
END
go

