--说明：分部零售毛利统计(按分部汇总)
--作者：Devil.H
--创建：2013.06.14
--参数：
--	@Period:会计月份额
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@DeptNo:部门
--	@Flag:前台标识
CREATE Function dbo.fn_AnalRMS804
(
	@Period varchar(6),
	@StartDate varchar(10),
	@EndDate varchar(10),
	@DeptNo varchar(20),
	@Flag int=0
)
Returns @uTable Table(
	DeptID varchar(20),
	DeptNo varchar(20),
	DeptName varchar(100),
	ItemId bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemSpec varchar(100),
	BarCode varchar(100),
	ColorName varchar(40),
	UnitName varchar(40),
	ClassId varchar(20),
	ClassName varchar(100),
	LabelId varchar(20),
	LabelName varchar(100),
	BoxNo varchar(100),
	Amt decimal(18,6),
	CstAmt decimal(18,6),
	GProAmt decimal(18,6),
	GProfit decimal(18,6),
	JHCstPrice decimal(18,6), 	--参考成本价
	JHCstAmt decimal(18,6), 	--参考成本
	JHGProAmt decimal(18,6),	--参考毛利
	JHGProfit decimal(18,6)		--参考毛利率
)
As
begin
	if @Flag=0 
		Return
	declare @AmtDec int
	Select @AmtDec=Isnull(AmtDec,2) From Sys_Config
	Set @AmtDec=Isnull(@AmtDec,2)	
	--销售定制品
	Declare @Special Table(DeptNo varchar(20),ItemID bigint,SQty decimal(18,8),CAmt decimal(18,6),SAmt decimal(18,6) Primary Key(DeptNo,ItemID))
	--临时成本表
	Declare @CostTmp Table(DeptNo varchar(20),ItemID bigint,Price decimal(18,10) Primary Key(DeptNo,ItemID))
	--销售数据汇总表
	Declare @TmpSales Table(DeptNo varchar(20),ItemID Bigint,SQty decimal(18,6),Amt decimal(18,6) Primary Key(DeptNo,ItemID))
	--销售数据临时表
	Declare @Sales Table(RowID bigint Identity(1,1),DeptNo varchar(20),ItemID Bigint,SQty decimal(18,6),Amt decimal(18,6) Primary Key(RowID))
	Insert Into @Sales(DeptNo,ItemID,SQty,Amt)
	Select a.DeptNo,b.ItemID,b.SQty,b.Amt
	From SMS_Stock a Inner Join SMS_StockDtl b On a.StockNo=b.StockNo 
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.CreateDate Between @StartDate And @EndDate)
		And (a.BillType='40' Or a.BillType='50')
		And (a.DeptNo Like @DeptNo + '%')

	if Not Exists(Select 1 From @Sales)
		Return
	--汇总销售数据 
	Insert Into @TmpSales(DeptNo,ItemID,SQty,Amt)
	Select DeptNo,ItemID,SUM(SQty),SUM(Amt)
	From @Sales
	Group By DeptNo,ItemID
	--获取临时成本
	INSERT INTO @CostTmp(DeptNo,ItemID,Price)
	SELECT Isnull(DeptNo,'$$$$'),ItemID,MEPrice
	FROM uf_CostPrice(@Period)	

	--成本统计（分部成本法）
	if Exists(Select 1 From SYS_Config Where Isnull(Method,'T')='S')
		Insert Into @uTable(DeptID,ItemId,Amt,CstAmt,GProAmt,JHCstAmt,JHGProAmt)
		Select t.DeptNo,t.ItemId,Isnull(t.Amt,0.0),Isnull(t.CstAmt,0.0),
			Isnull(t.Amt,0.0)-Isnull(t.CstAmt,0.0),Isnull(t.JHCstAmt,0.0),
			Isnull(t.Amt,0.0)-Isnull(t.JHCstAmt,0.0)
		From (Select a.DeptNo,a.ItemID,a.SQty,a.Amt,
				Round(Isnull(a.SQty,0.0)*Isnull(cb.Price,0.0),@AmtDec) As CstAmt,
				Round(Isnull(a.SQty,0.0)*Isnull(jh.Cost,0.0),@AmtDec) AS JHCstAmt
			From @TmpSales a Left Outer Join @CostTmp cb On a.DeptNo=cb.DeptNo And a.ItemID=cb.ItemID
					 Left Outer Join CST_Colligate_COST_Year jh On a.ItemID=jh.ItemID And jh.Period=@Period) t
	Else
		Insert Into @uTable(DeptID,ItemId,Amt,CstAmt,GProAmt,JHCstAmt,JHGProAmt)
		Select t.DeptNo,t.ItemId,Isnull(t.Amt,0.0),Isnull(t.CstAmt,0.0),
			Isnull(t.Amt,0.0)-Isnull(t.CstAmt,0.0),Isnull(t.JHCstAmt,0.0),
			Isnull(t.Amt,0.0)-Isnull(t.JHCstAmt,0.0)
		From (Select a.DeptNo,a.ItemID,a.SQty,a.Amt,
				Round(Isnull(a.SQty,0.0)*Isnull(cb.Price,0.0),@AmtDec) As CstAmt,
				Round(Isnull(a.SQty,0.0)*Isnull(jh.Cost,0.0),@AmtDec) AS JHCstAmt
			From @TmpSales a Left Outer Join @CostTmp cb On a.ItemID=cb.ItemID And cb.DeptNo='$$$$' 
					 Left Outer Join CST_Colligate_COST_Year jh On a.ItemID=jh.ItemID And jh.Period=@Period) t

	--更新部门资料
	Update a Set a.DeptNo=b.CodeNo,a.DeptName=b.CHName,
		GProfit=Case Isnull(a.Amt,0.0) When 0.0 Then 0.0 
					       Else Round(Isnull(a.GProAmt,0.0)/a.Amt,2*@AmtDec) End,
		a.JHGProfit=Case Isnull(a.Amt,0.0) When 0.0 Then 0.0 
						   Else Round(Isnull(a.JHGProAmt,0.0)/a.Amt,2*@AmtDec) End
	From @uTable a Inner Join BDM_DeptCode_V b On a.DeptID=b.CodeID
	--更新商品资料
	Update a Set a.ItemNo=g.ItemNo,a.ItemName=g.ItemName,a.ItemSpec=g.ItemSpec,a.BarCode=g.BarCode,
		a.ColorName=g.ColorName,a.UnitName=g.UnitName,a.ClassId=g.ClassId,a.ClassName=g.ClassName,
		a.LabelId=g.LabelId,a.LabelName=g.LabelName
	From @uTable a Inner Join BAS_Goods_V g On a.ItemID=g.ItemID

	--更新柜组号
	Update a Set a.BoxNo=b.BoxNo
	From @uTable a Inner Join SMS_RetailPrice b On a.DeptNo=b.DeptNo And a.ItemId=b.ItemId
	--返回
	Return
End
go

