--说明：分部零售汇总分析
--作者：Devil.H
--创建：2007.11.21
--修改：2010.05.08 Frank.H
--参数：
--	@StartDate:起始日期
--	@EndDate：截止日期
--	@DeptNo:分部
--	@CorpNo:公司
--	@Flag: 分析标识
CREATE Function dbo.fn_AnalRMS30
(
	@StartDate varchar(10),
	@EndDate varchar(10),
	@CorpNo varchar(30),
	@DeptNo varchar(20),
	@Flag bit
)
Returns Table
As
Return (
	SELECT a.DeptNo,d.CHName AS DeptName,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(c.Amt,0.0) WHEN '50' THEN -ISNULL(c.Amt,0.0) END) AS Amt,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(a.DiscAmt,0.0) WHEN '50' THEN -ISNULL(a.DiscAmt,0.0) END) AS DiscAmt,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(a.PaymentXJ,0.0) WHEN '50' THEN -ISNULL(a.PaymentXJ,0.0) END) AS XJAmt,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(a.PaymentSK,0.0) WHEN '50' THEN -ISNULL(a.PaymentSK,0.0) END) AS SKAmt,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(a.PaymentZP,0.0) WHEN '50' THEN -ISNULL(a.PaymentZP,0.0) END) AS ZPAmt,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(a.PaymentDD,0.0) WHEN '50' THEN -ISNULL(a.PaymentDD,0.0) END) AS DDAmt,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(a.PaymentCZ,0.0) WHEN '50' THEN -ISNULL(a.PaymentCZ,0.0) END) AS CZAmt,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(a.Receive1Amt,0.0) WHEN '50' THEN -ISNULL(a.Receive1Amt,0.0) END) AS Receive1Amt,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(a.Receive2Amt,0.0) WHEN '50' THEN -ISNULL(a.Receive2Amt,0.0) END) AS Receive2Amt,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(a.Receive3Amt,0.0) WHEN '50' THEN -ISNULL(a.Receive3Amt,0.0) END) AS Receive3Amt,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(c.Amt,0.0)-ISNULL(a.DiscAmt,0.0) WHEN '50' THEN -(ISNULL(c.Amt,0.0)-ISNULL(a.DiscAmt,0.0)) END) AS SJXSAmt
	FROM SMS_Retail a INNER JOIN (SELECT RetailNo,SUM(ISNULL(Amt,0.0)) AS Amt	
					FROM SMS_RetailDtl
					GROUP BY RetailNo) c ON a.RetailNo=c.RetailNo
			  LEFT OUTER JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
	WHERE (a.BillSts='20' Or a.BillSts='30')
		And Convert(char(10),CreateDate,120) Between @StartDate And @EndDate
		And (a.DeptNo Like @DeptNo + '%')
		And (d.DeptNo Like @CorpNo + '%')
	GROUP BY a.DeptNo,d.CHName
)
go

