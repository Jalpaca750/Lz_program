--说明：列出此用户需要别人审批的单据
--作者：wujinfeng
--创建：2008.11.03
--参数：
--	@EmployeeID 当前用户

CREATE Function uf_BillAuditing_Wait_List
(
	@EmployeeID as bigint
)
Returns Table
As
RETURN (

	SELECT distinct a.TblCode,a.Auditing_type,a.BillNo,d.TblName As BillName,a.EmployeeID,c.EmployeeName As employeename,CreateDate
			,a.Auditing_EmployeeID,e.EmployeeName As Auditing_EmployeeName
		FROM  BillAuditing a 
			LEFT OUTER JOIN  dbo.BDM_Employee c ON a.EmployeeID = c.EmployeeID
			LEFT OUTER JOIN   dbo.BDM_Employee e ON a.Auditing_EmployeeID = e.EmployeeID
			LEFT OUTER JOIN  dbo.Sys_AuditParm d ON a.TblCode = d.TblCode
		where BlankFlag='0' And (Auditing_Status='0' or Auditing_Status='1') And a.EmployeeID=@EmployeeID 
		and BillNo not in (select BillNo from BillAuditing where Auditing_Status='2' And EmployeeID=@EmployeeID)
	)

















go

