CREATE proc [dbo].[sp_AfterPMS40Audit]
(
	@orderNo VARCHAR(32),
	@billSts CHAR(2),
	@userId BIGINT
)
AS
BEGIN
    DECLARE @companyId VARCHAR(32),			   --公司Id
            @ownerId VARCHAR(32),			   --业主Id
            @warehouseId VARCHAR(32),		   --仓库Id
            @operatorId VARCHAR(32),		   --操作员Id	
            @curTime DATETIME,				   --操作时间 
            @guid VARCHAR(32),                 --GUID  
            @errors BIGINT;                    --错误码
    DECLARE @poNo VARCHAR(32),					--订单号(F10的OrderNo)
            @orderBillNo VARCHAR(32),			--采购订单编号
            @orderDate VARCHAR(10),				--采购订单下单日期
            @supplierId VARCHAR(32),			--供应商Id
            @requireDate VARCHAR(10),			--收货日期
            @requireTime VARCHAR(40),			--收货时间
            @deptId VARCHAR(32),				--经办部门（订货部门）			
            @handlerId VARCHAR(32),				--经办人
            @buyerId VARCHAR(32),				--采购员
            @currencyId VARCHAR(32),			--币种
            @exchangeRate DECIMAL(20,10),		--汇率
            @taxFlag INT,						--是否含税
            @poState INT,						--2,已审核
            @apState INT,						--0-待付款
            @orderSource INT,					--订单类型
            @totalFee DECIMAL(20,10),			--订单金额
            @wmsOrder VARCHAR(32),				--wms订单orderNo
            @creatorId VARCHAR(32),				--制单人
            @memo VARCHAR(2000);				--备注			
    DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int;
    --2000数据库兼容排序
    DECLARE @tmpDetail TABLE(orderId VARCHAR(32),orderNo VARCHAR(32),companyId VARCHAR(32),planId VARCHAR(32),planNo VARCHAR(32),
        planBillNo VARCHAR(32),viewOrder INT IDENTITY(1,1),warehouseId VARCHAR(32),eId VARCHAR(32),itemId VARCHAR(32),orderQty DECIMAL(20,6),
        pkgQty DECIMAL(20,6),bulkQty DECIMAL(20,6),befPrice DECIMAL(20,10),discount DECIMAL(6,2),discountFee DECIMAL(20,10),price DECIMAL(20,10),
        taxrate DECIMAL(6,2),fee DECIMAL(20,10),taxFee DECIMAL(20,10),totalFee DECIMAL(20,10),rebate DECIMAL(6,2),toOrder INT,updPrice INT,
        taxFlag INT,isTemporary INT,isEmergency INT,isPromotion INT,lotNo VARCHAR(32),buyerId VARCHAR(32),handlerId VARCHAR(32),deptId VARCHAR(32),
        sdOrderId VARCHAR(32),sdOrderNo VARCHAR(32),sdBillNo VARCHAR(32),sdCustomerNo VARCHAR(32),sdCustomerName VARCHAR(200),contractId VARCHAR(32),
        contractNo VARCHAR(32),poId VARCHAR(32),remarks VARCHAR(2000))
    SET @curTime=GETDATE();	
	--如果未开启同步，则停止推送
	IF NOT EXISTS(SELECT * FROM dbo.SYS_Config WHERE ISNULL(startWms,0)=1)
		RETURN;	
	--如果非配置数据，直接退出
	IF NOT EXISTS(SELECT * FROM dbo.PMS_Order WHERE OrderNo=@OrderNo AND DeptNo IN (SELECT DeptNo FROM WMS_Config))
		RETURN;
    --获取公司Id,业主Id
    SELECT TOP 1 @companyId=companyId,@ownerId=OwnerId FROM dbo.SYS_Config;
    --删除错误日志
	DELETE FROM dbo.SAM_Error WHERE funCode='sp_AfterPMS40Audit' AND billNo=@orderNo;
	SET @errors=0;
    BEGIN TRANSACTION
    IF @BillSts='20'
    BEGIN
    	--获取F10采购订单资料
    	SELECT	@poNo=poNo,
    			@orderDate=orderDate,
    			@supplierId=supplierId,
    			@requireDate=requireDate,
    			@requireTime=requireTime,
    			@deptId=deptId,
    			@handlerId=handlerId,
    			@buyerId=buyerId,
    			@currencyId=currencyId,
    			@exchangeRate=exchangeRate,
    			@taxFlag=taxFlag,
    			@poState=poState,
    			@apState=apState,
    			@orderSource=orderSource,
    			@totalFee=totalFee,
    			@warehouseId=warehouseId,
    			@wmsOrder=wmsOrder,
    			@creatorId=creatorId,
    			@memo=memo
    	FROM dbo.Sync_PMS_Order_V
    	WHERE poNo=@orderNo;
        SET @errors=@errors+@@ERROR;
    	--已经同步过的数据不需要同步
    	IF EXISTS(SELECT * FROM dbo.PMS_Order WHERE OrderNo=@OrderNo AND syncFlag=1)
    		OR EXISTS(SELECT * FROM YiWms.dbo.PMS_Order WHERE companyId=@companyId AND ownerId=@ownerId AND poNo=@OrderNo)
    	BEGIN
    		--获取已更新的订单
    		SELECT @wmsOrder=orderNo FROM YiWms.dbo.PMS_Order WHERE companyId=@companyId AND ownerId=@ownerId AND poNo=@OrderNo;
    		--更新订单状态
    		UPDATE dbo.PMS_Order SET syncFlag=1,wmsOrder=@wmsOrder,editTime=GETDATE() WHERE OrderNo=@OrderNo;
            SET @errors=@errors+@@ERROR;
    		COMMIT;
    		RETURN;
    	END
    	--检查供应商资料是否同步(同步视图数据)
    	IF NOT EXISTS(SELECT * FROM dbo.Sync_PMS_Order_V WHERE poNo=@OrderNo)
    	BEGIN
    		--写入同步错误日志	
    		INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
    		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterPMS40Audit','YI_PO_SUPPLIER_NOT_SYNC_ERROR',
    			'订单[' + @OrderNo + ']对应供应商资料没有同步到WMS，订单同步失败',@OrderNo,@OrderNo);
            SET @errors=@errors+@@ERROR;
    		COMMIT;
    		RETURN;
    	END	
    	--检查商品资料是否有没同步的
    	IF EXISTS(SELECT * FROM dbo.PMS_OrderDtl a WHERE a.OrderNo=@OrderNo AND (ISNULL(OQty,0.0)-ISNULL(SQty,0.0)>0.0) AND OrderID NOT IN(SELECT poId FROM dbo.Sync_PMS_OrderDtl_V WHERE OrderNo=@OrderNo))
    	BEGIN
    		--写入同步错误日志	
    		INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
    		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterPMS40Audit','YI_PO_ITEM_NOT_SYNC_ERROR',
    			'订单[' + @OrderNo + ']对应商品资料没有同步到WMS，订单同步失败',@OrderNo,@OrderNo);
            SET @errors=@errors+@@ERROR;
    		COMMIT;
    		RETURN;
    	END
    	--如果没有同步过，则@wmsOrder取得一个新的GUID
    	IF (ISNULL(@wmsOrder,'')='')
    		SET @wmsOrder=LOWER(REPLACE(NEWID(),'-',''));
    	SET @orderBillNo=@orderNo;
    	--写入采购订单主表
    	INSERT INTO YiWms.dbo.PMS_Order(orderNo,billNo,orderDate,companyId,ownerId,supplierId,requireDate,
    		requireTime,deptId,handlerId,warehouseId,buyerId,currencyId,exchangeRate,taxFlag,
    		poState,apState,orderSource,totalFee,auditTime,auditorId,poNo,memo,createTime,
    		creatorId,printNum,isLocked,lockerId,lockedTime,editTime,editorId)
    	VALUES(@wmsOrder,@orderBillNo,@orderDate,@companyId,@ownerId,@supplierId,@requireDate,
    		@requireTime,@deptId,@handlerId,@warehouseId,@buyerId,@currencyId,@exchangeRate,@taxFlag,
    		@poState,@apState,@orderSource,@totalFee,@curTime,@operatorId,@orderBillNo,@memo,@curTime,
    		@creatorId,0,0,'',NULL,@curTime,@operatorId);
        SET @errors=@errors+@@ERROR;        
        --写入临时表排序(主要兼容2000语法)
        INSERT INTO @tmpDetail(orderId,orderNo,companyId,planId,planNo,planBillNo,
    		warehouseId,eId,itemId,orderQty,pkgQty,bulkQty,befPrice,discount,discountFee,price,taxrate,
    		fee,taxFee,totalFee,rebate,toOrder,updPrice,taxFlag,isTemporary,isEmergency,isPromotion,lotNo,buyerId,
    		handlerId,deptId,sdOrderId,sdOrderNo,sdBillNo,sdCustomerNo,sdCustomerName,contractId,contractNo,poId,remarks)
    	SELECT orderId,@wmsOrder,@companyId,planId,planNo,planBillNo,@warehouseId,eId,itemId,orderQty,
            CASE ISNULL(pkgRatio,0) WHEN 0.0 THEN 0.0 ELSE FLOOR(orderQty/pkgRatio) END AS pkgQty,
    		CASE ISNULL(pkgRatio,0) WHEN 0.0 THEN orderQty ELSE orderQty-(FLOOR(orderQty/pkgRatio)*pkgRatio) END AS bulkQty,
    		befPrice,discount,discountFee,price,taxrate,fee,taxFee,totalFee,rebate,toOrder,updPrice,taxFlag,isTemporary,
    		isEmergency,isPromotion,'',@buyerId,@handlerId,@deptId,sdOrderId,sdOrderNo,sdOrderNo,sdCustomerNo,sdCustomerName,
    		contractId,contractNo,poId,remarks
    	FROM dbo.Sync_PMS_OrderDtl_V 
    	WHERE orderNo=@orderNo
        ORDER BY orderNo,poId;
        SET @errors=@errors+@@ERROR;
    	--写入采购订单明细表
    	INSERT INTO YiWms.dbo.PMS_OrderDetail(orderId,orderNo,companyId,planId,planNo,planBillNo,viewOrder,
    		warehouseId,eId,itemId,orderQty,pkgQty,bulkQty,befPrice,discount,discountFee,price,taxrate,
    		fee,taxFee,totalFee,rebate,toOrder,updPrice,taxFlag,isTemporary,isEmergency,isPromotion,lotNo,buyerId,
    		handlerId,deptId,sdOrderId,sdOrderNo,sdBillNo,sdCustomerNo,sdCustomerName,contractId,contractNo,poId,remarks)
    	SELECT orderId,orderNo,companyId,planId,planNo,planBillNo,viewOrder,
    		warehouseId,eId,itemId,orderQty,pkgQty,bulkQty,befPrice,discount,discountFee,price,taxrate,
    		fee,taxFee,totalFee,rebate,toOrder,updPrice,taxFlag,isTemporary,isEmergency,isPromotion,lotNo,buyerId,
    		handlerId,deptId,sdOrderId,sdOrderNo,sdBillNo,sdCustomerNo,sdCustomerName,contractId,contractNo,poId,remarks
        FROM @tmpDetail;
        SET @errors=@errors+@@ERROR;
    	--更新订单状态(已同步，WMS订单号和最后修改时间）
    	UPDATE dbo.PMS_Order SET syncFlag=1,wmsOrder=@wmsOrder,editTime=@curTime WHERE OrderNo=@orderNo;
        SET @errors=@errors+@@ERROR;
    	INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
    	VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterPMS40Audit','同步采购订单[' + @orderNo + ']',@wmsOrder,'EXEC sp_AfterPMS40Audit ''' + @orderNo + ''',''20'',' + CAST(@userId AS VARCHAR(10))); 
        SET @errors=@errors+@@ERROR;
    END
    --取消采购订单审核
    IF (@billSts='10')
    BEGIN
    	SELECT @wmsOrder=orderNo FROM YiWms.dbo.PMS_Order WHERE companyId=@companyId AND ownerId=@ownerId AND poNo=@OrderNo;			
    	DELETE FROM YiWms.dbo.PMS_OrderDetail WHERE orderNo=@wmsOrder;
        SET @errors=@errors+@@ERROR;
    	DELETE FROM YiWms.dbo.PMS_Order WHERE orderNo=@wmsOrder;
        SET @errors=@errors+@@ERROR;
    	INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
    	VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterPMS40Audit','取消采购订单[' + @orderNo + ']',@wmsOrder,'EXEC sp_AfterPMS40Audit ''' + @orderNo + ''',''10'',' + CAST(@userId AS VARCHAR(10))); 
        SET @errors=@errors+@@ERROR;
    END
    IF (@billSts='05')
    BEGIN
    	SELECT @wmsOrder=orderNo FROM YiWms.dbo.PMS_Order WHERE companyId=@companyId AND ownerId=@ownerId AND poNo=@OrderNo;
    	--更新订单状态(已同步，WMS订单号和最后修改时间）
    	UPDATE dbo.PMS_Order SET syncFlag=1,editTime=@curTime WHERE OrderNo=@orderNo;
    	SET @errors=@errors+@@ERROR;
        UPDATE YiWms.dbo.PMS_Order SET poState=-3 WHERE orderNo=@wmsOrder;
    	SET @errors=@errors+@@ERROR;
        INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
    	VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterPMS40Audit','终止采购订单[' + @orderNo + ']',@wmsOrder,'EXEC sp_AfterPMS40Audit ''' + @orderNo + ''',''05'',' + CAST(@userId AS VARCHAR(10))); 
        SET @errors=@errors+@@ERROR;
    END
    IF (@errors=0)
    BEGIN
		COMMIT;
	END
    ELSE
	BEGIN
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;		
		--写入同步错误日志	
		INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterPMS40Audit','YI_PO_SYNC_ERROR',LEFT(@ErrMsg,2000),@OrderNo,@OrderNo);
	END
END
go

