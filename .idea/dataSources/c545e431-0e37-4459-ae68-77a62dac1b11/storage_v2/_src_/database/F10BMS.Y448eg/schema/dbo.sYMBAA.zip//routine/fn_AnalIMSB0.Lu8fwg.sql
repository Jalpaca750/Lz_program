--说明：其他入出库单汇总分析
--作者：Devil.H
--创建：2007.11.19
--参数：
--	@Year:年度
--	@Month:月份
--	@Flag:标识
CREATE Function dbo.fn_AnalIMSB0
(
	@Period varchar(6),
	@StartDate varchar(10),
	@EndDate varchar(10),
	@DeptNo varchar(20),
	@Flag bit
)
returns @uTable Table(
	Seq bigint IDENTITY(1,1),
	DeptNo varchar(20),
	DeptName varchar(100),
	WareHouse varchar(20),
	WHName varchar(100),
	BillType varchar(40),
	IOObject varchar(40),
	ObjectNo varchar(40),
	ObjectName varchar(200),
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemAlias varchar(200),
	NameSpell varchar(200),
	ItemSpec varchar(100),
	BarCode varchar(100),
	ClassID varchar(20),
	ClassName varchar(100),
	LabelID varchar(20),
	LabelName varchar(100),
	ColorName varchar(40),
	UnitName varchar(40),
	SQty decimal(18,6),
	CPrice decimal(18,6),
	Amt decimal(18,6),
	CBAmt decimal(18,6)
	Primary Key(Seq)
)
As
Begin
	if @Flag=0 
		Return

	declare @Method char(1)
	--获取成本计算方式
	Select @Method=isnull(Method,'S') From Sys_Config
	Declare @CostTmp Table
	(
		DeptNo varchar(20),
		ItemID bigint,
		Price decimal(18,6)
		Primary Key(DeptNo,ItemID)
	)
	Declare @Tmp Table(Seq bigint IDENTITY(1,1),
			   DeptNo varchar(20),
			   DeptName varchar(40),
		           WareHouse varchar(20),
			   WHName varchar(40),
			   BillType varchar(40),
			   IOObject varchar(40),
			   ObjectNo varchar(40),
	                   ObjectName varchar(100),
			   ItemID Bigint,
			   SQty decimal(18,6),
			   Price decimal(18,6),
			   Amt decimal(18,6)
			   Primary Key(Seq)
			   )
	--获取临时成本
	Insert Into @CostTmp(DeptNo,ItemID,Price)
	Select Isnull(DeptNo,'$$$$'),ItemID,MEPrice
	From uf_CostPrice(@Period)
	--其他如出库单临时表
	Insert Into @Tmp(DeptNo,DeptName,WareHouse,WHName,BillType,IOObject,ObjectNo,ObjectName,ItemID,SQty,Amt)
	Select a.DeptNo,a.DeptName,a.WareHouse,a.WHName,a.BillType,a.IOObject,a.ObjectNo,a.ObjectName,
		b.ItemID,SUM(b.SQty),SUM(b.Amt)
	From IMS_Other_V a Inner Join IMS_OtherDtl b On a.OtherNo=b.OtherNo
	Where a.BillSts='20' 
		And (a.CreateDate Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%')
	Group By a.DeptNo,a.DeptName,a.WareHouse,a.WHName,a.BillType,a.IOObject,a.ObjectNo,a.ObjectName,b.ItemID
	--获取当调拨出库单成本价
	if @Method='S'
		Insert Into @uTable(DeptNo,DeptName,WareHouse,WHName,BillType,IOObject,ObjectNo,ObjectName,
			ItemNo,ItemName,ItemAlias,NameSpell,ItemSpec,BarCode,ClassID,ClassName,LabelID,LabelName,
			ColorName,UnitName,SQty,Amt,CPrice,CBAmt)
		Select a.DeptNo,a.DeptName,a.WareHouse,a.WHName,a.BillType,a.IOObject,a.ObjectNo,
			a.ObjectName,g.ItemNo,g.ItemName,g.ItemAlias,g.NameSpell,g.ItemSpec,g.BarCode,
			g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,g.UnitName,a.SQty,
			a.Amt,b.Price,Isnull(a.SQty,0.0)*Isnull(b.Price,0.0) as CBAmt
		From @Tmp a Inner Join BAS_Goods_V g On a.ItemID=g.ItemID
			    Left Outer Join @CostTmp b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
	Else
		Insert Into @uTable(DeptNo,DeptName,WareHouse,WHName,BillType,IOObject,ObjectNo,ObjectName,
			ItemNo,ItemName,ItemAlias,NameSpell,ItemSpec,BarCode,ClassID,ClassName,LabelID,LabelName,
			ColorName,UnitName,SQty,Amt,CPrice,CBAmt)
		Select a.DeptNo,a.DeptName,a.WareHouse,a.WHName,a.BillType,a.IOObject,a.ObjectNo,
			a.ObjectName,g.ItemNo,g.ItemName,g.ItemAlias,g.NameSpell,g.ItemSpec,g.BarCode,
			g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,g.UnitName,a.SQty,
			a.Amt,b.Price,Isnull(a.SQty,0.0)*Isnull(b.Price,0.0) as CBAmt
		From @Tmp a Inner Join BAS_Goods_V g On a.ItemID=g.ItemID
			    Left Outer Join @CostTmp b On a.ItemID=b.ItemID And b.DeptNo='$$$$'
	Return
End
go

