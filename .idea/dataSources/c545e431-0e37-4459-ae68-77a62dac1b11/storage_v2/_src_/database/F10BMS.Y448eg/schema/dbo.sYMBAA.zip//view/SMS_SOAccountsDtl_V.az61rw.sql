CREATE VIEW dbo.SMS_SOAccountsDtl_V
AS
SELECT b.StockID,a.StockNo,a.CreateDate,a.SendDate,a.SendAddr,b.Location,b.ItemID,c.ItemNo,c.ItemName, 
    c.ItemAlias,c.ItemSpec,c.ClassName,c.LabelName,c.ColorName,c.PkgSpec,c.UnitName,b.PkgQty, b.SQty, 
    ISNULL(b.SQty, 0.0) - ISNULL(b.IQty, 0.0) AS RemIQty, b.Price, b.Amt, b.ZQty, b.PaidAmt, 
    b.IAmt,b.DiscRate,b.IsSpecial,b.IsEffect,b.TaxFlag,ISNULL(b.Amt, 0.0) - ISNULL(b.IAmt, 0.0) AS RemIAmt,
    b.OrderNo, a.orderreninfo,a.PoNo,d.CustNo,d.CustName,b.Remarks,c.Defined1,c.Defined2,c.Defined3,
    (SELECT CHName FROM Web_Costs_Class cb WHERE a.CostsID = cb.CostsID) AS CostsName,a.Remarks AS Memo
FROM SMS_Stock a 
    INNER JOIN SMS_StockDtl b ON a.StockNo = b.StockNo 
    INNER JOIN BAS_Goods_V c ON b.ItemID = c.ItemID
    INNER JOIN BAS_Customer_V d ON a.CustID=d.CustID
WHERE (a.BillSts = '20' OR a.BillSts = '25') 
    AND (a.SMSAStockFlag = '0') 
    AND (ISNULL(b.Amt, 0.0) - ISNULL(b.IAmt, 0.0)<>0.0 Or Isnull(b.SQty,0.0)-Isnull(b.IQty,0.0)<>0.0)
UNION All
SELECT b.StockID,a.StockNo,a.CreateDate,a.SendDate,a.SendAddr,b.Location,b.ItemID,c.ItemNo,c.ItemName,
    c.ItemAlias,c.ItemSpec, c.ClassName, c.LabelName, c.ColorName, c.PkgSpec, c.UnitName, b.PkgQty, b.SQty, 
    ISNULL(b.SQty, 0.0) - ISNULL(b.IQty, 0.0) AS RemIQty, b.Price, b.Amt, b.ZQty, b.PaidAmt, 
    b.IAmt, b.DiscRate, b.IsSpecial, b.IsEffect, b.TaxFlag, ISNULL(b.Amt, 0.0) - ISNULL(b.IAmt, 0.0) AS RemIAmt, 
    b.OrderNo, a.orderreninfo,a.PoNo,d.CustNo,d.CustName,b.Remarks,c.Defined1,c.Defined2,c.Defined3,
    (SELECT CHName FROM Web_Costs_Class cb WHERE a.CostsID = cb.CostsID) AS CostsName,a.Remarks AS Memo
FROM dbo.SMS_AStock a 
    INNER JOIN dbo.SMS_AStockDtl b ON a.StockNo = b.StockNo 
    INNER JOIN dbo.BAS_Goods_V c ON b.ItemID = c.ItemID
INNER JOIN BAS_Customer_V d ON a.CustID=d.CustID
WHERE (a.BillSts = '20' OR a.BillSts = '25') 
    AND (ISNULL(b.Amt, 0.0) - ISNULL(b.IAmt, 0.0)<>0.0 Or Isnull(b.SQty,0.0)-Isnull(b.IQty,0.0)<>0.0)
go

