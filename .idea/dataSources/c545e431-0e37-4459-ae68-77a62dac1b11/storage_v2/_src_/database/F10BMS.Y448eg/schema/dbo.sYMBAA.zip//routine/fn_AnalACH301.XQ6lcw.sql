
CREATE Function dbo.fn_AnalACH301
(
	@StartDate varchar(10),
	@EndDate varchar(10),
	@Flag int
)
Returns @uTable Table(
	EmployeeID bigint,
	EmployeeName varchar(100),
	DeptNo varchar(20),
	CarRenID bigint,
	CarRenName varchar(100),
	BillType varchar(40),
	BillAmt decimal(18,6),
	BillCount bigint,
	PartQty decimal(18,6),
	AvgBillAmt decimal(18,6),
	AvgPartQty decimal(18,6)
)
As
Begin
	if @Flag=0
		Return
	Insert Into @uTable(EmployeeID,EmployeeName,DeptNo,CarRenID,CarRenName,BillType,BillAmt,PartQty,BillCount)
	Select a.Delivery,d.EmployeeName As DeliveryName,d.DeptCode,a.CarRenID,c.EmployeeName As CarRenName,
		b.BillType,Sum(b.ZAmt) AS Amt,Sum(b.PartQty) AS PartQty,Count(a.CarNumberNo) 
	From SMS_CarNumber a Inner Join 
	      SMS_CarNumberDtl b ON a.CarNumberNo=b.CarNumberNo Left Outer Join 
	      BDM_Employee d On a.Delivery=d.EmployeeID Left Outer Join
	      BDM_Employee c ON a.CarRenID=c.EmployeeID 
	Where (a.BillSts='20') And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.Delivery,d.EmployeeName,d.DeptCode,a.CarRenID,c.EmployeeName,b.BillType

	Update @uTable Set AvgBillAmt=Case Isnull(BillCount,0)
					When 0 then 0
					Else Round(Isnull(BillAmt,0.0)/BillCount,2) End,
			   AvgPartQty=Case Isnull(PartQty,0)
					When 0 then 0
					Else Round(Isnull(BillAmt,0.0)/PartQty,2) End
	Return
End
go

