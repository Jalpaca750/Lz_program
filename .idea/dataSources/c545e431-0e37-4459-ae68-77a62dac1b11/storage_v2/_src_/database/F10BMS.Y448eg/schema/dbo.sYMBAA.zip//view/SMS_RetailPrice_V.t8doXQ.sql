CREATE VIEW SMS_RetailPrice_V as
Select a.DeptNo,d.CHName As DeptName,a.ItemID,g.ItemNo,g.ItemName,g.ItemAlias,g.ItemSpec,
	g.NameSpell,g.BarCode,g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,
	g.UnitName,Isnull(a.SPrice,g.SPrice) As SPrice,Isnull(a.SPrice1,g.SPrice1) As SPrice1,
	Isnull(a.SPrice2,g.SPrice2) As SPrice2,Isnull(a.SPrice3,g.SPrice3) As SPrice3,
	Isnull(a.SafeSPrice,g.SafeSPrice) As SafeSPrice,g.Origin,a.LstDate,a.SourceDesc,
        a.BoxNo,a.BillNo
From SMS_RetailPrice a Left Outer Join 
	BDM_DeptCode_V d On a.DeptNo=d.CodeID Left Outer Join 
	BAS_Goods_V g On a.ItemID=g.ItemID
go

