--说明：采购欠款综合查询
--作者：Devil.H
--创建：2010.11.15
--参数：
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag：标志
CREATE Function dbo.fn_AnalACMA0
(
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag int=0
)
Returns @uTable Table(
	VendorID bigint,
	VendorNo varchar(20),
	VendorName varchar(200),
	NameSpell varchar(200),
	BuyerID bigint,
	Buyer varchar(100),
	LJQCAmt decimal(18,6),
	LJCGAmt decimal(18,6),
	LJFPAmt decimal(18,6),
	LJFZAmt decimal(18,6),
	LJFKAmt decimal(18,6),
	LJMFAmt decimal(18,6),
	LJYFAmt decimal(18,6),
	LJCXAmt decimal(18,6),
	LJRemIAmt decimal(18,6),
	LJRemPAmt decimal(18,6),
	LJQHKAmt decimal(18,6),
	LJQKAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40)
)
As
Begin	
	if @Flag=0
		Return
	--临时表
	declare @Tmp Table(VendorID bigint,
			   LJCGAmt decimal(18,6) Default 0.0,
			   LJFPAmt decimal(18,6) Default 0.0,
			   LJFZAmt decimal(18,6) Default 0.0,
			   LJFKAmt decimal(18,6) Default 0.0,
			   LJMFAmt decimal(18,6) Default 0.0,
			   LJYFAmt decimal(18,6) Default 0.0,
			   LJCXAmt decimal(18,6) Default 0.0,
			   LJQCAmt decimal(18,6) Default 0.0)
	--累计期采购额
	Insert Into @Tmp(VendorID,LJCGAmt)
	Select a.VendorID,Sum(b.Amt) as LJCGAmt
  	From PMS_Stock a inner join PMS_StockDtl b on a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='30' Or a.BillSts='25')  
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By a.VendorID
	--累计开票
	Insert Into @Tmp(VendorID,LJFPAmt,LJFZAmt)
	Select a.VendorID,Sum(a.IAmt) as LJFPAmt,Sum(a.DAmt) as LJFZAmt
	From PMS_Invoice a
	Where (a.BillSts='20' Or a.BillSts='30' Or a.BillSts='25')
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group by a.VendorID
	--累计收款、免收金额
	Insert Into @Tmp(VendorID,LJFKAmt,LJMFAmt)		
	Select a.VendorID,Sum(b.PayAmt) as LJFKAmt,Sum(b.FAmt) as LJMFAmt
	From PMS_Payment a inner join PMS_PaymentDtl b on a.PaymentNo=b.PaymentNo
	Where (a.BillSts='20') And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By a.VendorID
	--预付款
	Insert Into @Tmp(VendorID,LJYFAmt)	
	Select b.VendorID,Sum(b.AdvAmt) as LJYFAmt
	From PMS_Advances a inner join PMS_AdvancesDtl b on a.AdvancesNo=b.AdvancesNo
	Where (a.BillSts='20') And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By b.VendorID
	--冲销预付款
	Insert Into @Tmp(VendorID,LJCXAmt)	
	Select a.VendorID,Sum(a.AdvAmt) as LJCXAmt
	From PMS_Payment a
	Where (a.BillSts='20') And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group By a.VendorID
	--统计期初欠款
	Insert Into @Tmp(VendorID,LJQCAmt)
	Select a.VendorID,Sum(a.IAmt) as LJQCAmt
	From PMS_Invoice a
	Where (a.InvoiceNo Like '$00%') And (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group by a.VendorID
	--合计
	Insert Into @uTable(VendorID,LJQCAmt,LJCGAmt,LJFPAmt,LJFZAmt,LJFKAmt,LJMFAmt,LJYFAmt,LJCXAmt,LJRemIAmt,LJRemPAmt,LJQHKAmt,LJQKAmt)
	Select VendorID,Sum(LJQCAmt),Sum(LJCGAmt),Sum(LJFPAmt),Sum(LJFZAmt),Sum(LJFKAmt),Sum(LJMFAmt),Sum(LJYFAmt),Sum(LJCXAmt),
		Sum(Isnull(LJQCAmt,0.0)+Isnull(LJCGAmt,0.0)-Isnull(LJFPAmt,0.0)-Isnull(LJFZAmt,0.0)) as LJRemIAmt,
		Sum(Isnull(LJFPAmt,0.0)-Isnull(LJFKAmt,0.0)-Isnull(LJMFAmt,0.0)) as LJRemPAmt,
		Sum(Isnull(LJQCAmt,0.0)+Isnull(LJCGAmt,0.0)-Isnull(LJFZAmt,0.0)-Isnull(LJFKAmt,0.0)-Isnull(LJMFAmt,0.0)) As LJQHKAmt,
		Sum(Isnull(LJQCAmt,0.0)+Isnull(LJCGAmt,0.0)-Isnull(LJFZAmt,0.0)-Isnull(LJFKAmt,0.0)-Isnull(LJMFAmt,0.0)-Isnull(LJYFAmt,0.0)+Isnull(LJCXAmt,0.0)) As LJQKAmt
	From @Tmp
	Group By VendorID
	--更新资料
	Update a Set a.VendorNo=b.VendorNo,a.VendorName=b.VendorName,a.NameSpell=b.NameSpell,
		a.BuyerID=b.BuyerID,a.Buyer=b.Buyer,a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes
	From @uTable a,BDM_Vendor_V b
	Where a.VendorID=b.VendorID
	Return
End
go

