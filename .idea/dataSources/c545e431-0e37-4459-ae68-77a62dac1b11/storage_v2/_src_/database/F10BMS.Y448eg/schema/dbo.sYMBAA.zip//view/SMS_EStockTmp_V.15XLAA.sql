CREATE VIEW dbo.SMS_EStockTmp_V
AS
SELECT a.StockNo, a.Location, b.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, 
      b.ItemSpec, b.BarCode, b.ClassName, b.LabelName, b.ColorName, b.UnitName, 
      a.SQty, a.Price, a.Amt, b.BPackage, b.MPackage, b.Package, b.PkgRatio, b.PkgSpec, 
      b.SPrice, b.SPrice1, b.SPrice2, b.SPrice3, b.SafeSPrice
FROM dbo.SMS_EStockTmp a INNER JOIN
      dbo.BDM_ItemInfo_V b ON a.ItemNo = b.ItemNo
go

