--日志
CREATE VIEW dbo.SYS_LogFile_V
--with encryption
AS
SELECT dbo.SYS_LOGFILE.LogID, dbo.SYS_LOGFILE.UserID, 
      dbo.BDM_EMPLOYEE.EmployeeName AS UserName, dbo.SYS_LOGFILE.ProgNo, 
      dbo.SYS_LOGFILE.OptDesc, dbo.SYS_LOGFILE.OptDate
FROM dbo.SYS_LOGFILE INNER JOIN
      dbo.BDM_EMPLOYEE ON 
      dbo.SYS_LOGFILE.UserID = dbo.BDM_EMPLOYEE.EmployeeID

go

