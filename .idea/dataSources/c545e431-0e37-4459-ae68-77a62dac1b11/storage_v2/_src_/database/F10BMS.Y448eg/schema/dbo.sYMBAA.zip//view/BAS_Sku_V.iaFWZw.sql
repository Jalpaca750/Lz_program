create view BAS_Sku_V as
SELECT CAST(a.ItemID AS VARCHAR(32)) AS itemId,a.itemNo,a.ItemName,a.ItemSpec,
    a.zpCode,a.zpName,a.LabelID AS brandId,b.CHName AS brandCName,a.ClassID AS categoryId,
    c.CodeID AS categoryNo,c.CHName AS categoryCName,a.colorName,a.unitName,
    a.barcode,a.midBarcode,a.bigBarcode,a.pkgBarcode,a.taxrate,a.flag,
    CASE a.Flag WHEN '1' THEN '有效' ELSE '失效' END AS flagDesc,a.Remarks AS memo
FROM BDM_ItemInfo a
    INNER JOIN BDM_LabelCode_V b ON a.LabelID=b.CodeID
    INNER JOIN BDM_ItemClass_V c ON a.ClassID=c.CodeID
go

