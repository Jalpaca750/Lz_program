
--说明：客户欠款综合查询
--作者：Devil.H
--创建：2007.11.14
--参数：
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag：标志
CREATE Function dbo.fn_AnalACM50
(
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	CustID bigint,
	CustNo varchar(20),
	CustName varchar(200),
	NameSpell varchar(200),
	AreaCode varchar(20),
	AreaName varchar(100),
	MemberID varchar(20),
	Member varchar(100),
	PopedomID varchar(20),
	PopedomName varchar(100),
	CustType varchar(20),
	TypeName varchar(100),
	SalesID bigint,
	Sales varchar(100),
	KindName varchar(100),
	TradeName varchar(100),
	LJXSAmt decimal(18,6),
	LJAdAmt decimal(18,6),
	LJQCAmt decimal(18,6),
	LJFPAmt decimal(18,6),
	LJFZAmt decimal(18,6),
	LJSKAmt decimal(18,6),
	LJMFAmt decimal(18,6),
	LJYFAmt decimal(18,6),
	LJOffAmt decimal(18,6),
	LJRemIAmt decimal(18,6),
	LJRemPAmt decimal(18,6),
	LJQKAmt decimal(18,6),
	LJRemYFAmt decimal(18,6),
	LJRemTotal decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40),
	DepartId varchar(20),
	DepartName varchar(100)
)
As
Begin	
	if @Flag=0
		Return
	--临时表
	declare @Tmp Table(CustID bigint,
		LJXSAmt decimal(18,6) default 0.0,
		LJAdAmt decimal(18,6) default 0.0,
		LJFPAmt decimal(18,6) default 0.0,
		LJFZAmt decimal(18,6) default 0.0,
		LJSKAmt decimal(18,6) default 0.0,
		LJMFAmt decimal(18,6) default 0.0,
		LJYFAmt decimal(18,6) default 0.0,
		LJOffAmt decimal(18,6) default 0.0,
		LJQCAmt decimal(18,6) default 0.0)
	--累计销售额
	Insert Into @Tmp(CustID,LJXSAmt)
	Select a.CustID,Sum(Isnull(b.Amt,0.0)) as LJXSAmt
  	From SMS_Stock a inner join SMS_StockDtl b on a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where (a.DeptNo=d.CodeID) And (d.DeptNo Like @CorpNo + '%'))
	Group By a.CustID
	Union All
	Select CustID,SUM(Amt) as LJXSAmt
	From PRJ_Cost a
	Where (BillSts='20' Or BillSts='25' Or BillSts='30' Or BillSts='23') 
		And PayType='收费'
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group by CustID

	--累计销售虚开金额(A单金额)
	Insert Into @Tmp(CustID,LJAdAmt)
	Select ah.CustID,SUM(Isnull(ad.Amt,0.0)-Isnull(d.Amt,0.0)) As ADAmt
	From SMS_AStock ah Inner Join (Select StockNo,Sum(Amt) As Amt
				       From SMS_AStockDtl
				       Group By StockNo) ad On ah.StockNo=ad.StockNo
			   Left Outer Join (Select StockNo,Sum(Amt) As Amt
				            From SMS_StockDtl 
					    Group By StockNo)d On ah.StockNo_O=d.StockNo
	Where (ah.BillSts='20' Or ah.BillSts='25' Or ah.BillSts='30') 
			And (ah.DeptNo Like @DeptNo + '%')
			And Exists(Select 1 From BDM_DeptCode_V d Where ah.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By ah.CustID

	--累计发票,累计发票折扣
	Insert Into @Tmp(CustID,LJFPAmt,LJFZAmt)
	Select CustID,Sum(IAmt) as LJFPAmt,Sum(DAmt) as LJFZAmt
	From SMS_Invoice a
	Where (BillSts='20' Or BillSts='25' Or BillSts='30')
		And (DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where (a.DeptNo=d.CodeID) And (d.DeptNo Like @CorpNo + '%'))
	Group by CustID

	--累计收款、免收金额
	Insert Into @Tmp(CustID,LJSKAmt,LJMFAmt)
	Select a.CustID,Sum(b.PayAmt) as LJSKAmt,Sum(b.FAmt) as LJMFAmt
	From SMS_Payment a inner join SMS_PaymentDtl b on a.PaymentNo=b.PaymentNo
	Where (a.BillSts='20')
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where (a.DeptNo=d.CodeID) And (d.DeptNo Like @CorpNo + '%'))
	Group By a.CustID

	--累计零售
	Insert Into @Tmp(CustID,LJFPAmt,LJSKAmt,LJMFAmt)
	Select a.CustID,Sum(CASE a.BillType WHEN '40' THEN b.Amt WHEN '50' THEN - b.Amt END) as LJFPAmt,
		Sum(CASE a.BillType WHEN '40' THEN Isnull(b.Amt,0.0)-Isnull(a.DiscAmt,0.0) 
				    When '50' Then Isnull(a.DiscAmt,0.0)-Isnull(b.Amt,0.0) End) as LJSKAmt,
		Sum(CASE a.BillType WHEN '40' THEN a.DiscAmt WHEN '50' THEN - a.DiscAmt END) as LJMFAmt 
	From SMS_Retail a Inner Join (Select RetailNo,SUM(Amt) As Amt
				      From SMS_RetailDtl
				      Group By RetailNo) b On a.RetailNo=b.RetailNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where (a.DeptNo=d.CodeID) And (d.DeptNo Like @CorpNo + '%'))
	Group By a.CustID

	--累计销售现金审核
	Insert Into @Tmp(CustID,LJSKAmt,LJMFAmt)
	Select CustID,Sum(PaidAmt) as LJSKAmt,Sum(DiscAmt) as LJMFAmt
  	From SMS_Stock a
	Where (BillSts='20' Or BillSts='25' Or BillSts='30') 
		And (DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where (a.DeptNo=d.CodeID) And (d.DeptNo Like @CorpNo + '%'))
	Group By CustID

	--累计客户预付款
	Insert Into @Tmp(CustID,LJYFAmt)
	Select b.CustID,Sum(b.AdvAmt) as LJYFAmt
	From SMS_Advances a inner join SMS_AdvancesDtl b on a.AdvancesNo=b.AdvancesNo
	Where (a.BillSts='20')
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where (a.DeptNo=d.CodeID) And (d.DeptNo Like @CorpNo + '%'))
	Group By b.CustID

	--累计冲销预付款
	Insert Into @Tmp(CustID,LJOffAmt)
	Select CustID,Sum(AdvAmt) as LJOffAmt
	From SMS_Payment a
	Where (BillSts='20')
		And (DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where (a.DeptNo=d.CodeID) And (d.DeptNo Like @CorpNo + '%'))
	Group By CustID

	--累计客户期初欠款
	Insert Into @Tmp(CustID,LJQCAmt)
	Select CustID,Sum(IAmt) as LJQCAmt
	From SMS_Invoice a
	Where (InvoiceNo Like '$00%') And (BillSts='20' Or BillSts='25' Or BillSts='30') 
		And (DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where (a.DeptNo=d.CodeID) And (d.DeptNo Like @CorpNo + '%'))
	Group by CustID

	--合计
	Insert Into @uTable(CustID,LJQCAmt,LJXSAmt,LJAdAmt,LJFPAmt,LJFZAmt,LJSKAmt,LJMFAmt,
		LJYFAmt,LJOffAmt,LJRemIAmt,LJRemPAmt,LJQKAmt,LJRemYFAmt,LJRemTotal)
	Select CustID,Sum(LJQCAmt),Sum(LJXSAmt),SUM(LJAdAmt),Sum(LJFPAmt),Sum(LJFZAmt),Sum(LJSKAmt),Sum(LJMFAmt),
		Sum(LJYFAmt),Sum(LJOffAmt),
		Isnull(Sum(LJQCAmt),0.0)+Isnull(Sum(LJXSAmt),0.0)+Isnull(Sum(LJAdAmt),0.0)-Isnull(Sum(LJFPAmt),0)-Isnull(Sum(LJFZAmt),0) as LJRemIAmt,
		Isnull(Sum(LJFPAmt),0.0)-Isnull(Sum(LJSKAmt),0.0)-Isnull(Sum(LJMFAmt),0.0) as LJRemPAmt,
		Isnull(Sum(LJQCAmt),0.0)+Isnull(Sum(LJXSAmt),0.0)+Isnull(Sum(LJAdAmt),0.0)-Isnull(Sum(LJFZAmt),0.0)-Isnull(Sum(LJSKAmt),0)-Isnull(Sum(LJMFAmt),0.0) as LJQKAmt,
		SUM(ISNULL(LJYFAmt,0.0)-ISNULL(LJOffAmt,0.0)) As LJRemYFAmt,
		SUM(Isnull(LJQCAmt,0.0)+Isnull(LJXSAmt,0.0)+Isnull(LJAdAmt,0.0)-Isnull(LJFZAmt,0.0)-Isnull(LJSKAmt,0.0)-Isnull(LJMFAmt,0.0)-ISNULL(LJYFAmt,0.0)+ISNULL(LJOffAmt,0.0)) As LJRemTotal
	From @Tmp
	Group By CustID
	--更新客户资料
	Update a Set a.CustNo=b.CustNo,a.CustName=b.CustName,a.NameSpell=b.NameSpell,a.AreaCode=b.AreaCode,
		a.SalesID=b.SalesID,a.AreaName=b.AreaName,a.MemberID=b.MemberID,a.PopedomID=b.PopedomID,
		a.PopedomName=b.PopedomName,a.CustType=b.CustType,a.Sales=b.Sales,a.KindName=b.KindName,
		a.TradeName=b.TradeName,a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes,a.DepartId=b.DeptNo,
		a.DepartName=b.DeptName
	From @uTable a,BDM_Customer_V b
	Where a.CustID=b.CustID
	Return
End
go

