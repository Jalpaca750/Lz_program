--说明：调拨出库单汇总分析
--作者：Devil.H
--创建：2008.03.05
--参数：
--	@Period:会计月份
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@OutDeptNo:调出部门
--	@InDeptNo:调入部门
--	@Flag:标识
CREATE Function dbo.fn_AnalIMSA01
(
	@Period varchar(6),
	@StartDate varchar(10),
	@EndDate varchar(10),
	@OutDeptNo varchar(20),
	@InDeptNo varchar(20),
	@Flag bit=0
)

returns @uTable Table(
	DeptNo varchar(20),
	DeptName varchar(100),
	SQty decimal(18,6),
	IQty decimal(18,6),
	IAmt decimal(18,6),
	SAmt decimal(18,6),
	CPrice decimal(18,6)
)
As
Begin
	If @Flag=0 
		Return
	--临时成本文件
	Declare @CostTmp Table
	(
		DeptNo varchar(20),
		ItemID bigint,
		Price decimal(18,10)
		Primary Key(DeptNo,ItemID)
	)
	Declare @Tmp Table
	(
		DeptNo varchar(20),
		ItemID bigint,
		SQty decimal(18,6),
		IQty decimal(18,6)
		Primary Key(DeptNo,ItemID)
	)
	--临时成本
	Insert Into @CostTmp(DeptNo,ItemID,Price)
	Select Isnull(DeptNo,'$$$$'),ItemID,MEPrice
	From uf_CostPrice(@Period) 
	Insert Into @Tmp(DeptNo,ItemID,SQty,IQty)
	Select a.DeptNo,b.ItemID,SUM(b.SQty) As SQty,Sum(b.IQty) As IQty
	From IMS_Allot a Inner Join IMS_AllotDtl b On a.AllotNo=b.AllotNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.CreateDate Between @StartDate And @EndDate)
		And (a.DeptNo Like @OutDeptNo + '%')
		And (a.DeptNo_I Like @InDeptNo + '%')
	Group By a.DeptNo,b.ItemID
	--根据成本方法获取数据
	If Exists(Select 1 From SYS_Config Where Isnull(Method,'S')='S')
		Insert Into @uTable(DeptNo,DeptName,SQty,IQty,IAmt,SAmt,CPrice)
		Select a.DeptNo,do.CHName As DeptName_O,a.SQty,a.IQty,
			Isnull(a.IQty,0.0)*Isnull(b.Price,0.0) as IAmt,
			Isnull(a.SQty,0.0)*Isnull(b.Price,0.0) as SAmt,b.Price
		From @Tmp a Left Outer Join @CostTmp b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
		            Left Outer Join BDM_DeptCode_V do On a.DeptNo=do.CodeID
	else
		Insert Into @uTable(DeptNo,DeptName,SQty,IQty,IAmt,SAmt,CPrice)
		Select a.DeptNo,do.CHName As DeptName_O,a.SQty,a.IQty,
			Isnull(a.IQty,0.0)*Isnull(b.Price,0.0) as IAmt,
			Isnull(a.SQty,0.0)*Isnull(b.Price,0.0) as SAmt,b.Price
		From @Tmp a Left Outer Join @CostTmp b On b.DeptNo='$$$$' And a.ItemID=b.ItemID
		            Left Outer Join BDM_DeptCode_V do On a.DeptNo=do.CodeID
	Return
End
go

