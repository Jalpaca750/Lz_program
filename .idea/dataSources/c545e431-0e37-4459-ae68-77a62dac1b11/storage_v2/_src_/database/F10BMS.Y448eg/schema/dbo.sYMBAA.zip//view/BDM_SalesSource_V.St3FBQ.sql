--销售机会来源
CREATE VIEW dbo.BDM_SalesSource_V
AS
SELECT CodeID, CodeNo, CHName, ENName, Flag, Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL23')
go

