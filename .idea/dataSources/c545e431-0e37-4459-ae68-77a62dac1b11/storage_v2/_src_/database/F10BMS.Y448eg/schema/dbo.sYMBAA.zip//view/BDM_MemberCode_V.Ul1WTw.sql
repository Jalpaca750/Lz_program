
--会员代码
CREATE VIEW dbo.BDM_MemberCode_V
AS
SELECT CodeID, CodeNo, CHName, ENName,Flag, Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL10')
go

