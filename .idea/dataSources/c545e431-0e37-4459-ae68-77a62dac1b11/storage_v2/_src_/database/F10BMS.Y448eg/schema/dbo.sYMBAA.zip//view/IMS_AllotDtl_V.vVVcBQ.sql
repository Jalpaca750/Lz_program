
CREATE VIEW dbo.IMS_AllotDtl_V
AS
SELECT a.AllotID, a.AllotNo, b.CreateDate, b.BillSts, b.DeptNo, b.DeptName, a.DeptNo_I, 
    a.OrderNo, a.OrderID, a.WareHouse, ISNULL(d.Location, a.Location) AS Location, 
    a.ItemID, c.ItemNo, c.ItemName, c.ItemAlias, c.NameSpell, c.ItemSpec, c.BarCode, 
    c.ClassID, c.ClassName, c.LabelID, c.LabelName, c.ColorName, c.UnitName, 
    c.PkgSpec, a.PkgQty, ISNULL(e.OQty, 0.0) - ISNULL(e.DQty, 0.0) AS RemDQty, a.SQty, 
    a.Price, a.Amt, a.IQty,c.Defined1,c.Defined2,c.Defined3,c.Defined4,c.Defined5, 
    CASE b.BillSts WHEN '05' THEN 0.0 WHEN '00' THEN 0.0 ELSE ISNULL(a.SQty, 0.0) - ISNULL(a.IQty, 0.0) END AS RemIQty, 
    d.OnHandQty, f.OnHandQty AS OnHandQty_I, c.PPrice, 
    CASE ISNULL(a.SPrice,0.0) WHEN 0.0 THEN c.SPrice ELSE a.SPrice END AS SPrice, 
    c.SPrice1, c.SPrice2, c.SPrice3, c.BPackage, c.MPackage, c.Package, c.PkgRatio, a.CPrice, 
    c.ItemPHFlag, c.ItemPHName, a.YZStockQty, Y.QTY AS YZQty, a.PauseQty,a.Remarks, 
    a.wmsStockId,a.BefPrice,a.pickFlag,a.pickTime,b.BoxNum,b.WaveNo,   a.CheckBox 
FROM dbo.IMS_AllotDtl a 
    LEFT JOIN dbo.IMS_Subdepot f ON f.DeptNo = a.DeptNo_I AND f.ItemID = a.ItemID     
    LEFT JOIN dbo.IMS_Ledger d ON a.WareHouse = d.WareHouse AND a.ItemID = d.ItemID 
    LEFT JOIN dbo.BAS_Goods_V c ON a.ItemID = c.ItemID 
    LEFT JOIN dbo.PMS_OrderDtl e ON a.OrderID = e.OrderID 
    LEFT JOIN(SELECT x.AllotNo, x.CreateDate, x.DeptNo, y.CodeNo AS DeptCode,y.CHName AS DeptName, x.BillSts,x.BoxNum,x.WaveNo
              FROM dbo.IMS_Allot x 
                  LEFT JOIN dbo.BDM_DeptCode_V y ON x.DeptNo = y.CodeID) b ON a.AllotNo = b.AllotNo 
    LEFT JOIN dbo.IMS_YZStock_Sum_WareHouse_Sum_V Y ON  a.WareHouse = Y.WareHouseID AND a.ItemID = Y.ItemID

go

