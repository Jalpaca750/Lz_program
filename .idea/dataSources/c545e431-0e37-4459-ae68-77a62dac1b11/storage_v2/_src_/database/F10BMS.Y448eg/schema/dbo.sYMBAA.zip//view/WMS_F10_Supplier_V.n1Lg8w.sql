

/*==============================================================*/
/* View: WMS_F10_Supplier_V                                     */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_Supplier_V] as
SELECT a.vendorID,p.partnerId AS supplierId,p.partnerNo AS supplierNo,p.partnerName AS supplierName,
	p.companyAddress,b.employeeId AS buyerId
FROM dbo.BDM_Vendor a
	INNER JOIN YiWms.dbo.BAS_Partner p ON a.VendorNo=p.partnerNo
	LEFT JOIN dbo.WMS_F10_Employee_V b ON a.BuyerID=b.f10Id
WHERE EXISTS(SELECT * FROM SYS_Config c WHERE p.companyId=c.companyId AND p.ownerId=c.ownerId AND p.partnerType=2)
go

