CREATE VIEW dbo.PMS_Return_V
AS
SELECT a.ReturnNo, a.CreateDate, a.DeptNo, f.CHName AS DeptName, a.WareHouse, 
    g.CHName AS WHName, a.VendorID, b.VendorNo, b.VendorName, b.NameSpell, 
    b.LinkMan, b.Phone, b.Faxes, b.BuyerID, b.Buyer, e.Amt, a.BillSts,a.PrintNum,
    (SELECT StsName FROM BillStatus h WHERE a.BillSts=h.BillSts And h.BillType = 'PMS60') AS StsName,
    a.syncFlag,a.editTime,a.wmsOrder,a.wmsBillNo,a.Reason,a.Forcible, a.PFlag, a.AuditDate, 
    a.AuditID, d.EmployeeName AS Auditer, a.CreatorID, c.EmployeeName AS Creator,a.PrinterID,
    p.EmployeeName AS Printer, a.Remarks, a.CheckBox
FROM dbo.PMS_Return a 
    LEFT JOIN dbo.BDM_DeptCode_V f ON a.DeptNo=f.CodeID 
    LEFT JOIN dbo.BDM_WareHouse_V g ON a.WareHouse = g.CodeID 
    LEFT JOIN dbo.BDM_Vendor_V b ON a.VendorID = b.VendorID 
    LEFT JOIN dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID 
    LEFT JOIN dbo.BDM_Employee d ON a.AuditID = d.EmployeeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID=p.EmployeeID 
    LEFT JOIN (SELECT ReturnNo, SUM(Amt) AS Amt
               FROM PMS_ReturnDtl
               GROUP BY ReturnNo) e ON a.ReturnNo = e.ReturnNo
go

