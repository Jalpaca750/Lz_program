

CREATE Procedure sp_PMSOrderAudit
(
	@OrderNo varchar(20),
	@Flag char(2)
)
As
Begin
	declare @PlanNo varchar(20)
	declare @DeptNo_A varchar(20)
	declare @DeptNo varchar(20)
	--获取申调分部
	Select @DeptNo_A=DeptNo_A,@DeptNo=DeptNo
	From PMS_Order 
	Where OrderNo=@OrderNo
	--创建临时表
	Create Table #Tmp(ItemID bigint,OQty decimal(18,6),AQty decimal(18,6) Primary Key(ItemID))
	Insert Into #Tmp(ItemID,OQty,AQty)
	Select ItemID,sum(OQty),Sum(Isnull(OQty,0.0)-Isnull(SQty,0.0))
	From PMS_OrderDtl 
	Where OrderNo=@OrderNo
	Group By ItemID
	--审核
	if @Flag='20'
		Begin
			Update a Set a.AllocQty=Isnull(a.AllocQty,0.0)+Isnull(b.OQty,0.0)
			From IMS_Subdepot a Inner Join #Tmp b On a.DeptNo=@DeptNo_A And a.ItemID=b.ItemID
			--插入没有的分部库存调出分部
			Insert Into IMS_Subdepot(DeptNo,ItemID,OnHandQty,AllocQty)
			Select @DeptNo_A,ItemID,0,OQty
			From #Tmp a
			Where Not Exists(Select 1 From IMS_Subdepot b Where b.DeptNo=@DeptNo_A And a.ItemID=b.ItemID)
			--插入没有的分部库存调入分部
			Insert Into IMS_Subdepot(DeptNo,ItemID,OnHandQty)
			Select @DeptNo,ItemID,0
			From #Tmp a
			Where Not Exists(Select 1 From IMS_Subdepot b Where b.DeptNo=@DeptNo And a.ItemID=b.ItemID)
		End
	if @Flag='10'
		Begin
			--更新已有的分部库存
			Update a Set a.AllocQty=Isnull(a.AllocQty,0.0)-Isnull(b.OQty,0.0)
			From IMS_Subdepot a Inner Join #Tmp b On a.DeptNo=@DeptNo_A And a.ItemID=b.ItemID
		End
	if @Flag='05'
		Begin
			--更新已有的分部库存
			Update a Set a.AllocQty=Isnull(a.AllocQty,0.0)-Isnull(b.AQty,0.0)
			From IMS_Subdepot a Inner Join #Tmp b On a.DeptNo=@DeptNo_A And a.ItemID=b.ItemID
		End
	--作废
	if @Flag='00'
		begin
			--更新计划单的已采购数量
			Update a Set a.OQty=Isnull(a.OQty,0.0)-Isnull(b.OQty,0.0)
			From PMS_PlanDtl a Inner Join PMS_OrderDtl b On a.PlanID=b.PlanID
			Where b.OrderNo=@OrderNo
			--计划单
			declare mycursor cursor
			for select Distinct PlanNo from PMS_OrderDtl Where OrderNo=@OrderNo
			open mycursor
			fetch next from mycursor into @PlanNo
			while @@fetch_Status=0
			begin
				if Exists(Select 1 from PMS_PlanDtl Where Abs(Isnull(OQty,0.0))>0.0 And PlanNo=@PlanNo)
					Update PMS_Plan Set BillSts='25' Where PlanNo=@PlanNo And BillSts<>'05'
				else
					Update PMS_Plan Set BillSts='20' Where PlanNo=@PlanNo And BillSts<>'05'
				fetch next from mycursor into @PlanNo
			end
			close mycursor
			deallocate mycursor
		end 
End
go

