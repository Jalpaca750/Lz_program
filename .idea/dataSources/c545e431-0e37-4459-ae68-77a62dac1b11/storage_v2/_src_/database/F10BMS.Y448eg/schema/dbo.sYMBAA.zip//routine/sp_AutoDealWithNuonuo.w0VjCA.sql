CREATE PROCEDURE sp_AutoDealWithNuonuo
AS
BEGIN
    DECLARE @OrderNo VARCHAR(32);
    DECLARE @OrderBillNo VARCHAR(20);
    DECLARE @InvoiceNo VARCHAR(20);
    DECLARE @Invoice VARCHAR(1000);
    DECLARE @invoiceState VARCHAR(2)
    DECLARE @serialNo VARCHAR(40);
    DECLARE @totalFee DECIMAL(18,6);
    
    DECLARE @CurDate VARCHAR(10);
    DECLARE @CustID BIGINT;
    DECLARE @SalesID BIGINT;
    DECLARE @UserID BIGINT;
    DECLARE @DeptNo VARCHAR(32);
    DECLARE @DeptFlag VARCHAR(2);
    DECLARE @SendAddr VARCHAR(200);
    DECLARE @LinkMan VARCHAR(40);
    DECLARE @Phone VARCHAR(80);
    DECLARE @Remarks VARCHAR(32);
    DECLARE @IType VARCHAR(20);
    

    DECLARE @errors BIGINT;  
    DECLARE @sales TABLE(serialNo VARCHAR(40),OrderNo VARCHAR(32),orderBillNo VARCHAR(32),nuoOrderNo VARCHAR(32),invoiceState VARCHAR(2));
    SET @UserID=99;
    SET @CurDate=CONVERT(VARCHAR(10),GETDATE(),23);
    SET @Invoice='';
    SET @errors=0;
    BEGIN TRAN
    --同步数据到中间表
    INSERT INTO TCS_InvoiceEx(serialNo,orderNo,orderBillNo,nuoOrderNo,syncFlag,syncTime,invoiceState)
    SELECT b.serialNo,a.boneOrderNo,a.boneOrderBillNo,a.orderNo,0,NULL,a.invoiceState
    FROM TCS_Order a
        INNER JOIN TCS_Invoice b On a.invoiceSerialNum=b.serialNo
    WHERE NOT EXISTS(SELECT * FROM TCS_InvoiceEx ex WHERE b.serialNo=ex.serialNo)
        AND a.invoiceState IN('00','30');
    SET @errors=@errors+@@ERROR;
    --待处理数据    
    INSERT INTO @sales(serialNo,OrderNo,orderBillNo,nuoOrderNo,invoiceState)
    SELECT serialNo,OrderNo,orderBillNo,nuoOrderNo,invoiceState
    FROM TCS_InvoiceEx
    WHERE syncFlag=0;
    SET @errors=@errors+@@ERROR;
    WHILE EXISTS(SELECT * FROM @sales)
    BEGIN
        SELECT TOP 1 @serialNo=serialNo,@OrderNo=OrderNo,@OrderBillNo=OrderBillNo,@invoiceState=invoiceState FROM @sales ORDER BY orderBillNo;
        --发票状态
        IF (@invoiceState='00')
        BEGIN
            IF (EXISTS(SELECT * 
                       FROM SMS_Invoice a 
                           INNER JOIN SMS_InvoiceDtl b ON a.InvoiceNo=b.InvoiceNo
                       WHERE b.OrderNo=@OrderBillNo)
                )
            BEGIN
                --获取发票No
                SELECT TOP 1 @InvoiceNo=a.InvoiceNo 
                FROM SMS_Invoice a 
                    INNER JOIN SMS_InvoiceDtl b ON a.InvoiceNo=b.InvoiceNo
                WHERE b.OrderNo=@OrderBillNo
                --更新发票状态
                UPDATE SMS_Invoice SET BillSts='00' WHERE InvoiceNo=@InvoiceNo;
                SET @errors=@errors+@@ERROR;
                EXEC sp_SMSInvoiceAudit @InvoiceNo,'00';
                --同步数据状态
                UPDATE TCS_InvoiceEx SET syncFlag=1,syncTime=GETDATE() WHERE orderBillNo=@orderBillNo;
                SET @errors=@errors+@@ERROR;
            END
        END
        ELSE IF (@invoiceState='30')
        BEGIN
            --如果全部开票
            IF NOT EXISTS(SELECT * FROM TCS_OrderInvoice_V WHERE orderNo=@OrderNo)
            BEGIN
                IF (EXISTS(SELECT * 
                       FROM SMS_Invoice a 
                           INNER JOIN SMS_InvoiceDtl b ON a.InvoiceNo=b.InvoiceNo
                       WHERE b.OrderNo=@OrderBillNo)
                )
                BEGIN
                    --同步数据状态
                    UPDATE TCS_InvoiceEx SET syncFlag=1,syncTime=GETDATE() WHERE orderBillNo=@orderBillNo;
                END
                ELSE
                BEGIN
                    SELECT TOP 1 @DeptNo=DeptNo,@CustID=CustID,@SalesID=SalesID,@SendAddr=SendAddr,@LinkMan=LinkMan,@Phone=Phone,@Remarks=Remarks
                    FROM SMS_Stock a
                    WHERE EXISTS(SELECT * FROM SMS_StockDtl b WHERE a.StockNo=b.StockNo AND b.OrderNo=@OrderBillNo);
                    SET @errors=@errors+@@ERROR;
                    SELECT @DeptFlag=DeptFlag FROM BDM_DeptCode_V WHERE CodeID=@DeptNo;
                    SET @errors=@errors+@@ERROR;
                    --发票类型
                    SELECT @IType=CASE invoiceLine WHEN 'c' THEN '1033' WHEN 's' THEN '1032' WHEN 'p' THEN '9335' ELSE '' END
                    FROM TCS_Order 
                    WHERE invoiceSerialNum=@serialNo;
                    SET @errors=@errors+@@ERROR;
                    --获取发票号
                    SELECT @Invoice=@Invoice+a.invoiceNo+';'
                    FROM TCS_Invoice a
                        INNER JOIN TCS_InvoiceEx b ON a.serialNo=b.serialNo
                    WHERE b.orderNo=@OrderNo; 
                    SET @errors=@errors+@@ERROR;
                    --发票金额
                    SELECT @totalFee=SUM(totalFee) 
                    FROM TCS_Order
                    WHERE orderNo=@OrderNo;                    
                    --生成发票单号
                    EXEC dbo.sp_CreateCode @DeptFlag,'SMS90',@UserID, @InvoiceNo OUTPUT;
                    IF (@InvoiceNo!='')
                    BEGIN
                        INSERT INTO SMS_Invoice(InvoiceNo,DeptNo,CreateDate,CustID,IType,Invoice,PayMode,IAmt,DAmt,
                            PAmt,BillSts,PFlag,Integral,SalesID,AuditID,CreatorID,Remarks,PaymentUnAuditingFlag,ARDate,
                            PrintNum,RedFlag,SendAddr,LinkMan,Phone)
                        SELECT @InvoiceNo,@DeptNo,@CurDate,@CustID,@IType,@Invoice,'',@totalFee,0.0,
                            0.0,'20',0,0.0,@SalesID,@UserID,@UserID,@Remarks,0,CONVERT(VARCHAR(10),DATEADD(d,ISNULL(ADays,30),GETDATE()),23),
                            0,0,@SendAddr,@LinkMan,@Phone
                        FROM BDM_Customer 
                        WHERE CustID=@CustID;
                        SET @errors=@errors+@@ERROR;
                        INSERT INTO SMS_InvoiceDtl(InvoiceNo,StockID,StockNo,BillType,ItemID,PkgQty,IQty,Price,Amt,IsSpecial,
                            TaxFlag,PaidAmt,OrderID,OrderNo,Integral,SMSAStockFlag)
                        SELECT @InvoiceNo,StockID,StockNo,'10',ItemID,PkgQty,SQty,Price,Amt,IsSpecial,
                            TaxFlag,0.0,OrderID,OrderNo,Integral,0
                        FROM SMS_StockDtl a
                        WHERE OrderNo=@OrderBillNo AND EXISTS(SELECT * FROM SMS_Stock b WHERE a.StockNo=b.StockNo AND b.BillSts IN('20','25'));
                        SET @errors=@errors+@@ERROR;
                        EXEC sp_SMSInvoiceAudit @InvoiceNo,'00';
                        --同步数据状态
                        UPDATE TCS_InvoiceEx SET syncFlag=1,syncTime=GETDATE() WHERE orderBillNo=@orderBillNo;
                        SET @errors=@errors+@@ERROR;
                    END
                END
            END
        END
        DELETE FROM @sales WHERE OrderNo=@OrderNo;
    END
    IF (@errors=0)
        COMMIT;
    ELSE
        ROLLBACK;
END
go

