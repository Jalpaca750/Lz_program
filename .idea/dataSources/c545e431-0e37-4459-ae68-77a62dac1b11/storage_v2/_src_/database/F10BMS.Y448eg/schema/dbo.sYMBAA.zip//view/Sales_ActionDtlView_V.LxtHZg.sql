CREATE VIEW dbo.Sales_ActionDtlView_V
AS
SELECT a.BillID, a.BillNo,b.CreateDate, a.PlanXZ, C.CHName As PlanType, a.PlanType As PlanTypeID
,a.Object, a.TimeBegin, a.Content, 
a.TimeEnd, a.TimeCount, a.ObjectAddr, a.LinkMan, a.Phone, a.PG, a.RQ, a.Remarks
--,a.BillID_P
,a.BillID As BillID_P,a.BillID_P As BillID_P_N
,a.ExecuteSts
,a.OpportID,d.OpportName
,a.CheckBox
,a.TimeHJ
,a.BillID_N
FROM dbo.Sales_ActionDtl a 

LEFT OUTER JOIN      dbo.Sales_Action b ON a.BillNo = b.BillNo
LEFT OUTER JOIN      dbo.BDM_PlanType_V c ON a.PlanType = c.CodeID
LEFT OUTER JOIN      dbo.Sales_Opport d ON a.OpportID = d.OpportID















go

