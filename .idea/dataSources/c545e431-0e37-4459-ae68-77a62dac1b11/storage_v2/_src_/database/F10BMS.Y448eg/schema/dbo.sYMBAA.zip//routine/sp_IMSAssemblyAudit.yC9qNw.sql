CREATE Proc sp_IMSAssemblyAudit
(
	@AssemblyNo varchar(20),
	@Flag char(2)
)
As
Begin
	declare @WareHouse_I varchar(20)
	declare @WareHouse_O varchar(20)
	declare @CreateDate varchar(10)
	declare @AuditDate varchar(10)
	declare @DeptNo varchar(20)
	declare @ItemID bigint
	--获取组装产品出库库房，日期
	Select @DeptNo=DeptNo,@WareHouse_O=WareHouse_O,@WareHouse_I=WareHouse_I,
		@AuditDate=AuditDate,@CreateDate=CreateDate,@ItemID=ItemID 
	From IMS_Assembly
	Where AssemblyNo=@AssemblyNo
	--审核组装增加库存，部件减少库存
	If Isnull(@Flag,'10')='20'
		Begin
			--成品入库
			--商品
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.IQty,0)
			From BDM_ItemInfo a inner join IMS_Assembly b On a.ItemID=b.ItemID
			Where b.AssemblyNo=@AssemblyNo
			--分部
			if exists(Select 1 From IMS_Subdepot Where ItemID=@ItemID And DeptNo=@DeptNo)
				Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.IQty,0)
				From IMS_SubDepot a inner join IMS_Assembly b On a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
				Where b.AssemblyNo=@AssemblyNo
			Else
				Insert Into IMS_Subdepot(DeptNo,ItemID,OnHandQty)
				Select DeptNo,ItemID,IQty
				From IMS_Assembly
				Where AssemblyNo=@AssemblyNo
			--判断库房是否存在该商品(组装入库)
			if exists(Select 1 From IMS_Ledger Where WareHouse=@WareHouse_I And ItemID=@ItemID)
				Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.IQty,0),
					a.LastIDate=@CreateDate,a.LastIPrice=b.Price,a.DeptNo=b.DeptNo,a.LastTime=GetDate()
				From IMS_Ledger a inner join IMS_Assembly b on a.ItemID=b.ItemID And a.WareHouse=b.WareHouse_I
				Where b.AssemblyNo=@AssemblyNo
			else
				Insert Into IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastIDate,LastIPrice,LastTime)
				Select DeptNo,WareHouse_I,ItemID,IQty,CreateDate,Price,GetDate()
				From IMS_Assembly
				Where AssemblyNo=@AssemblyNo
			--部件出库
			--商品
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.OQty,0)
			From BDM_ItemInfo a Inner join IMS_AssemblyDtl b on a.ItemID=b.ItemID
			Where b.AssemblyNo=@AssemblyNo
			--分部
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.OQty,0)
			From IMS_Subdepot a,IMS_AssemblyDtl b 
			Where a.ItemID=b.ItemID And a.DeptNo=@DeptNo And b.AssemblyNo=@AssemblyNo
			Insert Into IMS_Subdepot(DeptNo,ItemID,OnHandQty)
			Select @DeptNo,ItemID,-OQty
			From IMS_AssemblyDtl
			Where AssemblyNo=@AssemblyNo And ItemID Not In(Select ItemID From IMS_Subdepot Where DeptNo=@DeptNo)
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.OQty,0),
				a.LastODate=@CreateDate,a.LastOPrice=b.Price,a.DeptNo=@DeptNo,a.LastTime=GetDate()
			From IMS_Ledger a inner join IMS_AssemblyDtl b on a.ItemID=b.ItemID And a.WareHouse=b.WareHouse_O
			Where b.AssemblyNo=@AssemblyNo
			Insert Into IMS_Ledger(WareHouse,ItemID,OnHandQty,LastODate,LastOPrice,DeptNo,LastTime)
			Select WareHouse_O,ItemID,-OQty,@CreateDate,Price,@DeptNo,GetDate()
			From IMS_AssemblyDtl
			Where AssemblyNo=@AssemblyNo And ItemID Not In(Select ItemID From IMS_Ledger Where WareHouse=@WareHouse_O)
			--写入流水账
			Insert Into IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,CreateDate,AuditDate)
			Select AssemblyNo,'组装入库单',DeptNo,WareHouse_I,ItemID,IQty,Price,Amt,CreateDate,AuditDate
			From IMS_Assembly
			Where AssemblyNo=@AssemblyNo
			Insert Into IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,CreateDate,AuditDate)
			Select AssemblyNo,'组装出库单',@DeptNo,@WareHouse_O,ItemID,-OQty,Price,-Amt,@CreateDate,@AuditDate
			From IMS_AssemblyDtl
			Where AssemblyNo=@AssemblyNo
		End
	--取消审核，组装库存减少，部件库存增加
	If Isnull(@Flag,'10')='10'
		Begin
			--成品入库
			--商品
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.IQty,0)
			From BDM_ItemInfo a inner join IMS_Assembly b On a.ItemID=b.ItemID
			Where b.AssemblyNo=@AssemblyNo
			--分部
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.IQty,0)
			From IMS_SubDepot a inner join IMS_Assembly b On a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
			Where b.AssemblyNo=@AssemblyNo
			--库房
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.IQty,0),a.LastTime=GetDate()
			From IMS_Ledger a inner join IMS_Assembly b on a.ItemID=b.ItemID And a.WareHouse=b.WareHouse_I
			Where b.AssemblyNo=@AssemblyNo
			--部件出库
			--商品
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.OQty,0)
			From BDM_ItemInfo a Inner join IMS_AssemblyDtl b on a.ItemID=b.ItemID
			Where b.AssemblyNo=@AssemblyNo
			--分部
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.OQty,0)
			From IMS_Subdepot a,IMS_AssemblyDtl b 
			Where a.ItemID=b.ItemID And a.DeptNo=@DeptNo And b.AssemblyNo=@AssemblyNo
			--库房
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.OQty,0),a.LastTime=GetDate()
			From IMS_Ledger a inner join IMS_AssemblyDtl b on a.ItemID=b.ItemID And a.WareHouse=b.WareHouse_O
			Where b.AssemblyNo=@AssemblyNo
			--删除流水账
			Delete From IMS_Flow Where BillNo=@AssemblyNo
		End
End
go

