

CREATE Proc sp_AnalSMS6A
(
	@Years int=0,
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0,
	@UserID bigint
)
As
Begin
	Delete From AnalSMS6A where UserID=@UserID

	--按客户汇总
	if isnull(@CorpNo,'')='' And isnull(@DeptNo,'')=''
		begin
			Insert Into AnalSMS6A(ItemID,QMonth,Amt,Sqty,UserID) 
			Select ItemID,Month(a.CreateDate) As QMonth,Sum(Amt) As Amt,Sum(Sqty) As Sqty,@UserID  From SMS_Stock a,SMS_Stockdtl b 
			Where  a.StockNo=b.StockNo And a.BillSts Not In('00','10') And Year(a.CreateDate)=@Years 
			Group By b.ItemID,Month(a.CreateDate) 
		end

	--按部门客户汇总
	if isnull(@CorpNo,'')='' And (Not isnull(@DeptNo,'')='')
		begin
			Insert Into AnalSMS6A(ItemID,QMonth,Amt,Sqty,UserID) 
			Select ItemID,Month(a.CreateDate) As QMonth,Sum(Amt) As Amt,Sum(Sqty) As Sqty,@UserID  From SMS_Stock a,SMS_Stockdtl b 
			Where  a.StockNo=b.StockNo And a.BillSts Not In('00','10') And Year(a.CreateDate)=@Years And a.DeptNo=@DeptNo 
			Group By b.ItemID,Month(a.CreateDate)  
		end

	--按公司客户汇总
	if (Not isnull(@CorpNo,'')='') And isnull(@DeptNo,'')=''
		begin
			Insert Into AnalSMS6A(ItemID,QMonth,Amt,Sqty,UserID) 
			Select ItemID,Month(a.CreateDate) As QMonth,Sum(Amt) As Amt,Sum(Sqty) As Sqty,@UserID  From SMS_Stock a,SMS_Stockdtl b 
			Where  a.StockNo=b.StockNo And a.BillSts Not In('00','10') And Year(a.CreateDate)=@Years 
			And a.DeptNo In(Select CodeID From BDM_DeptCode_V Where DeptNo=@CorpNo)
			Group By b.ItemID,Month(a.CreateDate) 
		end

	--按公司部门客户汇总
	if (Not isnull(@CorpNo,'')='') And (Not isnull(@DeptNo,'')='')
		begin
			Insert Into AnalSMS6A(ItemID,QMonth,Amt,Sqty,UserID) 
			Select ItemID,Month(a.CreateDate) As QMonth,Sum(Amt) As Amt,Sum(Sqty) As Sqty,@UserID  From SMS_Stock a,SMS_Stockdtl b 
			Where  a.StockNo=b.StockNo And a.BillSts Not In('00','10') And Year(a.CreateDate)=@Years And a.DeptNo=@DeptNo
			And a.DeptNo In(Select CodeID From BDM_DeptCode_V Where DeptNo=@CorpNo)
			Group By b.ItemID,Month(a.CreateDate)  
		end
End
go

