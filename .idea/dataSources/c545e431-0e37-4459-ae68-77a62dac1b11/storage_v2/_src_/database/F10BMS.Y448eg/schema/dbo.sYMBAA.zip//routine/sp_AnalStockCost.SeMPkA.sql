--说明：客户销售出库单毛利统计
--作者：Devil.H
--创建：2007.11.16
--参数：
--	@Months:月份
--	@Flag:0-自然月,1-会计月
--参与运算：
--当前月的销售出库数据
CREATE PROC [dbo].[sp_AnalStockCost]
(
	@Year INT,                  --年
	@Month INT                  --月
)
AS
BEGIN
	DECLARE @Period CHAR(6),             --会计期
	        @Method CHAR(1),             --成本核算方式:S-按分部核算成本;T-按总体核算成本
	        @STaxFlag BIT,               --销售不开票，成本不含税；CTaxFlag采购不开票加税率计成本
	        @Dec INT;                    --单价小数位数
	--获取成本计算方式
	SELECT @Method=ISNULL(Method,'S'),@Dec=ISNULL(PriceDec,2),@STaxFlag=ISNULL(STaxFlag,0) FROM Sys_Config;
	--获取当前会计期
	IF @Month<10
		SET @Period=CAST(@Year AS CHAR(4))+'0'+CAST(@Month AS CHAR(1));
	ELSE
		SET @Period=CAST(@Year AS CHAR(4))+CAST(@Month AS CHAR(2));
    --临时表存储成本数据
	CREATE TABLE #Tmp(DeptNo VARCHAR(20),ItemID BIGINT,MEPrice DECIMAL(18,6) Primary Key(DeptNo,ItemID));
	--临时表存储销售明细数据
	CREATE TABLE #Tmp1(StockID BIGINT,DeptNo VARCHAR(20),ItemID BIGINT,CPrice DECIMAL(18,6),IsSpecial BIT,orderId BIGINT);
	CREATE INDEX ix_Tmp ON #Tmp1(DeptNo,ItemId);
	--********增加会计月份时间处理***********************
	DECLARE @CW_Month_BDate CHAR(10)
	DECLARE @CW_Month_EDate CHAR(10)
	SET @CW_Month_BDate=(SELECT CW_Month FROM dbo.uf_Get_CW_Month(1,@Year,@Month))
	SET @CW_Month_EDate=(SELECT CW_Month FROM dbo.uf_Get_CW_Month(2,@Year,@Month))
	--**********************************************
	--获取成本价
	Insert Into #Tmp(DeptNo,ItemID,MEPrice)
	SELECT ISNULL(DeptNo,'$$$$'),ItemID,MEPrice 
	FROM uf_CostPrice(@Period);
	--获取当月入库单
	Insert Into #Tmp1(StockID,DeptNo,ItemID,IsSpecial,orderId)
	SELECT b.StockID,a.DeptNo,b.ItemID,ISNULL(b.IsSpecial,0),b.orderId
	FROM SMS_Stock a Inner Join SMS_StockDtl b On a.StockNo=b.StockNo
	Where a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate;
	--更新成本单价
	if @Method='S'
		Update a SET a.CPrice=b.MEPrice
		FROM #Tmp1 a 
		    Inner Join #Tmp b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
	ELSE
		Update a SET a.CPrice=b.MEPrice
		FROM #Tmp1 a 
		    Inner Join #Tmp b On a.ItemID=b.ItemID
    --处理能对得上得定制品
    Update a SET a.CPrice =b.Price 
    FROM #Tmp1 a
        Inner Join PMS_StockDtl b On a.orderId=b.XS_OrderID
	Where ISNULL(a.IsSpecial,0)=1
	--更新销售出库单成本
	if ISNULL(@STaxFlag,0)=1
		Update a SET a.CPrice=Case ISNULL(a.TaxFlag,0) When 0 then ISNULL(b.CPrice,0)
				                                       ELSE round(ISNULL(b.CPrice,0)/1.13,ISNULL(@Dec,2)+2) End
		FROM SMS_StockDtl a 
		    inner join #Tmp1 b on a.StockID=b.StockID
	ELSE
		Update a SET a.CPrice=ISNULL(b.CPrice,0)
		FROM SMS_StockDtl a 
		    inner join #Tmp1 b on a.StockID=b.StockID
	Drop Table #Tmp;
	Drop Table #Tmp1;
End

go

