create view SMS_StockBatch_V as
SELECT a.BillNo,a.WareHouseID,a.ItemID,a.PHNo,a.SNNo,b.BeginDate,b.EndDate,a.Qty
FROM JobNumberNo_Out a
    INNER JOIN JobNumberNo_In b ON a.JobNumberNo_In_SID=b.SID
go

