CREATE FUNCTION fn_AnalIMS10
(
	@ClassID varchar(20),
	@LabelID varchar(20)
)
RETURNS TABLE
AS
RETURN (
	SELECT a.ItemID, a.ItemNo, a.ItemName, a.ItemAlias, a.NameSpell, a.BarCode, a.ItemSpec, 
		a.ClassID, b.CHName AS ClassName, a.LabelID, c.CHName AS LabelName, 
		a.ColorName, a.UnitName, a.OnHandQty, 
		ISNULL(a.OnHandQty, 0.0) - ISNULL(d.AllocQty, 0.0) AS AvailQty,
                d.AllocQty_XS,d.AllocQty_DB, w.AdvanQty_DB,w.AdvanQty_CG,w.OnWayQty,
		CASE Isnull(a.PkgRatio, 0.0) WHEN 0.0 THEN NULL 
				     ELSE Round(ISNULL(w.OnWayQty,0.0)/Isnull(a.PkgRatio, 0.0), 4) END AS OnWayPkg, 
                ISNULL(a.OnHandQty, 0.0) - ISNULL(d.AllocQty, 0.0) + ISNULL(w.OnWayQty,0.0) AS AdvanQty,
                CASE Isnull(a.PkgRatio, 0.0) WHEN 0.0 THEN NULL 
				     ELSE Round((ISNULL(a.OnHandQty, 0.0) - ISNULL(d.AllocQty, 0.0) + ISNULL(w.OnWayQty,0.0))/Isnull(a.PkgRatio, 0.0), 4) END AS AdvanPkg, 
		(SELECT SUM(QTY) FROM dbo.IMS_YZStock Y Where a.ItemID = Y.ItemID) AS YZStockQty, a.PkgSpec, 
      		CASE Isnull(a.PkgRatio, 0.0) WHEN 0.0 THEN NULL 
				     ELSE Round(Isnull(a.OnHandQty, 0.0)/ Isnull(a.PkgRatio, 0.0), 4) END AS PkgQty, 
		a.BPackage, a.MPackage, a.Package, a.HotFlag, Case a.Flag When '1' Then '有效' Else '失效' End as Flag, 
		t.MaxStock,CASE Isnull(a.PkgRatio, 0.0) WHEN 0.0 THEN NULL 
				     ELSE Round(Isnull(t.MaxStock, 0.0)/ Isnull(a.PkgRatio, 0.0), 4) END AS MaxPkg, 
		t.MinStock,CASE Isnull(a.PkgRatio, 0.0) WHEN 0.0 THEN NULL 
				     ELSE Round(Isnull(t.MinStock, 0.0)/ Isnull(a.PkgRatio, 0.0), 4) END AS MinPkg, 
		s.Sales01, s.Sales02, s.Sales03, s.Sales04, a.Remarks
	FROM dbo.BDM_ItemInfo a LEFT OUTER JOIN
      		dbo.BDM_LabelCode_V c ON a.LabelID = c.CodeID LEFT OUTER JOIN
      		dbo.BDM_ItemClass_V b ON a.ClassID = b.CodeID LEFT OUTER JOIN
		(SELECT ItemID,Sum(AllocQty) As AllocQty,SUM(AllocQty_XS) AS AllocQty_XS,SUM(AllocQty_DB) AS AllocQty_DB 
		 FROM dbo.IMS_Allocate_V
		 Group By ItemID) d On a.ItemID=d.ItemID LEFT OUTER JOIN
		(SELECT ItemID,SUM(AdvanQty_DB) AS AdvanQty_DB,SUM(AdvanQty_CG) AS AdvanQty_CG,SUM(OnWayQty) AS OnWayQty
		 FROM IMS_OnWay_V
                 GROUP BY ItemID) w ON a.ItemID=w.ItemId LEFT OUTER JOIN
		(SELECT ItemID,SUM(MaxStock) AS MaxStock,SUM(MinStock) AS MinStock
		 FROM IMS_Subdepot
		 GROUP BY ItemID) t ON a.ItemID=t.ItemID LEFT OUTER JOIN
		(SELECT ItemId,SUM(CASE WHEN days<=7 THEN SQty ELSE 0 END) AS Sales01,
		          SUM(CASE WHEN days<=14 THEN SQty ELSE 0 END) AS Sales02,
		          SUM(CASE WHEN days<=30 THEN SQty ELSE 0 END) AS Sales03,
		          SUM(CASE WHEN days<=60 THEN SQty ELSE 0 END) AS Sales04
	         FROM SMS_LastSales_V
		 GROUP BY ItemId) s ON a.itemId=s.itemId 
	Where (a.ClassID Like @ClassID + '%') And (a.LabelID Like @LabelID + '%')
)
go

