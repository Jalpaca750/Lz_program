--说明：商品周转效率分析
--作者：Devil.H
--创建：2007.11.12
--参数：
--	@StartDate：起始日期
--	@EndDate：截止日期
--	@Flag：计算标示（为前台设计——1，计算）
CREATE Function dbo.fn_AnalIMS70
(	
	@Year int,
	@Month int,
	@Flag bit
)
returns @uTable Table(
	DeptNo varchar(20),
	DeptName varchar(100),
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemAlias varchar(200),
	NameSpell varchar(200),
	ItemSpec varchar(100),
	BarCode varchar(100),
	ClassID varchar(20),
	ClassName varchar(100),
	LabelID varchar(20),
	LabelName varchar(100),
	ColorName varchar(40),
	UnitName varchar(40),
	SQty decimal(18,6),
	Qty decimal(18,6),
	EQty decimal(18,6),
	ZZRate decimal(18,6),
	ZZDays decimal(18,6)
) 
As
Begin
	declare @Period char(6)
	declare @Days int
	if @Flag=0
		Return
	--获取当前会计期
	if @Month<10 
		Set @Period=Cast(@Year as char(4))+'0'+Cast(@Month as char(1))
	else
		Set @Period=Cast(@Year as char(4))+Cast(@Month as char(2))
	--获取当前日期天数
	Select @Days=1+Datediff(d,Cast(StartDate as datetime),Cast(EndDate as datetime)) 
	From SYS_CW_MonthPeriod 
	Where CW_Period=@Period
	--插入截止日期时库存
	Insert Into @uTable(DeptNo,DeptName,ItemID,SQty,Qty,EQty)
	Select a.DeptNo,d.CHName,a.ItemID,a.MSQty,a.MIQty,a.MEQty 
	From CST_Price a Left Outer Join BDM_DeptCode_V d On a.DeptNo=d.CodeID
	Where Period=@Period
	--更新周转率、周转天数
	Update @uTable Set ZZRate=Case Isnull(SQty,0.0)+Isnull(Qty,0.0) When 0.0 Then 0.0
									Else Round((Isnull(SQty,0.0)+Isnull(Qty,0.0)-Isnull(EQty,0.0))/(Isnull(SQty,0.0)+Isnull(Qty,0.0)),4) End,
			   ZZDays=Case Isnull(SQty,0.0)+Isnull(Qty,0.0)-Isnull(EQty,0.0) When 0.0 Then 0.0
									Else Abs(Round(@Days*Isnull(EQty,0.0)/(Isnull(SQty,0.0)+Isnull(Qty,0.0)-Isnull(EQty,0.0)),2)) End
	--更新商品资料
	Update a Set a.ItemNo=b.ItemNo,a.ItemName=b.ItemName,a.ItemAlias=b.ItemAlias,a.NameSpell=b.NameSpell,
		a.ItemSpec=b.ItemSpec,a.BarCode=b.BarCode,a.ClassID=b.ClassID,a.LabelID=b.LabelID,
		a.ColorName=b.ColorName,a.UnitName=b.UnitName,a.ClassName=b.ClassName,a.LabelName=b.LabelName
	From @uTable a Inner Join BAS_Goods_V b On a.ItemID=b.ItemID
	Return
End
go

