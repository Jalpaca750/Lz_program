CREATE VIEW dbo.SMS_Change_V
AS
SELECT a.ChangeNo, a.CreateDate, a.DeptNo, d.CHName AS DeptName, a.BillSts, 
      e.StsName, b.ChangeAmt, a.CreatorID, c.EmployeeName AS Creator, a.Remarks, 
      a.CheckBox
FROM dbo.SMS_Change a LEFT OUTER JOIN
      dbo.BillStatus e ON a.BillSts = e.BillSts LEFT OUTER JOIN
      dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V d ON a.DeptNo = d.CodeID LEFT OUTER JOIN
          (SELECT ChangeNo, SUM(ChangeAmt) AS ChangeAmt
         FROM dbo.SMS_ChangeDtl
         GROUP BY ChangeNo) b ON b.ChangeNo = a.ChangeNo
WHERE (e.BillType = 'ACM70')

go

