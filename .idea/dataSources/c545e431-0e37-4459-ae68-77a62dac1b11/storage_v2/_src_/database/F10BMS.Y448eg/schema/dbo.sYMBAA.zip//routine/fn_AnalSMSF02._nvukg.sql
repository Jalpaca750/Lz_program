--说明：销售发票毛利分析
--作者：Devil.H
--创建：2010.09.10
--参数：
--	@Period 会计年月
--	@CorpNo 公司代码
--	@DeptNo 分部代码
--	@PlanFlag:计划成本
--	@ByPDate:统计标识，1－按收款日期;0－按制单日期
--	@Flag:标识
CREATE Function fn_AnalSMSF02
(
	@uf_type varchar(2),
	@CreatorID bigint,
	@Period varchar(6),
	@PlanFlag bit=0,
	@ByPDate bit=0,
	@Flag bit=0
)
Returns @uTable Table(
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemSpec varchar(100),
	ClassName varchar(100),
	LabelName varchar(100),
	ColorName varchar(40),
	UnitName varchar(40),
    IQty decimal(18,6),
	IAmt decimal(18,6),
	CAmt decimal(18,6),
	GProAmt decimal(18,6),
	GProfit decimal(18,6)
)
As
Begin
	if @Flag=0
		Return
	declare @Year int
	declare @Month int
	declare @Method char(1)
	Set @Year=Cast(Left(@Period,4) as Int)
	Set @Month=Cast(Right(@Period,2) as Int)
	SELECT @Method=ISNULL(Method,'S') FROM SYS_Config
	--********增加会计月份时间处理***********************
	declare @StartDate char(10)
	declare @EndDate char(10)
	Select @StartDate=StartDate,@EndDate=EndDate From SYS_CW_MonthPeriod Where CW_Period=@Period
	--**********************************************
	Declare @CostTmp Table
	(
		DeptNo varchar(20),
		ItemID bigint,
		Price decimal(18,10)
		Primary Key(DeptNo,ItemID)
	)
	Declare @TmpSales Table
	(	
		RowID bigint Identity(1,1), 
		InvoiceNo varchar(20),
		DeptNo varchar(20),
	   	ItemID Bigint,
	   	IQty decimal(18,6),
		Price decimal(18,6),
		IAmt decimal(18,6),
		OrderID bigint,
		IsSpecial bit,
	   	Primary Key(RowID)
	)
	--定制成本
	Declare @Special Table
	(
		OrderID bigint,
		ItemID bigint,
		Price decimal(18,10)
	)
	--获取发票明细
	INSERT INTO @TmpSales(InvoiceNo,DeptNo,ItemID,IQty,Price,OrderID,IsSpecial,IAmt)
	SELECT a.InvoiceNo,a.DeptNo,b.ItemID,b.IQty,b.Price,b.OrderID,Isnull(b.IsSpecial,0),b.Amt
	FROM SMS_Invoice a INNER JOIN SMS_InvoiceDtl b On a.InvoiceNo=b.InvoiceNo
	WHERE a.InvoiceNo=Any(SELECT WhereNo FROM BDM_UF_Where WHERE uf_type=@uf_type AND CreatorID=@CreatorID)

	IF Not Exists(SELECT 1 FROM  @TmpSales)
		Return

	--指定成本
	IF @PlanFlag=1
		INSERT INTO @CostTmp(DeptNo,ItemID,Price)
		SELECT DeptNo,ItemID,Price
		FROM CST_PlanPrice
		WHERE CstYear=@Year And CstMonth=@Month	
	ELSE	--月加权平均成本
		INSERT INTO @CostTmp(DeptNo,ItemID,Price)
		SELECT Isnull(DeptNo,'$$$$'),ItemID,MEPrice
		FROM uf_CostPrice(@Period)

	--定制品成本
	Insert Into @Special(OrderID,ItemID,Price)
	Select y.XS_OrderID,y.ItemID,y.Price 
     	From PMS_Stock x Inner Join PMS_StockDtl y On x.StockNo=y.StockNo
     	Where (x.BillSts='20' Or x.BillSts='30' Or x.BillSts='25') And y.IsSpecial=1 And Exists(Select 1 From @TmpSales t Where y.XS_OrderID=t.OrderID)
	--更新定制成本
	Update a Set a.Price=b.Price
	From @TmpSales a Inner Join @Special b On a.OrderID=b.OrderID And a.ItemID=b.ItemID
	Where a.IsSpecial=1
	
	--指定成本
	IF (@PlanFlag=1) Or (@Method='S')
		INSERT INTO @uTable(ItemID,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,UnitName,IQty,IAmt,CAmt)
		SELECT a.ItemID,g.ItemNo,g.ItemName,g.ItemSpec,g.ClassName,g.LabelName,g.ColorName,
			g.UnitName,a.IQty,a.IAmt,
			Case a.IsSpecial When 0 Then ROUND(ISNULL(a.IQty,0.0)*ISNULL(b.Price,0.0),2) 
					        Else ROUND(ISNULL(a.IQty,0.0)*ISNULL(a.Price,0.0),2) End AS CAmt
		FROM @TmpSales a LEFT OUTER JOIN @CostTmp b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
				 LEFT OUTER JOIN BAS_Goods_V g ON a.ItemID=g.ItemID
	if @PlanFlag=0 And @Method='T'
		INSERT INTO @uTable(ItemID,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,UnitName,IQty,IAmt,CAmt)
		SELECT a.ItemID,g.ItemNo,g.ItemName,g.ItemSpec,g.ClassName,g.LabelName,g.ColorName,
			g.UnitName,a.IQty,a.IAmt,Case a.IsSpecial When 0 Then ROUND(ISNULL(a.IQty,0.0)*ISNULL(b.Price,0.0),2) 
					            Else ROUND(ISNULL(a.IQty,0.0)*ISNULL(a.Price,0.0),2) End AS CAmt
		FROM @TmpSales a LEFT OUTER JOIN @CostTmp b On b.DeptNo='$$$$' And a.ItemID=b.ItemID
				 LEFT OUTER JOIN BAS_Goods_V g ON a.ItemID=g.ItemID
	Update @uTable Set GProAmt=Isnull(IAmt,0.0)-Isnull(CAmt,0.0),
			   GProfit=Case Isnull(IAmt,0.0) When 0.0 Then 0.0 Else Round((Isnull(IAmt,0.0)-Isnull(CAmt,0.0))/IAmt,6) End
	Return
End
go

