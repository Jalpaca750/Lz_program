Create Function fn_GetMigrateSQL
(
	@fromDb varchar(100),
	@tableName varchar(40)
)
Returns @uTable Table(execSQL varchar(8000),colLen bigint)
As
Begin
	declare @colList varchar(2000)
	declare @execSQL varchar(8000)
	Set @colList=''
	select @colList=@colList + ',' + c.name
	From syscolumns c inner join sysobjects o on c.id=o.id
	Where o.name=@tableName And c.xtype Not in(189)
	Order by c.colId
	Set @colList = substring(@colList,2,len(@colList)-1)

	Set @execSQL = 'Insert Into ' + @tableName + '(' + @colList + ') Select ' + @colList + ' From ' + @fromDb + '.dbo.' + @tableName
	Insert Into @uTable(execSQL,colLen) Values(@execSQL,len(@execSQL))
	return
End
go

