
/*==============================================================*/
/* View: IMS_CheckPoint_V                                       */
/*==============================================================*/
create view IMS_CheckPoint_V as
SELECT cp.pointId,cp.pointNo,cp.companyId,''AS companyNo,'' AS companyName,cp.warehouseId,w.CodeNo AS warehouseNo,
    w.CHName AS warehouseName,cp.startArea,'' AS startRegionNo,'' AS startRegionDesc, cp.endArea,'' AS endRegionNo,
    '' AS endRegionDesc,cp.startOwner,'' AS startOwnerNo,'' AS startOwnerName,cp.endOwner,'' AS endOwnerNo, 
    '' AS endOwnerName,cp.startNo,cp.endNo,cp.categoryId,cat.CodeNo AS categoryNo,cat.CHName AS categoryCName,cp.brandId,
    b.CodeNo AS BrandNo,b.CHName AS BrandCName,cp.startItem,b1.itemNo AS startItemNo, b1.itemName AS startItemName,
    cp.endItem,b2.itemNo AS endItemNo,b2.itemName AS endItemName, cp.pointDate,CONVERT(VARCHAR(20),cp.startTime,120) AS startTime,
    CONVERT(VARCHAR(20),cp.endTime,120) AS endTime,cp.printNum,cp.inventory,CASE cp.inventory WHEN 1 THEN '库存归零' ELSE '保持原值' END inventoryDesc, 
    cp.checkState,CASE cp.checkState WHEN 0 THEN '已作废' WHEN 10 THEN '待盘点' WHEN 20 THEN '盘点中' WHEN 30 THEN '已完成' END stateName,
    cp.checkData,CASE cp.checkData WHEN 1 THEN '账面库存' WHEN 2 THEN '动态库存' END AS checkDataDesc,cp.parentId,
    CASE cp.parentId WHEN '-1' THEN '原始设置' ELSE '复盘设置' END AS reCheckDesc,cp.isLocked,cp.lockerId,u1.EmployeeName AS lockerName,
    CONVERT(VARCHAR(20),cp.lockedTime,120) AS lockedTime,cp.createTime,cp.creatorId,u2.EmployeeName AS creatorName,cp.editTime,cp.editorId,
    u3.EmployeeName AS editorName,w.DeptNo,cp.isSelected
FROM dbo.IMS_CheckPoint AS cp 
    INNER JOIN dbo.BDM_Warehouse_V AS w ON cp.warehouseId = w.CodeID
    LEFT JOIN dbo.BDM_ItemClass_V AS cat ON cp.categoryId = cat.CodeID
    LEFT JOIN dbo.BDM_LabelCode_V AS b ON cp.brandId=b.CodeID 
    LEFT JOIN dbo.BDM_ItemInfo AS b1 ON cp.startItem = b1.itemId 
    LEFT JOIN dbo.BDM_ItemInfo AS b2 ON cp.endItem = b2.itemId 
    LEFT JOIN dbo.BDM_Employee AS u1 ON cp.lockerId = CAST(u1.EmployeeId AS VARCHAR(32)) 
    LEFT JOIN dbo.BDM_Employee AS u2 ON cp.creatorId = CAST(u2.EmployeeId AS VARCHAR(32))
    LEFT JOIN dbo.BDM_Employee AS u3 ON cp.editorId = CAST(u3.EmployeeId AS VARCHAR(32))
go

