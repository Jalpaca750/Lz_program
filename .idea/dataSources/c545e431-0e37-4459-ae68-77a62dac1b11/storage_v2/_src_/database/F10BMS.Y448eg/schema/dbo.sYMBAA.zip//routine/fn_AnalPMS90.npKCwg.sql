--说明：采购付款发票总帐
--作者：Devil.H
--创建：2007.11.26
--参数：
--	@Year:年度
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:标识
CREATE Function dbo.fn_AnalPMS90
(
	@Year int=0,
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	VendorID bigint,
	VendorNo varchar(20),
	VendorName varchar(200),
	NameSpell varchar(200),
	BuyerID bigint,
	Buyer varchar(100),
	Month01Amt decimal(18,6),
	Month02Amt decimal(18,6),
	Month03Amt decimal(18,6),
	Month04Amt decimal(18,6),
	Month05Amt decimal(18,6),
	Month06Amt decimal(18,6),
	Month07Amt decimal(18,6),
	Month08Amt decimal(18,6),
	Month09Amt decimal(18,6),
	Month10Amt decimal(18,6),
	Month11Amt decimal(18,6),
	Month12Amt decimal(18,6),
	TotalAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40)
)
As
Begin
	if @Flag=0
		Return
	--没有过滤条件
	if isnull(@CorpNo,'')='' And isnull(@DeptNo,'')=''
		Insert Into @uTable(VendorID,Month01Amt,Month02Amt,Month03Amt,Month04Amt,
					     Month05Amt,Month06Amt,Month07Amt,Month08Amt,
					     Month09Amt,Month10Amt,Month11Amt,Month12Amt,TotalAmt)
		Select VendorID,
			Month01Amt = sum(case month(CreateDate) when  1 then Isnull(PAmt,0.0) else 0.0 end), 
			Month02Amt = sum(case month(CreateDate) when  2 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month03Amt = sum(case month(CreateDate) when  3 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month04Amt = sum(case month(CreateDate) when  4 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month05Amt = sum(case month(CreateDate) when  5 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month06Amt = sum(case month(CreateDate) when  6 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month07Amt = sum(case month(CreateDate) when  7 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month08Amt = sum(case month(CreateDate) when  8 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month09Amt = sum(case month(CreateDate) when  9 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month10Amt = sum(case month(CreateDate) when 10 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month11Amt = sum(case month(CreateDate) when 11 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month12Amt = sum(case month(CreateDate) when 12 then Isnull(PAmt,0.0) else 0.0 end),
		    	TotalAmt   = sum(Isnull(PAmt,0.0))
		From PMS_Invoice
		Where Year(CreateDate)=@Year And (BillSts='20' Or BillSts='25' Or BillSts='30')
		Group by VendorID
	--按部门过滤
	if isnull(@CorpNo,'')='' And (Not isnull(@DeptNo,'')='')
		Insert Into @uTable(VendorID,Month01Amt,Month02Amt,Month03Amt,Month04Amt,
					     Month05Amt,Month06Amt,Month07Amt,Month08Amt,
					     Month09Amt,Month10Amt,Month11Amt,Month12Amt,TotalAmt)
		Select VendorID,
			Month01Amt = sum(case month(CreateDate) when  1 then Isnull(PAmt,0.0) else 0.0 end), 
			Month02Amt = sum(case month(CreateDate) when  2 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month03Amt = sum(case month(CreateDate) when  3 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month04Amt = sum(case month(CreateDate) when  4 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month05Amt = sum(case month(CreateDate) when  5 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month06Amt = sum(case month(CreateDate) when  6 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month07Amt = sum(case month(CreateDate) when  7 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month08Amt = sum(case month(CreateDate) when  8 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month09Amt = sum(case month(CreateDate) when  9 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month10Amt = sum(case month(CreateDate) when 10 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month11Amt = sum(case month(CreateDate) when 11 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month12Amt = sum(case month(CreateDate) when 12 then Isnull(PAmt,0.0) else 0.0 end),
		    	TotalAmt   = sum(Isnull(PAmt,0.0))
		From PMS_Invoice
		Where Year(CreateDate)=@Year And (BillSts='20' Or BillSts='25' Or BillSts='30')
			And DeptNo=@DeptNo
		Group by VendorID
	--按公司过滤
	if (Not isnull(@CorpNo,'')='') And isnull(@DeptNo,'')=''
		Insert Into @uTable(VendorID,Month01Amt,Month02Amt,Month03Amt,Month04Amt,
					     Month05Amt,Month06Amt,Month07Amt,Month08Amt,
					     Month09Amt,Month10Amt,Month11Amt,Month12Amt,TotalAmt)
		Select VendorID,
			Month01Amt = sum(case month(CreateDate) when  1 then Isnull(PAmt,0.0) else 0.0 end), 
			Month02Amt = sum(case month(CreateDate) when  2 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month03Amt = sum(case month(CreateDate) when  3 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month04Amt = sum(case month(CreateDate) when  4 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month05Amt = sum(case month(CreateDate) when  5 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month06Amt = sum(case month(CreateDate) when  6 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month07Amt = sum(case month(CreateDate) when  7 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month08Amt = sum(case month(CreateDate) when  8 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month09Amt = sum(case month(CreateDate) when  9 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month10Amt = sum(case month(CreateDate) when 10 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month11Amt = sum(case month(CreateDate) when 11 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month12Amt = sum(case month(CreateDate) when 12 then Isnull(PAmt,0.0) else 0.0 end),
		    	TotalAmt   = sum(Isnull(PAmt,0.0))
		From PMS_Invoice a
		Where Year(CreateDate)=@Year And (BillSts='20' Or BillSts='25' Or BillSts='30')
			And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And d.DeptNo=@CorpNo)
		Group by VendorID
	--按公司部门过滤
	if (Not isnull(@CorpNo,'')='') And (Not isnull(@DeptNo,'')='')
		Insert Into @uTable(VendorID,Month01Amt,Month02Amt,Month03Amt,Month04Amt,
					     Month05Amt,Month06Amt,Month07Amt,Month08Amt,
					     Month09Amt,Month10Amt,Month11Amt,Month12Amt,TotalAmt)
		Select VendorID,
			Month01Amt = sum(case month(CreateDate) when  1 then Isnull(PAmt,0.0) else 0.0 end), 
			Month02Amt = sum(case month(CreateDate) when  2 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month03Amt = sum(case month(CreateDate) when  3 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month04Amt = sum(case month(CreateDate) when  4 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month05Amt = sum(case month(CreateDate) when  5 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month06Amt = sum(case month(CreateDate) when  6 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month07Amt = sum(case month(CreateDate) when  7 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month08Amt = sum(case month(CreateDate) when  8 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month09Amt = sum(case month(CreateDate) when  9 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month10Amt = sum(case month(CreateDate) when 10 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month11Amt = sum(case month(CreateDate) when 11 then Isnull(PAmt,0.0) else 0.0 end),
		    	Month12Amt = sum(case month(CreateDate) when 12 then Isnull(PAmt,0.0) else 0.0 end),
		    	TotalAmt   = sum(Isnull(PAmt,0.0))
		From PMS_Invoice a
		Where Year(CreateDate)=@Year And (BillSts='20' Or BillSts='25' Or BillSts='30')
			And DeptNo=@DeptNo
			And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And d.DeptNo=@CorpNo)
		Group by VendorID
	--更新供应商信息
	Update a Set a.VendorNo=b.VendorNo,a.VendorName=b.VendorName,a.NameSpell=b.NameSpell,
		a.BuyerID=b.BuyerID,a.Buyer=b.Buyer,a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes
	From @uTable a inner join BDM_Vendor_V b on a.VendorID=b.VendorID
	--返回
	Return
End
go

