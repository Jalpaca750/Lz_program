


CREATE VIEW [dbo].[IMS_Present_V]
AS
SELECT a.PresentNo, a.CreateDate, a.DeptNo, g.CHName AS DeptName, a.WareHouse, 
    h.CHName AS WHName, '赠品出库单' AS BillType, e.CustNo AS ObjectNo, 
e.CustName AS ObjectName, d .Amt, a.BillSts, a.IntegFlag, a.PFlag, 
    (SELECT StsName FROM BillStatus i WHERE a.BillSts = i.BillSts AND i.BillType = 'IMS60') AS StsName,
    a.SourceFlag,a.AuditDate, a.AuditID, c.EmployeeName AS Auditer, a.CreatorID, 
    b.EmployeeName AS Creator, a.PrintNum, a.PrinterID, p.EmployeeName AS Printer,  
    a.SendAddr,a.LinkMan,a.Phone,a.CarNumberSts,a.CarNumberDate,a.sendDate,a.sendTime,
    a.lineId,l.CHName AS lineName,a.wmsOrder,a.WmsBillNo,a.syncFlag,a.reasonId,
    r.CHName AS reasonDesc, a.Remarks, a.CheckBox
FROM dbo.IMS_Present a 
    LEFT JOIN dbo.BDM_WareHouse_V h ON a.WareHouse = h.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V g ON a.DeptNo = g.CodeID 
    LEFT JOIN dbo.BDM_Employee b ON a.CreatorID = b.EmployeeID 
    LEFT JOIN dbo.BDM_Employee c ON a.AuditID = c.EmployeeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID 
    LEFT JOIN (SELECT PresentNo, SUM(Amt) AS Amt
               FROM IMS_PresentDtl
               GROUP BY PresentNo) d ON a.PresentNo = d .PresentNo 
    LEFT JOIN dbo.BDM_Customer e ON a.CustID = e.CustID 
    LEFT JOIN dbo.BDM_Code l ON a.lineId=l.codeId 
    LEFT JOIN dbo.BDM_Code r ON a.reasonId=r.CodeID 
WHERE a.BillType = '20'
UNION ALL
SELECT a.PresentNo, a.CreateDate, a.DeptNo, g.CHName AS DeptName, a.WareHouse, 
    h.CHName AS WHName, '赠品入库单' AS BillType, f.VendorNo AS ObjectNo, 
    f.VendorName AS ObjectName, d .Amt, a.BillSts, a.IntegFlag, a.PFlag, 
    (SELECT StsName FROM BillStatus i WHERE a.BillSts = i.BillSts AND i.BillType = 'IMS60') AS StsName,
    a.SourceFlag,a.AuditDate, a.AuditID, c.EmployeeName AS Auditer, a.CreatorID, 
    b.EmployeeName AS Creator, a.PrintNum, a.PrinterID, p.EmployeeName AS Printer,
    a.SendAddr,a.LinkMan,a.Phone,a.CarNumberSts,a.CarNumberDate,a.sendDate,a.sendTime,
    a.lineId,l.CHName AS lineName,a.wmsOrder,a.WmsBillNo,a.syncFlag,a.reasonId,
    r.CHName AS reasonDesc,a.Remarks, a.CheckBox
FROM dbo.IMS_Present a 
    LEFT JOIN dbo.BDM_WareHouse_V h ON a.WareHouse = h.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V g ON a.DeptNo = g.CodeID 
    LEFT JOIN dbo.BDM_Employee b ON a.CreatorID = b.EmployeeID 
    LEFT JOIN dbo.BDM_Employee c ON a.AuditID = c.EmployeeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID 
    LEFT JOIN(SELECT PresentNo, SUM(Amt) AS Amt
              FROM IMS_PresentDtl
              GROUP BY PresentNo) d ON a.PresentNo = d .PresentNo 
    LEFT JOIN dbo.BDM_Vendor f ON a.VendorID = f.VendorID 
    LEFT JOIN dbo.BDM_Code l ON a.lineId=l.codeId 
    LEFT JOIN dbo.BDM_Code r ON a.reasonId=r.CodeID
WHERE a.BillType = '10'
go

