

CREATE VIEW [dbo].[WMS_SAD_Return_V]
AS
SELECT returnNo,billNo,companyId,ownerId,returnDate,ioType,warehouseId,customerId,receiverState,
    receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,groupId, 
    lineId,currencyId,exchangeRate,taxFlag,ioState,apState,totalFee,returnFee,postFee,reason,billSource, 
    salesId,buyerId,organizeId,isChange,logisticsType,deliveryId,deliveryTime,expressNo,logisticsId, 
    handlerId,handlerTime,deptId,dealTime,dealReason,thirdPartyNo,thirdSyncTime,thirdSyncFlag,orderType, 
    printNum,printId,shipState,memo,createtime,creatorId,auditorId,auditTime,isLocked,lockerId, 
    lockedTime,editTime,editorId,isSelected
FROM dbo.SAD_Return
UNION ALL
SELECT returnNo,billNo,companyId,ownerId,returnDate,ioType,warehouseId,customerId,receiverState,
    receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,receiverMobile,groupId, 
    lineId,currencyId,exchangeRate,taxFlag,ioState,apState,totalFee,returnFee,postFee,reason,billSource, 
    salesId,buyerId,organizeId,isChange,logisticsType,deliveryId,deliveryTime,expressNo,logisticsId, 
    handlerId,handlerTime,deptId,dealTime,dealReason,thirdPartyNo,thirdSyncTime,thirdSyncFlag,orderType, 
    printNum,printId,shipState,memo,createtime,creatorId,auditorId,auditTime,isLocked,lockerId, 
    lockedTime,editTime,editorId,isSelected
FROM YiWms.dbo.SAD_Return
WHERE CompanyId IN(SELECT companyId FROM SYS_Config)


go

