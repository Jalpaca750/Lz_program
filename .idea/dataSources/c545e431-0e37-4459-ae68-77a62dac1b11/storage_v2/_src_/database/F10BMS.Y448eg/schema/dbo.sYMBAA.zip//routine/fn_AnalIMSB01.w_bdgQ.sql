
--说明：其他入出库单统计分析
--作者：Devil.H
--创建：2010.08.03
--参数：
--	@StartDate:年度
--	@EndDate:自然月分
--	@DeptNo:部门
--	@WareHouse:仓库
--	@IOObject:入出库对象
--	@BillType:单据类型
--	@ClassID:商品大类
--	@LabelID:商品品牌
--	@ItemID:商品ID
--	@Flag:为前台设计
CREATE Function dbo.fn_AnalIMSB01
(
	@Period varchar(6),
	@StartDate varchar(10),
	@EndDate varchar(10),
	@DeptNo varchar(20),
	@WareHouse varchar(20),
	@IOObject varchar(2),
	@BillType varchar(2),
	@ClassID varchar(20),
	@LabelID varchar(20),
	@ItemID bigint=0,
	@Flag bit
)
Returns @uTable Table(
	DeptID varchar(20),
	DeptNo varchar(20),
	DeptName varchar(100),
	SQty decimal(18,6),
	Amt decimal(18,6),
	CstAmt decimal(18,6)
)
As
begin
	if @Flag=0 
		Return
	Declare @IsQTRK bit
	Declare @Method char(1)
	SELECT @IsQTRK=IsQTRK,@Method=Method FROM SYS_Config
	Declare @CostTmp Table
	(
		DeptNo varchar(20),
		ItemID bigint,
		Price decimal(18,10)
		Primary Key(DeptNo,ItemID)
	)
	Declare @TmpOther Table(
		DeptNo varchar(20),
		BillType varchar(2),
		ItemID Bigint,
	   	SQty decimal(18,6),
	   	Amt decimal(18,6)
	)
	--获取临时成本
	INSERT INTO @CostTmp(DeptNo,ItemID,Price)
	SELECT Isnull(DeptNo,'$$$$'),ItemID,MEPrice
	FROM uf_CostPrice(@Period)
	--获取符合条件的汇总数据
	INSERT INTO @TmpOther(DeptNo,BillType,ItemID,SQty,Amt)
	SELECT h.DeptNo,CASE h.BillType WHEN '60' THEN '10' ELSE h.BillType END,
	       dtl.ItemID,CASE h.BillType WHEN '10' THEN dtl.SQty
				   	  WHEN '20' THEN -dtl.SQty
				   	  WHEN '30' THEN -dtl.SQty
				   	  WHEN '60' THEN dtl.SQTY END AS SQty,
			   CASE h.BillType WHEN '10' THEN dtl.Amt
					   WHEN '20' THEN -dtl.Amt
					   WHEN '30' THEN -dtl.Amt
					   WHEN '60' THEN dtl.Amt END AS SQty
	FROM IMS_Other h INNER JOIN IMS_OtherDtl dtl ON h.OtherNo=dtl.OtherNo
	WHERE (h.BillSts='20') And (h.CreateDate Between @StartDate And @EndDate)
		And (h.DeptNo Like @DeptNo + '%')
		And (@IOObject=''  Or h.IOObject=@IOObject)
		And (@BillType=''  Or h.BillType=@BillType)
		And (dtl.WareHouse Like @WareHouse + '%')
		And (@ItemID=0 Or dtl.ItemID=@ItemID)
		And Exists(SELECT 1 FROM BDM_ItemInfo g 
			   WHERE dtl.ItemID=g.ItemID 
				And (g.ClassID Like @ClassID + '%') 
				And (g.LabelID Like @LabelID + '%')) 
	--获取成本计算方式
	IF ISNULL(@Method,'S')='S'
		INSERT INTO @uTable(DeptID,DeptNo,DeptName,SQty,Amt,CstAmt)
 		SELECT d.CodeID,d.CodeNo,d.CHName,SUM(t.SQty),SUM(t.Amt),SUM(t.CBAmt)
		FROM (SELECT a.DeptNo,a.ItemID,a.SQty,a.Amt,
				CASE WHEN @IsQTRK=1 And a.BillType='10' THEN a.Amt
				     ELSE ISNULL(a.SQty,0.0)*ISNULL(b.Price,0.0) END AS CBAmt
		      	FROM @TmpOther a INNER JOIN @CostTmp b ON a.DeptNo=b.DeptNo And a.ItemID=b.ItemID) t 
			LEFT OUTER JOIN BDM_DeptCode_V d ON t.DeptNo=d.CodeID
		GROUP BY d.CodeID,d.CodeNo,d.CHName
	ELSE
		INSERT INTO @uTable(DeptID,DeptNo,DeptName,SQty,Amt,CstAmt)
		SELECT d.CodeID,d.CodeNo,d.CHName,SUM(t.SQty),SUM(t.Amt),SUM(t.CBAmt)
		FROM (SELECT a.DeptNo,a.ItemID,a.SQty,a.Amt,
				CASE WHEN @IsQTRK=1 And a.BillType='10' THEN a.Amt
				     ELSE ISNULL(a.SQty,0.0)*ISNULL(b.Price,0.0) END AS CBAmt
		      	FROM @TmpOther a INNER JOIN @CostTmp b ON b.DeptNo='$$$$' And a.ItemID=b.ItemID) t 
			LEFT OUTER JOIN BDM_DeptCode_V d ON t.DeptNo=d.CodeID
		GROUP BY d.CodeID,d.CodeNo,d.CHName
	RETURN
End
go

