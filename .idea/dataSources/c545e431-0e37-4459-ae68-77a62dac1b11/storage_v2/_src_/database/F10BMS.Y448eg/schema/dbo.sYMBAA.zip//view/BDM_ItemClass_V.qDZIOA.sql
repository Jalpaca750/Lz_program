--商品大类
CREATE  VIEW dbo.BDM_ItemClass_V
AS
SELECT CodeID,OrderID,IsWeb, CodeNo, CHName, ENName,Flag, Classify,CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL02')
go

