--地区代码
CREATE VIEW dbo.SYS_AuditParm_V
AS
SELECT a.TblCode,a.TblName,a.AutoCheck,a.Auditing,a.AuditingOK,a.AutoCoding,b.CodeRule,b.Prefix,b.Link,b.StartNum,b.ViewOrder,
    a.AuditingFlag,a.AuditingPicFlag,a.IsPACheck,a.LstNumber,
    CASE b.CodeRule WHEN 1 THEN '分部标识+前缀+日期+5位流水'
                    WHEN 2 THEN '分部标识+前缀+日期+4位流水'
                    WHEN 3 THEN '分部标识+前缀+起始编号+流水'
                    WHEN 4 THEN '前缀+起始编号+流水'
                    WHEN 5 THEN '前缀+日期+5位流水'
                    WHEN 6 THEN '前缀+日期+4位流水'
                    WHEN 7 THEN '起始编号+流水'
                    WHEN 8 THEN '分部标识 + 起始编号 + 流水'
                    WHEN 9 THEN '分部标识 + 前缀 + 8位流水'
                    WHEN 10 THEN '分部标识 + 前缀 + 7位流水'
                    WHEN 11 THEN '分部标识 + 前缀 + 6位流水' END AS RuleDesc
FROM SYS_AuditParm a
    INNER JOIN SYS_BillType b ON a.TblCode=b.BillType
go

