CREATE VIEW dbo.出库单金额_成本_毛利
AS
SELECT DISTINCT 
                TOP (100) PERCENT dbo.SMS_StockDtl.StockNo, SUM(dbo.SMS_StockDtl.Amt) AS 出库金额, 
                SUM(dbo.CST_Price.MEPrice * dbo.SMS_StockDtl.SQty * 1.025) 
                + SUM(dbo.CST_Price.MEPrice * { fn IFNULL(dbo.SMS_StockDtl.ZQty, 0) } * 1.025) AS 成本金额, 
                SUM(dbo.SMS_StockDtl.Amt) - (SUM(dbo.CST_Price.MEPrice * dbo.SMS_StockDtl.SQty * 1.025) 
                + SUM(dbo.CST_Price.MEPrice * { fn IFNULL(dbo.SMS_StockDtl.ZQty, 0) } * 1.025)) AS 出库毛利
FROM      dbo.SMS_StockDtl INNER JOIN
                dbo.SMS_Stock ON dbo.SMS_StockDtl.StockNo = dbo.SMS_Stock.StockNo INNER JOIN
                dbo.CST_Price ON dbo.SMS_StockDtl.ItemID = dbo.CST_Price.ItemID AND LEFT(REPLACE(dbo.SMS_Stock.CreateDate, 
                '-', ''), 6) = dbo.CST_Price.Period INNER JOIN
                dbo.BDM_ItemInfo ON dbo.SMS_StockDtl.ItemID = dbo.BDM_ItemInfo.ItemID
GROUP BY dbo.SMS_StockDtl.StockNo
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[33] 4[20] 2[21] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "SMS_StockDtl"
            Begin Extent = 
               Top = 6
               Left = 490
               Bottom = 198
               Right = 860
            End
            DisplayFlags = 280
            TopColumn = 4
         End
         Begin Table = "SMS_Stock"
            Begin Extent = 
               Top = 152
               Left = 228
               Bottom = 336
               Right = 472
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CST_Price"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 153
               Right = 203
            End
            DisplayFlags = 280
            TopColumn = 1
         End
         Begin Table = "BDM_ItemInfo"
            Begin Extent = 
               Top = 38
               Left = 1056
               Bottom = 178
               Right = 1231
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 2655
         Width = 2235
         Width = 3015
         Width = 2970
         Width = 4395
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 12
         Column = 1440
         Alias = 900
         Table = 2880
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 135', 'SCHEMA', 'dbo', 'VIEW', '出库单金额_成本_毛利'
go

exec sp_addextendedproperty 'MS_DiagramPane2', N'0
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', '出库单金额_成本_毛利'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 2, 'SCHEMA', 'dbo', 'VIEW', '出库单金额_成本_毛利'
go

