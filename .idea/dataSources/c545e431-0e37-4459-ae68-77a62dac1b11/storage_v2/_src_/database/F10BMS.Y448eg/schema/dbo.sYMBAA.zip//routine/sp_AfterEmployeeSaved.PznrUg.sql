-- =============================================
-- Author:		<Frank.He>
-- Create date: <2017-07-29>
-- Description:	<员工资料保存后同步到WMS对应的表>
-- Parameter:   
--      @employeeNo 员工编码
-- =============================================
CREATE PROCEDURE [dbo].[sp_AfterEmployeeSaved]
(
	@employeeNo VARCHAR(20)
)
AS
BEGIN
	--接口变量
	DECLARE @companyId VARCHAR(32),
			@operatorId VARCHAR(32),
			@guid VARCHAR(32),
			@curTime DATETIME
	
	DECLARE @employeeName VARCHAR(100),
			@Sex VARCHAR(10),
			@Nation VARCHAR(100),
			@BirthDay CHAR(10),
			@IDCard VARCHAR(32),
			@Phone VARCHAR(40),
			@EMail VARCHAR(100),
			@IDAddr VARCHAR(200),
			@Addr VARCHAR(200),
			@deptNo VARCHAR(20),
			@deptId VARCHAR(32),
			@Flag CHAR(1),
			@Remarks VARCHAR(1000),
            @errors BIGINT;
			
	SELECT TOP 1 @companyId=companyId,@operatorId=IOperatorId FROM dbo.SYS_Config;
	SET @curTime=GETDATE();	
    --如果WMS接口未开启，直接退出
	IF NOT EXISTS(SELECT * FROM dbo.SYS_Config WHERE ISNULL(startWMS,0)=1)
	    RETURN;
	IF EXISTS(SELECT 1 FROM dbo.BDM_Employee WHERE EmployeeNo=@employeeNo AND syncFlag=1)
		RETURN;

	--取得员工资料数据	
	SELECT @employeeName=a.employeeName,@Sex=a.Sex,@Nation=a.Nation,@BirthDay=a.BirthDay,
		@IDCard=a.IDCard,@Phone=a.Phone,@EMail=a.EMail,@IDAddr=a.IDAddr,@Addr=a.Addr,
		@deptNo=d.CodeNo,@Flag=a.Flag,@Remarks=a.Remarks
	FROM dbo.BDM_Employee a 
		LEFT JOIN dbo.BDM_DeptCode_V d ON a.DeptCode=d.CodeID
	WHERE a.EmployeeNo=@employeeNo
	--获取员工部门Id
	SELECT @deptId=deptId
	FROM YiWms.dbo.BAS_Department
	WHERE companyId=@companyId AND deptNo=@deptNo;
    SET @errors=0;
	BEGIN TRANSACTION
	--员工资料是否已经同步
	IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Employee WHERE companyId=@companyId AND employeeNo=@employeeNo)
	BEGIN
		SET @guid=LOWER(REPLACE(NEWID(),'-',''));
		INSERT INTO YiWms.dbo.BAS_Employee(employeeId,employeeNo,companyId,employeeName,sex,nationality,birthday,
			officeTel,mobileNo,email,idCardNo,idAddress,currAddress,deptId,employeeState,memo,isLocked,lockerId,
			lockedTime,createTime,creatorId,editTime,editorId)
		VALUES(@guid,@employeeNo,@companyId,@employeeName,@Sex,@Nation,@BirthDay,'',@Phone,@EMail,@IDCard,@IDAddr,@Addr,@deptId,
			@Flag,@Remarks,0,'',NULL,@curTime,@operatorId,@curTime,@operatorId)
        SET @errors=+@errors+@@Error;
		--写入操作日志
		INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterEmployeeSaved',
			'通过接口同步员工资料，员工:[' + @employeeNo + '],员工名称:[' + @employeeName + ']',@guid,'');
        SET @errors=+@errors+@@Error;
	END
	ELSE
	BEGIN
		SELECT @guid=employeeId FROM YiWms.dbo.BAS_Employee WHERE companyId=@companyId AND employeeNo=@employeeNo;
		--写入操作日志
		INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterEmployeeSaved',
			'通过接口同步员工资料，员工:[' + @employeeNo + '],员工名称[' + @employeeName + ']',@guid,'');	
        SET @errors=+@errors+@@Error;		
		UPDATE YiWms.dbo.BAS_Employee SET employeeName=@employeeName,
											   sex=@Sex,
											   nationality=@Nation,
											   birthday=@BirthDay,
											   officeTel='',
											   mobileNo=@Phone,
											   email=@EMail,
											   idCardNo=@IDCard,
											   idAddress=@IDAddr,
											   currAddress=@Addr,
											   deptId=@deptId,
											   employeeState=@Flag,
											   memo=@Remarks,
											   editTime=@curTime,
											   editorId=@operatorId
		WHERE employeeId=@guid;
        SET @errors=+@errors+@@Error;
	END
	UPDATE dbo.BDM_Employee SET syncFlag=1 WHERE EmployeeNo=@employeeNo;
	SET @errors=+@errors+@@Error;
    IF @errors=0 
    BEGIN
        COMMIT;
    END
    ELSE
    BEGIN
    	IF @@TRANCOUNT > 0
    		 ROLLBACK
    	DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
    	SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;
    	RAISERROR(@ErrMsg, @ErrSeverity, 1)	
    	--写入同步错误日志	
    	INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
    	VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterEmployeeSaved','YI_EMPLOYEE_SYNC_ERROR',LEFT(@ErrMsg,2000),@guid,@employeeNo);
    END
END

go

