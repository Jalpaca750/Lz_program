--采购付款明细插入操作（Delete)
--2005-01-25
--Devil.H
--当上述操作发生时：
--更新采购发票已付款金额……
CREATE Trigger Trig_PMS_PaymentDtl_Del
On dbo.PMS_PaymentDtl
For Delete
As
Begin
	declare @InvoiceID bigint
	--更新订单的已入库数量
	Update a Set a.PAmt=Isnull(a.PAmt,0)-Isnull(b.PayAmt,0)-isnull(b.FAmt,0)
	From PMS_Invoice a,Deleted b
	Where a.InvoiceID=b.InvoiceID
	--计划单
	declare mycursor cursor
	for select Distinct InvoiceID from PMS_Invoice Where InvoiceID In(Select InvoiceID From Deleted)
	open mycursor
	fetch next from mycursor into @InvoiceID
	while @@fetch_Status=0
	begin
		--存在未执行的记录
		if exists(Select * from PMS_Invoice_V Where abs(Isnull(PAmt,0))>0 And InvoiceID=@InvoiceID)
			Update PMS_Invoice Set BillSts='25' Where InvoiceID=@InvoiceID
		else
			Update PMS_Invoice Set BillSts='20' Where InvoiceID=@InvoiceID	
		fetch next from mycursor into @InvoiceID
	end
	close mycursor
	deallocate mycursor

End
go

