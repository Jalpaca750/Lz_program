--移仓单审核操作（Update BillSts)
--2007-09-20
--Devil.H
--当上述操作发生时：
--更新库房总帐数量，同时更商品资料、入出库流水帐单状态
CREATE Proc sp_IMSTransferAudit
(
	@TransferNo varchar(20),
	@Flag char(2)
)
As
Begin
	declare @WareHouse_O varchar(20)
	declare @WareHouse_I varchar(20)
	declare @DeptNo varchar(20)
	declare @CreateDate varchar(10)
	declare @AuditDate varchar(10)
	--获取当前移仓库房
	Select @WareHouse_O=WareHouse_O,@WareHouse_I=WareHouse_I,@DeptNo=DeptNo,
		@AuditDate=AuditDate,@CreateDate=CreateDate
	From IMS_Transfer 
	Where TransferNo=@TransferNo
	if @Flag='20'	--验收
		begin
			--更新现有的商品
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.TQty,0),a.lasttime=getdate()
			From IMS_Ledger a,IMS_TransferDtl b
			Where a.ItemID=b.ItemID And a.WareHouse=@WareHouse_I And b.TransferNo=@TransferNo
			--插入没有的
			Insert Into IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,lasttime)
			Select @DeptNo,@WareHouse_I,ItemID,Isnull(TQty,0),getdate()
			From IMS_TransferDtl
			Where TransferNo=@TransferNo And ItemID Not In(Select ItemID From IMS_Ledger Where WareHouse=@WareHouse_I) 
			--移出
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.TQty,0),a.lasttime=getdate()
			From IMS_Ledger a,IMS_TransferDtl b
			Where a.ItemID=b.ItemID And a.WareHouse=@WareHouse_O And b.TransferNo=@TransferNo
			--写入库房商品流水帐
			Insert Into IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,CreateDate,AuditDate)
			Select TransferNo,BillType,DeptNo,WareHouse,ItemID,TQty,CreateDate,AuditDate
			From (Select TransferNo,'移仓单' As BillType,@DeptNo As DeptNo,@WareHouse_I As WareHouse,ItemID,TQty,@CreateDate As CreateDate,@AuditDate As AuditDate 
				From IMS_TransferDtl 
				Where TransferNo=@TransferNo
				Union All 
				Select TransferNo,'移仓单',@DeptNo,@WareHouse_O,ItemID,-TQty,@CreateDate,@AuditDate 
				From IMS_TransferDtl 
				Where TransferNo=@TransferNo) t
			Where Not Exists(Select 1 From IMS_Flow Where BillNo=@TransferNo)
		end 
	if @Flag='10'	--取消验收
		begin
			--更新现有的商品
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.TQty,0),a.lasttime=getdate()
			From IMS_Ledger a,IMS_TransferDtl b
			Where a.ItemID=b.ItemID And a.WareHouse=@WareHouse_I And b.TransferNo=@TransferNo
			--
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.TQty,0),a.lasttime=getdate()
			From IMS_Ledger a,IMS_TransferDtl b
			Where a.ItemID=b.ItemID And a.WareHouse=@WareHouse_O And b.TransferNo=@TransferNo
			--删除流水帐
			Delete From IMS_Flow Where BillNo=@TransferNo
		end
End
go

