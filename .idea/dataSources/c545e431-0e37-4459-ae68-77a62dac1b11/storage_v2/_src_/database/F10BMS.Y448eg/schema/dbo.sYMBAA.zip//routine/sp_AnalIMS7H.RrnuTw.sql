

--说明：商品收发存月报
--作者：Devil.H
--创建：2007.11.13
--参数：
--	@Year：年份
--	@Month：月份
CREATE Proc dbo.sp_AnalIMS7H
(	
	@Year bigint,
	@Month bigint
)
As
Begin
	declare @IsPur bit
	declare @IsZPRK bit
	declare @IsDBRK bit
	declare @IsZZRK bit
	declare @IsCXRK bit
	declare @IsQTRK bit
	declare @AmtDec int
	declare @Method char(1)

	declare @StartDate char(10)
	declare @EndDate char(10)
	declare @Period varchar(6)
	declare @OldPeriod varchar(6)
	--********增加会计月份时间处理***********************
	if @Month<10
		Set @Period=Cast(@Year as varchar(4))+'0'+Cast(@Month as varchar(1))
	else
		Set @Period=Cast(@Year as varchar(4))+Cast(@Month as varchar(2))

	--如果当前会计期已经封帐，则不再计算该月数据
	if Exists(Select 1 From SYS_Period Where SealFlag=1 And Period=@Period)
		return 

	--计算前一个会计期
	Select @OldPeriod=Case When @Month=1 Then Cast(@Year - 1 as varchar(4)) + '12'
		    		When @Month=11 Or @Month=12 Then Cast(@Year as varchar(4)) + Cast(@Month - 1 as varchar(2))
		    		Else Cast(@Year as varchar(4)) + '0' + Cast(@Month-1 as varchar(1)) End
	--会计月份的起始日期和截止日期
	Select @StartDate=StartDate,@EndDate=EndDate From SYS_CW_MonthPeriod Where CW_Period=@Period
	--成本核算方法
	Select @Method=isnull(Method,'T'),@IsPur=Isnull(IsPur,1),@IsZPRK=Isnull(IsZPRK,1),
		@IsDBRK=Isnull(IsDBRK,1),@IsZZRK=Isnull(IsZZRK,1),@IsCXRK=Isnull(IsCXRK,1),
		@IsQTRK=Isnull(IsQTRK,1),@AmtDec=Isnull(AmtDec,2)
	From Sys_Config
	--***************************************************
	--定制品成本
	Create Table #Special(DeptNo varchar(20),WareHouse varchar(20),ItemID bigint,SQty decimal(18,8),CAmt decimal(18,6),SAmt decimal(18,6) Primary Key(DeptNo,WareHouse,ItemID))
	--临时成本数据
	Create Table #CostTmp(DeptNo varchar(20),ItemID bigint,Price decimal(18,8) Primary Key(DeptNo,ItemID))
	--临时流水账表
	Create Table  #FlowTmp(DeptNo varchar(20),WareHouse varchar(20),BillType varchar(20),ItemID bigint,SQty decimal(18,6),Amt decimal(18,6))
	--临时进销存数据
	Create Table #TmpJXC(DeptNo varchar(20),WareHouse varchar(20),ItemID bigint,
			     QCQty decimal(18,6),QCAmt decimal(18,6),CGRK decimal(18,6),CGRKAmt decimal(18,6),
			     DBRK decimal(18,6),DBRKAmt decimal(18,6),ZPRK decimal(18,6),ZPRKAmt decimal(18,6),
			     QTRK decimal(18,6),QTRKAmt decimal(18,6),STRK decimal(18,6),STRKAmt decimal(18,6),
			     ZZRK decimal(18,6),ZZRKAmt decimal(18,6),CXRK decimal(18,6),CXRKAmt decimal(18,6),
			     PDRK decimal(18,6),XSCK decimal(18,6),LSCK decimal(18,6),YCDQty decimal(18,6),
			     DBCK decimal(18,6),ZPCK decimal(18,6),QTCK decimal(18,6),BSCK decimal(18,6),
			     ZZCK decimal(18,6),CXCK decimal(18,6),QMQty decimal(18,6),Price decimal(18,10)
			     Primary Key(DeptNo,WareHouse,ItemID))

	--临时成本
	Insert Into #CostTmp(DeptNo,ItemID,Price)
	Select Isnull(DeptNo,'$$$$'),ItemID,MEPrice
	From uf_CostPrice(@Period)
	--需要统计的数据
	Insert Into #FlowTmp(DeptNo,WareHouse,BillType,ItemID,SQty,Amt)
	Select DeptNo,WareHouse,Case BillType When '采购退货单' Then '采购入库单'
				    		When '销售退货单' Then '销售出库单'
				    		When '零售退货单' Then '零售出库单'
				    		WHEN '盘点调整单' then '其他出库单'
				    		Else BillType End,ItemID,SQty,Amt
	From IMS_Flow 
	Where CreateDate Between @StartDate And @EndDate
	--调价单
	Insert Into #FlowTmp(DeptNo,WareHouse,BillType,ItemID,SQty,Amt)
	Select a.DeptNo,c.WareHouse,'采购入库单',b.ItemID,0.0,b.Amt
	From PMS_Rectify a Inner Join PMS_RectifyDtl b On a.RectifyNo=b.RectifyNo
			   Inner Join PMS_StockDtl c On b.StockID=c.StockID
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.CreateDate Between @StartDate And @EndDate)
	--定制品成本
	Insert Into #Special(DeptNo,WareHouse,ItemID,SQty,SAmt)
	Select Case Isnull(@Method,'T') When 'S' Then a.DeptNo Else '$$$$' End,a.WareHouse,b.ItemID,
		SUM(-(Isnull(b.SQty,0.0)+Isnull(b.ZQty,0.0))),Sum(-(Isnull(b.SQty,0.0)+Isnull(b.ZQty,0.0))*Isnull(c.Price,0.0)) 
	From SMS_Stock a Inner Join SMS_StockDtl b On a.StockNo=b.StockNo 
		 	 Inner Join (Select y.XS_OrderID,y.Price 
				     From PMS_Stock x Inner Join PMS_StockDtl y On x.StockNo=y.StockNo
 
				     Where (x.BillSts='20' Or x.BillSts='25' Or x.BillSts='30') And Isnull(y.IsSpecial,0)=1) c On b.OrderID=c.XS_OrderID
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')	
		And (a.CreateDate Between @StartDate And @EndDate)
		And Isnull(b.IsSpecial,0)=1
	Group By a.DeptNo,a.WareHouse,b.ItemID

	--统计数据
	Insert Into #TmpJXC(DeptNo,WareHouse,ItemID,
		QCQty,QCAmt,CGRK,CGRKAmt,DBRK,DBRKAmt,ZPRK,ZPRKAmt,QTRK,
		QTRKAmt,STRK,STRKAmt,ZZRK,ZZRKAmt,CXRK,CXRKAmt,
		PDRK,XSCK,LSCK,DBCK,ZPCK,QTCK,BSCK,ZZCK,CXCK,YCDQty)
	Select t.DeptNo,t.WareHouse,t.ItemID,
		SUM(t.QCQty),SUM(t.QCAmt),SUM(t.CGRK),SUM(t.CGRKAmt),
		SUM(t.DBRK),SUM(t.DBRKAmt),SUM(t.ZPRK),SUM(t.ZPRKAmt),
		SUM(t.QTRK),SUM(t.QTRKAmt),SUM(t.STRK),SUM(t.STRKAmt),
		SUM(t.ZZRK),SUM(t.ZZRKAmt),SUM(t.CXRK),SUM(t.CXRKAmt),
		SUM(t.PDRK),SUM(t.XSCK),SUM(t.LSCK),SUM(t.DBCK),SUM(t.ZPCK),SUM(t.QTCK),SUM(t.BSCK),
		SUM(t.ZZCK),SUM(t.CXCK),SUM(t.YCDQty)
	From (Select DeptNo,WareHouse,ItemID,0.0 As QCQty,0.0 As QCAmt,
			CGRK=SUM(Case BillType When '采购入库单' Then SQty Else 0.0 End),
			CGRKAmt=SUM(Case BillType When '采购入库单' Then Amt Else 0.0 End),
			DBRK=SUM(Case BillType When '调拨入库单' Then SQty Else 0.0 End),
			DBRKAmt=SUM(Case BillType When '调拨入库单' Then Amt Else 0.0 End),
			ZPRK=SUM(Case BillType When '赠品入库单' Then SQty Else 0.0 End),
			ZPRKAmt=SUM(Case BillType When '赠品入库单' Then Amt Else 0.0 End),
			QTRK=SUM(Case BillType When '其他入库单' Then SQty Else 0.0 End),
			QTRKAmt=SUM(Case BillType When '其他入库单' Then Amt Else 0.0 End),
			STRK=SUM(Case BillType When '库存初始化' Then SQty Else 0.0 End),
			STRKAmt=SUM(Case BillType When '库存初始化' Then Amt Else 0.0 End),
			ZZRK=SUM(Case BillType When '组装入库单' Then SQty Else 0.0 End),
			ZZRKAmt=SUM(Case BillType When '组装入库单' Then Amt Else 0.0 End),
			CXRK=SUM(Case BillType When '拆卸入库单' Then SQty Else 0.0 End),
			CXRKAmt=SUM(Case BillType When '拆卸入库单' Then Amt Else 0.0 End),
			PDRK=Sum(Case BillType When '盘存清单' Then Isnull(SQty,0.0) else 0.0 end),
			XSCK=Sum(Case BillType When '销售出库单' Then Isnull(SQty,0.0) else 0.0 end),
			LSCK=Sum(Case BillType When '零售出库单' Then Isnull(SQty,0.0) else 0.0 end),
			DBCK=Sum(Case BillType When '调拨出库单' Then Isnull(SQty,0.0) else 0.0 end),
			ZPCK=Sum(Case BillType When '赠品出库单' Then Isnull(SQty,0.0) else 0.0 end),
			QTCK=Sum(Case BillType When '其他出库单' Then Isnull(SQty,0.0) else 0.0 end),
			BSCK=Sum(Case BillType When '报损出库单' Then Isnull(SQty,0.0) else 0.0 end),
			ZZCK=Sum(Case BillType When '组装出库单' Then Isnull(SQty,0.0) else 0.0 end),
			CXCK=Sum(Case BillType When '拆卸出库单' Then Isnull(SQty,0.0) else 0.0 end),
			YCDQty=Sum(Case BillType when '移仓单' then Isnull(SQty,0.0) else 0.0 end)
		From #FlowTmp
		Group By DeptNo,Warehouse,ItemID
		Union All 
		Select DeptNo,WareHouse,ItemID,QMQty,QMAmt,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,
				0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0
		From ANAL_IMS7H
		Where Period=@OldPeriod) t
	Group By t.DeptNo,t.WareHouse,t.ItemID
	--删除当前月数据
	Delete From ANAL_IMS7H Where Period=@Period	
	If @Method='S'
		Insert Into ANAL_IMS7H(Period,DeptNo,WareHouse,ItemID,
			QCQty,QCAmt,CGRK,CGRKAmt,DBRK,DBRKAmt,ZPRK,ZPRKAmt,QTRK,QTRKAmt,ZZRK,ZZRKAmt,CXRK,CXRKAmt,PDRK,PDRKAmt,SumRK,
			XSCK,XSCKAmt,LSCK,LSCKAmt,DBCK,DBCKAmt,ZPCK,ZPCKAmt,QTCK,QTCKAmt,ZZCK,ZZCKAmt,CXCK,CXCKAmt,YCDQty,YCDAmt,
			SumCK,SumCKAmt,QMQty,QMAmt,QMPrice)
		Select @Period,a.DeptNo,a.WareHouse,a.ItemID,
			a.QCQty,a.QCAmt,a.CGRK,a.CGRKAmt,
			a.DBRK,Case @IsDBRK When 1 Then a.DBRKAmt Else Round(Isnull(a.DBRK,0.0)*Isnull(b.Price,0.0),@AmtDec) End,
			a.ZPRK,Case @IsZPRK When 1 Then a.ZPRKAmt Else Round(Isnull(a.ZPRK,0.0)*Isnull(b.Price,0.0),@AmtDec) End,
			Isnull(a.QTRK,0.0)+Isnull(a.STRK,0.0),Case @IsQTRK When 1 Then Isnull(a.QTRKAmt,0.0)+Isnull(a.STRKAmt,0.0) Else Round((Isnull(a.QTRK,0.0)+Isnull(a.STRK,0.0))*Isnull(b.Price,0.0),@AmtDec) End,
			a.ZZRK,Case @IsZZRK When 1 Then a.ZZRKAmt Else Round(Isnull(a.ZZRK,0.0)*Isnull(b.Price,0.0),@AmtDec) End,
			a.CXRK,Case @IsCXRK When 1 Then a.CXRKAmt Else Round(Isnull(a.CXRK,0.0)*Isnull(b.Price,0.0),@AmtDec) End,
			a.PDRK,Round(Isnull(a.PDRK,0.0)*Isnull(b.Price,0.0),@AmtDec),	
			Isnull(a.CGRK,0.0)+Isnull(a.DBRK,0.0)+Isnull(a.ZPRK,0.0)+Isnull(a.QTRK,0.0)+Isnull(a.STRK,0.0)+Isnull(a.ZZRK,0.0)+Isnull(a.CXRK,0.0)+Isnull(a.PDRK,0.0),
			a.XSCK,Round(Isnull(a.XSCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			a.LSCK,Round(Isnull(a.LSCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			a.DBCK,Round(Isnull(a.DBCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			a.ZPCK,Round(Isnull(a.ZPCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0),Round((Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0))*Isnull(b.Price,0.0),@AmtDec),
			a.ZZCK,Round(Isnull(a.ZZCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			a.CXCK,Round(Isnull(a.CXCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			a.YCDQty,Round(Isnull(a.YCDQty,0.0)*Isnull(b.Price,0.0),@AmtDec),
			Isnull(a.XSCK,0.0)+Isnull(a.LSCK,0.0)+Isnull(a.DBCK,0.0)+Isnull(a.ZPCK,0.0)+Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0)+Isnull(a.ZZCK,0.0)+Isnull(a.CXCK,0.0)+Isnull(YCDQty,0.0),
			(Isnull(a.XSCK,0.0)+Isnull(a.LSCK,0.0)+Isnull(a.DBCK,0.0)+Isnull(a.ZPCK,0.0)+Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0)+Isnull(a.ZZCK,0.0)+Isnull(a.CXCK,0.0)+Isnull(YCDQty,0.0))*Isnull(b.Price,0.0),
			Isnull(a.QCQty,0.0) +Isnull(a.CGRK,0.0)+Isnull(a.DBRK,0.0)+Isnull(a.ZPRK,0.0)+Isnull(a.QTRK,0.0)+Isnull(a.STRK,0.0)+Isnull(a.ZZRK,0.0)+Isnull(a.CXRK,0.0)+Isnull(a.PDRK,0.0)+
			+Isnull(a.XSCK,0.0)+Isnull(a.LSCK,0.0)+Isnull(a.DBCK,0.0)+Isnull(a.ZPCK,0.0)+Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0)+Isnull(a.ZZCK,0.0)+Isnull(a.CXCK,0.0)+Isnull(YCDQty,0.0),
			(Isnull(a.QCQty,0.0) +Isnull(a.CGRK,0.0)+Isnull(a.DBRK,0.0)+Isnull(a.ZPRK,0.0)+Isnull(a.QTRK,0.0)+Isnull(a.STRK,0.0)+Isnull(a.ZZRK,0.0)+Isnull(a.CXRK,0.0)+Isnull(a.PDRK,0.0)+
			+Isnull(a.XSCK,0.0)+Isnull(a.LSCK,0.0)+Isnull(a.DBCK,0.0)+Isnull(a.ZPCK,0.0)+Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0)+Isnull(a.ZZCK,0.0)+Isnull(a.CXCK,0.0)+Isnull(YCDQty,0.0))*Isnull(b.Price,0.0),
			b.Price
		From #TmpJXC a Inner Join #CostTmp b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
	Else
		Insert Into ANAL_IMS7H(Period,DeptNo,WareHouse,ItemID,
			QCQty,QCAmt,CGRK,CGRKAmt,DBRK,DBRKAmt,ZPRK,ZPRKAmt,QTRK,QTRKAmt,ZZRK,ZZRKAmt,CXRK,CXRKAmt,PDRK,PDRKAmt,SumRK,
			XSCK,XSCKAmt,LSCK,LSCKAmt,DBCK,DBCKAmt,ZPCK,ZPCKAmt,QTCK,QTCKAmt,ZZCK,ZZCKAmt,CXCK,CXCKAmt,YCDQty,YCDAmt,
			SumCK,SumCKAmt,QMQty,QMAmt,QMPrice)
		Select @Period,a.DeptNo,a.WareHouse,a.ItemID,
			a.QCQty,a.QCAmt,a.CGRK,a.CGRKAmt,
			a.DBRK,Case @IsDBRK When 1 Then a.DBRKAmt Else Round(Isnull(a.DBRK,0.0)*Isnull(b.Price,0.0),@AmtDec) End,
			a.ZPRK,Case @IsZPRK When 1 Then a.ZPRKAmt Else Round(Isnull(a.ZPRK,0.0)*Isnull(b.Price,0.0),@AmtDec) End,
			Isnull(a.QTRK,0.0)+Isnull(a.STRK,0.0),Case @IsQTRK When 1 Then Isnull(a.QTRKAmt,0.0)+Isnull(a.STRKAmt,0.0) Else Round((Isnull(a.QTRK,0.0)+Isnull(a.STRK,0.0))*Isnull(b.Price,0.0),@AmtDec) End,
			a.ZZRK,Case @IsZZRK When 1 Then a.ZZRKAmt Else Round(Isnull(a.ZZRK,0.0)*Isnull(b.Price,0.0),@AmtDec) End,
			a.CXRK,Case @IsCXRK When 1 Then a.CXRKAmt Else Round(Isnull(a.CXRK,0.0)*Isnull(b.Price,0.0),@AmtDec) End,
			a.PDRK,Round(Isnull(a.PDRK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			Isnull(a.CGRK,0.0)+Isnull(a.DBRK,0.0)+Isnull(a.ZPRK,0.0)+Isnull(a.QTRK,0.0)+Isnull(a.STRK,0.0)+Isnull(a.ZZRK,0.0)+Isnull(a.CXRK,0.0)+Isnull(a.PDRK,0.0),
			a.XSCK,Round(Isnull(a.XSCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			a.LSCK,Round(Isnull(a.LSCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			a.DBCK,Round(Isnull(a.DBCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			a.ZPCK,Round(Isnull(a.ZPCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0),Round((Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0))*Isnull(b.Price,0.0),@AmtDec),
			a.ZZCK,Round(Isnull(a.ZZCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			a.CXCK,Round(Isnull(a.CXCK,0.0)*Isnull(b.Price,0.0),@AmtDec),
			a.YCDQty,Round(Isnull(a.YCDQty,0.0)*Isnull(b.Price,0.0),@AmtDec),	
			Isnull(a.XSCK,0.0)+Isnull(a.LSCK,0.0)+Isnull(a.DBCK,0.0)+Isnull(a.ZPCK,0.0)+Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0)+Isnull(a.ZZCK,0.0)+Isnull(a.CXCK,0.0)+Isnull(YCDQty,0.0),
			(Isnull(a.XSCK,0.0)+Isnull(a.LSCK,0.0)+Isnull(a.DBCK,0.0)+Isnull(a.ZPCK,0.0)+Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0)+Isnull(a.ZZCK,0.0)+Isnull(a.CXCK,0.0)+Isnull(YCDQty,0.0))*Isnull(b.Price,0.0),
			Isnull(a.QCQty,0.0) +Isnull(a.CGRK,0.0)+Isnull(a.DBRK,0.0)+Isnull(a.ZPRK,0.0)+Isnull(a.QTRK,0.0)+Isnull(a.STRK,0.0)+Isnull(a.ZZRK,0.0)+Isnull(a.CXRK,0.0)+Isnull(a.PDRK,0.0)+
			+Isnull(a.XSCK,0.0)+Isnull(a.LSCK,0.0)+Isnull(a.DBCK,0.0)+Isnull(a.ZPCK,0.0)+Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0)+Isnull(a.ZZCK,0.0)+Isnull(a.CXCK,0.0)+Isnull(YCDQty,0.0),
			(Isnull(a.QCQty,0.0) +Isnull(a.CGRK,0.0)+Isnull(a.DBRK,0.0)+Isnull(a.ZPRK,0.0)+Isnull(a.QTRK,0.0)+Isnull(a.STRK,0.0)+Isnull(a.ZZRK,0.0)+Isnull(a.CXRK,0.0)+Isnull(a.PDRK,0.0)+
			+Isnull(a.XSCK,0.0)+Isnull(a.LSCK,0.0)+Isnull(a.DBCK,0.0)+Isnull(a.ZPCK,0.0)+Isnull(a.QTCK,0.0)+Isnull(a.BSCK,0.0)+Isnull(a.ZZCK,0.0)+Isnull(a.CXCK,0.0)+Isnull(YCDQty,0.0))*Isnull(b.Price,0.0),
			b.Price
		From #TmpJXC a Inner Join #CostTmp b On b.DeptNo='$$$$' And a.ItemID=b.ItemID

	--定制品1.1
	Update a Set a.CAmt=Round(Isnull(a.SQty,0.0)*Isnull(b.Price,0.0),@AmtDec)
	From #Special a Inner Join #CostTmp b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
	--定制品1.2
	Update a Set a.SumRKAmt=ISNULL(a.CGRKAmt, 0.0) + ISNULL(a.DBRKAmt, 0.0) + ISNULL(a.ZPRKAmt, 0.0) + ISNULL(a.QTRKAmt, 0.0) + ISNULL(a.ZZRKAmt, 0.0) + ISNULL(a.CXRKAmt, 0.0) + ISNULL(a.PDRKAmt, 0.0),
		     a.XSCKAmt=Isnull(a.XSCKAmt,0.0)-Isnull(b.CAmt,0.0)+Isnull(b.SAmt,0.0),
		     a.SumCKAmt=Isnull(a.SumCKAmt,0.0)-Isnull(b.CAmt,0.0)+Isnull(b.SAmt,0.0)
	From ANAL_IMS7H a Left Outer Join #Special b On a.WareHouse=b.WareHouse And a.ItemID=b.ItemID
	Where Period=@Period
	--重新核算期末金额
	Update ANAL_IMS7H Set CBSYAmt=Isnull(QCAmt,0.0)+Isnull(SumRKAmt,0.0)+Isnull(SumCKAmt,0.0)-Isnull(QMAmt,0.0)
	Where Period=@Period
	Drop Table #Special
	Drop Table #FlowTmp
	Drop Table #CostTmp
	Drop Table #TmpJXC
End
go

