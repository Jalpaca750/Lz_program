--电子出库单
CREATE VIEW dbo.PMS_EStockTmp_V
--with encryption
AS
SELECT a.StockNo, a.ItemID, a.ItemNo, a.ItemName, a.ItemSpec, b.BarCode, b.ClassName, 
      b.LabelName, a.UnitName, a.WareHouse, c.Location, b.OnHandQty, b.AvailQty, 
      a.SQty, a.PPrice, a.Amt, b.Package, b.PPrice as Price,b.SafePPrice
FROM dbo.PMS_EStockTmp a INNER JOIN
      dbo.BDM_ItemInfo_V b ON a.ItemID = b.ItemID LEFT OUTER JOIN
      dbo.IMS_Ledger c ON a.WareHouse = c.WareHouse AND a.ItemID = c.ItemID






go

