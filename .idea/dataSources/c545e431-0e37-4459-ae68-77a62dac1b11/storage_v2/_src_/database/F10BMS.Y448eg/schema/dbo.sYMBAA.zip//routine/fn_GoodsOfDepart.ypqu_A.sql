CREATE FUNCTION fn_GoodsOfDepart(@DeptNo varchar(20))
RETURNS TABLE
AS
RETURN (
	SELECT a.ItemID, a.ItemNo, a.ItemName, a.ItemAlias, a.NameSpell, a.ItemSpec,  
		a.BarCode,a.ClassID, c.CHName AS ClassName, a.LabelID, d.CHName AS LabelName, 
		a.UnitName, a.ColorName,a.PkgSpec,a.BPackage,a.MPackage, a.Package,
		b.LocalOHQty, b.LocalAVQty,a.OnHandQty,
		ISNULL(a.OnHandQty, 0.0) - ISNULL(a.AllocQty, 0.0) AS AvailQty, 
		a.PPrice, ISNULL(p.SPrice, a.SPrice) AS SPrice,a.SPrice1, a.SPrice2, a.SPrice3, 
		a.SafePPrice, ISNULL(p.SafeSPrice, a.SafeSPrice) AS SafeSPrice, 
		a.Defined1, a.Defined2,a.Defined3, a.Defined4, a.Defined5, a.NotDisc, a.HotFlag,
		a.Flag,a.CreateDate,a.AmendDate,a.Remarks
	FROM dbo.BDM_ItemInfo a INNER JOIN
		(SELECT ItemID,SPrice,SPrice1,SPrice2,SPrice3,SafeSPrice
		 FROM SMS_RetailPrice
		 WHERE DeptNo=@DeptNo) p ON a.ItemID=p.ItemID LEFT OUTER JOIN
		dbo.BDM_ItemClass_V c ON a.ClassID = c.CodeID LEFT OUTER JOIN
		dbo.BDM_LabelCode_V d ON a.LabelID = d.CodeID LEFT OUTER JOIN
		(SELECT ItemID,OnHandQty as LocalOHQty,Isnull(OnHandQty,0.0)-Isnull(AllocQty,0.0) as LocalAVQty
		 FROM dbo.IMS_Subdepot 
		 WHERE DeptNo=@DeptNo) b ON a.ItemID = b.ItemID
)
go

