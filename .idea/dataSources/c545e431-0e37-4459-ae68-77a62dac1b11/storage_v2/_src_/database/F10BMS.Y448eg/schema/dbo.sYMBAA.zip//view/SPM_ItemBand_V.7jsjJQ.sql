CREATE View SPM_ItemBand_V
As
SELECT a.ItemBandNo, a.MemberID, CASE Isnull(d.CHName,'') WHEN '' THEN '所有客户' ELSE d.CHName END AS Member, 
	a.AreaCode, CASE Isnull(e.CHName, '') WHEN '' THEN '所有地区' ELSE e.CHName END AS AreaName, 
       a.CreatorID, f.EmployeeName AS Creator
FROM dbo.SPM_ItemBand a LEFT OUTER JOIN dbo.BDM_MemberCode_V d ON a.MemberID = d.CodeID 
			LEFT OUTER JOIN dbo.BDM_AreaCode_V e ON a.AreaCode = e.CodeID 
			LEFT OUTER JOIN dbo.BDM_Employee f ON a.CreatorID = f.EmployeeID
go

