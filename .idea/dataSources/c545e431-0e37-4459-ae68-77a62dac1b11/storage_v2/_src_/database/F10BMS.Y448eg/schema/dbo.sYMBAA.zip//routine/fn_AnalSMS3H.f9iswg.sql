--说明：分部销售汇总分析
--作者：Devil.H
--创建：2010.08.02
--参数：	
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:分部
--	@Flag :为前台设计
CREATE FUNCTION dbo.fn_AnalSMS3H
(
	@StartDate CHAR(10)='0000-01-01',
	@EndDate CHAR(10)='9999-12-31',
	@WareHouse VARCHAR(20)='',
	@DeptNo VARCHAR(20)='',
	@CustID BIGINT=0,
	@ItemID BIGINT=0,
	@Flag BIT=0
)
RETURNS @uTable TABLE(
	DeptID VARCHAR(20),
	DeptNo VARCHAR(20),
	DeptName VARCHAR(100),
	SelAmt DECIMAL(18,6),
	RetAmt DECIMAL(18,6),
    RealAmt DECIMAL(18,6),            --实际销售额(去掉返点，平台费)
    RebateAmt DECIMAL(18,6),          --返点
    PlatformFee DECIMAL(18,6),        --平台费
	TotalAmt DECIMAL(18,6),
	SelPercent DECIMAL(18,6),
	RetPercent DECIMAL(18,6),
	R_SScale DECIMAL(18,6),
	R_SPercent DECIMAL(18,6),
	DepartId VARCHAR(20),
	DepartName VARCHAR(100)
)
AS
BEGIN
	IF (@Flag=0)
		RETURN;
	DECLARE @SUMAmt DECIMAL(18,6),@SUMRAmt DECIMAL(18,6),@AmtDec INT;
    DECLARE @Tmp TABLE(DeptNo VARCHAR(20),DepartId VARCHAR(20),RetAmt DECIMAL(18,6),SelAmt DECIMAL(18,6),RebateAmt DECIMAL(18,6),PlatformFee DECIMAL(18,6),TotalAmt DECIMAL(18,6));
    --初始化变量
	SET @StartDate=CONVERT(CHAR(10),CAST(@StartDate AS DATETIME),23);
	SET @ENDDate=CONVERT(CHAR(10),CAST(@ENDDate AS DATETIME),23);
    SELECT @AmtDec=ISNULL(AmtDec,2) FROM SYS_Config;
	--获取商品销售数据	
	INSERT INTO @Tmp(DeptNo,DepartId,RetAmt,SelAmt,RebateAmt,PlatformFee,TotalAmt)
	SELECT a.DeptNo,a.DepartId,
		RAmt=Abs(Isnull(Sum(Case a.BillType when '20' then b.Amt else 0.0 end),0.0))
			+abs(isnull(Sum(Case a.BillType when '50' then b.Amt else 0.0 end),0.0)),
		SAmt=isnull(Sum(Case a.BillType when '10' then b.Amt else 0.0 end),0.0)
			+isnull(Sum(Case a.BillType when '30' then b.Amt else 0.0 end),0.0)
			+isnull(Sum(Case a.BillType when '40' then b.Amt else 0.0 end),0.0),
        RebateAmt=ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0),@AmtDec),
        PlatformFee=ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0),@AmtDec),
		TAmt=SUM(b.Amt)
	FROM SMS_Stock a 
        INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
        INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		AND (Convert(CHAR(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate) 
		AND (a.DeptNo Like @DeptNo + '%')
		AND (b.WareHouse Like @WareHouse + '%')	
		AND (a.CustID=@CustID Or @CustID=0)
		AND (b.ItemID=@ItemID Or @ItemID=0)
	GROUP BY a.DeptNo,a.DepartId;
	--获取以上客户的总销售额
	SELECT @SumAmt=Sum(SelAmt),@SumRAmt=Sum(RetAmt) FROM @Tmp;
	--写入表函数
	INSERT INTO @uTable(DeptID,DeptNo,DeptName,SelAmt,RetAmt,RebateAmt,PlatformFee,RealAmt,TotalAmt,SelPercent,
        RetPercent,R_SPercent,R_SScale,DepartId,DepartName)
	SELECT d.CodeID,d.CodeNo,d.CHName,t.SelAmt,t.RetAmt,t.RebateAmt,t.PlatformFee,t.RealAmt,t.TotalAmt,t.SelPercent,
        t.RetPercent,t.R_SPercent,CASE ISNULL(t.SelPercent,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(t.RetPercent,0.0)/t.SelPercent,6) END,
		t.DepartId,dt.CHName
	FROM (SELECT DeptNo,DepartId,SelAmt,RetAmt,TotalAmt,RebateAmt,PlatformFee,
                ISNULL(TotalAmt,0.0)-ISNULL(RebateAmt,0.0)-ISNULL(PlatformFee,0.0) AS RealAmt,
                CASE ISNULL(@SUMAMT,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(SelAmt,0.0)/@SumAmt,6) END AS SelPercent,
                CASE ISNULL(@SumRAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(RetAmt,0.0)/@SumRAmt,6) END AS RetPercent,				
                CASE ISNULL(SelAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(RetAmt,0.0)/SelAmt,6) END AS R_SPercent
          FROM @Tmp) t 
        LEFT JOIN BDM_DeptCode_V d ON t.DeptNo=d.CodeID 
		LEFT JOIN BDM_DeptCode_V dt ON t.DepartId=dt.CodeID
    DELETE FROM @Tmp;
	--返回
	RETURN;
END
go

