
CREATE Proc sp_YZStock_unAudit_
(
	@OrderNo varchar(20),
	@Flag char(2)
)
--取消审核销售订单、调拨申请
--2007-08-11
--Devil.H
--当上述操作发生时：
--更新预占库存数量……

As
Begin
	if @Flag='U1'--取消审核销售订单
		begin
			update T1 set T1.Qty=T1.Qty-T2.yzQty From IMS_YZStock T1,
			(select a.YZStockWareHouseID,b.ItemID,a.CustID,b.RemSQty+b.RemZQty As yzQty from SMS_Order a,SMS_OrderDtl_V b where a.OrderNo=b.OrderNo and a.OrderNo=@OrderNo) T2 
			where T1.ItemID=T2.ItemID And T1.WareHouseID=T2.YZStockWareHouseID and  T1.CustID=T2.CustID  
		End
	if @Flag='U2'--取消审核调拨申请
		begin
			update T1 set T1.Qty=T1.Qty-T2.yzQty From IMS_YZStock T1,
			(select a.YZStockWareHouseID,b.ItemID,a.DeptNo as CustID,b.RemDQty As yzQty from PMS_Order a,PMS_OrderDtl_V b where a.OrderNo=b.OrderNo and a.OrderNo=@OrderNo) T2 
			where T1.ItemID=T2.ItemID And T1.WareHouseID=T2.YZStockWareHouseID and  T1.CustID=T2.CustID  
		End



End
go

