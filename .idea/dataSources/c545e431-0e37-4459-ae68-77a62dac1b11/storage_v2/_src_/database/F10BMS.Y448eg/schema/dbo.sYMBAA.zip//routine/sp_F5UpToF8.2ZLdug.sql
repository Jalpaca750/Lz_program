--F5标准版本升级到F8标准版
--创建日期:2008-05-03
--创建人：Devil.H
Create Proc sp_F5UpToF8(
	@DBName varchar(40)
)
As
Begin
	--禁止触发器
	--销售部分
	Alter Table SMS_Arrearage Disable Trigger All
	Alter Table SMS_StockDtl Disable Trigger All
	Alter Table SMS_ChangeDtl Disable Trigger All
	Alter Table SMS_GatheringDtl Disable Trigger All
	Alter Table SMS_InvoiceDtl Disable Trigger All
	Alter Table SMS_PaymentDtl Disable Trigger All
	Alter Table SMS_RectifyDtl Disable Trigger All
	Alter Table SMS_ReturnDtl Disable Trigger All
	--库存部分
	Alter Table IMS_AllotDtl Disable Trigger All
	Alter Table IMS_InceptDtl Disable Trigger All
	--采购部分
	Alter Table PMS_Arrearage Disable Trigger All
	Alter Table PMS_PlanDtl Disable Trigger All
	Alter Table PMS_OrderDtl Disable Trigger All
	Alter Table PMS_StockDtl Disable Trigger All
	Alter Table PMS_ReturnDtl Disable Trigger All
	Alter Table PMS_RectifyDtl Disable Trigger All
	Alter Table PMS_InvoiceDtl Disable Trigger All
	Alter Table PMS_PaymentDtl Disable Trigger All
	
	Declare @mySQL varchar(2000)
	---------------资料部分升级---------------
	--1.升级基本代码
	Truncate Table BDM_Code
	Set @mySQL='Insert Into BDM_Code(CodeID,CodeNo,CHName,ENName,NameSpell,Classify,Remarks,DeptNo,DeptFlag) '
	Set @mySQL=@mySQL +'Select CodeID,CodeNo,CHName,ENName,NameSpell,Classify,Remarks,DeptNo,DeptFlag '
	Set @mySQL=@mySQL +'From '+@DBName+'.dbo.BDM_Code'
	exec (@mySQL)
	--2.升级员工资料
	Truncate Table BDM_Employee
	Set Identity_Insert BDM_Employee On
	Set @mySQL='Insert Into BDM_Employee(EmployeeID,EmployeeNo,EmployeeName,Sex,Nation,BirthDay,Degree,'
	Set @mySQL=@mySQL +'ELevel,Speciality,Academy,IDCard,Phone,EMail,IDAddr,Addr,DeptCode,JobCode,SignDate,'
	Set @mySQL=@mySQL +'SignYears,BPay,WAge,CurWAge,Flag,Photo,Remarks,ArgAmt,CustFlag,DiscFlag,DiscRate) '
	Set @mySQL=@mySQL +'Select EmployeeID,EmployeeNo,EmployeeName,Sex,Nation,BirthDay,Degree,ELevel,Speciality,'
	Set @mySQL=@mySQL +'Academy,IDCard,Phone,EMail,IDAddr,Addr,DeptCode,JobCode,SignDate,SignYears,BPay,'
	Set @mySQL=@mySQL +'WAge,CurWAge,Flag,Photo,Remarks,ArgAmt,CustFlag,DiscFlag,DiscRate '
	Set @mySQL=@mySQL +'From '+@DBName+'.dbo.BDM_Employee Where EmployeeID>=99'
	exec (@mySQL)
	Set Identity_Insert BDM_Employee Off
	Update BDM_Employee Set Sex=Case Isnull(Sex,'0') When '0' then '女' else '男' End
	--3.升级商品资料
	Truncate Table BDM_ItemInfo
	Set Identity_Insert BDM_ItemInfo On
	Set @mySQL='Insert Into BDM_ItemInfo(ItemID,ItemNo,ItemName,ItemAlias,NameSpell,ItemSpec,BarCode,ClassID,'
	Set @mySQL=@mySQL +'LabelID,ColorName,UnitName,Cubage,Weight,Package,PPrice,SPrice,SPrice1,SPrice2,SPrice3,'
	Set @mySQL=@mySQL +'SafePPrice,SafeSPrice,Integral,Defined1,Defined2,Defined3,Defined4,Defined5,'
	Set @mySQL=@mySQL +'Flag,CreateDate,CreatorID,AmendDate,MenderID,Remarks,PurDays) '
	Set @mySQL=@mySQL +'Select ItemID,ItemNo,ItemName,ItemAlias,NameSpell,ItemSpec,BarCode,ClassID,LabelID,'
	Set @mySQL=@mySQL +'ColorName,UnitName,Cubage,Weight,Package,PPrice,SPrice,SPrice1,SPrice2,SPrice3,'
	Set @mySQL=@mySQL +'SafePPrice,SafeSPrice,Integral,Defined1,Defined2,Defined3,Defined4,Defined5,'
	Set @mySQL=@mySQL +'Case Flag when ''有效'' then ''1'' else ''0'' End,CreateDate,CreatorID,AmendDate,'
	Set @mySQL=@mySQL +'MenderID,Remarks,PurDays From '+@DBName+'.dbo.BDM_ItemInfo_V'
	exec (@mySQL)
	Set Identity_Insert BDM_ItemInfo Off
	--4.升级客户资料
	Truncate Table BDM_Customer
	Set Identity_Insert BDM_Customer On
	Set @mySQL='Insert Into BDM_Customer(CustID,CustNo,CustName,NameSpell,CustAddr,SendAddr,CustType,'
	Set @mySQL=@mySQL +'MemberID,AreaCode,PopedomID,PostalCode,SalesID,DeptNo,Phone,Faxes,EMail,Webs,'
	Set @mySQL=@mySQL +'TradeID,KindID,LegalPerson,BankID,AccountNo,TaxNo,ADays,IDays,ADayFlag,'
	Set @mySQL=@mySQL +'CreditAmt,CreditFlag,Invoice,Finance,FPhone,OutValue,SalesAmt,Persons,'
	Set @mySQL=@mySQL +'CurrencyID,ArgAmt,Integral,Deduct,LinkMan,Sex,Ages,Degree,Loves,DeptName,'
	Set @mySQL=@mySQL +'JobName,PerPhone,Defined1,Defined2,Defined3,Flag,CreatorID,CreateDate,'
	Set @mySQL=@mySQL +'MenderID,AmendDate,Remarks,SendID,SJInteg,PriceFlag) '
	Set @mySQL=@mySQL +'Select CustID,CustNo,CustName,NameSpell,CustAddr,SendAddr,CustType,MemberID,'
	Set @mySQL=@mySQL +'AreaCode,PopedomID,PostalCode,SalesID,DeptNo,Phone,Faxes,EMail,Webs,'
	Set @mySQL=@mySQL +'TradeID,KindID,LegalPerson,BankID,AccountNo,TaxNo,ADays,IDays,ADayFlag,'
	Set @mySQL=@mySQL +'CreditAmt,CreditFlag,Invoice,Finance,FPhone,OutValue,SalesAmt,Persons,'
	Set @mySQL=@mySQL +'CurrencyID,ArgAmt,Integral,Deduct,LinkMan,Sex,Ages,Degree,Loves,DeptName,'
	Set @mySQL=@mySQL +'JobName,PerPhone,Defined1,Defined2,Defined3,Flag,CreatorID,CreateDate,'
	Set @mySQL=@mySQL +'MenderID,AmendDate,Remarks,SendID,SJInteg,PriceFlag From ' + @DBName +'.dbo.BDM_Customer'
	exec (@mySQL)
	Set Identity_Insert BDM_Customer Off
	--送货地址
	Truncate Table BDM_SendAddress
	Set @mySQL='Insert Into BDM_SendAddress(CustID,CustNo,SendAddr,DeptName,LinkMan,Phone,DefAddr) '
	Set @mySQL=@mySQL +'Select CustID,CustNo,SendAddr,DeptName,LinkMan,Phone,DefAddr '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.BDM_SendAddress '
	exec (@mySQL)
	--5.升级供应商资料
	Truncate Table BDM_Vendor
	Set Identity_Insert BDM_Vendor On
	Set @mySQL='Insert Into BDM_Vendor(VendorID,VendorNo,VendorName,NameSpell,VendorAddr,PostalCode,'
	Set @mySQL=@mySQL +'BuyerID,Phone,Faxes,EMail,Webs,TradeID,KindID,SendID,LegalPerson,BankID,'
	Set @mySQL=@mySQL +'AccountNo,TaxNo,ADays,OutValue,SalesAmt,Persons,ArgAmt,CreditAmt,CreditFlag,'
	Set @mySQL=@mySQL +'ADayFlag,LinkMan,Sex,Ages,Degree,DeptName,Loves,PerPhone,Defined1,Defined2,'
	Set @mySQL=@mySQL +'Defined3,Flag,CreatorID,CreateDate,MenderID,AmendDate,Remarks) '
	Set @mySQL=@mySQL +'Select VendorID,VendorNo,VendorName,NameSpell,VendorAddr,PostalCode,BuyerID,'
	Set @mySQL=@mySQL +'Phone,Faxes,EMail,Webs,TradeID,KindID,SendID,LegalPerson,BankID,AccountNo,'
	Set @mySQL=@mySQL +'TaxNo,ADays,OutValue,SalesAmt,Persons,ArgAmt,CreditAmt,CreditFlag,'
	Set @mySQL=@mySQL +'ADayFlag,LinkMan,Sex,Ages,Degree,DeptName,Loves,PerPhone,Defined1,Defined2,'
	Set @mySQL=@mySQL +'Defined3,Flag,CreatorID,CreateDate,MenderID,AmendDate,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.BDM_Vendor'
	exec (@mySQL)
	Set Identity_Insert BDM_Vendor Off
	---------------系统部分升级---------------
	--6.系统参数
	Truncate Table Sys_Config
	Set @mySQL='Insert Into Sys_Config(AccountNo,Version,BuildDate,RYNo,RYUSERID,Licence,SysDate,'
	Set @mySQL=@mySQL +'PriceDec,AmtDec,MinusFlag,ItemAuto,ItemPrefix,IAutoMode,CustAuto,CustPrefix,'
	Set @mySQL=@mySQL +'CAutoMode,VendorAuto,VPrefix,VAutoMode,KJDay,Method) '
	Set @mySQL=@mySQL +'Select ''F8SBQ2008'',Version,BuildDate,RYNo,RYUSERID,Licence,SysDate,'
	Set @mySQL=@mySQL +'PriceDec,AmtDec,MinusFlag,ItemAuto,ItemPrefix,IAutoMode,CustAuto,CustPrefix,'
	Set @mySQL=@mySQL +'CAutoMode,VendorAuto,VPrefix,VAutoMode,KJDay,Method  '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SYS_Config'
	exec (@mySQL)
	--7.公司信息
	Truncate Table SYS_Enterprise
	Set @mySQL='Insert Into SYS_Enterprise(CorpNo,CorpName,CorpPhone,CorpFaxes,CorpAddr,PostalCode,'
	Set @mySQL=@mySQL +'Bank,Accounts,TaxNo,TaxNo1,Corporation,CorpLogo) '
	Set @mySQL=@mySQL +'Select CorpNo,CorpName,CorpPhone,CorpFaxes,CorpAddr,PostalCode,Bank,Accounts,'
	Set @mySQL=@mySQL +'TaxNo,TaxNo1,Corporation,CorpLogo From ' + @DBName +'.dbo.SYS_Enterprise'
	exec (@mySQL)
	--8.公司日志
	Truncate Table Sys_LogFile
	Set @mySQL='Insert Into Sys_LogFile(UserID,ProgNo,OptDesc,OptDate) '
	Set @mySQL=@mySQL +'Select UserID,ProgNo,OptDesc,OptDate '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.Sys_LogFile Order By LogID'
	exec (@mySQL)
	--9.零售设置
	Truncate Table Sys_Retail
	Set @mySQL='Insert Into Sys_Retail(PCNo,MACAddress,DeptNo,CustID,WareHouse) '
	Set @mySQL=@mySQL +'Select PCNo,MACAddress,DeptNo,CustID,WareHouse '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.Sys_Retail'
	exec (@mySQL)
	--10.操作员
	Truncate Table SAM_Operator
	Set @mySQL='Insert Into SAM_Operator(EmployeeID,EmployeePsd,PCName,PCID,TeamNo,OnLine,LogIn,LogOut,Notes) '
	Set @mySQL=@mySQL +'Select EmployeeID,EmployeePsd,PCName,PCID,TeamNo,0,LogIn,LogOut,Notes '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SAM_Operator Where EmployeeID>10'
	exec (@mySQL)
	--11.分组
	Truncate Table SAM_Team
	Set @mySQL='Insert Into SAM_Team(TeamNo,TeamName,TeamDesc) '
	Set @mySQL=@mySQL +'Select TeamNo,TeamName,TeamDesc '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SAM_Team'
	exec (@mySQL)
	--12.查询分析授权
	Truncate Table RPT_Power
	Set @mySQL='Insert Into RPT_Power(UserID,EmployeeID) '
	Set @mySQL=@mySQL +'Select UserID,EmployeeID '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.RPT_Power'
	exec (@mySQL)
	--13.组权限
	Delete From SAM_TPower Where Not TeamNo='Admin'
	Set @mySQL='Insert Into SAM_TPower(TeamNo,Menu,IsImpower,IsAdd,IsQuery,IsModify,IsDeleted,IsCheck,IsUncheck,'
	Set @mySQL=@mySQL +'IsSetting,IsPrint,IsExport) Select a.TeamNo,b.Menu,a.IsImpower,a.IsAdd,a.IsQuery,a.IsModify,'
	Set @mySQL=@mySQL +'a.IsDeleted,a.IsCheck,a.IsUncheck,a.IsSetting,a.IsPrint,a.IsExport '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SAM_TPower a inner join SAM_Menu b On a.Menu=b.OldMenu '
	Set @mySQL=@mySQL +'Where Not a.TeamNo=''Admin'''
	exec (@mySQL)
	--14.用户权限
	Delete From SAM_Power Where Not EmployeeID=99
	Set @mySQL='Insert Into SAM_Power(EmployeeID,Menu,IsImpower,IsAdd,IsQuery,IsModify,IsDeleted,IsCheck,IsUncheck,'
	Set @mySQL=@mySQL +'IsSetting,IsPrint,IsExport) Select a.EmployeeID,b.Menu,a.IsImpower,a.IsAdd,a.IsQuery,a.IsModify,'
	Set @mySQL=@mySQL +'a.IsDeleted,a.IsCheck,a.IsUncheck,a.IsSetting,a.IsPrint,a.IsExport '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SAM_Power a inner join SAM_Menu b On a.Menu=b.OldMenu '
	Set @mySQL=@mySQL +'Where Not a.EmployeeID=99'
	exec (@mySQL)
	---------------促销部分升级---------------
	--15.按金额赠送设置
	Truncate Table SPM_AmtLargess
	Set @mySQL='Insert Into SPM_AmtLargess(LargessNo,StartDate,EndDate,MemberID,AreaCode,ClassID,LabelID,ItemID,CreatorID) '
	Set @mySQL=@mySQL +'Select LargessNo,StartDate,EndDate,MemberID,AreaCode,ClassID,LabelID,ItemID,CreatorID ' 
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SPM_AmtLargess'
	exec (@mySQL)
	Truncate Table SPM_AmtLargessDtl
	Set @mySQL='Insert Into SPM_AmtLargessDtl(LargessNo,SaleRoom,ItemID,ZQty,EndQty) '
	Set @mySQL=@mySQL +'Select LargessNo,SaleRoom,ItemID,ZQty,EndQty '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SPM_AmtLargessDtl'
	exec (@mySQL)
	--16.按积分赠送设置
	Truncate Table SPM_IntegLargess
	Set @mySQL='Insert Into SPM_IntegLargess(Integral,ItemID,ZQty,EndQty) '
	Set @mySQL=@mySQL +'Select Integral,ItemID,ZQty,EndQty '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SPM_IntegLargess'
	exec (@mySQL)
	--17.按积分赠送设置
	Truncate Table SPM_Integral
	Set @mySQL='Insert Into SPM_Integral(MemberID,AreaCode,IntegAmt,Integral,CreateDate,AmendDate) '
	Set @mySQL=@mySQL +'Select MemberID,AreaCode,IntegAmt,Integral,CreateDate,AmendDate '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SPM_Integral'
	exec (@mySQL)
	--18.设置会员价
	Truncate Table SPM_Price
	Set @mySQL='Insert Into SPM_Price(MemberID,ItemID,MPrice,SafeSPrice) '
	Set @mySQL=@mySQL +'Select MemberID,ItemID,MPrice,SafeSPrice '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SPM_Price'
	exec (@mySQL)
	--19.按数量设置赠品
	Truncate Table SPM_QtyLargess
	Set @mySQL='Insert Into SPM_QtyLargess(LargessNo,StartDate,EndDate,MemberID,AreaCode,ItemID,CreatorID) '
	Set @mySQL=@mySQL +'Select LargessNo,StartDate,EndDate,MemberID,AreaCode,ItemID,CreatorID '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SPM_QtyLargess'
	exec (@mySQL)
	Truncate Table SPM_QtyLargessDtl
	Set @mySQL='Insert Into SPM_QtyLargessDtl(LargessNo,OQty,ItemID,ZQty,EndQty) '
	Set @mySQL=@mySQL +'Select LargessNo,OQty,ItemID,ZQty,EndQty '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SPM_QtyLargessDtl'
	exec (@mySQL)
	---------------销售部分升级---------------
	--20.客户期初欠款
	Truncate Table SMS_Arrearage
	Set @mySQL='Insert Into SMS_Arrearage(CustID,DeptNo,Amt,Remarks) '
	Set @mySQL=@mySQL +'Select CustID,DeptNo,Amt,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Arrearage'
	exec (@mySQL)
	--21.营业员欠款
	Truncate Table SMS_Change
	Truncate Table SMS_ChangeDtl
	Set Identity_Insert SMS_ChangeDtl On
	Set @mySQL='Insert Into SMS_Change(ChangeNo,CreateDate,DeptNo,BillSts,CreatorID,Remarks) '
	Set @mySQL=@mySQL +'Select ChangeNo,CreateDate,DeptNo,BillSts,CreatorID,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Change'
	exec (@mySQL)
	Set @mySQL='Insert Into SMS_ChangeDtl(ChangeID,ChangeNo,EmployeeID,ChangeAmt,InkName,Remark) '
	Set @mySQL=@mySQL +'Select ChangeID,ChangeNo,EmployeeID,ChangeAmt,InkName,Remark '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_ChangeDtl'
	exec (@mySQL)
	Set Identity_Insert SMS_ChangeDtl Off
	--22.营业员交款管理
	Truncate Table SMS_Gathering
	Truncate Table SMS_GatheringDtl
	Set Identity_Insert SMS_GatheringDtl On
	Set @mySQL='Insert Into SMS_Gathering(GatheringNo,CreateDate,DeptNo,SalesID,BillSts,PayFlag,AuditID,'
	Set @mySQL=@mySQL +'AuditDate,PFlag,CreatorID,Remarks) '
	Set @mySQL=@mySQL +'Select GatheringNo,CreateDate,DeptNo,SalesID,BillSts,PayFlag,AuditID,AuditDate,'
	Set @mySQL=@mySQL +'PFlag,CreatorID,Remarks From ' + @DBName +'.dbo.SMS_Gathering'
	exec (@mySQL)
	Set @mySQL='Insert Into SMS_GatheringDtl(GatheringID,GatheringNo,ShiftNo,PCNo,RestAmt,Amt,PAmt,'
	Set @mySQL=@mySQL +'PayAmt,LAmt,SAmt,Remark) '
	Set @mySQL=@mySQL +'Select GatheringID,GatheringNo,ShiftNo,PCNo,RestAmt,Amt,PAmt,PayAmt,LAmt,SAmt,Remark '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_GatheringDtl'
	exec (@mySQL)
	Set Identity_Insert SMS_GatheringDtl Off
	--23.销售发票
	Truncate Table SMS_Invoice
	Truncate Table SMS_InvoiceDtl
	Set Identity_Insert SMS_Invoice On
	Set @mySQL='Insert Into SMS_Invoice(InvoiceID,InvoiceNo,DeptNo,CreateDate,CustID,IType,Invoice,PayMode,'
	Set @mySQL=@mySQL +'IAmt,DAmt,PAmt,BillSts,CreatorID,AuditDate,Remarks,PFlag,PDate,CAmt,SalesID,'
	Set @mySQL=@mySQL +'AuditID,BackDate,Integral) '
	Set @mySQL=@mySQL +'Select InvoiceID,InvoiceNo,DeptNo,CreateDate,CustID,IType,Invoice,PayMode,'
	Set @mySQL=@mySQL +'IAmt,DAmt,PAmt,BillSts,CreatorID,AuditDate,Remarks,PFlag,PDate,CAmt,SalesID,'
	Set @mySQL=@mySQL +'AuditID,BackDate,Integral '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Invoice'
	exec (@mySQL)
	Set Identity_Insert SMS_Invoice Off
	Set Identity_Insert SMS_InvoiceDtl On
	Set @mySQL='Insert Into SMS_InvoiceDtl(InvoiceID,InvoiceNo,StockID,ItemID,IQty,Price,Amt,Remarks,'
	Set @mySQL=@mySQL +'CPrice,PaidAmt) Select InvoiceID,InvoiceNo,StockID,ItemID,IQty,Price,Amt,'
	Set @mySQL=@mySQL +'Remarks,CPrice,PaidAmt From ' + @DBName +'.dbo.SMS_InvoiceDtl'
	exec (@mySQL)
	Set Identity_Insert SMS_InvoiceDtl Off
	--24.销售订单
	Truncate Table SMS_Order
	Truncate Table SMS_OrderDtl
	Set @mySQL='Insert Into SMS_Order(OrderNo,CreateDate,CustID,SendDate,SendAddr,DeptNo,SendID,'
	Set @mySQL=@mySQL +'SendFlag,BillSts,CreatorID,Remarks,PFlag,SendTime,SalesID,SourceFlag) '
	Set @mySQL=@mySQL +'Select OrderNo,CreateDate,CustID,SendDate,SendAddr,DeptNo,SendID,SendFlag,'
	Set @mySQL=@mySQL +'BillSts,CreatorID,Remarks,PFlag,SendTime,SalesID,SourceFlag '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Order'
	exec (@mySQL)
	Set Identity_Insert SMS_OrderDtl On
	Set @mySQL='Insert Into SMS_OrderDtl(OrderID,DeptNo,OrderNo,ItemID,OQty,Price,Amt,ZQty,'
	Set @mySQL=@mySQL +'PresentNo,SQty,SZQty,Remarks) Select OrderID,DeptNo,OrderNo,ItemID,OQty,'
	Set @mySQL=@mySQL +'Price,Amt,ZQty,PresentNo,SQty,SZQty,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_OrderDtl'
	exec (@mySQL)
	Set Identity_Insert SMS_OrderDtl Off
	--25.销售付款
	Truncate Table SMS_Payment
	Truncate Table SMS_PaymentDtl
	Set @mySQL='Insert Into SMS_Payment(PaymentNo,CreateDate,DeptNo,CustID,Credence,PayMode,BankID,'
	Set @mySQL=@mySQL +'Amt,BillSts,CreatorID,AuditDate,AuditID,Remarks,PFlag,SalesID) '
	Set @mySQL=@mySQL +'Select PaymentNo,CreateDate,DeptNo,CustID,Credence,PayMode,BankID,Amt,BillSts,'
	Set @mySQL=@mySQL +'CreatorID,AuditDate,AuditID,Remarks,PFlag,SalesID '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Payment'
	exec (@mySQL)
	Set @mySQL='Insert Into SMS_PaymentDtl(PayMentNo,InvoiceID,Invoice,IAmt,DAmt,FAmt,PayAmt,Remarks) '
	Set @mySQL=@mySQL +'Select PayMentNo,InvoiceID,Invoice,IAmt,DAmt,FAmt,PayAmt,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_PaymentDtl'
	exec (@mySQL)
	--25.客户销售价格
	Truncate Table SMS_Price
	Set @mySQL='Insert Into SMS_Price(CustID,ItemID,Price,MPrice) Select CustID,ItemID,Price,MPrice '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Price Order By CustID,ItemID'
	exec (@mySQL)
	--26.销售报价单
	Truncate Table SMS_Quote
	Truncate Table SMS_QuoteDtl
	Set @mySQL='Insert Into SMS_Quote(BillNo,CreateDate,DeptNo,CustID,BillSts,QuoteType,DisCount,' 
	Set @mySQL=@mySQL +'CreatorID,AuditDate,AuditID,Remarks,PFlag,SalesID) '
	Set @mySQL=@mySQL +'Select BillNo,CreateDate,DeptNo,CustID,BillSts,QuoteType,DisCount,CreatorID,'
	Set @mySQL=@mySQL +'AuditDate,AuditID,Remarks,PFlag,SalesID '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Quote '
	exec (@mySQL)
	Set @mySQL='Insert Into SMS_QuoteDtl(BillNo,DeptNo,ItemID,Qty,Price,MPrice,Remarks) '
	Set @mySQL=@mySQL +'Select BillNo,DeptNo,ItemID,Qty,Price,MPrice,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_QuoteDtl'
	exec (@mySQL)
	--27.销售调价单
	Truncate Table SMS_Rectify
	Truncate Table SMS_RectifyDtl
	Set @mySQL='Insert Into SMS_Rectify(RectifyNo,CreateDate,DeptNo,CustID,Effect,SendAddr,BillSts,'
	Set @mySQL=@mySQL +'CreatorID,AuditDate,AuditID,Remarks,PFlag,SalesID) '
	Set @mySQL=@mySQL +'Select RectifyNo,CreateDate,DeptNo,CustID,Effect,SendAddr,BillSts,CreatorID,'
	Set @mySQL=@mySQL +'AuditDate,AuditID,Remarks,PFlag,SalesID '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Rectify '
	exec (@mySQL)
	Set @mySQL='Insert Into SMS_RectifyDtl(RectifyNo,StockID,ItemID,RemRQty,MQty,Price,MPrice,Amt,Remarks) '
	Set @mySQL=@mySQL +'Select RectifyNo,StockID,ItemID,RemRQty,MQty,Price,MPrice,Amt,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_RectifyDtl '
	exec (@mySQL)
	--28.销售退货单
	Truncate Table SMS_Return
	Truncate Table SMS_ReturnDtl
	Set @mySQL='Insert Into SMS_Return(ReturnNo,CreateDate,DeptNo,WareHouse,CustID,Forcible,SendAddr,'
	Set @mySQL=@mySQL +'BillSts,CreatorID,AuditDate,AUditID,Remarks,PFlag,Integral,SalesID) '
	Set @mySQL=@mySQL +'Select ReturnNo,CreateDate,DeptNo,WareHouse,CustID,Forcible,SendAddr,BillSts,'
	Set @mySQL=@mySQL +'CreatorID,AuditDate,AUditID,Remarks,PFlag,Integral,SalesID '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Return'
	exec (@mySQL)
	Set @mySQL='Insert Into SMS_ReturnDtl(ReturnNo,StockID,WareHouse,ItemID,Location,RQty,Price,Amt,ZQty,Remarks) '
	Set @mySQL=@mySQL +'Select ReturnNo,StockID,WareHouse,ItemID,Location,RQty,Price,Amt,ZQty,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_ReturnDtl'
	exec (@mySQL)
	--29.零售单
	Truncate Table SMS_Retail
	Truncate Table SMS_RetailDtl
	Set @mySQL='Insert Into SMS_Retail(RetailNo,CreateDate,DeptNo,WareHouse,CustID,BillSts,BillType,CashFlag,'
	Set @mySQL=@mySQL +'Invoice,CreatorID,AuditDate,AuditID,PFlag,Remarks,DiscRate,'
	Set @mySQL=@mySQL +'CreateTime,PCNo,DiscAmt,FFlag,SalesID,Integral) '
	Set @mySQL=@mySQL +'Select RetailNo,CreateDate,DeptNo,WareHouse,CustID,BillSts,BillType,CashFlag,'
	Set @mySQL=@mySQL +'Invoice,CreatorID,AuditDate,AuditID,PFlag,Remarks,Isnull(Discount,0)*100,'
	Set @mySQL=@mySQL +'CreateTime,PCNo,DiscAmt,FFlag,SalesID,Integral '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Retail'
	exec (@mySQL)
	Set @mySQL='Insert Into SMS_RetailDtl(RetailNo,WareHouse,ItemID,SQty,Price,Amt,ZQty,Remarks,'
	Set @mySQL=@mySQL +'Location,DiscRate,SPrice,DeptNo,SafeSPrice)'
	Set @mySQL=@mySQL +'Select RetailNo,WareHouse,ItemID,SQty,Price,Amt,ZQty,Remarks,Location,'
	Set @mySQL=@mySQL +'Isnull(Discount,0)*100 ,SPrice,DeptNo,SafeSPrice '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_RetailDtl '
	exec (@mySQL)
	--30.交班单
	Truncate Table SMS_Shift
	Truncate Table SMS_ShiftDtl
	Set @mySQL='Insert Into SMS_Shift(ShiftNo,DeptNo,PCNo,CreateDate,CreatorID,LstDate,LstTime,'
	Set @mySQL=@mySQL +'PrintDate,RestAmt,XSAmt,MSAmt,Amt,PAmt,RemAmt,ReceiverID,BillSts,Remarks) '
	Set @mySQL=@mySQL +'Select ShiftNo,DeptNo,PCNo,CreateDate,CreatorID,LstDate,LstTime,PrintDate,'
	Set @mySQL=@mySQL +'RestAmt,XSAmt,MSAmt,Amt,PAmt,RemAmt,ReceiverID,BillSts,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Shift'
	exec (@mySQL)
	Set @mySQL='Insert Into SMS_ShiftDtl(ShiftNo,CashFlag,Amt,DiscAmt,Remark) '
	Set @mySQL=@mySQL +'Select ShiftNo,CashFlag,Amt,DiscAmt,Remark '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_ShiftDtl '
	exec (@mySQL)
	--31.销售出库单
	Truncate Table SMS_Stock
	Truncate Table SMS_StockDtl
	Set Identity_Insert SMS_StockDtl On
	Set @mySQL='Insert Into SMS_Stock(StockNo,CreateDate,DeptNo,WareHouse,CustID,BillType,SendAddr,'
	Set @mySQL=@mySQL +'SendID,SendDate,SendTime,BillSts,BackDate,Delivery,PaidDate,PaidUp,PaidAmt,'
	Set @mySQL=@mySQL +'DiscAmt,SalesID,AuditDate,AuditID,Integral,CreatorID,PFlag,Remarks) '
	Set @mySQL=@mySQL +'Select StockNo,CreateDate,DeptNo,WareHouse,CustID,BillType,SendAddr,SendID,'
	Set @mySQL=@mySQL +'SendDate,SendTime,BillSts,BackDate,Delivery,PaidDate,PaidUp,PaidAmt,'
	Set @mySQL=@mySQL +'DiscAmt,SalesID,AuditDate,AuditID,Integral,CreatorID,PFlag,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_Stock'
	exec (@mySQL)
	Set @mySQL='Insert Into SMS_StockDtl(StockID,StockNo,OrderID,WareHouse,ItemID,Location,SQty,Price,'
	Set @mySQL=@mySQL +'Amt,ZQty,IQty,IAmt,RQty,RZQty,Remarks,CPrice,PaidAMt,PAmt) '
	Set @mySQL=@mySQL +'Select StockID,StockNo,OrderID,WareHouse,ItemID,Location,SQty,Price,Amt,ZQty,'
	Set @mySQL=@mySQL +'IQty,IAmt,RQty,RZQty,Remarks,CPrice,PaidAMt,PAmt '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.SMS_StockDtl '
	exec (@mySQL)
	Set Identity_Insert SMS_StockDtl Off
	---------------库存部分升级---------------
	--32.调拨出库单
	Truncate Table IMS_Allot
	Truncate Table IMS_AllotDtl
	Set Identity_Insert IMS_AllotDtl On
	Set @mySQL='Insert Into IMS_Allot(AllotNo,CreateDate,DeptNo,WareHouse,DeptNo_I,BillSts,'
	Set @mySQL=@mySQL +'CreatorID,AuditDate,AuditID,PFlag,Remarks) '
	Set @mySQL=@mySQL +'Select AllotNo,CreateDate,DeptNo,WareHouse,DeptNo_I,BillSts,CreatorID,'
	Set @mySQL=@mySQL +'AuditDate,AuditID,PFlag,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_Allot'
	exec (@mySQL)
	Set @mySQL='Insert Into IMS_AllotDtl(AllotID,AllotNo,OrderID,WareHouse,Location,ItemID,SQty,Price,Amt,IQty,Remarks) '
	Set @mySQL=@mySQL +'Select AllotID,AllotNo,OrderID,WareHouse,Location,ItemID,SQty,Price,Amt,IQty,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_AllotDtl '
	exec (@mySQL)
	Set Identity_Insert IMS_AllotDtl Off
	--33.调拨入库单
	Truncate Table IMS_Incept
	Truncate Table IMS_InceptDtl
	Set Identity_Insert IMS_InceptDtl On
	Set @mySQL='Insert Into IMS_Incept(InceptNo,CreateDate,DeptNo,WareHouse,BillSts,CreatorID,'
	Set @mySQL=@mySQL +'AuditDate,AuditID,PFlag,Remarks) '
	Set @mySQL=@mySQL +'Select InceptNo,CreateDate,DeptNo,WareHouse,BillSts,CreatorID,AuditDate,'
	Set @mySQL=@mySQL +'AuditID,PFlag,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_Incept'
	exec (@mySQL)
	Set @mySQL='Insert Into IMS_InceptDtl(InceptID,InceptNo,AllotID,Location,WareHouse,ItemID,'
	Set @mySQL=@mySQL +'IQty,Price,Amt,Remarks) '
	Set @mySQL=@mySQL +'Select InceptID,InceptNo,AllotID,Location,WareHouse,ItemID,IQty,Price,Amt,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_InceptDtl '
	exec (@mySQL)
	Set Identity_Insert IMS_InceptDtl Off
	--34.盘点盈亏分析表
	Truncate Table IMS_Audit
	Set @mySQL='Insert Into IMS_Audit(LotNo,CreateDate,DeptNo,WareHouse,ItemID,OnHandQty,SQty,ActQty,Locked) '
	Set @mySQL=@mySQL +'Select LotNo,CreateDate,DeptNo,WareHouse,ItemID,OnHandQty,SQty,ActQty,Locked '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_Audit'
	exec (@mySQL)
	--35.盘点单
	Truncate Table IMS_Check
	Truncate Table IMS_CheckDtl
	Set @mySQL='Insert Into IMS_Check(CheckNo,CreateDate,DeptNo,WareHouse,LotNo,BillSts,CreatorID,'
	Set @mySQL=@mySQL +'AuditDate,AuditID,Remarks,PFlag) '
	Set @mySQL=@mySQL +'Select CheckNo,CreateDate,DeptNo,WareHouse,LotNo,BillSts,CreatorID,AuditDate,'
	Set @mySQL=@mySQL +'AuditID,Remarks,PFlag '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_Check'
	exec (@mySQL)
	Set @mySQL='Insert Into IMS_CheckDtl(CheckNo,LotNo,WareHouse,Location,ItemID,CurQty,SQty,Price,Amt,Remarks) '
	Set @mySQL=@mySQL +'Select CheckNo,LotNo,WareHouse,Location,ItemID,CurQty,SQty,Price,Amt,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_CheckDtl Order By CheckID'
	exec (@mySQL)
	--36.流水账
	Truncate Table IMS_Flow
	Set @mySQL='Insert Into IMS_Flow(BillNo,DeptNo,WareHouse,CreateDate,BillType,AuditDate,ItemID,SQty,Price,Amt) '
	Set @mySQL=@mySQL +'Select BillNo,DeptNo,WareHouse,CreateDate,BillType,AuditDate,ItemID,SQty,Price,Amt '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_Flow Order By BillNo,FlowID'
	exec (@mySQL)
	--37.库房总帐
	Truncate Table IMS_Ledger
	Set @mySQL='Insert Into IMS_Ledger(WareHouse,ItemID,Location,Price,Amt,LastIDate,LastIPrice,'
	Set @mySQL=@mySQL +'LastODate,LastOPrice,DeptNo) '
	Set @mySQL=@mySQL +'Select WareHouse,ItemID,Location,Price,Amt,LastIDate,LastIPrice,'
	Set @mySQL=@mySQL +'LastODate,LastOPrice,DeptNo '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_Ledger Order By WareHouse,ItemID'
	exec (@mySQL)
	--38.其他入出库单
	Truncate Table IMS_Other
	Truncate Table IMS_OtherDtl
	Set @mySQL='Insert Into IMS_Other(OtherNo,CreateDate,DeptNo,WareHouse,BillType,IOObject,CustID,'
	Set @mySQL=@mySQL +'EmployeeID,VendorID,BillSts,CreatorID,AuditDate,AuditID,Remarks,PFlag) '
	Set @mySQL=@mySQL +'Select OtherNo,CreateDate,DeptNo,WareHouse,BillType,IOObject,CustID,'
	Set @mySQL=@mySQL +'EmployeeID,VendorID,BillSts,CreatorID,AuditDate,AuditID,Remarks,PFlag '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_Other'
	exec (@mySQL)
	Set @mySQL='Insert Into IMS_OtherDtl(OtherNo,WareHouse,ItemID,Location,SQty,Price,Amt,Remarks) '
	Set @mySQL=@mySQL +'Select OtherNo,WareHouse,ItemID,Location,SQty,Price,Amt,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_OtherDtl Order By OtherID'
	exec (@mySQL)
	--39.赠品入出库单
	Truncate Table IMS_Present
	Truncate Table IMS_PresentDtl
	Set @mySQL='Insert Into IMS_Present(PresentNo,CreateDate,DeptNo,WareHouse,BillType,CustID,'
	Set @mySQL=@mySQL +'VendorID,BillSts,IntegFlag,CreatorID,AuditDate,AuditID,Remarks,PFlag) '
	Set @mySQL=@mySQL +'Select PresentNo,CreateDate,DeptNo,WareHouse,BillType,CustID,VendorID,'
	Set @mySQL=@mySQL +'BillSts,IntegFlag,CreatorID,AuditDate,AuditID,Remarks,PFlag '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_Present'
	exec (@mySQL)
	Set @mySQL='Insert Into IMS_PresentDtl(PresentNo,WareHouse,Location,ItemID,Integral,SQty,'
	Set @mySQL=@mySQL +'Price,Amt,CPrice,Remarks) '
	Set @mySQL=@mySQL +'Select PresentNo,WareHouse,Location,ItemID,Integral,SQty,Price,Amt,CPrice,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_PresentDtl Order By PresentNo,PresentID'
	exec (@mySQL)
	--40.库存调价单
	Truncate Table IMS_Rectify
	Truncate Table IMS_RectifyDtl
	Set @mySQL='Insert Into IMS_Rectify(RectifyNo,CreateDate,DeptNo,BillSts,CreatorID,'
	Set @mySQL=@mySQL +'AuditID,AuditDate,PFlag,Remarks) '
	Set @mySQL=@mySQL +'Select RectifyNo,CreateDate,DeptNo,BillSts,CreatorID,AuditID,'
	Set @mySQL=@mySQL +'AuditDate,PFlag,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_Rectify'
	exec (@mySQL)
	Set @mySQL='Insert Into IMS_RectifyDtl(RectifyNo,DeptNo,ItemID,OnHandQty,Price,MPrice,Amt,Remarks) '
	Set @mySQL=@mySQL +'Select RectifyNo,DeptNo,ItemID,OnHandQty,Price,MPrice,Amt,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_RectifyDtl Order By RectifyNo,RectifyID '
	exec (@mySQL)
	--41.分部库存
	Truncate Table IMS_Subdepot
	Set @mySQL='Insert Into IMS_Subdepot(DeptNo,ItemID,Location,Price,PPrice,SPrice,SPrice1,'
	Set @mySQL=@mySQL +'SPrice2,SPrice3,RPrice,SafePPrice,SafeSPrice,VendorID,MaxHive,MinHive,'
	Set @mySQL=@mySQL +'SafetyDays,MaxStock,MinStock,Stability) '
	Set @mySQL=@mySQL +'Select DeptNo,ItemID,Location,Price,PPrice,SPrice,SPrice1,SPrice2,SPrice3,'
	Set @mySQL=@mySQL +'RPrice,SafePPrice,SafeSPrice,VendorID,MaxHive,MinHive,SafetyDays,MaxStock,'
	Set @mySQL=@mySQL +'MinStock,Stability  '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_Subdepot Order By DeptNo,ItemID'
	exec (@mySQL)
	--42.移仓单
	Truncate Table IMS_Transfer
	Truncate Table IMS_TransferDtl
	Set @mySQL='Insert Into IMS_Transfer(TransferNo,CreateDate,DeptNo,WareHouse_O,WareHouse_I,'
	Set @mySQL=@mySQL +'BillSts,CreatorID,AuditDate,AuditID,Remarks,PFlag) '
	Set @mySQL=@mySQL +'Select TransferNo,CreateDate,DeptNo,WareHouse_O,WareHouse_I,BillSts,'
	Set @mySQL=@mySQL +'CreatorID,AuditDate,AuditID,Remarks,PFlag '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_Transfer'
	exec (@mySQL)
	Set @mySQL='Insert Into IMS_TransferDtl(TransferNo,WareHouse_O,ItemID,TQty,Price,Amt,Remarks) '
	Set @mySQL=@mySQL +'Select TransferNo,WareHouse_O,ItemID,TQty,Price,Amt,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName +'.dbo.IMS_TransferDtl Order By TransferNo,TransferID'
	exec (@mySQL)
	
	
	---------------采购部分升级---------------
	--43.供应商期初欠款
	Truncate Table PMS_Arrearage
	Set @mySQL='Insert Into PMS_Arrearage(VendorID,DeptNo,Amt,Remarks) '
	Set @mySQL=@mySQL +'Select VendorID,DeptNo,Amt,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_Arrearage'
	exec (@mySQL)
	--43.采购价格设置表
	Truncate Table PMS_Price
	Set @mySQL='Insert Into PMS_Price(DeptNo,VendorID,ItemID,Price,DefVendor,TaxFlag) '
	Set @mySQL=@mySQL +'Select DeptNo,VendorID,ItemID,Price,DefVendor,TaxFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_Price Order By DeptNo,VendorID,ItemID'
	exec (@mySQL)
	--44.采购询价单
	Truncate Table PMS_Quote
	Truncate Table PMS_QuoteDtl
	Set @mySQL='Insert Into PMS_Quote(BillNo,VendorID,DeptNo,BillSts,CreateDate,'
	Set @mySQL=@mySQL +'CreatorID,AuditID,AuditDate,Remarks,PFlag) '
	Set @mySQL=@mySQL +'Select BillNo,VendorID,DeptNo,BillSts,CreateDate,CreatorID,'
	Set @mySQL=@mySQL +'AuditID,AuditDate,Remarks,PFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_Quote'
	exec (@mySQL)
	Set @mySQL='Insert Into PMS_QuoteDtl(BillNo,ItemID,Qty,Price,Amt,Priority,Remarks,TaxFlag) '
	Set @mySQL=@mySQL +'Select BillNo,ItemID,Qty,Price,Amt,Priority,Remarks,TaxFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_QuoteDtl Order By BillNo,BillID'
	exec (@mySQL)
	--44.采购计划单
	Truncate Table PMS_Plan
	Truncate Table PMS_PlanDtl
	Set Identity_Insert PMS_PlanDtl On
	Set @mySQL='Insert Into PMS_Plan(PlanNo,CreateDate,DeptNo,VDeptNo,BillSts,CreatorID,PFlag,Remarks) '
	Set @mySQL=@mySQL +'Select PlanNo,CreateDate,DeptNo,VDeptNo,BillSts,CreatorID,PFlag,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_Plan'
	exec (@mySQL)
	Set @mySQL='Insert Into PMS_PlanDtl(PlanID,PlanNo,DeptNo,ItemID,PQty,Price,Amt,VendorID,'
	Set @mySQL=@mySQL +'OQty,Remarks,TaxFlag) '
	Set @mySQL=@mySQL +'Select PlanID,PlanNo,DeptNo,ItemID,PQty,Price,Amt,VendorID,OQty,Remarks,TaxFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_PlanDtl'
	exec (@mySQL)
	Set Identity_Insert PMS_PlanDtl Off
	--45.采购订单
	Truncate Table PMS_Order
	Truncate Table PMS_OrderDtl
	Set Identity_Insert PMS_OrderDtl On
	Set @mySQL='Insert Into PMS_Order(OrderNo,CreateDate,DeptNo,VendorID,DeptNo_A,SendDate,BillType,'
	Set @mySQL=@mySQL +'BillSts,CreatorID,Remarks,PFlag) '
	Set @mySQL=@mySQL +'Select OrderNo,CreateDate,DeptNo,VendorID,DeptNo_A,SendDate,BillType,'
	Set @mySQL=@mySQL +'BillSts,CreatorID,Remarks,PFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_Order'
	exec (@mySQL)
	Set @mySQL='Insert Into PMS_OrderDtl(OrderID,OrderNo,DeptNo,PlanID,ItemID,OQty,Price,Amt,SQty,DQty,'
	Set @mySQL=@mySQL +'Remarks,TaxFlag,DeptNo_A) '
	Set @mySQL=@mySQL +'Select OrderID,OrderNo,DeptNo,PlanID,ItemID,OQty,Price,Amt,SQty,DQty,'
	Set @mySQL=@mySQL +'Remarks,TaxFlag,DeptNo_A '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_OrderDtl'
	exec (@mySQL)
	Set Identity_Insert PMS_OrderDtl Off
	--46.采购入库单
	Truncate Table PMS_Stock
	Truncate Table PMS_StockDtl
	Set Identity_Insert PMS_StockDtl On
	Set @mySQL='Insert Into PMS_Stock(StockNo,CreateDate,DeptNo,WareHouse,VendorID,SendNo,'
	Set @mySQL=@mySQL +'BillType,BillSts,CreatorID,AuditDate,AuditID,Remarks,PFlag) '
	Set @mySQL=@mySQL +'Select StockNo,CreateDate,DeptNo,WareHouse,VendorID,SendNo,' 
	Set @mySQL=@mySQL +'BillType,BillSts,CreatorID,AuditDate,AuditID,Remarks,PFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_Stock'
	exec (@mySQL)
	Set @mySQL='Insert Into PMS_StockDtl(StockID,StockNo,WareHouse,Location,OrderID,ItemID,SQty,'
	Set @mySQL=@mySQL +'Price,Amt,IQty,IAmt,RQty,Remarks,TaxFlag) '
	Set @mySQL=@mySQL +'Select StockID,StockNo,WareHouse,Location,OrderID,ItemID,SQty,'
	Set @mySQL=@mySQL +'Price,Amt,IQty,IAmt,RQty,Remarks,TaxFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_StockDtl'
	exec (@mySQL)
	Set Identity_Insert PMS_StockDtl Off
	--47.采购退货单
	Truncate Table PMS_Return
	Truncate Table PMS_ReturnDtl
	Set @mySQL='Insert Into PMS_Return(ReturnNo,CreateDate,DeptNo,WareHouse,VendorID,'
	Set @mySQL=@mySQL +'BillSts,Forcible,CreatorID,AuditDate,AuditID,PFlag,Remarks) '
	Set @mySQL=@mySQL +'Select ReturnNo,CreateDate,DeptNo,WareHouse,VendorID,BillSts,'
	Set @mySQL=@mySQL +'Forcible,CreatorID,AuditDate,AuditID,PFlag,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_Return'
	exec (@mySQL)
	Set @mySQL='Insert Into PMS_ReturnDtl(ReturnNo,StockID,WareHouse,ItemID,Location,'
	Set @mySQL=@mySQL +'RQty,Price,Amt,Remarks,TaxFlag) '
	Set @mySQL=@mySQL +'Select ReturnNo,StockID,WareHouse,ItemID,Location,RQty,Price,'
	Set @mySQL=@mySQL +'Amt,Remarks,TaxFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_ReturnDtl Order By ReturnNo,ReturnID'
	exec (@mySQL)
	--48.采购调价单
	Truncate Table PMS_Rectify
	Truncate Table PMS_RectifyDtl
	Set @mySQL='Insert Into PMS_Rectify(RectifyNo,CreateDate,DeptNo,VendorID,Effect,'
	Set @mySQL=@mySQL +'BillSts,CreatorID,AuditDate,AuditID,Remarks,PFlag) '
	Set @mySQL=@mySQL +'Select RectifyNo,CreateDate,DeptNo,VendorID,Effect,BillSts,'
	Set @mySQL=@mySQL +'CreatorID,AuditDate,AuditID,Remarks,PFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_Rectify'
	exec (@mySQL)
	Set @mySQL='Insert Into PMS_RectifyDtl(RectifyNo,StockID,ItemID,RemRQty,MQty,'
	Set @mySQL=@mySQL +'Price,MPrice,Amt,Remarks,TaxFlag) '
	Set @mySQL=@mySQL +'Select RectifyNo,StockID,ItemID,RemRQty,MQty,Price,MPrice,'
	Set @mySQL=@mySQL +'Amt,Remarks,TaxFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_RectifyDtl Order By RectifyNo,RectifyID'
	exec (@mySQL)
	--49.采购发票
	Truncate Table PMS_Invoice
	Truncate Table PMS_InvoiceDtl
	Set Identity_Insert PMS_Invoice On
	Set @mySQL='Insert Into PMS_Invoice(InvoiceID,InvoiceNo,DeptNo,CreateDate,VendorID,IType,Invoice,'
	Set @mySQL=@mySQL +'PayMode,IAmt,DAmt,PAmt,BillSts,CreatorID,AuditDate,Remarks,PFlag,IFlag) '
	Set @mySQL=@mySQL +'Select InvoiceID,InvoiceNo,DeptNo,CreateDate,VendorID,IType,Invoice,PayMode,'
	Set @mySQL=@mySQL +'IAmt,DAmt,PAmt,BillSts,CreatorID,AuditDate,Remarks,PFlag,IFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_Invoice'
	exec (@mySQL)
	Set @mySQL='Insert Into PMS_InvoiceDtl(InvoiceNo,StockID,ItemID,IQty,Price,Amt,Remarks) '
	Set @mySQL=@mySQL +'Select InvoiceNo,StockID,ItemID,IQty,Price,Amt,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_InvoiceDtl Order By InvoiceNo,InvoiceID'
	exec (@mySQL)
	Set Identity_Insert PMS_Invoice Off
	Truncate Table PMS_Payment
	Truncate Table PMS_PaymentDtl
	Set @mySQL='Insert Into PMS_Payment(PaymentNo,CreateDate,DeptNo,VendorID,Credence,PayMode,'
	Set @mySQL=@mySQL +'BankID,Amt,BillSts,CreatorID,AuditDate,AuditID,Remarks,PFlag) '
	Set @mySQL=@mySQL +'Select PaymentNo,CreateDate,DeptNo,VendorID,Credence,PayMode,BankID,Amt,'
	Set @mySQL=@mySQL +'BillSts,CreatorID,AuditDate,AuditID,Remarks,PFlag '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_Payment'
	exec (@mySQL)
	Set @mySQL='Insert Into PMS_PaymentDtl(PaymentNo,InvoiceID,Invoice,IAmt,DAmt,FAmt,PayAmt,Remarks) '
	Set @mySQL=@mySQL +'Select PaymentNo,InvoiceID,Invoice,IAmt,DAmt,FAmt,PayAmt,Remarks '
	Set @mySQL=@mySQL +'From ' + @DBName + '.dbo.PMS_PaymentDtl Order By PaymentNo,PaymentID'
	exec (@mySQL)
	--恢复触发器
	--销售部分
	Alter Table SMS_InvoiceDtl Enable Trigger All
	Alter Table SMS_PaymentDtl Enable Trigger All
	Alter Table SMS_RectifyDtl Enable Trigger All
	Alter Table SMS_ReturnDtl Enable Trigger All
	Alter Table SMS_GatheringDtl Enable Trigger All
	Alter Table SMS_ChangeDtl Enable Trigger All
	Alter Table SMS_Arrearage Enable Trigger All
	Alter Table SMS_StockDtl Enable Trigger All
	--库存部分
	Alter Table IMS_AllotDtl Enable Trigger All
	Alter Table IMS_InceptDtl Enable Trigger All
	--采购部分
	Alter Table PMS_Arrearage Enable Trigger All
	Alter Table PMS_PlanDtl Enable Trigger All
	Alter Table PMS_OrderDtl Enable Trigger All
	Alter Table PMS_StockDtl Enable Trigger All
	Alter Table PMS_ReturnDtl Enable Trigger All
	Alter Table PMS_RectifyDtl Enable Trigger All
	Alter Table PMS_InvoiceDtl Enable Trigger All
	Alter Table PMS_PaymentDtl Enable Trigger All
End
go

