--删除装箱明细相关触发器
CREATE Trigger Trig_SMS_BoxupDtl_Dtl_Del
On dbo.SMS_BoxupDtl_Dtl
For Delete
As
Begin
	declare @StockNo varchar(20)
	set @StockNo=@StockNo
/*
	--更新出库单的已装箱数量
	--Update a Set a.BoxQty=Isnull(a.BoxQty,0)-Isnull(b.Qty,0)	From SMS_StockDtl a,Deleted b	Where a.StockID=b.StockID 

	declare mycursor cursor
	for select Distinct StockNo from SMS_StockDtl Where StockID In(Select StockID From Deleted)
	open mycursor
	fetch next from mycursor into @StockNo
	while @@fetch_Status=0
	begin
		--存在未装箱的记录
		if exists(Select * from SMS_StockDtl_V Where Abs(Isnull(RemBoxQty,0))>0 And StockNo=@StockNo)
			begin
				Update SMS_Stock Set BoxupSts='' Where StockNo=@StockNo	
			end 
		else
				begin
					Update SMS_Stock Set BoxupSts='' Where StockNo=@StockNo		
				end 
		fetch next from mycursor into @StockNo
	end
	close mycursor
	deallocate mycursor
*/
End






go

