--采购入库单明细插入操作（Insert)
--2005-01-25
--Devil.H
--当上述操作发生时：
--更新订单的已入库数量，同时更新订单状态
CREATE Trigger Trig_PMS_STOCKDTL_Ins
On dbo.PMS_StockDtl
--with encryption
For Insert
As
Begin
	declare @OrderNo varchar(20)
	--更新订单的已入库数量
	Update a Set a.SQty=Isnull(a.SQty,0)+Isnull(b.SQty,0)
	From PMS_OrderDtl a,Inserted b
	Where a.OrderID=b.OrderID
	--计划单
	declare mycursor cursor
	for select Distinct OrderNo from PMS_OrderDtl Where OrderID In(Select OrderID From Inserted)
	open mycursor
	fetch next from mycursor into @OrderNo
	while @@fetch_Status=0
	begin
		--存在未执行的记录
		if exists(Select * from PMS_OrderDtl_V Where Isnull(RemSQty,0)>0 And OrderNo=@OrderNo)
			Update PMS_Order Set BillSts='25' Where OrderNo=@OrderNo And BillSts<>'05'
		else
			Update PMS_Order Set BillSts='30' Where OrderNo=@OrderNo And BillSts<>'05'	
		fetch next from mycursor into @OrderNo
		
	end
	close mycursor
	deallocate mycursor

End
go

