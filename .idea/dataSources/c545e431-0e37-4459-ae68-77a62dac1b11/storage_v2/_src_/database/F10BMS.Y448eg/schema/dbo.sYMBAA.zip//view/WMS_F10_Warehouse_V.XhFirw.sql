/*==============================================================*/
/* View: WMS_F10_Warehouse_V                                    */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_Warehouse_V] as
SELECT a.warehouseId,a.warehouseNo AS warehouse,b.DeptNo
FROM YiWms.dbo.BAS_Warehouse a
    INNER JOIN dbo.BDM_WareHouse_V b ON a.warehouseNo=b.CodeID
go

