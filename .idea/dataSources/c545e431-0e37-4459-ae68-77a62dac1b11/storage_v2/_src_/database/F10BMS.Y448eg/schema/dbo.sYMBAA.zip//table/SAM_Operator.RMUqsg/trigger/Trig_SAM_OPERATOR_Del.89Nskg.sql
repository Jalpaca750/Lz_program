--操作员删除操作触发
--2005-01-22
--Devil.H
--当上述操作发生时：
--系统自动检删除该操作员的一切权限
Create Trigger Trig_SAM_OPERATOR_Del
On dbo.SAM_Operator
--with encryption
For Delete
As 
Begin

	Delete From SAM_Power 
	Where EmployeeID In(Select EmployeeID From Deleted )

End
go

