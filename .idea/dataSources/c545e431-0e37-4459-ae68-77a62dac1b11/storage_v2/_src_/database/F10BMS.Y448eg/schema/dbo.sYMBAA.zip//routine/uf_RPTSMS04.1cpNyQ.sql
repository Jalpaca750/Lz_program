--说明：系统报表之销售出库单
--作者：Devil.H
--创建：2006.06.13
--参数：
--	@BillNo	 :单据编号
--	@Row	 :每页打印行数
CREATE Function dbo.uf_RPTSMS04
(
	@BillNo varchar(20),
	@Row bigint,
	@OrderBy varchar(30)
)
Returns @uTable Table(
	BillID bigint identity(1,1),
	BillNo varchar(20),
	Location varchar(20),
	ItemNo varchar(20),
	ItemName varchar(80),
	ItemSpec varchar(80),
	ClassName varchar(40),
	LabelName varchar(40),
	ColorName varchar(40),
	UnitName varchar(40),
	PkgSpec varchar(40),
	PkgQty decimal(18,6),
	Price decimal(18,6),
	Amt decimal(18,6),
	SQty decimal(18,6),
	ZQty decimal(18,6),
	PPrice decimal(18,6),
	SPrice decimal(18,6),
	SPrice1 decimal(18,6),
	SPrice2 decimal(18,6),
	SPrice3 decimal(18,6),
	BPackage varchar(40),
	MPackage varchar(40),
	Package varchar(40),
	Remarks varchar(2000),
	OnHandQty decimal(18,6),
    BefPrice decimal(18,6),
    DiscRate decimal(18,6),
    BefAmt decimal(18,6)
)
As
Begin	
	declare @Rows bigint
	declare @NullRow bigint
	declare @i bigint
	--初始化变量
	Set @i=0
	--如果没有传递行数，默认9行
	Set @Row=isnull(@Row,9)
	if isnull(@BillNo,'')=''
		Return
	if upper(@OrderBy)='STOCKID'
		Insert Into @uTable(BillNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,
			UnitName,PkgSpec,PkgQty,Price,SQty,Amt,ZQty,PPrice,SPrice,SPrice1,SPrice2,SPrice3,
			BPackage,MPackage,Package,Remarks,OnHandQty,BefPrice,DiscRate,BefAmt)
		Select StockNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,UnitName,
			PkgSpec,PkgQty,Price,SQty,Amt,ZQty,PPrice,SPrice,SPrice1,SPrice2,SPrice3,BPackage,
			MPackage,Package,Remarks,OnHandQty,DiscountTemp,DiscRate,CAST(DiscountTemp AS DECIMAL(18,6))*SQty AS BefAmt
		From SMS_StockDtl_V
		Where StockNo=@BillNo
		Order By StockID
	if upper(@OrderBy)='ITEMNO'
		Insert Into @uTable(BillNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,
			UnitName,PkgSpec,PkgQty,Price,SQty,Amt,ZQty,PPrice,SPrice,SPrice1,SPrice2,SPrice3,
			BPackage,MPackage,Package,Remarks,OnHandQty,BefPrice,DiscRate,BefAmt)
		Select StockNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,UnitName,
			PkgSpec,PkgQty,Price,SQty,Amt,ZQty,PPrice,SPrice,SPrice1,SPrice2,SPrice3,BPackage,
			MPackage,Package,Remarks,OnHandQty,DiscountTemp,DiscRate,CAST(DiscountTemp AS DECIMAL(18,6))*SQty AS BefAmt
		From SMS_StockDtl_V
		Where StockNo=@BillNo
		Order By ItemNo
	if upper(@OrderBy)='LOCATION'
		Insert Into @uTable(BillNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,
			UnitName,PkgSpec,PkgQty,Price,SQty,Amt,ZQty,PPrice,SPrice,SPrice1,SPrice2,SPrice3,
			BPackage,MPackage,Package,Remarks,OnHandQty,BefPrice,DiscRate,BefAmt)
		Select StockNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,UnitName,
			PkgSpec,PkgQty,Price,SQty,Amt,ZQty,PPrice,SPrice,SPrice1,SPrice2,SPrice3,BPackage,
			MPackage,Package,Remarks,OnHandQty,DiscountTemp,DiscRate,CAST(DiscountTemp AS DECIMAL(18,6))*SQty AS BefAmt
		From SMS_StockDtl_V
		Where StockNo=@BillNo
		Order By Location
	--总的行数
	Select @Rows=Count(*) From @uTable
	if @Rows=0 
		return
	Set @NullRow=@Row-@Rows%@Row
	if @NullRow=@Row 
		Return
	while @i<@NullRow
		Begin
			Insert Into @uTable(BillNo)
			Values(@BillNo)
			Set @i=@i+1
		End
	--返回
	return
End
go

