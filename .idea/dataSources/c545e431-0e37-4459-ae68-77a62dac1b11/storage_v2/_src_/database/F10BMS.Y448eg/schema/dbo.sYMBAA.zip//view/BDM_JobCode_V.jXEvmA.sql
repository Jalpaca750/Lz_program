--职位代码
CREATE VIEW dbo.BDM_JobCode_V
AS
SELECT CodeID, CodeNo, CHName, ENName,Flag, Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL08')
go

