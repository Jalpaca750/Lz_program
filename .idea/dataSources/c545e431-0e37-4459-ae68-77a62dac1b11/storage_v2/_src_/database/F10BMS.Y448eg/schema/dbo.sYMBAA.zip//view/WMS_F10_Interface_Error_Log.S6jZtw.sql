    CREATE view [dbo].[WMS_F10_Interface_Error_Log] as
    SELECT errorId, companyId, createTime, creatorId, funCode, errorCode, errorMessage, billId, billNo
    FROM dbo.SAM_Error
    go

