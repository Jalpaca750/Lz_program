--审核销售出库
--2007-08-11
--Devil.H
--当上述操作发生时：
--更新预占库存数量……
CREATE Proc sp_YZStock_Audit_Stock
(
	@StockNo varchar(20),
	@Flag char(2)
)
As
Begin	
	if @Flag='A1'--销售出库审核
	begin
        --减少预占库存
        Update a Set a.OQty=Isnull(a.OQty,0.0)-(Isnull(b.SQty,0)+Isnull(b.ZQty,0))
        From IMS_Advance a 
            Inner Join SMS_StockDtl b On a.OrderId=b.OrderId
        Where b.StockNo=@StockNo;
		--填充 SMS_StockDt l的准备释放预占库存数量
        Update a Set YZStockQty=Case When Isnull(a.SQty,0)+Isnull(a.ZQty,0)-Isnull(Y.Qty,0)<0 then Isnull(a.SQty,0)+Isnull(a.ZQty,0) else Isnull(Y.Qty,0) end
        From SMS_StockDtl a 
			inner join SMS_Stock b On a.StockNo=b.StockNo 
			inner join IMS_YZStock Y On a.WareHouse=Y.WareHouseID And a.ItemID=Y.ItemID And b.CustID=Y.CustID 
        Where a.StockNo=@StockNo
		--释放预占库存数量
		Update Y Set Y.Qty=Y.Qty-Isnull(a.YZStockQty,0) 
        From IMS_YZStock Y 
            inner join SMS_StockDtl_V a On a.WareHouse=Y.WareHouseID  And a.ItemID=Y.ItemID And a.CustID=Y.CustID 
        Where a.StockNo=@StockNo
	end
	if @Flag='A2'--调拨出库审核
	begin
        --减少预占库存
        Update a Set a.OQty=Isnull(a.OQty,0.0)-(Isnull(b.SQty,0))
        From IMS_Advance a 
            Inner Join IMS_AllotDtl b On a.OrderId=b.OrderId
        Where b.AllotNo=@StockNo;
		--填充 IMS_AllotDtll 的准备释放预占库存数量
		Update a Set YZStockQty=Case When Isnull(a.RemIQty,0)-Isnull(Y.Qty,0)<0 then Isnull(a.RemIQty,0) else Isnull(Y.Qty,0) end
        From IMS_AllotDtl_V a 
			inner join IMS_YZStock  Y On a.WareHouse=Y.WareHouseID And a.ItemID=Y.ItemID And a.DeptNo_I=Y.CustID 
		Where a.AllotNo=@StockNo
		--释放预占库存数量
		Update Y Set Y.Qty=Y.Qty-Isnull(a.YZStockQty,0) 
        From IMS_YZStock Y inner join IMS_AllotDtl_V a On
            a.WareHouse=Y.WareHouseID And a.ItemID=Y.ItemID And a.DeptNo_I=Y.CustID 
        Where a.AllotNo=@StockNo;
	end
	if @Flag='A5'--赠品出库审核
	begin
		--填充 IMS_PresentDtl l的准备释放预占库存数量
		Update a Set YZStockQty=Case When Isnull(a.SQty,0)-Isnull(Y.Qty,0)<0 then Isnull(a.SQty,0) else Isnull(Y.Qty,0) end
        From IMS_PresentDtl_V a 
            inner join IMS_YZStock Y On a.WareHouse=Y.WareHouseID And a.ItemID=Y.ItemID And a.CustID=Y.CustID 
        Where a.PresentNo=@StockNo
		--释放预占库存数量
		Update Y Set Y.Qty=Y.Qty-Isnull(a.YZStockQty,0) 
        From IMS_YZStock Y inner join IMS_PresentDtl_V a On a.WareHouse=Y.WareHouseID And a.ItemID=Y.ItemID And a.CustID=Y.CustID 
        Where a.PresentNo=@StockNo
	end
	if @Flag='A6'--其它出库审核
	begin
		--填充 IMS_OtherDtl l的准备释放预占库存数量
		Update a Set YZStockQty=Case When Isnull(a.SQty,0)-Isnull(Y.Qty,0)<0 then Isnull(a.SQty,0) else Isnull(Y.Qty,0) end
        From IMS_OtherDtl_V a 
			inner join IMS_YZStock Y On a.WareHouse=Y.WareHouseID And a.ItemID=Y.ItemID And a.CustID=Y.CustID 
        Where a.OtherNo=@StockNo
		--释放预占库存数量
		Update Y Set Y.Qty=Y.Qty-Isnull(a.YZStockQty,0) 
        From IMS_YZStock Y inner join IMS_OtherDtl_V a On a.WareHouse=Y.WareHouseID  And a.ItemID=Y.ItemID And a.CustID=Y.CustID 
        Where a.OtherNo=@StockNo
	end
	if @Flag='U1'--取消审核销售订单
	begin
        --删除预占明细
        Delete From IMS_Advance WHERE orderId=ANY(select orderId from SMS_orderDtl WHERE orderNo=@StockNo) AND YZType='S';
        update T1 set T1.Qty=T1.Qty-T2.yzQty 
        From IMS_YZStock T1,
			(select a.YZStockWareHouseID,b.ItemID,a.CustID,b.RemSQty+b.RemZQty As yzQty 
             from SMS_Order a 
                inner Join SMS_OrderDtl_V b ON a.OrderNo=b.OrderNo
             where  a.OrderNo=@StockNo) T2 
	    where T1.WareHouseID=T2.YZStockWareHouseID and T1.ItemID=T2.ItemID And T1.CustID=T2.CustID  
	End
	if @Flag='U2'--取消审核调拨申请
	begin
        Delete From IMS_Advance WHERE orderId=ANY(select orderId from PMS_OrderDtl WHERE orderNo=@StockNo) AND YZType='P';
		update T1 set T1.Qty=T1.Qty-T2.yzQty 
        From IMS_YZStock T1,
		    (select a.YZStockWareHouseID,b.ItemID,a.DeptNo as CustID,b.RemDQty As yzQty 
             from PMS_Order a
                Inner Join PMS_OrderDtl_V b On a.OrderNo=b.OrderNo 
             Where a.OrderNo=@StockNo) T2 
		where T1.WareHouseID=T2.YZStockWareHouseID and T1.ItemID=T2.ItemID And T1.CustID=T2.CustID  
	End
	if @Flag='U3' --销售出库取消审核
	begin
        --减少预占库存
        Update a Set a.OQty=Isnull(a.OQty,0.0)+(Isnull(b.SQty,0)+Isnull(b.ZQty,0))
        From IMS_Advance a 
            Inner Join SMS_StockDtl b On a.OrderId=b.OrderId
        Where b.StockNo=@StockNo;
		--释放预占库存数量
		Update Y Set Y.Qty=Y.Qty+Isnull(a.YZStockQty,0) 
        From IMS_YZStock Y 
            inner join SMS_StockDtl_V a On a.WareHouse=Y.WareHouseID And a.ItemID=Y.ItemID And a.CustID=Y.CustID
        Where a.StockNo=@StockNo		
	End
	if @Flag='U4' ---取消调拨出库审核
	begin
        --增加预占库存
        Update a Set a.OQty=Isnull(a.OQty,0.0)+(Isnull(b.SQty,0))
        From IMS_Advance a 
            Inner Join IMS_AllotDtl b On a.OrderId=b.OrderId
        Where b.AllotNo=@StockNo;
		--释放预占库存数量
		Update Y Set Y.Qty=Y.Qty+Isnull(a.YZStockQty,0) 
        From IMS_YZStock Y 
            inner join IMS_AllotDtl_V a On a.WareHouse=Y.WareHouseID And a.ItemID=Y.ItemID And a.DeptNo_I=Y.CustID
        Where a.AllotNo=@StockNo		
	End
	if @Flag='U5' ---取消赠品出库审核
	begin
		--释放预占库存数量
		Update Y Set Y.Qty=Y.Qty+Isnull(a.YZStockQty,0) 
        From IMS_YZStock Y 
            inner join IMS_PresentDtl_V a On a.WareHouse=Y.WareHouseID And a.ItemID=Y.ItemID And a.CustID=Y.CustID
        Where a.PresentNo=@StockNo		
	End
	if @Flag='U6' ---取消其它出库审核
	begin
		--释放预占库存数量
		Update Y Set Y.Qty=Y.Qty+Isnull(a.YZStockQty,0) 
        From IMS_YZStock Y 
            inner join IMS_OtherDtl_V a On a.WareHouse=Y.WareHouseID And a.ItemID=Y.ItemID And a.CustID=Y.CustID
        Where a.OtherNo=@StockNo		
	End
	if @Flag='P3' ---中止调拨申请
	begin
		--中止调拨申请，将未出库的预占数量取消
		Update Y Set Y.Qty=Y.Qty-Isnull(a.RemDQty,0) 
        From IMS_YZStock Y inner join PMS_OrderDtl_V a On a.WareHouseID=Y.WareHouseID And a.ItemID=Y.ItemID And a.DeptNo=Y.CustID
		Where a.OrderNo=@StockNo		
	End
End
go

