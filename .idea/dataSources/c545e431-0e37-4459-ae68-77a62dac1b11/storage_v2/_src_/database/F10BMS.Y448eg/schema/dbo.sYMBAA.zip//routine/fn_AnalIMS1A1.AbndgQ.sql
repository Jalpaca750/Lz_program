--说明：库房总帐分析
--作者：Devil.H
--创建：2010.03.23
--参数：
--	@ItemID:商品ID
CREATE FUNCTION fn_AnalIMS1A1
(
	@DeptNo varchar(20),
	@ItemID bigint
)
RETURNS TABLE
AS
RETURN (SELECT a.WareHouse,c.CHName AS WHName,a.Location,b.ItemNo,b.ItemName,b.ItemAlias,
		b.NameSpell,b.ItemSpec,b.BarCode,b.ClassName,b.LabelName,b.ColorName,
		b.UnitName,a.OnHandQty,a.Price,a.Amt,
		a.LastIDate,a.LastIPrice,a.LastODate,a.LastOPrice,b.PkgSpec, 
		CASE Isnull(b.PkgRatio, 0.0) WHEN 0.0 THEN NULL 
		ELSE Round(Isnull(a.OnHandQty, 0.0) / Isnull(b.PkgRatio, 0.0), 4) END AS PkgQty
	FROM dbo.IMS_Ledger a INNER JOIN
	      dbo.BAS_Goods_V b ON a.ItemID = b.ItemID LEFT OUTER JOIN
	      dbo.BDM_WareHouse_V c ON a.WareHouse = c.CodeID
	Where a.ItemID=@ItemID And c.DeptNo=@DeptNo
)
go

