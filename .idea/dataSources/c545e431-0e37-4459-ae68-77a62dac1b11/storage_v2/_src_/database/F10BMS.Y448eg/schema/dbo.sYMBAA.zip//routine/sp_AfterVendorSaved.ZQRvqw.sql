CREATE PROCEDURE [dbo].[sp_AfterVendorSaved]
(
	@VendorNo VARCHAR(20)
)
AS
BEGIN	
	DECLARE @companyId VARCHAR(32),			--公司Id
			@ownerId VARCHAR(32),			--业主Id
			@operatorId VARCHAR(32),		--操作员Id	
			@curTime DATETIME,				--当前日期
			@partnerType INT;				--1-客户；2-供应商；3-业主;

	DECLARE @VendorID BIGINT,				--F10客户Id
			@partnerId VARCHAR(32),			--供应商Id
			@partnerName VARCHAR(200),		--供应商名称
			@partnerSpell VARCHAR(200),		--供应商名称拼音
			@companyAddress VARCHAR(100),	--供应商地址
			@Flag CHAR(1),					--供应商状态
			@zip VARCHAR(10),				--邮编
			@receiverAddress VARCHAR(100),
			@remarks VARCHAR(1000),			--备注
			@contactName VARCHAR(40),		--联系人名称
			@sex VARCHAR(10),				--性别
			@phone VARCHAR(80),				--联系人电话（私人电话）
			@contactTitle VARCHAR(40),		--职位
            @errors BIGINT;
    --如果WMS接口未开启，直接退出
    IF NOT EXISTS(SELECT * FROM dbo.SYS_Config WHERE ISNULL(startWMS,0)=1)
        RETURN;
    --如果不需要同步，则直接退出
	IF EXISTS(SELECT 1 FROm dbo.BDM_Vendor WHERE VendorNo=@VendorNo AND syncFlag=1)
		RETURN;
    SELECT TOP 1 @companyId=companyId,@operatorId=IOperatorId,@ownerId=OwnerId FROM dbo.SYS_Config;
	SET @curTime=GETDATE();
	SET @partnerType=2;										--供应商
	--获取供应商ID,名称、地址，邮编，默认联系人，性别、电话、职位，备注
	SELECT @VendorID=VendorID,@partnerName=VendorName,@partnerSpell=NameSpell,@companyAddress=VendorAddr,
		@zip=PostalCode,@contactName=LinkMan,@sex=CASE sex WHEN 1 THEN '男' WHEN 0 THEN '女' END,
		@Phone=Phone,@contactTitle=JobName,@Flag=Flag,@remarks=Remarks
	FROM dbo.BDM_Vendor 
	WHERE VendorNo=@VendorNo;
    SET @errors=0;
	BEGIN TRANSACTION
	--查找是否已经写入系统
	IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Partner WHERE companyId=@companyId AND partnerType=@partnerType AND ownerId=@ownerId AND partnerNo=@VendorNo)
	BEGIN
		SET @partnerId=LOWER(REPLACE(NEWID(),'-',''));
		--新建供应商资料
		INSERT INTO YiWms.dbo.BAS_Partner(partnerType,companyId,ownerId,partnerId,partnerNo,
			partnerName,shortName,partnerSpell,reportTitle,reportCode,companyAddress,zip,partnerState,
			isLocked,lockerId,lockedTime,createTime,creatorId,editTime,editorId,remarks)
		VALUES(@partnerType,@companyId,@ownerId,@partnerId,@VendorNo,
			@partnerName,'',@partnerSpell,'','',@companyAddress,@zip,@Flag,
			0,'',NULL,@curTime,@operatorId,@curTime,@operatorId,@remarks);
        SET @errors=@errors+@@ERROR;
		--写入供应商默认联系人
		INSERT INTO YiWms.dbo.BAS_Contact(contactId,companyId,partnerId,contactName,sex,contactTitle,
			officeTel,mobileNo,email,education,interest,ages,partnerType,isDefault,isDisable,isLocked,
			lockerId,lockedTime,createTime,creatorId,editTime,editorId)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@partnerId,@contactName,@sex,@contactTitle,
			@phone,'','','','','',@partnerType,1,0,0,'',NULL,@curTime,@operatorId,@curTime,@operatorId);
        SET @errors=@errors+@@ERROR;
		--写入操作日志
		INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterVendorSaved',
			'通过接口同步供应商资料，供应商编码:[' + @VendorNo + '],供应商名称:[' + @partnerName + ']',
			@partnerId,@VendorNo);	
        SET @errors=@errors+@@ERROR;
	END
	ELSE
	BEGIN
		SELECT @partnerId=partnerId
		FROM YiWms.dbo.BAS_Partner 
		WHERE companyId=@companyId AND partnerType=@partnerType AND ownerId=@ownerId AND partnerNo=@VendorNo;
		--修改供应商资料
		UPDATE  YiWms.dbo.BAS_Partner SET partnerName=@partnerName,
											   partnerSpell=@partnerSpell,
											   companyAddress=@companyAddress,
											   zip=@zip,
											   partnerState=@Flag,
											   editTime=@curTime,
											   editorId=@operatorId,
											   remarks=@remarks
		WHERE partnerId=@partnerId;
        SET @errors=@errors+@@ERROR;
		--修改供应商默认联系人
		UPDATE YiWms.dbo.BAS_Contact SET contactName=@contactName,
											  sex=@sex,
											  contactTitle=@contactTitle,
											  officeTel=@phone,
											  mobileNo='',
											  email='',
											  editTime=@curTime,
											  editorId=@operatorId
		WHERE partnerId=@partnerId AND isDefault=1;
        SET @errors=@errors+@@ERROR;
		--写入操作日志
		INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterVendorSaved',
			'通过接口同步供应商资料，供应商编码:[' + @VendorNo + '],供应商名称:[' + @partnerName + ']',
			@partnerId,@VendorNo);
        SET @errors=@errors+@@ERROR;
	END
	--更新同步状态
	UPDATE dbo.BDM_Vendor SET syncFlag=1 WHERE VendorNo=@VendorNo;
    SET @errors=@errors+@@ERROR;
    IF (@errors=0)
    BEGIN
		COMMIT;
	END
    ELSE
	BEGIN
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;
		RAISERROR(@ErrMsg, @ErrSeverity, 1)	
		--写入同步错误日志	
		INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterVendorSaved','YI_VENDOR_SYNC_ERROR',LEFT(@ErrMsg,2000),@partnerId,@VendorNo);
	END
END
go

