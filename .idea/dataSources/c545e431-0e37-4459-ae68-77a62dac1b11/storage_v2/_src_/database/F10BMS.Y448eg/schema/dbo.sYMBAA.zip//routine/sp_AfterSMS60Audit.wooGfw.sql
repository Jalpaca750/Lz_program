
CREATE proc [dbo].[sp_AfterSMS60Audit]
(
	@orderNo VARCHAR(32),
	@billSts CHAR(2),
	@userId BIGINT
)
AS
BEGIN
    DECLARE @companyId VARCHAR(32),			    --公司Id
            @ownerId VARCHAR(32),			    --业主Id
            @warehouseId VARCHAR(32),		    --仓库Id
            @operatorId VARCHAR(32),		    --操作员Id	
            @curTime DATETIME,				    --操作时间
            @funCode VARCHAR(100),			    --存储过程名称 
            @guid VARCHAR(32);                
    DECLARE @returnBillNo VARCHAR(32),			--F10退货单编号
            @returnDate VARCHAR(10),			--下单日期（F10的CreateTime)
            @customerId VARCHAR(32),			--客户Id
            @ioType VARCHAR(32),				--入出库类型
            @receiverState VARCHAR(32),			--送货地址（省）
            @receiverCity VARCHAR(32),			--送货地址（市）
            @receiverDistrict VARCHAR(32),		--送货地址（县）
            @receiverAddress VARCHAR(100),		--送货地址
            @receiverName VARCHAR(40),			--收货人
            @receiverTel VARCHAR(80),			--收货人电话
            @receiverMobile VARCHAR(40),		--收货人电话
            @groupId VARCHAR(32),				--分组Id
            @lineId VARCHAR(32),				--配送线路Id			
            @salesId VARCHAR(32),				--销售员Id			
            @billSource INT,					--退单来源
            @deptId VARCHAR(32),				--发货部门
            @handlerId VARCHAR(32),				--经手人
            @organizeId VARCHAR(100),			--成本中心名称
            @buyerId VARCHAR(100),				--易企购下单人昵称
            @currencyId VARCHAR(32),			--币别
            @exchangeRate DECIMAL(20,10),		--汇率
            @taxFlag INT,						--是否含税
            @ioState INT,						--订单状态 10-待审核;
            @apState INT,						--任务状态
            @orderType INT,						--10-销售订单			
            @bonePkgId VARCHAR(32),				--Bone子订单编号
            @boneOrdId VARCHAR(32),				--Bone订单编号
            @totalFee DECIMAL(20,10),			--总金额			
            @memo VARCHAR(1000),				--备注
            @creatorID VARCHAR(32),				--制单人Id
            @auditorId VARCHAR(32),				--审核人Id
            @auditTime DATETIME,				--审核时间
            @wmsOrder VARCHAR(32)				--Wms退货单编号
    DECLARE @ErrMsg NVARCHAR(4000),@ErrSeverity INT,@errors BIGINT;	
    DECLARE @sales TABLE(stockNo VARCHAR(32),billCount INT);
	--如果未开启同步，则停止推送
	IF NOT EXISTS(SELECT * FROM dbo.SYS_Config WHERE ISNULL(startWms,0)=1)
		RETURN;
    --如果非配置数据，直接退出
	IF NOT EXISTS(SELECT * FROM dbo.SMS_Return a WHERE a.returnNo=@OrderNo AND EXISTS(SELECT * FROM dbo.WMS_Config b WHERE a.Warehouse=b.Warehouse OR a.Warehouse=b.DclWarehouse OR a.Warehouse=b.whId01))
		RETURN;
    --获取公司Id,业主Id
    SELECT TOP 1 @companyId=companyId,@ownerId=OwnerId FROM dbo.SYS_Config;
    SET @funCode='sp_AfterSMS60Audit'
	SET @curTime=GETDATE();		
	--获取当前操作用户Id	
	SELECT @operatorId=userId FROM dbo.WMS_F10_User_V WHERE employeeId=@userId;
	--清除同步错误
	DELETE FROM dbo.SAM_Error WHERE companyId=@companyId AND funCode=@funCode AND billNo=@orderNo;
	SET @errors=0;
    BEGIN TRANSACTION		
    IF @BillSts='20'
    BEGIN
    	--获取退货单主表资料
        SELECT @wmsOrder=wmsOrder,	
            @returnBillNo=billNo,
            @returnDate=returnDate,			
            @ioType=ioType,
            @customerId=customerId,
            @receiverState=receiverState,
            @receiverCity=receiverCity,
            @receiverDistrict=receiverDistrict,
            @receiverAddress=receiverAddress,
            @receiverName=receiverName,
            @receiverTel=receiverTel,
            @receiverMobile=receiverMobile,
            @groupId=groupId,
            @lineId=lineId,
            @currencyId=currencyId,
            @exchangeRate=exchangeRate,
            @taxFlag=taxFlag,
            @apState=apState,
            @ioState=ioState,
            @billSource=billSource,			
            @salesId=salesId,					
            @buyerId=buyerId,
            @organizeId=organizeId,
            @handlerId=handlerId,
            @warehouseId=warehouseId,
            @deptId=deptId,
            @orderType=orderType,			
            @creatorID=creatorId,
            @totalFee=totalFee,					
            @memo=memo,
            @auditTime=auditTime,
            @auditorId=auditorId
    	FROM dbo.Sync_SMS_Return_V a
    	WHERE billNo=@orderNo;
        SET @errors=@errors+@@ERROR;
    	--检查客户资料是否同步
    	IF NOT EXISTS(SELECT * FROM dbo.Sync_SMS_Return_V WHERE billNo=@OrderNo)
    	BEGIN
    		--写入同步错误日志	
    		INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
    		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,@funCode,'YI_SR_CUST_NOT_SYNC_ERROR',
    			'销售退货单[' + @OrderNo + ']对应客户资料没有同步到WMS，同步失败',@OrderNo,@OrderNo);
            SET @errors=@errors+@@ERROR;
    		COMMIT;
    		RETURN;
    	END	
    	--检查商品资料是否有没同步的
    	IF EXISTS(SELECT * FROM dbo.SMS_ReturnDtl a WHERE a.ReturnNo=@OrderNo AND returnId NOT IN(SELECT contractId FROM dbo.Sync_SMS_ReturnDtl_V WHERE contractNo=@OrderNo))
    	BEGIN
    		--写入同步错误日志	
    		INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
    		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,@funCode,'YI_SR_ITEM_NOT_SYNC_ERROR',
    			'销售退货单[' + @OrderNo + ']对应商品资料没有同步到WMS，同步失败',@OrderNo,@OrderNo);
            SET @errors=@errors+@@ERROR;
    		COMMIT;
    		RETURN;
    	END	
    	--已经同步过的数据不需要同步
    	IF EXISTS(SELECT * FROM dbo.SMS_Return WHERE ReturnNo=@OrderNo AND syncFlag=1) 
    		OR EXISTS(SELECT * FROM YiWms.dbo.SAD_Return WHERE companyId=@companyId AND ownerId=@ownerId AND billNo=@OrderNo)
    	BEGIN
    		SELECT @wmsOrder=returnNo FROM YiWms.dbo.SAD_Return WHERE companyId=@companyId AND ownerId=@ownerId AND billNo=@OrderNo;
    		--更新订单状态(已同步，WMS订单号和最后修改时间）
    		UPDATE dbo.SMS_Return SET syncFlag=1,wmsOrder=@wmsOrder,editTime=@curTime WHERE ReturnNo=@orderNo;
            SET @errors=@errors+@@ERROR;
    		COMMIT;
    		RETURN;
    	END
    	--如果没有同步过，则@wmsOrder取得一个新的GUID
    	IF (ISNULL(@wmsOrder,'')='')
    		SET @wmsOrder=LOWER(REPLACE(NEWID(),'-',''));
    	--写入采购订单主表     
    	INSERT INTO YiWms.dbo.SAD_Return(returnNo,billNo,companyId,ownerId,returnDate,ioType,warehouseId,
    		customerId,receiverState,receiverCity,receiverDistrict,receiverAddress,receiverName,receiverTel,
    		receiverMobile,groupId,lineId,currencyId,exchangeRate,taxFlag,ioState,apState,totalFee,returnFee,
    		postFee,reason,billSource,salesId,buyerId,organizeId,handlerId,handlerTime,deptId,thirdSyncFlag,
    		orderType,printNum,printId,shipState,memo,createtime,creatorId,auditorId,auditTime,isLocked,
    		lockerId,lockedTime,editTime,editorId)
    	VALUES(@wmsOrder,@returnBillNo,@companyId,@ownerId,@returnDate,@ioType,@warehouseId,@customerId,
    		@receiverState,@receiverCity,@receiverDistrict,@receiverAddress,@receiverName,@receiverTel,
    		@receiverMobile,@groupId,@lineId,@currencyId,@exchangeRate,@taxFlag,@ioState,@apState,@totalFee,0.0,
    		0.0,'',@billSource,@salesId,@buyerId,@organizeId,@handlerId,NULL,@deptId,0,@orderType,0,'',
    		0,@memo,@curTime,@creatorId,@auditorId,@auditTime,0,'',NULL,@curTime,@operatorId);
        SET @errors=@errors+@@ERROR;
    	--写入采购订单明细表	
    	INSERT INTO YiWms.dbo.SAD_ReturnDetail(returnId,returnNo,companyId,warehouseId,viewOrder,stockId,
    		stockNo,stockBillNo,lotNo,locationNo,eId,itemId,returnQty,pkgQty,bulkQty,befPrice,discount,
    		discountFee,price,taxrate,fee,taxFee,totalFee,costPrice,rebate,invoiceQty,invoiceFee,payQty,
    		payFee,toOrder,isPromotion,groupId,salesId,handlerId,deptId,contractId,contractNo,remarks)
    	SELECT LOWER(REPLACE(NEWID(),'-','')),@wmsOrder,@companyId,@warehouseId,viewOrder,stockId,
    		stockNo,stockBillNo,lotNo,locationNo,eId,itemId,returnQty,FLOOR(returnQty/pkgRatio) AS pkgQty,
    		returnQty-(FLOOR(returnQty/pkgRatio)*pkgRatio) AS bulkQty,befPrice,discount,discountFee,price,taxrate,
    		ROUND(totalFee/(1+taxrate/100),2) AS fee,totalFee-ROUND(totalFee/(1+taxrate/100),2) AS taxFee,
    		totalFee,0.0,rebate,invoiceQty,invoiceFee,payQty,payFee,toOrder,isPromotion,groupId,@salesId,
    		@handlerId,@deptId,contractId,contractNo,remarks
    	FROM dbo.Sync_SMS_ReturnDtl_V 
    	WHERE returnNo=@orderNo;
        SET @errors=@errors+@@ERROR;
    	--更新订单状态(已同步，WMS订单号和最后修改时间）
    	UPDATE dbo.SMS_Return SET syncFlag=1,wmsOrder=@wmsOrder,editTime=@curTime WHERE ReturnNo=@orderNo;
        SET @errors=@errors+@@ERROR;
    	INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
    	VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,@funCode,'同步销售退货单[' + @orderNo + ']，同步成功',@wmsOrder,'EXEC dbo.sp_AfterSMS60Audit ''' + @orderNo + ''',''20'',' + CAST(@userId AS VARCHAR(10))); 
    	SET @errors=@errors+@@ERROR;
        --增加一个处理，审核后自动生成上架清单
    	EXEC YiWms.dbo.up_Audit_SalesReceive @wmsOrder,@operatorId;
    	SET @errors=@errors+@@ERROR;
        IF (@@ROWCOUNT>0)
    	BEGIN
    		INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
    		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,@funCode,'审核销售退货单，单据编号[' + @returnBillNo + ']',@wmsOrder,'EXEC dbo.up_Audit_SalesReceive ''' + @wmsOrder + ''',''' + @operatorId + ''';'); 	
    	    SET @errors=@errors+@@ERROR;
        END        
    END
    --取消采购订单审核
    IF (@billSts='10')
    BEGIN
    	SELECT @wmsOrder=returnNo FROM YiWms.dbo.SAD_Return WHERE companyId=@companyId AND ownerId=@ownerId AND billNo=@OrderNo; 
    	IF (ISNULL(@wmsOrder,'')!='')
    	BEGIN
    		--退货单已经审核（产生上架数据）则不许取消审核
    		IF EXISTS(SELECT * FROM YiWms.dbo.SAD_Return WHERE returnNo=@wmsOrder AND ioState IN(20,25,30))
    		BEGIN
    			--写入同步错误日志	
    			INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
    			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,@funCode,'YI_SR_CANCEL_SYNC_ERROR',
    				'销售退货单[' + @OrderNo + ']已经产生上架数据，取消操作失败',@OrderNo,@OrderNo);
                SET @errors=@errors+@@ERROR;
    		END
    		ELSE
    		BEGIN
    			DELETE FROM YiWms.dbo.SAD_ReturnDetail WHERE returnNo=@wmsOrder;
                SET @errors=@errors+@@ERROR;
    			DELETE FROM YiWms.dbo.SAD_Return WHERE returnNo=@wmsOrder;
                SET @errors=@errors+@@ERROR;
    			INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
    			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,@funCode,'取消销售退货单[' + @orderNo + ']，同步成功',@wmsOrder,'EXEC dbo.sp_AfterSMS60Audit ''' + @orderNo + ''',''10'',' + CAST(@userId AS VARCHAR(10))); 
                SET @errors=@errors+@@ERROR;
    		END
    	END
    END    
    IF (@errors=0)
    BEGIN
        COMMIT;
    END
    ELSE
    BEGIN
        IF @@TRANCOUNT > 0
            ROLLBACK;
        SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;		
        --写入同步错误日志	
        INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
        VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,@funCode,'YI_SR_SYNC_ERROR',LEFT(@ErrMsg,2000),@OrderNo,@OrderNo);
    END
END

go

