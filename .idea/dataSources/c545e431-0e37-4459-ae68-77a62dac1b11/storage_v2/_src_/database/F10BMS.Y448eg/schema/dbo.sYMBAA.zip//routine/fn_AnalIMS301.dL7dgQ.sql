--说明：库存资金占用分析
--作者：Devil.H
--创建：2010.08.03
--参数：
--	@DeptNo:部门
--	@WareHouse:仓库
--	@ClassID:商品大类
--	@LabelID:商品品牌
--	@ItemID:商品ID
--	@Flag:为前台设计
CREATE FUNCTION dbo.fn_AnalIMS301
(
	@DeptNo VARCHAR(20),
	@WareHouse VARCHAR(20),
	@ClassID VARCHAR(20),
	@LabelID VARCHAR(20),
	@ItemID BIGINT,
	@Flag INT
)
RETURNS @uTable TABLE(
	DeptID VARCHAR(20),
	DeptNo VARCHAR(20),
	DeptName VARCHAR(100),
	WareHouse VARCHAR(20),
	WHName VARCHAR(100),
	ItemNo VARCHAR(20),
	ItemName VARCHAR(200),
	ItemSpec VARCHAR(100),
	ItemAlias VARCHAR(200),
	Namespell VARCHAR(200),
	BarCode VARCHAR(100),
	ClassID VARCHAR(20),
	ClassName VARCHAR(100),
	LabelID VARCHAR(20),
	LabelName VARCHAR(100),
	ColorName VARCHAR(40),
	UnitName VARCHAR(40),
	PkgSpec VARCHAR(40),
	PkgQty DECIMAL(18,6),
	Price DECIMAL(18,6),
	OnHandQty DECIMAL(18,6),
	Amt DECIMAL(18,6),
	WAmt DECIMAL(18,6),
	IMSPercent DECIMAL(18,6),
	JHCstPrice DECIMAL(18,6), 	--参考成本价
	JHCstAmt DECIMAL(18,6),		--参考成本
	Defined1 VARCHAR(200),
	Defined2 VARCHAR(200),
	Defined3 VARCHAR(200),
	Defined4 VARCHAR(200),
	Defined5 VARCHAR(200)
	PRIMARY KEY(DeptID,WareHouse,ItemNo)
)
AS
BEGIN
    IF (@Flag=0) 
		RETURN;
    DECLARE @Period VARCHAR(6),@WAmt DECIMAL(18,6),@Year INT,@Month INT;
    DECLARE @Tmp TABLE(WareHouse VARCHAR(20), WAmt DECIMAL(18,6) PRIMARY KEY (WareHouse))
	DECLARE @CostTmp TABLE(DeptNo VARCHAR(20),ItemID BIGINT,Price DECIMAL(18,10) PRIMARY KEY(DeptNo,ItemID));
	DECLARE @StoreTmp TABLE(DeptNo VARCHAR(20),WareHouse VARCHAR(20),ItemID BIGINT,OnHandQty DECIMAL(18,6) PRIMARY KEY(DeptNo,WareHouse,ItemID));
	--会计期间
	SELECT @Period=CW_Period 
	FROM SYS_CW_MonthPeriod a
	WHERE EXISTS(SELECT * FROM SYS_GetDate_V b WHERE  b.Today BETWEEN a.StartDate AND a.EndDate);
    SET @Year=CAST(LEFT(@Period,4) AS INT);
	SET @Month=CAST(RIGHT(@Period,2) AS INT);
	--临时成本
    IF (@Flag=1)
    	INSERT INTO @CostTmp(DeptNo,ItemID,Price)
    	SELECT ISNULL(DeptNo,'$$$$'),ItemID,MEPrice
    	FROM uf_CostPrice(@Period) 
    IF (@Flag=2)
        INSERT INTO @CostTmp(DeptNo,ItemID,Price)
		SELECT DeptNo,ItemID,Price
		FROM CST_PlanPrice
		WHERE CstYear=@Year AND CstMonth=@Month; 
	--仓库数量
	INSERT INTO @StoreTmp(DeptNo,WareHouse,ItemID,OnHandQty)
	SELECT l.DeptNo,l.WareHouse,l.ItemID,l.OnHandQty
	FROM IMS_Ledger l
        INNER JOIN BDM_ItemInfo g ON l.ItemID=g.ItemID
	WHERE (l.WareHouse LIKE @WareHouse + '%')
		AND (l.DeptNo LIKE @DeptNo + '%')
		AND (@ItemID=0 OR l.ItemID=@ItemID)
		AND (ABS(ISNULL(l.OnHandQty,0.0))>0.0)
		AND (ISNULL(g.ClassID,'') LIKE @ClassID + '%')
		AND (ISNULL(g.LabelID,'') LIKE @LabelID + '%');
	--总体成本法
	IF EXISTS(SELECT * FROM SYS_Config WHERE ISNULL(Method,'S')='T')
		INSERT INTO @uTable(DeptID,DeptNo,DeptName,WareHouse,WHName,ItemNo,ItemName,ItemSpec,
			ItemAlias,NameSpell,BarCode,ClassID,ClassName,LabelID,LabelName,ColorName,UnitName,
			OnHandQty,Price,Amt,JHCstAmt,JHCstPrice,Defined1,Defined2,Defined3,Defined4,Defined5,
			PkgSpec,PkgQty)
		SELECT d.CodeID,d.CodeNo,d.CHName AS DeptName,l.WareHouse,w.CHName AS WHName,g.ItemNo,
            g.ItemName,g.ItemSpec,g.ItemAlias,g.NameSpell,g.BarCode,g.ClassID,g.ClassName,
			g.LabelID,g.LabelName,g.ColorName,g.UnitName,l.OnHandQty,cb.Price,
			ISNULL(l.OnHandQty,0.0)*ISNULL(cb.Price,0.0) AS Amt,
			ISNULL(l.OnHandQty,0.0)*ISNULL(jh.Cost,0.0) AS JHAmt,jh.Cost,
			g.Defined1,g.Defined2,g.Defined3,g.Defined4,g.Defined5,g.PkgSpec,
			CASE ISNULL(g.PkgRatio,0.0) WHEN 0.0 THEN NULL ELSE ROUND(ISNULL(l.OnHandQty,0.0)/g.PkgRatio,2) END
		FROM @StoreTmp l 
            LEFT JOIN @CostTmp cb ON cb.DeptNo='$$$$' AND l.ItemID=cb.ItemID 
			LEFT JOIN CST_Colligate_COST_Year jh ON l.ItemID=jh.ItemID AND jh.Period=@Period
			LEFT JOIN BDM_DeptCode_V d ON l.DeptNo=d.CodeID
			LEFT JOIN BDM_WareHouse_V w ON l.WareHouse=w.CodeID
			LEFT JOIN BAS_Goods_V g ON l.ItemID=g.ItemID;	
	ELSE
		INSERT INTO @uTable(DeptID,DeptNo,DeptName,WareHouse,WHName,ItemNo,ItemName,ItemSpec,
			ItemAlias,NameSpell,BarCode,ClassID,ClassName,LabelID,LabelName,ColorName,UnitName,
			OnHandQty,Price,Amt,JHCstAmt,JHCstPrice,Defined1,Defined2,Defined3,Defined4,Defined5,
			PkgSpec,PkgQty)
		SELECT d.CodeID,d.CodeNo,d.CHName AS DeptName,l.WareHouse,w.CHName AS WHName,g.ItemNo,
            g.ItemName,g.ItemSpec,g.ItemAlias,g.NameSpell,g.BarCode,g.ClassID,g.ClassName,
			g.LabelID,g.LabelName,g.ColorName,g.UnitName,l.OnHandQty,cb.Price,
			ISNULL(l.OnHandQty,0.0)*ISNULL(cb.Price,0.0) AS Amt,
			ISNULL(l.OnHandQty,0.0)*ISNULL(jh.Cost,0.0) AS JHAmt,jh.Cost,
			g.Defined1,g.Defined2,g.Defined3,g.Defined4,g.Defined5,g.PkgSpec,
			CASE ISNULL(g.PkgRatio,0.0) WHEN 0.0 THEN NULL ELSE ROUND(ISNULL(l.OnHandQty,0.0)/g.PkgRatio,2) END
		From @StoreTmp l 
            LEFT JOIN @CostTmp cb ON cb.DeptNo=l.DeptNo AND l.ItemID=cb.ItemID 
		    LEFT JOIN CST_Colligate_COST_Year jh ON l.ItemID=jh.ItemID And jh.Period=@Period
			LEFT JOIN BDM_DeptCode_V d ON l.DeptNo=d.CodeID
			LEFT JOIN BDM_WareHouse_V w ON l.WareHouse=w.CodeID
			LEFT JOIN BAS_Goods_V g On l.ItemID=g.ItemID;
	--获取商品总金额
	INSERT INTO @Tmp(WareHouse,WAmt)
	SELECT WareHouse,Sum(Amt)
	FROM @uTable 	
	GROUP BY WareHouse;
	--更新库房总金额
	UPDATE a SET a.WAmt=ISNULL(b.WAmt,0),
		         a.IMSPercent=CASE ISNULL(b.WAmt,0.0) WHEN 0.0 THEN 0.0 
						                              ELSE ROUND(ISNULL(a.Amt,0.0)/ISNULL(b.WAmt,0.0),6) END
	FROM @uTable a 
        INNER JOIN @Tmp b ON a.WareHouse=b.WareHouse;
    DELETE FROM @Tmp;
    DELETE FROM @CostTmp;
    DELETE FROM @StoreTmp;
	--返回
	RETURN;
END
go

