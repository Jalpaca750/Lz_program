--说明：系统报表之组装清单
--作者：Devil.H
--创建：2007.10.31
--参数：
--	@BillNo	 :单据编号
--	@Row	 :每页打印行数
--修改: 2021-08-07 商品名称等数据长度增长，并增加商品简称字段
CREATE FUNCTION dbo.uf_RPTIMS40
(
    @BillNo VARCHAR(20),
    @Row BIGINT,
    @OrderBy VARCHAR(30)
)
RETURNS @uTable TABLE(
    BillID BIGINT IDENTITY(1,1),
    BillNo VARCHAR(20),
    Location VARCHAR(20),
    ItemNo VARCHAR(20),
    ItemName VARCHAR(200),
    ItemAlias VARCHAR(200),
    Barcode VARCHAR(100),
    ItemSpec VARCHAR(100),
    ClassName VARCHAR(100),
    LabelName VARCHAR(100),
    ColorName VARCHAR(40),
    UnitName VARCHAR(40),
    PkgSpec VARCHAR(40),
    PkgQty DECIMAL(18,6),
    OQty DECIMAL(18,6),
    Price DECIMAL(18,6),
    Amt DECIMAL(18,6),
    PPrice DECIMAL(18,6),
    SPrice DECIMAL(18,6),
    SPrice1 DECIMAL(18,6),
    SPrice2 DECIMAL(18,6),
    SPrice3 DECIMAL(18,6),
    BPackage VARCHAR(40),
    MPackage VARCHAR(40),
    Package VARCHAR(40),
    Remarks VARCHAR(2000)
)
AS
BEGIN	
    DECLARE @Rows BIGINT;
    DECLARE @NullRow BIGINT;
    DECLARE @i BIGINT;
    --初始化变量
    SET @i=0;
    --如果没有传递行数，默认9行
    SET @Row=isnull(@Row,9);
    IF ISNULL(@BillNo,'')=''
        RETURN;
    IF UPPER(@OrderBy)='ASSEMBLYID'
        INSERT INTO @uTable(BillNo,Location,ItemNo,ItemName,ItemAlias,Barcode,ItemSpec,ClassName,
            LabelName,ColorName,UnitName,Price,PkgSpec,PkgQty,OQty,Amt,PPrice,SPrice,SPrice1,
            SPrice2,SPrice3,Remarks)
        SELECT AssemblyNo,Location,ItemNo,ItemName,ItemAlias,Barcode,ItemSpec,ClassName,LabelName,
            ColorName,UnitName,Price,PkgSpec,PkgQty,OQty,Amt,PPrice,SPrice,SPrice1,SPrice2,SPrice3,
            Remarks
        FROM IMS_AssemblyDtl_V
        WHERE AssemblyNo=@BillNo
        ORDER BY AssemblyID;
    IF UPPER(@OrderBy)='ITEMNO'
        INSERT INTO @uTable(BillNo,Location,ItemNo,ItemName,ItemAlias,Barcode,ItemSpec,ClassName,
            LabelName,ColorName,UnitName,Price,PkgSpec,PkgQty,OQty,Amt,PPrice,SPrice,SPrice1,SPrice2,
            SPrice3,Remarks)
        SELECT AssemblyNo,Location,ItemNo,ItemName,ItemAlias,Barcode,ItemSpec,ClassName,LabelName,
            ColorName,UnitName,Price,PkgSpec,PkgQty,OQty,Amt,PPrice,SPrice,SPrice1,SPrice2,SPrice3,
            Remarks
        FROM IMS_AssemblyDtl_V
        WHERE AssemblyNo=@BillNo
        ORDER BY ItemNo;
    IF UPPER(@OrderBy)='LOCATION'
        INSERT INTO @uTable(BillNo,Location,ItemNo,ItemName,ItemAlias,Barcode,ItemSpec,ClassName,
            LabelName,ColorName,UnitName,Price,PkgSpec,PkgQty,OQty,Amt,PPrice,SPrice,SPrice1,SPrice2,
            SPrice3,Remarks)
        SELECT AssemblyNo,Location,ItemNo,ItemName,ItemAlias,Barcode,ItemSpec,ClassName,LabelName,
            ColorName,UnitName,Price,PkgSpec,PkgQty,OQty,Amt,PPrice,SPrice,SPrice1,SPrice2,SPrice3,
            Remarks
        FROM IMS_AssemblyDtl_V
        WHERE AssemblyNo=@BillNo
        ORDER BY Location;
    --总的行数
    SELECT @Rows=COUNT(*) FROM @uTable;
    IF @Rows=0 
        RETURN;
    SET @NullRow=@Row-@Rows%@Row;
    IF @NullRow=@Row 
        RETURN;
    WHILE @i<@NullRow
    BEGIN
        INSERT INTO @uTable(BillNo)
        VALUES(@BillNo);
        SET @i=@i+1;
    END
    --返回
    RETURN;
END
go

