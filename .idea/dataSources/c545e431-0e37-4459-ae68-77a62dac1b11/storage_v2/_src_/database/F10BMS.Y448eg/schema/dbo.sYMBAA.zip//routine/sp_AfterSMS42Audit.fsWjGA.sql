CREATE proc sp_AfterSMS42Audit
(
	@CarNumberNo varchar(20),
	@BillSts char(2)
)
as
Begin
	DECLARE @msgTemplet VARCHAR(200)
	DECLARE @needSend bit
	--获取发车单短信配置
	SELECT @msgTemplet=msgTemplet,@needSend=needSend
	FROM SMS_MessageConfig 
	WHERE msgEvents='SMS42'

	IF @BillSts='20'
	BEGIN
		--送货员，联系电话
		DECLARE @DeliveryMan VARCHAR(100)
		DECLARE @Phone VARCHAR(100)
		DECLARE @Delivery BIGINT,@OrderNo VARCHAR(20),@StockNo VARCHAR(20)
		--送货员Id
		SELECT @Delivery=Delivery
		FROM SMS_CarNumber 
		WHERE CarNumberNo=@CarNumberNo
		--送货员名称、联系电话
		SELECT @DeliveryMan=EmployeeName,@Phone=Phone 
		FROM BDM_Employee 
		WHERE EmployeeId=@Delivery
		
		--替换送货员和电话
		SET @msgTemplet=Replace(@msgTemplet,'#DeliveryMan#',@DeliveryMan)
		SET @msgTemplet=Replace(@msgTemplet,'#Phone#',@Phone)
		--写入发送队列
		IF ISNULL(@needSend,0)<>0
			INSERT INTO SMS_Message(msgCreate,msgSource,mobileNo,msgText,sendState,isBatch,billType,billNo,expand1)	
			SELECT GetDate(),'系统',a.MobileNo,Replace(@msgTemplet,'#OrderNo#',a.OrderNo),0,
				Case Charindex(';',a.MobileNo) When 0 Then 0 ELSE 1 End, 
				'SMS42',a.OrderNo,@CarNumberNo
			FROM SMS_OrderMobile a INNER JOIN 
				(SELECT Distinct y.OrderNo 
				 FROM SMS_CarNumberdtl x INNER JOIN SMS_StockDtl y ON x.BillNo=y.StockNo
				 WHERE x.CarNumberNo=@CarNumberNo) t ON a.OrderNo=t.OrderNo	
		--物流状态列表

		DECLARE myCursor CURSOR
		FOR SELECT DISTINCT b.OrderNo,b.StockNo
		FROM SMS_CarNumberdtl a 
			INNER JOIN SMS_StockDtl b ON a.BillNo=b.StockNo
		WHERE a.CarNumberNo=@CarNumberNo
		OPEN myCursor
		FETCH NEXT FROM myCursor INTO @OrderNo,@StockNo
		WHILE @@FETCH_STATUS=0
		BEGIN
			DELETE FROM Web_OrderState WHERE orderNo=@OrderNo AND stockNo=@StockNo AND [action]=4;
			INSERT INTO Web_OrderState(orderNo,Content,CreateTime,StockNo,action)
			VALUES(@OrderNo, '您所订货品已经发出，送货员: ' + ISNULL(@DeliveryMan,'') + ' 电话: ' + ISNULL(@Phone,''),CONVERT(VARCHAR(20),GETDATE(),120),@StockNo,4);

			FETCH NEXT FROM myCursor INTO @OrderNo,@StockNo
		END
		CLOSE myCursor
		DEALLOCATE myCursor 


	END
	IF @BillSts='10'
		RETURN
End
go

