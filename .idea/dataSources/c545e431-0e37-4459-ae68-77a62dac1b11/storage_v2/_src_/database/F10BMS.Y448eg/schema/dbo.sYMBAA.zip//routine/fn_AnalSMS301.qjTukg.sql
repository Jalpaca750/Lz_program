

--说明：客户销售分析明晰
--作者：Devil.H
--创建：2007.11.06
--参数：
--	@CustID:客户
--  @SalesID:销售员ID
--	@DeptNo:分部
--	@CorpNo:公司
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@Flag :为前台设计
--修改：2021-03-17 增加销售员维度过滤
CREATE FUNCTION [dbo].[fn_AnalSMS301]
(	
	@CustID BIGINT=0,
	@SalesID BIGINT=0,
	@StartDate CHAR(10)='0000-01-01',
	@EndDate CHAR(10)='9999-12-31',
	@CorpNo VARCHAR(2)='',
	@DeptNo VARCHAR(20)='',
	@Flag BIT=0
)
RETURNs @uTable Table(
	ItemID BIGINT,
	ItemNo VARCHAR(20),
	ItemName VARCHAR(200),
	ItemSpec VARCHAR(100),
	ClassName VARCHAR(100),
	LabelName VARCHAR(100),
	ColorName VARCHAR(40),
	UnitName VARCHAR(40),
	PkgSpec VARCHAR(40),
	AvgPrice DECIMAL(18,6),
	SQty DECIMAL(18,6),
	RQty DECIMAL(18,6),
	TQty DECIMAL(18,6),
	PkgQty DECIMAL(18,6),
	SelAmt DECIMAL(18,6),
	RetAmt DECIMAL(18,6),
    RealAmt DECIMAL(18,6),            --实际销售额(去掉返点，平台费)
    RebateAmt DECIMAL(18,6),          --返点
    PlatformFee DECIMAL(18,6),        --平台费
	TotalAmt DECIMAL(18,6),
	SelPercent DECIMAL(18,6),
	RetPercent DECIMAL(18,6),
	R_SScale DECIMAL(18,6),
	R_SPercent DECIMAL(18,6)
)
AS
BEGIN
    IF (@Flag=0) 
		RETURN;
	DECLARE @SUMAmt DECIMAL(18,6),@SUMRAmt DECIMAL(18,6),@AmtDec INT;
	DECLARE @Tmp Table(ItemID BIGINT,RQty DECIMAL(18,6),SQty DECIMAL(18,6),RetAmt DECIMAL(18,6),SelAmt DECIMAL(18,6),TQty DECIMAL(18,6),RebateAmt DECIMAL(18,6),PlatformFee DECIMAL(18,6),TotalAmt DECIMAL(18,6));
	--初始化变量
	SET @StartDate=CONVERT(CHAR(10),CAST(@StartDate AS DATETIME),23);
	SET @EndDate=CONVERT(CHAR(10),CAST(@EndDate AS DATETIME),23);
    SELECT @AmtDec=ISNULL(AmtDec,2) FROM SYS_Config;
	--临时数据
	INSERT INTO @Tmp(ItemID,RQty,SQty,RetAmt,SelAmt,RebateAmt,PlatformFee,TQty,TotalAmt)
	SELECT b.ItemID,
		RQty=ABS(ISNULL(SUM(CASE a.BillType WHEN '20' THEN b.SQty ELSE 0.0 END),0.0))
			+ABS(ISNULL(SUM(CASE a.BillType WHEN '50' THEN b.SQty ELSE 0.0 END),0.0)),
		SQty=ISNULL(SUM(CASE a.BillType WHEN '10' THEN b.SQty ELSE 0.0 END),0.0)
			+ISNULL(SUM(CASE a.BillType When '40' THEN b.SQty ELSE 0.0 END),0.0),
		RAmt=ABS(ISNULL(SUM(CASE a.BillType WHEN '20' THEN b.Amt ELSE 0.0 END),0.0))
			+ABS(ISNULL(SUM(CASE a.BillType WHEN '50' THEN b.Amt ELSE 0.0 END),0.0)),
		SAmt=ISNULL(SUM(CASE a.BillType WHEN '10' THEN b.Amt ELSE 0.0 END),0.0)
			+ISNULL(SUM(CASE a.BillType WHEN '30' THEN b.Amt ELSE 0.0 END),0.0)
			+ISNULL(SUM(CASE a.BillType WHEN '40' THEN b.Amt ELSE 0.0 END),0.0),
        RebateAmt=ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0),@AmtDec),
        PlatformFee=ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0),@AmtDec),
		TQty=SUM(b.SQty),TotalAmt=SUM(b.Amt)
	FROM SMS_Stock a 
        INNER JOIN SMS_StockDtl b On a.StockNo=b.StockNo
        INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	WHERE a.CustID=@CustID
	    AND (a.SalesID=@SalesID)
        AND (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		AND (CONVERT(CHAR(10),CAST(a.CreateDate AS DATETIME),23) BETWEEN @StartDate AND @EndDate) 
		AND (a.DeptNo Like @DeptNo + '%')
		AND EXISTS(SELECT 1 
			       FROM BDM_DeptCode_V d 
			       WHERE (d.CodeID=a.DeptNo) AND (d.DeptNo Like @CorpNo + '%'))
	GROUP BY b.ItemID;
	--获取以上客户的总销售额
	SELECT @SUMAmt=SUM(SelAmt),@SUMRAmt=SUM(RetAmt) FROM @Tmp;
    --汇总数据
	INSERT INTO @uTable(ItemID,ItemNo,ItemName,ItemSpec,UnitName,ColorName,ClassName,LabelName,
        RQty,SQty,RetAmt,SelAmt,RebateAmt,PlatformFee,RealAmt,SelPercent,RetPercent,R_SPercent,
        AvgPrice,R_SScale,TQty,TotalAmt,PkgSpec,PkgQty)
	SELECT t.ItemID,g.ItemNo,g.ItemName,g.ItemSpec,g.UnitName,g.ColorName,g.ClassName,g.LabelName,
        t.RQty,t.SQty,t.RetAmt,t.SelAmt,t.RebateAmt,t.PlatformFee,t.TotalAmt-t.RebateAmt-t.PlatformFee,
        t.SelPercent,t.RetPercent,t.R_SPercent,t.AvgPrice,
        CASE ISNULL(t.SelPercent,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(t.RetPercent,0.0)/t.SelPercent,6) END,
        t.TQty,t.TotalAmt,g.PkgSpec,CASE ISNULL(g.PkgRatio,0.0) WHEN 0.0 THEN Null ELSE Round(ISNULL(t.TQty,0.0)/g.PkgRatio,4) END		
	FROM BAS_Goods_V g 
        INNER JOIN (SELECT ItemID,RQty,SQty,SelAmt,RetAmt,TQty,TotalAmt,RebateAmt,PlatformFee,
                        CASE ISNULL(@SUMAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(SelAmt,0.0)/@SUMAmt,6) END AS SelPercent,
                        CASE ISNULL(@SUMRAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(RetAmt,0.0)/@SUMRAmt,6) END AS RetPercent,
                        CASE ISNULL(SelAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(RetAmt,0.0)/SelAmt,6) END AS R_SPercent,
                        CASE ISNULL(SQty,0.0)-ISNULL(RQty,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND((ISNULL(SelAmt,0.0)-ISNULL(RetAmt,0.0))/(ISNULL(SQty,0.0)-ISNULL(RQty,0.0)),2) END AS AvgPrice 
                    FROM @Tmp) t ON t.ItemID=g.ItemID;
    DELETE FROM @Tmp;
	--返回
	RETURN;
END
go

