--说明：未付款发票分析
--作者：Devil.H
--创建：2007.11.26
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@Flag：标志
CREATE Function dbo.fn_AnalPMS7A
(
	@Flag bit=0
)
Returns Table
As
Return (SELECT a.InvoiceNo,a.CreateDate,a.DeptNo,d.CHName as DeptName,a.VendorID,
		v.VendorNo,v.VendorName,v.NameSpell,v.LinkMan,v.Phone,v.Faxes,
		v.BuyerID,v.Buyer,a.IType,i.CHName as ITName,a.Invoice,a.IAmt,
		a.DAmt,ISNULL(a.IAmt,0.0)-ISNULL(a.PAmt,0.0) AS RemAmt,a.IFlag,
		a.CreatorID,e.EmployeeName as Creator,a.Remarks,
		a.BillSts,(SELECT StsName 
			   FROM BillStatus s 
			   WHERE a.BillSts=s.BillSts And s.BillType='PMS90') AS StsName
	FROM PMS_Invoice a INNER JOIN BDM_Vendor_V v ON a.VendorID=v.VendorID
		LEFT OUTER JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
		LEFT OUTER JOIN BDM_InvoiceType_V i ON a.IType=i.CodeID
		LEFT OUTER JOIN BDM_Employee e ON a.CreatorID=e.EmployeeID
	WHERE (BillSts='20' Or BillSts='25') 
		And ISNULL(a.IAmt,0.0)-ISNULL(a.PAmt,0.0)<>0.0
)
go

