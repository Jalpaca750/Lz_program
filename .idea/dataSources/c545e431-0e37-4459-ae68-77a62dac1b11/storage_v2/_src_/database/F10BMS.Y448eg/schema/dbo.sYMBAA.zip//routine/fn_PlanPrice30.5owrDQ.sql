CREATE Function dbo.fn_PlanPrice30
(
	@DeptNo varchar(20),
	@CstYear bigint,
	@CstMonth bigint,
	@OnlyDepart int
)
Returns Table
AS
Return(Select ItemNo,ItemName,ItemSpec,ClassID,ClassName,LabelID,LabelName,ColorName,UnitName,PPrice
	From BDM_ItemInfo_V a
	Where @OnlyDepart=0 And 
	      Not Exists(Select 1 From CST_PlanPrice b 
		 	 Where a.ItemID=b.ItemID And b.CstYear=@CstYear And b.CstMonth=@CstMonth And b.DeptNo=@DeptNo)
	Union All
	Select ItemNo,ItemName,ItemSpec,ClassID,ClassName,LabelID,LabelName,ColorName,UnitName,PPrice
	From BDM_ItemInfo_V a
	Where @OnlyDepart=1 And 
	      Not Exists(Select 1 From CST_PlanPrice b 
			 Where a.ItemID=b.ItemID And b.CstYear=@CstYear And b.CstMonth=@CstMonth And b.DeptNo=@DeptNo)
	      And Exists(Select 1 From IMS_Subdepot c Where c.DeptNo=@DeptNo And a.ItemID=c.ItemID)
)
go

