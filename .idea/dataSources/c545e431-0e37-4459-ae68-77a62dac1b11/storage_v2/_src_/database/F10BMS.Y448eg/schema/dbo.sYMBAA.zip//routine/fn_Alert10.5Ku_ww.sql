--说明：未执行计划提醒
--作者：Devil.H
--创建：2010.03.24
--参数：
--	无
CREATE FUNCTION fn_Alert10
(
)
RETURNS TABLE
AS
RETURN (
    SELECT a.AllotNo,a.CreateDate,do.CHName AS DeptName,di.CHName AS DeptName_I,
		g.ItemNo,g.ItemName,g.ItemSpec,g.ColorName,g.UnitName,b.SQty,
		ISNULL(b.SQty,0.0)-ISNULL(b.IQty,0.0) AS RemIQty,
		e.EmployeeName AS Creator,a.Remarks
	FROM IMS_Allot a INNER JOIN IMS_AllotDtl b ON a.AllotNo=b.AllotNo
		INNER JOIN BDM_ItemInfo_V g ON g.ItemID=b.ItemID
		LEFT OUTER JOIN BDM_DeptCode_V do ON do.CodeID=a.DeptNo
		LEFT OUTER JOIN BDM_DeptCode_V di ON di.CodeID=a.DeptNo_I
		LEFT OUTER JOIN BDM_Employee e ON a.CreatorID=e.EmployeeID
	WHERE (a.BillSts='20' Or a.BillSts='10' Or a.BillSts='25')
		And (ISNULL(b.SQty,0.0)-ISNULL(b.IQty,0.0)<>0.0)
)
go

