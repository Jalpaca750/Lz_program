CREATE VIEW dbo.ANAL_IMS7H_V
AS
SELECT a.Period, a.DeptNo, c.CHName AS DeptName, a.WareHouse, 
      w.CHName AS WHName, a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, 
      b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, b.LabelID, b.LabelName, 
      b.ColorName, b.UnitName, a.QCQty, a.QCAmt, a.CGRK, a.CGRKAmt, a.DBRK, 
      a.DBRKAmt, a.ZPRK, a.ZPRKAmt, a.QTRK, a.QTRKAmt, a.ZZRK, a.ZZRKAmt, a.CXRK, 
      a.CXRKAmt, a.PDRK, a.PDRKAmt, a.YCDQty, a.YCDAmt, a.SumRK, a.SumRKAmt, 
      a.XSCK, a.XSCKAmt, a.LSCK, a.LSCKAmt, a.DBCK, a.DBCKAmt, a.ZPCK, a.ZPCKAmt, 
      a.QTCK, a.QTCKAmt, a.ZZCK, a.ZZCKAmt, a.CXCK, a.CXCKAmt, a.SumCK, 
      a.SumCKAmt, a.QMQty, a.QMPrice, a.QMAmt,CBSYAmt
FROM dbo.ANAL_IMS7H a LEFT OUTER JOIN
      dbo.BDM_DeptCode_V c ON a.DeptNo = c.CodeID LEFT OUTER JOIN
      dbo.BAS_Goods_V b ON a.ItemID = b.ItemID LEFT OUTER JOIN
      dbo.BDM_WareHouse_V w ON a.WareHouse = w.CodeID
go

