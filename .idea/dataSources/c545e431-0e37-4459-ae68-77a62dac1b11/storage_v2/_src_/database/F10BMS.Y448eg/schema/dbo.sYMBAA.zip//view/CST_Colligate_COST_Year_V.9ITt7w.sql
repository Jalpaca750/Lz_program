CREATE VIEW dbo.CST_Colligate_COST_Year_V
AS
SELECT a.SID,a.Period,a.ItemID,a.COST
,b.ItemNo, b.ItemName,b.ItemAlias, b.NameSpell, b.ItemSpec, b.BarCode, b.ClassID, b.ClassName,b.LabelID, b.LabelName, b.ColorName, b.UnitName 

FROM dbo.CST_Colligate_COST_Year a 
INNER JOIN dbo.BDM_ItemInfo_V b ON a.ItemID = b.ItemID 





go

