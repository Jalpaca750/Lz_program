
CREATE Proc sp_BillAuditing_unPass_AlertPause
(
	@TBLCODE varchar(10),	
	@BillNo varchar(20),
	@AuditingEmployeeID as bigint,
	@Flag char(2)

)
As
Begin
	declare @Auditing_dj 		numeric(9)
	set  @Auditing_dj =(SELECT Top 1 Auditing_dj  FROM  BillAuditing a where TblCode=@TBLCODE And billNo=@BillNo and Auditing_EmployeeID=@AuditingEmployeeID)
		
	if @Flag='T'--单据审批通过
		begin			
			update BillAuditing set Auditing_Status='0' where Auditing_Status='3' And TblCode=@TBLCODE And BillNo=@BillNo And Auditing_dj=@Auditing_dj
		End
	if @Flag='F'--单据审批未通过
		begin
			--将当前单据同层的单据修改为3，不提示其它人需要审批此单据
			update BillAuditing set Auditing_Status='3' where Auditing_Status='0' And TblCode=@TBLCODE And BillNo=@BillNo And Auditing_dj=@Auditing_dj
		End



End
go

