CREATE VIEW dbo.IMS_ItemInfo_V
AS
SELECT a.ItemID, a.ItemNo, a.ItemName, a.ItemAlias, a.NameSpell, a.BarCode, a.ItemSpec, 
      a.ClassID, b.CHName AS ClassName, a.LabelID, c.CHName AS LabelName, a.ColorName,
      a.UnitName, a.OnHandQty, ISNULL(a.OnHandQty, 0)-ISNULL(a.AllocQty, 0) AS AvailQty, ISNULL(y.Qty,0) As YZStockQty,
	--a.UnitName, a.OnHandQty, ISNULL(a.OnHandQty, 0)- ISNULL(a.AllocQty, 0) AS AvailQty,
      a.PkgSpec,
      Case Isnull(a.PkgRatio,0) When 0 then Null else Round(Isnull(a.OnHandQty,0)/Isnull(a.PkgRatio,0),4) End as PkgQty,
      a.BPackage, a.MPackage, a.Package, a.HotFlag, a.Flag, a.Remarks
FROM dbo.BDM_ItemInfo a LEFT OUTER JOIN
      dbo.BDM_LabelCode_V c ON a.LabelID = c.CodeID LEFT OUTER JOIN
      dbo.BDM_ItemClass_V b ON a.ClassID = b.CodeID
left join IMS_YZStock_Sum_ItemID_V Y on a.ItemID=Y.ItemID




go

