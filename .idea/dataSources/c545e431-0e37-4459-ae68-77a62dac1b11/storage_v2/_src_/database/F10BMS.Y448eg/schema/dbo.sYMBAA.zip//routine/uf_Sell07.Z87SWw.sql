--说明：客户销售毛利统计
--作者：Devil.H
--创建：2006.12.20
--参数：
--	@Year:年度
--	@Month:自然月分
--	@CorpNo：公司
--	@DeptNo:部门
--	@Flag:前台标识
CREATE Function dbo.uf_Sell07
(
	@Year int=0,
	@Month int=0,
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	CustID bigint,
	CustNo varchar(20),
	CustName varchar(80),
	NameSpell varchar(80),
	CustType varchar(20),
	MemberID varchar(20),
	AreaCode varchar(20),
	AreaName varchar(40),
	PopedomID varchar(20),
	PopedomName varchar(40),
	SalesID bigint,
	Sales varchar(40),
	SQty decimal(18,6),
	Amt decimal(18,6),
	NoTaxAmt decimal(18,6),
	CstAmt decimal(18,6),
	NoTaxCstAmt decimal(18,6),
	GProAmt decimal(18,6),
	NoTaxGProAmt decimal(18,6),
	GProfit decimal(18,6)
)
--加密
--with encryption
As
begin
	if @Flag=0 
		Return
	declare @AmtDec int
	Select @AmtDec=Isnull(AmtDec,2) From Sys_Config
	--按客户汇总
	if isnull(@CorpNo,'')='' And isnull(@DeptNo,'')=''
		Insert Into @uTable(CustID,SQty,Amt,NoTaxAmt,CstAmt,NoTaxCstAmt)
		Select CustID,Sum(SQty),Sum(Amt),
			Sum(Round(Isnull(Amt,0)/(1+isnull(TaxRate,0.17)),@AmtDec+2)),
			Sum(round(isnull(SQty,0)*isnull(CPrice,0),@AmtDec)),
			Sum(round(isnull(SQty,0)*isnull(CPrice,0)/(1+isnull(TaxRate,0.17)),@AmtDec+2))
		From SMS_StockDtl_V
		Where BillSts Not In('00','10') And Year(CreateDate)=@Year And Month(CreateDate)=@Month
		Group By CustID
	--按部门汇总
	if isnull(@CorpNo,'')='' And (Not isnull(@DeptNo,'')='')
		Insert Into @uTable(CustID,SQty,Amt,NoTaxAmt,CstAmt,NoTaxCstAmt)
		Select CustID,Sum(SQty),Sum(Amt),
			Sum(Round(Isnull(Amt,0)/(1+isnull(TaxRate,0.17)),@AmtDec+2)),
			Sum(round(isnull(SQty,0)*isnull(CPrice,0),@AmtDec)),
			Sum(round(isnull(SQty,0)*isnull(CPrice,0)/(1+isnull(TaxRate,0.17)),@AmtDec+2))
		From SMS_StockDtl_V
		Where BillSts Not In('00','10') And DeptNo=@DeptNo And 
			Year(CreateDate)=@Year And Month(CreateDate)=@Month
		Group By CustID
	--按公司汇总
	if (Not isnull(@CorpNo,'')='') And isnull(@DeptNo,'')=''
		Insert Into @uTable(CustID,SQty,Amt,NoTaxAmt,CstAmt,NoTaxCstAmt)
		Select CustID,Sum(SQty),Sum(Amt),
			Sum(Round(Isnull(Amt,0)/(1+isnull(TaxRate,0.17)),@AmtDec+2)),
			Sum(round(isnull(SQty,0)*isnull(CPrice,0),@AmtDec)),
			Sum(round(isnull(SQty,0)*isnull(CPrice,0)/(1+isnull(TaxRate,0.17)),@AmtDec+2))
		From SMS_StockDtl_V
		Where BillSts Not In('00','10')  
			And Year(CreateDate)=@Year And Month(CreateDate)=@Month
			And DeptNo In(Select CodeID From BDM_DeptCode_V Where DeptNo=@CorpNo)
		Group By CustID
	--按公司部门汇总
	if (Not isnull(@CorpNo,'')='') And (Not isnull(@DeptNo,'')='')
		Insert Into @uTable(CustID,SQty,Amt,NoTaxAmt,CstAmt,NoTaxCstAmt)
		Select CustID,Sum(SQty),Sum(Amt),
			Sum(Round(Isnull(Amt,0)/(1+isnull(TaxRate,0.17)),@AmtDec+2)),
			Sum(round(isnull(SQty,0)*isnull(CPrice,0),@AmtDec)),
			Sum(round(isnull(SQty,0)*isnull(CPrice,0)/(1+isnull(TaxRate,0.17)),@AmtDec+2))
		From SMS_StockDtl_V
		Where BillSts Not In('00','10') And DeptNo=@DeptNo
			And Year(CreateDate)=@Year And Month(CreateDate)=@Month
			And DeptNo In(Select CodeID From BDM_DeptCode_V Where DeptNo=@CorpNo)
		Group By CustID
	--更新客户资料,计算毛利、毛利率
	Update a Set a.CustNo=b.CustNo,a.CustName=b.CustName,a.NameSpell=b.NameSpell,a.CustType=b.CustType,
		a.MemberID=b.MemberID,a.AreaCode=b.AreaCode,a.PopedomID=b.PopedomID,a.SalesID=b.SalesID,
		a.AreaName=b.AreaName,a.PopedomName=b.PopedomName,a.Sales=b.Sales,
		a.GProAmt=isnull(a.Amt,0)-isnull(a.CstAmt,0),
		a.NoTaxGProAmt=isnull(a.NoTaxAmt,0)-isnull(a.NoTaxCstAmt,0),
		GProfit=case isnull(a.Amt,0) 
			When 0 then 0 
			else round((isnull(a.Amt,0)-isnull(a.CstAmt,0))/isnull(a.Amt,0),4) End
	From @uTable a inner join BDM_Customer_V b on a.CustID=b.CustID
	--返回
	Return
End
go

