

CREATE Function dbo.fn_DeliveryCar
(
	@BillNo varchar(20),
	@LineID varchar(20)
)
Returns Table
As
Return
(
	SELECT a.CustID,b.CustNo,b.CustName,a.SendAddr,a.LinkMan,a.Phone,t.ZQty,t.ZAmt,
	      CASE a.BillType WHEN '10' THEN '销售出库单' WHEN '20' THEN '销售退货单' END AS BillType,
	      a.StockNo AS BillNo,b.AreaCode,b.PopedomName,a.Remarks,a.CarNumberSts,a.DispatcherID,
	      a.PH_OperatorID,a.PartQty,c.ViewOrder,Isnull(a.SendDate,a.CreateDate) As SendDate
	FROM dbo.SMS_Stock a INNER JOIN
	      (SELECT StockNo,SUM(ISNULL(SQty,0.0)+ISNULL(ZQty,0.0)) As ZQty,SUM(Amt) As ZAmt
	       From dbo.SMS_StockDtl
	       GROUP BY StockNo) t ON a.StockNo=t.StockNo INNER JOIN
	      dbo.BAS_Customer_V b ON a.CustID=b.CustID LEFT OUTER JOIN
	      dbo.BDM_SendAddress c ON a.CustID=c.CustID And a.SendAddr=c.SendAddr And a.LinkMan=c.LinkMan
	WHERE (a.StockNo Like @BillNo + '%')
	      AND (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
	      AND (a.BillType='10' Or a.BillType='20')
	      AND (a.LineID=@LineID) AND (ISNULL(a.CarNumberSts,'')='')
	Union All
	SELECT a.CustID,b.CustNo,b.CustName,a.SendAddr,a.LinkMan,a.Phone,1 AS ZQty,a.IAmt AS ZAmt,
	      '销售发票' AS BillType,a.InvoiceNo AS BillNo,b.AreaCode,b.PopedomName,a.Remarks,
	      a.CarNumberSts,0,0,1 As PartQty,c.ViewOrder,a.CreateDate
	FROM dbo.SMS_Invoice a INNER JOIN
	      dbo.BAS_Customer_V b ON a.CustID=b.CustID LEFT OUTER JOIN
	      dbo.BDM_SendAddress c ON a.CustID=c.CustID And a.SendAddr=c.SendAddr And a.LinkMan=c.LinkMan
	WHERE (a.InvoiceNo Like @BillNo + '%')
	      And (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
              AND (c.LineID=@LineID) AND (ISNULL(a.CarNumberSts,'')='')
	Union All
	SELECT a.CustID,b.CustNo,b.CustName,b.SendAddr,b.LinkMan,b.Phone,1 AS ZQty,a.Amt AS ZAmt,
	      '销售收款单' AS BillType,a.PaymentNo AS BillNo,b.AreaCode,b.PopedomName,a.Remarks,
	      a.CarNumberSts,0,0,1 As PartQty,9999 AS ViewOrder,a.CreateDate
	FROM dbo.SMS_Payment a INNER JOIN
	      dbo.BAS_Customer_V b ON a.CustID=b.CustID
	WHERE (a.PaymentNo Like @BillNo + '%') AND (ISNULL(a.CarNumberSts,'')='')
	Union All
	SELECT a.CustID,b.CustNo,b.CustName,a.SendAddr,c.LinkMan,c.Phone,1 AS ZQty,a.ProjectAmt AS ZAmt,
	      '项目订单' AS BillType,a.BillNo,b.AreaCode,b.PopedomName,a.ProjectSubject AS Remarks,
	      a.CarNumberSts,0,0,a.PartQty,c.ViewOrder,a.ExecBegin
	FROM dbo.PRJ_Order a INNER JOIN
	      dbo.BAS_Customer_V b ON a.CustID=b.CustID LEFT OUTER JOIN
	      dbo.BDM_SendAddress c ON a.CustID=c.CustID And a.SendAddr=c.SendAddr And a.LinkMan=c.LinkMan
	WHERE (a.BillNo Like @BillNo + '%')
	      And (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
              AND (c.LineID=@LineID) AND (ISNULL(a.CarNumberSts,'')='')
	Union All
	SELECT DeptNo_I AS CustID,DeptCode_I AS CustNo,DeptName_I As CustName,'从' + DeptName + '到' + DeptName_I AS SendAddr,
	      '' AS LinkMan,'' AS Phone,ZQty,ZAmt,'调拨出库单' AS BillType,AllotNo AS BillNo,
	      '' AS AreaCode,'' AS PopedomName,Remarks,CarNumberSts,0,0,PartQty,9999 AS ViewOrder,CreateDate
	From dbo.IMS_Allot_V
	WHERE (AllotNo Like @BillNo + '%')
	    And (BillSts='20' Or BillSts='25' Or BillSts='30') 
        AND (ISNULL(CarNumberSts,'')='') AND (LineID=@LineID)
)
go

