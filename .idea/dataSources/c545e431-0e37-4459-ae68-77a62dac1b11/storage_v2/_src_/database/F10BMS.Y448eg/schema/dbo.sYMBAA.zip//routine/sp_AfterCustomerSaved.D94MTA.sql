-- =============================================
-- Author:	    <Frank.He>
-- Create date: <2017-07-08>
-- Description:	<客户资料保存后同步到WMS对应的表>
-- Parameter:   
--      @custNo 客户编码
-- =============================================
CREATE PROCEDURE [dbo].[sp_AfterCustomerSaved]
(
	@custNo VARCHAR(20)
)
AS
BEGIN	
	DECLARE @companyId VARCHAR(32),			--公司Id
			@ownerId VARCHAR(32),			--业主Id
			@operatorId VARCHAR(32),		--操作员Id	
			@curTime DATETIME,				--当前日期
			@partnerType INT;				--1-客户;
			
	DECLARE @CustID BIGINT,					--F10客户Id
			@partnerId VARCHAR(32),			--客户Id
			@partnerName VARCHAR(200),		--客户名称
			@partnerSpell VARCHAR(200),		--客户名称拼音
			@companyAddress VARCHAR(100),	--客户地址
			@Flag CHAR(1),					--客户状态
			@zip VARCHAR(10),				--邮编
			@receiverAddress VARCHAR(100),
			@remarks VARCHAR(1000),			--备注
			@contactName VARCHAR(40),		--联系人名称
			@sex VARCHAR(10),				--性别
			@phone VARCHAR(80),				--联系人电话（私人电话）
			@contactTitle VARCHAR(40),		--职位
            @errors BIGINT;

    --如果WMS接口未开启，直接退出
	IF NOT EXISTS(SELECT * FROM dbo.SYS_Config WHERE ISNULL(startWMS,0)=1)
	    RETURN;
	IF EXISTS(SELECT 1 FROM dbo.BDM_Customer WHERE CustNo=@custNo AND syncFlag=1)
		RETURN;
	SELECT TOP 1 @companyId=companyId,@operatorId=IOperatorId,@ownerId=OwnerId FROM dbo.SYS_Config;
	SET @curTime=GETDATE();
	SET @partnerType=1;

	--获取公司默认联系人，性别、电话、职位
	SELECT @CustID=CustID,@partnerName=CustName,@partnerSpell=NameSpell,@companyAddress=CustAddr,
		@zip=PostalCode,@contactName=LinkMan,@sex=CASE sex WHEN 1 THEN '男' WHEN 0 THEN '女' END,
		@Phone=PerPhone,@contactTitle=JobName,@Flag=Flag,@remarks=Remarks
	FROM dbo.BDM_Customer 
	WHERE CustNo=@custNo;
	SET @errors=0;
	BEGIN TRANSACTION
	--查找是否已经写入系统
	IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.BAS_Partner WHERE companyId=@companyId AND partnerType=@partnerType AND ownerId=@ownerId AND partnerNo=@custNo)
	BEGIN
		SET @partnerId=LOWER(REPLACE(NEWID(),'-',''));
		--新建客户资料
		INSERT INTO YiWms.dbo.BAS_Partner(partnerType,companyId,ownerId,partnerId,partnerNo,
			partnerName,shortName,partnerSpell,reportTitle,reportCode,companyAddress,zip,partnerState,
			isLocked,lockerId,lockedTime,createTime,creatorId,editTime,editorId,remarks)
		VALUES(@partnerType,@companyId,@ownerId,@partnerId,@custNo,
			@partnerName,'',@partnerSpell,'','',@companyAddress,@zip,@Flag,
			0,'',NULL,@curTime,@operatorId,@curTime,@operatorId,@remarks);
        SET @errors=@errors+@@ERROR;
		--写入客户默认联系人
		INSERT INTO YiWms.dbo.BAS_Contact(contactId,companyId,partnerId,contactName,sex,contactTitle,
			officeTel,mobileNo,email,education,interest,ages,partnerType,isDefault,isDisable,isLocked,
			lockerId,lockedTime,createTime,creatorId,editTime,editorId)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@partnerId,@contactName,@sex,@contactTitle,
			@phone,'','','','','',@partnerType,1,0,0,'',NULL,@curTime,@operatorId,@curTime,@operatorId);
        SET @errors=@errors+@@ERROR;
		--写入操作日志
		INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCustomerSaved',
			'通过接口同步客户资料，客户编码:[' + @custNo + '],客户名称:[' + @partnerName + ']',
			@partnerId,@CustNo);	
        SET @errors=@errors+@@ERROR;
	END
	ELSE
	BEGIN
		SELECT @partnerId=partnerId
		FROM YiWms.dbo.BAS_Partner 
		WHERE companyId=@companyId AND partnerType=@partnerType AND ownerId=@ownerId AND partnerNo=@custNo;
		--修改客户资料
		UPDATE  YiWms.dbo.BAS_Partner SET partnerName=@partnerName,
											   partnerSpell=@partnerSpell,
											   companyAddress=@companyAddress,
											   zip=@zip,
											   partnerState=@Flag,
											   editTime=@curTime,
											   editorId=@operatorId,
											   remarks=@remarks
		WHERE partnerId=@partnerId;
        SET @errors=@errors+@@ERROR;
		--修改客户默认联系人
		UPDATE YiWms.dbo.BAS_Contact SET contactName=@contactName,
											  sex=@sex,
											  contactTitle=@contactTitle,
											  officeTel=@phone,
											  mobileNo='',
											  email='',
											  editTime=@curTime,
											  editorId=@operatorId
		WHERE partnerId=@partnerId AND isDefault=1;
        SET @errors=@errors+@@ERROR;
		--写入操作日志
		INSERT INTO YiWms.dbo.SAM_Log(logId,companyId,operatorId,createTime,functionName,description,billId,sqlText)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,@operatorId,@curTime,'sp_AfterCustomerSaved',
			'通过接口同步客户资料，客户编码:[' + @custNo + '],客户名称:[' + @partnerName + ']',
			@partnerId,@CustNo);
        SET @errors=@errors+@@ERROR;
	END		
	--客户地址
	DECLARE myCursor CURSOR
	FOR SELECT SendAddr
	    FROM dbo.BDM_SendAddress
	    WHERE CustID=@CustID
	OPEN myCursor
	FETCH NEXT FROM myCursor INTO @receiverAddress
	WHILE @@FETCH_STATUS=0
	BEGIN
		EXEC sp_AfterAddressSaved @custId,@receiverAddress
        SET @errors=@errors+@@ERROR;
		FETCH NEXT FROM myCursor INTO @receiverAddress
	END
	CLOSE myCursor
	DEALLOCATE myCursor		
	--更新客户资料同步状态
	UPDATE dbo.BDM_Customer SET syncFlag=1 WHERE CustNo=@custNo;		
    SET @errors=@errors+@@ERROR;
    IF (@errors=0)
    BEGIN
		COMMIT
    END
    ELSE
	BEGIN
		IF @@TRANCOUNT > 0
			 ROLLBACK
		DECLARE @ErrMsg nvarchar(4000), @ErrSeverity int
		SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;
		RAISERROR(@ErrMsg, @ErrSeverity, 1)	
		--写入同步错误日志	
		INSERT INTO YiWms.dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterCustomerSaved','YI_CUSTOMER_SYNC_ERROR',LEFT(@ErrMsg,2000),@partnerId,@custNo);
	END
END
go

