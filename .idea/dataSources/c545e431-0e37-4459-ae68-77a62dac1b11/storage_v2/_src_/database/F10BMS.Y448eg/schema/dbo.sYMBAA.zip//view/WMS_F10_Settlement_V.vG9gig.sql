

/*==============================================================*/
/* View: WMS_F10_Settlement_V                                   */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_Settlement_V] as
SELECT CodeID,b.settlementId
FROM dbo.BDM_SendMode_V a
	INNER JOIN YiWms.dbo.BAS_Settlement b ON a.CodeID=b.settlementNo
WHERE EXISTS(SELECT * FROM SYS_Config c WHERE b.companyId=c.companyId)
go

