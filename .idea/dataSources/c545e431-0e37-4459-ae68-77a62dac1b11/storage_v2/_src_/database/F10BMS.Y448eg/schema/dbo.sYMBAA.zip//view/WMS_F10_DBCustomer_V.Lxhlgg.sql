

/*==============================================================*/
/* View: WMS_F10_DBCustomer_V                                   */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_DBCustomer_V] as
SELECT a.CodeID AS deptId,a.CHName AS deptName,p.partnerId AS customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,
    p.fullAddress AS receiverAddress,p.contactName AS receiverName,p.officeTel AS receiverTel
FROM dbo.BDM_DeptCode_V a
	INNER JOIN YiWms.dbo.BAS_Partner_V p ON a.CodeID=p.partnerNo
WHERE EXISTS(SELECT 1 FROM dbo.SYS_Config b WHERE p.companyId=b.companyId AND p.ownerId=b.OwnerId AND p.partnerType=1)
go

