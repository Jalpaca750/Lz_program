--说明：商品年度采购分析
--作者：Devil.H
--创建：2007.11.23
--参数：
--	@Year:年度
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:标识
CREATE Function dbo.fn_AnalPMS40
(
	@Year int=0,
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	NameSpell varchar(200),
	ItemAlias varchar(200),
	ItemSpec varchar(100),
	BarCode varchar(100),
	ClassID varchar(20),
	ClassName Varchar(100),
	LabelID varchar(20),
	LabelName varchar(100),
	ColorName varchar(40),
	UnitName varchar(40),
	PkgSpec varchar(40),
	Month01Amt decimal(18,6),
	Month02Amt decimal(18,6),
	Month03Amt decimal(18,6),
	Month04Amt decimal(18,6),
	Month05Amt decimal(18,6),
	Month06Amt decimal(18,6),
	Month07Amt decimal(18,6),
	Month08Amt decimal(18,6),
	Month09Amt decimal(18,6),
	Month10Amt decimal(18,6),
	Month11Amt decimal(18,6),
	Month12Amt decimal(18,6),
	Month01Qty decimal(18,6),
	Month02Qty decimal(18,6),
	Month03Qty decimal(18,6),
	Month04Qty decimal(18,6),
	Month05Qty decimal(18,6),
	Month06Qty decimal(18,6),
	Month07Qty decimal(18,6),
	Month08Qty decimal(18,6),
	Month09Qty decimal(18,6),
	Month10Qty decimal(18,6),
	Month11Qty decimal(18,6),
	Month12Qty decimal(18,6),
	Month01Pkg decimal(18,6),
	Month02Pkg decimal(18,6),
	Month03Pkg decimal(18,6),
	Month04Pkg decimal(18,6),
	Month05Pkg decimal(18,6),
	Month06Pkg decimal(18,6),
	Month07Pkg decimal(18,6),
	Month08Pkg decimal(18,6),
	Month09Pkg decimal(18,6),
	Month10Pkg decimal(18,6),
	Month11Pkg decimal(18,6),
	Month12Pkg decimal(18,6),
	TotalQty decimal(18,6),
	TotalAmt decimal(18,6),
	TotalPkg decimal(18,6)
)
As
Begin
	if @Flag=0
		return

	Insert Into @uTable(ItemID,
			Month01Amt,Month02Amt,Month03Amt,Month04Amt,Month05Amt,Month06Amt,
			Month07Amt,Month08Amt,Month09Amt,Month10Amt,Month11Amt,Month12Amt,
			Month01Qty,Month02Qty,Month03Qty,Month04Qty,Month05Qty,Month06Qty,
			Month07Qty,Month08Qty,Month09Qty,Month10Qty,Month11Qty,Month12Qty,
			TotalQty,TotalAmt)
	Select b.ItemID,
		Month01Amt=SUM(CASE Month(a.CreateDate) when 1 then b.Amt else 0.0 end),
		Month02Amt=SUM(CASE Month(a.CreateDate) when 2 then b.Amt else 0.0 end),
		Month03Amt=SUM(CASE Month(a.CreateDate) when 3 then b.Amt else 0.0 end),
		Month04Amt=SUM(CASE Month(a.CreateDate) when 4 then b.Amt else 0.0 end),
		Month05Amt=SUM(CASE Month(a.CreateDate) when 5 then b.Amt else 0.0 end),
		Month06Amt=SUM(CASE Month(a.CreateDate) when 6 then b.Amt else 0.0 end),
		Month07Amt=SUM(CASE Month(a.CreateDate) when 7 then b.Amt else 0.0 end),
		Month08Amt=SUM(CASE Month(a.CreateDate) when 8 then b.Amt else 0.0 end),
		Month09Amt=SUM(CASE Month(a.CreateDate) when 9 then b.Amt else 0.0 end),
		Month10Amt=SUM(CASE Month(a.CreateDate) when 10 then b.Amt else 0.0 end),
		Month11Amt=SUM(CASE Month(a.CreateDate) when 11 then b.Amt else 0.0 end),
		Month12Amt=SUM(CASE Month(a.CreateDate) when 12 then b.Amt else 0.0 end),
		Month01Qty=SUM(CASE Month(a.CreateDate) when 1 then b.Sqty else 0.0 end),
		Month02Qty=SUM(CASE Month(a.CreateDate) when 2 then b.Sqty else 0.0 end),
		Month03Qty=SUM(CASE Month(a.CreateDate) when 3 then b.Sqty else 0.0 end),
		Month04Qty=SUM(CASE Month(a.CreateDate) when 4 then b.Sqty else 0.0 end),
		Month05Qty=SUM(CASE Month(a.CreateDate) when 5 then b.Sqty else 0.0 end),
		Month06Qty=SUM(CASE Month(a.CreateDate) when 6 then b.Sqty else 0.0 end),
		Month07Qty=SUM(CASE Month(a.CreateDate) when 7 then b.Sqty else 0.0 end),
		Month08Qty=SUM(CASE Month(a.CreateDate) when 8 then b.Sqty else 0.0 end),
		Month09Qty=SUM(CASE Month(a.CreateDate) when 9 then b.Sqty else 0.0 end),
		Month10Qty=SUM(CASE Month(a.CreateDate) when 10 then b.Sqty else 0.0 end),
		Month11Qty=SUM(CASE Month(a.CreateDate) when 11 then b.Sqty else 0.0 end),
		Month12Qty=SUM(CASE Month(a.CreateDate) when 12 then b.Sqty else 0.0 end),
		TotalQty=SUM(b.Sqty),TotalAmt=SUM(b.Amt)
	FROM PMS_Stock a INNER JOIN PMS_Stockdtl b ON a.StockNo=b.StockNo
	WHERE Year(a.CreateDate)=@Year And (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		And a.DeptNo=@DeptNo
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And d.DeptNo=@CorpNo)
	GROUP BY b.ItemID
	--更新
	Update a Set a.ItemNo=b.ItemNo,a.ItemName=b.ItemName,a.ItemSpec=b.ItemSpec,a.NameSpell=b.NameSpell,
		a.ItemAlias=b.ItemAlias,a.BarCode=b.BarCode,a.ClassID=b.ClassID,a.LabelID=b.LabelID,
		a.UnitName=b.UnitName,a.ColorName=b.ColorName,a.PkgSpec=b.PkgSpec,
		a.Month01Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month01Qty,0.0)/b.PkgRatio,4) End,
		a.Month02Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month02Qty,0.0)/b.PkgRatio,4) End,
		a.Month03Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month03Qty,0.0)/b.PkgRatio,4) End,
		a.Month04Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month04Qty,0.0)/b.PkgRatio,4) End,
		a.Month05Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month05Qty,0.0)/b.PkgRatio,4) End,
		a.Month06Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month06Qty,0.0)/b.PkgRatio,4) End,
		a.Month07Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month07Qty,0.0)/b.PkgRatio,4) End,
		a.Month08Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month08Qty,0.0)/b.PkgRatio,4) End,
		a.Month09Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month09Qty,0.0)/b.PkgRatio,4) End,
		a.Month10Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month10Qty,0.0)/b.PkgRatio,4) End,
		a.Month11Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month11Qty,0.0)/b.PkgRatio,4) End,
		a.Month12Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month12Qty,0.0)/b.PkgRatio,4) End,
		a.TotalPkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.TotalQty,0.0)/b.PkgRatio,4) End
	From @uTable a inner join BDM_ItemInfo_V b on a.ItemID=b.ItemID
	--返回
	Return
End
go

