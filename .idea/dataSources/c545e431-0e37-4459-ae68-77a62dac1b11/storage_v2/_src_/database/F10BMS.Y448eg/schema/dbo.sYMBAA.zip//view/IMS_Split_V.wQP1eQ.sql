CREATE VIEW [dbo].[IMS_Split_V]
AS
SELECT a.SplitNo, a.CreateDate, a.DeptNo, b.CHName AS DeptName, a.WareHouse_I, 
      c.CHName AS WHName_I, a.WareHouse_O, d.CHName AS WHName_O, a.ItemID, e.ItemNo, 
      e.ItemName, e.ItemAlias, e.NameSpell, e.ItemSpec, e.BarCode, e.ClassID, e.ClassName, 
      e.LabelID, e.LabelName, e.ColorName, e.UnitName, a.OQty, a.Price, a.Amt, a.BillSts, 
      (SELECT StsName FROM BillStatus f WHERE a.BillSts=f.BillSts AND f.BillType = 'IMS50') AS StsName, 
      a.PFlag, a.AuditID, g.EmployeeName AS Auditer, a.AuditDate, a.CreatorID, h.EmployeeName AS Creator, 
      a.PrintNum, a.PrinterID, P.EmployeeName AS Printer, a.Remarks, a.CheckBox
FROM dbo.IMS_Split a LEFT OUTER JOIN
      dbo.BDM_Employee h ON a.CreatorID = h.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee g ON a.AuditID = g.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID LEFT OUTER JOIN
      dbo.BAS_Goods_V e ON a.ItemID = e.ItemID LEFT OUTER JOIN 
      dbo.BDM_WareHouse_V d ON d.CodeID = a.WareHouse_O LEFT OUTER JOIN
      dbo.BDM_WareHouse_V c ON a.WareHouse_I = c.CodeID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID
go

