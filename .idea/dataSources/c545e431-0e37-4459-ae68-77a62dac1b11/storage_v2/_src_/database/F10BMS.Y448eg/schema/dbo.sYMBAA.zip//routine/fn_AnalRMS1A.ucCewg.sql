--说明：分部零售商品明细分析
--作者：Devil.H
--创建：2007.11.21
--修改：2010.05.08 Frank.H
--参数：
--	@StartDate:起始日期
--	@EndDate：截止日期
--	@DeptNo:分部
--	@CorpNo:公司
--	@Flag: 分析标识
CREATE Function dbo.fn_AnalRMS1A
(
	@StartDate varchar(10),
	@EndDate varchar(10),
	@DeptNo varchar(20),
	@Flag bit
)
Returns Table
As
Return (
	SELECT b.RetailID,a.RetailNo,a.CreateDate,a.CreateTime,a.WareHouse,
		w.CHName AS WHName,a.DeptNo,d.CHName AS DeptName,a.PCNo,
		a.CustID,c.CustNo,c.CustName,c.NameSpell AS CustSpell,
		CASE a.BillType WHEN '40' THEN '零售出库单' 
				WHEN '50' THEN '零售退货单' END AS BillType,
       		CASE a.CashFlag WHEN 'A' THEN '现金' 
				WHEN 'B' THEN '支票' 
				WHEN 'C' THEN '刷卡'
       				WHEN 'D' THEN '抵用券' 
				WHEN 'E' THEN '其他' 
				WHEN 'Z' THEN '转配送' END AS CashFlag,
		a.BillSts,(SELECT StsName 
			   FROM BillStatus s 
			   WHERE s.BillSts=a.BillSts And s.BillType='SMSA0') AS StsName,
		rp.BoxNo,a.DiscountCardNo,a.CardDiscRate,
		CASE a.BillType WHEN '40' THEN ISNULL(a.DiscAmt,0.0) WHEN '50' THEN -ISNULL(a.DiscAmt,0.0) END AS DiscAmt,
		CASE a.BillType WHEN '40' THEN ISNULL(a.PaymentXJ,0.0) WHEN '50' THEN -ISNULL(a.PaymentXJ,0.0) END AS XJAmt,
		CASE a.BillType WHEN '40' THEN ISNULL(a.PaymentSK,0.0) WHEN '50' THEN -ISNULL(a.PaymentSK,0.0) END AS SKAmt,
		CASE a.BillType WHEN '40' THEN ISNULL(a.PaymentZP,0.0) WHEN '50' THEN -ISNULL(a.PaymentZP,0.0) END AS ZPAmt,
		CASE a.BillType WHEN '40' THEN ISNULL(a.PaymentDD,0.0) WHEN '50' THEN -ISNULL(a.PaymentDD,0.0) END AS DDAmt,
		CASE a.BillType WHEN '40' THEN ISNULL(a.Receive1Amt,0.0) WHEN '50' THEN -ISNULL(a.Receive1Amt,0.0) END AS Receive1Amt,
		CASE a.BillType WHEN '40' THEN ISNULL(a.Receive2Amt,0.0) WHEN '50' THEN -ISNULL(a.Receive2Amt,0.0) END AS Receive2Amt,
		CASE a.BillType WHEN '40' THEN ISNULL(a.Receive3Amt,0.0) WHEN '50' THEN -ISNULL(a.Receive3Amt,0.0) END AS Receive3Amt,
		b.Location,b.ItemID,g.ItemNo,g.ItemName,g.ItemAlias,g.NameSpell AS ItemSpell,g.BarCode,
		g.ItemSpec,g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,g.UnitName,
		CASE a.BillType WHEN '40' THEN ISNULL(b.SQty,0.0) WHEN '50' THEN -ISNULL(b.SQty,0.0) END AS SQty,
		CASE a.BillType WHEN '40' THEN ISNULL(b.Amt,0.0) WHEN '50' THEN -ISNULL(b.Amt,0.0) END AS Amt,
		b.Price,b.SPrice,b.DiscRate,b.SafeSPrice,a.CreatorID,e1.EmployeeName as Creator,
		a.SalesID,e2.EmployeeName As SalesName,a.Remarks
	FROM SMS_Retail a INNER JOIN SMS_RetailDtl b ON a.RetailNo=b.RetailNo
			  LEFT OUTER JOIN BDM_Customer c ON a.CustID=c.CustID
			  LEFT OUTER JOIN BDM_ItemInfo_V g ON b.ItemID=g.ItemID
			  LEFT OUTER JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
			  LEFT OUTER JOIN BDM_WareHouse_V w ON a.WareHouse=w.CodeID
			  LEFT OUTER JOIN BDM_Employee e1 ON a.CreatorID=e1.EmployeeID
			  LEFT OUTER JOIN BDM_Employee e2 ON a.SalesID =e2.EmployeeID
			  LEFT OUTER JOIN SMS_RetailPrice rp ON b.DeptNo=rp.DeptNo AND b.ItemID=rp.ItemID
	WHERE Convert(char(10),a.CreateDate,120) Between @StartDate And @EndDate
		And (a.DeptNo Like @DeptNo + '%')
		And @Flag=1
)
go

