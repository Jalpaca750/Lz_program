CREATE VIEW dbo.WEB_UserSc_V
AS
SELECT C.ClassName AS ScName, c.ClassID as SCID,P.ProductID, P.CustID FROM dbo.WEB_User_SC P INNER JOIN dbo.WEB_SC_Class C ON P.Sc_Class = C.ClassID
go

