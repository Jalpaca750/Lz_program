--说明：分部零售商品排行
--作者：Devil.H
--创建：2007.11.21
--修改: 2010.05.11,Frank.H
--参数：
--	@StartDate:起始日期
--	@EndDate：截止日期
--	@CorpNo:公司范围
--	@DeptNo：分部范围
--	@ClassID:大类
--	@LabelID: 品牌
--	@Flag:	分析标识
CREATE Function dbo.fn_AnalRMS10
(
	@StartDate varchar(10),
	@EndDate varchar(10),
	@CorpNo varchar(2),
	@DeptNo varchar(20),
	@ClassID varchar(20),
	@LabelID varchar(20),
	@Flag bit
)
Returns Table
As
Return (
	SELECT g.ItemNo,g.ItemName,g.ItemSpec,g.ClassID,g.ClassName,g.LabelName,g.ColorName,g.UnitName,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(c.SQty,0.0) WHEN '50' THEN -ISNULL(c.SQty,0.0) END) AS SQty,
		SUM(CASE a.BillType WHEN '40' THEN ISNULL(c.Amt,0.0) WHEN '50' THEN -ISNULL(c.Amt,0.0) END) AS Amt
	FROM SMS_Retail a INNER JOIN SMS_RetailDtl c ON a.RetailNo=c.RetailNo
		          INNER JOIN BAS_Goods_V g ON c.ItemID=g.ItemID		
	WHERE (a.BillSts='20' Or a.BillSts='30')
		And (Convert(char(10),a.CreateDate,120) Between @StartDate And @EndDate)
		And (g.ClassID Like @ClassID + '%')
		And (g.LabelID Like @LabelID + '%')
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(SELECT 1 
			   FROM BDM_DeptCode_V d 
			   Where (a.DeptNo=d.CodeID) 
				And (d.DeptNo Like @CorpNo + '%'))
	GROUP BY ItemNo,g.ItemName,g.ItemSpec,g.ClassID,g.ClassName,g.LabelName,g.ColorName,g.UnitName
)
go

