--说明：商品年度销售毛利统计
--作者：Devil.H
--创建：2007.11.16
--参数：
--	@Year:年度
--	@CorpNo:公司
--	@DeptNo:分部
--	@Flag:标识
CREATE FUNCTION [dbo].[fn_AnalSMS90]
(
	@Year INT=0,
	@CorpNo VARCHAR(2)='',
	@DeptNo VARCHAR(20)='',
	@isGift BIT=0,
	@Flag BIT=0
)
Returns @uTable Table(
	ItemID BIGINT,
	ItemNo VARCHAR(20),
	ItemName VARCHAR(200),
	ItemAlias VARCHAR(200),
	NameSpell VARCHAR(200),
	ItemSpec VARCHAR(100),
	BarCode VARCHAR(100),
	ClassID VARCHAR(20),
	ClassName VARCHAR(100),
	LabelID VARCHAR(20),
	LabelName VARCHAR(100),
	ColorName VARCHAR(40),
	UnitName VARCHAR(20),
	isUnsalable BIT,
	isStop BIT,
	hotFlag BIT,
	Month01Amt DECIMAL(18,6),
	Month02Amt DECIMAL(18,6),
	Month03Amt DECIMAL(18,6),
	Month04Amt DECIMAL(18,6),
	Month05Amt DECIMAL(18,6),
	Month06Amt DECIMAL(18,6),
	Month07Amt DECIMAL(18,6),
	Month08Amt DECIMAL(18,6),
	Month09Amt DECIMAL(18,6),
	Month10Amt DECIMAL(18,6),
	Month11Amt DECIMAL(18,6),
	Month12Amt DECIMAL(18,6),
	TotalAmt DECIMAL(18,6)
)
AS
BEGIN
    IF (@Flag=0)
		RETURN;
	DECLARE @AmtDec INT
	SELECT @AmtDec=ISNULL(AmtDec,2) FROM Sys_Config
	Set @AmtDec=ISNULL(@AmtDec,2)
    if (ISNULL(@isGift,0)=0)
	    INSERT INTO @uTable(ItemID,MONTH01Amt,MONTH02Amt,MONTH03Amt,MONTH04Amt,MONTH05Amt,MONTH06Amt,
		                       MONTH07Amt,MONTH08Amt,MONTH09Amt,MONTH10Amt,MONTH11Amt,MONTH12Amt,TotalAmt)
	    SELECT b.ItemID,
		    MONTH01Amt=SUM(CASE MONTH(a.CreateDate) WHEN 1 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH02Amt=SUM(CASE MONTH(a.CreateDate) WHEN 2 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH03Amt=SUM(CASE MONTH(a.CreateDate) WHEN 3 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH04Amt=SUM(CASE MONTH(a.CreateDate) WHEN 4 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH05Amt=SUM(CASE MONTH(a.CreateDate) WHEN 5 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH06Amt=SUM(CASE MONTH(a.CreateDate) WHEN 6 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH07Amt=SUM(CASE MONTH(a.CreateDate) WHEN 7 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH08Amt=SUM(CASE MONTH(a.CreateDate) WHEN 8 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH09Amt=SUM(CASE MONTH(a.CreateDate) WHEN 9 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH10Amt=SUM(CASE MONTH(a.CreateDate) WHEN 10 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH11Amt=SUM(CASE MONTH(a.CreateDate) WHEN 11 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH12Amt=SUM(CASE MONTH(a.CreateDate) WHEN 12 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    TotalAmt=SUM(ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0.0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec))
	    FROM SMS_Stock a 
            INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
            INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	    WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30') 
	        AND YEAR(a.CreateDate)=@Year
	        AND (a.DeptNo Like @DeptNo + '%')
	        AND (a.DeptNo IN(SELECT CodeID FROM BDM_DeptCode_V WHERE DeptNo LIKE @CorpNo + '%'))
	    Group By b.ItemID
	ELSE
	    INSERT INTO @uTable(ItemID,MONTH01Amt,MONTH02Amt,MONTH03Amt,MONTH04Amt,MONTH05Amt,MONTH06Amt,
		                       MONTH07Amt,MONTH08Amt,MONTH09Amt,MONTH10Amt,MONTH11Amt,MONTH12Amt,TotalAmt)
	    SELECT b.ItemID,
		    MONTH01Amt=SUM(CASE MONTH(a.CreateDate) WHEN 1 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH02Amt=SUM(CASE MONTH(a.CreateDate) WHEN 2 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH03Amt=SUM(CASE MONTH(a.CreateDate) WHEN 3 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH04Amt=SUM(CASE MONTH(a.CreateDate) WHEN 4 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH05Amt=SUM(CASE MONTH(a.CreateDate) WHEN 5 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH06Amt=SUM(CASE MONTH(a.CreateDate) WHEN 6 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH07Amt=SUM(CASE MONTH(a.CreateDate) WHEN 7 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH08Amt=SUM(CASE MONTH(a.CreateDate) WHEN 8 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH09Amt=SUM(CASE MONTH(a.CreateDate) WHEN 9 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH10Amt=SUM(CASE MONTH(a.CreateDate) WHEN 10 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH11Amt=SUM(CASE MONTH(a.CreateDate) WHEN 11 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH12Amt=SUM(CASE MONTH(a.CreateDate) WHEN 12 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    TotalAmt=SUM(ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0.0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec))
	    FROM SMS_Stock a 
            INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
            INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	    WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30') 
	        AND YEAR(a.CreateDate)=@Year
	        AND (a.DeptNo Like @DeptNo + '%')
	        AND (a.DeptNo IN(SELECT CodeID FROM BDM_DeptCode_V WHERE DeptNo LIKE @CorpNo + '%'))
	    Group By b.ItemID;
	--更新
	UPDATE a SET a.ItemNo=b.ItemNo,a.ItemName=b.ItemName,a.ItemSpec=b.ItemSpec,a.NameSpell=b.NameSpell,
		a.ItemAlias=b.ItemAlias,a.BarCode=b.BarCode,a.ClassID=b.ClassID,a.LabelID=b.LabelID,a.UnitName=b.UnitName,
		a.ClassName=b.ClassName,a.LabelName=b.LabelName,a.ColorName=b.ColorName
	FROM @uTable a 
        INNER JOIN BAS_Goods_V b ON a.ItemID=b.ItemID
	--返回
	RETURN;
END
go

