CREATE VIEW dbo.SMS_BoxupDtl_V
AS
SELECT a.BoxupDtlID, a.BoxupNo, a.BoxNo, ISNULL(T.ZQty, 0) AS Zqty, ISNULL(T.ZAmt, 0) 
      AS ZAmt, a.PartQty, a.Remarks, a.CheckBox
FROM dbo.SMS_BoxupDtl a LEFT OUTER JOIN
          (SELECT BoxupNo,BoxNo, SUM(Qty) AS ZQty, SUM(Amt) AS ZAmt
         FROM SMS_BoxupDtl_Dtl
         GROUP BY BoxupNo,BoxNo) T ON a.BoxupNo=t.BoxupNo And a.BoxNo = T.BoxNo
go

