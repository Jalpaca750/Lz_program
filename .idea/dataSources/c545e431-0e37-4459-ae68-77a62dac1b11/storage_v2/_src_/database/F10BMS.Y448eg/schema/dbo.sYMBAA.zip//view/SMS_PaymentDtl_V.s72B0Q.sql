CREATE VIEW dbo.SMS_PaymentDtl_V
AS
SELECT a.PaymentID, a.PaymentNo, c.CreateDate, c.DeptNo, c.CustID, c.Credence, a.BillType,
    '销售发票' AS BillTypeDesc,a.InvoiceID,
    CASE ISNULL(a.InvoiceNo, '')  WHEN '' THEN b.InvoiceNo ELSE a.InvoiceNo END AS InvoiceNo, 
    a.Invoice, a.IAmt, a.DAmt, ISNULL(b.IAmt, 0) - ISNULL(b.PAmt, 0) AS RemAmt, a.FAmt, 
    a.PayAmt,b.CreateDate As InvoiceDate, a.Remarks, a.CheckBox
FROM dbo.SMS_PaymentDtl a 
    INNER JOIN dbo.SMS_Payment c ON a.PaymentNo = c.PaymentNo 
    LEFT JOIN dbo.SMS_Invoice b ON a.InvoiceID = b.InvoiceID
WHERE a.BillType=10
UNION ALL
SELECT a.PaymentID, a.PaymentNo, c.CreateDate, c.DeptNo, c.CustID, c.Credence, a.BillType,
    CASE a.BillType WHEN 20 THEN  '销售出库单' WHEN 30 THEN '销售退货单' WHEN 40 THEN '销售调价单' END AS BillTypeDesc,
    a.InvoiceID,CASE ISNULL(a.InvoiceNo, '')  WHEN '' THEN b.StockNo ELSE a.InvoiceNo END AS InvoiceNo, 
    a.Invoice, a.IAmt, a.DAmt, ISNULL(b.Amt, 0) - ISNULL(b.PaidAmt, 0) AS RemAmt, a.FAmt, a.PayAmt,
    b.CreateDate As InvoiceDate, a.Remarks, a.CheckBox
FROM dbo.SMS_PaymentDtl a 
    INNER JOIN dbo.SMS_Payment c ON a.PaymentNo = c.PaymentNo 
    LEFT JOIN (SELECT x.StockNo,x.CreateDate,x.PaidAmt,SUM(y.Amt) AS Amt
               FROM dbo.SMS_Stock x
                    INNER JOIN dbo.SMS_StockDtl y ON x.StockNo=y.StockNo
               GROUP BY x.StockNo,x.CreateDate,x.PaidAmt) b ON a.InvoiceNo = b.StockNo
WHERE a.BillType IN(20,30,40)
go

