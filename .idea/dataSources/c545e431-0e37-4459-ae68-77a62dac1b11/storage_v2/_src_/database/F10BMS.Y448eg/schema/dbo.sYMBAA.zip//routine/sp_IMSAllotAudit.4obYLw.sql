CREATE Proc sp_IMSAllotAudit
(
	@AllotNo varchar(20),
	@Flag char(2)
)
AS
Begin

	declare @PauseQty decimal(18,6)
	declare @WareHouse varchar(20)
	declare @DeptNo varchar(20)
	declare @AuditDate char(10)
	declare @CreateDate char(10)
	declare @SQty decimal(18,6)
	declare @Price decimal(18,6)
	declare @Amt decimal(18,6)
	declare @OrderNo varchar(20)
	declare @Location varchar(20)
	declare @ItemID bigint
	--日期、出库单号
	Select @WareHouse=WareHouse,@DeptNo=DeptNo,@AuditDate=AuditDate,
		@CreateDate=CreateDate
	From IMS_Allot 
	Where AllotNo=@AllotNo
	--临时表
	Create Table #Tmp(DeptNo varchar(20),WareHouse varchar(20),ItemID bigint,SQty decimal(18,6),IQty decimal(18,6),AQty decimal(18,6) Primary Key(ItemID))
	--汇总数据
	Insert Into #Tmp(DeptNo,WareHouse,ItemID,SQty,IQty,AQty)
	Select @DeptNo,@WareHouse,ItemID,Isnull(Sum(SQty),0.0),isnull(Sum(IQty),0.0),Sum(Case Isnull(OrderID,0) When 0 Then 0.0 Else Isnull(SQty,0.0) End)
	From IMS_AllotDtl
	Where AllotNo=@AllotNo
	Group By ItemID
	if @Flag='20'--审核
		Begin 
			--写入价格表
			Update a Set a.SPrice=Case Isnull(b.SPrice,0.0) When 0.0 Then a.SPrice Else b.SPrice End,
				     a.LstDate=Convert(varchar(10),GetDate(),120),
				     a.SourceDesc='调拨单',a.BillNo=@AllotNo
			From SMS_RetailPrice a Inner Join IMS_AllotDtl b ON a.DeptNo=b.DeptNo_I And a.ItemID=b.ItemID
			Where b.AllotNo=@AllotNo
			Insert Into SMS_RetailPrice(DeptNo,ItemID,SPrice,LstDate,SourceDesc,BillNo)
			Select DeptNo_I,ItemID,Max(SPrice),Convert(varchar(10),GetDate(),120),'调拨单',@AllotNo
			From IMS_AllotDtl a 
			Where AllotNo=@AllotNo And Not Exists(Select 1 From SMS_RetailPrice t Where a.DeptNo_I=t.DeptNo And a.ItemID=t.ItemID)
				And Isnull(SPrice,0.0)>0.0
			Group By DeptNo_I,ItemID
			
			--写入流水帐
			Insert Into IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,CreateDate,AuditDate)
			Select AllotNo,'调拨出库单',@DeptNo,@WareHouse,ItemID,-Isnull(SQty,0),Price,-Amt,
				@CreateDate,@AuditDate
			From IMS_AllotDtl
			Where AllotNo=@AllotNo And Not Exists(Select 1 From IMS_Flow Where BillNo=@AllotNo)
			--更商品资料总库存
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.SQty,0)
			From BDM_ItemInfo a Inner Join #Tmp b On a.ItemID=b.ItemID
			--更新分部库存总帐
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.SQty,0),a.AllocQty=Isnull(a.AllocQty,0.0)-Isnull(b.AQty,0.0)
			From IMS_Subdepot a Inner Join #Tmp b On a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
			Insert Into IMS_Subdepot(DeptNo,ItemID,OnHandQty)
			Select DeptNo,ItemID,-SQty
			From #Tmp a
			Where Not Exists(Select 1 From IMS_Subdepot b Where a.DeptNo=b.DeptNo And a.ItemID=b.ItemID)
			--更新库房总账
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.SQty,0),a.LastTime=GetDate()
			From IMS_Ledger a Inner Join #Tmp b On a.ItemID=b.ItemID And a.WareHouse=b.WareHouse
			Insert Into IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastTime)
			Select DeptNo,WareHouse,ItemID,-SQty,GetDate()
			From #Tmp a
			Where Not Exists(Select 1 From IMS_Ledger b Where a.WareHouse=b.WareHouse And a.ItemID=b.ItemID)
			--更新库房总帐相关数据
			declare mycursor cursor
			for select OrderNo,Location,ItemID,Price,SQty from IMS_AllotDtl Where AllotNo=@AllotNo
			open mycursor
			fetch next from mycursor into @OrderNo,@Location,@ItemID,@Price,@SQty
			while @@fetch_status=0
			begin
				--更新库房总帐
				Update IMS_Ledger Set LastOPrice=Case When Isnull(@Price,0.0)>0.0 Then @Price Else LastOPrice End,
					Location=Case Isnull(@Location,'') When '' then Location else @Location End,
					LastODate=@CreateDate
				Where ItemID=@ItemID And WareHouse=@WareHouse
				fetch next from mycursor into @OrderNo,@Location,@ItemID,@Price,@SQty
			end
			close mycursor
			deallocate mycursor 
		End
	if @Flag='10'
		Begin 
			--删除流水帐
			Delete From IMS_Flow Where BillNo=@AllotNo
			--更商品资料总库存
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.SQty,0)
			From BDM_ItemInfo a Inner Join #Tmp b On a.ItemID=b.ItemID
			--更新分部库存总帐
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.SQty,0),a.AllocQty=Isnull(a.AllocQty,0.0)+Isnull(b.AQty,0.0)
			From IMS_Subdepot a Inner Join #Tmp b On a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
			--更新库房总帐
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.SQty,0),a.LastTime=GetDate()
			From IMS_Ledger a Inner Join #Tmp b On a.ItemID=b.ItemID And a.WareHouse=b.WareHouse
		End
	if @Flag='05'
		Begin
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.SQty,0)-isnull(b.IQty,0)
			From BDM_ItemInfo a Inner Join #Tmp b On a.ItemID=b.ItemID
			--更新分部库存总帐
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.SQty,0)-isnull(b.IQty,0)
			From IMS_Subdepot a Inner Join #Tmp b On a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
			--更新库房总帐
			Update a Set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.SQty,0)-isnull(b.IQty,0),a.LastTime=GetDate()
			From IMS_Ledger a Inner Join #Tmp b On a.ItemID=b.ItemID And a.WareHouse=@WareHouse
			--写入流水帐
			Delete From IMS_Flow Where BillNo=@AllotNo
			--写入流水帐
			Insert Into IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,CreateDate,AuditDate)
			Select AllotNo,'调拨出库单',@DeptNo,@WareHouse,ItemID,-Isnull(IQty,0),Price,-(Isnull(IQty,0)*Isnull(Price,0)),
				@CreateDate,@AuditDate
			From IMS_AllotDtl
			Where AllotNo=@AllotNo And Isnull(IQty,0.0)>0.0
			
			Update IMS_AllotDtl Set PauseQty=ISNULL(SQty,0.0)-ISNULL(IQty,0.0) 
			Where AllotNo=@AllotNo And ISNULL(SQty,0.0)-ISNULL(IQty,0.0)>0.0
			Update a set a.SQty=Isnull(a.SQty,0.0)+(ISNULL(b.SQty,0.0)-ISNULL(b.IQty,0.0)) 
			From PMS_OrderDtl a Inner Join IMS_AllotDtl b ON a.OrderID=b.OrderID
			Where  b.AllotNo=@AllotNo And ISNULL(b.SQty,0.0)-ISNULL(b.IQty,0.0)>0.0
		End
	if @Flag='00'		--作废单据
		begin
			Update a Set a.DQty=Isnull(a.DQty,0.0)-Isnull(b.SQty,0.0)
			From PMS_OrderDtl a,IMS_AllotDtl b
			Where a.OrderID=b.OrderID And b.AllotNo=@AllotNo
			declare mycursor cursor
			for Select Distinct OrderNo From IMS_AllotDtl Where AllotNo=@AllotNo
			open mycursor
			fetch next from mycursor into @OrderNo
			while @@fetch_Status=0
			begin
				--存在已入库数量〉0的更新为部分入库,否则更新为已审核
				if exists(Select 1 from PMS_OrderDtl Where Isnull(DQty,0)>0 And OrderNo=@OrderNo)
					Update PMS_Order Set BillSts='25' Where OrderNo=@OrderNo And BillSts<>'05'	
				else
					Update PMS_Order Set BillSts='20' Where OrderNo=@OrderNo And BillSts<>'05'	
				fetch next from mycursor into @OrderNo
			end
			close mycursor
			deallocate mycursor
		end 
End
go

