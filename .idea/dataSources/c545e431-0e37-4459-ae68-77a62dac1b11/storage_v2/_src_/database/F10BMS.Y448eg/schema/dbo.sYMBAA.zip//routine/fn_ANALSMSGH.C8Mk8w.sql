--说明：未收款账龄分析
--作者：Frank.H
--创建：2012.05.06
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@Flag:前台标识
CREATE Function dbo.fn_ANALSMSGH
(
	@StartDate varchar(10),
	@EndDate varchar(10),
	@Flag int=0
)
Returns @uTable Table(
	CustID bigint,
	CustNo varchar(20),
	CustName varchar(200),
	NameSpell varchar(200),
	CustType varchar(20),
	TypeName varchar(100),
	PopedomID varchar(20),
	PopedomName varchar(100),
	AreaCode varchar(20),
	AreaName varchar(100),
	MemberID varchar(20),
	Member varchar(100),
	SalesID bigint,
	SalesName varchar(100),
	ADays int,
	QCAmt decimal(18,6) default 0.0,
	BQSAmt decimal(18,6) default 0.0,
	BQIAmt decimal(18,6) default 0.0,
	QMAmt decimal(18,6) default 0.0,
	InAmt decimal(18,6) default 0.0,
	In030 decimal(18,6) default 0.0,
	In045 decimal(18,6) default 0.0,
	In060 decimal(18,6) default 0.0,
	In090 decimal(18,6) default 0.0,
	In180 decimal(18,6) default 0.0,
	In270 decimal(18,6) default 0.0,
	In365 decimal(18,6) default 0.0,
	Over365 decimal(18,6) default 0.0
)
As
begin
	if @Flag=0 
		Return

	declare @Today varchar(10)
	declare @tmpSales Table(
		CustID bigint,
		QCAmt decimal(18,6) default 0.0,
		BQSAmt decimal(18,6) default 0.0,
		BQIAmt decimal(18,6) default 0.0,
		QMAmt decimal(18,6) default 0.0,
		InAmt decimal(18,6) default 0.0,
		In030 decimal(18,6) default 0.0,
		In045 decimal(18,6) default 0.0,
		In060 decimal(18,6) default 0.0,
		In090 decimal(18,6) default 0.0,
		In180 decimal(18,6) default 0.0,
		In270 decimal(18,6) default 0.0,
		In365 decimal(18,6) default 0.0,
		Over365 decimal(18,6) default 0.0
		)
	declare @tmpPDays Table(
		CustID bigint,
		RemIAmt decimal(18,6),
		AIDate varchar(10),
		PDays int,
		OverDays int
		)
	--当前系统日期
	Select @Today=@EndDate

	--客户期初未开票数据
	Insert Into @tmpSales(CustID,QCAmt,BQSAmt,BQIAmt,QMAmt)
	Select a.CustID,Sum(Isnull(b.Amt,0.0)-Isnull(t.IAmt,0.0)),0.0,0.0,0.0
	From SMS_Stock a Inner Join SMS_StockDtl b On a.StockNo=b.StockNo
					 Left Outer Join(
						Select y.StockID,Sum(y.Amt) As IAmt
						From SMS_Invoice x Inner Join SMS_InvoiceDtl y On x.InvoiceNo=y.InvoiceNo
						Where (x.BillSts='20' Or x.BillSts='25' Or x.BillSts='30') --And (x.CreateDate<=@StartDate)
						Group By y.StockID) t On b.StockID=t.StockID
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		And a.CreateDate<@StartDate
	Group By a.CustID
	--本期销售
	Insert Into @tmpSales(CustID,QCAmt,BQSAmt,BQIAmt,QMAmt)	
	Select a.CustID,0.0,Sum(b.Amt),0.0,0.0
	From SMS_Stock a Inner Join SMS_StockDtl b On a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.CustID
	--本期开票
	Insert Into @tmpSales(CustID,QCAmt,BQSAmt,BQIAmt,QMAmt)
	Select a.CustID,0.0,0.0,Sum(b.Amt),0.0 
	From SMS_Invoice a Inner Join SMS_InvoiceDtl b On a.InvoiceNo=b.InvoiceNo
	Where (a.BillSts='20' Or a.Billsts='25' Or a.Billsts='30') 
		And (a.CreateDate Between @StartDate And @EndDate)
		And (b.SMSAStockFlag='0')
	Group By a.CustID

	--客户票期分析
	--截至期末未开发票的出库单
	Insert Into @tmpPDays(CustID,RemIAmt,AIDate,PDays,OverDays)
	Select a.CustID,Isnull(b.Amt,0.0)-Isnull(t.IAmt,0.0) As RemIAmt,DateAdd(d,Isnull(c.PDays,30),a.CreateDate) As AIDays,c.PDays,DateDiff(d,DateAdd(d,Isnull(c.PDays,30),a.CreateDate),@Today)
	From SMS_Stock a Inner Join SMS_StockDtl b On a.StockNo=b.StockNo
					 Inner Join BDM_Customer c On a.CustID=c.CustID
					 Left Outer Join(
						Select y.StockID,Sum(y.Amt) As IAmt
						From SMS_Invoice x Inner Join SMS_InvoiceDtl y On x.InvoiceNo=y.InvoiceNo
						Where (x.BillSts='20' Or x.BillSts='25' Or x.BillSts='30') 
							And (x.CreateDate<=@EndDate) And (y.SMSAStockFlag='0')
						Group By y.StockID) t On b.StockID=t.StockID
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		And (a.CreateDate<@EndDate)
		And (Isnull(b.Amt,0.0)-Isnull(t.IAmt,0.0)<>0.0)
	Insert Into @tmpSales(CustID,InAmt,In030,In045,In060,In090,In180,In270,In365,Over365)
	Select CustID,
			Sum(Case When Isnull(OverDays,0)<=0 Then RemIAmt Else 0.0 End),
			Sum(Case When Isnull(OverDays,0)>0 And Isnull(OverDays,0)<=30 Then RemIAmt Else 0.0 End),
			Sum(Case When Isnull(OverDays,0)>30 And Isnull(OverDays,0)<=45 Then RemIAmt Else 0.0 End),
			Sum(Case When Isnull(OverDays,0)>45 And Isnull(OverDays,0)<=60 Then RemIAmt Else 0.0 End),
			Sum(Case When Isnull(OverDays,0)>60 And Isnull(OverDays,0)<=90 Then RemIAmt Else 0.0 End),
			Sum(Case When Isnull(OverDays,0)>90 And Isnull(OverDays,0)<=180 Then RemIAmt Else 0.0 End),
			Sum(Case When Isnull(OverDays,0)>180 And Isnull(OverDays,0)<=270 Then RemIAmt Else 0.0 End),
			Sum(Case When Isnull(OverDays,0)>270 And Isnull(OverDays,0.0)<=365 Then RemIAmt Else 0.0 End),
			Sum(Case When Isnull(OverDays,0)>365 Then RemIAmt Else 0.0 End)
	From @tmpPDays
	Group By CustID	
	Insert Into @uTable(CustID,QCAmt,BQSAmt,BQIAmt,QMAmt,InAmt,In030,In045,In060,In090,In180,In270,In365,Over365)
	Select CustID,
		Sum(QCAmt) As QCAmt,
		Sum(BQSAmt) As BQSAmt,
		Sum(BQIAmt) As BQIAmt,
		Sum(Isnull(QCAmt,0.0)+Isnull(BQSAmt,0.0)-Isnull(BQIAmt,0.0)) As QMAmt,
		Sum(InAmt) As InAmt,
		Sum(In030) As In030,
		Sum(In045) As In045,
		Sum(In060) As In060,
		Sum(In090) As In090,
		Sum(In180) As In180,
		Sum(In270) As In270,
		Sum(In365) As In365,
		Sum(Over365)
	From @tmpSales
	Group By CustID
	--更新客户资料
	Update a Set a.CustNo=b.CustNo,a.CustName=b.CustName,a.NameSpell=b.NameSpell,a.CustType=b.CustType,
		     a.TypeName=b.TypeName,a.PopedomID=b.PopedomID,a.PopedomName=b.PopedomName,
		     a.AreaCode=b.AreaCode,a.AreaName=b.AreaName,a.MemberID=b.MemberID,a.Member=b.Member,	
		     a.SalesID=b.SalesID,a.SalesName=b.Sales,a.ADays=Isnull(b.PDays,30)
	From @uTable a Inner Join BAS_Customer_V b On a.CustID=b.CustID
	Return
End 
go

