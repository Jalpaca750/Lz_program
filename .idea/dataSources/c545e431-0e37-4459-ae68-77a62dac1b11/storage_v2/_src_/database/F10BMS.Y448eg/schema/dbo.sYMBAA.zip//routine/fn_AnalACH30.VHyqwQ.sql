--送货员业绩统计
--2010.03.23
--Devil.H
--参数
--参数
--	@StartDate:年份
--	@EndDate:月份
--	@Flag	
CREATE Function dbo.fn_AnalACH30
(
	@StartDate varchar(10),
	@EndDate varchar(10),
	@Flag int
)
Returns @uTable Table(
	EmployeeID bigint,
	EmployeeName varchar(100),
	DeptNo varchar(20),
	BillAmt decimal(18,6),
	ItemCount bigint,
	BillCount bigint,
	PartQty decimal(18,6),
	AvgItemAmt decimal(18,6),
	AvgBillAmt decimal(18,6),
	AvgItemCount decimal(18,6)
)
As
Begin
	if @Flag=0
		Return
	if @Flag=1
		Insert Into @uTable(EmployeeID,EmployeeName,DeptNo,BillAmt,ItemCount,BillCount,PartQty,AvgItemAmt,AvgBillAmt,AvgItemCount)
		Select x.Delivery,z.EmployeeName,Left(z.DeptCode,4),y.Amt,y.ItemCount,x.BillCount,PartQty,
			AvgItemAmt=Case Isnull(y.ItemCount,0)
					When 0 then 0
					Else Round(Isnull(y.Amt,0.0)/y.ItemCount,2) End,
		   	AvgBillAmt=Case Isnull(x.BillCount,0)
					When 0 then 0
					Else Round(Isnull(y.Amt,0.0)/x.BillCount,2) End,
		   	AvgItemCount=Case Isnull(x.BillCount,0)
					When 0 then 0
					Else Round(Isnull(y.ItemCount,0)/BillCount,2) End
		From (Select Delivery,Count(1) as BillCount,Sum(PartQty) As PartQty
		 	From SMS_Stock 
			Where (BillSts='20' Or BillSts='25' Or BillSts='30')
				And (Isnull(CreateDate,'') Between @StartDate And @EndDate)
				And (Isnull(Delivery,0)<>0) 
			Group By Delivery) x Inner Join 
		       (Select a.Delivery,Sum(Isnull(b.Amt,0)) as Amt,Count(1) as ItemCount 
			From SMS_Stock a Inner join SMS_StockDtl b On a.StockNo=b.StockNo
			Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
				And (Isnull(a.CreateDate,'') Between @StartDate And @EndDate)
				And (Isnull(a.Delivery,0)<>0)
			Group By a.Delivery) y On x.Delivery=y.Delivery 
			Inner Join BDM_Employee z On x.Delivery=z.EmployeeID
	if @Flag=2
		Insert Into @uTable(EmployeeID,EmployeeName,DeptNo,BillAmt,ItemCount,BillCount,PartQty,AvgItemAmt,AvgBillAmt,AvgItemCount)
		Select x.Delivery,z.EmployeeName,Left(z.DeptCode,4),y.Amt,y.ItemCount,x.BillCount,x.PartQty,
			AvgItemAmt=Case Isnull(y.ItemCount,0)
					When 0 then 0
					Else Round(Isnull(y.Amt,0.0)/y.ItemCount,2) End,
		   	AvgBillAmt=Case Isnull(x.BillCount,0)
					When 0 then 0
					Else Round(Isnull(y.Amt,0.0)/x.BillCount,2) End,
		   	AvgItemCount=Case Isnull(x.BillCount,0)
					When 0 then 0
					Else Round(Isnull(y.ItemCount,0)/BillCount,2) End
		From (Select Delivery,Count(1) as BillCount,Sum(PartQty) As PartQty
		 	From SMS_Stock 
			Where (Isnull(BackDate,'') Between @StartDate And @EndDate)
				And (BillSts='20' Or BillSts='25' Or BillSts='30')
				And (Isnull(Delivery,0)<>0) 
			Group By Delivery) x Inner Join 
		       (Select a.Delivery,Sum(Isnull(b.Amt,0)) as Amt,Count(1) as ItemCount 
			From SMS_Stock a Inner join SMS_StockDtl b On a.StockNo=b.StockNo
			Where (Isnull(a.BackDate,'') Between @StartDate And @EndDate)
				And (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
				And (Isnull(a.Delivery,0)<>0)
			Group By a.Delivery) y On x.Delivery=y.Delivery 
			Inner Join BDM_Employee z On x.Delivery=z.EmployeeID
	Return
End
go

