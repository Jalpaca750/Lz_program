CREATE VIEW [dbo].[PMS_Invoice_V]
AS
SELECT a.InvoiceID, a.InvoiceNo, a.CreateDate, a.DeptNo, e.CHName AS DeptName, 
	a.VendorID, b.VendorNo, b.VendorName, b.NameSpell, b.LinkMan, b.Phone, b.Faxes, 
	b.BuyerID, b.Buyer, a.IType, d.CHName AS ITName, a.Invoice, a.PayMode, a.IAmt, 
	a.DAmt, a.PAmt, ISNULL(a.IAmt, 0) - ISNULL(a.PAmt, 0) AS RemAmt, a.BillSts, 
	(SELECT StsName From BillStatus f WHERE a.BillSts=f.BillSts And f.BillType = 'PMS90')AS StsName,
	a.RedFlag,CASE a.RedFlag WHEN -1 THEN '红字' WHEN 0 THEN '蓝字' WHEN 1 THEN '冲红' END AS RedInvoice,  
	a.AuditDate, a.IFlag, a.PFlag, a.CreatorID, c.EmployeeName AS Creator,
	a.CreateDate As InvoiceDate, a.APDate, a.PrintNum,a.PrinterID,
	p.EmployeeName AS Printer,a.Remarks, a.CheckBox
FROM dbo.PMS_Invoice a LEFT OUTER JOIN
      dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V e ON a.DeptNo = e.CodeID LEFT OUTER JOIN
      dbo.BDM_Vendor_V b ON a.VendorID = b.VendorID LEFT OUTER JOIN
      dbo.BDM_InvoiceType_V d ON a.IType = d.CodeID LEFT OUTER JOIN
      dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID
go

