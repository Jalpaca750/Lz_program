--采购订单明细插入操作（Insert)
--2007-08-21
--Devil.H
--当上述操作发生时：
--更新计划单的已执行采购数量，同时更新计划单状态

--采购订单明细插入操作（Insert)
--2008-12-09
--wujinfeng
--当上述操作发生时：
--当前合同的已执行数量减少
CREATE Trigger Trig_PMS_OrderDtl_Ins
On dbo.PMS_OrderDtl
For Insert
As
Begin
	declare @PlanNo varchar(20)
	--更新计划单的已采购数量
	Update a Set a.OQty=Isnull(a.OQty,0)+Isnull(b.OQty,0)	From PMS_PlanDtl a,Inserted b	Where a.PlanID=b.PlanID
	--计划单
	declare mycursor cursor
	for select Distinct PlanNo From Inserted
	open mycursor
	fetch next from mycursor into @PlanNo
	while @@fetch_Status=0
	begin
		--存在未执行的记录
		if exists(Select * from PMS_PlanDtl_V Where Isnull(RemOQty,0)>0 And PlanNo=@PlanNo)
			Update PMS_Plan Set BillSts='25' Where PlanNo=@PlanNo And BillSts<>'05'	
		else
			Update PMS_Plan Set BillSts='30' Where PlanNo=@PlanNo And BillSts<>'05'	
		fetch next from mycursor into @PlanNo
	end
	close mycursor
	deallocate mycursor


	--增中合同处理
	declare @BillNo varchar(20)
	declare @BillID bigint
	declare @OrderID bigint

	--已执行数量更新
	Update a Set a.SQty=Isnull(a.SQty,0)+Isnull(b.OQty,0) From CON_PmsDtl a,Inserted b Where a.BillID=b.BillID

	--已分配数量减少
	declare mycursors cursor
	for Select OrderID,BillID from Inserted 
	open mycursors
	fetch next from mycursors into @OrderID,@BillID
	while @@fetch_Status=0
	begin
			--订单编号
			Select @BillNo=BillNo From CON_PmsDtl Where BillID=@BillID
			--存在未执行的记录
			if exists(Select * from CON_PmsDtl_V Where Isnull(ExecQty,0)>0 And BillNo=@BillNo)
				Update CON_Pms Set BillSts='25' Where BillNo=@BillNo And BillSts<>'05'
			else
				Update CON_Pms Set BillSts='30' Where BillNo=@BillNo And BillSts<>'05'
				
		fetch next from mycursors into @BillNo,@BillID
	end
	close mycursors
	deallocate mycursors
End
go

