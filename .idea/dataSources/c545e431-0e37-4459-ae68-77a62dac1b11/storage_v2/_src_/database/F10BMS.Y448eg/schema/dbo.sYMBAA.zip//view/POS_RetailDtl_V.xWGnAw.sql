CREATE VIEW dbo.POS_RetailDtl_V
AS
SELECT a.RetailID, a.RetailNo, b.CreateDate, b.CreateTime, b.CashFlag, b.PCNo, b.CustID, 
      a.DeptNo, a.WareHouse, b.BillType, a.Location, a.ItemID, c.ItemNo, c.ItemName, 
      c.ItemAlias, c.NameSpell, c.ItemSpec, c.BarCode, c.ClassID, c.ClassName, c.LabelID, 
      c.LabelName, c.ColorName, c.UnitName, a.Price, a.SPrice, a.ZQty, a.DiscRate, 
      a.SafeSPrice, c.PPrice, c.SPrice1, c.SPrice2, c.SPrice3, d.OnHandQty, c.Integral, 
      c.NotDisc, CASE b.BillType WHEN '40' THEN a.SQty ELSE - a.SQty END AS SQty, 
      CASE b.BillType WHEN '40' THEN a.Amt ELSE - a.Amt END AS Amt, c.Package, 
      c.MPackage, c.BPackage, a.DiscAmt, a.Integral AS DtlIntegral, a.IsPromotion, 
      c.PkgRatio, b.ShiftNo, a.Remarks, a.CheckBox
FROM dbo.SMS_RetailDtl a LEFT OUTER JOIN
      dbo.IMS_Ledger d ON a.WareHouse = d.WareHouse AND 
      a.ItemID = d.ItemID LEFT OUTER JOIN
      dbo.BDM_ItemInfo_V c ON a.ItemID = c.ItemID LEFT OUTER JOIN
      dbo.SMS_Retail b ON a.RetailNo = b.RetailNo
go

