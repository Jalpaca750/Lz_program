CREATE VIEW dbo.SMS_AStockDtl_V
AS
SELECT a.StockID, a.StockNo, e.CreateDate, e.CustID, e.SendAddr, e.DeptNo, 
      a.WareHouse, ISNULL(f.Location, a.Location) AS Location, e.BillSts, e.BillType, 
      a.OrderID, a.OrderNo, a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, 
      b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, b.LabelID, b.LabelName,b.ColorName,  
      b.UnitName, f.OnHandQty, b.PkgSpec,a.PkgQty,a.SQty, a.Price,a.Amt, a.ZQty,   
      a.RQty, a.IsSpecial,a.DiscRate,a.IsEffect,a.TaxFlag,a.PaidAmt, a.IsPromotion,
      ISNULL(c.OQty, 0) - ISNULL(c.SQty, 0) AS RemSQty,
      ISNULL(c.ZQty, 0) - ISNULL(c.SZQty, 0) AS RemZQty,
      ISNULL(a.PaidAmt, 0) - ISNULL(a.PAmt, 0) AS RemPAmt, a.IQty, 
      ISNULL(a.SQty, 0) - ISNULL(a.IQty, 0) AS RemIQty, a.IAmt, 
      ISNULL(a.Amt, 0) - ISNULL(a.IAmt, 0) AS RemAmt, 
      ISNULL(a.SQty, 0) - ISNULL(a.RQty, 0) AS RemRQty, 
      ISNULL(a.ZQty, 0) - ISNULL(a.RZQty, 0) AS RemRZQty, a.CPrice, b.BPackage, b.MPackage, b.Package, 
      b.PkgRatio, b.TaxRate, b.HotFlag, b.NotDisc, b.PPrice, b.SPrice, b.SPrice1, b.SPrice2, 
      b.SPrice3, b.SafeSPrice, b.PurDays, b.Integral, a.Remarks, a.CheckBox,a.DiscountTemp,
      B.ItemPHFlag, B.ItemPHName,a.Integral As DtlIntegral,a.YZStockQty,a.BoxQty, 
      ISNULL(a.SQty, 0) +ISNULL(a.ZQty, 0)-ISNULL(a.BoxQty, 0)  As RemBoxQty,'A' As SMSAStockFlag, 
      cb.CHName As CostsName
FROM dbo.SMS_AStockDtl a LEFT OUTER JOIN
      dbo.SMS_AStock e ON a.StockNo = e.StockNo LEFT OUTER JOIN
      dbo.BAS_Goods_V b ON a.ItemID = b.ItemID LEFT OUTER JOIN
      dbo.IMS_Ledger f ON a.WareHouse = f.WareHouse AND a.ItemID = f.ItemID LEFT OUTER JOIN
      dbo.SMS_OrderDtl c ON a.OrderID = c.OrderID LEFT OUTER JOIN  
      dbo.Web_Costs_Class cb ON e.CostsID = cb.CostsID
go

