CREATE VIEW dbo.IMS_Subdepot_V
AS
SELECT a.DeptNo, c.CHName AS DeptName, a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, 
      b.NameSpell, b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, b.LabelID, 
      b.LabelName, b.ColorName, b.UnitName, a.Location, a.OnHandQty, a.AllocQty,
      Case Isnull(b.PkgRatio,0) when 0 then Null else Round(Isnull(a.OnHandQty,0)/Isnull(b.PkgRatio,0),4) End as PkgQty, 
      ISNULL(a.OnHandQty, 0) - ISNULL(a.AllocQty, 0) AS AvailQty, ISNULL(y.Qty,0) As YZStockQty,
--ISNULL(a.OnHandQty, 0) - ISNULL(a.AllocQty, 0) AS AvailQty,
a.Price, a.VendorID, 
      d.VendorNo, d.VendorName, a.MaxHive, a.MinHive, a.SafetyDays, a.MaxStock, 
      a.MinStock, ISNULL(a.OnHandQty, 0) - ISNULL(a.MaxStock, 0) AS OverQty, 
      ISNULL(a.MinStock, 0) - ISNULL(a.OnHandQty, 0) AS UnderQty, a.Stability, 
      b.BPackage, b.MPackage, b.Package, b.PkgRatio, b.PkgSpec, b.HotFlag, b.NotDisc, 
      b.SPrice, a.RPrice, b.SPrice1, b.SPrice2, b.SPrice3, b.PPrice, b.SafePPrice, 
      b.SafeSPrice
,TT.Qty01 as ZJ_Sqty,TT.Amt01 as ZJ_Amt
,b.Flag
,TT.Qty01,TT.Qty02,TT.Qty03
,a.OnHandQty*a.Price As KCAmt
FROM dbo.IMS_Subdepot a LEFT OUTER JOIN
      dbo.BDM_Vendor d ON a.VendorID = d.VendorID LEFT OUTER JOIN
      dbo.BDM_ItemInfo_V b ON a.ItemID = b.ItemID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V c ON a.DeptNo = c.CodeID
left join IMS_YZStock_Sum_DeptID_V Y on a.ItemID=Y.ItemID and a.DeptNo=Y.DeptNo
LEFT OUTER JOIN      dbo.ANAL_LstSanSell_V TT ON a.DeptNo = TT.DeptNo AND       a.ItemID = TT.ItemID








go

