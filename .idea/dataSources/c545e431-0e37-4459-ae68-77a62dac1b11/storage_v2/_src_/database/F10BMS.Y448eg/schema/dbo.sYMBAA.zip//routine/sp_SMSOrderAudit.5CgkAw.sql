


CREATE PROCEDURE sp_SMSOrderAudit
(
	@OrderNo VARCHAR(20),
	@Flag CHAR(2)
)
AS
BEGIN
	--临时表
	DECLARE @tmpQty TABLE(DeptNo VARCHAR(20),ItemID BIGINT,AllocQty DECIMAL(20,10) PRIMARY KEY(DeptNo,ItemID));
    --合同单号,消费积分，客户编号
	DECLARE @BillNo VARCHAR(20),@OrderAmt DECIMAL(18,6),@ConAmt DECIMAL(18,6),@XFIntegral DECIMAL(18,6),@CustID BIGINT;
    DECLARE @errors BIGINT,@ErrMsg VARCHAR(4000),@ErrSeverity BIGINT;    
    --当前客户
	SELECT @CustID=CustID,@BillNo=ISNULL(ConNo,'') FROM SMS_Order WHERE OrderNo=@OrderNo;
	--积分消费
	SELECT @XFIntegral=SUM(ISNULL(OQty,0.0)) 
    FROM SMS_OrderDtl 
    WHERE OrderNo=@OrderNo AND ItemID IN(SELECT ItemID FROM BDM_ItemInfo WHERE ItemNo='JFDK');
    SET @errors=0;
    SELECT @OrderAmt=SUM(Amt)
    FROM SMS_OrderDtl 
    WHERE OrderNo=@OrderNo;
    BEGIN TRANSACTION    
    --排队等待
    WHILE EXISTS(SELECT * FROM dbo.SAM_Schedule WHERE jobCode='sal_order_job' AND IsLocked=1)
    BEGIN
        SET @errors=0;
    END
    UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='sp_SMSOrderAudit' WHERE jobCode='sal_order_job';
	--验收（商品资料中可用量减少）
	IF (@Flag='20')
	BEGIN
        --非定制商品占用量写入临时表
    	INSERT INTO @tmpQty(DeptNo,ItemID,AllocQty)
    	SELECT a.DeptNo,b.ItemID,SUM(ISNULL(b.OQty,0.0)+ISNULL(b.ZQty,0.0))
    	FROM SMS_Order a 
            INNER JOIN SMS_OrderDtl b ON a.OrderNo=b.OrderNo
    	WHERE a.OrderNo=@OrderNo AND ISNULL(b.IsSpecial,0)=0
    	GROUP BY a.DeptNo,b.ItemID;
        SET @errors=@errors+@@ERROR;        
        --处理订单对应合同
        IF (ISNULL(@BillNo,'')<>'')
        BEGIN
            SELECT @ConAmt=SUM(ROUND(ISNULL(Qty, 0)* ISNULL(Price, 0), 2))
            FROM CON_SmsDtl
            WHERE BillNo=@BillNo;
            --如果合同未执行完成，但订单金额大于等于合同金额，则合同自动完成
            IF (ISNULL(@orderAmt,0.0)-ISNULL(@conAmt,0.0)>=0.0)
                UPDATE CON_Sms SET BillSts='30' WHERE BillNo=@BillNo And BillSts<>'05';
            SET @errors=@errors+@@ERROR;
        END       
        --处理积分
		IF (ISNULL(@XFIntegral,0.0)<>0.0)
        BEGIN
            --客户积分减少
		    UPDATE BDM_Customer SET Deduct=ISNULL(Deduct,0.0) - ISNULL(@XFIntegral,0.0) WHERE CustID=@CustID;	
            SET @errors=@errors+@@ERROR;	
            --如果消费积分(积分抵扣)
            INSERT INTO Web_IntegralLog(RelatingOrder,Description,Integral,UpdateType,UpdateDate,UserID)
            SELECT @OrderNo,'积分抵扣现金',@XFIntegral,'-',GETDATE(),@CustID
            SET @errors=@errors+@@ERROR;
		END
		--更新已有商品的已分配量
		UPDATE s SET s.AllocQty=ISNULL(s.AllocQty,0.0)+ISNULL(t.AllocQty,0.0)
		FROM IMS_Subdepot s 
            INNER JOIN @tmpQty t ON s.DeptNo=t.DeptNo AND s.ItemID=t.ItemID;
        SET @errors=@errors+@@ERROR;
		--写入没有的商品
		INSERT INTO IMS_Subdepot(DeptNo,ItemID,OnHandQty,AllocQty)
		SELECT DeptNo,ItemID,0.0,AllocQty
		FROM @tmpQty t
		WHERE Not Exists(SELECT 1 FROM IMS_Subdepot s WHERE s.DeptNo=t.DeptNo AND s.ItemID=t.ItemID);		
        SET @errors=@errors+@@ERROR;
		--写入订单状态(web)
		DELETE FROM Web_OrderState WHERE OrderNo=@OrderNo AND [action]=2;
        SET @errors=@errors+@@ERROR;
		INSERT INTO Web_OrderState(OrderNo,[action],CreateTime,Content)
		SELECT OrderNo,2,Convert(VARCHAR(20),GetDate(),120),'您的订单已通过客服审核，等待仓库配货'
		FROM SMS_Order
		WHERE OrderNo=@OrderNo;
        SET @errors=@errors+@@ERROR;
	END
	ELSE IF(@Flag='10')
	BEGIN
        --非定制商品占用量写入临时表
    	INSERT INTO @tmpQty(DeptNo,ItemID,AllocQty)
    	SELECT a.DeptNo,b.ItemID,SUM(ISNULL(b.OQty,0.0)+ISNULL(b.ZQty,0.0))
    	FROM SMS_Order a 
            INNER JOIN SMS_OrderDtl b ON a.OrderNo=b.OrderNo
    	WHERE a.OrderNo=@OrderNo AND ISNULL(b.IsSpecial,0)=0
    	GROUP BY a.DeptNo,b.ItemID;
        SET @errors=@errors+@@ERROR;
		--更新已有商品的已分配量
		UPDATE s SET s.AllocQty=ISNULL(s.AllocQty,0.0)-ISNULL(t.AllocQty,0.0)
		FROM IMS_Subdepot s 
            INNER JOIN @tmpQty t ON s.DeptNo=t.DeptNo AND s.ItemID=t.ItemID;
        SET @errors=@errors+@@ERROR;
        --取消预占
        DELETE FROM IMS_Advance WHERE orderNo=@orderNo;
        SET @errors=@errors+@@ERROR;
        --处理积分
        IF (ISNULL(@XFIntegral,0.0)<>0.0)
        BEGIN 
		    --客户积分增加
		    UPDATE BDM_Customer SET Deduct=ISNULL(Deduct,0.0) + ISNULL(@XFIntegral,0.0) WHERE CustID=@CustID;
            SET @errors=@errors+@@ERROR;
		    --如果消费积分(积分抵扣)			
		    INSERT INTO Web_IntegralLog(RelatingOrder,Description,Integral,UpdateType,UpdateDate,UserID)
		    SELECT @OrderNo,'返还积分抵扣现金',@XFIntegral,'+',GETDATE(),@CustID;
            SET @errors=@errors+@@ERROR;
		END
	END
	ELSE IF (@Flag='05')
	BEGIN
		INSERT INTO @tmpQty(DeptNo,ItemID,AllocQty)
		SELECT a.DeptNo,b.ItemID,SUM(ISNULL(b.OQty,0.0)+ISNULL(b.ZQty,0.0)-ISNULL(b.SQty,0.0)-ISNULL(b.SZQty,0.0))
		FROM SMS_Order a 
            INNER JOIN SMS_OrderDtl b ON a.OrderNo=b.OrderNo
		WHERE a.OrderNo=@OrderNo AND ISNULL(b.IsSpecial,0)=0
		GROUP BY a.DeptNo, b.ItemID;
        SET @errors=@errors+@@ERROR;
        --取消预占
        DELETE FROM IMS_Advance WHERE orderNo=@orderNo;
		--更新已有商品的已分配量
		UPDATE s SET s.AllocQty=ISNULL(s.AllocQty,0.0)-ISNULL(t.AllocQty,0.0)
		FROM IMS_Subdepot s 
            INNER JOIN @tmpQty t ON s.DeptNo=t.DeptNo AND s.ItemID=t.ItemID;
        SET @errors=@errors+@@ERROR;
        --积分不再处理
	END
	ELSE IF (@Flag='00')		--作废单据
	BEGIN
		--更新销售合同的已执行数量
		UPDATE a SET a.SQty=ISNULL(a.SQty,0)-ISNULL(b.OQty,0)
		FROM CON_SmsDtl a 
            INNER JOIN SMS_OrderDtl b ON a.BillID=b.BillID
		WHERE b.OrderNo=@OrderNo;
        SET @errors=@errors+@@ERROR;
		--更新订单
		DECLARE mycursors CURSOR
		FOR SELECT DISTINCT BillNo FROM SMS_OrderDtl WHERE OrderNo=@OrderNo
		OPEN mycursors
		FETCH NEXT FROM mycursors INTO @BillNo
		WHILE @@fetch_Status=0
		BEGIN
			--存在未执行的记录
			IF EXISTS(SELECT 1 FROM CON_SMSDtl WHERE BillNo=@BillNo And ISNULL(SQty,0.0)>0.0)
				UPDATE CON_SMS SET BillSts='25' WHERE BillNo=@BillNo And BillSts<>'05'
			ELSE
				UPDATE CON_SMS SET BillSts='20' WHERE BillNo=@BillNo And BillSts<>'05'
            SET @errors=@errors+@@ERROR;
			FETCH NEXT FROM mycursors INTO @BillNo
		END
		CLOSE mycursors
		DEALLOCATE mycursors
	END 
    UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='sal_order_job';
    SET @errors=@errors+@@ERROR;
    --事务处理
    IF (@errors=0)
    BEGIN        
        COMMIT;
    END
    ELSE
    BEGIN
        IF @@TRANCOUNT > 0
            ROLLBACK;
        SELECT @ErrMsg=[description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;	
        --写入同步错误日志	
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
        VALUES(LOWER(REPLACE(NEWID(),'-','')),'01',GETDATE(),'99','sp_SMSOrderAudit','SMS_ORDER_AUIDT_ERROR',LEFT(@ErrMsg,2000),@OrderNo,@OrderNo);
        UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='sal_order_job';
    END
END
go

