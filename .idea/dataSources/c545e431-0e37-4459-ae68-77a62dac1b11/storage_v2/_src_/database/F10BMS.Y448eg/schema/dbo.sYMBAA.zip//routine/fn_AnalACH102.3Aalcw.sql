--说明：销售员项目统计
--作者：Devil.H
--创建：2007.11.15
--参数：
--	@Period:年月
--	@Flag:标识
CREATE  function dbo.fn_AnalACH102
(	
	@Period char(6)='200001',
	@StartDate varchar(10),
	@EndDate varchar(10),
	@Flag bit=0
)
Returns @uTable Table(
	Period char(6),
	SalesID bigint,
	Sales varchar(100),
	DeptNo varchar(20),
	DeptName varchar(100),
	OrdAmt decimal(18,6),
	OrdQty decimal(18,6),
	InvAmt decimal(18,6),
	InvQty decimal(18,6),
	CstAmt decimal(18,6),
	InvoiceAmt decimal(18,6),
	GProAmt decimal(18,6),
	GProfit decimal(18,6),
	PayAmt decimal(18,6),
	PAmt decimal(18,6),
	PCstAmt decimal(18,6),
	PGProAmt decimal(18,6),
	PGProfit decimal(18,6),
	DepartId varchar(20),
	DepartName varchar(100)
)
As
begin
	declare @Year int
	declare @Month int
	declare @AmtDec int

	if @Flag=0
		Return
	declare @Tmp Table(
		SalesID bigint,
		DepartId varchar(20),
		OrdAmt decimal(18,6),
		OrdQty decimal(18,6),
		InvAmt decimal(18,6),
		InvQty decimal(18,6),
		CstAmt decimal(18,6),
		InvoiceAmt decimal(18,6),
		GProAmt decimal(18,6),
		GProfit decimal(18,6),
		PayAmt decimal(18,6),
		PAmt decimal(18,6),
		PCstAmt decimal(18,6),
		PGProAmt decimal(18,6),
		LSMSAmt decimal(18,6))

	--当前月起始、截至日期
	Set @Year=Cast(Left(@Period,4) as int)
	set @Month=Cast(right(@Period,2) as int)
	--小数位数
	Select @AmtDec=AmtDec From Sys_Config

	--统计项目金额
	Insert Into @Tmp(SalesID,DepartId,OrdAmt,InvAmt,CstAmt)
	Select a.SalesID,c.DeptNo,SUM(b.ProjectAmt),SUM(b.ProjectJSAmt),Sum(a.CostAmtSum)
	From Prj_Cost a Left Outer Join Prj_Execute b On a.ExecuteNo=b.BillNo
		Inner Join BDM_Customer c ON a.CustID=c.CustID
	Where a.BillSts='20' And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.SalesID,c.DeptNo

	--统计已收完款的发票金额
	Insert Into @Tmp(SalesID,DepartId,InvoiceAmt,PayAmt)
	Select SalesID,DepartId,Isnull(Sum(IAmt),0) As InvoiceAmt,Sum(PAmt) As PayAmt
	From SMS_Invoice
	Where (BillSts='20' Or BillSts='25' Or BillSts='30') 
		And (CreateDate Between @StartDate And @EndDate)
		And InvoiceNo Like '#%'
	Group By SalesID,DepartId

	--汇总
	Insert Into @uTable(SalesID,DepartId,OrdAmt,OrdQty,InvAmt,InvQty,CstAmt,InvoiceAmt,GProAmt,PayAmt,PAmt,PCstAmt,PGProAmt)
	Select SalesID,DepartId,Sum(OrdAmt),Sum(OrdQty),Sum(InvAmt),Sum(InvQty),Sum(CstAmt),Sum(InvoiceAmt),  
		isnull(Sum(InvAmt),0.0)-isnull(Sum(CstAmt),0.0),Sum(PayAmt),Sum(PAmt),Sum(PCstAmt),
		Isnull(Sum(PAmt),0.0)-Isnull(Sum(PCstAmt),0.0)
	From @Tmp
	Group By SalesID,DepartId
	--更新毛利、毛利率
	Update @uTable Set GProfit=case Isnull(InvAmt,0.0) 
				when 0.0 then 0.0 
				else Round((Isnull(InvAmt,0.0)-Isnull(CstAmt,0.0))/Isnull(InvAmt,0.0),@AmtDec*2) end,
			PGProfit=Case Isnull(PAmt,0.0)
				When 0.0 then 0.0
				else Round((Isnull(PAmt,0.0)-Isnull(PCstAmt,0.0))/Isnull(PAmt,0.0),@AmtDec*2) End
	--更新销售员ming
	Update a Set a.Sales=b.EmployeeName,a.DeptNo=left(b.DeptCode,4)	
	From @uTable a,BDM_Employee b	
        Where a.SalesID=b.EmployeeID
	--更新销售员所在部门
	Update a Set a.DeptName=CHName	
	From @uTable a,BDM_DeptCode_V b	
	Where a.DeptNo=b.CodeID

	Update a Set a.DepartName=CHName	
	From @uTable a,BDM_DeptCode_V b	
	Where a.DepartId=b.CodeID
	--返回
	Return
End
go

