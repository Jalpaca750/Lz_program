
--说明：客户商品销售明细分析
--作者：Devil.H
--创建：2010.06.01
--参数：
--	@StartDate:起始日期
--	@EndDate:截止日期
--	@CorpNo:公司No
--	@DeptNo:部门
CREATE FUNCTION dbo.fn_AnalSMS4A
(	
	@StartDate CHAR(10)='0000-01-01',
	@EndDate CHAR(10)='9999-12-31',
	@DeptNo VARCHAR(20)=''
) 
RETURNS TABLE
As
RETURN(	
	SELECT a.StockNo,CASE a.BillType WHEN '10' THEN '出库单' 
                                     WHEN '20' THEN '退货单'
                                     WHEN '30' THEN '调价单'
                                     WHEN '40' THEN '零售单'
                                     WHEN '50' THEN '零售退货' END AS BillType,a.PoNo,
        a.DeptNo,d.CodeNo AS Depart, d.CHName AS DeptName,a.WareHouse,w.CodeNo AS WHNo,w.CHName AS WHName,
        a.CreateDate,a.CustID,c.CustNo,c.CustName,c.NameSpell AS CustSpell,c.CustType,c.TypeName,c.MemberID,
        c.Member,c.AreaCode,c.AreaName,c.PopedomID,c.PopedomName,a.SendAddr,a.LinkMan,a.Phone, a.SalesID,es.EmployeeNo AS SalesNo,
        es.EmployeeName AS Sales,b.ItemID,g.ItemNo,g.ItemName,g.NameSpell AS ItemSpell,g.ItemAlias,g.ItemSpec,
        g.BarCode,g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,g.UnitName,b.SQty,b.DiscountTemp,b.DiscRate,
        b.DiscType,dt.CHName As DiscName,b.Price,b.Amt,Null As ZQty,a.PaidDate,b.PaidAmt,a.DiscAmt,a.CostsID,
        cb.CHName AS CostsName,a.Remarks,g.PkgSpec,g.Defined1,g.Defined2,g.Defined3,g.Defined4,g.Defined5,
        CASE ISNULL(g.PkgRatio,0.0) WHEN 0.0 THEN NULL ELSE ROUND(ISNULL(b.SQty,0.0)/g.PkgRatio,4) END PkgQty,
        a.DepartId,dc.CHName AS DepartName,ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,2) AS RebateAmt,
        ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,2) AS PlatformFee,
        ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,2)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,2) AS RealAmt,
        g.MidBarcode,g.BigBarcode,g.PkgBarcode
	FROM SMS_Stock a 
        INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
        INNER JOIN BAS_Customer_V c ON a.CustID=c.CustID
        INNER JOIN BAS_Goods_V g ON b.ItemID=g.ItemID
        LEFT JOIN BDM_Employee es ON a.SalesID=es.EmployeeID
        LEFT JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
        LEFT JOIN BDM_WareHouse_V w ON a.WareHouse=w.CodeID
        LEFT JOIN Web_Costs_Class cb ON a.CostsID=cb.CostsID
        LEFT JOIN BDM_DiscType_V dt ON b.DiscType=dt.CodeID
        LEFT JOIN BDM_DeptCode_V dc ON a.DepartId=dc.CodeID
	WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		AND (a.BillType='10' Or a.BillType='20' Or a.BillType='40' Or a.BillType='50')
		AND (a.DeptNo Like @DeptNo +'%')
		AND (CONVERT(CHAR(10),CAST(a.CreateDate AS DATETIME),23) BETWEEN @StartDate AND @EndDate)
		AND (ISNULL(b.SQty,0.0)<>0.0)
	UNION ALL
	SELECT a.StockNo,CASE a.BillType WHEN '10' THEN '出库单' 
                					 WHEN '20' THEN '退货单'
                					 WHEN '30' THEN '调价单'
                					 WHEN '40' THEN '零售单'
                					 WHEN '50' THEN '零售退货' END AS BillType,a.PoNo,
        a.DeptNo,d.CodeNo AS Depart, d.CHName AS DeptName,a.WareHouse,w.CodeNo AS WHNo,w.CHName AS WHName,
        a.CreateDate,a.CustID,c.CustNo,c.CustName,c.NameSpell AS CustSpell,c.CustType,c.TypeName,c.MemberID,
        c.Member,c.AreaCode,c.AreaName,c.PopedomID,c.PopedomName,a.SendAddr,a.LinkMan,a.Phone,a.SalesID,es.EmployeeNo AS SalesNo,
        es.EmployeeName AS Sales,b.ItemID,g.ItemNo,g.ItemName,g.NameSpell AS ItemSpell,g.ItemAlias,g.ItemSpec,
        g.BarCode,g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,g.UnitName,b.SQty,b.DiscountTemp,b.DiscRate,
        b.DiscType,dt.CHName As DiscName,b.Price,b.Amt,b.ZQty,a.PaidDate,b.PaidAmt,a.DiscAmt,a.CostsID,cb.CHName AS CostsName,
        a.Remarks,g.PkgSpec,g.Defined1,g.Defined2,g.Defined3,g.Defined4,g.Defined5,
        CASE ISNULL(g.PkgRatio,0.0) WHEN 0.0 THEN NULL ELSE ROUND(ISNULL(b.SQty,0.0)/g.PkgRatio,4) END PkgQty,
        a.DepartId,dc.CHName AS DepartName,ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,2) AS RebateAmt,
        ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,2) AS PlatformFee,
        ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,2)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,2) AS RealAmt,
        g.MidBarcode,g.BigBarcode,g.PkgBarcode
	FROM SMS_Stock a 
        INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
        INNER JOIN BAS_Customer_V c ON a.CustID=c.CustID
        INNER JOIN BAS_Goods_V g ON b.ItemID=g.ItemID
        LEFT JOIN BDM_Employee es ON a.SalesID=es.EmployeeID
        LEFT JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
        LEFT JOIN BDM_WareHouse_V w ON a.WareHouse=w.CodeID
        LEFT JOIN Web_Costs_Class cb ON a.CostsID=cb.CostsID
        LEFT JOIN BDM_DiscType_V dt ON b.DiscType=dt.CodeID
        LEFT JOIN BDM_DeptCode_V dc ON a.DepartId=dc.CodeID
	WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
        AND (a.BillType='30')
		AND (a.DeptNo Like @DeptNo +'%')
		AND (CONVERT(CHAR(10),CAST(a.CreateDate AS DATETIME),23) BETWEEN @StartDate AND @EndDate)
	UNION ALL
	SELECT a.StockNo, '赠品' AS BillType,a.PoNo,
        a.DeptNo,d.CodeNo AS Depart, d.CHName AS DeptName,a.WareHouse,w.CodeNo AS WHNo,w.CHName AS WHName,
        a.CreateDate,a.CustID,c.CustNo,c.CustName,c.NameSpell AS CustSpell,c.CustType,c.TypeName,c.MemberID,
        c.Member,c.AreaCode,c.AreaName,c.PopedomID,c.PopedomName,a.SendAddr,a.LinkMan,a.Phone,a.SalesID,es.EmployeeNo AS SalesNo,
        es.EmployeeName AS Sales,b.ItemID,g.ItemNo,g.ItemName,g.NameSpell AS ItemSpell,g.ItemAlias,g.ItemSpec,
        g.BarCode,g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,g.UnitName,b.ZQty,Null As DiscountTemp,
        Null As DiscRate,b.DiscType,dt.CHName As DiscName,Null As Price,Null As Amt,Null As ZQty,a.PaidDate,
        b.PaidAmt,a.DiscAmt,a.CostsID,cb.CHName AS CostsName,a.Remarks,g.PkgSpec,g.Defined1,g.Defined2,g.Defined3,
        g.Defined4,g.Defined5,CASE ISNULL(g.PkgRatio,0.0) WHEN 0.0 THEN NULL ELSE ROUND(ISNULL(b.SQty,0.0)/g.PkgRatio,4) END PkgQty,
        a.DepartId,dc.CHName AS DepartName,NULL AS RebateAmt,NULL AS PlatformFee,NULL AS RealAmt,g.MidBarcode,
        g.BigBarcode,g.PkgBarcode
	FROM SMS_Stock a 
        INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
        INNER JOIN BAS_Customer_V c ON a.CustID=c.CustID
        INNER JOIN BAS_Goods_V g ON b.ItemID=g.ItemID
        LEFT JOIN BDM_Employee es ON a.SalesID=es.EmployeeID
        LEFT JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
        LEFT JOIN BDM_WareHouse_V w ON a.WareHouse=w.CodeID
        LEFT JOIN Web_Costs_Class cb ON a.CostsID=cb.CostsID
        LEFT JOIN BDM_DiscType_V dt ON b.DiscType=dt.CodeID
        LEFT JOIN BDM_DeptCode_V dc ON a.DepartId=dc.CodeID
	WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		AND (a.DeptNo Like @DeptNo +'%')
		AND (CONVERT(CHAR(10),CAST(a.CreateDate AS DATETIME),23) BETWEEN @StartDate AND @EndDate)
		AND (ISNULL(b.ZQty,0.0)<>0.0)
)
go

