

--说明：客户销售月报
--作者：Devil.H
--创建：2007.11.11
--参数：
--	@Year:年度
--	@Month:月份
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag：标志
--修改：2021-03-17 增加销售员维度(原销售员跟随客户资料，改为跟随单据）
CREATE Function [dbo].[fn_AnalSMS50]
(
	@Year int=0,
	@Month int=0,
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	CustID bigint,
	CustNo varchar(20),
	CustName varchar(200),
	NameSpell varchar(200),
	AreaCode varchar(20),
	AreaName varchar(100),
	MemberID varchar(20),
	Member varchar(100),
	PopedomID varchar(20),
	PopedomName varchar(100),
	CustType varchar(20),
	TypeName varchar(100),
	TradeName varchar(100),
	KindName varchar(100),
	SalesID bigint,
	Sales varchar(100),
	Day01Amt decimal(18,6),
	Day02Amt decimal(18,6),
	Day03Amt decimal(18,6),
	Day04Amt decimal(18,6),
	Day05Amt decimal(18,6),
	Day06Amt decimal(18,6),
	Day07Amt decimal(18,6),
	Day08Amt decimal(18,6),
	Day09Amt decimal(18,6),
	Day10Amt decimal(18,6),
	Day11Amt decimal(18,6),
	Day12Amt decimal(18,6),
	Day13Amt decimal(18,6),
	Day14Amt decimal(18,6),
	Day15Amt decimal(18,6),
	Day16Amt decimal(18,6),
	Day17Amt decimal(18,6),
	Day18Amt decimal(18,6),
	Day19Amt decimal(18,6),
	Day20Amt decimal(18,6),
	Day21Amt decimal(18,6),
	Day22Amt decimal(18,6),
	Day23Amt decimal(18,6),
	Day24Amt decimal(18,6),
	Day25Amt decimal(18,6),
	Day26Amt decimal(18,6),
	Day27Amt decimal(18,6),
	Day28Amt decimal(18,6),
	Day29Amt decimal(18,6),
	Day30Amt decimal(18,6),
	Day31Amt decimal(18,6),
	TotalAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40),
	DepartId varchar(20),
	DepartName varchar(100)
)
As
Begin	
	if @Flag=0 
		return
	--********增加会计月份时间处理***********************
	declare @CW_Month_BDate char(10)
	declare @CW_Month_EDate char(10)
	Set @CW_Month_BDate=(select CW_Month from dbo.uf_Get_CW_Month(1,@Year,@Month))
	Set @CW_Month_EDate=(select CW_Month from dbo.uf_Get_CW_Month(2,@Year,@Month))
	--**********************************************
	Insert Into @uTable(CustID,DepartId,SalesID,Day01Amt,Day02Amt,Day03Amt,Day04Amt,Day05Amt,Day06Amt,Day07Amt,
		Day08Amt,Day09Amt,Day10Amt,Day11Amt,Day12Amt,Day13Amt,Day14Amt,Day15Amt,Day16Amt,Day17Amt,
		Day18Amt,Day19Amt,Day20Amt,Day21Amt,Day22Amt,Day23Amt,Day24Amt,Day25Amt,Day26Amt,Day27Amt,
		Day28Amt,Day29Amt,Day30Amt,Day31Amt,TotalAmt)
	Select a.CustID,a.DepartId,a.SalesID,
		Day01Amt=Sum(Case Day(a.CreateDate) When 1 then b.Amt else 0.0 end),
		Day02Amt=Sum(Case Day(a.CreateDate) When 2 then b.Amt else 0.0 end),
		Day03Amt=Sum(Case Day(a.CreateDate) When 3 then b.Amt else 0.0 end),
		Day04Amt=Sum(Case Day(a.CreateDate) When 4 then b.Amt else 0.0 end),
		Day05Amt=Sum(Case Day(a.CreateDate) When 5 then b.Amt else 0.0 end),
		Day06Amt=Sum(Case Day(a.CreateDate) When 6 then b.Amt else 0.0 end),
		Day07Amt=Sum(Case Day(a.CreateDate) When 7 then b.Amt else 0.0 end),
		Day08Amt=Sum(Case Day(a.CreateDate) When 8 then b.Amt else 0.0 end),
		Day09Amt=Sum(Case Day(a.CreateDate) When 9 then b.Amt else 0.0 end),
		Day10Amt=Sum(Case Day(a.CreateDate) When 10 then b.Amt else 0.0 end),
		Day11Amt=Sum(Case Day(a.CreateDate) When 11 then b.Amt else 0.0 end),
		Day12Amt=Sum(Case Day(a.CreateDate) When 12 then b.Amt else 0.0 end),
		Day13Amt=Sum(Case Day(a.CreateDate) When 13 then b.Amt else 0.0 end),
		Day14Amt=Sum(Case Day(a.CreateDate) When 14 then b.Amt else 0.0 end),
		Day15Amt=Sum(Case Day(a.CreateDate) When 15 then b.Amt else 0.0 end),
		Day16Amt=Sum(Case Day(a.CreateDate) When 16 then b.Amt else 0.0 end),
		Day17Amt=Sum(Case Day(a.CreateDate) When 17 then b.Amt else 0.0 end),
		Day18Amt=Sum(Case Day(a.CreateDate) When 18 then b.Amt else 0.0 end),
		Day19Amt=Sum(Case Day(a.CreateDate) When 19 then b.Amt else 0.0 end),
		Day20Amt=Sum(Case Day(a.CreateDate) When 20 then b.Amt else 0.0 end),
		Day21Amt=Sum(Case Day(a.CreateDate) When 21 then b.Amt else 0.0 end),
		Day22Amt=Sum(Case Day(a.CreateDate) When 22 then b.Amt else 0.0 end),
		Day23Amt=Sum(Case Day(a.CreateDate) When 23 then b.Amt else 0.0 end),
		Day24Amt=Sum(Case Day(a.CreateDate) When 24 then b.Amt else 0.0 end),
		Day25Amt=Sum(Case Day(a.CreateDate) When 25 then b.Amt else 0.0 end),
		Day26Amt=Sum(Case Day(a.CreateDate) When 26 then b.Amt else 0.0 end),
		Day27Amt=Sum(Case Day(a.CreateDate) When 27 then b.Amt else 0.0 end),
		Day28Amt=Sum(Case Day(a.CreateDate) When 28 then b.Amt else 0.0 end),
		Day29Amt=Sum(Case Day(a.CreateDate) When 29 then b.Amt else 0.0 end),
		Day30Amt=Sum(Case Day(a.CreateDate) When 30 then b.Amt else 0.0 end),
		Day31Amt=Sum(Case Day(a.CreateDate) When 31 then b.Amt else 0.0 end),
		TotalAmt=Sum(b.Amt)
	From SMS_Stock a inner join SMS_StockDtl b On a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By a.CustID,a.SalesID, a.DepartId;

	--更新客户资料
	Update a Set a.CustNo=b.CustNo,a.CustName=b.CustName,a.NameSpell=b.NameSpell,a.AreaCode=b.AreaCode,
		a.AreaName=b.AreaName,a.MemberID=b.MemberID,a.PopedomID=b.PopedomID,a.CustType=b.CustType,
		a.Member=b.Member,a.PopedomName=b.PopedomName,a.TypeName=b.TypeName,a.KindName=b.KindName,
		a.TradeName=b.TradeName,a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes
	From @uTable a 
	    INNER JOIN BAS_Customer_V b ON a.CustID=b.CustID
    Update a Set a.DepartName=c.CHName
	From @uTable a 
	    INNER JOIN BDM_DeptCode_V c ON a.DepartId=c.CodeID
	Update a Set a.Sales=b.EmployeeName
	From @uTable a
	    INNER JOIN BDM_Employee b ON a.SalesID=b.EmployeeID
	--更新客户信息
 	return
End


go

