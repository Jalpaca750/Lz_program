
--说明：商品年度销售分析
--作者：Devil.H
--创建：2007.11.16
--参数：
--	@Years:年度
--	@CorpNo:公司编码
--	@DeptNo:部门编码
--	@Flag
CREATE  Function dbo.fn_AnalSMS6A
(
	@Years int=0,
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	NameSpell varchar(200),
	ItemAlias varchar(200),
	ItemSpec varchar(100),
	BarCode varchar(100),
	ClassID varchar(20),
	ClassName Varchar(100),
	LabelID varchar(20),
	LabelName varchar(100),
	ColorName varchar(40),
	UnitName varchar(40),
	PkgSpec varchar(40),
	Month01Amt decimal(18,6),
	Month02Amt decimal(18,6),
	Month03Amt decimal(18,6),
	Month04Amt decimal(18,6),
	Month05Amt decimal(18,6),
	Month06Amt decimal(18,6),
	Month07Amt decimal(18,6),
	Month08Amt decimal(18,6),
	Month09Amt decimal(18,6),
	Month10Amt decimal(18,6),
	Month11Amt decimal(18,6),
	Month12Amt decimal(18,6),
	Month01Qty decimal(18,6),
	Month02Qty decimal(18,6),
	Month03Qty decimal(18,6),
	Month04Qty decimal(18,6),
	Month05Qty decimal(18,6),
	Month06Qty decimal(18,6),
	Month07Qty decimal(18,6),
	Month08Qty decimal(18,6),
	Month09Qty decimal(18,6),
	Month10Qty decimal(18,6),
	Month11Qty decimal(18,6),
	Month12Qty decimal(18,6),
	Month01Pkg decimal(18,6),
	Month02Pkg decimal(18,6),
	Month03Pkg decimal(18,6),
	Month04Pkg decimal(18,6),
	Month05Pkg decimal(18,6),
	Month06Pkg decimal(18,6),
	Month07Pkg decimal(18,6),
	Month08Pkg decimal(18,6),
	Month09Pkg decimal(18,6),
	Month10Pkg decimal(18,6),
	Month11Pkg decimal(18,6),
	Month12Pkg decimal(18,6),
	TotalQty decimal(18,6),
	TotalAmt decimal(18,6),
	TotalPkg decimal(18,6),
	DepartId varchar(20),
	DepartName varchar(100)
)
As
Begin
	if @Flag=0 
		Return

	Insert Into @uTable(DepartId,ItemID,Month01Amt,Month02Amt,Month03Amt,Month04Amt,
				   Month05Amt,Month06Amt,Month07Amt,Month08Amt,
				   Month09Amt,Month10Amt,Month11Amt,Month12Amt,
			           Month01Qty,Month02Qty,Month03Qty,Month04Qty,
                                   Month05Qty,Month06Qty,Month07Qty,Month08Qty,
                                   Month09Qty,Month10Qty,Month11Qty,Month12Qty,TotalQty,TotalAmt)
	Select a.DepartId,b.ItemID,
		Month01Amt=sum(case Month(a.CreateDate) when 1 then b.Amt else 0.0 end),
		Month02Amt=sum(case Month(a.CreateDate) when 2 then b.Amt else 0.0 end),
		Month03Amt=sum(case Month(a.CreateDate) when 3 then b.Amt else 0.0 end),
		Month04Amt=sum(case Month(a.CreateDate) when 4 then b.Amt else 0.0 end),
		Month05Amt=sum(case Month(a.CreateDate) when 5 then b.Amt else 0.0 end),
		Month06Amt=sum(case Month(a.CreateDate) when 6 then b.Amt else 0.0 end),
		Month07Amt=sum(case Month(a.CreateDate) when 7 then b.Amt else 0.0 end),
		Month08Amt=sum(case Month(a.CreateDate) when 8 then b.Amt else 0.0 end),
		Month09Amt=sum(case Month(a.CreateDate) when 9 then b.Amt else 0.0 end),
		Month10Amt=sum(case Month(a.CreateDate) when 10 then b.Amt else 0.0 end),
		Month11Amt=sum(case Month(a.CreateDate) when 11 then b.Amt else 0.0 end),
		Month12Amt=sum(case Month(a.CreateDate) when 12 then b.Amt else 0.0 end),
		Month01Qty=sum(case Month(a.CreateDate) when 1 then b.Sqty else 0.0 end),
		Month02Qty=sum(case Month(a.CreateDate) when 2 then b.Sqty else 0.0 end),
		Month03Qty=sum(case Month(a.CreateDate) when 3 then b.Sqty else 0.0 end),
		Month04Qty=sum(case Month(a.CreateDate) when 4 then b.Sqty else 0.0 end),
		Month05Qty=sum(case Month(a.CreateDate) when 5 then b.Sqty else 0.0 end),
		Month06Qty=sum(case Month(a.CreateDate) when 6 then b.Sqty else 0.0 end),
		Month07Qty=sum(case Month(a.CreateDate) when 7 then b.Sqty else 0.0 end),
		Month08Qty=sum(case Month(a.CreateDate) when 8 then b.Sqty else 0.0 end),
		Month09Qty=sum(case Month(a.CreateDate) when 9 then b.Sqty else 0.0 end),
		Month10Qty=sum(case Month(a.CreateDate) when 10 then b.Sqty else 0.0 end),
		Month11Qty=sum(case Month(a.CreateDate) when 11 then b.Sqty else 0.0 end),
		Month12Qty=sum(case Month(a.CreateDate) when 12 then b.Sqty else 0.0 end),
		TotalQty=sum(b.Sqty),TotalAmt=sum(b.Amt)
	From SMS_Stock a inner join SMS_StockDtl b On a.StockNo=b.StockNo
	Where Year(a.CreateDate)=@Years And (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group By a.DepartId,b.ItemID
	--更新
	Update a Set a.ItemNo=b.ItemNo,a.ItemName=b.ItemName,a.ItemSpec=b.ItemSpec,a.NameSpell=b.NameSpell,
		a.ItemAlias=b.ItemAlias,a.BarCode=b.BarCode,a.ClassID=b.ClassID,a.LabelID=b.LabelID,a.ColorName=b.ColorName,
		a.UnitName=b.UnitName,a.ClassName=b.ClassName,a.LabelName=b.LabelName,a.PkgSpec=b.PkgSpec,
		a.Month01Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month01Qty,0.0)/b.PkgRatio,4) End,
		a.Month02Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month02Qty,0.0)/b.PkgRatio,4) End,
		a.Month03Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month03Qty,0.0)/b.PkgRatio,4) End,
		a.Month04Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month04Qty,0.0)/b.PkgRatio,4) End,
		a.Month05Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month05Qty,0.0)/b.PkgRatio,4) End,
		a.Month06Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month06Qty,0.0)/b.PkgRatio,4) End,
		a.Month07Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month07Qty,0.0)/b.PkgRatio,4) End,
		a.Month08Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month08Qty,0.0)/b.PkgRatio,4) End,
		a.Month09Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month09Qty,0.0)/b.PkgRatio,4) End,
		a.Month10Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month10Qty,0.0)/b.PkgRatio,4) End,
		a.Month11Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month11Qty,0.0)/b.PkgRatio,4) End,
		a.Month12Pkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.Month12Qty,0.0)/b.PkgRatio,4) End,
		a.TotalPkg=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.TotalQty,0.0)/b.PkgRatio,4) End
	From @uTable a inner join BAS_Goods_V b on a.ItemID=b.ItemID
	Update a Set a.DepartName=d.CHName FROM @uTable a INNER JOIN BDM_DeptCode_V d ON a.DepartId=d.CodeId
	Return
End
go

