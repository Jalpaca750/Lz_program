CREATE VIEW dbo.SMS_Logistics_Analyze_V
AS
SELECT a.StockNo, a.CustID, a.CreateDate, b.OrderNo, b.Amt, a.CostsID, 
      c.CHName AS CostsName, a.PH_OperatorID, a.CarNumberSts, a.BillSts, 
      a.BillType,ISNULL(t.CarNoName, l.logisticsBill) AS logisticsBill, 
      ISNULL(t.CarRen, l.logistics) AS logistics,a.SignName,
      ISNULL(t.CarDate,CONVERT(VARCHAR(10),l.logisticsTime,120)) AS logisticsTime, a.Remarks
FROM dbo.SMS_Stock a INNER JOIN
      (SELECT StockNo, OrderNo, SUM(Amt) AS Amt
       FROM SMS_StockDtl
       GROUP BY StockNo, OrderNo) b ON a.StockNo = b.StockNo LEFT OUTER JOIN
      dbo.Web_Costs_Class c ON a.CostsID = c.CostsID LEFT OUTER JOIN
      (SELECT a1.stockNo, a1.logisticsBill, a1.logisticsTime,a2.CHName AS logistics
       FROM SMS_Stock_Logistics a1 INNER JOIN 
             BDM_Code a2 ON a1.logisticsId = a2.CodeID) l ON a.StockNo = l.stockNo LEFT OUTER JOIN
      (SELECT y.StockNo, x.CarNo, z.CHName AS CarNoName,e.EmployeeName AS CarRen,x.CarDate
       FROM SMS_CarNumber x INNER JOIN
               SMS_CarNumberDtl y ON (x.CarNumberNo = y.CarNumberNo) INNER JOIN
               BDM_CarNo_V z ON x.CarNo = z.CodeID LEFT JOIN
               BDM_Employee e ON x.CarRenID = e.EmployeeID) t ON a.StockNo = t.StockNo
go

