CREATE VIEW dbo.SMS_Rectify_V
AS
SELECT a.RectifyNo, a.CreateDate, a.DeptNo, f.CHName AS DeptName, a.CustID, b.CustNo, 
    b.CustName, b.NameSpell, b.CustType, b.TypeName, b.MemberID, b.Member,b.AreaCode,  
    b.AreaName, b.PopedomID, b.PopedomName, a.LinkMan, a.Phone,b.Faxes, a.SalesID,  
    g.EmployeeName AS Sales, a.SendAddr, a.Effect, e.Amt, a.BillSts,a.PFlag,  
    (SELECT StsName FROM BillStatus h WHERE h.BillSts=a.BillSts And h.BillType='SMS70') AS StsName, 
    a.CostsID, cb.CHName As CostsName,a.AuditDate, a.AuditID, d.EmployeeName AS Auditer, 
    a.PrintNum,a.PrinterID,p.EmployeeName As Printer, a.CreatorID, c.EmployeeName AS Creator, 
    a.HandlerID, h.EmployeeName As Handler,a.Remarks,a.DepartId,dt.CHName AS DepartName,
    a.CheckBox
FROM dbo.SMS_Rectify a 
    LEFT JOIN dbo.BDM_Employee g ON g.EmployeeID = a.SalesID 
    LEFT JOIN dbo.BDM_Employee d ON a.AuditID = d.EmployeeID 
    LEFT JOIN dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID 
    LEFT JOIN dbo.BAS_Customer_V b ON a.CustID = b.CustID 
    LEFT JOIN (SELECT RectifyNo, SUM(Amt) AS Amt
               FROM SMS_RectifyDtl
               GROUP BY RectifyNo) e ON a.RectifyNo = e.RectifyNo 
    LEFT JOIN dbo.BDM_DeptCode_V f ON a.DeptNo = f.CodeID 
    LEFT JOIN dbo.Web_Costs_Class cb ON a.CostsID = cb.CostsID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID=p.EmployeeID 
    LEFT JOIN dbo.BDM_Employee h ON a.HandlerID=h.EmployeeID 
    LEFT JOIN dbo.BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
go

