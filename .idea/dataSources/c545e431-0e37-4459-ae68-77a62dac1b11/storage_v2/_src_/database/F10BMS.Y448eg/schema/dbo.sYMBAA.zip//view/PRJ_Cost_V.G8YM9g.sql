CREATE VIEW dbo.PRJ_Cost_V
AS
SELECT a.BillNo, a.CreateDate, a.DeptNo, a.CustID, a.BillSts, a.InvoiceNo, a.Remarks, 
      a.OrderNo, a.ExecuteNo, a.PFlag, a.AuditDate, a.AuditID, a.CreatorID, 
      f.EmployeeName AS Creator, H.EmployeeName AS Auditer, 
      (Select StsName From BillStatus g Where g.BillType = 'PRJ30' And a.BillSts=g.BillSts) As StsName,
      c.CustNo, c.CustName, c.NameSpell, c.CustType, c.TypeName, c.MemberID, 
      c.Member, c.AreaCode, c.AreaName, c.PopedomID, c.PopedomName, c.LinkMan, 
      c.Phone, c.Faxes, c.SendAddr, K.JBRen, K.ExecRen, K.ExecSts, K.ProjectAmt, 
      K.ProjectJSAmt, K.ExecAddress, K.ExecBegin, K.ExecContent, 
      b.CHName AS DeptName, b.CodeNo, a.CostAmtSum, a.Cost01, a.Cost02, a.Cost03, 
      a.Cost04, a.Cost05, a.Cost06, a.Cost07, a.Cost08, a.Amt, a.SY01, a.SY02, a.SY03, 
      a.SalesID, M.RemAmt, a.CheckBox
FROM dbo.PRJ_Cost a LEFT OUTER JOIN
      dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID LEFT OUTER JOIN
      dbo.BDM_Customer_V c ON a.CustID = c.CustID LEFT OUTER JOIN
      dbo.BDM_Employee f ON a.CreatorID = f.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee H ON a.AuditID = H.EmployeeID LEFT OUTER JOIN
      dbo.PRJ_Execute_V K ON a.ExecuteNo = K.BillNo LEFT OUTER JOIN
      dbo.SMS_Invoice_V M ON '#' + a.BillNo = M.InvoiceNo
go

