--说明：销售员业绩统计
--作者：Devil.H
--创建：2010.11.16
--参数：
--	@Period:年月
--	@Flag:标识
CREATE FUNCTION [dbo].[fn_AnalACH101]
(	
	@Period CHAR(6)='200001',
	@StartDate VARCHAR(10)='',
	@EndDate VARCHAR(10)='',
	@Flag INT=0
)
RETURNS @uTABLE TABLE(
	Period CHAR(6),
	SalesID BIGINT,
	Sales VARCHAR(100),
	DeptNo VARCHAR(20),
	DeptName VARCHAR(100),
	OrdAmt DECIMAL(18,6),
	OrdQty DECIMAL(18,6),
	InvAmt DECIMAL(18,6),
	InvQty DECIMAL(18,6),
	CstAmt DECIMAL(18,6),
	GProAmt DECIMAL(18,6),
	GProfit DECIMAL(18,6),
	PayAmt DECIMAL(18,6),
	PAmt DECIMAL(18,6),
	PCstAmt DECIMAL(18,6),
	PGProAmt DECIMAL(18,6),
	PGProfit DECIMAL(18,6),
    SalFee DECIMAL(18,6),
    PayFee DECIMAL(18,6),
	DepartId VARCHAR(20),
	DepartName VARCHAR(100)
)
AS
BEGIN	
	IF (@Flag=0)
		RETURN;
    --临时成本表
    DECLARE @CostTmp TABLE(DeptNo VARCHAR(20),ItemID BIGINT,Price DECIMAL(18,10) PRIMARY KEY(DeptNo,ItemID));
	--临时表
	DECLARE @Tmp TABLE(SalesID BIGINT,DeptNo VARCHAR(20),DepartId VARCHAR(20),OrdAmt DECIMAL(18,6),OrdQty DECIMAL(18,6),InvAmt DECIMAL(18,6),InvQty DECIMAL(18,6),CstAmt DECIMAL(18,6),GProAmt DECIMAL(18,6),GProfit DECIMAL(18,6),PayAmt DECIMAL(18,6),PAmt DECIMAL(18,6),PCstAmt DECIMAL(18,6),PGProAmt DECIMAL(18,6),LSMSAmt DECIMAL(18,6),SalFee DECIMAL(18,6),PayFee DECIMAL(18,6));
	--临时销售表
	DECLARE @TmpSales TABLE (RowID BIGINT IDENTITY(1,1),SalesID BIGINT,DeptNo VARCHAR(20),DepartId VARCHAR(20),ItemID BIGINT,SQty DECIMAL(18,6),Price DECIMAL(18,6),IsSpecial BIT,Amt DECIMAL(18,6),Discount DECIMAL(18,6),OrderID BIGINT PRIMARY KEY(RowID));
	--定制成本
	DECLARE @Special TABLE(OrderID BIGINT,ItemID BIGINT,Price DECIMAL(18,6));
	--金额小数位数
	DECLARE @AmtDec INT;
	SELECT @AmtDec=AmtDec FROM Sys_Config;
	--统计销售订单金额
	INSERT INTO @Tmp(SalesID,DeptNo,OrdAmt,OrdQty)
	SELECT a.SalesID,a.DeptNo,SUM(ROUND(ISNULL(b.Price,0.0)*ISNULL(b.OQty,0.0),@AmtDec)) AS OrdAmt,SUM(b.SQty) AS OrdQty
	FROM SMS_Order a 
	    INNER JOIN SMS_OrderDtl b ON a.OrderNo=b.OrderNo
	WHERE (a.BillSts IN('20','25','30','05'))
	    AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
	GROUP BY a.SalesID,a.DeptNo;
	--符合条件的销售数据到临时表 
	INSERT INTO @TmpSales(SalesID,DeptNo,ItemID,SQty,Price,Amt,IsSpecial,OrderID,Discount)
	SELECT a.SalesID,a.DeptNo,b.ItemID,ISNULL(b.SQty,0)+ISNULL(b.ZQty,0.0),b.Price,b.Amt,ISNULL(b.IsSpecial,0),b.OrderID,ISNULL(c.Rebate,0.0)+ISNULL(c.PlatformFee,0.0)
	FROM SMS_Stock a 
	    INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo 
        INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	Where (a.BillSts IN('20','25','30')) 
		AND (a.CreateDate BETWEEN @StartDate AND @EndDate);
    --获取临时成本
	INSERT INTO @CostTmp(DeptNo,ItemID,Price)
	SELECT ISNULL(DeptNo,'$$$$'),ItemID,MEPrice
	FROM uf_CostPrice(@Period);	
    --成本统计（分部成本法）
	IF EXISTS(SELECT * FROM SYS_Config WHERE ISNULL(Method,'S')='S')
		UPDATE a SET a.Price=b.Price
		FROM @TmpSales a 
		    INNER JOIN @CostTmp b ON a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID;
	ELSE
		UPDATE a SET a.Price=b.Price
		FROM @TmpSales a 
            INNER JOIN @CostTmp b On b.DeptNo='$$$$' AND a.ItemID=b.ItemID;
    --定制品成本
	INSERT INTO @Special(OrderID,ItemID,Price)
	SELECT y.XS_OrderID,y.ItemID,y.Price 
 	FROM PMS_Stock x 
 	    INNER JOIN PMS_StockDtl y ON x.StockNo=y.StockNo
 	WHERE (x.BillSts IN('20','25','30'))
        AND EXISTS(SELECT * FROM @TmpSales t WHERE y.XS_OrderID=t.OrderID);        
	--更新定制成本
	UPDATE a SET a.Price=b.Price
	FROM @TmpSales a 
	    INNER JOIN @Special b ON a.OrderID=b.OrderID;
	--汇总销售额、成本
    INSERT INTO @Tmp(SalesID,DeptNo,InvQty,InvAmt,CstAmt,GProAmt,SalFee)    
	SELECT SalesID,DeptNo,SUM(SQty),SUM(Amt),SUM(ROUND(ISNULL(SQty,0.0)*ISNULL(Price,0.0),@AmtDec)),
	    SUM(ISNULL(Amt,0.0)-ROUND(ISNULL(SQty,0.0)*ISNULL(Price,0.0),@AmtDec)),
        SUM(ISNULL(Amt,0.0)*(Discount/100.0))
    FROM @TmpSales
    GROUP BY SalesID,DeptNo;
	--统计当前月收款
	INSERT INTO @Tmp(SalesID,DeptNo,PayAmt,PayFee)
	SELECT a.SalesID,a.DeptNo,SUM(b.PayAmt) AS PayAmt,SUM(b.PayAmt*(ISNULL(c.PlatformFee,0.0)+ISNULL(c.Rebate,0.0))/100.0)
	FROM SMS_Payment a 
	    INNER JOIN SMS_PaymentDtl b ON a.PaymentNo=b.PaymentNo
        INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	WHERE (a.BillSts='20') 
		AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
	GROUP BY a.SalesID,a.DeptNo;

	--统计销售收现金
	INSERT INTO @Tmp(SalesID,DeptNo,PayAmt,PayFee)
	SELECT a.SalesID,a.DeptNo,SUM(a.PaidAmt),SUM(a.PaidAmt*(ISNULL(c.PlatformFee,0.0)+ISNULL(c.Rebate,0.0))/100.0)
	FROM SMS_Stock a
        INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	WHERE (a.BillSts IN('20','25','30'))
	    AND (a.PaidDate BETWEEN @StartDate AND @EndDate)
		AND (ISNULL(a.PaidAmt,0.0)<>0.0)
	GROUP BY a.SalesID,a.DeptNo;

	--统计零售收现金
	INSERT INTO @Tmp(SalesID,DeptNo,PayAmt,PAmt)
	SELECT a.SalesID,a.DeptNo,SUM(CASE a.BillType WHEN '40' THEN ISNULL(b.Amt,0.0)-ISNULL(a.DiscAmt,0.0)
					                     WHEN '50' THEN ISNULL(a.DiscAmt,0.0)-ISNULL(b.Amt,0.0) END),
                     SUM(CASE a.BillType WHEN '40' THEN ISNULL(b.Amt,0.0)-ISNULL(a.DiscAmt,0.0)
					                     WHEN '50' THEN ISNULL(a.DiscAmt,0.0)-ISNULL(b.Amt,0.0) END)
	FROM SMS_Retail a 
	    INNER JOIN (SELECT RetailNo,SUM(Amt) AS Amt 
                    FROM SMS_RetailDtl
                    GROUP BY RetailNo) b ON a.RetailNo=b.RetailNo
		INNER JOIN BDM_Customer c ON a.CustID=c.CustId
	WHERE (a.BillSts IN('20','25','30'))
        AND (a.CreateDate BETWEEN @StartDate AND @EndDate)
	GROUP BY a.SalesID,a.DeptNo;

	--清除数据
	DELETE FROM @TmpSales;
	INSERT INTO @TmpSales(SalesID,DeptNo,ItemID,SQty,OrderID,IsSpecial)
	SELECT a.SalesID,a.DeptNo,b.ItemID,ISNULL(b.IQty,0),b.OrderID,ISNULL(b.IsSpecial,0)
	FROM SMS_Invoice a 
	    INNER JOIN SMS_InvoiceDtl b ON a.InvoiceNo=b.InvoiceNo 
	WHERE (a.BillSts IN('20','25','30')) 
		AND (a.PDate BETWEEN @StartDate AND @EndDate)
		AND (ISNULL(a.IAmt,0.0)-ISNULL(a.PAmt,0.0)<=0.0);
	--成本统计（分部成本法）
	IF EXISTS(SELECT * FROM SYS_Config WHERE ISNULL(Method,'S')='S')
		UPDATE a SET a.Price=b.Price
		FROM @TmpSales a 
		    INNER JOIN @CostTmp b ON a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID;
	ELSE
		UPDATE a SET a.Price=b.Price
		FROM @TmpSales a 
            INNER JOIN @CostTmp b ON b.DeptNo='$$$$' AND a.ItemID=b.ItemID;	
	--更新定制成本
	UPDATE a SET a.Price=b.Price
	FROM @TmpSales a 
	    INNER JOIN @Special b ON a.OrderID=b.OrderID;
	INSERT INTO @Tmp(SalesID,DeptNo,PCstAmt)
	SELECT SalesID,DeptNo,SUM(ROUND(ISNULL(SQty,0.0)*ISNULL(Price,0.0),@AmtDec))
	FROM @TmpSales
	GROUP BY SalesID,DeptNo;	    	
	--统计已收完款的发票金额/成本金额
	INSERT INTO @Tmp(SalesID,DeptNo,PAmt)
	SELECT a.SalesID,DeptNo,SUM(ISNULL(b.PayAmt,0.0)-ISNULL(b.FAmt,0.0)) As PAmt
	FROM SMS_Invoice a 
	    LEFT JOIN SMS_PaymentDtl b ON a.InvoiceID=b.InvoiceID
	Where (a.BillSts IN('20','30','25'))
	    AND (a.PDate BETWEEN @StartDate AND @EndDate)
		AND (ISNULL(a.IAmt,0.0)-ISNULL(a.PAmt,0.0)<=0.0) 
	GROUP BY SalesID,DeptNo;
	--汇总
	INSERT INTO @uTable(SalesID,DeptNo,OrdAmt,OrdQty,InvAmt,InvQty,CstAmt,GProAmt,PayAmt,PAmt,PCstAmt,PGProAmt)
	SELECT SalesID,DeptNo,SUM(OrdAmt),SUM(OrdQty),SUM(InvAmt),SUM(InvQty),SUM(ISNULL(CstAmt,0.0)+ISNULL(SalFee,0.0)),
		SUM(ISNULL(GProAmt,0.0)-ISNULL(SalFee,0.0)),SUM(PayAmt),SUM(PAmt),SUM(ISNULL(PCstAmt,0.0)+ISNULL(PayFee,0.0)),
		SUM(ISNULL(PAmt,0.0)-ISNULL(PCstAmt,0.0)-ISNULL(PayFee,0.0))
	FROM @Tmp
	GROUP BY SalesID,DeptNo;
	--更新毛利、毛利率
	UPDATE @uTABLE SET GProfit=CASE ISNULL(InvAmt,0.0) WHEN 0.0 THEN 0.0 
				                                       ELSE ROUND(ISNULL(GProAmt,0.0)/InvAmt,@AmtDec*2) END,
			           PGProfit=CASE ISNULL(PAmt,0.0) WHEN 0.0 THEN 0.0
				                                      ELSE ROUND(ISNULL(PGProAmt,0.0)/PAmt,@AmtDec*2) END;
	--更新销售员ming
	UPDATE a SET a.Sales=b.EmployeeName
	FROM @uTABLE a 
	    INNER JOIN BDM_Employee b ON a.SalesID=b.EmployeeID;
	--更新销售员所在部门
	UPDATE a SET a.DeptName=CHName
	FROM @uTABLE a 
	    INNER JOIN BDM_DeptCode_V b ON a.DeptNo=b.CodeID;
	--返回
	RETURN;
END
go

