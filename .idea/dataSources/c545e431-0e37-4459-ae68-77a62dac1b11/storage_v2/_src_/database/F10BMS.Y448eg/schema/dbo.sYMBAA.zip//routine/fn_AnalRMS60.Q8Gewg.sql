--说明：商品销售毛利统计
--作者：Devil.H
--创建：2007.11.21
--参数：
--	@Year:年分
--	@Month:自然月
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:前台标识
CREATE Function dbo.fn_AnalRMS60
(
	@Year int=0,
	@Month int=0,
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemAlias varchar(200),
	NameSpell varchar(200),
	ItemSpec varchar(100),
	BarCode varchar(100),
	ClassID varchar(20),
	ClassName varchar(100),
	LabelID Varchar(20),
	LabelName varchar(100),
	ColorName varchar(40),
	UnitName varchar(40),
	SQty decimal(18,6),
	Amt decimal(18,6),
	CstAmt decimal(18,6),
	GProAmt decimal(18,6),
	GProfit decimal(18,6)
)
As
Begin
	if @Flag=0 
		Return
	declare @AmtDec int
	declare @Tmp Table(ItemID bigint,
			SQty decimal(18,6),
			Amt decimal(18,6),
			CstAmt decimal(18,6),
			GProAmt decimal(18,6)
			Primary Key(ItemID)
		     )

	Select @AmtDec=Isnull(AmtDec,2) From Sys_Config

	--********增加会计月份时间处理***********************
	declare @CW_Month_BDate char(10)
	declare @CW_Month_EDate char(10)
	Select @CW_Month_BDate=StartDate,@CW_Month_EDate=EndDate 
	From SYS_CW_MonthPeriod 
	Where Year(CW_Period+'01')=@Year And Month(CW_Period+'01')=@Month
	--Set @CW_Month_BDate=(select CW_Month from dbo.uf_Get_CW_Month(1,@Year,@Month))
	--Set @CW_Month_EDate=(select CW_Month from dbo.uf_Get_CW_Month(2,@Year,@Month))
	--**********************************************	
	--获取数据
	Insert Into @Tmp(ItemID,SQty,Amt,CstAmt,GProAmt)
	Select b.ItemID,
		Sum(Isnull(b.SQty,0.0)),
		Sum(Isnull(b.Amt,0.0)),
		Sum(Round(Isnull(b.SQty,0.0)*Isnull(b.CPrice,0.0),@AmtDec)),
		Sum(Round(Isnull(b.Amt,0)-Isnull(b.SQty,0.0)*Isnull(b.CPrice,0.0),@AmtDec))
	From SMS_Stock a Inner Join SMS_StockDtl b On a.StockNo=b.StockNo
	Where (a.BillType='40' Or a.BillType='50') 
		And (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 
			   From BDM_DeptCode_V d 
			   Where a.DeptNo=d.CodeID 
				And (d.DeptNo Like @CorpNo + '%'))
	Group By b.ItemID
	--写入表函数
	Insert Into @uTable(ItemID,ItemNo,ItemName,ItemAlias,NameSpell,ItemSpec,BarCode,
			ClassID,ClassName,LabelID,LabelName,ColorName,UnitName,SQty,Amt,
			CstAmt,GProAmt,GProfit)
	Select a.ItemID,b.ItemNo,b.ItemName,b.ItemAlias,b.NameSpell,b.ItemSpec,b.BarCode,
		b.ClassID,b.ClassName,b.LabelID,b.LabelName,b.ColorName,b.UnitName,a.SQty,
		a.Amt,a.CstAmt,a.GProAmt,Case Isnull(a.Amt,0.0) When 0.0 Then 0.0
								Else Round((a.Amt - Isnull(CstAmt,0.0))/a.Amt,2*@AmtDec) End
	From @Tmp a Inner Join BDM_ItemInfo_V b On a.ItemID=b.ItemID
	--返回
	Return
End
go

