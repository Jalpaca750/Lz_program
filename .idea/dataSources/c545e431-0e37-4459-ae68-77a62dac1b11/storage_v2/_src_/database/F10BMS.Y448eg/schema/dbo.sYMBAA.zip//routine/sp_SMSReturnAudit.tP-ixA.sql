--增加退货时按照评论后积分方式的扣减
CREATE PROC [dbo].[sp_SMSReturnAudit]
(
	@ReturnNo VARCHAR(20),              --退货单号
	@Flag CHAR(2)                       --20-审核；10-弃审
)
AS
BEGIN
    DECLARE @ReturnID BIGINT,
            @WareHouse VARCHAR(20),
            @DeptNo VARCHAR(20),
            @ItemID BIGINT,
            @CustID BIGINT,
            @AuditDate CHAR(10),
            @CreateDate CHAR(10),
            @StockID BIGINT,
            @RQty DECIMAL(18,6),
            @SQty DECIMAL(18,6),
            @Amt DECIMAL(18,6),
            @Integral DECIMAL(18,6),
            @Location VARCHAR(20),
            @IsSYSIntegral AS BIT,
            @errors BIGINT;
	--2017-09-08 增加wms系统业务处理
    DECLARE @wmsStock VARCHAR(32),
            @remarks VARCHAR(2000),
            @jfItem BIGINT
	--2011.11.24增加积分模式和金额积分标准,会员自动升级积分和级别
    DECLARE @IntegralMode INT,
            @UnitIntegral DECIMAL(18,6),
            @MemberID VARCHAR(20),
            @TotalAmt DECIMAL(18,6),
            --积分抵扣商品退货
            @XFIntegral DECIMAL(18,6),
            --2012.05.09 钉子户退订单返回积分
            @OrderNo VARCHAR(20),
            @boneOrdNo VARCHAR(40),
            @ErrMsg nVARCHAR(4000),
            @ErrSeverity int;	
	--如果单据处于中间状态，则跳出(WMS过度状态)
	IF EXISTS(SELECT 1 FROM SMS_Return WHERE ReturnNo=@ReturnNo AND BillSts='15')
		RETURN;
	--清除同步错误
	DELETE FROM SAM_Error WHERE funCode='sp_SMSReturnAudit' AND billNo=@ReturnNo;
	SET @errors=0;
	BEGIN TRANSACTION;
    --排队等待
    WHILE EXISTS(SELECT * FROM dbo.SAM_Schedule WHERE jobCode='inv_posting_job' AND IsLocked=1)
    BEGIN
        SET @errors=0;
    END
    UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='sp_SMSReturnAudit' WHERE jobCode='inv_posting_job';
	--积分抵扣商品Id
	SELECT @jfItem=ItemID FROM BDM_ItemInfo WHERE ItemNo='JFDK';
	--订单编号
	SELECT TOP 1 @OrderNo = OrderNo
	FROM SMS_StockDtl 
	WHERE StockNo IN(SELECT StockNo FROM SMS_ReturnDtl WHERE ReturnNo=@ReturnNo);
	SET @errors=@errors+@@ERROR;
	--积分消费
	SELECT @XFIntegral=SUM(ISNULL(RQty,0.0)) FROM SMS_ReturnDtl WHERE ReturnNo=@ReturnNo AND ItemID=@jfItem;
	--系统积分启用标识
	SELECT @IsSYSIntegral=ISNULL(IsSYSIntegral,0),@IntegralMode=ISNULL(IntegralMode,1),@UnitIntegral=ISNULL(UnitIntegral,0.0) FROM Sys_Config;
	--获取退货单
	SELECT @WareHouse=WareHouse,@DeptNo=DeptNo,@AuditDate=CONVERT(VARCHAR(10),GETDATE(),23),@CustID=CustID,
	    @CreateDate=CreateDate,@boneOrdNo=boneOrdNo,@wmsStock=wmsOrder,@remarks=Remarks
	From SMS_Return 
	WHERE ReturnNo=@ReturnNo;
	SET @errors=@errors+@@ERROR;
	--退货金额
	SELECT @Amt=SUM(Amt) FROM SMS_ReturnDtl WHERE ReturnNo=@ReturnNo;	
	--创建临时表
	CREATE TABLE #Tmp(DeptNo VARCHAR(20),WareHouse VARCHAR(20),ItemID BIGINT,SQty DECIMAL(18,6));
	--获取退货数量(虚拟商品不算)
	INSERT INTO #Tmp(DeptNo,WareHouse,ItemID,SQty)
	SELECT @DeptNo,@WareHouse,a.ItemID,ISNULL(SUM(a.RQty),0.0)+ISNULL(SUM(a.ZQty),0.0)
	FROM SMS_ReturnDtl a   
	    INNER JOIN BDM_ItemInfo b ON a.ItemID=b.ItemID
	WHERE ReturnNo=@ReturnNo AND ISNULL(b.IsVirtual,0)=0
	GROUP BY a.ItemID;
	SET @errors=@errors+@@ERROR;
	--系统启用了积分功能,且客户参与积分功能	
	IF EXISTS(SELECT 1 FROM BDM_Customer WHERE CustID=@CustID AND ISNULL(IsIntegral,1)=1 AND ISNULL(@IsSYSIntegral,0)=1)
	BEGIN
		--按单位数量积分
		IF (ISNULL(@IntegralMode,1)=1)
			--wujinfeng-Add-客户积分处理			
			SELECT @Integral=SUM(ISNULL(b.RQty,0)*ISNULL(b.Integral,0.0)) 
			FROM SMS_Return a 
				INNER JOIN SMS_ReturnDtl b ON a.ReturnNo=b.ReturnNo
				INNER JOIN BDM_Customer c ON a.CustID=c.CustID
			WHERE (a.ReturnNo=@ReturnNo) AND CONVERT(VARCHAR(10),a.CreateDate,120)>CONVERT(VARCHAR(10),c.zj_ql_Date,120);
		--按金额积分
		ELSE IF (ISNULL(@IntegralMode,1)=2)
			SELECT @Integral=ISNULL(@Amt,0.0)/@UnitIntegral
			FROM SMS_Return a 
				INNER JOIN BDM_Customer c ON a.CustID=c.CustID
			WHERE (a.ReturnNo=@ReturnNo) AND CONVERT(VARCHAR(10),a.CreateDate,120)>CONVERT(VARCHAR(10),c.zj_ql_Date,120); 
		--评论后积分
		ELSE IF (ISNULL(@IntegralMode,1)=3)
			SELECT @Integral=SUM(CASE ISNULL(y.Qty,0.0) WHEN 0.0 Then 0.0 ELSE ISNULL(x.RQty,0.0) * ISNULL(y.Integral,0.0)/ISNULL(y.Qty,0.0) END)
			FROM (SELECT a.ReturnNo,a.ItemID,a.RQty,b.OrderNo 
				  FROM SMS_ReturnDtl a 
				      INNER JOIN SMS_StockDtl b ON a.StockID=b.StockID
				  WHERE a.ReturnNo=@ReturnNo) x 
				 INNER JOIN Web_IntegralLog y ON x.OrderNo=y.RelatingOrder AND x.ItemID=y.ItemID
			WHERE NOT EXISTS(SELECT 1 FROM BDM_ItemInfo g WHERE g.ItemID=x.ItemID AND g.ItemNo='JFDK')
	END
	ELSE
	BEGIN
		SET @Integral=0.0;
	END
	--审核
	IF (@Flag='20')
	BEGIN
		--更新客户欠款(客户积分增加抵扣商品）
		IF (ISNULL(@IntegralMode,1)=3)	
		BEGIN			
			UPDATE BDM_Customer SET ArgAmt=ISNULL(ArgAmt,0.0)-ISNULL(@Amt,0.0),
									Integral=ISNULL(Integral,0.0)-ISNULL(@Integral,0.0),
									Deduct=ISNULL(Deduct,0.0) + ISNULL(@XFIntegral,0.0),
									SJInteg=ISNULL(SJInteg,0.0) - ISNULL(@Integral,0.0)
			WHERE CustID=@CustID;
		END
		ELSE
		BEGIN
			UPDATE BDM_Customer Set ArgAmt=ISNULL(ArgAmt,0.0)-ISNULL(@Amt,0.0),
									Integral=ISNULL(Integral,0.0)-ISNULL(@Integral,0.0),
									Deduct=ISNULL(Deduct,0.0) + ISNULL(@XFIntegral,0.0)
			WHERE CustID=@CustID;			
		END
		SET @errors=@errors+@@ERROR;
		--积分消费扣减		
		INSERT INTO Web_IntegralLog(RelatingOrder,[Description],Integral,UpdateType,UpdateDate,UserID)
		SELECT @OrderNo,'积分抵扣返回',ABS(@XFIntegral),'+',GETDATE(),@CustID
		WHERE ISNULL(@XFIntegral,0.0)<>0.0;
		SET @errors=@errors+@@ERROR;
		--系统启用了积分功能,且客户参与积分功能	
		IF EXISTS(SELECT 1 FROM BDM_Customer WHERE CustID=@CustID AND ISNULL(IsIntegral,1)=1 AND ISNULL(@IsSYSIntegral,0)=1)
		BEGIN
			--评论后积分
			IF ISNULL(@IntegralMode,1)=3
			BEGIN
				--审核前的销售额
				SELECT @TotalAmt=SUM(b.Amt)
				FROM SMS_Stock a 
				    INNER JOIN SMS_StockDtl b On a.StockNo=b.StockNo
				WHERE a.CustID=@CustID AND (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30');
				SET @errors=@errors+@@ERROR;
				--获取当前金额下的最高级会员
				SELECT @MemberID=MemberID
				FROM (SELECT TOP 1 MemberID FROM SPM_Integral WHERE UpAmt<=ISNULL(@TotalAmt,0.0)-ISNULL(@Amt,0.0) ORDER BY UpAmt DESC) t;
				SET @errors=@errors+@@ERROR;					
				--更新会员级别
				UPDATE BDM_Customer SET MemberID=@MemberID WHERE CustID=@CustID AND ISNULL(@MemberID,'')<>'';
				SET @errors=@errors+@@ERROR;
				--返回积分		
				INSERT INTO Web_IntegralLog(RelatingOrder,[Description],Integral,UpdateType,UpdateDate,UserID)
				SELECT @OrderNo,'销售退货返回积分',@Integral,'-',GETDATE(),@CustID
				WHERE ISNULL(@Integral,0.0)<>0.0;
				SET @errors=@errors+@@ERROR;
			END	
		END
		--写入客户开票资料
        INSERT INTO SMS_StockEx(stockNo,invoiceFlag,invoiceCompany,invoiceAddress,invoiceTel,invoiceTax,invoiceAccount,invoiceBank)
        SELECT TOP 1 @ReturnNo,invoiceFlag,invoiceCompany,invoiceAddress,invoiceTel,invoiceTax,invoiceAccount,invoiceBank
        FROM BAS_CustomerInvoice
        WHERE CustomerId=CAST(@CustID AS VARCHAR(20))
            AND ISNULL(IsDefault,1)=1;
		--写入流水帐
		INSERT INTO IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,CreateDate,AuditDate,memo,wmsBillNo,remarks)
		SELECT a.ReturnNo,'销售退货单',@DeptNo,@WareHouse,a.ItemID,ISNULL(a.RQty,0.0)+ISNULL(a.ZQty,0.0),a.Price,a.Amt,@CreateDate,@AuditDate,a.Remarks,@ReturnNo,@remarks
		FROM SMS_ReturnDtl a 
		    INNER JOIN BDM_ItemInfo b ON a.ItemID=b.ItemID
		WHERE a.ReturnNo=@ReturnNo 
			AND ISNULL(b.IsVirtual,0)=0
			AND NOT EXISTS(SELECT 1 FROM IMS_Flow WHERE BillNo=@ReturnNo);	
	    SET @errors=@errors+@@ERROR;	
		--写入销售出库单
		INSERT INTO SMS_Stock(StockNo,CreateDate,DeptNo,WareHouse,CustID,BillType,BillSts,SendAddr,LinkMan,Phone,
			CreatorID,AuditDate,AuditID,Remarks,SalesID,HandlerID,CostsID,CarNumberSts,CarNumberDate,PoNo,ServicRate)
		SELECT ReturnNo,CreateDate,DeptNo,WareHouse,CustID,'20','20',SendAddr,linkMan,Phone,CreatorID,AuditDate,
			AuditID,Remarks,SalesID,HandlerID,CostsID,CarNumberSts,CarNumberDate,PoNo,ServicRate
		FROM SMS_Return
		WHERE ReturnNo=@ReturnNo 
			AND NOT EXISTS(SELECT 1 FROM SMS_Stock WHERE StockNo=@ReturnNo);
		SET @errors=@errors+@@ERROR;
		--写入销售出库单明细
		INSERT INTO SMS_StockDtl(StockNo,ItemID,WareHouse,SQty,Price,Amt,Location,ZQty,TaxFlag,boneOrdNo)
		SELECT a.ReturnNo,a.ItemID,a.WareHouse,-a.RQty,a.Price,-a.Amt,a.Location,-ISNULL(a.ZQty,0.0),ISNULL(a.TaxFlag,0.0),@boneOrdNo
		FROM SMS_ReturnDtl a 
		WHERE a.ReturnNo=@ReturnNo 
			AND NOT EXISTS(SELECT 1 FROM SMS_StockDtl WHERE StockNo=@ReturnNo);	
		SET @errors=@errors+@@ERROR;		
			
		--更新商品资料
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0) 
		FROM BDM_ItemInfo a 
		    INNER JOIN #Tmp b On a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;
		
		--更新分部商品总账
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0) 
		FROM IMS_Subdepot a 
		    INNER JOIN #Tmp b On a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID; 
		SET @errors=@errors+@@ERROR;
		INSERT INTO IMS_Subdepot(DeptNo,ItemID,OnHandQty)
		SELECT DeptNo,ItemID,SQty
		FROM #Tmp a
		WHERE NOT EXISTS(SELECT 1 FROM IMS_Subdepot b WHERE a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID);
		SET @errors=@errors+@@ERROR;
		
		--库房总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0),LastIDate=@CreateDate 
		FROM IMS_Ledger a 
		    INNER JOIN #Tmp b On a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;
		INSERT INTO IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastIDate)
		SELECT DeptNo,WareHouse,ItemID,SQty,@CreateDate
		FROM #Tmp a
		WHERE NOT EXISTS(SELECT 1 FROM IMS_Ledger b WHERE a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID);
		SET @errors=@errors+@@ERROR;
	END
	--取消审核
	IF (@Flag='10')
	BEGIN
		--更新客户欠款
		IF ISNULL(@IntegralMode,1)=3
			UPDATE BDM_Customer SET ArgAmt=ISNULL(ArgAmt,0.0)+ISNULL(@Amt,0.0),
									Integral=ISNULL(Integral,0.0)+ISNULL(@Integral,0.0),
									Deduct=ISNULL(Deduct,0.0) - ISNULL(@XFIntegral,0.0),
									SJInteg=ISNULL(SJInteg,0.0) + ISNULL(@Integral,0.0)
			WHERE CustID=@CustID;
		ELSE
			UPDATE BDM_Customer SET ArgAmt=ISNULL(ArgAmt,0.0)+ISNULL(@Amt,0.0),
									Integral=ISNULL(Integral,0.0)+ISNULL(@Integral,0.0),
									Deduct=ISNULL(Deduct,0.0) - ISNULL(@XFIntegral,0.0)
			WHERE CustID=@CustID;
		SET @errors=@errors+@@ERROR;
		--积分消费扣减		
		INSERT INTO Web_IntegralLog(RelatingOrder,[Description],Integral,UpdateType,UpdateDate,UserID)
		SELECT @OrderNo,'冲积分抵扣返回',ABS(@XFIntegral),'-',GETDATE(),@CustID
		WHERE ISNULL(@XFIntegral,0.0)<>0.0;
		SET @errors=@errors+@@ERROR;
		--如果设置了会员自动升级，则升级会员级别
		IF ISNULL(@IntegralMode,1)=3
		BEGIN
			--审核前的销售额
			SELECT @TotalAmt=SUM(b.Amt)
			FROM SMS_Stock a 
			    INNER JOIN SMS_StockDtl b On a.StockNo=b.StockNo
			WHERE a.CustID=@CustID AND (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30');
			
			--获取当前金额下的最高级会员
			SELECT @MemberID=MemberID
			FROM (SELECT TOP 1 MemberID FROM SPM_Integral WHERE UpAmt<=ISNULL(@TotalAmt,0.0)+ISNULL(@Amt,0.0) ORDER BY UpAmt DESC) t;
			SET @errors=@errors+@@ERROR;					
			--更新会员级别
			UPDATE BDM_Customer SET MemberID=@MemberID WHERE CustID=@CustID AND ISNULL(@MemberID,'')<>'';
			SET @errors=@errors+@@ERROR;
			--返回积分		
			INSERT INTO Web_IntegralLog(RelatingOrder,[Description],Integral,UpdateType,UpdateDate,UserID)
			SELECT @OrderNo,'冲退货返回积分',@Integral,'+',GETDATE(),@CustID
			WHERE ISNULL(@Integral,0.0)<>0.0;
			SET @errors=@errors+@@ERROR;
		END
        --删除开票资料
        DELETE FROM SMS_StockEx WHERE StockNo=@ReturnNo;
		--写删除流水帐
		DELETE FROM IMS_Flow WHERE BillNo=@ReturnNo;
		SET @errors=@errors+@@ERROR;
		--删除销售出库单
		DELETE FROM SMS_StockDtl WHERE StockNo=@ReturnNo;
		SET @errors=@errors+@@ERROR;
		DELETE FROM SMS_Stock WHERE StockNo=@ReturnNo;	
		SET @errors=@errors+@@ERROR;		
		--更新商品资料
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0) FROM BDM_ItemInfo a INNER JOIN #Tmp b On a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;
		--更新分部商品总账
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0) FROM IMS_Subdepot a INNER JOIN #Tmp b On a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID; 
		SET @errors=@errors+@@ERROR;
		--更新库房总账
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0) FROM IMS_Ledger a INNER JOIN #Tmp b On a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID;
	    SET @errors=@errors+@@ERROR;
	END
	--作废
	IF (@Flag='00')
	BEGIN
		--更新可退货数量
		UPDATE a SET a.RQty=ISNULL(a.RQty,0.0)-ISNULL(b.RQty,0.0),a.RZQty=ISNULL(RZQty,0.0)-ISNULL(b.ZQty,0.0)
		FROM SMS_StockDtl a INNER JOIN SMS_ReturnDtl b On a.StockID=b.StockID
		WHERE b.ReturnNo=@ReturnNo;
		SET @errors=@errors+@@ERROR;
    END
    UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='inv_posting_job';
    SET @errors=@errors+@@ERROR;
	IF (@errors=0)
	BEGIN		
		COMMIT;
    END
    ELSE
	BEGIN
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;	
        UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='inv_posting_job';
		--写入同步错误日志	
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),'01',GETDATE(),'99','sp_SMSReturnAudit','SMS_RETURN_AUIDT_ERROR',LEFT(@ErrMsg,2000),@ReturnNo,@ReturnNo);
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END
END

go

