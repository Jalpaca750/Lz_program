CREATE VIEW dbo.SMS_RetailDtl_V
AS
SELECT a.RetailID, a.RetailNo, b.CreateDate, b.CreateTime, b.CashFlag, b.PCNo, b.CustID, 
      a.DeptNo, a.WareHouse, b.BillType, a.Location, a.ItemID, c.ItemNo, c.ItemName, 
      c.ItemAlias, c.NameSpell, c.ItemSpec, c.BarCode, c.ClassID, c.ClassName, c.LabelID, 
      c.LabelName, c.ColorName, c.UnitName, a.Price, a.SPrice, a.ZQty, a.DiscRate, 
      a.SafeSPrice, c.PPrice, c.SPrice1, c.SPrice2, c.SPrice3, d.OnHandQty, c.Integral, 
      c.NotDisc, CASE b.BillType WHEN '40' THEN SQty ELSE - SQty END AS SQty, 
      CASE b.BillType WHEN '40' THEN Amt ELSE - Amt END AS Amt, c.Package, 
      c.MPackage, c.BPackage, '' AS IndexXH, a.DiscAmt, a.Integral AS DtlIntegral, 
      b.ShiftNo, a.Remarks, a.CheckBox
FROM dbo.SMS_RetailDtl a LEFT OUTER JOIN
      dbo.IMS_Subdepot d ON a.DeptNo = d.DeptNo AND 
      a.ItemID = d.ItemID LEFT OUTER JOIN
      dbo.BAS_Goods_V c ON a.ItemID = c.ItemID LEFT OUTER JOIN
      dbo.SMS_Retail b ON a.RetailNo = b.RetailNo
go

