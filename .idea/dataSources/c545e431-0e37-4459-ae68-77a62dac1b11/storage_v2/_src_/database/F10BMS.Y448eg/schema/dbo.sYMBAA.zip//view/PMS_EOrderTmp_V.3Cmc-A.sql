CREATE VIEW dbo.PMS_EOrderTmp_V
AS
SELECT b.OrderNo, b.ItemID, a.ItemNo, a.ItemName, a.ItemSpec, a.ClassName, 
	a.LabelName, a.UnitName, '' As Location, b.OQty, b.PPrice As Price, 
	b.Amt, a.OnHandQty, a.AvailQty,a.PPrice,a.SafePPrice,a.PkgSpec,a.PkgRatio,
	a.Bpackage,a.Mpackage,a.Package,a.ColorName
FROM dbo.PMS_EOrderTmp b INNER JOIN
      dbo.BDM_ItemInfo_V a ON b.ItemID = a.ItemID
go

