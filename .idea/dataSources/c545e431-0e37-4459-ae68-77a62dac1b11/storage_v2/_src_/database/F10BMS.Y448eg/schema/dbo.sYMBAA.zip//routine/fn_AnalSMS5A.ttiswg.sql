

--说明：商品销售月报
--作者：Devil.H
--创建：2007.11.11
--参数：
--	@Year:年度
--	@Month:月份
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag：标志
CREATE Function dbo.fn_AnalSMS5A
(
	@Year int=0,
	@Month int=0,
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemAlias varchar(200),
	NameSpell varchar(200),
	ItemSpec varchar(100),
	BarCode varchar(100),
	ClassID varchar(20),
	ClassName varchar(100),
	LabelID varchar(20),
	LabelName varchar(100),
	ColorName varchar(40),
	UnitName varchar(40),
	Day01 decimal(18,6),
	Day02 decimal(18,6),
	Day03 decimal(18,6),
	Day04 decimal(18,6),
	Day05 decimal(18,6),
	Day06 decimal(18,6),
	Day07 decimal(18,6),
	Day08 decimal(18,6),
	Day09 decimal(18,6),
	Day10 decimal(18,6),
	Day11 decimal(18,6),
	Day12 decimal(18,6),
	Day13 decimal(18,6),
	Day14 decimal(18,6),
	Day15 decimal(18,6),
	Day16 decimal(18,6),
	Day17 decimal(18,6),
	Day18 decimal(18,6),
	Day19 decimal(18,6),
	Day20 decimal(18,6),
	Day21 decimal(18,6),
	Day22 decimal(18,6),
	Day23 decimal(18,6),
	Day24 decimal(18,6),
	Day25 decimal(18,6),
	Day26 decimal(18,6),
	Day27 decimal(18,6),
	Day28 decimal(18,6),
	Day29 decimal(18,6),
	Day30 decimal(18,6),
	Day31 decimal(18,6),
	Total decimal(18,6),
	DepartId varchar(20),
	DepartName varchar(100)
)
As
Begin	
	if @Flag=0 
		return
	--********增加会计月份时间处理***********************
	declare @CW_Month_BDate char(10)
	declare @CW_Month_EDate char(10)
	Set @CW_Month_BDate=(select CW_Month from dbo.uf_Get_CW_Month(1,@Year,@Month))
	Set @CW_Month_EDate=(select CW_Month from dbo.uf_Get_CW_Month(2,@Year,@Month))
	--**********************************************
	--不设过滤条件
	Insert Into @uTable(DepartId,ItemID,Day01,Day02,Day03,Day04,Day05,Day06,Day07,
		Day08,Day09,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,
		Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,
		Day28,Day29,Day30,Day31,Total)
	Select a.DepartId,b.ItemID,
		Day01=Sum(Case Day(a.CreateDate) When 1 then b.Amt else 0.0 end),
		Day02=Sum(Case Day(a.CreateDate) When 2 then b.Amt else 0.0 end),
		Day03=Sum(Case Day(a.CreateDate) When 3 then b.Amt else 0.0 end),
		Day04=Sum(Case Day(a.CreateDate) When 4 then b.Amt else 0.0 end),
		Day05=Sum(Case Day(a.CreateDate) When 5 then b.Amt else 0.0 end),
		Day06=Sum(Case Day(a.CreateDate) When 6 then b.Amt else 0.0 end),
		Day07=Sum(Case Day(a.CreateDate) When 7 then b.Amt else 0.0 end),
		Day08=Sum(Case Day(a.CreateDate) When 8 then b.Amt else 0.0 end),
		Day09=Sum(Case Day(a.CreateDate) When 9 then b.Amt else 0.0 end),
		Day10=Sum(Case Day(a.CreateDate) When 10 then b.Amt else 0.0 end),
		Day11=Sum(Case Day(a.CreateDate) When 11 then b.Amt else 0.0 end),
		Day12=Sum(Case Day(a.CreateDate) When 12 then b.Amt else 0.0 end),
		Day13=Sum(Case Day(a.CreateDate) When 13 then b.Amt else 0.0 end),
		Day14=Sum(Case Day(a.CreateDate) When 14 then b.Amt else 0.0 end),
		Day15=Sum(Case Day(a.CreateDate) When 15 then b.Amt else 0.0 end),
		Day16=Sum(Case Day(a.CreateDate) When 16 then b.Amt else 0.0 end),
		Day17=Sum(Case Day(a.CreateDate) When 17 then b.Amt else 0.0 end),
		Day18=Sum(Case Day(a.CreateDate) When 18 then b.Amt else 0.0 end),
		Day19=Sum(Case Day(a.CreateDate) When 19 then b.Amt else 0.0 end),
		Day20=Sum(Case Day(a.CreateDate) When 20 then b.Amt else 0.0 end),
		Day21=Sum(Case Day(a.CreateDate) When 21 then b.Amt else 0.0 end),
		Day22=Sum(Case Day(a.CreateDate) When 22 then b.Amt else 0.0 end),
		Day23=Sum(Case Day(a.CreateDate) When 23 then b.Amt else 0.0 end),
		Day24=Sum(Case Day(a.CreateDate) When 24 then b.Amt else 0.0 end),
		Day25=Sum(Case Day(a.CreateDate) When 25 then b.Amt else 0.0 end),
		Day26=Sum(Case Day(a.CreateDate) When 26 then b.Amt else 0.0 end),
		Day27=Sum(Case Day(a.CreateDate) When 27 then b.Amt else 0.0 end),
		Day28=Sum(Case Day(a.CreateDate) When 28 then b.Amt else 0.0 end),
		Day29=Sum(Case Day(a.CreateDate) When 29 then b.Amt else 0.0 end),
		Day30=Sum(Case Day(a.CreateDate) When 30 then b.Amt else 0.0 end),
		Day31=Sum(Case Day(a.CreateDate) When 31 then b.Amt else 0.0 end),
		Total=Sum(b.Amt)
	From SMS_Stock a inner join SMS_StockDtl b On a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.CreateDate Between @CW_Month_BDate And @CW_Month_EDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By a.DepartId,b.ItemID
	--更新商品资料
	Update a Set a.ItemNo=b.ItemNo,a.ItemName=b.ItemName,a.ItemSpec=b.ItemSpec,a.NameSpell=b.NameSpell,
		a.ItemAlias=b.ItemAlias,a.BarCode=b.BarCode,a.ClassID=b.ClassID,a.LabelID=b.LabelID,
		a.ClassName=b.ClassName,a.LabelName=b.LabelName,a.ColorName=b.ColorName,a.UnitName=b.UnitName
	From @uTable a inner join BAS_Goods_V b on a.ItemID=b.ItemID
	
	update a set a.DepartName=d.CHName FROM @uTable a Inner Join BDM_DeptCode_V d On a.DepartId=d.CodeID
	--返回
 	return
End
go

