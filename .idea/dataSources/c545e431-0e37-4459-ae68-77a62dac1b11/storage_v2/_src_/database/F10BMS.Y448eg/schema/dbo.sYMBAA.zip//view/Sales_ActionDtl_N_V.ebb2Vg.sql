--上一工作计划
CREATE VIEW dbo.Sales_ActionDtl_N_V
AS
SELECT a.BillID, a.BillID As BillID_N, a.BillNo,a.PlanXZ, C.CHName As PlanType, a.PlanType As PlanTypeID
,a.Object,a.Content,a.RQ
,a.ExecuteSts
,a.CustID
FROM dbo.Sales_ActionDtl_N a 
--LEFT OUTER JOIN      dbo.Sales_Action b ON a.BillNo = b.BillNo
LEFT OUTER JOIN      dbo.BDM_PlanType_V c ON a.PlanType = c.CodeID













go

