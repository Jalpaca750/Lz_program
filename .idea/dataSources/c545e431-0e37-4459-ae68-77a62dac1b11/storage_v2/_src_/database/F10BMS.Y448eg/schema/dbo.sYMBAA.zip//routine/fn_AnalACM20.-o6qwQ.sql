--说明：客户回款分析
--作者：Devil.H
--创建：2007.11.14
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag：标志
CREATE Function [dbo].[fn_AnalACM20]
(
	@StartDate char(10)='2000-01-01',
	@EndDate char(10)='2000-01-01',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	CustID bigint,
	CustNo varchar(20),
	CustName varchar(100),
	NameSpell varchar(100),
	AreaCode varchar(20),
	AreaName varchar(100),
	MemberID varchar(20),
	Member varchar(100),
	PopedomID varchar(20),
	PopedomName varchar(100),
	CustType varchar(20),
	TypeName varchar(100),
	SalesID bigint,
	Sales varchar(100),
	KindName varchar(100),
	TradeName varchar(100),
	PayAmt decimal(18,6),
    unPaidAmt decimal(18,6),
	LSAmt decimal(18,6),
	XSAmt decimal(18,6),
	YEAmt decimal(18,6),
	TotalAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40),
	DepartId varchar(20),
	DepartName varchar(100)
	
)
As
Begin	
	if @Flag=0
		Return
	--初始化变量
	Set @StartDate=Convert(Char(10),Cast(@StartDate as datetime),120)
	Set @EndDate=Convert(Char(10),Cast(@EndDate as datetime),120)
	--临时表
	declare @Tmp Table(CustID bigint,SalesID bigint,DepartId varchar(20),PayAmt decimal(18,6),unPaidAmt decimal(18,6),LSAmt decimal(18,6),XSAmt decimal(18,6),YFAmt decimal(18,6),CXAmt decimal(18,6))
    --写入临时表
	Insert Into @Tmp(CustID,SalesID,DepartId,PayAmt,unPaidAmt,LSAmt,XSAmt,YFAmt,CXAmt)
	--预付款
	Select b.CustID,a.SalesId, a.DepartId,0.0 as PayAmt,0.0 AS unPaidAmt,0.0 as LSAmt,0.0 as XSAmt,Sum(AdvAmt),0.0 as CXAmt
	From SMS_Advances a inner join SMS_AdvancesDtl b On a.AdvancesNo=b.AdvancesNo
	Where (a.BillSts='20') 
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By b.CustID,a.SalesID,a.DepartId
	Union All
	--收款与冲销
	Select CustID,SalesID,DepartId,Sum(Amt),0.0 AS unPaidAmt,0.0 as LSAmt,0.0 as XSAmt,0.0 as YFAmt,Sum(AdvAmt)
	From SMS_Payment a
	Where (BillSts Not In('00','10')) 
		And (Convert(char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By CustID,SalesID,DepartId
	Union All
	--免收款
	Select a.CustID,a.SalesID, a.DepartId,0.0 AS payAmt,SUM(b.FAmt) AS unPaidAmt,0.0 as LSAmt,0.0 as XSAmt,0.0 as YFAmt,0.0 AS AdvAmt
	From SMS_Payment a INNER JOIN SMS_PaymentDtl b ON a.paymentNo=b.paymentNo
	Where (a.BillSts Not In('00','10'))   
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By a.CustID,a.SalesID,a.DepartId
	Union All
	--零售
	Select a.CustID,a.SalesID, a.DeptNo,0.0 as PayAmt,0.0 AS unPaidAmt, Sum(Case a.BillType When '40' Then Isnull(b.Amt,0.0)-Isnull(a.DiscAmt,0.0)
						          When '50' Then Isnull(a.DiscAmt,0.0)-Isnull(b.Amt,0.0) End) as LSAmt,
		0.0 as XSAmt,0.0 as YFAmt,0.0 as CXAmt
	From SMS_Retail a Inner Join (Select RetailNo,Sum(Amt) As Amt
				      From SMS_RetailDtl
				      Group By RetailNo) b On a.RetailNo=b.RetailNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By a.CustID,a.SalesID,a.DeptNo
	Union All
	--现金销售
	Select CustID,a.SalesID,a.DepartId,0.0 as PayAmt,0.0 AS unPaidAmt,0.0 as LSAmt,Sum(PaidAmt) as XSAmt,0.0 as YFAmt,0.0 as CXAmt
	From SMS_Stock a
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (Convert(char(10),Cast(a.PaidDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	Group By CustID,SalesID,DepartId
	--写入表值函数	
	Insert Into @uTable(CustID,SalesID,DepartId,PayAmt,unPaidAmt,LSAmt,XSAmt,YEAmt,TotalAmt)
	Select CustID,SalesID,DepartId,Sum(PayAmt),SUM(unpaidAmt),Sum(LSAmt),Sum(XSAmt),Isnull(Sum(YFAmt),0)-Isnull(Sum(CXAmt),0),
		Isnull(Sum(PayAmt),0)+Isnull(Sum(LSAmt),0)+Isnull(Sum(XSAmt),0)+Isnull(Sum(YFAmt),0)-Isnull(Sum(CXAmt),0)
	From @Tmp
	Group By CustID,SalesID,DepartId
	--更新客户资料
	Update a Set a.CustNo=b.CustNo,a.CustName=b.CustName,a.NameSpell=b.NameSpell,a.AreaCode=b.AreaCode,
		a.AreaName=b.AreaName,a.MemberID=b.MemberID,a.Member=b.Member,a.PopedomID=b.PopedomID,
		a.PopedomName=b.PopedomName,a.CustType=b.CustType,a.TypeName=b.TypeName,a.KindName=b.KindName,
		a.TradeName=b.TradeName,a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes,a.Sales=c.EmployeeName
	From @uTable a 
	    INNER JOIN BAS_Customer_V b ON a.CustID=b.CustID
	    LEFT JOIN BDM_Employee c ON a.SalesID=c.EmployeeID

	Update a Set a.DepartName=d.CHName From @uTable a Inner Join BDM_DeptCode_V d ON a.DepartId=d.CodeId
	Return
End
go

