CREATE VIEW dbo.SMS_StockCheck_V
AS
SELECT a.CheckBox,a.StockID, a.StockNo, a.OrderNo, a.ItemID, g.ItemNo, g.ItemName, g.ItemAlias, 
      g.NameSpell, g.ItemSpec, g.BarCode, g.ClassID, g.ClassName, g.LabelID, g.LabelName,
      g.ColorName, g.UnitName, a.SQty, a.Price, a.Amt, a.ZQty, NULL AS CheckQty,
      ISNULL(a.SQty,0.0)+ISNULL(a.ZQty,0.0)-ISNULL(t.CheckQty,0.0) AS RemDQty,
      a.IsSpecial, a.IsEffect, a.TaxFlag, a.Remarks,b.CheckerId
FROM dbo.SMS_StockDtl a 
    INNER JOIN dbo.BAS_Goods_V g ON a.ItemID = g.ItemID 
    INNER JOIN dbo.SMS_Stock b ON a.stockNo=b.StockNo
    LEFT JOIN (SELECT StockID,Sum(CheckQty) As CheckQty 
               FROM CE_CheckDelivery 
               GROUP BY StockID) t On a.StockID=t.StockID
go

