
create view TCS_OrderInvoiceDetail_V as
/*
SELECT a.orderNo,a.orderId,ex.billNo AS orderBillNo,a.companyId AS corpId,a.viewOrder,
    CAST(g.itemId AS VARCHAR(32)) AS itemId,b.itemNo,b.itemName,g.zpCode AS goodsCode,
    g.ZPName AS goodsName,g.itemSpec,b.brandCName,b.categoryCName,g.unitName,
    g.colorName,'1' AS withTaxFlag,ISNULL(a.orderQty,0.0)-ISNULL(t.invQty,0.0) AS orderQty,
    a.befPrice,a.discount,a.price AS vatPrice,
    g.taxrate,CAST(a.price/(1.0+ISNULL(g.taxrate,13)/100.0) AS DECIMAL(20,10)) AS price,
    CAST(CAST(a.price/(1.0+ISNULL(g.taxrate,13)/100.0) AS DECIMAL(20,10))*(ISNULL(a.orderQty,0.0)-ISNULL(t.invQty,0.0)) AS DECIMAL(20,2)) AS fee,
    CAST(a.price*(ISNULL(a.orderQty,0.0)-ISNULL(t.invQty,0.0)) AS DECIMAL(20,2)) AS totalFee
FROM Bone.dbo.ECM_OrderDetail a
    INNER JOIN Bone.dbo.ECM_OrderEx ex ON a.packageId=ex.packageId
    INNER JOIN Bone.dbo.BAS_ItemSku_V b ON a.itemId=b.itemId
    LEFT JOIN dbo.BDM_ItemInfo g ON b.itemNo=g.ItemNo
    LEFT JOIN (SELECT orderId,SUM(CAST(Num AS DECIMAL(20,2))) AS invQty 
               FROM TCS_Order x
                   INNER JOIN TCS_InvoiceDetail y ON x.invoiceNo=y.invoiceNo
               WHERE x.invoiceState IN('10','20','30') 
               GROUP BY orderId) t ON a.orderId=t.orderId
WHERE ISNULL(a.orderQty,0.0)-ISNULL(t.invQty,0.0)>0.0
UNION ALL
*/
SELECT a.StockNo AS orderNo,CAST(b.StockID AS VARCHAR(20)) AS orderId,a.StockNo AS orderBillNo,
    d.corpId,1 AS viewOrder,
    --释放注释
    --ROW_NUMBER() OVER(PARTITION BY a.StockNo ORDER BY b.StockID) AS viewOrder,
    CAST(b.itemID AS VARCHAR(20)) AS itemId,bi.ItemNo,bi.ItemName,
    bi.zpCode AS goodsCode,bi.ZPName AS goodsName,bi.itemSpec,bi.LabelName AS brandCName,
    bi.ClassName AS categoryCName,bi.unitName,bi.colorName,'1' AS withTaxFlag,
    ISNULL(b.SQty,0.0)-ISNULL(t.invQty,0.0) AS orderQty,b.DiscountTemp AS befPrice,b.DiscRate AS discount,
    b.price AS vatPrice,bi.taxrate,CAST(b.price/(1.0+ISNULL(bi.taxrate,13)/100.0) AS DECIMAL(20,4)) AS price,
    CAST(CAST(b.price/(1.0+ISNULL(bi.taxrate,13)/100.0) AS DECIMAL(20,4))*(ISNULL(b.SQty,0.0)-ISNULL(t.invQty,0.0)) AS DECIMAL(20,2)) AS fee,
    CAST(b.price*(ISNULL(b.SQty,0.0)-ISNULL(t.invQty,0.0)) AS DECIMAL(20,2)) AS totalFee
FROM SMS_Stock a
    INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
    INNER JOIN BDM_DeptCode_V d ON a.DeptNo=d.CodeID
    INNER JOIN BAS_Goods_V bi ON b.ItemID=bi.ItemID
    LEFT JOIN (SELECT orderId,SUM(CAST(Num AS DECIMAL(20,2))) AS invQty 
               FROM TCS_Order x
                   INNER JOIN TCS_InvoiceDetail y ON x.invoiceNo=y.invoiceNo
               WHERE x.invoiceState IN('10','20','30') 
               GROUP BY orderId) t ON t.orderId=CAST(b.StockID AS VARCHAR(20))
WHERE ISNULL(b.SQty,0.0)-ISNULL(t.invQty,0.0)>0.0
go

