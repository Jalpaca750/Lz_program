--说明：客户年度销售毛利统计
--作者：Devil.H
--创建：2007.11.16
--参数：
--	@Year:年度
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:标识
CREATE FUNCTION [dbo].[fn_AnalSMS8A]
(
	@Year INT=0,
	@CorpNo VARCHAR(2)='',
	@DeptNo VARCHAR(20)='',
	@isGift BIT=0,
	@Flag BIT
)
RETURNS @uTable TABLE(
	CustID BIGINT,
	CustNo VARCHAR(20),
	CustName VARCHAR(200),
	CustSpell VARCHAR(200),
	CustType VARCHAR(20),
	TypeName VARCHAR(100),
	MemberID VARCHAR(20),
	Member VARCHAR(100),
	AreaCode VARCHAR(20),
	AreaName VARCHAR(100),
	PopedomID VARCHAR(20),
	PopedomName VARCHAR(100),
	TradeName VARCHAR(100),
	KindName VARCHAR(100),
	SalesID BIGINT,
	Sales VARCHAR(100),
	MONTH01Amt DECIMAL(18,6),
	MONTH02Amt DECIMAL(18,6),
	MONTH03Amt DECIMAL(18,6),
	MONTH04Amt DECIMAL(18,6),
	MONTH05Amt DECIMAL(18,6),
	MONTH06Amt DECIMAL(18,6),
	MONTH07Amt DECIMAL(18,6),
	MONTH08Amt DECIMAL(18,6),
	MONTH09Amt DECIMAL(18,6),
	MONTH10Amt DECIMAL(18,6),
	MONTH11Amt DECIMAL(18,6),
	MONTH12Amt DECIMAL(18,6),
	TotalAmt DECIMAL(18,6),
	LinkMan VARCHAR(40),
	Phone VARCHAR(80),
	Faxes VARCHAR(40)
)
AS
BEGIN
	IF (@Flag=0)
		RETURN;
	DECLARE @AmtDec INT
	SELECT @AmtDec=ISNULL(AmtDec,2) FROM Sys_Config
	Set @AmtDec=ISNULL(@AmtDec,2)
    if (ISNULL(@isGift,0)=0)
	    INSERT INTO @uTable(CustID,SalesID,MONTH01Amt,MONTH02Amt,MONTH03Amt,MONTH04Amt,MONTH05Amt,MONTH06Amt,
		                       MONTH07Amt,MONTH08Amt,MONTH09Amt,MONTH10Amt,MONTH11Amt,MONTH12Amt,TotalAmt)
	    SELECT a.CustID,a.SalesID,
		    MONTH01Amt=SUM(CASE MONTH(a.CreateDate) WHEN 1 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH02Amt=SUM(CASE MONTH(a.CreateDate) WHEN 2 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH03Amt=SUM(CASE MONTH(a.CreateDate) WHEN 3 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH04Amt=SUM(CASE MONTH(a.CreateDate) WHEN 4 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH05Amt=SUM(CASE MONTH(a.CreateDate) WHEN 5 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH06Amt=SUM(CASE MONTH(a.CreateDate) WHEN 6 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH07Amt=SUM(CASE MONTH(a.CreateDate) WHEN 7 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH08Amt=SUM(CASE MONTH(a.CreateDate) WHEN 8 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH09Amt=SUM(CASE MONTH(a.CreateDate) WHEN 9 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH10Amt=SUM(CASE MONTH(a.CreateDate) WHEN 10 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH11Amt=SUM(CASE MONTH(a.CreateDate) WHEN 11 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH12Amt=SUM(CASE MONTH(a.CreateDate) WHEN 12 THEN ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    TotalAmt=SUM(ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0.0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec))
	    FROM SMS_Stock a 
            INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
            INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	    WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30') 
	        AND YEAR(a.CreateDate)=@Year
	        AND (a.DeptNo Like @DeptNo + '%')
	        AND (a.DeptNo IN(SELECT CodeID FROM BDM_DeptCode_V WHERE DeptNo LIKE @CorpNo + '%'))
	    Group By a.CustID,a.SalesID
	ELSE
	    INSERT INTO @uTable(CustID,SalesID,MONTH01Amt,MONTH02Amt,MONTH03Amt,MONTH04Amt,MONTH05Amt,MONTH06Amt,
		                       MONTH07Amt,MONTH08Amt,MONTH09Amt,MONTH10Amt,MONTH11Amt,MONTH12Amt,TotalAmt)
	    SELECT a.CustID,a.SalesID,
		    MONTH01Amt=SUM(CASE MONTH(a.CreateDate) WHEN 1 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH02Amt=SUM(CASE MONTH(a.CreateDate) WHEN 2 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH03Amt=SUM(CASE MONTH(a.CreateDate) WHEN 3 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH04Amt=SUM(CASE MONTH(a.CreateDate) WHEN 4 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH05Amt=SUM(CASE MONTH(a.CreateDate) WHEN 5 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH06Amt=SUM(CASE MONTH(a.CreateDate) WHEN 6 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH07Amt=SUM(CASE MONTH(a.CreateDate) WHEN 7 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH08Amt=SUM(CASE MONTH(a.CreateDate) WHEN 8 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH09Amt=SUM(CASE MONTH(a.CreateDate) WHEN 9 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH10Amt=SUM(CASE MONTH(a.CreateDate) WHEN 10 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH11Amt=SUM(CASE MONTH(a.CreateDate) WHEN 11 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    MONTH12Amt=SUM(CASE MONTH(a.CreateDate) WHEN 12 THEN ISNULL(b.Amt,0.0)-ROUND((ISNULL(b.SQty,0.0)+ISNULL(b.ZQty,0.0))*ISNULL(b.CPrice,0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec) ELSE 0.0 END),
		    TotalAmt=SUM(ISNULL(b.Amt,0.0)-ROUND(ISNULL(b.SQty,0.0)*ISNULL(b.CPrice,0.0),@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0,@AmtDec)-ROUND(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0,@AmtDec))
	    FROM SMS_Stock a 
            INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
            INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	    WHERE (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30') 
	        AND YEAR(a.CreateDate)=@Year
	        AND (a.DeptNo Like @DeptNo + '%')
	        AND (a.DeptNo IN(SELECT CodeID FROM BDM_DeptCode_V WHERE DeptNo LIKE @CorpNo + '%'))
	    Group By a.CustID,a.SalesID;
	--更新客户资料
	UPDATE a SET a.CustNo=b.CustNo,a.CustName=b.CustName,a.CustSpell=b.NameSpell,a.AreaCode=b.AreaCode,
		a.AreaName=b.AreaName,a.MemberID=b.MemberID,a.PopedomID=b.PopedomID,a.CustType=b.CustType,
		a.Member=b.Member,a.PopedomName=b.PopedomName,a.TypeName=b.TypeName,a.KindName=b.KindName,
		a.TradeName=b.TradeName,a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes,a.Sales=c.EmployeeName
	FROM @uTable a 
        INNER JOIN BAS_Customer_V b ON a.CustID=b.CustID
        LEFT JOIN BDM_Employee c ON a.SalesID=c.EmployeeID;
	--返回
	RETURN;
END
go

