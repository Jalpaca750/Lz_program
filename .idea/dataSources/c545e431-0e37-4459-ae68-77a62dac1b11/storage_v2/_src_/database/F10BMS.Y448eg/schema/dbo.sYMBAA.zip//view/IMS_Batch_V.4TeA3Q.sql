CREATE view IMS_Batch_V as
SELECT a.SID,a.ItemID,a.WareHouseID,b.CHName  As WareHouseName,c.ItemNo,c.ItemName,c.ItemSpec,c.ItemPHFlag,
    c.ItemPHName,c.BarCode,c.NameSpell,c.ItemAlias,c.UnitName,c.ColorName,c.PkgSpec,c.PkgRatio,
    a.PHNo,a.SNNo,ISNULL(a.Qty,0.0)+ISNULL(a.TQty,0.0)-ISNULL(a.OQty,0.0) AS onhandQty,d.Price,
    ROUND((ISNULL(a.Qty,0.0)+ISNULL(a.TQty,0.0)-ISNULL(a.OQty,0.0))*ISNULL(d.Price,0.0),2) AS Amt,
    a.BeginDate,a.EndDate,a.YXQ,a.BillType,a.BillNo,a.CreatorID,a.JobFlag,c.LabelId,c.LabelName,
    c.ClassID,c.ClassName,
    CASE ISNULL(c.PkgRatio,0) WHEN 0 THEN ISNULL(a.Qty,0.0)+ISNULL(a.TQty,0.0)-ISNULL(a.OQty,0.0) 
                              ELSE (ISNULL(a.Qty,0.0)+ISNULL(a.TQty,0.0)-ISNULL(a.OQty,0.0))/c.PkgRatio END AS PkgQty
FROM JobNumberNo_In a 
    INNER JOIN BDM_WareHouse_V b ON a.WareHouseID = b.CodeID 
    INNER JOIN BDM_ItemInfo_V c ON a.ItemID = c.ItemID 
    LEFT JOIN PMS_StockDtl d ON a.billNo=d.StockNo AND a.ItemID=d.ItemID
go

