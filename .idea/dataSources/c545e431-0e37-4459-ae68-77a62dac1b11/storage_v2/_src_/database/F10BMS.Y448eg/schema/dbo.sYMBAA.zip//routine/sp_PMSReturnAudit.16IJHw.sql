CREATE Proc sp_PMSReturnAudit
(
	@ReturnNo varchar(20),
	@Flag char(2)
)
As
Begin
	declare @ItemID  bigint
	declare @DeptNo	varchar(20)
	declare @WareHouse varchar(20)
	declare @ReturnID bigint
	declare @CreateDate char(10)
	declare @AuditDate char(10)
	declare @Amt decimal(18,6)
	declare @VendorID bigint
    declare @errors bigint
    --排队等待
    WHILE EXISTS(SELECT * FROM dbo.SAM_Schedule WHERE jobCode='inv_posting_job' AND IsLocked=1)
    BEGIN
        SET @errors=0;
    END
    UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='sp_PMSReturnAudit' WHERE jobCode='inv_posting_job';
	--当前盘存清单编号
	select @CreateDate=CreateDate,@AuditDate=CONVERT(VARCHAR(10),GETDATE(),23),@VendorID=VendorID,
		@WareHouse=WareHouse,@DeptNo=DeptNo
	From PMS_Return
	Where ReturnNo=@ReturnNo
	--退货款
	Select @Amt=Sum(Amt) from PMS_ReturnDtl Where ReturnNo=@ReturnNo
	--创建临时表
	Create Table #Tmp(DeptNo varchar(20),WareHouse varchar(20),ItemID bigint,SQty decimal(18,6))
	Insert Into #Tmp(DeptNo,WareHouse,ItemID,SQty)
	Select @DeptNo,@WareHouse,a.ItemID,Sum(a.RQty)
	From PMS_ReturnDtl a
        INNER JOIN BDM_ItemInfo b ON a.ItemId=b.ItemId
	Where a.ReturnNo=@ReturnNo AND b.IsVirtual=0
	Group By a.ItemID
	--审核通过
	if @Flag='20'
		begin
			--写入供应商欠款
			Update BDM_Vendor Set ArgAmt=isnull(ArgAmt,0)-isnull(@Amt,0)
			Where VendorID=@VendorID
			--写入采购入库单
			Insert Into PMS_Stock(StockNo,DeptNo,WareHouse,CreateDate,VendorID,BillType,BillSts,CreatorID,
				AuditDate,AuditID,Remarks)
			Select ReturnNo,DeptNo,WareHouse,CreateDate,VendorID,'20','20',CreatorID,@AuditDate,AuditID,Remarks 
			From PMS_Return
			Where ReturnNo=@ReturnNo And Not Exists(Select 1 From PMS_Stock Where StockNo=@ReturnNo)
			--写入采购入库明细
			Insert Into PMS_StockDtl(StockNo,ItemID,WareHouse,PkgQty,SQty,Price,Amt,Location,TaxFlag,IsSpecial)
			Select ReturnNo,ItemID,WareHouse,-PkgQty,-RQty,Price,-Amt,Location,TaxFlag,IsSpecial
			From PMS_ReturnDtl
			Where ReturnNo=@ReturnNo And Not Exists(Select 1 From PMS_StockDtl Where StockNo=@ReturnNo)
			--写入流水帐中
			Insert Into IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,CreateDate,AuditDate,wmsBillNo)
			Select a.ReturnNo,'采购退货单',@DeptNo,@WareHouse,a.ItemID,-a.RQty,a.Price,-a.Amt,@CreateDate,@AuditDate,a.ReturnNo
			From PMS_ReturnDtl a
                INNER JOIN BDM_ItemInfo b On a.itemId=b.itemId
			Where a.ReturnNo=@ReturnNo AND b.IsVirtual=0
			--更新商品资料文件
			Update a set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.SQty,0)
			From BDM_ItemInfo a Inner Join #Tmp b On a.ItemID=b.ItemID
			--更新分部商品资料文件
			Update a set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.SQty,0)
			From IMS_Subdepot a Inner Join #Tmp b On a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
			--写入总帐
			Update a set a.OnHandQty=Isnull(a.OnHandQty,0)-Isnull(b.SQty,0),a.LastTime=GetDate()
			From IMS_Ledger a Inner Join #Tmp b On a.ItemID=b.ItemID And a.WareHouse=b.WareHouse
		end
	--取消审核
	if @Flag='10' 
		begin
			--写入供应商欠款
			Update BDM_Vendor Set ArgAmt=isnull(ArgAmt,0)+isnull(@Amt,0)
			Where VendorID=@VendorID
			--删除明细数据
			Delete From PMS_StockDtl WHere StockNo=@ReturnNo 
			--删除入库单数据
			Delete From PMS_Stock Where StockNo=@ReturnNo
			--删除流水帐中的记录
			Delete from IMS_Flow Where BillNo=@ReturnNo
			--更新商品资料文件
			Update a set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.SQty,0)
			From BDM_ItemInfo a Inner Join #Tmp b On a.ItemID=b.ItemID
			--更新分部商品资料文件
			Update a set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.SQty,0)
			From IMS_Subdepot a Inner Join #Tmp b On a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
			--库房总帐
			Update a set a.OnHandQty=Isnull(a.OnHandQty,0)+Isnull(b.SQty,0),a.LastTime=GetDate()
			From IMS_Ledger a Inner Join #Tmp b On a.ItemID=b.ItemID And a.WareHouse=b.WareHouse
		end 
	--作废
	if @Flag='00'
		--更新原入库单的退货数量
		Update a set a.RQty=Isnull(a.RQty,0)-abs(Isnull(b.RQty,0))
		From PMS_StockDtl a Inner Join PMS_ReturnDtl b On a.StockID=b.StockID
		Where ReturnNo=@ReturnNo	
    UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='inv_posting_job';
End
go

