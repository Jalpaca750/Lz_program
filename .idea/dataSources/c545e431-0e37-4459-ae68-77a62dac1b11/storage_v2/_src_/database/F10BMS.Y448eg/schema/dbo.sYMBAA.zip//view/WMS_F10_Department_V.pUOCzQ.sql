

/*==============================================================*/
/* View: WMS_F10_Department_V                                   */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_Department_V] as
SELECT a.CodeID,b.deptId,b.deptNo,b.deptName,b.parentId
FROM dbo.BDM_DeptCode_V a
	INNER JOIN YiWms.dbo.BAS_Department b ON a.CodeNo=b.deptNo
WHERE EXISTS(SELECT * FROM SYS_Config c WHERE b.companyId=c.companyId)
go

