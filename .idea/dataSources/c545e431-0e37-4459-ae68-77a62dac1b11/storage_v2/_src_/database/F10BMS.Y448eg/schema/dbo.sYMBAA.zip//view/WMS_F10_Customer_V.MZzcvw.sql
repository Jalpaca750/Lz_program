
/*==============================================================*/
/* View: WMS_F10_Customer_V                                     */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_Customer_V] as
SELECT a.custId,p.partnerId AS customerId,p.partnerNo AS customerNo,p.partnerName AS customerName,p.companyAddress,
	a.ServiceID,e1.EmployeeName AS ServiceName,a.LinkMan,a.Phone,pc.CHName AS popedomName
FROM dbo.BDM_Customer a 
	INNER JOIN YiWms.dbo.BAS_Partner p ON a.CustNo=p.partnerNo
	LEFT JOIN dbo.BDM_Employee e1 ON a.ServiceID=e1.EmployeeID
    LEFT JOIN dbo.BDM_PopedomCode_V pc ON a.popedomId=pc.CodeID
WHERE EXISTS(SELECT 1 FROM dbo.SYS_Config b WHERE p.companyId=b.companyId AND p.ownerId=b.OwnerId AND p.partnerType=1)
go

