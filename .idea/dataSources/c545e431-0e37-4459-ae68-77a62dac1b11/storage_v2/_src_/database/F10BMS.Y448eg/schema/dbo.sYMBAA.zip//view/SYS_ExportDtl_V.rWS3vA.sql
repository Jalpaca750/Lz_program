--导出
CREATE VIEW dbo.SYS_ExportDtl_V
--with encryption
AS
SELECT a.ExportID, a.ExportNo, a.TblCode, a.FdCode, a.CHName, a.Seq, a.WithValue, 
      a.Row, a.Col, a.IsExport, b.EmployeeID, b.FrmCode, b.IsDef
FROM dbo.SYS_EXPORTDTL a INNER JOIN
      dbo.SYS_EXPORT b ON a.ExportNo = b.ExportNo
go

