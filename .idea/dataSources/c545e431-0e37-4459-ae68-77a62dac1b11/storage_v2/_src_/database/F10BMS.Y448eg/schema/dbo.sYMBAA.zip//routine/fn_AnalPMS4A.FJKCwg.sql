--说明：未执行计划分析
--作者：Devil.H
--创建：2007.11.23
--参数：
--	@Year:年分
--	@Month：月份
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:标识
CREATE Function fn_AnalPMS4A
(
	@DeptNo varchar(20)
)
Returns table
As
Return(SELECT b.PlanID,a.PlanNo,a.CreateDate,a.DeptNo,d1.CHName as DeptName,
		b.ItemID,g.ItemNo,g.ItemName,g.ItemAlias,g.BarCode,g.NameSpell,
		g.ItemSpec,g.ClassID,g.ClassName,g.LabelID,g.LabelName,g.ColorName,g.PkgSpec,
		g.UnitName,b.PQty,Isnull(b.PQty,0.0)-Isnull(b.OQty,0.0) as RemOQty,b.PkgQty,
		v.VendorNo,v.VendorName,a.CreatorID,a.BillSts,e.EmployeeName as Creator,a.Remarks,
		(SELECT StsName FROM BillStatus s WHERE s.BillSts=a.BillSts And s.BillType='PMS30') AS StsName
	FROM PMS_Plan a INNER JOIN PMS_PlanDtl b ON a.PlanNo=b.PlanNo
		INNER JOIN BDM_ItemInfo_V g ON b.ItemID=g.ItemID
		LEFT OUTER JOIN BDM_Vendor_V v ON b.VendorID=v.VendorID
		LEFT OUTER JOIN BDM_DeptCode_V d1 ON a.DeptNo=d1.CodeID
		LEFT OUTER JOIN BDM_Employee e ON e.EmployeeID=a.CreatorID
	WHERE (a.BillSts='10' Or a.BillSts='20' Or a.BillSts='25')
		And (a.DeptNo like @DeptNo + '%')
		And Isnull(b.PQty,0.0)-Isnull(b.OQty,0.0)>0.0
)
go

