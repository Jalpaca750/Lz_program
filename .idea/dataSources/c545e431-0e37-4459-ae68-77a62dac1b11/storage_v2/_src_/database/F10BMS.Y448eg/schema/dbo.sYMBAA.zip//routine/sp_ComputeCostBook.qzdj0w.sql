--说明：月末成本帐
--作者：Devil.H
--创建：2007.11.06
--参数：@Period:会计月份
--参与运算：
--本月出库（销售出库、其他出库、报损出库、赠品出库，调拨出库,组装出库，拆卸出库）
--本月入库（采购入库、其他入库、赠品入库、盘点数据、调拨入库，组装入库，拆卸入库）
CREATE Proc sp_ComputeCostBook
(
	@Period char(6)
)
As
Begin
	set nocount on
	declare @Method char(1)				--成本核算方式
	declare @StartDate char(10)
	declare @EndDate char(10)
	--创建临时表,存储本期入库数量、出库数量
	Create Table #Tmp1(DeptNo varchar(20),ItemID bigint,IQty decimal(18,6),CQty decimal(18,6))
	Create Table #Tmp2(DeptNo varchar(20),ItemID bigint,IQty decimal(18,6),CQty decimal(18,6) Primary Key(DeptNo,ItemID))
	--判断当前月是否已经封帐
	If  exists(Select 1 from Sys_Period Where isnull(SealFlag,0)=1 And Period=@Period)
		return
	--获取成本核算方式
	Select @Method=Method From Sys_Config
	--当前会计期起始日期和截止日期
	Select @StartDate=StartDate,@EndDate=EndDate From SYS_CW_MonthPeriod Where CW_Period=@Period
	--销售出库数量
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select a.DeptNo,b.ItemID,0.0 as IQty,Sum(Isnull(b.SQty,0.0) + Isnull(ZQty,0.0)) as CQty
	From SMS_Stock a Inner join SMS_StockDtl b on a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.DeptNo,b.ItemID
	--其他出库
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)	
	Select a.DeptNo,b.ItemID,0.0 as IQty,Sum(b.SQty) as CQty
	From IMS_Other a Inner join IMS_OtherDtl b on a.OtherNo=b.OtherNo
	Where (a.BillType='20') And (a.BillSts='20')
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.DeptNo,b.ItemID
	Union ALl 
	Select a.DeptNo,b.ItemID,0.0 as IQty,Sum(-b.SQty) as CQty
	From IMS_Other a Inner join IMS_OtherDtl b on a.OtherNo=b.OtherNo
	Where (a.BillType='50') And (a.BillSts='20')
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.DeptNo,b.ItemID
	Union ALl 
	Select a.DeptNo,b.ItemID,0.0 as IQty,Sum(b.SQty) as CQty
	From IMS_Other a Inner join IMS_OtherDtl b on a.OtherNo=b.OtherNo
	Where (a.BillType='30') And (a.BillSts='20') 
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.DeptNo,b.ItemID
	--赠品出库
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select a.DeptNo,b.ItemID,0.0 as IQty,Sum(b.SQty) as CQty
	From IMS_Present a Inner join IMS_PresentDtl b on a.PresentNo=b.PresentNo
	Where (a.BillType='20') And (a.BillSts='20')
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.DeptNo,b.ItemID
	--调拨出库
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select a.DeptNo,b.ItemID,0.0 as IQty,Sum(b.SQty) as CQty
	From IMS_Allot a inner join IMS_AllotDtl b on a.AllotNo=b.AllotNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.DeptNo,b.ItemID 
	Union all
	Select a.DeptNo,b.ItemID,0 as IQty,Sum(b.IQty) as CQty
	From IMS_Allot a inner join IMS_AllotDtl b on a.AllotNo=b.AllotNo
	Where (a.BillSts='05') 
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.DeptNo,b.ItemID 
	--组装出库
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select a.DeptNo,b.ItemID,0.0 as IQty,Sum(b.OQty) as CQty
	From IMS_Assembly a inner join IMS_AssemblyDtl b on a.AssemblyNo=b.AssemblyNo
	Where (a.BillSts='20') 
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.DeptNo,b.ItemID 
	--拆卸出库
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select DeptNo,ItemID,0.0 as IQty,Sum(OQty) as CQty
	From IMS_Split
	Where (BillSts='20')
		And (CreateDate Between @StartDate And @EndDate)
	Group By DeptNo,ItemID 
	--计算采购入库数量
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select a.DeptNo,b.ItemID,Sum(b.SQty) as IQty,0.0 as CQty 
	From PMS_Stock a Inner join PMS_StockDtl b On a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		And (a.CreateDate Between @StartDate And @EndDate)
	Group by a.DeptNo,b.ItemID

	--其他入库单
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select a.DeptNo,b.ItemID,Sum(b.SQty) as IQty,0.0 as CQty
	From IMS_Other a Inner join IMS_OtherDtl b On a.OtherNo=b.OtherNo
	Where (a.BillType='10') And (a.BillSts ='20') 
		And (a.CreateDate Between @StartDate And @EndDate)
	Group by a.DeptNo,b.ItemID
	Union All
	Select a.DeptNo,b.ItemID,Sum(b.SQty) as IQty,0.0 as CQty
	From IMS_Other a Inner join IMS_OtherDtl b On a.OtherNo=b.OtherNo
	Where (a.BillType='60') And (a.BillSts='20')
		And a.CreateDate Between @StartDate And @EndDate
	Group by a.DeptNo,b.ItemID
	--赠品入库
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select a.DeptNo,b.ItemID,Sum(b.SQty) as IQty,0.0 as CQty
	From IMS_Present a Inner join IMS_PresentDtl b on a.PresentNo=b.PresentNo
	Where (a.BillType='10') And (a.BillSts='20')
		And a.CreateDate Between @StartDate And @EndDate
	Group By a.DeptNo,b.ItemID
	--调拨入库单
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select a.DeptNo,b.ItemID,Sum(b.IQty) as IQty,0.0 as CQty
	From IMS_Incept a inner join IMS_InceptDtl b on a.InceptNo=b.InceptNo
	Where (a.BillSts='20')
		And (a.CreateDate Between @StartDate And @EndDate)
	Group By a.DeptNo,b.ItemID
	--盘点
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select DeptNo,ItemID,Sum(SQty) as IQty,0.0 as CQty
	From IMS_Audit
	Where CreateDate Between @StartDate And @EndDate And Locked=1
	Group By DeptNo,ItemID

	--组装入库
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select DeptNo,ItemID,Sum(IQty) as IQty,0 as CQty
	From IMS_Assembly
	Where BillSts='20' 
		And (CreateDate Between @StartDate And @EndDate)
	Group By DeptNo,ItemID
	--拆卸入库单
	Insert Into #Tmp1(DeptNo,ItemID,IQty,CQty)
	Select a.DeptNo,b.ItemID,Sum(b.IQty) as IQty,0 as CQty
	From IMS_Split a inner join IMS_SplitDtl b on a.SplitNo=b.SplitNo
	Where a.BillSts='20' And a.CreateDate Between @StartDate And @EndDate
	Group By a.DeptNo,b.ItemID
	if @Method='S'
		begin
			--汇总当前入出库数量
			Insert Into #Tmp2(DeptNo,ItemID,IQty,CQty)
			Select DeptNo,ItemID,Sum(IQty),Sum(CQty)
			From #Tmp1
			Group By DeptNo,ItemID
			--更新
			Update a Set a.MIQty=isnull(b.IQty,0),a.MOQty=isnull(b.CQty,0)
			From CST_Price a Inner Join #Tmp2 b On a.DeptNo=b.DeptNo And a.ItemID=b.ItemID
			Where a.Period=@Period
		end 
	if @Method='T'
		begin
			--汇总当前入出库数量
			Insert Into #Tmp2(DeptNo,ItemID,IQty,CQty)
			Select '$$$$',ItemID,Sum(IQty),Sum(CQty)
			From #Tmp1
			Group By ItemID
			Update a Set a.MIQty=isnull(b.IQty,0),a.MOQty=isnull(b.CQty,0)
			From CST_Price a Inner Join #Tmp2 b On b.DeptNo='$$$$' And a.ItemID=b.ItemID
			Where a.Period=@Period
		end
	--更新期末数量、金额
	Update CST_Price Set MEQty=Isnull(MSQty,0)+Isnull(MIQty,0)-Isnull(MOQty,0),
		MEAmt=Round(Isnull(MEPrice,0)*(Isnull(MSQty,0)+Isnull(MIQty,0)-Isnull(MOQty,0)),4)
	Where Period=@Period
End
go

