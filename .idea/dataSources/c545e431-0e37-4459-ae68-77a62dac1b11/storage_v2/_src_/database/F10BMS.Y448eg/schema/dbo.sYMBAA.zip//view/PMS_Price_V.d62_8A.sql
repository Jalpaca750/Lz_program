CREATE VIEW dbo.PMS_Price_V
AS
SELECT a.PriceID, a.DeptNo, d.CHName AS DeptName, a.VendorID, b.VendorNo, 
      b.VendorName, b.NameSpell AS VNameSpell, b.LinkMan, b.Phone, b.Faxes, a.ItemID, 
      C.ItemNo, C.ItemName, C.ItemAlias, C.NameSpell AS INameSpell, C.ItemSpec, 
      C.BarCode, C.ClassID, C.ClassName, C.LabelID, C.LabelName, C.ColorName, 
      C.UnitName, a.Price, a.TaxFlag, C.PPrice, C.SafePPrice, C.BPackage, C.MPackage, 
      C.Package, C.PkgRatio, C.PkgSpec, C.HotFlag, C.NotDisc, C.Integral, C.Defined1, 
      C.Defined2, C.Defined3, C.Defined4, C.Defined5, a.DefVendor,a.LastDate, a.CheckBox
FROM dbo.PMS_Price a LEFT OUTER JOIN
      dbo.BDM_DeptCode_V d ON a.DeptNo = d.CodeID LEFT OUTER JOIN
      dbo.BDM_Vendor b ON a.VendorID = b.VendorID LEFT OUTER JOIN
      dbo.BAS_Goods_V C ON a.ItemID = C.ItemID
go

