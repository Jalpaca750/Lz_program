CREATE VIEW dbo.RPT_SellGeneralBook_V
AS
SELECT a.CustID, b.CustNo, b.CustName, b.NameSpell, b.CustType, b.TypeName, 
      b.MemberID, b.Member, b.AreaCode, b.AreaName, b.PopedomID, b.PopedomName, 
      b.SalesID, b.Sales, b.KindName, b.TradeName, a.Years, a.Months, a.IMSAmt, 
      a.IXSAmt, a.IYKAmt, a.IFPAmt, a.IZKAmt, a.IMEAmt, a.PMSAmt, a.PFPAmt, a.PYSAmt, 
      a.PSKAmt, a.PMFAmt, a.PYFAmt, a.PCXAmt, a.PMEAmt, a.LstDate, b.LinkMan, 
      b.Phone, b.Faxes
FROM dbo.RPT_SellGeneralBook a INNER JOIN
      dbo.BDM_Customer_V b ON a.CustID = b.CustID
go

