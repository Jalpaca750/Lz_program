--说明：客户赠品成本统计
--作者：Devil.H
--创建：2005.04.22
--参数：
--	@Months:月份
--	@Flag:0-自然月,1-会计月
--参与运算：
--当前月的销售出库数据
Create proc sp_SellGProfitPresent
(
	@Year int,
	@Month int
)
--加密
--with encryption
As
Begin
	declare @Period char(6)
	declare @Method char(1)
	select @Method=isnull(Method,'T') From Sys_Config
	print @Method
	--获取当前会计期
	if @Month<10
		Set @Period=Cast(@Year as char(4))+'0'+Cast(@Month as char(1))
	else
		Set @Period=Cast(@Year as char(4))+Cast(@Month as char(2))
	--创建临时表
	Create Table #Tmp(PresentID bigint,PresentNo varchar(20),DeptNo varchar(20),ItemID bigint,
		CPrice decimal(18,6),SQty decimal(18,6))
	Create Table #Tmp2(ItemID bigint,DeptNo varchar(20),MEPrice decimal(18,6))
	Insert Into #Tmp2(ItemID,DeptNo,MEPrice)
	Select ItemID,DeptNo,MEPrice From uf_ComputePrice(@Period)
	--获取本月赠送数据
	Insert Into #Tmp(PresentID,PresentNo,DeptNo,ItemID,SQty)
	Select b.PresentID,b.PresentNo,a.DeptNo,b.ItemID,b.SQty
	From IMS_Present a inner join IMS_PresentDtl b on a.PresentNo=b.PresentNo
	Where a.BillSts Not In('00','10') And Year(a.CreateDate)=@Year And Month(a.CreateDate)=@Month
	--更新成本单价
	if @Method='T'
		Update a Set a.CPrice=b.MEPrice
		From #Tmp a,#Tmp2 b
		Where a.ItemID=b.ItemID
	else
		Update a Set a.CPrice=b.MEPrice
		From #Tmp a,#Tmp2 b
		Where a.ItemID=b.ItemID And a.DeptNo=b.DeptNo
	--更新赠品单成本单价
	Update a Set a.CPrice=isnull(b.CPrice,0)
	From IMS_PresentDtl a inner join #Tmp b on a.PresentID=b.PresentID
	Drop Table #Tmp
	Drop Table #Tmp2
End

go

