--说明：商品采购分析
--作者：Devil.H
--创建：2007.11.22
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:计算标识
CREATE Function dbo.fn_AnalPMS2A
(
	@StartDate char(10)='2000-01-01',
	@EndDate char(10)='2000-01-01',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	NameSpell varchar(200),
	ItemSpec varchar(100),
	ItemAlias varchar(200),
	BarCode varchar(100),
	ClassID varchar(20),
	ClassName varchar(100),
	LabelID varchar(20),
	LabelName varchar(100),
	ColorName varchar(20),
	UnitName varchar(40),
	PkgSpec varchar(40),
	AvgPrice decimal(18,6),
	SQty decimal(18,6),
	RQty decimal(18,6),
	TQty decimal(18,6),
	PkgQty decimal(18,6),
	PurAmt decimal(18,6),
	RetAmt decimal(18,6),
	TotalAmt decimal(18,6),
	PurPercent decimal(18,6),
	RetPercent decimal(18,6),
	R_PScale decimal(18,6),
	R_PPercent decimal(18,6)
)
As
Begin
	declare @SumAmt decimal(18,6)
	declare @SumRAmt decimal(18,6)
	if @Flag=0
		Return
	--初始化变量
	Set @StartDate=Convert(Char(10),Cast(@StartDate as datetime),120)
	Set @EndDate=Convert(Char(10),Cast(@EndDate as datetime),120)
	
	Insert Into @uTable(ItemID,RQty,RetAmt,SQty,PurAmt,TQty,TotalAmt)	
	Select b.ItemID,
		RQty=abs(Sum(Case a.BillType When '20' then b.SQty else 0.0 end)),
		RetAmt=abs(Sum(Case a.BillType when '20' then b.Amt else 0.0 end)),
		SQty=abs(Sum(Case a.BillType When '10' then b.SQty else 0.0 end)),
		PurAmt=isnull(Sum(Case a.BillType when '10' then b.Amt else 0.0 end),0.0)
			+isnull(Sum(Case a.BillType when '30' then b.Amt else 0.0 end),0.0),
		Sum(b.SQty),Sum(b.Amt)
	From PMS_Stock a inner join PMS_StockDtl b On a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.DeptNo like @DeptNo + '%')
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And Exists(Select 1 From BDM_DeptCode_V d Where (a.DeptNo=d.CodeID) And (d.DeptNo Like @CorpNo + '%'))
	Group By b.ItemID

	--更新商品信息
	Update a Set a.ItemNo=b.ItemNo,a.ItemName=b.ItemName,a.ItemSpec=b.ItemSpec,a.UnitName=b.UnitName,
		a.ColorName=b.ColorName,a.ClassName=b.ClassName,a.LabelName=b.LabelName,a.NameSpell=b.NameSpell,
		a.ItemAlias=b.ItemAlias,a.BarCode=b.BarCode,a.ClassID=b.ClassID,a.LabelID=b.LabelID,a.PkgSpec=b.PkgSpec,
		a.PkgQty=Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.TQty,0.0)/b.PkgRatio,4) End		
	From @uTable a inner join BDM_ItemInfo_V b On a.ItemID=b.ItemID
	--获取以上供应商的总采购额
	Select @SumAmt=Sum(PurAmt),@SumRAmt=Sum(RetAmt) From @uTable
	--更新各个供应商采购百分比
	Update @uTable Set PurPercent=case Isnull(@SumAmt,0.0) 
				When 0.0 then 0.0 
				Else Round(isnull(PurAmt,0.0)/@SumAmt,6) End,
		RetPercent=case Isnull(@SumRAmt,0.0)
				When 0.0 then 0.0
				Else Round(isnull(RetAmt,0.0)/@SumRAmt,6) End,
		R_PPercent=case Isnull(PurAmt,0.0)
				When 0.0 then 0.0
				Else round(Isnull(RetAmt,0.0)/Isnull(PurAmt,0.0),6) End,
		AvgPrice=case isnull(SQty,0.0)-isnull(RQty,0.0)
				when 0.0 then 0.0
				else round((isnull(PurAmt,0.0)-isnull(RetAmt,0.0))/(isnull(SQty,0.0)-isnull(RQty,0.0)),2) End 
	--更新权重
	Update @uTable Set R_PScale=case isnull(PurPercent,0.0)
				When 0.0 then 0.0
				Else Round(isnull(RetPercent,0.0)/Isnull(PurPercent,0.0),2) End 
	--返回
	Return
End
go

