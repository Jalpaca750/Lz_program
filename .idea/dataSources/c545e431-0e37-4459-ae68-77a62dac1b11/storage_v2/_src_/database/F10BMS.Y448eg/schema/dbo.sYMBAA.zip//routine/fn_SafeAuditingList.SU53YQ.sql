CREATE Function fn_SafeAuditingList
(
	@Flag as int=0
)
Returns @uTable Table
(
	CheckBox 	bit default 0,
	BillID 		bigint,
	BillNo		varchar(20),
	DeptNo		varchar(20),
	DeptName	varchar(100),
	ItemID 		bigint,
	ItemNo		varchar(20),
	ItemName	varchar(200),
	ItemSpec    varchar(100),
	ColorName	varchar(40),
	UnitName 	varchar(40),
	CustID 		Bigint,
	CustNo		varchar(20),
	CustName	varchar(200),
	QTY 		decimal(18,6),
	Price	  	decimal(18,6),
	Amt	  	decimal(18,6),
	SafeSPrice	decimal(18,6),
	PPrice		decimal(18,6),
	GProfit		decimal(18,6),
	BillSts		varchar(2),
	StsName		varchar(20),
	BillFlag	varchar(6),
	BillType	varchar(40),
	CreatorID 	bigint,
	CreatorName	varchar(100),
    OrderRenInfo varchar(1000),
	CreateDate	varchar(10),
	IsSafeAuditing	varchar(1),
	IsSafeAuditResult	varchar(10),
	IsSafeAuditEmployeeID 	bigint,
	IsSafeAuditEmployee 	varchar(40),
    Remarks varchar(2000)
)
As
Begin
	If @Flag=0 
		Return
	
	--销售报价单
	Insert Into @uTable(BillID,BillNo,DeptNo,DeptName,ItemID,ItemNo,ItemName,ItemSpec,
		ColorName,UnitName,CustID,CustNo,CustName,QTY,Price,Amt,PPrice,SafeSPrice,BillSts,StsName,
		BillFlag,BillType,CreatorID,CreatorName,CreateDate,IsSafeAuditing,IsSafeAuditResult,
		IsSafeAuditEmployeeID,IsSafeAuditEmployee,GProfit,Remarks,OrderRenInfo)
	Select b.BillID,b.BillNo,a.DeptNo,d.CHName As DeptName,b.ItemID,g.ItemNo,g.ItemName,
		g.ItemSpec,g.ColorName,g.UnitName,a.CustID,c.CustNo,c.CustName,b.Qty,b.Price,
		ROUND(ISNULL(b.Qty, 0) * ISNULL(b.Price, 0), 2) As Amt,g.PPrice,
		g.SafeSPrice,a.BillSts,
		(Select StsName From BillStatus s Where a.BillSts=s.BillSts And s.BillType='SMS20') As StsName,
		'SMS20' As BillFlag,'销售报价单' As BillType,a.CreatorID,e1.EmployeeName As CreatorName,
		a.CreateDate,b.IsSafeAuditing,b.IsSafeAuditResult,b.IsSafeAuditEmployeeID,
		e2.EmployeeName As IsSafeAuditEmployee,
		Case Isnull(b.Price,0.0) When 0.0 Then 0.0 
					 Else Round((Isnull(b.Price,0.0)-Isnull(g.PPrice,0.0))/b.Price,4) End As GProfit,
        a.Remarks,'' AS OrderRenInfo
	From SMS_Quote a Inner Join SMS_QuoteDtl b On a.BillNo=b.BillNo
			 Left Outer Join BDM_Customer c On a.CustID=c.CustID
			 Left Outer Join BDM_ItemInfo g On b.ItemID=g.ItemID
			 Left Outer Join BDM_Employee e1 On a.CreatorID=e1.EmployeeID
			 Left Outer Join BDM_DeptCode_V d On a.DeptNo=d.CodeID
			 Left Outer Join BDM_Employee e2 On b.IsSafeAuditEmployeeID=e2.EmployeeID
	Where b.IsSafeAuditing=1
	--销售订单
	Insert Into @uTable(BillID,BillNo,DeptNo,DeptName,ItemID,ItemNo,ItemName,ItemSpec,
		ColorName,UnitName,CustID,CustNo,CustName,QTY,Price,Amt,PPrice,SafeSPrice,BillSts,StsName,
		BillFlag,BillType,CreatorID,CreatorName,CreateDate,IsSafeAuditing,IsSafeAuditResult,
		IsSafeAuditEmployeeID,IsSafeAuditEmployee,GProfit,Remarks,OrderRenInfo)
	select b.OrderID,b.OrderNo,a.DeptNo,d.CHName As DeptName,b.ItemID,g.ItemNo,g.ItemName,
		g.ItemSpec,g.ColorName,g.UnitName,a.CustID,c.CustNo,c.CustName,b.OQTY,b.Price,b.Amt,g.PPrice,
		g.SafeSPrice,a.BillSts,
		(Select StsName From BillStatus s Where a.BillSts=s.BillSts And s.BillType='SMS30') As StsName,
		'SMS30' As BillFlag,'销售订货单' As BillType,a.CreatorID,e1.EmployeeName As CreatorName,
		a.CreateDate,b.IsSafeAuditing,b.IsSafeAuditResult,b.IsSafeAuditEmployeeID,
		e2.EmployeeName As IsSafeAuditEmployee,
		Case Isnull(b.Price,0.0) When 0.0 Then 0.0 
					 Else Round((Isnull(b.Price,0.0)-Isnull(g.PPrice,0.0))/b.Price,4) End As GProfit,
        a.Remarks,a.OrderRenInfo
	From SMS_Order a Inner Join SMS_OrderDtl b On a.OrderNo=b.OrderNo
			 Left Outer Join BDM_Customer c On a.CustID=c.CustID
			 Left Outer Join BDM_ItemInfo g On b.ItemID=g.ItemID
			 Left Outer Join BDM_Employee e1 On a.CreatorID=e1.EmployeeID
			 Left Outer Join BDM_DeptCode_V d On a.DeptNo=d.CodeID
			 Left Outer Join BDM_Employee e2 On b.IsSafeAuditEmployeeID=e2.EmployeeID
	where b.IsSafeAuditing=1
	--销售出库单
	Insert Into @uTable(BillID,BillNo,DeptNo,DeptName,ItemID,ItemNo,ItemName,ItemSpec,
		ColorName,UnitName,CustID,CustNo,CustName,QTY,Price,Amt,PPrice,SafeSPrice,BillSts,StsName,
		BillFlag,BillType,CreatorID,CreatorName,CreateDate,IsSafeAuditing,IsSafeAuditResult,
		IsSafeAuditEmployeeID,IsSafeAuditEmployee,GProfit,Remarks)
	select b.StockID,b.StockNo,a.DeptNo,d.CHName As DeptName,b.ItemID,g.ItemNo,g.ItemName,g.ItemSpec,
		g.ColorName,g.UnitName,a.CustID,c.CustNo,c.CustName,b.SQTY,b.Price,b.Amt,g.PPrice,g.SafeSPrice,a.BillSts,
		(Select StsName From BillStatus s Where a.BillSts=s.BillSts And s.BillType='SMS40') As StsName,
		'SMS40' As BillFlag,'销售出库单' As BillType,a.CreatorID,e1.EmployeeName As CreatorName,
		a.CreateDate,b.IsSafeAuditing,b.IsSafeAuditResult,b.IsSafeAuditEmployeeID,
		e2.EmployeeName As IsSafeAuditEmployee,
		Case Isnull(b.Price,0.0) When 0.0 Then 0.0 
					 Else Round((Isnull(b.Price,0.0)-Isnull(g.PPrice,0.0))/b.Price,4) End As GProfit,a.Remarks
	From SMS_Stock a Inner Join SMS_StockDtl b On a.StockNo=b.StockNo 
			 Left Outer Join BDM_Customer c On a.CustID=c.CustID
			 Left Outer Join BDM_ItemInfo g On b.ItemID=g.ItemID
			 Left Outer Join BDM_Employee e1 On a.CreatorID=e1.EmployeeID
			 Left Outer Join BDM_DeptCode_V d On a.DeptNo=d.CodeID
			 Left Outer Join BDM_Employee e2 On b.IsSafeAuditEmployeeID=e2.EmployeeID
	Where b.IsSafeAuditing=1
	--销售调价单
	Insert Into @uTable(BillID,BillNo,DeptNo,DeptName,ItemID,ItemNo,ItemName,ItemSpec,
		ColorName,UnitName,CustID,CustNo,CustName,QTY,Price,Amt,PPrice,SafeSPrice,BillSts,StsName,
		BillFlag,BillType,CreatorID,CreatorName,CreateDate,IsSafeAuditing,IsSafeAuditResult,
		IsSafeAuditEmployeeID,IsSafeAuditEmployee,GProfit,Remarks)
	Select b.RectifyID,b.RectifyNo,a.DeptNo,d.CHName As DeptName,b.ItemID,g.ItemNo,g.ItemName,g.ItemSpec,
		g.ColorName,g.UnitName,a.CustID,c.CustNo,c.CustName,b.MQTY,b.Price,b.Amt,g.PPrice,g.SafeSPrice,a.BillSts,
		(Select StsName From BillStatus s Where a.BillSts=s.BillSts And s.BillType='SMS70') As StsName,
		'SMS70' As BillFlag,'销售调价单' As BillType,a.CreatorID,e1.EmployeeName As CreatorName,
		a.CreateDate,b.IsSafeAuditing,b.IsSafeAuditResult,b.IsSafeAuditEmployeeID,
		e2.EmployeeName As IsSafeAuditEmployee,
		Case Isnull(b.Price,0.0) When 0.0 Then 0.0 
					 Else Round((Isnull(b.Price,0.0)-Isnull(g.PPrice,0.0))/b.Price,4) End As GProfit,a.Remarks
	From SMS_Rectify a Inner Join SMS_RectifyDtl b On a.RectifyNo=b.RectifyNo 
			   Left Outer Join BDM_Customer c On a.CustID=c.CustID
			   Left Outer Join BDM_ItemInfo g On b.ItemID=g.ItemID
			   Left Outer Join BDM_Employee e1 On a.CreatorID=e1.EmployeeID
			   Left Outer Join BDM_DeptCode_V d On a.DeptNo=d.CodeID
			   Left Outer Join BDM_Employee e2 On b.IsSafeAuditEmployeeID=e2.EmployeeID
	Where b.IsSafeAuditing=1
	--销售合同
	Insert Into @uTable(BillID,BillNo,DeptNo,DeptName,ItemID,ItemNo,ItemName,ItemSpec,
		ColorName,UnitName,CustID,CustNo,CustName,QTY,Price,Amt,PPrice,SafeSPrice,BillSts,StsName,
		BillFlag,BillType,CreatorID,CreatorName,CreateDate,IsSafeAuditing,IsSafeAuditResult,
		IsSafeAuditEmployeeID,IsSafeAuditEmployee,GProfit,Remarks)
	Select b.BillID,b.BillNo,a.DeptNo,d.CHName As DeptName,b.ItemID,g.ItemNo,g.ItemName,g.ItemSpec,
		g.ColorName,g.UnitName,a.CustID,c.CustNo,c.CustName,b.QTY,b.Price,ROUND(ISNULL(b.Qty, 0)* ISNULL(b.Price, 0), 2) As Amt,
		g.PPrice,g.SafeSPrice,a.BillSts,
		(Select StsName From BillStatus s Where a.BillSts=s.BillSts And s.BillType='CON20') As StsName,
		 'CON20' As BillFlag,'销售合同单' As BillType,a.CreatorID,e1.EmployeeName As CreatorName,
		a.CreateDate,b.IsSafeAuditing,b.IsSafeAuditResult,b.IsSafeAuditEmployeeID,
		e2.EmployeeName As IsSafeAuditEmployee,
		Case Isnull(b.Price,0.0) When 0.0 Then 0.0 
					 Else Round((Isnull(b.Price,0.0)-Isnull(g.PPrice,0.0))/b.Price,4) End As GProfit,a.Remarks
	From CON_SMS a Inner Join CON_SMSDtl b On a.BillNo=b.BillNo 
		       Left Outer Join BDM_Customer c On a.CustID=c.CustID
		       Left Outer Join BDM_ItemInfo g On b.ItemID=g.ItemID
		       Left Outer Join BDM_Employee e1 On a.CreatorID=e1.EmployeeID
		       Left Outer Join BDM_DeptCode_V d On a.DeptNo=d.CodeID
		       Left Outer Join BDM_Employee e2 On b.IsSafeAuditEmployeeID=e2.EmployeeID
	Where b.IsSafeAuditing=1
	Return
End
go

