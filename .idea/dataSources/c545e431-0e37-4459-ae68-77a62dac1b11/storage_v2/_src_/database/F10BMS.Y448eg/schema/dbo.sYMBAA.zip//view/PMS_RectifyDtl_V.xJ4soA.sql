CREATE VIEW dbo.PMS_RectifyDtl_V
AS
SELECT a.RectifyID, a.RectifyNo, d.CreateDate, d.BillSts, a.StockID, a.StockNo, a.ItemID, 
      c.ItemNo, c.ItemName, c.ItemAlias, c.NameSpell, c.ItemSpec, c.BarCode, c.ClassID, 
      c.ClassName, c.LabelID, c.LabelName, c.ColorName, c.UnitName, b.WareHouse, 
      a.RemRQty, a.MQty, a.Price, a.MPrice, a.Amt, a.TaxFlag, c.SafePPrice, c.TaxRate, 
      a.Remarks, c.Package, a.CheckBox
FROM dbo.PMS_RectifyDtl a LEFT OUTER JOIN
      dbo.BAS_Goods_V c ON a.ItemID = c.ItemID LEFT OUTER JOIN
      dbo.PMS_Rectify d ON a.RectifyNo = d.RectifyNo LEFT OUTER JOIN
      dbo.PMS_StockDtl b ON a.StockID = b.StockID
go

