
CREATE PROCEDURE [dbo].[sp_AfterIMSAdvance]
(
    @OrderNo varchar(20),                             --单据编号
    @advType VARCHAR(10),                             --标识
    @userId BIGINT                                    --当前用户      
)
AS
BEGIN
    DECLARE @wmsOrder VARCHAR(32);				        --订单单号(WMS系统)
    DECLARE @companyId VARCHAR(32);	                    --公司Id
	DECLARE @ownerId VARCHAR(32);                       --业主编号
	DECLARE @operatorId VARCHAR(32);				    --WMS用户Id
	DECLARE @errMsg VARCHAR(2000);                      --错误消息
    --如果未开启同步，则停止推送
    IF NOT EXISTS(SELECT * FROM dbo.SYS_Config WHERE ISNULL(startWms,0)=1)
	    RETURN;
	--获取公司Id,业主Id
    SELECT TOP 1 @companyId=companyId,@ownerId=ownerId FROM dbo.SYS_Config;
    --获取当前操作用户Id	
    SELECT @operatorId=userId
    FROM YiWms.dbo.SAM_User
    WHERE companyId=@companyId AND userNo=ANY(SELECT userNo=employeeNo FROM dbo.BDM_Employee WHERE EmployeeID=@userId);
    --是否需要进WMS
    IF (@advType='S')
    BEGIN
        IF NOT EXISTS(SELECT * FROM dbo.SMS_Order WHERE OrderNo=@OrderNo AND DeptNo IN(SELECT DeptNo FROM WMS_Config))
	        RETURN;
	END
	ELSE
	BEGIN
	    --如果非上海公司数据，直接退出
	    IF NOT EXISTS(SELECT * FROM dbo.PMS_Order WHERE OrderNo=@OrderNo AND DeptNo_A IN (SELECT DeptNo FROM WMS_Config))
		    RETURN;
	END
	--获取WMS订单编号和客户Id
    SELECT @wmsOrder=orderNo FROM YiWms.dbo.SAD_Order WHERE companyId=@companyId AND ownerId=@ownerId AND billNo=@OrderNo;
    --先锁定，再预占
    UPDATE YiWms.dbo.SAD_Order SET isLocked=1,lockerId=@operatorId WHERE orderNo=@wmsOrder;
    EXEC YiWms.dbo.up_F10OrderPreemption @wmsOrder,@companyId,@operatorId,@errMsg OUTPUT;
    --解锁
    UPDATE YiWms.dbo.SAD_Order SET isLocked=0,lockerId='' WHERE orderNo=@wmsOrder;
    IF LEN(@errMsg)>0
    BEGIN
        INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(REPLACE(NEWID(),'-',''),@companyId,GETDATE(),@operatorId,'sp_AfterIMSAdvance','YI_ORDER_PRE_ERROR',@errMsg,@wmsOrder,@OrderNo);
        RETURN -1;
    END
END
go

