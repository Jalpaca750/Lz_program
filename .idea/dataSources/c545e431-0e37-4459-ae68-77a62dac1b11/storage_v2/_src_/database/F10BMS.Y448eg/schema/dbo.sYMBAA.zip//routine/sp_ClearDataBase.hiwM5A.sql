--说明：实施前清除系统数据
--作者：Devil.H
--创建：2007.11.04
--修改: 2010.11.17 Frank.H
--	新增了客户销价和供应商销价是否保留的功能，清理以前清库不干净的表。
--参数：	
--	@Code:	1-清除;0-保留基本代码
--	@Item:	1-清除;0-保留商品资料
--	@Cust:	1-清除;0-保留客户资料
--	@Vendor:	1-清除;0-保留供应商资料
--	@Employee:	1-清除;0-保留员工资料
--	@CustPrice:	1-清除;0-保留客户销价
--	@VendorPrice:	1-清除;0-保留供应商进价
CREATE PROCEDURE sp_ClearDataBase 
(
    @Code CHAR(1)='0',
    @Item CHAR(1)='0',
    @Cust CHAR(1)='0',
    @Vendor CHAR(1)='0',
    @Employee CHAR(1)='0',
    @CustPrice CHAR(1)='0',
    @VendorPrice CHAR(1)='0'
)
AS
BEGIN
    DECLARE @errors BIGINT;
    SET NOCOUNT ON
    SET @errors=0;
    BEGIN TRANSACTION
    --删除基本代码
    IF (@Code='1')
    BEGIN
        --清除基本代码，并写入内置数据
        TRUNCATE TABLE BDM_Code;
        SET @errors=@errors+@@ERROR;
        INSERT INTO BDM_Code(CodeID,CodeNo,CHName,Classify) VALUES('1000','1000','非会员','FL10');
        SET @errors=@errors+@@ERROR;
        INSERT INTO BDM_Code(CodeID,CodeNo,CHName,Classify) VALUES('1001','1001','会员','FL10');
        SET @errors=@errors+@@ERROR;
        --删除相关基础数据上的基本代码
        UPDATE BDM_ItemInfo SET ClassID='',LabelID='',PurLine='';
        SET @errors=@errors+@@ERROR;
        UPDATE BDM_Customer SET DeptNo='',CustType='',MemberID='',AreaCode='',PopedomID='',BankID='',Degree='',TradeID='',KindID='',OutValue='',SalesAmt='',Persons='';
        SET @errors=@errors+@@ERROR;
        UPDATE BDM_Vendor SET BankID='',Degree='',TradeID='',KindID='',OutValue='',SalesAmt='',Persons=''
        SET @errors=@errors+@@ERROR;
        UPDATE BDM_Employee SET Degree='',DeptCode='',JobCode='';
        SET @errors=@errors+@@ERROR;
        --删除基本信息
        TRUNCATE TABLE BDM_Employee_DeptNo;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE BDM_EmployeeLine;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE SAM_Warehouse;
        SET @errors=@errors+@@ERROR;
    END
	--删除商品资料
    IF (@Item='1')
    BEGIN
        TRUNCATE TABLE BDM_ItemInfo;
        SET @errors=@errors+@@ERROR;
        --删除价格设置
        TRUNCATE TABLE SMS_Price;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE PMS_Price;
        SET @errors=@errors+@@ERROR;
    END
    ELSE
    BEGIN
        UPDATE BDM_ItemInfo Set OnHandQty=0.0,AllocQty=0.0;
        SET @errors=@errors+@@ERROR;
    END
	--删除客户
    IF (@Cust='1')
    BEGIN
        TRUNCATE TABLE BDM_Customer;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE BDM_SendAddress;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE BDM_CustomerCall;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE SMS_Price;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE Web_Costs_Class;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE BDM_Employee_Sales_Cust;
        SET @errors=@errors+@@ERROR;        
    END 
    ELSE
    BEGIN
        UPDATE BDM_Customer SET ArgAmt=0.0,Integral=0.0,Deduct=0.0,AdvAmt=0.0,SJInteg=0.0,qlInteg=0.0,zj_qlInteg=0.0,Integralbk=0.0;
    END
	--删除供应商
    IF (@Vendor='1')
    BEGIN
        TRUNCATE TABLE BDM_Vendor;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE PMS_Price;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE BDM_Employee_Sales_Vendor;
        SET @errors=@errors+@@ERROR;
    END 
    ELSE
    BEGIN
        UPDATE BDM_Vendor SET ArgAmt=0.0,AdvAmt=0.0;
        SET @errors=@errors+@@ERROR;
    END
	--删除客户价格
	IF (@CustPrice='1')
	BEGIN
        TRUNCATE TABLE SMS_Price;
        SET @errors=@errors+@@ERROR;
    END
	--删除供应商价格
	IF (@VendorPrice='1')
    BEGIN
		TRUNCATE TABLE PMS_Price;
        SET @errors=@errors+@@ERROR;
    END
	--删除员工数据
	IF (@Employee='1')
    BEGIN
        DELETE FROM BDM_Employee WHERE EmployeeID>99;
        SET @errors=@errors+@@ERROR;
        --删除用户
        DELETE FROM SAM_Operator WHERE EmployeeID>99;
        SET @errors=@errors+@@ERROR;
        --删除组
        DELETE FROM SAM_Team WHERE TeamNo<>'Admin';
        SET @errors=@errors+@@ERROR;
        --删除用户权限
        DELETE FROM SAM_Power WHERE EmployeeID>99;
        SET @errors=@errors+@@ERROR;
        DELETE FROM SAM_Special_Power WHERE EmployeeID>99;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE RPT_Power;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE RPT_AutoAwokePower;
        SET @errors=@errors+@@ERROR;
        --删除组权限
        DELETE FROM SAM_TPower WHERE TeamNo<>'Admin';
        SET @errors=@errors+@@ERROR;
        UPDATE BDM_ItemInfo SET CreatorID=99,MenderID=Null;
        SET @errors=@errors+@@ERROR;
        UPDATE BDM_Customer SET CreatorID=99,MenderID=Null;
        SET @errors=@errors+@@ERROR;
        UPDATE BDM_Vendor SET CreatorID=99,MenderID=Null;
        SET @errors=@errors+@@ERROR;
        --删除基本信息
        TRUNCATE TABLE BDM_Employee_DeptNo;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE BDM_Employee_Sales_Cust;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE BDM_Employee_Sales_Vendor;
        SET @errors=@errors+@@ERROR;
        TRUNCATE TABLE SAM_Warehouse;
        SET @errors=@errors+@@ERROR;
    END
	ELSE
    BEGIN
		UPDATE BDM_Employee SET ArgAmt=0;
        SET @errors=@errors+@@ERROR;
    END
	--查询设置
	TRUNCATE TABLE ANAL_Equity;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE ANAL_IMS7H;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE ANAL_PMSGBook;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE ANAL_SMSGBook;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE AnalPMS40;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE AnalSMS6A;
    SET @errors=@errors+@@ERROR;

	TRUNCATE TABLE BDM_AgentNote;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE BDM_Cust_Latency;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE BDM_CustCredit;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE BDM_ItemBand;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE BDM_Knowledge;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE BDM_SafePrice;		--删除提审数据
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE BDM_SendAdd_Latency;
    SET @errors=@errors+@@ERROR;
	--合同
	TRUNCATE TABLE CON_PMS;			--采购合同 
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE CON_PmsDtl;		--采购明细
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE CON_SMS;			--销售合同
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE CON_SmsDtl;		--销售明细
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE CON_SMS_Log;		--销售合同日志
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE CON_PMS_Log;		--采购合同日志？
    SET @errors=@errors+@@ERROR;

	--成本
	TRUNCATE TABLE CST_Price;		--删除成本数据
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE CST_PlanPrice;		--指定成本表
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE CST_Colligate_COST;	--综合成本
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE CST_Colligate_COST_Dtl;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE CST_Colligate_COST_Year;
    SET @errors=@errors+@@ERROR;

	--删除库存管理数据
	TRUNCATE TABLE IMS_Allocate;		--暂时没用
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_AllotDtl;		--调拨出库单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM IMS_Allot;			--调拨出库单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_AssemblyDtl;		--组装入库单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM IMS_Assembly;		--组装入库单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_Audit;		--盘点单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_CheckDtl;		--盘存清单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM IMS_Check;		--盘存清单
    SET @errors=@errors+@@ERROR;
    TRUNCATE TABLE IMS_CheckPoint;
    SET @errors=@errors+@@ERROR;
    TRUNCATE TABLE IMS_CheckStock;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_Flow;			--入出库流水账
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_InceptDtl;		--调拨入库单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM IMS_Incept;			--调拨入库单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_JXCReport;		--进销存报表
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_Ledger;		--库房总帐
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_OtherDtl;		--其他入出库单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM IMS_Other;			--其他入出库单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_PresentDtl;	--赠品入出库单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM IMS_Present;			--赠品入出库单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_RectifyDtl;		--调价单
    SET @errors=@errors+@@ERROR;
	DELETE FROM IMS_Rectify;		--调价单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_SplitDtl;		--拆卸入库单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM IMS_Split;			--拆卸入库单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_Subdepot;		--分部库房帐
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_TransferDtl		--移仓单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM IMS_Transfer		--移仓单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_YZStock		--预占库存
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE IMS_YZStockLog
    SET @errors=@errors+@@ERROR;
    TRUNCATE TABLE IMS_Advance;
    SET @errors=@errors+@@ERROR;
	
	--F10新增删除
	--批号
	TRUNCATE TABLE JobNumberNo_In;		--批号入库
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE JobNumberNo_Out;		--批号出库
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE JobNumberNo_AdjustH;	--调整历史
    SET @errors=@errors+@@ERROR;
	
	--删除采购数据
	TRUNCATE TABLE PMS_AdvancesDtl;		--供应商预付款明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM PMS_Advances;		--供应商预付款
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE PMS_Arrearage;		--供应欠款
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE PMS_InvoiceDtl;		--采购发票明细	
    SET @errors=@errors+@@ERROR;
	DELETE FROM PMS_Invoice;			--采购发票
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE PMS_OrderDtl;		--采购订单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM PMS_Order;			--采购订单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE PMS_PaymentDtl;		--采购付款明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM PMS_Payment;			--采购付款
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE PMS_PlanDtl;		--采购计划明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM PMS_Plan;			--采购计划
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE PMS_QuoteDtl;		--询价单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM PMS_Quote;			--询价单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE PMS_RectifyDtl;		--采购调价单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM PMS_Rectify;			--采购调价单	
    SET @errors=@errors+@@ERROR;	
	TRUNCATE TABLE PMS_ReturnDtl;		--采购退货单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM PMS_Return;			--采购退货单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE PMS_SafePrice;		--采购价格
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE PMS_StockDtl;		--采购入库单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM PMS_Stock;			--采购入库单
    SET @errors=@errors+@@ERROR;
	
	--项目
	TRUNCATE TABLE PRJ_Order;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE PRJ_Execute;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE PRJ_Cost;
    SET @errors=@errors+@@ERROR;
	
	--报表临时文件
	TRUNCATE TABLE RPT_IMSHive;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE RPT_PurGeneralBook;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE RPT_PurSimpleBook;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE RPT_SellAchieve;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE RPT_SellCostPrice;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE RPT_SellGeneralBook;
    SET @errors=@errors+@@ERROR;

	--销售机会
	TRUNCATE TABLE Sales_Opport;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE Sales_Action;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE Sales_ActionDtl;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE Sales_ActionD_Feedback;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE Sales_Action_Compete;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE Sales_ActionDtl_N;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SAM_Label;
    SET @errors=@errors+@@ERROR;
	--删除销售数据	
	TRUNCATE TABLE SMS_AdvancesDtl;		--客户预付款明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_Advances;		--客户预付款
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_Arrearage;		--客户欠款
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_Boxup;		--装箱
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_BoxupDtl;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_BoxupDtl_Dtl;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_CarNumberDtl;
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_CarNumber;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_ChangeDtl;
    SET @errors=@errors+@@ERROR;		--零钱发放单明细
	DELETE FROM SMS_Change;			--零钱发放单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_GatheringDtl;		--缴款单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_Gathering;		--缴款单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_InvoiceDtl;		--销售发票明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_Invoice;			--销售发票
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_OrderDtl;		--销售订单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_Order;			--销售订单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_PaymentDtl;		--销售收款单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_Payment;			--销售收款单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_QuoteDtl;		--报价单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_Quote;			--报价单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_RectifyDtl;		--销售调价单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_Rectify;			--销售调价单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_ReturnDtl;		--销售退货单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_Return;			--销售退货单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_StockDtl;		--销售出库单明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_Stock;			--销售出库单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_RetailDtl;		--零售明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_Retail;			--零售
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_Shift;		--交班单
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_ShiftDtl;		--交班单明细
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_RetailPrice;		--门店零售价
    SET @errors=@errors+@@ERROR;
	ALTER TABLE SMS_AStock Disable Trigger All;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SMS_AStockDtl;		--A单
    SET @errors=@errors+@@ERROR;
	DELETE FROM SMS_AStock;
    SET @errors=@errors+@@ERROR;
	ALTER TABLE SMS_AStock Enable Trigger All;
    SET @errors=@errors+@@ERROR;

	--删除促销数据
	TRUNCATE TABLE SPM_AmtLargessDtl;	--按金额促销明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SPM_AmtLargess;		--按金额促销
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_BatchMemberPrice;	--按金额促销明细
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_DiscountCardNo_DeptNo;--折扣卡明细
    SET @errors=@errors+@@ERROR;
	DELETE FROM SPM_DiscountCardNo;		--折扣卡
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_IntegLargess;		--积分赠送
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_Integral;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_ItemBand;
    SET @errors=@errors+@@ERROR;
	--促销商品邦定
	TRUNCATE TABLE SPM_ItemBandCustomer;	--促销商品邦定
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_ItemBandDtl;		--促销商品邦定
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_ItemBandDtl_Temp;	--促销商品邦定
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_Price;		--会员价
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_Promotion;		--价格促销
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_PromotionPrice;	--价格促销
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_PromotionPriceCustomer;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_PromotionPriceDtl;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_QtyLargess;		--按数量促销
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SPM_QtyLargessDtl;	--按数量促销明细	
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE Sys_Retail;		--零售相关设置
    SET @errors=@errors+@@ERROR;
	
	--网站数据
	TRUNCATE TABLE WEB_Customer;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE WEB_FousePic;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE WEB_HotSearch;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE WEB_News;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE WEB_Order;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE WEB_OrderDtl;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE WEB_Rank;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE WEB_SC_Class;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE WEB_User_SC;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE WEB_Big_Fouse;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE WEB_Book_get;
    SET @errors=@errors+@@ERROR;
	--日志
	TRUNCATE TABLE SYS_Logfile;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SYS_Period;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SYS_CW_MonthPeriod;
    SET @errors=@errors+@@ERROR;

	--审批
	TRUNCATE TABLE BillAuditing;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE SAM_Auditing_Operator;
    SET @errors=@errors+@@ERROR;
	DELETE FROM BDM_Account Where Len(AccountId)>4;
    SET @errors=@errors+@@ERROR;
	DELETE FROM BDM_RPType Where Len(rpId)>4;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE ACM_Fees;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE ACM_FeesDtl;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE ACM_FeesFlow;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE ACM_RPFlow;
    SET @errors=@errors+@@ERROR;

	TRUNCATE TABLE POS_Card;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE POS_CardCharge;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE POS_CardDivert;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE POS_CardFlow;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE POS_CardRetail;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE POS_CardTransaction;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE Web_ItemInfo_Add;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE Web_QuestionOrder;
    SET @errors=@errors+@@ERROR;
	TRUNCATE TABLE Web_QuestionReply;	
    SET @errors=@errors+@@ERROR;
    --清除编码表
    TRUNCATE TABLE SYS_Coding;
    SET @errors=@errors+@@ERROR;
    --清除开票数据
    TRUNCATE TABLE TCS_Order;
    SET @errors=@errors+@@ERROR;
    TRUNCATE TABLE TCS_InvoiceDetail;
    SET @errors=@errors+@@ERROR;
    TRUNCATE TABLE TCS_Invoice;
    SET @errors=@errors+@@ERROR;
    TRUNCATE TABLE TCS_InvoiceItems;
    SET @errors=@errors+@@ERROR;
    TRUNCATE TABLE TCS_InvoiceEx;
    SET @errors=@errors+@@ERROR;
    TRUNCATE TABLE SMS_StockEx;
    SET @errors=@errors+@@ERROR;    
    TRUNCATE TABLE SMS_PaymentEx
    SET @errors=@errors+@@ERROR; 
    TRUNCATE TABLE SMS_StockEx
    SET @errors=@errors+@@ERROR; 
    IF (@errors=0)
    BEGIN
        COMMIT;
    END
    ELSE
    BEGIN
        IF @@TRANCOUNT > 0
            ROLLBACK;
    END
END

go

