

/*==============================================================*/
/* View: WMS_F10_Line_V                                         */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_Line_V] as
SELECT a.CodeID,b.lineId
FROM dbo.BDM_Code a 
	INNER JOIN YiWms.dbo.BAS_AddressLine b ON a.CodeID=b.lineCode
WHERE EXISTS(SELECT * FROM SYS_Config c WHERE b.companyId=c.companyId)
go

