CREATE VIEW dbo.SPM_ItemBandDtl_V
AS
SELECT a.ItemBandNo,a.ParentID, c.ItemNo AS ParentNo, c.ItemName AS ParentName, a.ItemID, 
      b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, b.ItemSpec, b.BarCode, b.ClassID, 
      b.ClassName, b.LabelID, b.LabelName, b.ColorName, b.UnitName, b.Package, a.OQty, 
      b.PPrice, b.SPrice, b.SPrice1, b.SPrice2, b.SPrice3, b.SafePPrice, b.SafeSPrice, 
      b.Defined1, b.Defined2, b.Defined3, b.Defined4, b.Defined5, b.HotFlag, b.Flag, 
      b.Remarks
FROM dbo.SPM_ItemBandDtl a LEFT OUTER JOIN
      dbo.BDM_ItemInfo c ON a.ParentID = c.ItemID LEFT OUTER JOIN
      dbo.BAS_Goods_V b ON a.ItemID = b.ItemID
go

