CREATE VIEW dbo.SMS_QuoteDtl_V
AS
SELECT a.BillID, a.BillNo, a.DeptNo, a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, 
      	b.NameSpell, b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, b.LabelID, 
      	b.LabelName, b.ColorName, b.UnitName, a.Qty, a.Price, 
	ROUND(ISNULL(a.Qty, 0) * ISNULL(a.Price, 0), 2) AS Amt, d.OnHandQty,
	a.MPrice, b.PPrice, b.SPrice, b.SPrice1, b.SPrice2, b.SPrice3, b.SafeSPrice, 
	CASE Isnull(a.Price, 0) WHEN 0 THEN 0 
		                       ELSE round((Isnull(a.Price, 0) - isnull(b.PPrice, 0)) / Isnull(a.Price, 0), 6) END AS GProfit, 
	b.HotFlag, b.NotDisc,  a.IsSafeAuditing, a.IsSafeAuditResult, a.IsSafeAuditEmployeeID, 
      	SA.EmployeeName AS IsSafeAuditEmployee,a.Remarks, a.CheckBox
FROM dbo.SMS_QuoteDtl a LEFT OUTER JOIN
      	dbo.BAS_Goods_V b ON a.ItemID = b.ItemID LEFT OUTER JOIN
      	dbo.BDM_Employee SA ON a.IsSafeAuditEmployeeID = SA.EmployeeID LEFT OUTER JOIN
 	dbo.IMS_Subdepot d On a.DeptNo=d.DeptNo And a.ItemID=d.ItemID
go

