CREATE Function [dbo].[fn_AnalACMD01]
(
	@AccountId varchar(40),
	@ReportorId bigint,
	@StartDate varchar(10),
	@EndDate varchar(10),
	@QCAmt decimal(18,6),
	@Flag int=0
)
Returns @uTable Table(
	viewOrder bigint,
	CreateDate varchar(10),
	BillNo varchar(20),
	rpId varchar(40),
	rpName varchar(200),
	Notes varchar(2000),
	QCAmt decimal(18,6),
	ReceiveAmt decimal(18,6),
	PayAmt decimal(18,6),
	QMAmt decimal(18,6),
	BillType varchar(10),
	CreatorId bigint,
	CreatorName varchar(100)
)
begin
	Declare @viewOrder bigint
	Declare @billId bigint
	Declare @DeptNo varchar(20),@AccLimited INT
	if @Flag=0 
		Return
	--获取账户余额查询控制	
	Select @AccLimited=ISNULL(AccLimited,0) FROM SYS_Config;
	IF (@AccLimited=1)
        SELECT @DeptNo=LEFT(DeptCode,4) FROM BDM_Employee WHERE EmployeeID=@ReportorId;
    ELSE
        SET @DeptNo=''
	Set @viewOrder=1
	Insert Into @uTable(viewOrder,CreateDate,BillNo,rpId,rpName,Notes,QCAmt,ReceiveAmt,PayAmt,QMAmt,CreatorId,CreatorName,BillType)
	Values(@viewOrder,@StartDate,'10000000','','期初余额',@StartDate + '前余额',@QCAmt,0.0,0.0,@QCAmt,NULL,NULL,'')
	
	Declare myCursor Cursor
	For SELECT BillId
		FROM ACM_FeesFlow_V
		WHERE (AccountId Like @AccountId + '%')
		     And (ReportorId=@ReportorId)
			 And (CreateDate between @StartDate And @EndDate)
			 And (DeptNo LIKE @DeptNo+'%')
		ORDER BY CreateTime
	open mycursor
	fetch next from mycursor into @billId
	while @@fetch_status=0
	begin
		Set @viewOrder=@viewOrder+1
		Insert Into @uTable(viewOrder,CreateDate,BillNo,rpId,rpName,Notes,QCAmt,ReceiveAmt,PayAmt,QMAmt,CreatorId,CreatorName,BillType)
		Select @viewOrder,CreateDate,BillNo,rpId,rpName,Notes,@QCAmt,ReceiveAmt,PayAmt,@QCAmt + Isnull(PayAmt,0.0) + Isnull(ReceiveAmt,0.0),CreatorId,CreatorName,BillType
		From ACM_FeesFlow_V 
		Where BillId=@BillId
		SELECT @QCAmt = @QCAmt + Isnull(PayAmt,0.0) + Isnull(ReceiveAmt,0.0) 
		From ACM_FeesFlow 
		Where BillId=@BillId		
		fetch next from mycursor into @billId
	end
	close mycursor
	deallocate mycursor
	Return
End
go

