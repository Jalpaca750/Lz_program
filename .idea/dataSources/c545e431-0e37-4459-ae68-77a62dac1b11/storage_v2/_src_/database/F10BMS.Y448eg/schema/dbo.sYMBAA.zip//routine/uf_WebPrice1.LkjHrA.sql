
Create Function uf_WebPrice1
(
@CustID bigint
)
Returns Table

as 
Return(Select a.PicAmount,a.NTrue,a.AmendDate,a.CreateDate,a.origin,a.defined1,a.defined2,a.defined3,a.Defined4,
		a.ItemID,a.Weight,a.Sale,a.SaleOrder,a.LabelName,a.Cubage,a.Integral,a.OnHandQty,a.PurDays,a.PkgRatio, 
		a.Remarks, a.ItemNo,a.ItemName,a.NameSpell,a.ItemSpec,a.BarCode,a.ItemAlias,a.ClassID,a.ClassName, a.LabelID, 
		a.UnitName,a.PkgSpec,a.HotFlag,SPrice1,a.SPrice3,a.SPrice,a.Sprice2 as ZXprice,a.ColorName, a.IsWeb,a.Flag,a.NOrder,a.HotOrder,
		Isnull(b.Price,
			Isnull(c.Price,
				Isnull(d.MPrice,Case (Select upper(PriceFlag) from BDM_Customer Where CustID=@CustID) 
							When 'SPRICE1' then a.SPrice1 
							When 'SPRICE2' Then a.SPrice2 
							When 'SPRICE3' Then a.SPrice3 
							Else a.SPrice End)
				)
			) as SPrice2,b.Price as CXPrice,
		Isnull(c.Price,
				Isnull(d.MPrice,Case (Select upper(PriceFlag) from BDM_Customer Where CustID=@CustID) 
							When 'SPRICE1' then a.SPrice1 
							When 'SPRICE2' Then a.SPrice2 
							When 'SPRICE3' Then a.SPrice3 
							Else a.SPrice End)
				) as Price,(Case (Select upper(PriceFlag) from BDM_Customer Where CustID=@CustID) 
						When 'SPRICE1' then a.SPrice1 
						When 'SPRICE2' Then a.SPrice2 
						When 'SPRICE3' Then a.SPrice3 
						Else a.SPrice End) as YPrice,c.Price as HYPrice
	From BDM_ItemInfo_V a
	Left Outer Join 
	(SELECT ItemID,Price
	 FROM Web_Promotion_V WHERE (CustID = '' OR CustID IS NULL OR CustID = @CustID)
	) b On a.ItemID=b.ItemID
	Left Outer Join 
	(
	 SELECT ItemID,Price 
	 FROM SMS_Price 
	 Where CustID=@CustID 
	) c On a.ItemID=c.ItemID
	Left Outer Join 
	(
	 Select ItemID,MPrice
	 From SPM_Price
	 Where MemberID=Any(Select MemberID from BDM_Customer where CustID=@CustID)
	) d on a.ItemID=d.ItemID
	WHERE 1=1 
	--AND IsWeb=1
	AND Flag= '有效'
	)

go

