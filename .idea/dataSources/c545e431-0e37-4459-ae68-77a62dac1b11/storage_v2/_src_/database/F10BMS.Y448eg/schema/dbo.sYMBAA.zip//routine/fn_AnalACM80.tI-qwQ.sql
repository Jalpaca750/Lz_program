--说明：采购收票付款简明总帐
--作者：Devil.H
--创建：2007.11.15	
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:标识
CREATE Function dbo.fn_AnalACM80
(
	@StartDate char(10)='2000-01-01',
	@EndDate char(10)='2000-01-01',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
) 
Returns @uTable Table(
	VendorID bigint,
	VendorNo varchar(20),
	VendorName varchar(200),
	NameSpell varchar(200),
	BuyerID bigint,
	Buyer varchar(100),
	QCAmt decimal(18,6),
	CGAmt decimal(18,6),
	FPAmt decimal(18,6),
	FZAmt decimal(18,6),
	FKAmt decimal(18,6),
	MFAmt decimal(18,6),
	YFAmt decimal(18,6),
	CXAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40)
)
As
Begin	
	if @Flag=0
		Return
	--初始化变量
	Set @StartDate=Convert(Char(10),Cast(@StartDate as datetime),120)
	Set @EndDate=Convert(Char(10),Cast(@EndDate as datetime),120)
	--创建临时表
	declare @Tmp Table(VendorID bigint,
			   CGAmt decimal(18,6) default 0.0,
			   FPAmt decimal(18,6) default 0.0,
			   FZAmt decimal(18,6) default 0.0,
			   FKAmt decimal(18,6) default 0.0,
			   MFAmt decimal(18,6) default 0.0,
			   YFAmt decimal(18,6) default 0.0,
			   CXAmt decimal(18,6) default 0.0,
			   QCAmt decimal(18,6) default 0.0)
	--统计本期采购额
	Insert Into @Tmp(VendorID,CGAmt)
	Select a.VendorID,Sum(b.Amt) as CGAmt
  	From PMS_Stock a inner join PMS_StockDtl b on a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group By a.VendorID
	--统计本期发票金额
	Insert Into @Tmp(VendorID,FPAmt,FZAmt)
	Select VendorID,Sum(IAmt) as FPAmt,Sum(DAmt) as FZAmt
	From PMS_Invoice a
	Where (BillSts='20' Or BillSts='25' Or BillSts='30')
		And (Convert(char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group by VendorID
	--统计本期付款金额
	Insert Into @Tmp(VendorID,FKAmt,MFAmt)
	Select a.VendorID,Sum(b.PayAmt),Sum(b.FAmt)
	From PMS_Payment a inner join PMS_PaymentDtl b on a.PaymentNo=b.PaymentNo
	Where (a.BillSts='20') 
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group By a.VendorID
	--统计本期预付款
	Insert Into @Tmp(VendorID,YFAmt)
	Select b.VendorID,Sum(AdvAmt) as YFAmt
	From PMS_Advances a inner join PMS_AdvancesDtl b on a.AdvancesNo=b.AdvancesNo
	Where (a.BillSts='20')
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group By b.VendorID
	--统计本期冲预付款
	Insert Into @Tmp(VendorID,CXAmt)
	Select VendorID,Sum(AdvAmt) as CXAmt
	From PMS_Payment a
	Where (BillSts='20')
		And (Convert(char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group By VendorID
	--统计期初欠款
	Insert Into @Tmp(VendorID,QCAmt)
	Select VendorID,Sum(IAmt) as QCAmt
	From PMS_Invoice a
	Where (InvoiceNo Like '$00%') And (BillSts='20' Or BillSts='25' Or BillSts='30') 
		And (Convert(char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group by VendorID
	--合计
	Insert Into @uTable(VendorID,CGAmt,FPAmt,FZAmt,FKAmt,MFAmt,YFAmt,CXAmt,QCAmt)
	Select VendorID,Sum(CGAmt),Sum(FPAmt),Sum(FZAmt),Sum(FKAmt),Sum(MFAmt),Sum(YFAmt),Sum(CXAmt),Sum(QCAmt)
	From @Tmp
	Group By VendorID
	--更新供应商资料
	Update  a Set a.VendorNo=b.VendorNo,a.VendorName=b.VendorName,a.NameSpell=b.NameSpell,
		a.BuyerID=b.BuyerID,a.Buyer=b.Buyer,a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes
	From @uTable a , BDM_Vendor_V b
	Where a.VendorID=b.VendorID
	--返回
	Return
End
go

