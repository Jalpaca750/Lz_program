


-------------------------------------------------------------------------------------------------------------------------------------------------------
--更新时间：2012年5月29日 11:43:26
--更 新 人：CHENHEGANG
--更新说明：新增价差报表函数
CREATE Function fn_WebPriceDifference
(
	@CustID bigint,
	@BJYear bigint,
	@StartDate varchar(10),
	@EndDate varchar(10)
)
Returns @uTable Table
(
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(80),
	ItemSpec varchar(80),
	ColorName varchar(40),
	UnitName varchar(40),
	Price decimal(18,6),
	SQty decimal(18,6),
	Amt decimal(18,6),
	YPrice decimal(18,6),
	YAmt decimal(18,6),
	gapAmt decimal(18,6),
	gapPercent decimal(18,6),
	statetype varchar(40)
)
As
Begin
	--xx年报价单价格
	declare @FstTmp Table(ItemID bigint,Price decimal(18,6))
	Insert Into @FstTmp(ItemID,Price)
	Select b.ItemID,Max(b.Price)
	From SMS_Quote a Inner Join SMS_QuoteDtl b ON a.BillNo=b.BillNo 
	Where (a.BillSts='20') And (a.CustID=@CustID) And YEAR(a.CreateDate)=@BJYear
	Group By b.ItemID

	--当前时间段内销售数据
	declare @SalesTmp Table(ItemID bigint,SQty decimal(18,6),Amt decimal(18,6),Price decimal(18,6))
	Insert Into @SalesTmp(ItemID,SQty,Amt)
	Select b.ItemID,SUM(b.SQty) As SQty,SUM(b.Amt) As Amt
	From SMS_Stock a Inner Join SMS_StockDtl b ON a.StockNo=b.StockNo 
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		And (a.CustID=@CustID) And (a.CreateDate Between @StartDate And @EndDate)
	Group By b.ItemID
	Update @SalesTmp Set Price=Round(ISNULL(Amt,0.0)/ISNULL(SQty,0.0),4)
	Where ISNULL(SQty,0.0)<>0.0

	insert into @uTable(ItemID,ItemNo,ItemName,ItemSpec,ColorName,UnitName,SQty,Amt,Price,YPrice,YAmt,gapAmt,statetype,gapPercent)
	Select a.ItemID,g.ItemNo,g.ItemName,g.ItemSpec,g.ColorName,g.UnitName,
		a.SQty,a.Amt,a.Price,ISNULL(b.Price,a.Price) As YPrice,
		Round(ISNULL(b.Price,a.Price)*Isnull(a.SQty,0.0),2) As YAmt,
		Round(ISNULL(b.Price,a.Price)*Isnull(a.SQty,0.0),2) - ISNULL(a.Amt,0.0) As gapAmt,
		Case ISNULL(b.ItemID,0) When 0 Then '0' Else '1' End As statetype,
		ISNULL(a.Amt,0.0)*17/100 AS gapPercent   
	From @SalesTmp a Inner Join BDM_ItemInfo g On a.ItemID=g.ItemID 
		Left Outer Join @FstTmp b On a.ItemID=b.ItemID
	return
end 

go

