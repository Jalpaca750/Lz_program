--销售出库单细删除操作（BillSts='20'审核/BillSts='10'取消审核)
--2005-01-22
--Devil.H
--当上述操作发生时：
--当前订单已出库数量减少
CREATE Trigger Trig_SMS_GatheringDtl_Del
On dbo.SMS_GatheringDtl
--with encryption
For Delete
As
Begin
	Update SMS_Shift Set BillSts='未交款'
	Where ShiftNo In(Select ShiftNo From Deleted)
End
go

