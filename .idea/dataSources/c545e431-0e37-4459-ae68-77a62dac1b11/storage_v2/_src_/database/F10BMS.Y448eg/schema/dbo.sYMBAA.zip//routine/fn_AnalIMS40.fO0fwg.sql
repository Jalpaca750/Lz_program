--说明：库存商品ABC分析
--作者：Devil.H
--创建：2007.11.12
--参数：
CREATE Function dbo.fn_AnalIMS40
(
	@WareHouse varchar(20),
	@ARate decimal(18,6),
	@BRate decimal(18,6),
	@Flag bit
)
Returns @uTable Table(
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemAlias varchar(200),
	NameSpell varchar(200),
	ItemSpec varchar(100),
	BarCode varchar(100),
	ClassID varchar(20),
	ClassName varchar(100),
	LabelID varchar(20),
	LabelName varchar(100),
	ColorName varchar(40),
	UnitName varchar(20),
	PkgSpec varchar(40),
	PkgQty decimal(18,6),
	Price decimal(18,6),
	OnHandQty decimal(18,6),
	Amt decimal(18,6),
	IMSPercent decimal(18,6),
	ABCFlag char(1)
)
As
Begin
	declare @Period varchar(6)
	declare @TotalAmt decimal(18,6)
	declare @i bigint
	declare @Amt decimal(18,6)
	declare @SumAmt decimal(18,6)
	declare @ItemID bigint
	Declare @CostTmp Table
	(
		DeptNo varchar(20),
		ItemID bigint,
		Price decimal(18,10)
		Primary Key(DeptNo,ItemID)
	)
	if @Flag=0 
		Return
	--会计期间
	Select @Period=CW_Period 
	From SYS_CW_MonthPeriod a
	Where Exists(Select 1 From SYS_GetDate_V b Where  b.Today Between a.StartDate And a.EndDate)
	--临时成本
	Insert Into @CostTmp(DeptNo,ItemID,Price)
	Select Isnull(DeptNo,'$$$$'),ItemID,MEPrice
	From uf_CostPrice(@Period) 
	--总体成本法
	if Exists(Select 1 From SYS_Config Where Method='T')
		Insert Into @uTable(ItemID,OnHandQty,ItemNo,ItemName,ItemAlias,NameSpell,
			ColorName,ItemSpec,BarCode,ClassID,ClassName,LabelID,LabelName,
			UnitName,Price,Amt,PkgSpec,PkgQty)
		Select a.ItemID,a.OnHandQty,b.ItemNo,b.ItemName,b.ItemAlias,b.NameSpell,
			b.ColorName,b.ItemSpec,b.BarCode,b.ClassID,b.ClassName,b.LabelID,
			b.LabelName,b.UnitName,c.Price,
			Isnull(a.OnHandQty,0.0)*Isnull(c.Price,0.0) As Amt,b.PkgSpec,
			Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.OnHandQty,0.0)/b.PkgRatio,4) End
		From IMS_Ledger a Inner Join BAS_Goods_V b On a.ItemID=b.ItemID
				  Left Outer Join @CostTmp c On a.ItemID=c.ItemID
		Where Abs(Isnull(a.OnHandQty,0.0))>0.0 And a.WareHouse=@WareHouse
		Order By Amt Desc
	Else
		Insert Into @uTable(ItemID,OnHandQty,ItemNo,ItemName,ItemAlias,NameSpell,
			ColorName,ItemSpec,BarCode,ClassID,ClassName,LabelID,LabelName,
			UnitName,Price,Amt,PkgSpec,PkgQty)
		Select a.ItemID,a.OnHandQty,b.ItemNo,b.ItemName,b.ItemAlias,b.NameSpell,
			b.ColorName,b.ItemSpec,b.BarCode,b.ClassID,b.ClassName,b.LabelID,
			b.LabelName,b.UnitName,c.Price,
			Isnull(a.OnHandQty,0.0)*Isnull(c.Price,0.0) As Amt,b.PkgSpec,
			Case Isnull(b.PkgRatio,0.0) When 0.0 Then Null Else Round(Isnull(a.OnHandQty,0.0)/b.PkgRatio,4) End
		From IMS_Ledger a Inner Join BAS_Goods_V b On a.ItemID=b.ItemID
				  Left Outer Join @CostTmp c On a.ItemID=c.ItemID And a.DeptNo=c.DeptNo
		Where Abs(Isnull(a.OnHandQty,0.0))>0.0 And a.WareHouse=@WareHouse
		Order By Amt Desc
		
	--获取商品总金额
	Select @TotalAmt=Sum(Amt) From @uTable 
	if Isnull(@TotalAmt,0)=0 
		Return
	--更新商品
	Update @uTable Set IMSPercent=Case Isnull(@TotalAmt,0.0) When 0.0 Then 0.0
								 Else Round(Isnull(Amt,0.0)/Isnull(@TotalAmt,0.0),6) End
	--初始化
	Set @SumAmt=0.0
	Declare mycursor cursor
	For Select Amt,ItemID From @uTable Order By Amt Desc
	Open mycursor
	fetch next from mycursor into @Amt,@ItemID
	While @@FETCH_STATUS = 0
	Begin
		Set @SumAmt=@SumAmt+Isnull(@Amt,0.0)
		if @SumAmt/@TotalAmt>0 And @SumAmt/@TotalAmt*100-@ARate<=0.0
			Update @uTable Set ABCFlag='A' Where ItemID=@ItemID
		if @SumAmt/@TotalAmt*100-@ARate>0 And @SumAmt/@TotalAmt*100-@ARate-@BRate<=0.0
			Update @uTable Set ABCFlag='B' Where ItemID=@ItemID
		fetch next from mycursor into @Amt,@ItemID
	End
	Close mycursor
	Deallocate mycursor
	Update @uTable Set ABCFlag='C' Where ABCFlag Is Null
	Return
End
go

