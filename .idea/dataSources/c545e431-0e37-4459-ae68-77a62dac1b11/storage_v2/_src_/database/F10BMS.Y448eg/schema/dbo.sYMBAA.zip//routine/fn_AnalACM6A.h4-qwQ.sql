
--说明：供应商预付款明细
--作者：Devil.H
--创建：2007.11.15
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag：标志
CREATE Function dbo.fn_AnalACM6A
(
	@StartDate char(10)='2000-01-01',
	@EndDate char(10)='2000-01-01',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	BillType varchar(20),
	BillNo varchar(20),
	CreateDate varchar(10),
	Credence varchar(40),
	VendorID bigint,
	VendorNo varchar(20),
	VendorName varchar(200),
	NameSpell varchar(200),
	BuyerID bigint,
	Buyer varchar(100),
	AdvAmt decimal(18,6),
	OffAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40)
)
As
Begin	
	if @Flag=0
		Return
	--初始化变量
	Set @StartDate=Convert(Char(10),Cast(@StartDate as datetime),120)
	Set @EndDate=Convert(Char(10),Cast(@EndDate as datetime),120)
	
	Insert Into @uTable(BillType,BillNo,CreateDate,Credence,VendorID,AdvAmt,BuyerID,Buyer)
	Select '预付款单',a.AdvancesNo,a.CreateDate,a.Credence,b.VendorID,b.AdvAmt,a.CreatorID,e.EmployeeName
	From PMS_Advances a 
        Inner join PMS_AdvancesDtl b On a.AdvancesNo=b.AdvancesNo
        Left Join BDM_Employee e ON a.CreatorId=e.EmployeeId
	Where (a.BillSts='20')
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Insert Into @uTable(BillType,BillNo,CreateDate,Credence,VendorID,OffAmt,BuyerID,Buyer)
	Select '应付款单',PaymentNo,CreateDate,Credence,VendorID,AdvAmt,a.CreatorID,e.EmployeeName
	From PMS_Payment a
        Left Join BDM_Employee e ON a.CreatorId=e.EmployeeId
	Where (BillSts='20') And Isnull(AdvFlag,0)=1
		And (Convert(char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%'))
	--更新客户资料
	Update a Set a.VendorNo=b.VendorNo,a.VendorName=b.VendorName,a.NameSpell=b.NameSpell,
		a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes
	From @uTable a,BDM_Vendor_V b
	Where a.VendorID=b.VendorID
	Return
End
go

