CREATE VIEW [dbo].[IMS_Other_V]
AS
SELECT a.OtherNo, a.CreateDate, a.DeptNo, b.CHName AS DeptName, a.Warehouse, 
    c.CHName AS WHName,  CASE a.BillType WHEN '10' THEN '其他入库单' 
                                         WHEN '20' THEN '其他出库单' 
                                         WHEN '30' THEN '报损出库单' 
                                         WHEN '60' THEN '库存初始化' END AS BillType, 
    '客户' AS IOObject, a.CustID AS ObjectID, d.CustNo AS ObjectNo, d.CustName AS ObjectName, 
    a.SendAddr,a.Phone,a.LinkMan,a.SendDate,a.SendTime,a.LineId,l.CHName AS lineName,a.WmsOrder,
    a.WmsBillNo,h.Amt, a.BillSts, g.StsName, a.PFlag, a.AuditDate,a.AuditID, e.EmployeeName AS Auditer, 
    a.CreatorID, f.EmployeeName AS Creator, a.PrintNum, a.PrinterID, p.EmployeeName AS Printer, 
    a.DepartId,dt.CHName AS DepartName,a.SyncFlag,a.EditTime,a.Remarks, a.CheckBox
FROM dbo.IMS_Other a 
    LEFT JOIN dbo.BillStatus g ON a.BillSts = g.BillSts 
    LEFT JOIN dbo.BDM_Employee f ON a.CreatorID = f.EmployeeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID 
    LEFT JOIN dbo.BDM_Employee e ON a.AuditID = e.EmployeeID 
    LEFT JOIN dbo.BDM_Customer d ON a.CustID = d.CustID 
    LEFT JOIN dbo.BDM_WareHouse_V c ON a.Warehouse = c.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID 
    LEFT JOIN (SELECT OtherNo, SUM(Amt) AS Amt
               FROM IMS_OtherDtl
               GROUP BY OtherNo) h ON a.OtherNo = h.OtherNo 
    LEFT JOIN dbo.BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
    LEFT JOIN dbo.BDM_Code l ON a.lineId=l.codeId
WHERE (a.IOObject = '10') AND (g.BillType = 'IMS90')
UNION ALL
SELECT a.OtherNo, a.CreateDate, a.DeptNo, b.CHName AS DeptName, a.Warehouse, 
    c.CHName AS WHName, CASE a.BillType WHEN '10' THEN '其他入库单' 
    		                            WHEN '20' THEN '其他出库单' 
    		                            WHEN '30' THEN '报损出库单' 
                                        WHEN '60' THEN '库存初始化' END AS BillType, 
    '供应商' AS IOObject, a.VendorID, d.VendorNo AS ObjectNo,d.VendorName AS ObjectName, 
    a.SendAddr,a.Phone,a.LinkMan,a.SendDate,a.SendTime,a.LineId,l.CHName AS lineName,a.WmsOrder,
    a.WmsBillNo,h.Amt, a.BillSts, g.StsName, a.PFlag, a.AuditDate,a.AuditID, e.EmployeeName AS Auditer, 
    a.CreatorID, f.EmployeeName AS Creator,a.PrintNum, a.PrinterID, p.EmployeeName AS Printer,
    a.DepartId,dt.CHName AS DepartName,a.SyncFlag,a.EditTime,a.Remarks, a.CheckBox
FROM dbo.IMS_Other a 
    LEFT JOIN dbo.BillStatus g ON a.BillSts = g.BillSts 
    LEFT JOIN dbo.BDM_Employee f ON a.CreatorID = f.EmployeeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID 
    LEFT JOIN dbo.BDM_Employee e ON a.AuditID = e.EmployeeID 
    LEFT JOIN dbo.BDM_Vendor d ON a.VendorID = d.VendorID 
    LEFT JOIN dbo.BDM_WareHouse_V c ON a.Warehouse = c.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID 
    LEFT JOIN (SELECT OtherNo, SUM(Amt) AS Amt
               FROM IMS_OtherDtl
               GROUP BY OtherNo) h ON a.OtherNo = h.OtherNo  
    LEFT JOIN dbo.BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
    LEFT JOIN dbo.BDM_Code l ON a.lineId=l.codeId
WHERE (a.IOObject = '20') AND (g.BillType = 'IMS90')
UNION ALL
SELECT a.OtherNo, a.CreateDate, a.DeptNo, b.CHName AS DeptName, a.Warehouse, 
    c.CHName AS WHName, CASE a.BillType WHEN '10' THEN '其他入库单'
                                        WHEN '20' THEN '其他出库单' 
    			                        WHEN '30' THEN '报损出库单' 
    		                            WHEN '60' THEN '库存初始化' END AS BillType, 
    '内部员工' AS IOObject, a.EmployeeID, d.EmployeeNo AS ObjectNo,d.EmployeeName AS ObjectName, 
    a.SendAddr,a.Phone,a.LinkMan,a.SendDate,a.SendTime,a.LineId,l.CHName AS lineName,a.WmsOrder,
    a.WmsBillNo,h.Amt,a.BillSts, g.StsName, a.PFlag, a.AuditDate,a.AuditID, e.EmployeeName AS Auditer, 
    a.CreatorID, f.EmployeeName AS Creator, a.PrintNum, a.PrinterID, p.EmployeeName AS Printer,
    a.DepartId,dt.CHName AS DepartName,a.SyncFlag,a.EditTime,a.Remarks, a.CheckBox
FROM dbo.IMS_Other a 
    LEFT JOIN dbo.BillStatus g ON a.BillSts = g.BillSts 
    LEFT JOIN dbo.BDM_Employee f ON a.CreatorID = f.EmployeeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID 
    LEFT JOIN dbo.BDM_Employee e ON a.AuditID = e.EmployeeID 
    LEFT JOIN dbo.BDM_Employee d ON a.EmployeeID = d.EmployeeID 
    LEFT JOIN dbo.BDM_WareHouse_V c ON a.Warehouse = c.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID 
    LEFT JOIN (SELECT OtherNo, SUM(Amt) AS Amt
               FROM IMS_OtherDtl
               GROUP BY OtherNo) h ON a.OtherNo = h.OtherNo  
    LEFT JOIN dbo.BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
    LEFT JOIN dbo.BDM_Code l ON a.lineId=l.codeId
WHERE (a.IOObject = '30')  AND (g.BillType = 'IMS90')
UNION ALL
SELECT a.OtherNo, a.CreateDate, a.DeptNo, b.CHName AS DeptName, a.Warehouse, 
    c.CHName AS WHName, CASE a.BillType WHEN '10' THEN '其他入库单' 
                                        WHEN '20' THEN '其他出库单' 
                                        WHEN '30' THEN '报损出库单' 
                                        WHEN '60' THEN '库存初始化' END AS BillType, 
    '部门' AS IOObject, d.CodeID AS ObjectID, d.CodeNo AS ObjectNo, d.CHName AS ObjectName, 
    a.SendAddr,a.Phone,a.LinkMan,a.SendDate,a.SendTime,a.LineId,l.CHName AS lineName,a.WmsOrder,
    a.WmsBillNo,h.Amt,a.BillSts, g.StsName, a.PFlag, a.AuditDate, a.AuditID, e.EmployeeName AS Auditer, 
    a.CreatorID, f.EmployeeName AS Creator, a.PrintNum, a.PrinterID, p.EmployeeName AS Printer,
    a.DepartId,dt.CHName AS DepartName,a.SyncFlag,a.EditTime,a.Remarks, a.CheckBox
FROM dbo.IMS_Other a 
    LEFT JOIN dbo.BillStatus g ON a.BillSts = g.BillSts     
    LEFT JOIN dbo.BDM_Employee f ON a.CreatorID = f.EmployeeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID 
    LEFT JOIN dbo.BDM_Employee e ON a.AuditID = e.EmployeeID 
    LEFT JOIN dbo.BDM_WareHouse_V c ON a.Warehouse = c.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V d On a.DepartNo=d.CodeID 
    LEFT JOIN (SELECT OtherNo,SUM(Amt) AS Amt
               FROM IMS_OtherDtl
               GROUP BY OtherNo) h ON a.OtherNo = h.OtherNo  
    LEFT JOIN dbo.BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
    LEFT JOIN dbo.BDM_Code l ON a.lineId=l.codeId
WHERE (a.IOObject = '35') AND (g.BillType = 'IMS90')
UNION ALL
SELECT a.OtherNo, a.CreateDate, a.DeptNo, b.CHName AS DeptName, a.Warehouse, 
    c.CHName AS WHName, CASE a.BillType WHEN '10' THEN '其他入库单' 
    			                        WHEN '20' THEN '其他出库单' 
    			                        WHEN '30' THEN '报损出库单' 
    			                        WHEN '60' THEN '库存初始化' END AS BillType, 
    '其他' AS IOObject, NULL AS ObjectID, NULL AS ObjectNo, NULL AS ObjectName,
    a.SendAddr,a.Phone,a.LinkMan,a.SendDate,a.SendTime,a.LineId,l.CHName AS lineName,a.WmsOrder,
    a.WmsBillNo,h.Amt, a.BillSts, g.StsName, a.PFlag, a.AuditDate, a.AuditID, e.EmployeeName AS Auditer, 
    a.CreatorID, f.EmployeeName AS Creator, a.PrintNum, a.PrinterID, p.EmployeeName AS Printer,
    a.DepartId,dt.CHName AS DepartName,a.SyncFlag,a.EditTime,a.Remarks, a.CheckBox
FROM dbo.IMS_Other a 
    LEFT JOIN dbo.BillStatus g ON a.BillSts = g.BillSts 
    LEFT JOIN dbo.BDM_Employee f ON a.CreatorID = f.EmployeeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID 
    LEFT JOIN dbo.BDM_Employee e ON a.AuditID = e.EmployeeID 
    LEFT JOIN dbo.BDM_WareHouse_V c ON a.Warehouse = c.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID 
    LEFT JOIN (SELECT OtherNo, SUM(Amt) AS Amt
               FROM IMS_OtherDtl
               GROUP BY OtherNo) h ON a.OtherNo = h.OtherNo 
    LEFT JOIN dbo.BDM_DeptCode_V dt ON a.DepartId=dt.CodeID
    LEFT JOIN dbo.BDM_Code l ON a.lineId=l.codeId
WHERE (a.IOObject = '40' Or Isnull(a.IOObject,'')='') AND (g.BillType = 'IMS90')
go

