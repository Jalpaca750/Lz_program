CREATE FUNCTION fn_AnalIMS101
(
	@ItemID bigint
)
RETURNS TABLE
AS
RETURN (
	SELECT a.DeptNo, b.CHName AS DeptName, a.ItemID, c.ItemNo, c.ItemName, c.ItemAlias, 
	      	c.NameSpell, c.ItemSpec, c.BarCode, c.ClassID, c.ClassName, c.LabelID, 
	      	c.LabelName, c.ColorName, c.UnitName, a.OnHandQty, 
		ISNULL(a.OnHandQty, 0.0) - ISNULL(d.AllocQty, 0.0) AS AvailQty,
	      	(SELECT SUM(QTY)
	         FROM dbo.IMS_YZStock Y Inner Join dbo.BDM_WareHouse_V x On y.WareHouseID=x.CodeID
	         WHERE a.DeptNo = x.DeptNo AND a.ItemID = Y.ItemID) AS YZStockQty,
	      	CASE Isnull(c.PkgRatio, 0.0) WHEN 0.0 THEN NULL 
		                           ELSE Round(Isnull(a.OnHandQty,0.0) / Isnull(c.PkgRatio, 0.0), 4) END AS PkgQty, 
		c.PkgSpec,a.MaxStock,a.MinStock,OnWayQty,
		CASE Isnull(c.PkgRatio, 0.0) WHEN 0.0 THEN NULL 
		                           ELSE Round(Isnull(a.MaxStock,0.0) / Isnull(c.PkgRatio, 0.0), 4) END AS MaxPkg,
		CASE Isnull(c.PkgRatio, 0.0) WHEN 0.0 THEN NULL 
		                           ELSE Round(Isnull(a.MinStock,0.0) / Isnull(c.PkgRatio, 0.0), 4) END AS MinPkg
	FROM dbo.IMS_Subdepot a INNER JOIN
	      dbo.BAS_Goods_V c ON a.ItemID = c.ItemID INNER JOIN
	      dbo.BDM_DeptCode_V b ON a.DeptNo = b.CodeID LEFT OUTER JOIN 
	      dbo.IMS_Allocate_V d On a.DeptNo=d.DeptNo And a.ItemID=d.ItemID LEFT OUTER JOIN
	      dbo.IMS_OnWay_V e On a.DeptNo=e.DeptNo And a.ItemID=e.ItemID
	Where a.ItemID=@ItemID
)
go

