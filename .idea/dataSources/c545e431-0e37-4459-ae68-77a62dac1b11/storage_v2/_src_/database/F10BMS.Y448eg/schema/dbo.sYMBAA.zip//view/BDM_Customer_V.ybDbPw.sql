CREATE  VIEW dbo.BDM_Customer_V
AS
SELECT a.CustID, a.CustNo, a.CustName, a.NameSpell, a.CustAddr, a.SendAddr, a.PostalCode, a.CustType, 
    e.CHName AS TypeName, a.MemberID, j.CHName AS Member, a.AreaCode, f.CHName AS AreaName, a.PopedomID, 
    i.CHName AS PopedomName, a.SalesID, b.EmployeeName AS Sales, a.DeptNo, g.CHName AS DeptName, a.Phone, 
    a.Faxes, a.EMail, a.Webs, a.WebName, a.WebPassword, a.ShowQty, a.IsContract, a.TradeID, l.CHName AS TradeName, 
    a.KindID, k.CHName AS KindName, a.LegalPerson, a.AccountNo, a.TaxNo, a.ADays, a.ADayFlag, a.IDays, 
    a.CreditAmt, a.CreditFlag, a.Invoice, a.Finance, a.FPhone, a.AdvAmt, a.ArgAmt,a.Penalty, a.SendID, m.CHName AS SendMode, 
    a.SendFlag, a.PriceFlag, a.DiscRate, a.Integral AS SumInteg, a.SJInteg, a.ReportTitle,a.ReportCode,a.PlatformFee,
    a.rebate, ISNULL(a.Integral, 0) - ISNULL(a.SJInteg, 0) AS WJInteg, a.Deduct, 
    CAST(ISNULL(a.SJInteg, 0) - ISNULL(a.Deduct, 0) - ISNULL(a.qlInteg, 0) AS bigint) AS Integral, a.LinkMan, 
    a.OutValue, a.SalesAmt, a.Persons, a.CurrencyID, a.DeptName AS DName, a.JobName, a.PerPhone,a.ServiceID,
    sv.EmployeeName AS ServiceName, CASE a.Sex WHEN '1' THEN '男' WHEN '0' THEN '女' END AS Sex, 
    CASE a.Ages WHEN '10' THEN '20-29' WHEN '20' THEN '30-39' WHEN '30' THEN '40-49' WHEN '40' THEN '50-59' END AS Ages, 
    a.Defined1, a.Defined2, a.Defined3, CASE isnull(a.Flag, '1') WHEN '1' THEN '有效' ELSE '失效' END AS Flag, a.CreatorID, 
    c.EmployeeName AS Creator, a.CreateDate, a.MenderID,a.ParentID, d.EmployeeName AS Mender, a.AmendDate, a.Remarks, 
    a.CheckBox, a.IsIntegral, a.qlInteg, a.zj_qlInteg, a.zj_ql_Date, q.EmployeeName AS zj_ql_Creator, a.Integralbk, 
    ISNULL(cc.ADays, 0) AS cc_ADays, ISNULL(cc.Amt, 0) AS cc_Amt,a.LockPrice,a.PDays,a.logisticsId,lg.logisticsCode,
    lg.logisticsName
FROM dbo.BDM_Customer a  
    LEFT JOIN dbo.BDM_SendMode_V m ON a.SendID=m.CodeID 
    LEFT JOIN dbo.BDM_PopedomCode_V i ON a.PopedomID=i.CodeID
    LEFT JOIN dbo.BDM_EKind_V k ON a.KindID = k.CodeID 
    LEFT JOIN dbo.BDM_TradeCode_V l ON a.TradeID = l.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V g ON a.DeptNo = g.CodeID 
    LEFT JOIN dbo.BDM_MemberCode_V j ON a.MemberID = j.CodeID 
    LEFT JOIN dbo.BDM_Employee d ON a.MenderID = d.EmployeeID 
    LEFT JOIN dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID 
    LEFT JOIN dbo.BDM_Employee b ON a.SalesID = b.EmployeeID 
    LEFT JOIN dbo.BDM_Employee sv ON a.ServiceID=sv.EmployeeID 
    LEFT JOIN dbo.BDM_Employee q ON a.zj_ql_CreatorID = q.EmployeeID 
    LEFT JOIN dbo.BDM_CustType_V e ON a.CustType = e.CodeID 
    LEFT JOIN dbo.BDM_AreaCode_V f ON a.AreaCode = f.CodeID 
    LEFT JOIN dbo.BAS_Logistics lg ON a.logisticsId=lg.logisticsId
    LEFT JOIN dbo.uf_BDM_CustCredit('') cc ON a.CustID = cc.CustID
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1[50] 2[25] 3) )"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1 [56] 4 [18] 2))"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "i"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 109
               Right = 172
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "m"
            Begin Extent = 
               Top = 6
               Left = 210
               Bottom = 109
               Right = 344
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "a"
            Begin Extent = 
               Top = 114
               Left = 38
               Bottom = 217
               Right = 208
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "k"
            Begin Extent = 
               Top = 114
               Left = 246
               Bottom = 217
               Right = 380
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "l"
            Begin Extent = 
               Top = 222
               Left = 38
               Bottom = 325
               Right = 172
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "g"
            Begin Extent = 
               Top = 222
               Left = 210
               Bottom = 325
               Right = 350
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "j"
            Begin Extent = 
               Top = 330
               Left = 38
               Bottom = 433
               Right = 172
            End
            DisplayFlags = 280
            TopColumn = 0
         End
 ', 'SCHEMA', 'dbo', 'VIEW', 'BDM_Customer_V'
go

exec sp_addextendedproperty 'MS_DiagramPane2', N'        Begin Table = "d"
            Begin Extent = 
               Top = 330
               Left = 210
               Bottom = 433
               Right = 362
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "c"
            Begin Extent = 
               Top = 438
               Left = 38
               Bottom = 541
               Right = 190
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "b"
            Begin Extent = 
               Top = 438
               Left = 228
               Bottom = 541
               Right = 380
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "q"
            Begin Extent = 
               Top = 546
               Left = 38
               Bottom = 649
               Right = 190
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "e"
            Begin Extent = 
               Top = 546
               Left = 228
               Bottom = 649
               Right = 362
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "f"
            Begin Extent = 
               Top = 654
               Left = 38
               Bottom = 757
               Right = 172
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "cc"
            Begin Extent = 
               Top = 654
               Left = 210
               Bottom = 743
               Right = 344
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      RowHeights = 240
      Begin ColumnWidths = 85
         Width = 284
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Wi', 'SCHEMA', 'dbo', 'VIEW', 'BDM_Customer_V'
go

exec sp_addextendedproperty 'MS_DiagramPane3', N'dth = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
         Width = 1440
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'BDM_Customer_V'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 3, 'SCHEMA', 'dbo', 'VIEW', 'BDM_Customer_V'
go

