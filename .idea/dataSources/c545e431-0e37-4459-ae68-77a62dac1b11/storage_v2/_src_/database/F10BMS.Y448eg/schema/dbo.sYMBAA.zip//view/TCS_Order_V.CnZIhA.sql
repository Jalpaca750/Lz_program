
create view TCS_Order_V as
/*
--平台业务
SELECT a.orderNo,a.billNo AS orderBillNo,a.billNo AS boneOrderBillNo,b.packageId AS boneOrderPkgId,
    b.billNo AS boneOrderPkgBillNo,a.companyId AS corpId,o.DeptNo AS orgId,o.DeptNo AS orgNo,d.CHName AS orgName,a.poNo,
    a.oCustomerId AS customerId,c.partnerNo AS customerNo,c.partnerName AS customerName,a.receiverAddress,
    a.receiverName,ISNULL(a.receiverMobile,'')+ISNULL(a.receiverTel,'') AS fullPhone,a.invoiceFlag,
    (CASE t.invoiceLine WHEN '' THEN '不开票' WHEN 'c' THEN '普票(纸)' WHEN 's' THEN '专票(纸)' WHEN 'p' THEN '普票(电)' WHEN 'b' THEN '专票(电)' END) AS invoiceType,
    CASE t.invoiceType WHEN 1 THEN '蓝字' ELSE '红字' END AS redFlag,
    a.invoiceCompany,a.invoiceTax,a.invoiceAddress,a.invoiceTel,a.invoiceAccount,a.invoiceBank,a.totalFee,v.partnerNo AS vendorNo,
    v.partnerName AS vendorName,CASE ISNULL(v.partnerId,'') WHEN '' THEN '我方' ELSE '服务商' END AS deliverFlag,
    o.billSts AS orderState,(SELECT StsName FROM dbo.BillStatus WHERE BillType='SMS30' AND BillSts=o.BillSts) AS stateDesc,
    t.invoiceLine,t.invoiceState,
    CASE ISNULL(t.invoiceState,'10') WHEN '10' THEN '待开票' WHEN '20' THEN '开票中' WHEN '30' THEN '已开票' WHEN '-1' THEN '作废中' ELSE '已作废' END AS invoiceStateDesc,
    CONVERT(VARCHAR(10),a.orderDate,23) AS orderDate,CONVERT(VARCHAR(20),t.createTime,120) AS createTime,o.Remarks AS memo,
    i.pdfUrl,i.pictureUrl,i.invoiceCode,t.invoiceNo,i.invoiceNo AS invoiceNum,i.checkCode,i.qrCode,i.cipherText,
    i.paperPdfUrl,t.invoiceSerialNum,t.reason,t.orderNo AS applyNo,t.buyerAccount,t.buyerAddress,t.buyerName,t.buyerPhone,t.buyerTaxNum,t.buyerTel,
    t.salerAccount,t.salerAddress,t.salerTaxNum,t.salerTel
FROM Bone.dbo.ECM_Order a
    INNER JOIN Bone.dbo.ECM_OrderEx b ON a.orderNo=b.orderNo
    INNER JOIN Bone.dbo.TP_Platform p ON a.orderSource=p.platformId
    INNER JOIN Bone.dbo.BAS_Partner c ON a.oCustomerId=c.partnerId
    INNER JOIN dbo.SMS_Order o ON a.billNo=o.OrderNo
    INNER JOIN dbo.BDM_DeptCode_V d ON o.DeptNo=d.CodeID
    LEFT JOIN Bone.dbo.BAS_Partner v ON c.refSupplierId=v.partnerId
    INNER JOIN dbo.TCS_Order t ON a.orderNo=t.boneOrderNo
    LEFT JOIN dbo.TCS_Invoice i ON t.invoiceSerialNum=i.serialNo
WHERE t.invoiceState IN('-1','00','20','30','10','3','2')
UNION ALL
*/
--标准业务
SELECT a.StockNo AS orderNo,a.StockNo AS orderBillNo,a.StockNo AS boneOrderBillNo,a.StockNo AS boneOrderPkgId,
    a.StockNo AS boneOrderPkgBillNo,d.corpId,d.CodeID AS orgId,d.CodeNo AS orgNo,d.CHName AS orgName,a.poNo,
    CAST(a.CustID AS VARCHAR(32)) AS customerId,c.CustNo AS customerNo,c.CustName AS customerName,
    a.SendAddr AS receiverAddress,a.LinkMan AS receiverName,a.Phone AS fullPhone,
    ex.invoiceFlag,(CASE invoiceflag WHEN 0 THEN '不开票' WHEN 1 THEN '普票(纸)' WHEN 2 THEN '专票(纸)' WHEN 3 THEN '普票(电)' WHEN 4 THEN '专票(电)' END) AS invoiceType,
    CASE t.invoiceType WHEN 1 THEN '蓝字' ELSE '红字' END AS redFlag,
    ex.invoiceCompany,ex.invoiceTax,ex.invoiceAddress,ex.invoiceTel,ex.invoiceAccount,ex.invoiceBank,
    t.totalFee,'' AS vendorNo,'' AS vendorName,'我方' AS deliverFlag,
    a.billSts AS orderState,(SELECT StsName FROM dbo.BillStatus WHERE BillType='SMS40' AND BillSts=a.BillSts) AS stateDesc,
    t.invoiceLine,t.invoiceState,
    CASE ISNULL(t.invoiceState,'10') WHEN '10' THEN '待开票' WHEN '20' THEN '开票中' WHEN '30' THEN '已开票' WHEN '-1' THEN '作废中' ELSE '已作废' END AS invoiceStateDesc,
    a.CreateDate AS orderDate,CONVERT(VARCHAR(20),t.createTime,120) AS createTime,a.Remarks AS memo,
    i.pdfUrl,i.pictureUrl,i.invoiceCode,t.invoiceNo,i.invoiceNo AS invoiceNum,i.checkCode,i.qrCode,i.cipherText,
    i.paperPdfUrl,t.invoiceSerialNum,t.reason,t.orderNo AS applyNo,t.buyerAccount,t.buyerAddress,t.buyerName,t.buyerPhone,t.buyerTaxNum,t.buyerTel,
    t.salerAccount,t.salerAddress,t.salerTaxNum,t.salerTel
FROM SMS_Stock a
    INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
    INNER JOIN BDM_Customer c ON a.CustID=c.CustID
    INNER JOIN SMS_StockEx ex ON a.StockNo=ex.stockNo
    INNER JOIN BDM_DeptCode_V d ON a.DeptNo =d.CodeID
    INNER JOIN TCS_Order t ON a.StockNo=t.boneOrderNo
    LEFT JOIN dbo.TCS_Invoice i ON t.invoiceSerialNum=i.serialNo
WHERE t.invoiceState IN('-1','00','20','30','10','3','2')
go

