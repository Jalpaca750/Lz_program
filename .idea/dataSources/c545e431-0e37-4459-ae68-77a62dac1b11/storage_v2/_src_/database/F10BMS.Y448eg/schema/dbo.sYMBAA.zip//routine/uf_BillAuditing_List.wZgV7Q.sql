
--说明：列出此用户需要审批的单据
--作者：wujinfeng
--创建：2008.10.25
--参数：
--	@Auditing_EmployeeID 审批用户
CREATE Function uf_BillAuditing_List
(
	@Auditing_EmployeeID as bigint
)
Returns @uTable Table
(
	SID 		bigint,
	TblCode	varchar(100),
	Auditing_type	varchar(1),
	BillNo		varchar(20),
	BillName	varchar(20),
	EmployeeID 	bigint,
	EmployeeName 	varchar(100),
	Auditing_dj 	numeric(9),
	Auditing_EmployeeID 	bigint,
	Auditing_EmployeeName 	varchar(100),
	Auditing_Status 		bigint,
	Auditing_Remarks	varchar(200),
	CreateDate	datetime
)
As
Begin	
	declare @i bigint
	Insert Into @uTable(SID,  TblCode,   Auditing_type,   BillNo,   BillName,    EmployeeID,    EmployeeName,  Auditing_dj,Auditing_EmployeeID,      Auditing_EmployeeName,Auditing_Status,   Auditing_Remarks,CreateDate)
		SELECT  a.SID,a.TblCode,a.Auditing_type,a.BillNo,d.TblName,a.EmployeeID,c.EmployeeName,a.Auditing_dj,a.Auditing_EmployeeID,h.EmployeeName,           a.Auditing_Status,a.Auditing_Remarks,CreateDate
		
		FROM  BillAuditing a 
			LEFT OUTER JOIN   dbo.BDM_Employee c ON a.EmployeeID = c.EmployeeID
			LEFT OUTER JOIN   dbo.BDM_Employee h ON a.Auditing_EmployeeID = h.EmployeeID
			LEFT OUTER JOIN   dbo.Sys_AuditParm d ON a.TblCode = d.TblCode
		where BlankFlag='0' And Auditing_Status='0' And Auditing_EmployeeID=@Auditing_EmployeeID
		--and (not exists (select 1 from BillAuditing b where Auditing_dj<a.Auditing_dj     and Auditing_Status=0 and billNo=a.billNo) Or
		  and (not exists (select 1 from BillAuditing b where Auditing_dj<a.Auditing_dj     and Auditing_Status<>'1' and billNo=a.billNo) Or
        		                exists (select 1 from BillAuditing c where Auditing_dj=a.Auditing_dj-1    and Auditing_Status='1' and billNo=a.billNo and Auditing_type='2'))
		  and  not exists (select 1 from BillAuditing d where Auditing_dj=a.Auditing_dj+1   and Auditing_Status='1' and billNo=a.billNo)
        		  and  not  exists (select 1 from BillAuditing e where Auditing_dj=a.Auditing_dj    and Auditing_Status='1' and billNo=a.billNo and Auditing_type='2')
		--一人审批通过且已经有一人审批通过
	--返回
	return
end
go

