CREATE VIEW dbo.IMS_PresentDtl_V
AS
SELECT a.PresentID, a.PresentNo, d.CreateDate, d.BillSts, a.WareHouse, 
      ISNULL(f.Location, a.Location) AS Location, a.ItemID, b.ItemNo, b.ItemName, 
      b.ItemAlias, b.NameSpell, b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, 
      b.LabelID, b.LabelName, b.ColorName, b.UnitName, a.Integral, b.PkgSpec, a.PkgQty, 
      a.SQty, a.Price, a.Amt, a.CPrice, b.PPrice, b.SPrice, b.SPrice1, b.SPrice2, b.SPrice3, 
      b.BPackage, b.MPackage, b.Package, f.OnHandQty, b.PkgRatio, a.Remarks, 
      a.CheckBox, a.Integral AS DtlIntegral, b.ItemPHFlag, b.ItemPHName, d.CustID, 
      ISNULL(a.Integral, 0.0) * ISNULL(a.SQty, 0.0) AS SumIntegral, a.YZStockQty, 
      Y.QTY AS YZQty
FROM dbo.IMS_PresentDtl a LEFT OUTER JOIN
      dbo.BAS_Goods_V b ON a.ItemID = b.ItemID LEFT OUTER JOIN
      dbo.IMS_Present d ON a.PresentNo = d.PresentNo LEFT OUTER JOIN
      dbo.IMS_Ledger f ON a.WareHouse = f.WareHouse AND a.ItemID = f.ItemID LEFT OUTER JOIN
      dbo.IMS_YZStock_Sum_WareHouse_Sum_V Y ON a.ItemID = Y.ItemID AND  a.WareHouse = Y.WareHouseID
go

