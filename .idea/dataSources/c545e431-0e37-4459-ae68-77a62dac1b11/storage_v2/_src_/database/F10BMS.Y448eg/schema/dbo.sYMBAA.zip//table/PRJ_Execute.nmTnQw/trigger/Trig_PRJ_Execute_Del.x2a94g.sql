CREATE Trigger Trig_PRJ_Execute_Del
On dbo.PRJ_Execute
--with encryption
For Delete
As
Begin

	Update a Set a.ExecSts='未执行' From PRJ_Order a,Inserted b Where a.BillNo=b.OrderNo
End
go

