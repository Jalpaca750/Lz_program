

CREATE VIEW dbo.PMS_StockDtl_V
AS
SELECT a.StockID, a.StockNo, e.CreateDate, e.BillSts, e.BillType, e.VendorID, e.DeptNo, 
    a.OrderID, a.OrderNo, a.WareHouse, ISNULL(f.Location, a.Location) AS Location, 
    a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, b.ItemSpec, b.BarCode, 
    b.ClassID, b.ClassName, b.LabelID, b.LabelName, b.ColorName, b.UnitName, 
    ISNULL(c.OQty, 0.0) - ISNULL(c.SQty, 0.0) AS RemSQty, 
    a.PkgQty, a.SQty, a.Price, a.Amt, a.IsEffect, a.TaxFlag, a.IsSpecial, a.IQty, 
    ISNULL(a.SQty, 0.0) - ISNULL(a.IQty, 0.0) AS RemIQty, a.IAmt, 
    ISNULL(a.Amt, 0.0) - ISNULL(a.IAmt, 0.0) AS RemAmt, a.RQty, 
    ISNULL(a.SQty, 0.0) - ISNULL(a.RQty, 0.0) AS RemRQty, a.PAmt, 
    ISNULL(a.PAmt, 0.0) - ISNULL(a.PIAmt, 0.0) AS RemPAmt, a.PlanID, 
    a.PlanNo, a.XS_OrderNo, a.XS_OrderID, b.PPrice, b.SafePPrice, b.PkgRatio, b.PkgSpec, 
    b.BPackage, b.MPackage, b.Package, f.OnHandQty, f.AvailQty, b.HotFlag, b.NotDisc, 
    a.Remarks, a.CheckBox, b.ItemPHFlag, b.ItemPHName, a.XS_CustNo, a.XS_CustName,a.IsPromotion,
    b.Defined1,b.Defined2,b.Defined3,b.Defined4,b.Defined5,a.shelvesTime,a.shelvesFlag,
    e.Rebate,e.TaxRate,b.SPrice,b.SPrice1,b.SPrice2,b.SPrice3
FROM dbo.PMS_StockDtl a 
    LEFT JOIN dbo.PMS_Stock e ON a.StockNo = e.StockNo 
    LEFT JOIN dbo.BAS_Goods_V b ON a.ItemID = b.ItemID 
    LEFT JOIN dbo.IMS_Ledger f ON a.WareHouse = f.WareHouse AND a.ItemID = f.ItemID 
    LEFT JOIN dbo.PMS_OrderDtl c ON a.OrderID = c.OrderID
go

