CREATE VIEW dbo.SMS_BoxupDtl_Dtl_V
AS
SELECT a.BoxupDtl_DtlID, a.BoxupDtlID, a.BoxupNo, a.BoxNo, '' AS Location, a.StockID, 
      a.StockNo, a.ItemID, c.ItemNo, c.ItemName, c.ItemAlias, c.NameSpell, c.ItemSpec, 
      c.BarCode, c.ClassID, c.ClassName, c.LabelID, c.LabelName, c.ColorName, 
      c.UnitName, c.PkgSpec, a.Qty, a.Price, a.Amt, c.PPrice, c.SPrice, c.SPrice1, c.SPrice2, 
      c.Package, c.MPackage, c.BPackage, c.SPrice3, c.PkgRatio, c.Integral, a.Remarks, 
      ISNULL(b.SQty, 0.0) + ISNULL(b.ZQty, 0.0) - ISNULL(b.BoxQty, 0.0) AS RemBoxQty, 
      a.CheckBox, a.Qty AS MQty, a.Qty AS SqlQty, e.PartQty,a.BillType
FROM dbo.SMS_BoxupDtl_Dtl a LEFT OUTER JOIN
      dbo.SMS_BoxupDtl e ON a.BoxupDtlID = e.BoxupDtlID AND 
      a.BoxNo = e.BoxNo LEFT OUTER JOIN
      dbo.BDM_ItemInfo_V c ON a.ItemID = c.ItemID INNER JOIN
      dbo.SMS_StockDtl b ON a.StockID = b.StockID AND a.StockNo=b.StockNo
Union All
SELECT a.BoxupDtl_DtlID, a.BoxupDtlID, a.BoxupNo, a.BoxNo, '' AS Location, a.StockID, 
      a.StockNo, a.ItemID, c.ItemNo, c.ItemName, c.ItemAlias, c.NameSpell, c.ItemSpec, 
      c.BarCode, c.ClassID, c.ClassName, c.LabelID, c.LabelName, c.ColorName, 
      c.UnitName, c.PkgSpec, a.Qty, a.Price, a.Amt, c.PPrice, c.SPrice, c.SPrice1, c.SPrice2, 
      c.Package, c.MPackage, c.BPackage, c.SPrice3, c.PkgRatio, c.Integral, a.Remarks, 
      ISNULL(b.SQty, 0.0) - ISNULL(b.BoxQty, 0.0) AS RemBoxQty, 
      a.CheckBox, a.Qty AS MQty, a.Qty AS SqlQty, e.PartQty,a.BillType
FROM dbo.SMS_BoxupDtl_Dtl a LEFT OUTER JOIN
      dbo.SMS_BoxupDtl e ON a.BoxupDtlID = e.BoxupDtlID AND 
      a.BoxNo = e.BoxNo LEFT OUTER JOIN
      dbo.BDM_ItemInfo_V c ON a.ItemID = c.ItemID INNER JOIN
      dbo.IMS_AllotDtl b ON a.StockID = b.AllotID AND a.StockNo=b.AllotNo
go

