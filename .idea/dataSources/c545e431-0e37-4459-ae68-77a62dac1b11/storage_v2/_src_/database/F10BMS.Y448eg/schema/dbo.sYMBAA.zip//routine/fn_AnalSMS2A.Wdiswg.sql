

--说明：商品品牌销售排行榜
--作者：Devil.H
--创建：2010.06.29
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:分部
--	@Flag：标志
CREATE FUNCTION dbo.fn_AnalSMS2A
(
	@StartDate VARCHAR(10)='0000-01-01',
	@EndDate VARCHAR(10)='9999-12-31',
	@CorpNo VARCHAR(2)='',
	@DeptNo VARCHAR(20)='',
	@Flag BIT=0
)
RETURNS TABLE
AS
RETURN (
	SELECT LabelID,Isnull(LabelName,'未定义品牌商品') AS LabelName,
		SUM(SellQty) AS SellQty,SUM(SellAmt) AS SellAmt,SUM(RebateAmt) AS RebateAmt,
        SUM(PlatformFee) AS PlatformFee,SUM(RealAmt) AS RealAmt  
	FROM fn_AnalSMS1A(@StartDate,@EndDate,@CorpNo,@DeptNo,'','',@Flag)
	GROUP BY LabelID,LabelName
)
go

