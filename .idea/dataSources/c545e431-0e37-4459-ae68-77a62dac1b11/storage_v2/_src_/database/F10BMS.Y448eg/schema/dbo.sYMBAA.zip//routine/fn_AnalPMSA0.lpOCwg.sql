--说明：供应商货品单价分析
--作者：Devil.H
--创建：2007.11.26
--参数：
--	@StartDate:起始日期
--	@EndDate:截止日期
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag:标识
CREATE function dbo.fn_AnalPMSA0
(
	@StartDate char(10)='2000-01-01',
	@EndDate char(10)='2000-01-01',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	VendorID bigint,
	VendorNo varchar(20),
	VendorName varchar(200),
	VendorSpell varchar(200),
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemAlias varchar(200),
	ItemSpell varchar(200),
	ItemSpec varchar(100),
	BarCode varchar(100),
	ClassID varchar(20),
	ClassName varchar(100),
	LabelID varchar(20),
	LabelName varchar(100),
	ColorName varchar(40),
	UnitName varchar(40),
	LstPrice decimal(18,6),
	AvgPrice decimal(18,6),
	PPrice	decimal(18,6),
	SQty decimal(18,6),
	Amt decimal(18,6),
	GQty decimal(18,6),
	GAmt decimal(18,6),
	LstRatio decimal(18,6),
	AvgRatio decimal(18,6),
	QtyScale decimal(18,6),
	AmtScale decimal(18,6),
	MaxStockID varchar(20),
	BuyerID bigint,
	Buyer varchar(100),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40)
	Primary Key(VendorID,ItemID)
)
As
Begin
	if @Flag=0
		Return
	--初始化变量
	Set @StartDate=Convert(Char(10),Cast(@StartDate as datetime),120)
	Set @EndDate=Convert(Char(10),Cast(@EndDate as datetime),120)
	declare @Tmp Table(ItemID bigint,
			   GQty decimal(18,6),
			   GAmt decimal(18,6)
			   Primary Key(ItemID)
			   )
	--没有过滤条件
	if isnull(@CorpNo,'')='' And isnull(@DeptNo,'')=''
		begin
			--获取供应商，商品的销售数量，金额和最后一次销售的序号
			Insert Into @uTable(VendorID,ItemID,SQty,Amt,MaxStockID)
			Select a.VendorID,b.ItemID,Sum(Isnull(b.SQty,0.0)),Sum(Isnull(b.Amt,0.0)),Max(StockID)
			From PMS_Stock a Inner Join PMS_StockDtl b On a.StockNo=b.StockNo
			Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
				And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
			Group By a.VendorID,b.ItemID
		end
	--按部门过滤
	if isnull(@CorpNo,'')='' And (Not isnull(@DeptNo,'')='')
		begin
			--获取供应商，商品的销售数量，金额和最后一次销售的序号
			Insert Into @uTable(VendorID,ItemID,SQty,Amt,MaxStockID)
			Select a.VendorID,b.ItemID,Sum(Isnull(b.SQty,0.0)),Sum(Isnull(b.Amt,0.0)),Max(StockID)
			From PMS_Stock a Inner Join PMS_StockDtl b On a.StockNo=b.StockNo
			Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
				And a.DeptNo=@DeptNo
				And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
			Group By a.VendorID,b.ItemID
		end
	--按公司过滤
	if (Not isnull(@CorpNo,'')='') And isnull(@DeptNo,'')=''
		begin
			--获取供应商，商品的销售数量，金额和最后一次销售的序号
			Insert Into @uTable(VendorID,ItemID,SQty,Amt,MaxStockID)
			Select a.VendorID,b.ItemID,Sum(Isnull(b.SQty,0.0)),Sum(Isnull(b.Amt,0.0)),Max(StockID)
			From PMS_Stock a Inner Join PMS_StockDtl b On a.StockNo=b.StockNo
			Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
				And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
				And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And d.DeptNo=@CorpNo)
			Group By a.VendorID,b.ItemID
		end
	--按公司部门过滤
	if (Not isnull(@CorpNo,'')='') And (Not isnull(@DeptNo,'')='')
		begin
			--获取供应商，商品的销售数量，金额和最后一次销售的序号
			Insert Into @uTable(VendorID,ItemID,SQty,Amt,MaxStockID)
			Select a.VendorID,b.ItemID,Sum(Isnull(b.SQty,0.0)),Sum(Isnull(b.Amt,0.0)),Max(StockID)
			From PMS_Stock a Inner Join PMS_StockDtl b On a.StockNo=b.StockNo
			Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
				And a.DeptNo=@DeptNo
				And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
				And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And d.DeptNo=@CorpNo)
			Group By a.VendorID,b.ItemID
		end
	--获取商品的销售数量，销售金额
	Insert Into @Tmp(ItemID,GQty,GAmt)
	Select ItemID,Sum(Isnull(SQty,0.0)),Sum(Isnull(Amt,0.0))
	From @uTable
	Group By ItemID


	--更新商品总进货量，总进货金额，最近进价、平均价、总平均价,供应商资料
	Update a Set a.GQty=Isnull(c.GQty,0.0),
		     a.GAmt=Isnull(c.GAmt,0.0),
		     a.LstPrice=b.Price,
		     a.AvgPrice=Case Isnull(a.SQty,0.0) 
					When 0.0 Then 0.0
					Else Round(Isnull(a.Amt,0.0)/Isnull(a.SQty,0.0),6) End,
		     a.PPrice=Case Isnull(c.GQty,0.0) 
				When 0.0 Then 0.0 
				Else Round(Isnull(c.GAmt,0.0)/Isnull(c.GQty,0.0),6) End,
		     a.VendorNo=v.VendorNo,
		     a.VendorName=v.VendorName,
		     a.VendorSpell=v.NameSpell,
		     a.LinkMan=v.LinkMan,
		     a.Phone=v.Phone,
		     a.Faxes=v.Faxes,
		     a.BuyerID=v.BuyerID,
		     a.Buyer=v.Buyer,
		     a.ItemNo=g.ItemNo,
		     a.ItemName=g.ItemName,
		     a.ItemAlias=g.ItemAlias,
		     a.ItemSpell=g.NameSpell,
		     a.ItemSpec=g.ItemSpec,
		     a.UnitName=g.UnitName,
		     a.CLassID=g.ClassID,
		     a.LabelID=g.LabelID,
		     a.ClassName=g.ClassName,
		     a.LabelName=g.LabelName,
		     a.ColorName=g.ColorName		
	From @uTable a Inner Join PMS_StockDtl b On a.MaxStockID=b.StockID
		       Inner Join @Tmp c On a.ItemID=c.ItemID
		       Inner Join BDM_Vendor_V v On a.VendorID=v.VendorID	
		       Inner Join BDM_ItemInfo_V g On a.ItemID=g.ItemID
	
	--更新最近进价比、平均价比
	Update @uTable Set LstRatio=case isnull(PPrice,0.0) 
				When 0.0 then 0.0
				else round(isnull(LstPrice,0.0)/isnull(PPrice,0.0),6) end,
			   AvgRatio=case isnull(PPrice,0.0) 
				When 0.0 then 0.0 
				else round(isnull(AvgPrice,0.0)/isnull(PPrice,0.0),6) end,
			   QtyScale=case isnull(GQty,0.0) 
				When 0.0 then 0.0
				else round(isnull(SQty,0.0)/isnull(GQty,0.0),6) end,
			   AmtScale=case isnull(GAmt,0.0) 
				When 0.0 then 0.0
				else round(isnull(Amt,0.0)/isnull(GAmt,0.0),6) end
	--返回
	Return
End
go

