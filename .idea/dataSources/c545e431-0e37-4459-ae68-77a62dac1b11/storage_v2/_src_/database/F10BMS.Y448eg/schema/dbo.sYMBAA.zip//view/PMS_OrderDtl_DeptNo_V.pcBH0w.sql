
CREATE VIEW dbo.PMS_OrderDtl_DeptNo_V
AS
SELECT a.OrderID, a.OrderNo, a.DeptNo,ff.CHName As DeptName,a.DeptNo_A, d.CreateDate, d.BillType, d.BillSts, 
      a.PlanID, a.PlanNo, a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, 
      b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, b.LabelID, b.LabelName, 
      b.ColorName, b.UnitName, ISNULL(c.PQty, 0) - ISNULL(c.OQty, 0) AS RemOQty, 
      b.PkgSpec, a.PkgQty, a.OQty, a.Price, a.Amt, a.TaxFlag, a.IsSpecial, a.XS_OrderID, 
      a.XS_OrderNo, a.SQty, ISNULL(a.OQty, 0) - ISNULL(a.SQty, 0) AS RemSQty, 
      ISNULL(a.OQty, 0) - ISNULL(a.DQty, 0) AS RemDQty, e.OnHandQty, 
      ISNULL(e.OnHandQty, 0) - ISNULL(e.AllocQty, 0) AS AvailQty, 
      f.OnHandQty AS OnHandQty_A, ISNULL(f.OnHandQty, 0) - ISNULL(f.AllocQty, 0) 
      AS AvailQty_A, e.MaxStock, e.MinStock, b.PPrice, b.SafePPrice, b.SPrice, b.SPrice1, 
      b.SPrice2, b.SPrice3, b.BPackage, b.MPackage, b.Package, b.PkgRatio, b.HotFlag, 
      b.NotDisc, a.Remarks, a.CheckBox
     ,B.ItemPHFlag, B.ItemPHName
,d.YZStockWareHouseID as WareHouseID
,Y.Qty As YZStockQty
,a.billid,a.billNo
,T.ExecQty,T.FH As ContractFH,a.OQty As ConExportQty
,TT.Qty01 as ZJ_Sqty
FROM dbo.PMS_OrderDtl a 
LEFT OUTER JOIN      dbo.IMS_Subdepot f ON a.ItemID = f.ItemID AND       a.DeptNo_A = f.DeptNo 
LEFT OUTER JOIN      dbo.BDM_ItemInfo_V b ON a.ItemID = b.ItemID 
LEFT OUTER JOIN      dbo.IMS_Subdepot e ON a.DeptNo = e.DeptNo AND       a.ItemID = e.ItemID 
LEFT OUTER JOIN      dbo.PMS_Order d ON a.OrderNo = d.OrderNo 
LEFT OUTER JOIN      dbo.PMS_PlanDtl c ON a.PlanID = c.PlanID 
LEFT join IMS_YZStock_Sum_DeptID_V Y on a.ItemID=Y.ItemID and a.DeptNo_A=Y.DeptNo
LEFT OUTER JOIN dbo.CON_PMSDtl_V T ON a.BillID = T.BillID

LEFT OUTER JOIN      dbo.BDM_DeptCode_V ff ON a.DeptNo = ff.CodeID
LEFT OUTER JOIN      dbo.ANAL_LstSanSell_V TT ON a.DeptNo = TT.DeptNo AND       a.ItemID = TT.ItemID


go

