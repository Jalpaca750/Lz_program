CREATE VIEW dbo.BDM_SafePrice_V
AS
SELECT a.SID, a.ItemID, a.CustID, a.Price, a.Remarks, a.CreatorID, 
      b.EmployeeName AS PriceAuditingName
FROM dbo.BDM_SafePrice a LEFT OUTER JOIN
      dbo.BDM_Employee b ON a.CreatorID = b.EmployeeID
go

