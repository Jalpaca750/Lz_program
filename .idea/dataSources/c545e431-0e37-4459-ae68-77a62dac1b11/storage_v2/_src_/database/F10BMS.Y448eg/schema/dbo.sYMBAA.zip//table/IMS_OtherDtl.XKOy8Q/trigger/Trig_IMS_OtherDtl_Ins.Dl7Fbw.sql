--其他入出库单（Insert)
--2005-01-25
--Devil.H
--当上述操作发生时：
--其他出库影响到已分配量
CREATE Trigger Trig_IMS_OtherDtl_Ins
On dbo.IMS_OtherDtl
--with encryption
For Insert
As
Begin
	declare @BillType char(2)
	declare @OtherNo varchar(20)
	--获取单据号码
	select @OtherNo=OtherNo From Inserted
	--获取单据类型
	Select @BillType=BillType From IMS_Other Where OtherNo=@OtherNo
	if @BillType='20' Or @BillType='40'
		Update a Set a.AllocQty=isnull(AllocQty,0)+isnull(b.SQty,0)
		From BDM_ItemInfo a,Inserted b
		Where a.ItemID=b.ItemID
		
End
go

