
CREATE VIEW dbo.PMS_POAccounts_V
AS
SELECT a.StockNo, a.CreateDate, a.DeptNo, f.CHName AS DeptName, a.WareHouse, 
    g.CHName AS WHName, a.VendorID, b.VendorNo, b.VendorName, b.VendorAddr, 
    b.NameSpell, b.LinkMan, b.Phone, b.Faxes, b.BuyerID, b.Buyer, e.SQty, e.Amt, 
    e.RemIAmt,a.PAmt, a.PDate, a.SendNo, a.BillType,a.wmsStock,a.BillSts, 
    (SELECT StsName FROM BillStatus h WHERE a.BillSts=h.BillSts And h.BillType = 'PMS50') AS StsName, 
    a.PFlag,a.PrintNum,a.PrinterID,p.EmployeeName As Printer,a.RecieverId,
    e1.EmployeeName AS RecieverName, a.AuditDate, a.AuditID, d.EmployeeName AS Auditer, 
    a.CreatorID, c.EmployeeName AS Creator,ISNULL(a.SendID,b.SendID) AS SendID,
    ISNULL(K.CHName,b.SendMode) AS SendName,a.AuditingPICFlag,a.shelvesId,
    e2.EmployeeName AS shelvesName,a.shelvesTime,a.shelvesFlag,a.Rebate,a.TaxRate,
    a.memo,a.Remarks,a.CheckBox
FROM dbo.PMS_Stock a 
    LEFT JOIN dbo.BDM_Vendor_V b ON a.VendorID = b.VendorID 
    LEFT JOIN dbo.BDM_Employee d ON a.AuditID = d.EmployeeID 
    LEFT JOIN dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID 
    LEFT JOIN (SELECT StockNo,SUM(SQty) AS SQty,SUM(Amt) AS Amt,SUM(Isnull(Amt,0.0)-Isnull(IAmt,0.0)) As RemIAmt
               FROM PMS_StockDtl
               GROUP BY StockNo) e ON a.StockNo = e.StockNo 
    LEFT JOIN dbo.BDM_WareHouse_V g ON a.WareHouse = g.CodeID 
    LEFT JOIN dbo.BDM_DeptCode_V f ON a.DeptNo = f.CodeID 
    LEFT JOIN dbo.BDM_SendMode_V k ON a.SendID = k.CodeID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID=p.EmployeeID
    LEFT JOIN dbo.BDM_Employee e1 ON a.RecieverId=e1.EmployeeId
    LEFT JOIN dbo.BDM_Employee e2 ON a.shelvesId=e2.EmployeeId
WHERE (a.BillSts='20' OR a.BillSts='25') 
    AND ISNULL(e.RemIAmt,0.0)<>0.0
go

