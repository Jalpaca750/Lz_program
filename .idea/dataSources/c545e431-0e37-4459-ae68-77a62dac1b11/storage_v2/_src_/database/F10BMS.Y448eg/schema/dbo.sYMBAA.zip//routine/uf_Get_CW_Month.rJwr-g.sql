--说明：获取财务月
--作者：wujinfeng
--创建：2008.11.20
--参数：
--	@CustID:客户
--	@Flag：标志
--select * from dbo.uf_Get_CW_Month(1,2008,2)

CREATE Function dbo.uf_Get_CW_Month(@ltype int,@Year int,@Month int)
	Returns @uTable Table(CW_Month char(10))
	As
	Begin
		
	--********增加会计月份时间***********************
	declare @CW_Month varchar(6)
	declare @CW_Month_BDate char(10)
	declare @CW_Month_EDate char(10)

	if len(@Month)=1
		begin
		set @CW_Month=Cast(@Year As varchar(4))+'0'+Cast(@Month As varchar(1))
		end
	else
		begin
		set @CW_Month=Cast(@Year As varchar(4))+Cast(@Month As varchar(2))
		end
		
		--Set @CW_Month_BDate=Convert(Char(10),Cast(@CW_Month_BDate as datetime),120)
		--Set @CW_Month_BDate=Convert(Char(10),Cast(@CW_Month_BDate as datetime),120)
	
	if @ltype=1
		begin
			Set @CW_Month_BDate=(select Convert(Char(10),Cast(StartDate as datetime),120) from SYS_CW_MonthPeriod where CW_Period=@CW_Month)
			Insert Into @uTable values(@CW_Month_BDate)
		end
	if @ltype=2

		begin
			Set @CW_Month_EDate=(select Convert(Char(10),Cast(EndDate   as datetime),120) from SYS_CW_MonthPeriod where CW_Period=@CW_Month)
			Insert Into @uTable values(@CW_Month_EDate)
		end

		Return
	End

go

