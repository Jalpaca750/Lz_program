
CREATE VIEW [dbo].[BDM_ItemInfo_V]
AS
SELECT a.ItemID, a.ItemNo, a.ItemName, a.ItemAlias, a.NameSpell, a.ItemSpec,a.ArtNo,a.BarCode, 
    a.ClassID, b.CodeNo AS ClassNo, b.CHName AS ClassName, a.LabelID,c.CodeNo AS LabelNo,
    ISNULL(c.OrderID,999999) As LabelOrder, c.CHName AS LabelName, a.ColorName, a.UnitName, 
    a.ItemLong,a.ItemWidth,a.ItemHeight,a.ItemWeight,a.ItemVolume,a.MiddleUnit,a.MidBarcode,
    a.MiddleLong,a.MiddleWidth,a.MiddleHeight,a.MiddleWeight,a.MiddleVolume,a.MiddleRatio,
    a.BigUnit,a.BigBarcode,a.BigLong,a.BigWidth,a.BigHeight,a.BigWeight,a.BigVolume,a.BigRatio,
    a.PkgUnit,a.PkgBarcode,a.PkgLong,a.PkgWidth,a.PkgHeight,a.PkgWeight,a.PkgVolume,
    a.Cubage, a.Weight, a.BPackage, a.MPackage, a.Package, a.BUnit, a.MUnit, a.Unit,     
    a.PkgRatio, a.PkgSpec, a.PurDays, a.Origin, a.TaxRate, a.PPrice, a.SPrice, a.SPrice1, 
    a.SPrice2, a.SPrice3, a.SafePPrice, a.SafeSPrice,a.AdvancedDays,
    a.IsVirtual,CASE a.IsVirtual WHEN 0 THEN '实物' WHEN 1 THEN '服务' WHEN 2 THEN '虚拟' END AS VirtualFlag,
    a.AllowSplit,CASE a.AllowSplit WHEN 0 THEN '不拆分' WHEN 1 THEN '拆分' WHEN 2 THEN '自拆分' END AS SplitMode,
    a.SplitRatio,a.PrintControl,a.SafetyDays,
    a.OnHandQty,ISNULL(a.OnHandQty, 0.0) - ISNULL(t.AllocQty, 0.0) AS AvailQty, a.Integral, a.Defined1,
    a.Defined2, a.Defined3, a.Defined4, a.Defined5, a.HotFlag, a.NotDisc, a.ItemPHFlag, 
    CASE a.ItemPHFlag WHEN 'P' THEN '批号' WHEN 'S' THEN '序列号' ELSE '都不管理' END AS ItemPHName, 
    a.NTrue, a.PicAmount, a.Sale, a.SaleOrder, a.RecommOrder, a.Recomm, a.NOrder, a.HotOrder, a.IsWeb, 
    CASE isnull(a.Flag, '1') WHEN '1' THEN '有效' ELSE '失效' END AS Flag, a.InMid, a.ToMidDate,
    a.CreateDate, a.CreatorID, d.EmployeeName AS Creator, a.AmendDate, a.MenderID, e.EmployeeName AS Mender,  
    a.PromotionInfo,a.PurLine,l1.CHName AS PurLineDesc,a.SalLine,l2.CHName AS SalLineDesc,a.syncFlag,a.editTime,
    a.ZPCode, a.ZPName, a.Remarks, a.CheckBox
FROM dbo.BDM_ItemInfo a 
    LEFT JOIN dbo.BDM_Employee d ON a.CreatorID = d.EmployeeID 
    LEFT JOIN dbo.BDM_Employee e ON a.MenderID = e.EmployeeID 
    LEFT JOIN dbo.BDM_LabelCode_V c ON a.LabelID = c.CodeID 
    LEFT JOIN dbo.BDM_ItemClass_V b ON a.ClassID = b.CodeID 
    LEFT JOIN dbo.BDM_Code l1 ON a.PurLine=l1.CodeID AND l1.Classify='FL32'
    LEFT JOIN dbo.BDM_Code l2 ON a.SalLine=l2.CodeID AND l1.Classify='FL33'
    LEFT JOIN (SELECT ItemID,SUM(AllocQty) As AllocQty
                FROM IMS_Allocate_V
                Group By ItemID) t ON a.ItemID=t.ItemID
go

