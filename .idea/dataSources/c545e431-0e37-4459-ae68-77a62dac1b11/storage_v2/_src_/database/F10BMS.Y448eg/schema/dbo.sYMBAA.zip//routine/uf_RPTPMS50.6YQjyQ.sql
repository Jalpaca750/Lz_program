
--说明：系统报表之采购入库单
--作者：Devil.H
--创建：2007.10.13
--参数：
--	@BillNo	 :单据编号
--	@Row	 :每页打印行数
CREATE Function dbo.uf_RPTPMS50
(
	@BillNo varchar(20),
	@Row bigint,
	@OrderBy varchar(30)
)
Returns @uTable Table(
	BillID bigint identity(1,1),
	BillNo varchar(20),
	Location varchar(20),
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemSpec varchar(200),
    Barcode varchar(100),
	ClassName varchar(40),
	LabelName varchar(40),
	ColorName varchar(40),
	UnitName varchar(40),
	Price decimal(18,6),
	PkgSpec varchar(40),
	PkgQty decimal(18,6),
	SQty decimal(18,6),
	Amt decimal(18,6),
	PPrice decimal(18,6),
    SPrice decimal(18,6),
	BPackage varchar(40),
	MPackage varchar(40),
	Package varchar(40),
	Remarks varchar(2000)
)
As
Begin	
	declare @Rows bigint
	declare @NullRow bigint
	declare @i bigint
	--初始化变量
	Set @i=0
	--如果没有传递行数，默认9行
	Set @Row=isnull(@Row,9)
	if isnull(@BillNo,'')=''
		Return
	if upper(@OrderBy)='STOCKID'
		Insert Into @uTable(BillNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,
			UnitName,Price,SQty,PkgSpec,PkgQty,Amt,PPrice,BPackage,MPackage,Package,Remarks,Barcode,SPrice)
		Select StockNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,UnitName,
			Price,SQty,PkgSpec,PkgQty,Amt,PPrice,BPackage,MPackage,Package,Remarks,Barcode,SPrice
		From PMS_StockDtl_V
		Where StockNo=@BillNo
		Order By StockID
	if upper(@OrderBy)='ITEMNO'
		Insert Into @uTable(BillNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,
			UnitName,Price,SQty,PkgSpec,PkgQty,Amt,PPrice,BPackage,MPackage,Package,Remarks,Barcode,SPrice)
		Select StockNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,UnitName,
			Price,SQty,PkgSpec,PkgQty,Amt,PPrice,BPackage,MPackage,Package,Remarks,Barcode,SPrice
		From PMS_StockDtl_V
		Where StockNo=@BillNo
		Order By ItemNo
	if upper(@OrderBy)='LOCATION'
		Insert Into @uTable(BillNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,
			UnitName,Price,SQty,PkgSpec,PkgQty,Amt,PPrice,BPackage,MPackage,Package,Remarks,Barcode,SPrice)
		Select StockNo,Location,ItemNo,ItemName,ItemSpec,ClassName,LabelName,ColorName,UnitName,
			Price,SQty,PkgSpec,PkgQty,Amt,PPrice,BPackage,MPackage,Package,Remarks,Barcode,SPrice
		From PMS_StockDtl_V
		Where StockNo=@BillNo
		Order By Location
	--总的行数
	Select @Rows=Count(*) From @uTable
	if @Rows=0 
		return
	Set @NullRow=@Row-@Rows%@Row
	if @NullRow=@Row 
		Return
	while @i<@NullRow
		Begin
			Insert Into @uTable(BillNo)
			Values(@BillNo)
			Set @i=@i+1
		End
	--返回
	return
End
go

