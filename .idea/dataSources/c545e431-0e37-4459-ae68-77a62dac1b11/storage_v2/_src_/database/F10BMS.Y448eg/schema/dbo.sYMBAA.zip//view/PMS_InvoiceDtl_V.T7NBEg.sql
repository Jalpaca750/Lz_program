CREATE VIEW dbo.PMS_InvoiceDtl_V
AS
SELECT a.InvoiceID, a.InvoiceNo, d.CreateDate, d.BillSts, a.StockID, a.StockNo, a.BillType, 
    a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, b.ItemSpec, b.BarCode, b.ClassID, 
    b.ClassName, b.LabelID, b.LabelName, b.ColorName, b.UnitName,ISNULL(c.RemIQty,0.0)+ISNULL(a.IQty,0.0) AS RemIQty, 
    ISNULL(c.RemIAmt,0.0)+ISNULL(a.Amt,0.0) AS RemAmt,a.IQty, a.Price, a.Amt, a.PAmt, 
    ISNULL(c.RemPAmt,0.0)+ISNULL(a.PAmt,0.0) AS RemPAmt,a.OrderID, a.OrderNo, c.IsSpecial, 
    c.OnHandQty, b.PPrice, b.SafePPrice, a.TaxFlag, a.Remarks, a.CheckBox
FROM dbo.PMS_InvoiceDtl a 
    INNER JOIN dbo.PMS_Invoice d ON a.InvoiceNo = d.InvoiceNo
    INNER JOIN dbo.BAS_Goods_V b ON a.ItemID = b.ItemID 
    LEFT JOIN (SELECT ISNULL(x.SQty, 0.0) - ISNULL(x.IQty, 0.0) AS RemIQty,
                   ISNULL(x.Amt,0.0)-ISNULL(x.IAmt,0.0) AS RemIAmt,
		           ISNULL(x.PAmt, 0.0) - ISNULL(x.PIAmt, 0.0) AS RemPAmt, 
		           y.OnHandQty, x.StockID, x.IsSpecial
               FROM dbo.PMS_StockDtl x 
                   INNER JOIN dbo.IMS_Ledger y ON x.WareHouse = y.WareHouse AND x.ItemID = y.ItemID
            ) c ON a.StockID = c.StockID
go

