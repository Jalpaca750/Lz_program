CREATE VIEW dbo.PMS_ReturnDtl_V
AS
SELECT a.ReturnID, a.ReturnNo, e.CreateDate, e.VendorID, e.BillSts, a.StockID, a.StockNo, 
    a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, b.ItemSpec, b.BarCode, 
    b.ClassID, b.ClassName, b.LabelID, b.LabelName, b.ColorName, b.UnitName, 
    ISNULL(f.Location, a.Location) AS Location, a.WareHouse, f.OnHandQty, 
    ISNULL(c.SQty, 0.0) - ISNULL(c.RQty, 0.0) AS RemRQty, b.PkgSpec, a.PkgQty, a.RQty, 
    a.Price, a.Amt, a.TaxFlag, a.IsSpecial, b.PPrice, b.SafePPrice, b.PkgRatio, 
    b.BPackage, b.MPackage, b.Package, c.OrderID, c.OrderNo, c.PlanID, c.XS_OrderNo, 
    c.XS_OrderID, c.PlanNo, a.Remarks, a.CheckBox, b.ItemPHFlag, b.ItemPHName, 
    Y.QTY AS YZStockQty,e.Rebate,e.TaxRate,ISNULL(b.IsVirtual,0) AS IsVirtual
FROM dbo.PMS_ReturnDtl a 
    LEFT JOIN dbo.BAS_Goods_V b ON a.ItemID = b.ItemID 
    LEFT JOIN dbo.PMS_Return e ON a.ReturnNo = e.ReturnNo 
    LEFT JOIN dbo.IMS_Ledger f ON a.WareHouse = f.WareHouse AND a.ItemID = f.ItemID 
    LEFT JOIN dbo.PMS_StockDtl c ON a.StockID = c.StockID 
    LEFT JOIN dbo.IMS_YZStock_Sum_WareHouse_Sum_V Y ON a.WareHouse = Y.WareHouseID AND a.ItemID = Y.ItemID 
go

