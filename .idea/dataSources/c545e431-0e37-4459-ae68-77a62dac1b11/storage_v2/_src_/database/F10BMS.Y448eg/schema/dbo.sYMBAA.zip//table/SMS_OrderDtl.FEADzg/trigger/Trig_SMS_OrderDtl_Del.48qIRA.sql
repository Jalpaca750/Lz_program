--销售出库单细删除操作（BillSts='20'审核/BillSts='10'取消审核)
--2008-12-09
--wujinfeng
--当上述操作发生时：
--当前合同的已执行数量减少
CREATE Trigger Trig_SMS_OrderDtl_Del
On dbo.SMS_OrderDtl
For Delete
As
Begin
	declare @BillNo varchar(20),@BillID bigint,@OrderID bigint;
	--已出库数量更新
	Update a Set a.SQty=Isnull(a.SQty,0)-Isnull(b.OQty,0) 
    From CON_SmsDtl a 
        Inner Join Deleted b On a.BillID=b.BillID;
    --获取写入合同单号
    Select @BillNo=BillNo From Deleted;
    if (Isnull(@billNo,'')<>'')
	begin
		--存在未执行的记录
		if exists(Select * from CON_SmsDtl Where Isnull(SQty,0)>0 And BillNo=@BillNo)
			Update CON_Sms Set BillSts='25' Where BillNo=@BillNo And BillSts<>'05'
		else
			Update CON_Sms Set BillSts='20' Where BillNo=@BillNo And BillSts<>'05'
	end
End
go

