CREATE VIEW dbo.SPM_IntegLargess_V
AS
SELECT a.Seq, a.Integral, a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, 
      b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, b.LabelID, b.LabelName, 
      b.ColorName, b.UnitName, a.ZQty, a.EndQty
FROM dbo.SPM_IntegLargess a INNER JOIN
      dbo.BAS_Goods_V b ON a.ItemID = b.ItemID
go

