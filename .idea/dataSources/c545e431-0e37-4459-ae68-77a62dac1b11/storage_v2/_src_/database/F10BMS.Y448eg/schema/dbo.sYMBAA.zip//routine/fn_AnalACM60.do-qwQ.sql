--说明：供应商预付款分析
--作者：Devil.H
--创建：2007.11.15
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag：标志
CREATE Function dbo.fn_AnalACM60
(
	@StartDate char(10)='2000-01-01',
	@EndDate char(10)='2000-01-01',
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0
)
Returns @uTable Table(
	VendorID bigint,
	VendorNo varchar(20),
	VendorName varchar(200),
	NameSpell varchar(200),
	BuyerID bigint,
	Buyer varchar(100),
	AdvAmt decimal(18,6),
	OffAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40)
)
As
Begin	
	if @Flag=0
		Return
	--初始化变量
	Set @StartDate=Convert(Char(10),Cast(@StartDate as datetime),120)
	Set @EndDate=Convert(Char(10),Cast(@EndDate as datetime),120)
	--临时表
	declare @Tmp Table(VendorID bigint,AdvAmt decimal(18,6),OffAmt decimal(18,6))
	Insert Into @Tmp(VendorID,AdvAmt,OffAmt)
	Select b.VendorID,Sum(AdvAmt),0.0 as OffAmt
	From PMS_Advances a inner join PMS_AdvancesDtl b On a.AdvancesNo=b.AdvancesNo
	Where (a.BillSts='20')
		And (Convert(char(10),Cast(a.CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (a.DeptNo Like @DeptNo + '%') 
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group By b.VendorID
	Union All
	Select VendorID,0.0 as AdvAmt,Sum(AdvAmt)
	From PMS_Payment a	
	Where (BillSts='20') And Isnull(AdvFlag,0)=1 
		And (Convert(char(10),Cast(CreateDate as datetime),120) Between @StartDate And @EndDate)
		And (DeptNo Like @DeptNo + '%') 
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group By VendorID
	--写入表值函数	
	Insert Into @uTable(VendorID,AdvAmt,OffAmt)
	Select VendorID,Sum(AdvAmt),Sum(OffAmt)
	From @Tmp
	Group By VendorID
	--更新客户资料
	Update a Set a.VendorNo=b.VendorNo,a.VendorName=b.VendorName,a.NameSpell=b.NameSpell,
		a.BuyerID=b.BuyerID,a.Buyer=b.Buyer,a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes
	From @uTable a,BDM_Vendor_V b
	Where a.VendorID=b.VendorID
	Return
End
go

