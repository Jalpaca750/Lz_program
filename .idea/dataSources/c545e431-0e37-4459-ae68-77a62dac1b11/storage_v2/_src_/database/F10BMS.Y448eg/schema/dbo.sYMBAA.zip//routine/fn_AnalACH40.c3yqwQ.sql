--说明：资产权益统计
--作者：Devil.H
--创建：2007.11.21
--修改: 2010.03.24 Devil.H
--参数：	
--	@Flag:为前台设计
CREATE  Function dbo.fn_AnalACH40
(
	@Flag bit
)
Returns @uTable Table(
	Seq bigint,
	Item varchar(200),
	Amt decimal(18,6),
	LstDate varchar(10)
	Primary Key(Seq)
)
As
Begin
	declare @KCAmt decimal(18,6)
	declare @XSAmt decimal(18,6)
	declare @XJAmt decimal(18,6)
	declare @FPAmt decimal(18,6)
	declare @FZAmt decimal(18,6)
	declare @SKAmt decimal(18,6)
	declare @MSAmt decimal(18,6)
	declare @QCAmt decimal(18,6)
	declare @YFAmt decimal(18,6)
	declare @CXAmt decimal(18,6)
	declare @CGAmt decimal(18,6)
	if @Flag=0
	Begin 
		Insert Into @uTable(Seq,Item,Amt) 
		Values(1,'库存资金',Null)
		Insert Into @uTable(Seq,Item,Amt)
		Values(2,'加:应收帐款',Null)
		Insert Into @uTable(Seq,Item,Amt)
		Values(3,'减:预收款余额',Null)
		Insert Into @uTable(Seq,Item,Amt)
		Values(4,'减:应付帐款',Null)
		Insert Into @uTable(Seq,Item,Amt)
		Values(5,'加:预付款余额',Null)
		Insert Into @uTable(Seq,Item,Amt) 
		Values(6,'加:其他净资产',Null)
		Return
	End
	--库存金额
	Select @KCAmt=Sum(Isnull(Amt,0.0)) From IMS_Ledger
	Insert Into @uTable(Seq,Item,Amt) Values(1,'库存资金',IsNull(@KCAmt,0.0))
	--总销售额,总现金
	Select @XSAmt=Sum(Isnull(b.Amt,0.0))
	From SMS_Stock a Inner join SMS_StockDtl b on a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
	--总零售现金
	Select @XJAmt=Isnull(@XJAmt,0.0)+Sum(Isnull(b.Amt,0.0))
	From SMS_Retail a inner join SMS_RetailDtl b on a.RetailNo=b.RetailNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') And a.BillType='40'
	Select @XJAmt=Isnull(@XJAmt,0.0)-Sum(Isnull(b.Amt,0.0))
	From SMS_Retail a inner join SMS_RetailDtl b on a.RetailNo=b.RetailNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') And a.BillType='50'
	--销售收现折扣
	Select @XJAmt=Isnull(@XJAmt,0.0)+Sum(Isnull(DiscAmt,0.0))+Sum(Isnull(PaidAmt,0.0))
	From SMS_Stock 
	Where (BillSts='20' Or BillSts='25' Or BillSts='30')
	--总期初欠款
	Select @QCAmt=Sum(Isnull(Amt,0.0)) From SMS_Arrearage
	--发票折扣
	Select @FZAmt=Sum(Isnull(DAmt,0.0)) 
	From SMS_Invoice 
	Where (BillSts='20' Or BillSts='25' Or BillSts='30')
	--总收发票款
	Select @SKAmt=Sum(Isnull(b.PayAmt,0.0)),@MSAmt=Sum(Isnull(b.FAmt,0.0))
	From SMS_Payment a inner join SMS_PaymentDtl b On a.PaymentNo=b.PaymentNo
	Where a.BillSts='20'
	Insert Into @uTable(Seq,Item,Amt) 
	Values(2,'加:应收帐款',Isnull(@XSAmt,0.0)+Isnull(@QCAmt,0.0)-Isnull(@FZAmt,0.0)-Isnull(@XJAmt,0.0)-
		Isnull(@SKAmt,0.0)-Isnull(@MSAmt,0.0))
	--预付款(客户)
	Select @YFAmt=Sum(Isnull(b.AdvAmt,0.0))
	From SMS_Advances a Inner Join SMS_AdvancesDtl b On a.AdvancesNo=b.AdvancesNo
	Where a.BillSts='20'
	--冲销
	Select @CXAmt=Sum(Isnull(AdvAmt,0.0))
	From SMS_Payment
	Where BillSts='20'
	Insert Into @uTable(Seq,Item,Amt) 
	Values(3,'减:预收款余额',-(Isnull(@YFAmt,0.0)-Isnull(@CXAmt,0.0)))

	--统计当前采购金额
	Select @CGAmt=Sum(Isnull(b.Amt,0.0)) 
	From PMS_Stock a inner join PMS_StockDtl b on a.StockNo=b.StockNo
	Where (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
	--统计采购发票
	Select @FZAmt=Sum(Isnull(DAmt,0.0))
	From PMS_Invoice 
	Where (BillSts='20' Or BillSts='25' Or BillSts='30')
	--期初欠款
	Select @QCAmt=Sum(Isnull(Amt,0.0)) From PMS_Arrearage
	--总付发票款
	Select @SKAmt=Sum(Isnull(b.PayAmt,0.0)),@MSAmt=Sum(Isnull(b.FAmt,0.0))
	From PMS_Payment a inner join PMS_PaymentDtl b On a.PaymentNo=b.PaymentNo
	Where a.BillSts='20'
	Insert Into @uTable(Seq,Item,Amt) 
	Values(4,'减:应付帐款',-(Isnull(@CGAmt,0.0)+Isnull(@QCAmt,0.0)-Isnull(@FZAmt,0.0)-
		Isnull(@SKAmt,0.0)-Isnull(@MSAmt,0.0)))
	--预付款
	Select @YFAmt=Sum(Isnull(b.AdvAmt,0.0))
	From PMS_Advances a Inner Join PMS_AdvancesDtl b On a.AdvancesNo=b.AdvancesNo
	Where a.BillSts='20'
	--冲销
	Select @CXAmt=Sum(Isnull(AdvAmt,0.0))
	From PMS_Payment
	Where BillSts='20'
	Insert Into @uTable(Seq,Item,Amt) 
	Values(5,'加:预付款余额',Isnull(@YFAmt,0.0)-Isnull(@CXAmt,0.0))
	--插入其他
	Insert Into @uTable(Seq,Item,Amt) Values(6,'加:其他净资产',Null)
	--返回
	return
End
go

