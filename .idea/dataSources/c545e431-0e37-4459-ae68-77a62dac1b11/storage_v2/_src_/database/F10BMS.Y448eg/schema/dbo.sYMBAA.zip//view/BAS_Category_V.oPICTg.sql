
create view BAS_Category_V as
SELECT a.CodeID AS categoryId,a.CodeID AS categoryNo,a.CHName AS categoryCName,
    CASE LEN(a.CodeID) WHEN 4 THEN '' ELSE LEFT(a.CodeID,LEN(a.CodeID)-4) END AS parentId,
    b.CHName AS parentCName
FROM BDM_ItemClass_V a
    LEFT JOIN BDM_Code b ON LEFT(a.CodeID,LEN(a.CodeID)-4)=b.CodeID
go

