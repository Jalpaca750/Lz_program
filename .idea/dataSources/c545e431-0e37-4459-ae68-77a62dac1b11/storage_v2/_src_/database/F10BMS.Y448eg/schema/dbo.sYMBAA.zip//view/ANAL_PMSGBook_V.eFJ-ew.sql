CREATE VIEW dbo.ANAL_PMSGBook_V
AS
SELECT a.VendorID, b.VendorNo, b.VendorName, b.NameSpell, b.BuyerID, b.Buyer, 
      b.LinkMan, b.Phone, b.Faxes, a.Years, a.Months, a.IMSAmt, a.ICGAmt, a.IYKAmt, 
      a.IFPAmt, a.IZKAmt, a.IMEAmt, a.PMSAmt, a.PFPAmt, a.PYSAmt, a.PFKAmt, a.PMFAmt, 
      a.PYFAmt, a.PCXAmt, a.PMEAmt, a.LstDate
FROM dbo.ANAL_PMSGBook a INNER JOIN
      dbo.BDM_Vendor_V b ON a.VendorID = b.VendorID
go

