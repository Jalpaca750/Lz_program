CREATE VIEW dbo.Web_Order_V
AS
SELECT a.OrderNo, a.CreateDate, a.DeptNo, e.CHName AS DeptName, a.CustID, b.CustNo, 
      b.CustName, b.NameSpell, b.CustType, b.TypeName, b.MemberID, b.Member, 
      b.AreaCode, b.AreaName, b.PopedomID, b.PopedomName, b.LinkMan, b.Phone, 
      b.Faxes, a.SalesID, j.EmployeeName AS Sales, d.Amt, a.SendDate, a.SendTime, 
      a.SendAddr, a.SendID, f.CHName AS SendMode, a.SendFlag, a.SourceFlag, a.BillSts, 
      g.StsName, a.CreatorID, c.EmployeeName AS Creator, a.PFlag, b.IsContract, 
      a.IsCheck, a.WebName, a.Remarks, a.CheckBox
, a.CostsID, cb.CHName As CostsName,a.orderreninfo

FROM dbo.Web_Order a LEFT OUTER JOIN
      dbo.BillStatus g ON a.BillSts = g.BillSts LEFT OUTER JOIN
      dbo.BDM_Employee j ON a.SalesID = j.EmployeeID LEFT OUTER JOIN
      dbo.BDM_SendMode_V f ON a.SendID = f.CodeID LEFT OUTER JOIN
      dbo.BDM_Customer_V b ON a.CustID = b.CustID LEFT OUTER JOIN
      dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID 
 LEFT OUTER join  dbo.Web_Costs_Class cb ON a.CostsID = cb.CostsID

LEFT OUTER JOIN
          (SELECT OrderNo, SUM(Amt) AS Amt
         FROM Web_OrderDtl
         GROUP BY OrderNo) d ON a.OrderNo = d.OrderNo LEFT OUTER JOIN
      dbo.BDM_DeptCode_V e ON a.DeptNo = e.CodeID
WHERE (g.BillType = 'SMS30')
go

