--年销售额
CREATE VIEW dbo.BDM_SalesAmt_V
AS
SELECT CodeID, CodeNo, CHName, ENName, Flag,Classify, CheckBox
FROM dbo.BDM_CODE
WHERE (Classify = 'FL21')
go

