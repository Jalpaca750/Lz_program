

--说明：不动销商品分析
--作者：Devil.H
--创建：2012.05.14
--参数：
--	@CorpNo：公司
--	@DeptNo:部门
--	@OverDays: 不动销天数
--	@Flag：  标志
CREATE FUNCTION fn_AnalSMS2H
(
	@CorpNo VARCHAR(2),
	@DeptNo VARCHAR(20),
	@OverDays BIGINT=90,
	@Flag BIT=0
)
RETURNS @uTable TABLE(
    WHID VARCHAR(20),
    WHName VARCHAR(100),
    ItemID BIGINT,
    ItemNo VARCHAR(20),
    ItemName VARCHAR(200),
    ItemAliAS VARCHAR(200),
    NameSpell VARCHAR(200),
    ItemSpec VARCHAR(100),
    BarCode VARCHAR(100),
    MidBarcode VARCHAR(100),
    BigBarcode VARCHAR(100),
    PkgBarcode VARCHAR(100),
    ClASsID VARCHAR(20),
    ClASsName VARCHAR(100),
    LabelID VARCHAR(20),
    LabelName VARCHAR(100),
    ColorName VARCHAR(40),
    UnitName VARCHAR(40),
    PkgSpec VARCHAR(40),
    OnHandQty DECIMAL(18,6),
    PkgQty DECIMAL(18,6),
    LstDate VARCHAR(10),
    OverDays BIGINT,
    PurLine VARCHAR(100),
    PurLineDesc VARCHAR(100),
    PurDate VARCHAR(10),
    PurQty DECIMAL(18,6)
)
AS
BEGIN	
	IF (@Flag=0) 
		RETURN;
	--当前日期
	DECLARE @Today VARCHAR(10)
	SELECT @Today=Today FROM SYS_GetDate_V;
	--临时表
	DECLARE @uTmp TABLE(WHID VARCHAR(20),ItemID BIGINT,LstDate VARCHAR(10));
    DECLARE @pTmp TABLE(WHID VARCHAR(20),ItemID BIGINT,LstDate VARCHAR(10));
    DECLARE @qTmp TABLE(WHID VARCHAR(20),ItemID BIGINT,LstDate VARCHAR(10),SQty DECIMAL(18,6) PRIMARY KEY(WHID,ItemID));
    --写入仓库商品最后销售日期
	INSERT INTO @uTmp(WHID,ItemID,LstDate)	
	SELECT WareHouse,ItemID,MAX(CreateDate)
	FROM (
	    --对外销售 MAX(a.CreateDate)
	    SELECT a.WareHouse,b.ItemID,MAX(a.CreateDate) CreateDate
	    FROM SMS_Stock a 
            INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
	    WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
            AND (a.BillType='10')
            AND (a.DeptNo Like @DeptNo + '%')
		    AND EXISTS(SELECT * FROM BDM_DeptCode_V d WHERE (a.DeptNo=d.CodeID) AND (d.DeptNo LIKE @CorpNo + '%'))
	    GROUP BY a.WareHouse,b.ItemID
	    UNION ALL 
	    --内部销售
	    SELECT a.WareHouse,b.ItemID,MAX(a.CreateDate) CreateDate
	    FROM IMS_Allot a
	        INNER JOIN IMS_AllotDtl b ON a.AllotNo=b.AllotNo  
	    WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
	        AND (a.DeptNo Like @DeptNo + '%')
		    AND EXISTS(SELECT * FROM BDM_DeptCode_V d WHERE (a.DeptNo=d.CodeID) AND (d.DeptNo LIKE @CorpNo + '%'))
		GROUP BY a.WareHouse,b.ItemID
	    ) t
	GROUP BY WareHouse,ItemID;    
    --最后采购日期,采购单明细ID
	INSERT INTO @pTmp(WHID,ItemID,LstDate)
	SELECT WareHouse,ItemID,MAX(CreateDate)
	FROM (
            --外采
            SELECT a.WareHouse,b.ItemID,MAX(a.CreateDate) CreateDate,MAX(b.StockID) StockID
            FROM PMS_Stock a 
                INNER JOIN PMS_StockDtl b ON a.StockNo=b.StockNo
            WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
                AND (a.BillType='10')
                AND (a.DeptNo Like @DeptNo + '%')
                AND EXISTS(SELECT * FROM BDM_DeptCode_V d WHERE (a.DeptNo=d.CodeID) AND (d.DeptNo LIKE @CorpNo + '%'))
            GROUP BY a.WareHouse,b.ItemID
            --内采
            UNION ALL
            SELECT a.WareHouse,b.ItemID,MAX(a.CreateDate) CreateDate,MAX(b.InceptID) InceptID
            FROM IMS_Incept a 
                INNER JOIN IMS_InceptDtl b ON a.InceptNo=b.InceptNo
            WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
                AND (a.DeptNo Like @DeptNo + '%')
                AND EXISTS(SELECT * FROM BDM_DeptCode_V d WHERE (a.DeptNo=d.CodeID) AND (d.DeptNo LIKE @CorpNo + '%'))
            GROUP BY a.WareHouse,b.ItemID
            ) t
    GROUP BY WareHouse,ItemID;
    --汇总当天采购量
    INSERT INTO @qTmp(WHID,ItemID,SQty)
    SELECT WareHouse,ItemID,SUM(SQty)
    FROM (
            --外采
            SELECT a.WareHouse,b.ItemID,SUM(b.SQty) SQty
            FROM PMS_Stock a 
                INNER JOIN PMS_StockDtl b ON a.StockNo=b.StockNo
                INNER JOIN @pTmp c ON a.Warehouse=c.WHID AND a.CreateDate=c.LstDate AND b.ItemID=c.ItemID
            WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
                AND (a.BillType='10')
                AND (a.DeptNo Like @DeptNo + '%')
                AND EXISTS(SELECT * FROM BDM_DeptCode_V d WHERE (a.DeptNo=d.CodeID) AND (d.DeptNo LIKE @CorpNo + '%'))
            GROUP BY a.WareHouse,b.ItemID
            UNION ALL
            --内采购
            SELECT a.WareHouse,b.ItemID,SUM(b.IQty)
            FROM IMS_Incept a 
                INNER JOIN IMS_InceptDtl b ON a.InceptNo=b.InceptNo
                INNER JOIN @pTmp c ON a.Warehouse=c.WHID AND a.CreateDate=c.LstDate AND b.ItemID=c.ItemID
            WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
                AND (a.DeptNo Like @DeptNo + '%')
                AND EXISTS(SELECT * FROM BDM_DeptCode_V d WHERE (a.DeptNo=d.CodeID) AND (d.DeptNo LIKE @CorpNo + '%'))
            GROUP BY a.WareHouse,b.ItemID
        ) t 
    GROUP BY WareHouse,ItemID;
	--写入
	INSERT INTO @uTable(WHID,WHName,ItemID,ItemNo,ItemName,ItemAliAS,NameSpell,ItemSpec,BarCode,MidBarcode,
	    BigBarcode,PkgBarcode,ClassID,ClassName,LabelID,LabelName,ColorName,UnitName,PkgSpec,OnHandQty,PkgQty,
        LstDate,OverDays,PurLine,PurLineDesc,PurDate,PurQty)
	SELECT l.Warehouse,w.CHName AS WHName,l.ItemID,g.ItemNo,g.ItemName,g.ItemAliAS,g.NameSpell,g.ItemSpec,g.BarCode,g.MidBarcode,
		g.BigBarcode,g.PkgBarcode,g.ClASsID,g.ClASsName,g.LabelID,g.LabelName,g.ColorName,g.UnitName,g.PkgSpec,l.OnHandQty,
		CASE ISNULL(g.PkgRatio,0.0) WHEN 0.0 THEN Null ELSE ROUND(ISNULL(l.OnHandQty,0.0)/g.PkgRatio,4) END,
		a.LstDate,DATEDIFF(d,a.LstDate,@Today)-90,g.PurLine,c.CHName,b.LstDate,d.SQty
	FROM IMS_Ledger l 
        INNER JOIN BAS_Goods_V g ON l.ItemID=g.ItemID
		INNER JOIN BDM_WareHouse_V w ON l.WareHouse=w.CodeID
        LEFT JOIN @uTmp a On l.WareHouse=a.WHID And l.ItemID=a.ItemID
        LEFT JOIN @pTmp b ON l.WareHouse=b.WHID And l.ItemID=b.ItemID
        LEFT JOIN @qTmp d ON l.WareHouse=d.WHID And l.ItemID=d.ItemID
        LEFT JOIN BDM_Code c ON c.Classify='FL32' AND g.PurLine=c.CodeID
	WHERE (DATEDIFF(d,a.LstDate,@Today)-@OverDays>0 OR (a.LstDate IS NULL)) 
	    AND (ISNULL(l.OnHandQty,0.0)>0.0);
    DELETE FROM @uTmp;
    DELETE FROM @pTmp;
    DELETE FROM @qTmp;
	--返回
 	RETURN;
END
go

