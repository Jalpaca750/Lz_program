--销售付款明细插入操作（Insert)
--2005-01-25
--Devil.H
--当上述操作发生时：
--更新销售发票已付款金额……
CREATE Trigger Trig_SMS_PAYMENTDTL_Ins
On dbo.SMS_PaymentDtl
For Insert
As
Begin
	declare @InvoiceID bigint
	--更新发票的已付款金额
	Update a Set a.PAmt=Isnull(a.PAmt,0.0)+Isnull(b.PayAmt,0.0)+isnull(b.FAmt,0.0)
	From SMS_Invoice a Inner Join Inserted b On a.InvoiceID=b.InvoiceID
	--计划单
	declare mycursor cursor
	for select InvoiceID from  Inserted
	open mycursor
	fetch next from mycursor into @InvoiceID
	while @@fetch_Status=0
	begin
		--存在未执行的记录
		if exists(Select 1 from SMS_Invoice Where InvoiceID=@InvoiceID And Isnull(PAmt,0.0)<>0.0 And Isnull(PAmt,0.0)-Isnull(IAmt,0.0)<>0.0)
			Begin
				Update SMS_Invoice Set BillSts='25' Where InvoiceID=@InvoiceID
				--更新项目服务的收款状态
				Update PRJ_Cost Set BillSts='25' Where '#'+BillNo=(select InvoiceNo From SMS_Invoice where InvoiceID=@InvoiceID)
			end			
		if exists(Select 1 from SMS_Invoice Where InvoiceID=@InvoiceID And Isnull(PAmt,0.0)<>0.0 And Isnull(PAmt,0.0)-Isnull(IAmt,0.0)=0.0)
			begin
				Update SMS_Invoice Set BillSts='30' Where InvoiceID=@InvoiceID	
				--更新项目服务的收款状态
				Update PRJ_Cost Set BillSts='30' Where '#'+BillNo=(select InvoiceNo From SMS_Invoice where InvoiceID=@InvoiceID)
			End
		if exists(Select 1 from SMS_Invoice Where InvoiceID=@InvoiceID And Isnull(PAmt,0.0)=0.0)
			begin
				Update SMS_Invoice Set BillSts='20' Where InvoiceID=@InvoiceID	
				--更新项目服务的收款状态
				Update PRJ_Cost Set BillSts='23' Where '#'+BillNo=(select InvoiceNo From SMS_Invoice where InvoiceID=@InvoiceID)
			End	
		fetch next from mycursor into @InvoiceID
	end
	close mycursor
	deallocate mycursor
End
go

