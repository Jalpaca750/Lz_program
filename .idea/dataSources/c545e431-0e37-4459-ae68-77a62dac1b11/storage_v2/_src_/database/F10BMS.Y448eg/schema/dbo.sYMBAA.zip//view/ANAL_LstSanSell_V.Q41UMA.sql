CREATE VIEW dbo.ANAL_LstSanSell_V
AS
SELECT a.DeptNo, b.ItemID, 
SUM(CASE LEFT(CONVERT(char(10), cast(a.CreateDate AS datetime), 120), 7) WHEN LEFT(CONVERT(char(10), dateadd(m, - 1, GetDate()), 120), 7) THEN b.SQty ELSE 0 END) AS Qty01, 
SUM(CASE LEFT(CONVERT(char(10), cast(a.CreateDate AS datetime), 120), 7) WHEN LEFT(CONVERT(char(10), dateadd(m, - 1, GetDate()), 120), 7) THEN b.Amt ELSE 0 END)  AS Amt01, 
SUM(CASE LEFT(CONVERT(char(10), cast(a.CreateDate AS datetime), 120), 7) WHEN LEFT(CONVERT(char(10), dateadd(m, - 2, GetDate()), 120), 7) THEN b.SQty ELSE 0 END) AS Qty02, 
SUM(CASE LEFT(CONVERT(char(10), cast(a.CreateDate AS datetime), 120), 7) WHEN LEFT(CONVERT(char(10), dateadd(m, - 3, GetDate()), 120), 7) THEN b.SQty ELSE 0 END) AS Qty03
FROM dbo.SMS_Stock a INNER JOIN dbo.SMS_StockDtl b ON a.StockNo = b.StockNo
WHERE (a.BillSts NOT IN ('00', '10')) AND (CONVERT(char(10), CAST(a.CreateDate AS datetime), 120) BETWEEN LEFT(CONVERT(char(10), 
      DATEADD(m, - 3, GETDATE()), 120), 7) + '-01' AND CONVERT(char(10), GETDATE(), 120))
GROUP BY a.DeptNo, b.ItemID

go

