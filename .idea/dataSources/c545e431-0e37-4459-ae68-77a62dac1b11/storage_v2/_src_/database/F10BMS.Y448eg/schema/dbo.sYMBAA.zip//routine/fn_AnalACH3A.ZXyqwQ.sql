--经办人业绩统计
--2011.03.08
--Frank
--参数
--	@StartDate:年份
--	@EndDate:月份
--	@Flag	
CREATE FUNCTION dbo.fn_AnalACH3A
(
	@StartDate VARCHAR(10),
	@EndDate VARCHAR(10),
	@Flag int
)
RETURNS @uTable TABLE(
	EmployeeID BIGINT,
	EmployeeName VARCHAR(100),
	DeptNo VARCHAR(20),
	BillAmt DECIMAL(18,6),
	ItemCount BIGINT,
	BillCount BIGINT,
	AvgItemAmt DECIMAL(18,6),
	AvgBillAmt DECIMAL(18,6),
	AvgItemCount DECIMAL(18,6),
    BillType VARCHAR(40)
)
AS
BEGIN
    IF @Flag=0
        RETURN
    --销售出库单
	INSERT INTO @uTable(EmployeeID,EmployeeName,DeptNo,BillAmt,ItemCount,BillCount,AvgItemAmt,AvgBillAmt,AvgItemCount,BillType)
	SELECT x.HandlerID,z.EmployeeName,Left(z.DeptCode,4),y.Amt,y.ItemCount,x.BillCount,
        AvgItemAmt=Case Isnull(y.ItemCount,0)
				WHEN 0 THEN 0
				Else Round(Isnull(y.Amt,0.0)/y.ItemCount,2) END,
	   	AvgBillAmt=Case Isnull(x.BillCount,0)
				WHEN 0 THEN 0
				Else Round(Isnull(y.Amt,0.0)/x.BillCount,2) END,
	   	AvgItemCount=Case Isnull(x.BillCount,0)
				WHEN 0 THEN 0
				Else Round(Isnull(y.ItemCount,0)/BillCount,2) END,'销售出库单'
	FROM (SELECT HandlerID,Count(1) AS BillCount
	 	  FROM SMS_Stock 
		  WHERE (BillSts='20' OR BillSts='25' OR BillSts='30')
			  AND (ISNULL(CreateDate,'') BETWEEN @StartDate AND @EndDate)
			  AND (ISNULL(HandlerID,0)<>0) 
		  GROUP BY HandlerID
        ) x INNER JOIN (SELECT a.HandlerID,SUM(ISNULL(b.Amt,0)) AS Amt,Count(1) AS ItemCount 
                        FROM SMS_Stock a INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
		                WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
                            AND (ISNULL(a.CreateDate,'') BETWEEN @StartDate AND @EndDate)
                            AND (ISNULL(a.HandlerID,0)<>0)
		                GROUP BY a.HandlerID
                        ) y ON x.HandlerID=y.HandlerID 
        INNER JOIN BDM_Employee z ON x.HandlerID=z.EmployeeID;
    --采购订单
    INSERT INTO @uTable(EmployeeID,EmployeeName,DeptNo,BillAmt,ItemCount,BillCount,AvgItemAmt,AvgBillAmt,AvgItemCount,BillType)
	SELECT x.HandlerID,z.EmployeeName,Left(z.DeptCode,4),y.Amt,y.ItemCount,x.BillCount,
        AvgItemAmt=Case Isnull(y.ItemCount,0)
				WHEN 0 THEN 0
				Else Round(Isnull(y.Amt,0.0)/y.ItemCount,2) END,
	   	AvgBillAmt=Case Isnull(x.BillCount,0)
				WHEN 0 THEN 0
				Else Round(Isnull(y.Amt,0.0)/x.BillCount,2) END,
	   	AvgItemCount=Case Isnull(x.BillCount,0)
				WHEN 0 THEN 0
				Else Round(Isnull(y.ItemCount,0)/BillCount,2) END,'采购订单'
	FROM (SELECT HandlerID,Count(1) AS BillCount
	 	  FROM PMS_Order 
		  WHERE (BillSts='20' OR BillSts='25' OR BillSts='30')
			  AND (ISNULL(CreateDate,'') BETWEEN @StartDate AND @EndDate)
			  AND (ISNULL(HandlerID,0)<>0) 
		  GROUP BY HandlerID
        ) x INNER JOIN (SELECT a.HandlerID,SUM(ISNULL(b.Amt,0)) AS Amt,Count(1) AS ItemCount 
                        FROM PMS_Order a INNER JOIN PMS_OrderDtl b ON a.OrderNo=b.OrderNo
		                WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
                            AND (ISNULL(a.CreateDate,'') BETWEEN @StartDate AND @EndDate)
                            AND (ISNULL(a.HandlerID,0)<>0)
		                GROUP BY a.HandlerID
                        ) y ON x.HandlerID=y.HandlerID 
        INNER JOIN BDM_Employee z ON x.HandlerID=z.EmployeeID;
    --采购入库单
    INSERT INTO @uTable(EmployeeID,EmployeeName,DeptNo,BillAmt,ItemCount,BillCount,AvgItemAmt,AvgBillAmt,AvgItemCount,BillType)
	SELECT x.HandlerID,z.EmployeeName,Left(z.DeptCode,4),y.Amt,y.ItemCount,x.BillCount,
        AvgItemAmt=Case Isnull(y.ItemCount,0)
				WHEN 0 THEN 0
				Else Round(Isnull(y.Amt,0.0)/y.ItemCount,2) END,
	   	AvgBillAmt=Case Isnull(x.BillCount,0)
				WHEN 0 THEN 0
				Else Round(Isnull(y.Amt,0.0)/x.BillCount,2) END,
	   	AvgItemCount=Case Isnull(x.BillCount,0)
				WHEN 0 THEN 0
				Else Round(Isnull(y.ItemCount,0)/BillCount,2) END,'采购入库单'
	FROM (SELECT HandlerID,Count(1) AS BillCount
	 	  FROM PMS_Stock 
		  WHERE (BillSts='20' OR BillSts='25' OR BillSts='30')
			  AND (ISNULL(CreateDate,'') BETWEEN @StartDate AND @EndDate)
			  AND (ISNULL(HandlerID,0)<>0) 
		  GROUP BY HandlerID
        ) x INNER JOIN (SELECT a.HandlerID,SUM(ISNULL(b.Amt,0)) AS Amt,Count(1) AS ItemCount 
                        FROM PMS_Stock a INNER JOIN PMS_StockDtl b ON a.StockNo=b.StockNo
		                WHERE (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
                            AND (ISNULL(a.CreateDate,'') BETWEEN @StartDate AND @EndDate)
                            AND (ISNULL(a.HandlerID,0)<>0)
		                GROUP BY a.HandlerID
                        ) y ON x.HandlerID=y.HandlerID 
        INNER JOIN BDM_Employee z ON x.HandlerID=z.EmployeeID;
	RETURN
END
go

