CREATE VIEW [dbo].[IMS_Transfer_V]
AS
SELECT a.TransferNo, a.CreateDate, a.DeptNo, f.CHName AS DeptName, a.WareHouse_O, 
      e.CHName AS WHName_O, a.WareHouse_I, d.CHName AS WHName_I, a.BillSts, 
      (SELECT StsName FROM BillStatus g WHERE a.BillSts=g.BillSts AND g.BillType = 'IMS70') AS StsName,
      a.AuditDate, a.AuditID, c.EmployeeName AS Auditer, a.PFlag, a.PrintNum, a.CreatorID, 
      b.EmployeeName AS Creator, a.PrinterID, p.EmployeeName AS Printer, a.Remarks, a.CheckBox
FROM dbo.IMS_Transfer a LEFT OUTER JOIN
      dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V f ON a.DeptNo = f.CodeID LEFT OUTER JOIN
      dbo.BDM_WareHouse_V d ON a.WareHouse_I = d.CodeID LEFT OUTER JOIN
      dbo.BDM_WareHouse_V e ON a.WareHouse_O = e.CodeID LEFT OUTER JOIN
      dbo.BDM_Employee b ON a.CreatorID = b.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee c ON a.AuditID = c.EmployeeID
go

