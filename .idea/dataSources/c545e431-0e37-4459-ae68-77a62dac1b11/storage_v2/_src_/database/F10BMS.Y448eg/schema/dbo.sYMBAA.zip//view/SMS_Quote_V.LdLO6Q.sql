CREATE VIEW dbo.SMS_Quote_V
AS
SELECT a.BillNo, a.CreateDate, a.DeptNo, e.CHName AS DeptName, a.CustID, b.CustNo, 
       	b.CustName, b.NameSpell, b.CustType, b.TypeName, b.MemberID, b.Member, 
       	b.AreaCode, b.AreaName, b.PopedomID, b.PopedomName, b.LinkMan, b.Phone, 
       	b.Faxes, b.SendAddr, a.BillSts,
	(SELECT StsName
	 FROM BillStatus g
	 WHERE g.BillType = 'SMS20' AND a.BillSts = g.BillSts) AS StsName, 
	a.QuoteType, a.DisCount, a.SalesID, f.EmployeeName AS Sales, a.AuditDate, 
	a.AuditID, d.EmployeeName AS Auditer, a.CreatorID, c.EmployeeName AS Creator,a.PFlag, 
	a.AuditingFlag,CASE a.AuditingFlag WHEN '0' THEN '否' 
			                   WHEN '1' THEN '是' END AS ISAuditing, 
	CASE WHEN a.AuditingFlag = '0' THEN '' 
	     WHEN a.AuditingStatus = '0' THEN '未通过' 
	     WHEN a.AuditingStatus = '1' THEN '通过' 
	     ELSE '' END AS BillAuditing_Result,a.AuditingPICFlag,a.BImport,a.PrintNum,a.PrinterID,
	g.EmployeeName As Printer,a.departId,h.CHName AS departName, a.Remarks, a.CheckBox
FROM dbo.SMS_Quote a LEFT OUTER JOIN
	dbo.BAS_Customer_V b ON a.CustID = b.CustID LEFT OUTER JOIN
	dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID LEFT OUTER JOIN
	dbo.BDM_Employee d ON a.AuditID = d.EmployeeID LEFT OUTER JOIN
      	dbo.BDM_DeptCode_V e ON a.DeptNo = e.CodeID LEFT OUTER JOIN
      	dbo.BDM_Employee f ON a.SalesID = f.EmployeeID LEFT OUTER JOIN
	dbo.BDM_Employee g On a.PrinterID=g.EmployeeID LEFT OUTER JOIN
        dbo.BDM_DeptCode_V h ON a.departId=h.CodeId 
go

