
-- =============================================
-- Author:		<xiaojian.He>
-- Create date: <2007-09-06以前>
-- Description:	<发货单审核、取消审核、作废等业务处理>
--		Frank 2017-09-06日 修改，商品资料增加虚拟商品功能
--		对应审核操作时，虚拟商品不扣减库存
--      对于直接做发货单的商品保存时会自动占用已分配量
-- Parameter:   
--      @StockNo—销售出库单编号
--      @Flag—操作标识  20-审核;10-取消审核;05-终止;00-作废
-- =============================================
CREATE PROCEDURE sp_SMSStockAudit
(
	@StockNo VARCHAR(20),            --销售出库单编号
	@Flag CHAR(2)
)
AS
BEGIN
    DECLARE @WareHouse VARCHAR(20),
            @DeptNo VARCHAR(20),
            @ItemID BIGINT,
            @CustID BIGINT,
            @AuditDate CHAR(10),
            @CreateDate CHAR(10),
            @Amt DECIMAL(18,6),
            @OrderNo VARCHAR(20),
            @Location VARCHAR(20),
            @SQty DECIMAL(18,6),
            @ZQty DECIMAL(18,6),
            @Price DECIMAL(18,6),
            @IsEffect BIT,
            @IsSpecial BIT,
            @IsSYSIntegral BIT,
            @Integral DECIMAL(18,6),
            @memo varchar(1000),
	        @remarks varchar(2000);
	--2009.02.11修改，在系统设置采购加税率计成本情况下，入库非定制商品不开票加上税率----
	DECLARE @STaxFlag BIT,@CTaxFlag BIT,@ErrMsg VARCHAR(4000),@ErrSeverity INT;
	--2011.11.24增加积分模式和金额积分标准,会员自动升级积分和级别
	DECLARE @IntegralMode INT,
	        @UnitIntegral DECIMAL(18,6),
            @MemberID VARCHAR(20),
            @TotalAmt DECIMAL(18,6),	
            @DepartId VARCHAR(20),
            @errors BIGINT;

	--系统积分启用标识/促销标识
    SELECT @IsSYSIntegral=ISNULL(IsSYSIntegral,0),
            @STaxFlag=STaxFlag,
            @CTaxFlag=CTaxFlag,
            @IntegralMode=ISNULL(IntegralMode,1),
            @UnitIntegral=ISNULL(UnitIntegral,0.0) 
    FROM Sys_Config;
	--获取审核后的客户、日期、出库单号
	SELECT @WareHouse=WareHouse,
            @DeptNo=DeptNo,
            @CustID=CustID,
            @AuditDate=CONVERT(VARCHAR(10),GETDATE(),23),
            @CreateDate=CreateDate,
            @Integral=ISNULL(Integral,0),
            @DepartId=DepartId,
            @memo=memo,
            @Remarks=Remarks 
	FROM SMS_Stock 
	WHERE StockNo=@StockNo;
    --出库单总金额
    SELECT @Amt=Sum(Amt) FROM SMS_StockDtl WHERE StockNo=@StockNo;
	--临时表
	CREATE TABLE #Tmp(DeptNo VARCHAR(20),WareHouse VARCHAR(20),ItemID BIGINT,SQty DECIMAL(18,6),AQty DECIMAL(18,6));
	
    SET @errors=0;
    BEGIN TRANSACTION;
    --排队等待
    WHILE EXISTS(SELECT * FROM dbo.SAM_Schedule WHERE jobCode='inv_posting_job' AND IsLocked=1)
    BEGIN
        SET @errors=0;
    END
    UPDATE dbo.SAM_Schedule SET IsLocked=1,lockedProc='sp_SMSStockAudit' WHERE jobCode='inv_posting_job';
    --汇总数据
	INSERT INTO #Tmp(DeptNo,WareHouse,ItemID,SQty,AQty)
	SELECT @DeptNo,@WareHouse,a.ItemID,SUM(ISNULL(a.SQty,0.0)+ISNULL(a.ZQty,0.0)),
        SUM(CASE ISNULL(a.OrderID,0) WHEN 0 THEN 0 ELSE ISNULL(a.SQty,0.0)+ISNULL(a.ZQty,0.0) END)
	FROM SMS_StockDtl a
        INNER JOIN BDM_ItemInfo b ON a.ItemId=b.ItemId
	WHERE a.StockNo=@StockNo
        AND ISNULL(b.IsVirtual,0)=0
	GROUP BY a.ItemID;
	SET @errors=@errors+@@ERROR;
	--系统启用了积分功能,且客户参与积分功能	
	IF EXISTS(SELECT 1 FROM BDM_Customer WHERE CustID=@CustID AND ISNULL(IsIntegral,1)=1 AND ISNULL(@IsSYSIntegral,0)=1)
    BEGIN
		--按单位数量积分
		IF (ISNULL(@IntegralMode,1)=1)
			SELECT @Integral=SUM(ISNULL(b.SQty,0.0)*ISNULL(b.Integral,0.0)) 
			FROM SMS_Stock a 
			    INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
			    INNER JOIN BDM_Customer c ON a.CustID=c.CustID
			WHERE (a.StockNo=@StockNo) AND (CONVERT(VARCHAR(10),a.CreateDate,120)>CONVERT(VARCHAR(10),c.zj_ql_Date,120));
		ELSE IF (ISNULL(@IntegralMode,1)=2)
			SELECT @Integral=ISNULL(@Amt,0.0)/@UnitIntegral
			FROM SMS_Stock a Inner Join BDM_Customer c ON a.CustID=c.CustID
			WHERE (a.StockNo=@StockNo) AND (CONVERT(VARCHAR(10),a.CreateDate,120)>CONVERT(VARCHAR(10),c.zj_ql_Date,120)); 
		ELSE IF (ISNULL(@IntegralMode,1)=3)
			SET @Integral=0.0;
	END
	ELSE
	BEGIN
		SET @Integral=0.0;
	END
	SET @errors=@errors+@@ERROR;
	--审核
	IF (@Flag='20')
	BEGIN 
        --客户欠款数量增加
        UPDATE BDM_Customer SET ArgAmt=ISNULL(ArgAmt,0.0)+ISNULL(@Amt,0.0),Integral=ISNULL(Integral,0.0)+ISNULL(@Integral,0.0)
        WHERE CustID=@CustID;
        SET @errors=@errors+@@ERROR;
        --如果设置了会员自动升级，则升级会员级别
        IF (ISNULL(@IntegralMode,1)=3)
        BEGIN
	        --审核前的销售额
	        SELECT @TotalAmt=SUM(b.Amt)
	        FROM SMS_Stock a 
	            INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
	        WHERE a.CustID=@CustID AND (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30');
	        --获取当前金额下的最高级会员
	        SELECT @MemberID=MemberID
	        FROM (SELECT TOP 1 MemberID FROM SPM_Integral WHERE UpAmt<=ISNULL(@TotalAmt,0.0)+ISNULL(@Amt,0.0) ORDER BY UpAmt DESC) t;					
	        --更新会员级别
	        UPDATE BDM_Customer SET MemberID=@MemberID WHERE CustID=@CustID AND (ISNULL(@MemberID,'')<>'');
	        SET @errors=@errors+@@ERROR;
        END
        --写入客户开票资料
        IF EXISTS(SELECT * FROM Web_InvoiceInfo WHERE OrderNo IN(SELECT OrderNo FROM SMS_StockDtl WHERE StockNo=@StockNo))
        BEGIN
            INSERT INTO SMS_StockEx(stockNo,invoiceFlag,invoiceCompany,invoiceAddress,invoiceTel,invoiceTax,invoiceAccount,invoiceBank)
            SELECT TOP 1 @StockNo,invoiceType,companyName,companyAdd,companyPhone,companySh,companyYhzh,companyKhh
            FROM Web_InvoiceInfo
            WHERE OrderNo IN(SELECT OrderNo FROM SMS_StockDtl WHERE StockNo=@StockNo);
        END
        ELSE
        BEGIN
            INSERT INTO SMS_StockEx(stockNo,invoiceFlag,invoiceCompany,invoiceAddress,invoiceTel,invoiceTax,invoiceAccount,invoiceBank)
            SELECT TOP 1 @StockNo,invoiceFlag,invoiceCompany,invoiceAddress,invoiceTel,invoiceTax,invoiceAccount,invoiceBank
            FROM BAS_CustomerInvoice
            WHERE CustomerId=CAST(@CustID AS VARCHAR(20))
                AND ISNULL(IsDefault,1)=1;
        END
        --写入流水帐
        INSERT INTO IMS_Flow(BillNo,BillType,DeptNo,WareHouse,ItemID,SQty,Price,Amt,CreateDate,AuditDate,DepartId,memo,wmsBillNo,remarks)
        SELECT a.StockNo,'销售出库单',@DeptNo,@WareHouse,a.ItemID,-(ISNULL(a.SQty,0.0)+ISNULL(a.ZQty,0.0)),Price,-ISNULL(Amt,0.0),
	        @CreateDate,@AuditDate,@DepartId,@memo,@StockNo,@remarks
        FROM SMS_StockDtl a
            INNER JOIN BDM_ItemInfo b ON a.ItemID=b.ItemID
        WHERE StockNo=@StockNo 
            AND ISNULL(b.IsVirtual,0)=0
            AND NOT EXISTS(SELECT 1 FROM IMS_Flow WHERE BillNo=@StockNo);
        SET @errors=@errors+@@ERROR;        
		--更商品资料总库存
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0)
		FROM BDM_ItemInfo a 
		    INNER JOIN #Tmp b ON a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;
		--更新分部库存总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0),a.AllocQty=ISNULL(a.AllocQty,0.0)-ISNULL(b.AQty,0.0)
		FROM IMS_Subdepot a 
		    INNER JOIN #Tmp b ON a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID;
        SET @errors=@errors+@@ERROR;
		--插入没有的分部库存
		INSERT INTO IMS_Subdepot(DeptNo,ItemID,OnHandQty)
		SELECT @DeptNo,ItemID,-SQty
		FROM #Tmp a
		WHERE NOT EXISTS(SELECT 1 FROM IMS_Subdepot b WHERE a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID);
		SET @errors=@errors+@@ERROR;		
		--更新库房总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)-ISNULL(b.SQty,0.0),a.LastTime=GETDATE(),a.LastODate=CONVERT(VARCHAR(10),GETDATE(),23) 
		FROM IMS_Ledger a 
		    INNER JOIN #Tmp b ON a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID; 
		SET @errors=@errors+@@ERROR;    
		--插入没有商品
		INSERT INTO IMS_Ledger(DeptNo,WareHouse,ItemID,OnHandQty,LastTime,LastODate)
		SELECT DeptNo,WareHouse,ItemID,-SQty,GETDATE(),CONVERT(VARCHAR(10),GETDATE(),23)
		FROM #Tmp a
		WHERE NOT EXISTS(SELECT 1 FROM IMS_Ledger b WHERE a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID);
        SET @errors=@errors+@@ERROR;         
		--更新库房总帐相关数据
		DECLARE myCursor CURSOR
		FOR SELECT a.ItemID,a.OrderNo,a.Location,a.SQty,a.ZQty,a.Price,a.IsEffect,a.IsSpecial 
		    FROM SMS_StockDtl a
		        INNER JOIN BDM_ItemInfo b ON a.ItemId=b.ItemId
		    WHERE a.StockNo=@StockNo AND ISNULL(b.IsVirtual,0)=0
		    ORDER BY stockId;
        OPEN myCursor;
        FETCH NEXT FROM mycursor INTO @ItemID,@OrderNo,@Location,@SQty,@ZQty,@Price,@IsEffect,@IsSpecial;
        WHILE @@FETCH_STATUS=0
        BEGIN
            --更新单价
            IF ISNULL(@IsSpecial,0)=0
	        BEGIN
		        IF EXISTS(SELECT 1 FROM SMS_Price WHERE CustID=@CustID AND ItemID=@ItemID)--更新单价					
			        UPDATE SMS_Price SET Price=@Price,LastDate=@CreateDate
			        WHERE CustID=@CustID 
			            AND ItemID=@ItemID 
			            AND ISNULL(@Price,0.0)>0.0 
			            AND ISNULL(@IsEffect,1)=1
				        AND EXISTS(SELECT 1 FROM BDM_Customer WHERE CustID=@CustID AND ISNULL(LockPrice,0)=0);
		        ELSE
			        INSERT INTO SMS_Price(CustID,ItemID,Price,LastDate)
			        SELECT CustID,@ItemID,@Price,@CreateDate
			        FROM BDM_Customer
			        WHERE CustID=@CustID 
			            AND ISNULL(LockPrice,0)=0 
			            AND ISNULL(@IsEffect,1)=1 
			            AND ISNULL(@Price,0.0)>0.0;
			    SET @errors=@errors+@@ERROR;							
	        END
            --更新库房总帐相关数据
            UPDATE IMS_Ledger SET LastOPrice=CASE WHEN ISNULL(@Price,0.0)>0.0 THEN @Price ELSE LastOPrice END,
	                              Location=CASE ISNULL(@Location,'') WHEN '' THEN Location ELSE @Location END,
	                              LastODate=@CreateDate,LastTime=GETDATE()
            WHERE WareHouse=@WareHouse AND ItemID=@ItemID;
            SET @errors=@errors+@@ERROR;
            FETCH NEXT FROM myCursor INTO @ItemID,@OrderNo,@Location,@SQty,@ZQty,@Price,@IsEffect,@IsSpecial
        END
        CLOSE myCursor;
        DEALLOCATE myCursor;
        --处理定制品含税与非含税             
        --20090211增加，在系统设置采购加税率计成本情况下，入库非定制商品不开票加上税率----
		IF (@STaxFlag=1) AND (@CTaxFlag=0)
		BEGIN
            UPDATE a SET a.CPrice=ISNULL(b.Price,0.0)*1.13
            FROM SMS_StockDtl a 
                INNER JOIN PMS_StockDtl b ON a.OrderID=b.XS_OrderID 
            WHERE a.StockNo=@StockNo AND ISNULL(a.IsSpecial,0)=1 AND ISNULL(b.TaxFlag,0)=1;
            SET @errors=@errors+@@ERROR;
		END
		ELSE IF (@STaxFlag=0) AND (@CTaxFlag=1)
		BEGIN
			UPDATE a SET a.CPrice=ISNULL(b.Price,0)/1.13
			FROM SMS_StockDtl a 
			    INNER JOIN PMS_StockDtl b ON a.OrderID=b.XS_OrderID 
			WHERE a.StockNo=@StockNo AND ISNULL(a.IsSpecial,0)=1 AND ISNULL(a.TaxFlag,0)=1;
			SET @errors=@errors+@@ERROR;
		END
		ELSE IF (@STaxFlag=1) AND (@CTaxFlag=1)
		BEGIN
			UPDATE a SET a.CPrice=ISNULL(b.Price,0)*1.13
			FROM SMS_StockDtl a 
			    INNER JOIN PMS_StockDtl b ON a.OrderID=b.XS_OrderID 
			WHERE a.StockNo=@StockNo AND ISNULL(a.IsSpecial,0)=1 AND ISNULL(b.TaxFlag,0)=1;
			SET @errors=@errors+@@ERROR;
			UPDATE a SET a.CPrice=ISNULL(b.Price,0)/1.13
			FROM SMS_StockDtl a 
			    INNER JOIN PMS_StockDtl b ON a.OrderID=b.XS_OrderID 
			WHERE a.StockNo=@StockNo AND ISNULL(a.IsSpecial,0)=1 AND ISNULL(a.TaxFlag,0)=1;
			SET @errors=@errors+@@ERROR;
			UPDATE a SET a.CPrice=ISNULL(b.Price,0) 
			FROM SMS_StockDtl a 
			    INNER JOIN PMS_StockDtl b ON a.OrderID=b.XS_OrderID 
			WHERE a.StockNo=@StockNo AND ISNULL(a.IsSpecial,0)=1 AND ISNULL(a.TaxFlag,0)=1 AND ISNULL(b.TaxFlag,0)=1;
			SET @errors=@errors+@@ERROR;
		END
		------------------------------------------------------------------------------------------------
	END
	ELSE IF (@Flag='10')
	BEGIN
		--客户欠款数量减少,积分减少
		UPDATE BDM_Customer SET ArgAmt=ISNULL(ArgAmt,0.0)-ISNULL(@Amt,0.0),Integral=ISNULL(Integral,0.0)-ISNULL(@Integral,0.0)
		WHERE CustID=@CustID;
		SET @errors=@errors+@@ERROR;
		--如果设置了会员自动升级，则升级会员级别
		IF (ISNULL(@IntegralMode,1)=3)
		BEGIN
			--审核前的销售额
			SELECT @TotalAmt=SUM(b.Amt)
			FROM SMS_Stock a 
			    INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
			WHERE a.CustID=@CustID AND (a.BillSts='20' OR a.BillSts='25' OR a.BillSts='30');
			--获取当前金额下的最高级会员
			SELECT TOP 1 @MemberID=MemberID FROM SPM_Integral WHERE UpAmt<=ISNULL(@TotalAmt,0.0) ORDER BY UpAmt DESC;					
			--更新会员级别
			UPDATE BDM_Customer SET MemberID=@MemberID WHERE CustID=@CustID AND ISNULL(@MemberID,'')<>'';
			SET @errors=@errors+@@ERROR; 
		END
        --删除开票资料
        DELETE FROM SMS_StockEx WHERE StockNo=@StockNo;
		--从流水帐删除
		DELETE FROM IMS_Flow WHERE BillNo=@StockNo;
		SET @errors=@errors+@@ERROR;
		--更商品资料总库存
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0)
		FROM BDM_ItemInfo a 
		    INNER JOIN #Tmp b ON a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR;
		--更新分部库存总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0),a.AllocQty=ISNULL(a.AllocQty,0.0)+ISNULL(b.AQty,0.0)
		FROM IMS_Subdepot a 
		    INNER JOIN #Tmp b ON a.DeptNo=b.DeptNo AND a.ItemID=b.ItemID;
		--更新库房总帐
		UPDATE a SET a.OnHandQty=ISNULL(a.OnHandQty,0.0)+ISNULL(b.SQty,0.0),a.LastTime=GETDATE()
		FROM IMS_Ledger a 
		    INNER JOIN #Tmp b ON a.WareHouse=b.WareHouse AND a.ItemID=b.ItemID;
		SET @errors=@errors+@@ERROR; 
	END
	ELSE IF (@Flag='00')		--作废单据
	BEGIN
		--已出库数量更新
		UPDATE a SET a.SQty=ISNULL(a.SQty,0.0)-ISNULL(b.SQty,0.0),a.SZQty=ISNULL(a.SZQty,0.0)-ISNULL(b.ZQty,0.0)
		FROM SMS_OrderDtl a
		    INNER JOIN SMS_StockDtl b ON a.OrderID=b.OrderID
		WHERE b.StockNo=@StockNo;
		SET @errors=@errors+@@ERROR;
		--更新订单
		DECLARE myCursors CURSOR
		FOR SELECT DISTINCT OrderNo FROM SMS_StockDtl WHERE StockNo=@StockNo;
		OPEN myCursors;
		FETCH NEXT FROM myCursors INTO @OrderNo;
		WHILE @@FETCH_STATUS=0
		BEGIN
			--存在未执行的记录
			IF EXISTS(SELECT 1 FROM SMS_OrderDtl WHERE ISNULL(SQty,0.0)>0.0 AND OrderNo=@OrderNo)
				UPDATE SMS_Order SET BillSts='25' WHERE OrderNo=@OrderNo AND BillSts<>'05'
			ELSE
				UPDATE SMS_Order SET BillSts='20' WHERE OrderNo=@OrderNo And BillSts<>'05'
			SET @errors=@errors+@@ERROR;	
			FETCH NEXT FROM myCursors INTO @OrderNo;
		END
		CLOSE myCursors;
		DEALLOCATE myCursors;
	END
    UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='inv_posting_job';
    SET @errors=@errors+@@ERROR;
	--错误处理
	IF (@errors=0)
	BEGIN
	    COMMIT;
	END
	ELSE
	BEGIN
	    IF @@TRANCOUNT > 0
			 ROLLBACK;
		SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;	
        UPDATE dbo.SAM_Schedule SET IsLocked=0,lockedProc='' WHERE jobCode='inv_posting_job';
		--写入同步错误日志	
		INSERT INTO SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),'01',GETDATE(),'99','sp_SMSStockAudit','SMS_STOCK_AUIDT_ERROR',LEFT(@ErrMsg,2000),@StockNo,@StockNo);
		RAISERROR(@ErrMsg, @ErrSeverity, 1);
	END
END

go

