
--送货方式
CREATE VIEW dbo.BDM_SendMode_V
AS
SELECT CodeID, CodeNo, CHName, ENName, Flag, Classify,CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL13')
go

