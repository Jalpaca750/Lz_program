--零售收款审核(Update)
--2005-01-25
--Devil.H
--当上述操作发生时：
--更新销售发票已付款金额……
--零售收款审核(Update)
--2005-01-25
--Devil.H
--当上述操作发生时：
--更新销售发票已付款金额……
CREATE Proc sp_SMSGatherAudit
(
	@GatheringNo varchar(20),
	@Flag char(2)
)
As
Begin
	--验收（商品资料中可用量减少）
	if @Flag='20'			--单据状态
		Update a Set a.BillSts='已交款'
		From SMS_Shift a,SMS_GatheringDtl b
		Where a.ShiftNo=b.ShiftNo And b.GatheringNo=@GatheringNo
	--取消验收（商品资料中可用量增加）
	if @Flag='10'
		Update a Set a.BillSts='未交款'
		From SMS_Shift a,SMS_GatheringDtl b
		Where a.ShiftNo=b.ShiftNo And b.GatheringNo=@GatheringNo
End
go

