CREATE  Function [dbo].[fn_ItemInfo]
(
	@DeptNo varchar(20),
	@CustID bigint,
	@ClassID varchar(20),
	@LabelID varchar(20),
	@Flag int=1
)
Returns @uTable Table(
	ItemID bigint,
	ItemNo varchar(20),
	ItemName varchar(200),
	ItemSpec varchar(100),
	ColorName varchar(40),
	UnitName varchar(40),
	ClassID varchar(20),
	ClassName varchar(100),
	LabelID varchar(20),
	LabelName varchar(100),
	ItemAlias varchar(200),
	Barcode varchar(100),
	NameSpell varchar(200),
	Defined1 varchar(200),
	Defined2 varchar(200),
	Defined3 varchar(200),
	Defined4 varchar(200),
	Defined5 varchar(200),
	BPackage varchar(40),
	MPackage varchar(40),
	Package varchar(40),
	SPrice decimal(18,6),
	SPrice1 decimal(18,6),
	SPrice2 decimal(18,6),
	SPrice3 decimal(18,6),
	PPrice decimal(18,6),
	OQty decimal(18,6),
	Price decimal(18,6),
	PurDays varchar(40),
	HotFlag bit,
	ItemPHFlag varchar(1),
	ItemPHName varchar(20),
	HisFlag varchar(10),
	LastDate varchar(10),
	OnHandQty decimal(18,6),
	AvailQty decimal(18,6),
	YZStockQty decimal(18,6),
	YZStock_Qty decimal(18,6),
	Remarks varchar(2000),
	PromotionInfo varchar(2000)
	Primary Key(ItemID)
)  
As 
Begin 
	If @Flag=0 
		Return
	--历史商品	 
	If @Flag=1
		Insert Into @uTable(ItemID,ItemNo,ItemName,ItemSpec,ColorName,UnitName,ClassID,ClassName,
			LabelID,LabelName,ItemAlias,BarCode,NameSpell,Defined1,Defined2,Defined3,Defined4,
			Defined5,BPackage,MPackage,Package,SPrice,SPrice1,SPrice2,SPrice3,PPrice,OQty,Price,
			PurDays,HotFlag,ItemPHFlag,ItemPHName,Remarks,PromotionInfo,HisFlag,LastDate)
		SELECT g.ItemID,g.ItemNo,g.ItemName,g.ItemSpec,g.ColorName,g.UnitName,g.ClassID,g.ClassName,
			g.LabelID,g.LabelName,g.ItemAlias,g.BarCode,g.NameSpell,g.Defined1,g.Defined2,
			g.Defined3,g.Defined4,g.Defined5,g.BPackage,g.mPackage,g.Package,g.SPrice,g.SPrice1,
			g.SPrice2,g.SPrice3,g.PPrice,Null AS OQty,p.Price,g.PurDays,g.HotFlag,
			g.ItemPHFlag,CASE g.ItemPHFlag WHEN 'P' THEN '批号' 
							WHEN 'S' THEN '序列号' 
							ELSE '都不管理' END AS ItemPHName,g.Remarks,g.PromotionInfo,
			'0-历史商品' AS HisFlag,p.LastDate
		FROM dbo.BAS_Goods_V g Inner Join SMS_Price p On p.CustID=@CustID And p.ItemID=g.ItemID
		WHERE g.Flag='1' And (g.ClassID Like @ClassID + '%') And (g.LabelID Like @LabelID + '%')
		Option(Fast 10)	
	Else
		Insert Into @uTable(ItemID,ItemNo,ItemName,ItemSpec,ColorName,UnitName,ClassID,ClassName,
			LabelID,LabelName,ItemAlias,BarCode,NameSpell,Defined1,Defined2,Defined3,Defined4,
			Defined5,BPackage,MPackage,Package,SPrice,SPrice1,SPrice2,SPrice3,PPrice,OQty,Price,
			PurDays,HotFlag,ItemPHFlag,ItemPHName,Remarks,PromotionInfo,HisFlag,LastDate)
		SELECT g.ItemID,g.ItemNo,g.ItemName,g.ItemSpec,g.ColorName,g.UnitName,g.ClassID,g.ClassName,
			g.LabelID,g.LabelName,g.ItemAlias,g.BarCode,g.NameSpell,g.Defined1,g.Defined2,
			g.Defined3,g.Defined4,g.Defined5,g.BPackage,g.mPackage,g.Package,g.SPrice,g.SPrice1,
			g.SPrice2,g.SPrice3,g.PPrice,Null AS OQty,Null AS Price,g.PurDays,g.HotFlag,
			g.ItemPHFlag,CASE g.ItemPHFlag WHEN 'P' THEN '批号' 
							WHEN 'S' THEN '序列号' 
							ELSE '都不管理' END AS ItemPHName,g.Remarks,g.PromotionInfo,
			'1-普通商品' AS HisFlag,Null As LastDate
		FROM dbo.BAS_Goods_V g 
		WHERE g.Flag='1' And (g.ClassID Like @ClassID + '%') And (g.LabelID Like @LabelID + '%')
		Option(Fast 10)
	--更新库存
	Update a Set a.OnhandQty=Isnull(b.OnhandQty,0.0),
			     a.AvailQty=Isnull(b.AvailQty,0.0),
                 a.YZStockQty=Isnull(b.YZStockQty,0.0),
                 a.YZStock_Qty=ISNULL(b.OnHandQty,0.0)-ISNULL(b.YZStockQty,0.0)
	From @uTable a Inner Join 
		(SELECT t1.ItemID,t1.OnHandQty,Isnull(t1.OnHandQty,0.0)-Isnull(t1.AllocQty,0.0) As AvailQty,t2.Qty As YZStockQty
		 FROM dbo.IMS_Subdepot t1 LEFT OUTER JOIN 
			  dbo.IMS_YZStock_Sum_DeptID_V t2 ON t1.DeptNo=t2.DeptNo And t1.ItemID=t2.ItemID
		 WHERE t1.DeptNo=@DeptNo) b On a.ItemID=b.ItemID 
	If (@Flag<>1) 	
		Update a Set a.Price=b.Price,
					 a.LastDate=b.LastDate,
					 a.HisFlag='0-历史商品'
		From @uTable a Inner Join SMS_Price b On b.CustID=@CustID And a.ItemID=b.ItemID	
	Return
End
go

