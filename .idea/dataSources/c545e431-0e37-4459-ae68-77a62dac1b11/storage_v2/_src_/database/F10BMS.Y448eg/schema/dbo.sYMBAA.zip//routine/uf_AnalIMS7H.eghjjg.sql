

--说明：入出库数量月报表
--作者：Devil.H
--创建：2007.11.04
--参数：@Period:会计月份
CREATE function dbo.uf_AnalIMS7H
(
	@OldPeriod char(6),
	@StartDate varchar(10),
	@EndDate varchar(10)
)
Returns Table 
As 
Return
	Select DeptNo,ItemID,Sum(QCQty) as QCQty,Sum(QCAmt) as QCAmt,Sum(CGRK) as CGRK,
		Sum(DBRK) as DBRK,Sum(ZPRK) as ZPRK,Sum(QTRK) as QTRK,Sum(ZZRK) as ZZRK,
		Sum(CXRK) as CXRK,Sum(PDRK) as PDRK,Sum(XSCK) as XSCK,Sum(LSCK) as LSCK,
		Sum(DBCK) as DBCK,Sum(ZPCK) as ZPCK,Sum(QTCK) as QTCK,Sum(ZZCK) as ZZCK,
		Sum(CXCK) as CXCK,Sum(QMQty) as QMQty
	From (Select DeptNo,ItemID,0 as QCQty,0 as QCAmt,
			CGRK=Sum(Case BillType when '采购入库单' then Isnull(SQty,0) else 0 end)
				+Sum(Case BillType when '采购退货单' then Isnull(SQty,0) else 0 end),
			DBRK=Sum(Case BillType when '调拨入库单' then Isnull(SQty,0) else 0 end),
			ZPRK=Sum(Case BillType when '赠品入库单' then Isnull(SQty,0) else 0 end),
			QTRK=Sum(Case BillType when '其他入库单' then Isnull(SQty,0) else 0 end)
				+Sum(Case BillType when '库存初始化' then Isnull(SQty,0) else 0 end),
			ZZRK=Sum(Case BillType when '组装入库单' then Isnull(SQty,0) else 0 end),
			CXRK=Sum(Case BillType when '拆卸入库单' then Isnull(SQty,0) else 0 end),
			PDRK=Sum(Case BillType when '盘存清单' then Isnull(SQty,0) else 0 end),
			XSCK=Sum(Case BillType when '销售出库单' then Isnull(SQty,0) else 0 end)
				+Sum(Case BillType when '销售退货单' then Isnull(SQty,0) else 0 end),
			LSCK=Sum(Case BillType when '零售出库单' then Isnull(SQty,0) else 0 end)
				+Sum(Case BillType when '零售退货单' then Isnull(SQty,0) else 0 end),
			DBCK=Sum(Case BillType when '调拨出库单' then Isnull(SQty,0) else 0 end),
			ZPCK=Sum(Case BillType when '赠品出库单' then Isnull(SQty,0) else 0 end),
			QTCK=Sum(Case BillType when '其他出库单' then Isnull(SQty,0) else 0 end)
				+Sum(Case BillType when '报损出库单' then Isnull(SQty,0) else 0 end),
			ZZCK=Sum(Case BillType when '组装出库单' then Isnull(SQty,0) else 0 end),
			CXCK=Sum(Case BillType when '拆卸出库单' then Isnull(SQty,0) else 0 end),0 as QMQty
		From IMS_Flow
		Where CreateDate Between @StartDate And @EndDate
		Group By DeptNo,ItemID
		Union All
		Select DeptNo,ItemID,QMQty,QMAmt,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
		From ANAL_IMS7H
		Where Period=@OldPeriod) a
	Group By DeptNo,ItemID

go

