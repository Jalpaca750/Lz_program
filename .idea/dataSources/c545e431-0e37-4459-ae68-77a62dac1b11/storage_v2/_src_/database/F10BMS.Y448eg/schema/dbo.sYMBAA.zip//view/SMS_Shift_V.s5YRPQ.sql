CREATE  VIEW dbo.SMS_Shift_V
AS
SELECT a.ShiftNo, a.DeptNo, d.CHName AS DeptName, a.PCNo, a.CreatorID, a.CreateDate,
      b.EmployeeName AS Creator, a.LstDate, a.PrintDate, a.RestAmt,a.XSAmt,a.MSAmt, 
      a.Amt,a.PAmt,a.RemAmt, e.PayAmt,e.LAmt,e.SAmt,a.BillSts, a.ReceiverID, c.EmployeeName AS Receiver, a.Remarks, 
      a.CheckBox
FROM dbo.SMS_Shift a LEFT OUTER JOIN
      dbo.BDM_DeptCode_V d ON a.DeptNo = d.CodeID LEFT OUTER JOIN
      dbo.BDM_Employee c ON a.ReceiverID = c.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee b ON a.CreatorID = b.EmployeeID LEFT OUTER JOIN
	(Select ShiftNo,Sum(PayAmt) as PayAmt,Sum(LAmt) as LAmt,Sum(SAmt) as SAmt 
	 From SMS_GatheringDtl 
	 Group By ShiftNo) e ON a.ShiftNo=e.ShiftNo
go

