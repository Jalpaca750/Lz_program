CREATE VIEW dbo.SMS_Monitor_V
AS
SELECT a.CreateDate,'1-送货单' AS BillType, a.StockNo, c.CustName,a.SendDate,c.LineName, a.SendAddr, 
      a.WLFlag, PH_DateTime,a.BoxupSts,a.BoxupTime, a.CarNumberSts, ISNULL(t.CarNumber,sl.CHName) AS CarNumber, 
      a.CarNumberDate,ISNULL(e.EmployeeName,sl.CHName) AS DeliveryMan, a.SignName,a.SignDate, 
      CASE DateDiff(d, a.SendDate, GetDate()) WHEN 0 THEN 1 ELSE 2 END AS ViewOrder,a.Remarks
FROM SMS_Stock a INNER JOIN
      BDM_SendAddress_V c ON a.CustID=c.CustID AND a.SendAddr=c.SendAddr LEFT OUTER JOIN
      (SELECT c.CHName AS CarNumber, y.BillNo
       FROM SMS_CarNumber x INNER JOIN
             SMS_CarNumberDtl y ON x.CarNumberNo = y.CarNumberNo INNER JOIN
             BDM_CarNo_V c ON x.CarNo = c.CodeID) t ON a.StockNo = t .BillNo LEFT OUTER JOIN
      BDM_Employee e ON a.Delivery = e.EmployeeID LEFT OUTER JOIN
      (SELECT l.stockNo,m.CHName,l.logisticsTime
       FROM SMS_Stock_Logistics l INNER JOIN BDM_CarNo_V m ON l.logisticsID=m.CodeID) sl ON a.stockNo=sl.stockNo
WHERE (a.BillSts = '20') And (a.BillType='10') AND (Isnull(SignName, '') = '') AND ISNULL(a.BackDate,'')=''
UNION ALL
SELECT a.CreateDate,'2-发票' AS BillType, a.InvoiceNo, c.CustName,a.CreateDate, c.LineName, c.SendAddr, '已配货' AS WLFlag, 
      GetDate() AS PH_DateTime,'已装箱' AS BoxupSts,GetDate() As BoxupTime, a.CarNumberSts, t .CarNumber, 
      a.CarNumberDate,e.EmployeeName AS BackerName, a.SignName,NULL, CASE DateDiff(d, a.CreateDate, 
      GetDate()) WHEN 0 THEN 1 ELSE 2 END AS ViewOrder,a.Remarks
FROM SMS_Invoice a INNER JOIN
      BDM_SendAddress_V c ON a.CustID = c.CustID AND a.SendAddr=c.SendAddr LEFT OUTER JOIN
      (SELECT c.CHName AS CarNumber, y.BillNo
       FROM SMS_CarNumber x INNER JOIN
             SMS_CarNumberDtl y ON x.CarNumberNo = y.CarNumberNo INNER JOIN
             BDM_CarNo_V c ON x.CarNo = c.CodeID) t ON a.InvoiceNo = t .BillNo LEFT OUTER JOIN
      BDM_Employee e ON a.BackerID = e.EmployeeID
WHERE (BillSts = '20') AND (Isnull(SignName, '') = '') AND (LEFT(InvoiceNo, 1) <> '$') AND ISNULL(a.BackDate,'')=''
go

