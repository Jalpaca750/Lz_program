CREATE VIEW dbo.CST_Colligate_COST_LstMonth_V
AS
select A.Period,A.itemid,A.COST From CST_Colligate_COST_Year_V A,
(select max(period) As Period,itemid from CST_Colligate_COST_Year_V group by itemid) B
where A.Period=B.Period And A.itemid=B.itemid
go

