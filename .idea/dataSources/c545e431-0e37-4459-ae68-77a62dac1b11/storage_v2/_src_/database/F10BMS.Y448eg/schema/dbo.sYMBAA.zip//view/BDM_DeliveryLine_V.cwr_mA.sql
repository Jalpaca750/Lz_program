



--配送线路
CREATE VIEW dbo.BDM_DeliveryLine_V
AS
SELECT CodeID, CodeNo, CHName, ENName, Flag,Classify, CheckBox
FROM dbo.BDM_Code
WHERE (Classify = 'FL30')
go

