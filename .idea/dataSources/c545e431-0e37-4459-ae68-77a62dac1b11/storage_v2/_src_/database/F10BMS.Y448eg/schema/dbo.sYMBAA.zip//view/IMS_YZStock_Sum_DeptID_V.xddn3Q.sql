
CREATE VIEW dbo.IMS_YZStock_Sum_DeptID_V
AS
SELECT b.DeptNo,a.ItemID,sum(QTY) AS QTY
FROM dbo.IMS_YZStock a,BDM_WareHouse_V b
where a.WareHouseID=b.CodeID
GROUP BY b.DeptNo,a.ItemID







go

