--说明：客户年度销售额分析
--作者：Devil.H
--创建：2007.11.16
--参数：
--	@Years:年度
--	@CorpNo:公司
--	@DeptNo:部门
--	@Flag
CREATE  Function [dbo].[fn_AnalSMS60]
(
	@Years int=0,
	@CorpNo varchar(2)='',
	@DeptNo varchar(20)='',
	@Flag bit=0)
Returns @uTable Table(
	CustID bigint,
	CustNo varchar(20),
	CustName varchar(200),
	NameSpell varchar(200),
	CustType varchar(20),
	TypeName varchar(100),
	MemberID varchar(20),
	Member varchar(100),
	AreaCode Varchar(20),
	AreaName varchar(100),
	PopedomID varchar(20),
	PopedomName varchar(100),
	KindName varchar(100),
	TradeName varchar(100),
	SalesID bigint,
	Sales varchar(100),
	Month01Amt decimal(18,6),
	Month02Amt decimal(18,6),
	Month03Amt decimal(18,6),
	Month04Amt decimal(18,6),
	Month05Amt decimal(18,6),
	Month06Amt decimal(18,6),
	Month07Amt decimal(18,6),
	Month08Amt decimal(18,6),
	Month09Amt decimal(18,6),
	Month10Amt decimal(18,6),
	Month11Amt decimal(18,6),
	Month12Amt decimal(18,6),
	TotalAmt decimal(18,6),
	LinkMan varchar(40),
	Phone varchar(80),
	Faxes varchar(40),
	DepartId varchar(20),
	DepartName varchar(100)
)
As
Begin
	if @Flag=0 
		Return
	Insert Into @uTable(CustID,SalesID,DepartId,Month01Amt,Month02Amt,Month03Amt,Month04Amt,Month05Amt,Month06Amt,Month07Amt,
		Month08Amt,Month09Amt,Month10Amt,Month11Amt,Month12Amt,TotalAmt)
	Select a.CustID,a.SalesID, a.DepartId,
		Month01Amt=sum(case Month(a.CreateDate) when 1 then b.Amt else 0.0 end),
		Month02Amt=sum(case Month(a.CreateDate) when 2 then b.Amt else 0.0 end),
		Month03Amt=sum(case Month(a.CreateDate) when 3 then b.Amt else 0.0 end),
		Month04Amt=sum(case Month(a.CreateDate) when 4 then b.Amt else 0.0 end),
		Month05Amt=sum(case Month(a.CreateDate) when 5 then b.Amt else 0.0 end),
		Month06Amt=sum(case Month(a.CreateDate) when 6 then b.Amt else 0.0 end),
		Month07Amt=sum(case Month(a.CreateDate) when 7 then b.Amt else 0.0 end),
		Month08Amt=sum(case Month(a.CreateDate) when 8 then b.Amt else 0.0 end),
		Month09Amt=sum(case Month(a.CreateDate) when 9 then b.Amt else 0.0 end),
		Month10Amt=sum(case Month(a.CreateDate) when 10 then b.Amt else 0.0 end),
		Month11Amt=sum(case Month(a.CreateDate) when 11 then b.Amt else 0.0 end),
		Month12Amt=sum(case Month(a.CreateDate) when 12 then b.Amt else 0.0 end),
		TotalAmt=sum(b.Amt)
	From SMS_Stock a inner join SMS_StockDtl b On a.StockNo=b.StockNo
	Where Year(a.CreateDate)=@Years And (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30') 
		And (a.DeptNo Like @DeptNo + '%')
		And Exists(Select 1 From BDM_DeptCode_V d Where a.DeptNo=d.CodeID And (d.DeptNo Like @CorpNo + '%')) 
	Group By a.CustID,a.SalesID,a.DepartId
	--更新客户资料
	Update a Set a.CustNo=b.CustNo,a.CustName=b.CustName,a.NameSpell=b.NameSpell,a.AreaCode=b.AreaCode,
		a.AreaName=b.AreaName,a.MemberID=b.MemberID,a.PopedomID=b.PopedomID,a.CustType=b.CustType,
		a.Member=b.Member,a.PopedomName=b.PopedomName,a.TypeName=b.TypeName,a.KindName=b.KindName,
		a.TradeName=b.TradeName,a.LinkMan=b.LinkMan,a.Phone=b.Phone,a.Faxes=b.Faxes
	From @uTable a,BAS_Customer_V b
	Where a.CustID=b.CustID
	Update a Set a.DepartName=d.CHName From @uTable a Inner Join BDM_DeptCode_V d ON a.DepartId=d.CodeId
	
	Update a Set a.Sales=b.EmployeeName
	From @uTable a
	    INNER JOIN BDM_Employee b ON a.SalesID=b.EmployeeID
	    
	--返回
	Return
End
go

