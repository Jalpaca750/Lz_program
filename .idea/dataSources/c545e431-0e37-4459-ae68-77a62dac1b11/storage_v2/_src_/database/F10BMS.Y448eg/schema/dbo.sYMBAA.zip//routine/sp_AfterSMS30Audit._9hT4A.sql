
CREATE PROCEDURE [dbo].[sp_AfterSMS30Audit]
(
	@OrderNo varchar(20),					--单据编号
	@BillSts char(2),						--单据状态
	@userId BIGINT							--操作员
)
AS
BEGIN
	DECLARE @companyId VARCHAR(32),			--公司Id
			@ownerId VARCHAR(32),			--业主Id
			@warehouseId VARCHAR(32),		--仓库Id
			@operatorId VARCHAR(32),		--操作员Id	
			@curTime DATETIME;				--操作时间 
	DECLARE @orderDate VARCHAR(10),			--下单日期（F10的CreateTime)
			@customerId VARCHAR(32),		--客户Id
			@sendDate VARCHAR(10),			--交货日期
			@sendTime VARCHAR(40),			--交货时间
			@receiverAddress VARCHAR(100),	--送货地址
			@receiverName VARCHAR(40),		--收货人
			@receiverTel VARCHAR(80),		--收货人电话
			@lineId VARCHAR(32),			--配送线路Id
			@settlementId VARCHAR(32),		--结算方式Id
			@groupId VARCHAR(32),			--客服（F10客服名称）
			@isTogether INT,				--1,货齐一起送；0,有货先送
			@salesId VARCHAR(32),			--销售员Id			
			@orderSource INT,				--9网站;10-F10
			@deptId VARCHAR(32),			--发货部门
			@handlerId VARCHAR(32),			--经手人
			@organizeId VARCHAR(100),		--成本中心名称
			@logisticsId VARCHAR(32),       --物流公司
			@buyerId VARCHAR(100),			--易企购下单人昵称
			@currencyId VARCHAR(32),		--币别
			@exchangeRate DECIMAL(20,10),	--汇率
			@taxFlag INT,					--是否含税
			@sdState INT,					--订单状态 10-待审核;
			@taskState INT,					--任务状态
			@arState INT,					--是否已经付款1-是
			@orderType INT,					--10-销售订单
			@aFlag INT,						--订单类型：0-正常；1-有A单；2-A单
			@aOrderNo VARCHAR(32),			--A单编码
            @PoNo VARCHAR(40),              --客户单号
			@bonePkgId VARCHAR(32),			--Bone子订单编号
			@boneOrdId VARCHAR(32),			--Bone订单编号
			@totalFee DECIMAL(20,10),		--总金额
			@flag INT,						--紧急标识
			@memo VARCHAR(1000),			--备注
			@creatorID VARCHAR(32),			--制单人Id
			@auditorId VARCHAR(32),			--审核人Id
			@auditTime DATETIME,			--审核时间
			@wmsOrder VARCHAR(32),			--Wms订单No
			@ordField1 INT,					--自定义字段1存放分装数量SplitNum
			@ordField3 VARCHAR(100),        --自定义字段3存放地址辖区popedomName
			@stockNo VARCHAR(32);			--对应出库单(WMS)
	DECLARE @ErrMsg nvarchar(4000),@ErrSeverity int,@funCode VARCHAR(100),@errors BIGINT;	
	DECLARE @sales TABLE(stockNo VARCHAR(32),billCount INT);
    DECLARE @tmpDetail TABLE(orderId VARCHAR(32),orderNo VARCHAR(32),companyId VARCHAR(32),viewOrder INT IDENTITY(1,1),
                            warehouseId VARCHAR(32),eId VARCHAR(32),itemId VARCHAR(32),orderQty DECIMAL(20,6),befPrice DECIMAL(20,10),
                            discount DECIMAL(6,2),price DECIMAL(20,10),taxrate DECIMAL(6,2),fee DECIMAL(20,10),taxFee DECIMAL(20,10),
                            totalFee DECIMAL(20,10),pkgQty DECIMAL(20,6),bulkQty DECIMAL(20,6),shipQty DECIMAL(20,6),stockQty DECIMAL(20,6),
                            isRed INT,rebate DECIMAL(10,6),toOrder INT,updPrice INT,isPromotion INT,isGift INT,needAssemble INT,isVirtual INT,
                            salesId VARCHAR(32),deptId VARCHAR(32),remarks VARCHAR(2000),contractId VARCHAR(32),contractNo VARCHAR(32),
                            boneOrdId VARCHAR(32),ordDtlEx02 VARCHAR(100));
	SET @funCode='sp_AfterSMS30Audit';
  	SET @curTime=GETDATE();    
	--如果未开启同步，则停止推送
	IF NOT EXISTS(SELECT * FROM dbo.SYS_Config WHERE ISNULL(startWms,0)=1)
		RETURN;
	--如果非配置数据，直接退出，AFlag=0实施时可根据情况修改
	IF NOT EXISTS(SELECT * FROM dbo.SMS_Order WHERE OrderNo=@OrderNo AND AFlag=0 AND DeptNo IN(SELECT DeptNo FROM WMS_Config))
		RETURN;
    --获取公司Id,业主Id
    SELECT TOP 1 @companyId=companyId,@ownerId=OwnerId FROM dbo.SYS_Config;
	--获取当前操作用户Id	
	SELECT @operatorId=userId
	FROM YiWms.dbo.SAM_User
	WHERE companyId=@companyId AND userNo=ANY(SELECT userNo=employeeNo FROM dbo.BDM_Employee WHERE EmployeeID=@userId);
	--清除订单错误消息
	DELETE FROM dbo.SAM_Error WHERE funCode=@funCode AND billNo=@orderNo;	
	SET @errors=0;
	--开始同步操作    
	BEGIN TRANSACTION
	--审核订单
	IF (@BillSts='20')
	BEGIN	    
		--获取订单信息
		SELECT @orderDate=orderDate,
				@customerId=customerId,
				@sendDate=sendDate,
				@sendTime=sendTime,
				@receiverAddress=receiverAddress,
				@receiverName=receiverName,
				@receiverTel=receiverTel,
				@lineId=lineId,
				@settlementId=settlementId,					
				@isTogether=isTogether,
				@salesId=salesId,					
				@orderSource=orderSource,
				@deptId=deptId,
				@handlerId=handlerId,
				@organizeId=organizeId,
				@logisticsId=logisticsId,
				@buyerId=buyerId,
				@groupId=groupId,
				@currencyId=currencyId,
				@exchangeRate=exchangeRate,
				@taxFlag=taxFlag,
				@sdState=sdState,
				@taskState=taskState,
				@arState=arState,
				@orderType=orderType,
				@aFlag=aFlag,					
				@aOrderNo=aOrderNo,
				@warehouseId=warehouseId,
				@bonePkgId=bonePkgId,
				@boneOrdId=boneOrdId,
				@ordField1=ordField1,
				@ordField3=ordField3,
				@totalFee=totalFee,
				@creatorID=creatorId,
				@wmsOrder=wmsOrder,
				@flag=flag,
				@memo=memo,
				@auditTime=auditTime,
				@auditorId=auditorId,
                @PoNo=PoNo
		FROM dbo.Sync_SMS_Order_V
		WHERE OrderNo=@OrderNo;
        SET @errors=@errors+@@ERROR;        
		--如果当前订单不在同步中间视图
		IF NOT EXISTS(SELECT * FROM dbo.Sync_SMS_Order_V WHERE OrderNo=@OrderNo)
		BEGIN
			--且也没有同步到WMS
			IF NOT EXISTS(SELECT * FROM YiWms.dbo.SAD_Order WHERE companyId=@companyId AND ownerId=@ownerId AND billNo=@OrderNo)
			BEGIN
				--写入同步错误日志	
				INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
				VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterSMS30Audit','YI_SO_CUST_NOT_SYNC_ERROR',
					'订单[' + @OrderNo + ']对应客户资料没有同步到WMS，订单同步失败',@OrderNo,@OrderNo); 
				COMMIT;
				RETURN;
			END
		END
		--检查商品资料是否有没同步的
		IF EXISTS(SELECT * FROM dbo.SMS_OrderDtl a WHERE a.OrderNo=@OrderNo AND (ISNULL(OQty,0.0)-ISNULL(SQty,0.0)>0.0) AND OrderID NOT IN(SELECT OrderID FROM dbo.Sync_SMS_OrderDtl_V WHERE OrderNo=@OrderNo))
		BEGIN
			--写入同步错误日志	
			INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
			VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterSMS30Audit','YI_SO_ITEM_NOT_SYNC_ERROR',
				'订单[' + @OrderNo + ']对应商品资料没有同步到WMS，订单同步失败',@OrderNo,@OrderNo);
			COMMIT;
			RETURN;
		END		
		--已经同步过的数据不需要同步
		IF EXISTS(SELECT * FROM dbo.SMS_Order WHERE OrderNo=@OrderNo AND syncFlag=1)
			OR EXISTS(SELECT * FROM YiWms.dbo.SAD_Order WHERE companyId=@companyId AND ownerId=@ownerId AND billNo=@OrderNo)
		BEGIN
			--获取已更新的订单
			SELECT @wmsOrder=orderNo FROM YiWms.dbo.SAD_Order WHERE companyId=@companyId AND ownerId=@ownerId AND billNo=@OrderNo;
			--更新订单状态
			UPDATE dbo.SMS_Order SET syncFlag=1,wmsOrder=@wmsOrder,editTime=GETDATE() WHERE OrderNo=@OrderNo;
			COMMIT;
			RETURN;
		END
		--如果是Bone平台的单据，则直接取ECM_OrderEx的PackageId作为主键
		IF (ISNULL(@bonePkgId,'')!='')
			SET @wmsOrder=@bonePkgId;	
		ELSE
			SET @wmsOrder=LOWER(REPLACE(NEWID(),'-',''));			
		--写入WMS
		INSERT INTO YiWms.dbo.SAD_Order(orderNo,companyId,ownerId,billNo,createTime,
			orderDate,customerId,receiverAddress,lineId,receiverName,receiverTel,warehouseId,
			orderType,isTogether,shipDate,shipTime,settlementId,groupId,currencyId,exchangeRate,taxFlag,
			sdState,arState,taskState,totalFee,orderSource,organizeId,salesId,deptId,handlerId,buyerId,
			flag,aFlag,aOrderNo,thirdSyncFlag,ordField1,ordField2,ordField3,memo,isLocked,lockerId,lockedTime,
			creatorId,auditorId,auditTime,editTime,editorId,logisticsId,poNo)
		VALUES(@wmsOrder,@companyId,@ownerId,@OrderNo,@curTime,
			@orderDate,@customerId,@receiverAddress,@lineId,@receiverName,@receiverTel,@warehouseId,
			@orderType,@isTogether,@SendDate,@sendTime,@settlementId,@groupId,@currencyId,@exchangeRate,
			@taxFlag,@sdState,@arState,@taskState,@totalFee,@orderSource,@organizeId,@SalesID,@deptId,
			@handlerId,@buyerId,@flag,@aFlag,@aOrderNo,0,@ordField1,@boneOrdId,@ordField3,@memo,0,'',NULL,
			@creatorId,@auditorId,@auditTime,@curTime,@operatorId,@logisticsId,@poNo);	
        SET @errors=@errors+@@ERROR;
		--订单明细写入临时表(用于2000语法)	
        INSERT INTO @tmpDetail(orderId,orderNo,companyId,warehouseId,eId,itemId,orderQty,befPrice,discount,
            price,taxrate,fee,taxFee,totalFee,pkgQty,bulkQty,shipQty,stockQty,isRed,rebate,toOrder,updPrice,
            isPromotion,isGift,needAssemble,isVirtual,salesId,deptId,remarks,contractId,contractNo,boneOrdId,ordDtlEx02)
		SELECT LOWER(REPLACE(NEWID(),'-','')),@wmsOrder AS orderNo,@companyId AS companyId,@warehouseId AS warehouseId,
			a.eId,a.itemId,a.orderQty,a.befPrice,a.discount,a.Price,a.taxrate,a.fee,a.taxFee,a.totalFee,
			CASE ISNULL(a.pkgRatio,0) WHEN 0 THEN 0.0 ELSE FLOOR(a.orderQty/a.pkgRatio) END AS pkgQty,
			CASE ISNULL(a.pkgRatio,0) WHEN 0 THEN a.orderQty ELSE a.orderQty-FLOOR(a.orderQty/a.pkgRatio)*a.pkgRatio END AS bulkQty,
			0.0 AS shipQty,a.stockQty,0 AS IsRed,0.0 AS rebate,a.toOrder,a.updPrice,a.isPromotion,
			ISNULL(a.isGift,0) AS isGift,a.needAssemble,a.isVirtual,@salesId AS salesId,@deptId AS deptId,
			a.remarks,a.OrderID AS contractId,a.OrderNo AS contractNo,@boneOrdId AS boneOrdId,ordDtlEx02
		FROM dbo.Sync_SMS_OrderDtl_V a
		WHERE a.OrderNo=@OrderNo
		ORDER BY a.OrderId,a.isGift;
		SET @errors=@errors+@@ERROR;
        INSERT INTO YiWms.dbo.SAD_OrderDetail(orderId,orderNo,companyId,viewOrder,warehouseId,
			eId,itemId,orderQty,befPrice,discount,price,taxRate,fee,taxFee,totalFee,pkgQty,
			bulkQty,shipQty,stockQty,isRed,rebate,toOrder,updPrice,isPromotion,isGift,needAssemble,
			isVirtual,salesId,deptId,remarks,contractId,contractNo,boneOrdId,ordDtlEx02)
		SELECT orderId,orderNo,companyId,viewOrder,warehouseId,
			eId,itemId,orderQty,befPrice,discount,Price,taxrate,fee,taxFee,totalFee,pkgQty,
			bulkQty,shipQty,stockQty,IsRed,rebate,toOrder,updPrice,isPromotion,isGift,needAssemble,
			isVirtual,salesId,deptId,remarks,contractId,contractNo,boneOrdId,ordDtlEx02
		FROM @tmpDetail;	 
        SET @errors=@errors+@@ERROR;    
		--更新订单状态
		UPDATE dbo.SMS_Order SET syncFlag=1,wmsOrder=@wmsOrder,editTime=GETDATE() WHERE OrderNo=@OrderNo;
        SET @errors=@errors+@@ERROR;		
	END
	--取消订单审核
	IF (@BillSts='10')
	BEGIN
		SELECT @wmsOrder=orderNo,@aFlag=aFlag FROM YiWms.dbo.SAD_Order WHERE companyId=@companyId AND ownerId=@ownerId AND billNo=@OrderNo;
        SET @errors=@errors+@@ERROR;
		IF (ISNULL(@wmsOrder,'')!='')
		BEGIN
			--取得订单No
			INSERT INTO @sales(stockNo,billCount)
			SELECT stockNo,COUNT(1) AS stockCount 
			FROM YiWms.dbo.SAD_StockDetail 
			WHERE orderNo=@wmsOrder 
			GROUP BY stockNo;
            SET @errors=@errors+@@ERROR;
			--直送订单
			IF (@aFlag=3)
			BEGIN
				--则只需要根据SAD_StockDetail表还原IMS_Ledger表对应的已分配量即可
				IF EXISTS (SELECT 1 FROM @sales)		
				BEGIN
					--写入同步错误日志	
					INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
					VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterSMS30Audit','YI_SO_VENDOR_SEND_NOT_CANCEL',
						'直送订单[' + @OrderNo + ']已完成作业，取消审核失败',@OrderNo,@OrderNo);
					COMMIT;
					RETURN;
				END
			END
			--如果是普通订单
			IF (@aFlag=0 OR @aFlag=1)
			BEGIN
				--则只需要根据SAD_Stock表还原IMS_Ledger表对应的已分配量即可
				UPDATE a SET a.allocQty = ISNULL(a.allocQty,0.0)-ISNULL(b.pickQty,0.0)
				FROM YiWms.dbo.IMS_Ledger a 
					INNER JOIN (SELECT companyId,warehouseId,itemId,SUM(stockQty) AS pickQty
								FROM YiWms.dbo.SAD_StockDetail
								WHERE orderNo=@wmsOrder
								GROUP BY companyId,warehouseId,itemId
								) b ON a.companyId=b.companyId AND a.warehouseId=b.warehouseId AND a.itemId=b.itemId;
                SET @errors=@errors+@@ERROR;
			END
			--删除出库单明细数据
			DELETE FROM YiWms.dbo.SAD_StockDetail WHERE orderNo=@wmsOrder;	
			SET @errors=@errors+@@ERROR;				 
			DECLARE myCursor CURSOR
			FOR --获取订单对应的出库单No
				SELECT stockNo FROM @sales
			OPEN myCursor
			FETCH NEXT FROM myCursor INTO @stockNo
			WHILE @@FETCH_STATUS=0
			BEGIN
				--如果出库单明细已经全部删除，则删除主表
				IF NOT EXISTS(SELECT 1 FROM YiWms.dbo.SAD_StockDetail WHERE stockNo=@stockNo)
				BEGIN
					DELETE FROM YiWms.dbo.SAD_Stock WHERE stockNo=@stockNo;
                    SET @errors=@errors+@@ERROR;
				END
				ELSE
				BEGIN
                    DECLARE @Nos VARCHAR(2000);
                    SET @Nos='';
                    SELECT DISTINCT @Nos=@Nos + orderBillNo + ','
                    FROM YiWms.dbo.SAD_StockDetail 
                    WHERE stockNo=@stockNo;
                    IF LEN(@Nos)>1
                        SET @Nos=LEFT(@Nos,LEN(@Nos)-1)
					--更新出库单对应订单编号
					UPDATE a SET a.mergeNo=@Nos
					FROM YiWms.dbo.SAD_Stock a 
					WHERE a.stockNo=@stockNo;
                    SET @errors=@errors+@@ERROR;
					--更新出库单总金额
					UPDATE a SET a.totalFee=(SELECT SUM(totalFee) FROM YiWms.dbo.SAD_StockDetail WHERE stockNo=a.stockNo)
					FROM YiWms.dbo.SAD_Stock a 
					WHERE a.stockNo=@stockNo;
                    SET @errors=@errors+@@ERROR;
				END
				FETCH NEXT FROM myCursor INTO @stockNo
			END
			CLOSE myCursor
			DEALLOCATE myCursor
			--删除订单数据数据
			DELETE FROM YiWms.dbo.SAD_OrderDetail WHERE orderNo=@wmsOrder;
            SET @errors=@errors+@@ERROR;
			DELETE FROM YiWms.dbo.SAD_Order WHERE orderNo=@wmsOrder;
            SET @errors=@errors+@@ERROR;
            --删除订单预占数据
            DELETE FROM YiWms.dbo.IMS_Advance WHERE OrderNo=@wmsOrder;
            SET @errors=@errors+@@ERROR;
		END
	END
	--终止订单
	IF (@BillSts='05')
	BEGIN
	    SELECT @wmsOrder=orderNo,@aFlag=aFlag FROM YiWms.dbo.SAD_Order WHERE companyId=@companyId AND ownerId=@ownerId AND billNo=@OrderNo;
		--更新订单状态即可
		UPDATE YiWms.dbo.SAD_Order SET sdState=15 WHERE companyId=@companyId AND ownerId=@ownerId AND billNo=@OrderNo;
        SET @errors=@errors+@@ERROR;
		UPDATE dbo.SMS_Order SET syncFlag=1,editTime=GETDATE() WHERE OrderNo=@OrderNo;	
        SET @errors=@errors+@@ERROR;
        --更新预占库存为0
        UPDATE YiWms.dbo.IMS_Advance SET advQty=0 WHERE orderNo=@wmsOrder;
        SET @errors=@errors+@@ERROR;
	END
    IF (@errors=0)
    BEGIN
		COMMIT;
	END
    ELSE
	BEGIN
		IF @@TRANCOUNT > 0
			 ROLLBACK;
		SELECT @ErrMsg = [description],@ErrSeverity = severity
        FROM master.dbo.sysmessages
        WHERE msglangid=2052 AND error=@errors;			
		--写入同步错误日志	
		INSERT INTO dbo.SAM_Error(errorId,companyId,createTime,creatorId,funCode,errorCode,errorMessage,billId,billNo)
		VALUES(LOWER(REPLACE(NEWID(),'-','')),@companyId,GETDATE(),@operatorId,'sp_AfterSMS30Audit','YI_SO_SYNC_ERROR',LEFT(@ErrMsg,2000),@OrderNo,@OrderNo);
	END
END

go

