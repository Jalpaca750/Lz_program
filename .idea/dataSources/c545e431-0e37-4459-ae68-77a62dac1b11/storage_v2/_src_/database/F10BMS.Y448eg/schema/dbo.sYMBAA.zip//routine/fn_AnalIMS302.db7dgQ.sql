
--说明：其他入出库单统计分析
--作者：Devil.H
--创建：2010.08.03
--参数：
--	@DeptNo:部门
--	@WareHouse:仓库
--	@ClassID:商品大类
--	@LabelID:商品品牌
--	@ItemID:商品ID
--	@Flag:为前台设计
CREATE FUNCTION dbo.fn_AnalIMS302
(
	@DeptNo VARCHAR(20),
	@WareHouse VARCHAR(20),
	@ClassID VARCHAR(20),
	@LabelID VARCHAR(20),
	@ItemID BIGINT,
	@Flag INT
)
RETURNS @uTable TABLE(
	WareHouse VARCHAR(20),
	WHName VARCHAR(100),
	DeptNo VARCHAR(20),
	ClassID VARCHAR(20),
	ClassName VARCHAR(100),
	Amt DECIMAL(18,6),
	WAmt DECIMAL(18,6),
	IMSPercent DECIMAL(18,6),
	JHCstAmt DECIMAL(18,6) 		--参考成本
)
AS
BEGIN
	IF (@Flag=0) 
		RETURN;
	DECLARE @Tmp TABLE(WareHouse VARCHAR(20),Amt DECIMAL(18,6) PRIMARY KEY(WareHouse));
	--获取库存商品信息
	INSERT INTO @uTable(WareHouse,WHName,DeptNo,ClassID,ClassName,Amt,JHCstAmt)--指定成本价处理
	SELECT WareHouse,WHName,DeptNo,ClassID,ClassName,SUM(Amt),SUM(JHCstAmt)
	FROM fn_AnalIMS301(@DeptNo,@WareHouse,@ClassID,@LabelID,@ItemID,1)
	GROUP BY WareHouse,WHName,DeptNo,ClassID,ClassName;
	--获取商品总金额
	INSERT INTO @Tmp(WareHouse,Amt)
	SELECT WareHouse,SUM(Amt)
	FROM @uTable 	
	GROUP BY WareHouse;
	--更新库房总金额
	UPDATE a SET a.WAmt=ISNULL(b.Amt,0),
		         a.IMSPercent=CASE ISNULL(b.Amt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(a.Amt,0.0)/ISNULL(b.Amt,0.0),6) END
	FROM @uTable a 
        INNER JOIN @Tmp b ON a.WareHouse=b.WareHouse;
	RETURN;
END
go

