--说明：商品客户销售分析
--作者：Devil.H
--创建：2010.06.29
--参数：	
--	@ItemID:商品ID
--	@StartDate:起始日期
--	@ENDDate:截至日期
--	@CorpNo:公司
--	@DeptNo:分部
--	@Flag :为前台设计
CREATE FUNCTION dbo.fn_AnalSMS3A1
(
	@ItemID BIGINT=0,
	@StartDate CHAR(10)='0000-01-01',
	@ENDDate CHAR(10)='9999-12-31',
	@CorpNo VARCHAR(2)='',
	@DeptNo VARCHAR(20)='',
	@Flag BIT=0
)
RETURNS @uTABLE TABLE(
	CustID BIGINT,
	CustNo VARCHAR(20),
	CustName VARCHAR(200),
	LinkMan VARCHAR(40),
	Phone VARCHAR(80),
	Faxes VARCHAR(40),
	SQty DECIMAL(18,6),
	RQty DECIMAL(18,6),
	TQty DECIMAL(18,6),
	AvgPrice DECIMAL(18,6),
	SelAmt DECIMAL(18,6),	
	RetAmt DECIMAL(18,6),	
    RealAmt DECIMAL(18,6),            --实际销售额(去掉返点，平台费)
    RebateAmt DECIMAL(18,6),          --返点
    PlatformFee DECIMAL(18,6),        --平台费
	TotalAmt DECIMAL(18,6),
	SelPercent DECIMAL(18,6),
	RetPercent DECIMAL(18,6),
	R_SScale  DECIMAL(16,6),
	R_SPercent DECIMAL(18,6),
	CustType VARCHAR(20),
	TypeName VARCHAR(100),
	MemberID VARCHAR(20),
	Member VARCHAR(100),
	AreaCode VARCHAR(20),
	AreaName VARCHAR(100),
	PopedomID VARCHAR(20),
	PopedomName VARCHAR(100),
	KindName VARCHAR(100),
	TradeName VARCHAR(100)
)
AS
BEGIN
	IF (@Flag=0)
		RETURN;
	DECLARE @SUMAmt DECIMAL(18,6),@SUMRAmt DECIMAL(18,6),@AmtDec INT;
	DECLARE @Tmp TABLE(CustID BIGINT,RQty DECIMAL(18,6),SQty DECIMAL(18,6),RetAmt DECIMAL(18,6),SelAmt DECIMAL(18,6),RebateAmt DECIMAL(18,6),PlatformFee DECIMAL(18,6),TQty DECIMAL(18,6),TotalAmt DECIMAL(18,6));
    --初始化变量
	SET @StartDate=CONVERT(CHAR(10),CAST(@StartDate AS DATETIME),23);
	SET @ENDDate=CONVERT(CHAR(10),CAST(@ENDDate AS DATETIME),23);
    SELECT @AmtDec=ISNULL(AmtDec,2) FROM SYS_Config;
	--获取商品销售数据	
	Insert Into @Tmp(CustID,RetAmt,RQty,SelAmt,SQty,RebateAmt,PlatformFee,TQty,TotalAmt)
	Select a.CustID,
		RAmt=ABS(ISNULL(SUM(CASE a.BillType WHEN '20' THEN b.Amt ELSE 0 END),0))
			+ABS(ISNULL(SUM(CASE a.BillType WHEN '50' THEN b.Amt ELSE 0 END),0)),
		RQty=ABS(ISNULL(SUM(CASE a.BillType WHEN '20' THEN b.SQty ELSE 0 END),0))
			+ABS(ISNULL(SUM(CASE a.BillType WHEN '50' THEN b.SQty ELSE 0 END),0)),
		SAmt=ISNULL(SUM(CASE a.BillType WHEN '10' THEN b.Amt ELSE 0 END),0)
			+ISNULL(SUM(CASE a.BillType WHEN '30' THEN b.Amt ELSE 0 END),0)
			+ISNULL(SUM(CASE a.BillType WHEN '40' THEN b.Amt ELSE 0 END),0),
		SQty=ISNULL(SUM(CASE a.BillType WHEN '10' THEN b.SQty ELSE 0 END),0)
			+ISNULL(SUM(CASE a.BillType WHEN '40' THEN b.SQty ELSE 0 END),0),
        RebateAmt=ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.Rebate,0.0)/100.0),@AmtDec),
        PlatformFee=ROUND(SUM(ISNULL(b.Amt,0.0)*ISNULL(c.PlatformFee,0.0)/100.0),@AmtDec),
		TQty=SUM(b.SQty),TotalAmt=SUM(b.Amt)
	FROM SMS_Stock a 
        INNER JOIN SMS_StockDtl b ON a.StockNo=b.StockNo
        INNER JOIN BDM_Customer c ON a.CustID=c.CustID
	WHERE b.ItemID=@ItemID 
        AND (a.BillSts='20' Or a.BillSts='25' Or a.BillSts='30')
		AND (CONVERT(CHAR(10),CAST(a.CreateDate AS DATETIME),120) BETWEEN @StartDate AND @ENDDate) 
		AND (a.DeptNo Like @DeptNo + '%')
		AND EXISTS(SELECT 1 
			       FROM BDM_DeptCode_V d 
			       WHERE (d.CodeID=a.DeptNo) AND (d.DeptNo Like @CorpNo + '%'))
	GROUP BY a.CustID;
	--获取以上客户的总销售额
	SELECT @SUMAmt=SUM(SelAmt),@SUMRAmt=SUM(RetAmt) FROM @Tmp;
    --汇总数据
	INSERT INTO @uTABLE(CustID,CustNo,CustName,CustType,TypeName,MemberID,Member,AreaCode,
        AreaName,PopedomID,PopedomName,LinkMan,Phone,Faxes,KindName,TradeName,RQty,SQty,
        SelAmt,RebateAmt,PlatformFee,RealAmt,RetAmt,SelPercent,RetPercent,R_SPercent,R_SScale,
        TQty,TotalAmt)
	SELECT a.CustID,c.CustNo,c.CustName,c.CustType,c.TypeName,c.MemberID,c.Member,c.AreaCode,
		c.AreaName,c.PopedomID,c.PopedomName,c.LinkMan,c.Phone,c.Faxes,c.KindName,c.TradeName,a.RQty,a.SQty,
		a.SelAmt,a.RebateAmt,a.PlatformFee,a.RealAmt,a.RetAmt,a.SelPercent,a.RetPercent,a.R_SPercent,
		CASE ISNULL(a.SelPercent,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(a.RetPercent,0.0)/a.SelPercent,6) END,
		a.TQty,a.TotalAmt
	FROM BAS_Customer_V c 

        INNER JOIN (SELECT CustID,RQty,SQty,SelAmt,RetAmt,TQty,TotalAmt,RebateAmt,PlatformFee,
                        ISNULL(TotalAmt,0.0)-ISNULL(RebateAmt,0.0)-ISNULL(PlatformFee,0.0) AS RealAmt,
                        CASE ISNULL(@SUMAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(SelAmt,0.0)/@SUMAmt,6) END AS SelPercent,
                        CASE ISNULL(@SUMRAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(RetAmt,0.0)/@SUMRAmt,6) END AS RetPercent,
                        CASE ISNULL(SelAmt,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND(ISNULL(RetAmt,0.0)/SelAmt,6) END AS R_SPercent,
                        CASE ISNULL(SQty,0.0)-ISNULL(RQty,0.0) WHEN 0.0 THEN 0.0 ELSE ROUND((ISNULL(SelAmt,0.0)-ISNULL(RetAmt,0.0))/(ISNULL(SQty,0.0)-ISNULL(RQty,0.0)),2) END AS AvgPrice 
                    FROM @Tmp) a ON a.CustID=c.CustID
    DELETE FROM @Tmp;
	--返回
	RETURN;
END
go

