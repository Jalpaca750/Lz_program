

/*==============================================================*/
/* View: WMS_F10_Packing_Item_V                                 */
/*==============================================================*/
CREATE view [dbo].[WMS_F10_Packing_Item_V] as
SELECT a.itemId,a.itemNo,a.itemName,b.cartonId,a.PPrice
FROM dbo.BDM_ItemInfo a
	INNER JOIN (SELECT sizeId AS cartonId,sizeNo AS itemNo
				FROM YiWms.dbo.WMS_BoxSize x
				WHERE boxType=2
				    AND EXISTS(SELECT * FROM SYS_Config y WHERE x.companyId=y.companyId)
				)  b ON a.ItemNo=b.itemNo
go

