CREATE VIEW dbo.SPM_QtyLargessDtl_V
AS
SELECT a.LargessNo, a.ItemID, b.ItemNo, b.ItemName, b.ItemAlias, b.NameSpell, 
      b.ItemSpec, b.BarCode, b.ClassID, b.ClassName, b.LabelID, b.LabelName, 
      b.UnitName, b.OnHandQty, b.AvailQty, a.ZQty, a.OQty, a.CheckBox, 
      b.ColorName
FROM dbo.SPM_QtyLargessDtl a INNER JOIN
      dbo.BDM_ItemInfo_V b ON a.ItemID = b.ItemID
go

