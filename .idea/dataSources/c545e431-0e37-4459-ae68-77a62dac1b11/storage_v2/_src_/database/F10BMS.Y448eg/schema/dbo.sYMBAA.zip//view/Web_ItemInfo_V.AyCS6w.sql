CREATE VIEW dbo.Web_ItemInfo_V
AS
SELECT a.ItemID, a.ItemNo, a.ItemName, a.ItemAlias, a.NameSpell, a.ItemSpec, a.BarCode, 
      a.ClassID, b.CodeNo AS ClassNo, b.CHName AS ClassName, a.LabelID, 
      c.CodeNo AS LabelNo, ISNULL(c.OrderID, 999999) AS LabelOrder, 
      c.CHName AS LabelName, a.ColorName, a.UnitName, a.Cubage, a.Weight, 
      a.BPackage, a.MPackage, a.Package, a.BUnit, a.MUnit, a.Unit, a.PkgRatio, a.PkgSpec, 
      a.PurDays, a.Origin, a.TaxRate, a.PPrice, a.SPrice, a.SPrice1, a.SPrice2, a.SPrice3, 
      a.SafePPrice, a.SafeSPrice, a.OnHandQty, ISNULL(a.OnHandQty, 0.0) 
      - ISNULL(t.AllocQty, 0.0) AS AvailQty, a.Integral, a.Defined1, a.Defined2, a.Defined3, 
      a.Defined4, a.Defined5, a.HotFlag, a.NotDisc, a.ItemPHFlag, 
      CASE a.ItemPHFlag WHEN 'P' THEN '批号' WHEN 'S' THEN '序列号' ELSE '都不管理' END
       AS ItemPHName, a.NTrue, a.PicAmount, a.Sale, a.SaleOrder, a.RecommOrder, 
      a.Recomm, a.NOrder, a.HotOrder, a.IsWeb, a.Flag, 
      a.InMid, a.ToMidDate, a.CreateDate,a.CreatorID, d.EmployeeName AS Creator, 
      a.AmendDate, a.MenderID, e.EmployeeName AS Mender, a.PromotionInfo, a.Remarks, a.CheckBox
FROM dbo.WEB_ItemInfo_Add a LEFT OUTER JOIN
      dbo.BDM_Employee d ON a.CreatorID = d.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee e ON a.MenderID = e.EmployeeID LEFT OUTER JOIN
      dbo.BDM_LabelCode_V c ON a.LabelID = c.CodeID LEFT OUTER JOIN
      dbo.BDM_ItemClass_V b ON a.ClassID = b.CodeID LEFT OUTER JOIN
          (SELECT ItemID, SUM(AllocQty) AS AllocQty
         FROM IMS_Allocate_V
         GROUP BY ItemID) t ON a.ItemID = t.ItemID
go

