CREATE VIEW dbo.PRJOrderDtl_V
AS
SELECT a.BillNo,a.ExecContent
FROM dbo.PRJ_Order a 


go

