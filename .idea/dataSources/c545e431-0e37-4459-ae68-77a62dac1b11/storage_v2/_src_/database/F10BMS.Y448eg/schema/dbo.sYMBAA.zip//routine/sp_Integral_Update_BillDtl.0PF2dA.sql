
CREATE proc sp_Integral_Update_BillDtl(	@BillNo varchar(20),@BillType Varchar(5))
as
Begin
	--更新明细表中的商品积分与单据产生日期
	if @BillType='SMS40'
	begin
		--出库单
		Update A Set A.Integral=B.Integral,A.CreateDate=B.CreateDate From SMS_StockDtl A,SMS_StockDtl_V B where A.StockNo=B.StockNo And A.ItemID=B.ItemID And A.StockNo=@BillNo

		--处理Amt#######################################################
		declare  @StockNo varchar(20)
		set @StockNo=@BillNo
		if exists(Select 1 From SMS_StockDtl Where StockNo=@StockNo and Amt=0)
		begin
			update SMS_StockDtl set Amt=(Case When isnull(price,0)=0 Then 0 When isnull(Sqty,0)=0 Then 0 else Round(isnull(Sqty,0)*isnull(Price,0),2) end) where StockNo=@StockNo and Amt=0
		end
		
		if exists(Select 1 From SMS_StockDtl Where StockNo=@StockNo and (SQty=0 or Price=0))
		begin
			update SMS_StockDtl set Amt=0 where StockNo=@StockNo and (SQty=0 or Price=0)
		end
		
		if exists(Select * From SMS_StockDtl Where StockNo=@StockNo and Amt>0 and Sqty>0 and Price>0 and abs(case isnull(price,0) When 0 then 1 else ((Amt/price)-Sqty) End)>=0.01) 
		begin
			update SMS_StockDtl set Amt=(Case When isnull(price,0)=0 Then 0 When isnull(Sqty,0)=0 Then 0 else Round(isnull(Sqty,0)*isnull(Price,0),2) end)
			where StockNo=@StockNo and abs(case isnull(price,0) When 0 then 1 else ((Amt/price)-Sqty) End)>=0.01
		end	
		--############################################################	
	end

	if @BillType='SMS60'
	begin
		--退货单
		--Update A Set A.Integral=B.Integral,A.CreateDate=B.CreateDate From SMS_ReturnDtl A,SMS_ReturnDtl_V B where A.ReturnNo=B.ReturnNo And A.ItemID=B.ItemID And A.ReturnNo=@BillNo
		Update A Set A.Integral=C.Integral,A.CreateDate=C.CreateDate 
		From SMS_ReturnDtl A,SMS_StockDtl C 
		where A.ItemID=C.ItemID And A.StockNo=C.StockNo And A.ReturnNo=@BillNo

		Update A Set A.Integral=B.Integral,A.CreateDate=B.CreateDate From SMS_ReturnDtl A,SMS_ReturnDtl_V B where A.ReturnNo=B.ReturnNo And A.ItemID=B.ItemID And len(a.CreateDate)=0 And A.ReturnNo=@BillNo
	end

	if @BillType='SMS90'
	begin
		--发票单		
		--Update A Set A.Integral=B.Integral,A.CreateDate=B.CreateDate From SMS_InvoiceDtl A,SMS_InvoiceDtl_V B where A.InvoiceNo=B.InvoiceNo And A.ItemID=B.ItemID And A.InvoiceNo=@BillNo
		Update A Set A.Integral=C.Integral,A.CreateDate=C.CreateDate 
		From SMS_InvoiceDtl A,SMS_StockDtl C 
		where A.ItemID=C.ItemID And A.StockNo=C.StockNo And A.InvoiceNo=@BillNo
	end

	--if @BillType='IMS60'
	--begin
		--赠品单		
	--	Update A Set A.CreateDate=B.CreateDate From IMS_PresentDtl A,IMS_PresentDtl_V B where A.PresentNo=B.PresentNo And A.ItemID=B.ItemID And A.PresentNo=@BillNo
	--end
	--更新明细表中的商品积分与单据产生日期
	if @BillType='SMSA0'
	begin
		--零售单
		Update A Set A.Integral=B.Integral,A.CreateDate=B.CreateDate From SMS_RetailDtl A,SMS_RetailDtl_V B where A.RetailNo=B.RetailNo And A.ItemID=B.ItemID And A.RetailNo=@BillNo
	end
End
go

