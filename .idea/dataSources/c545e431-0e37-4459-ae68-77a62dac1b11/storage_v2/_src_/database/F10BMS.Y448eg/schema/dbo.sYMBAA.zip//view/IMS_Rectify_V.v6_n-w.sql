CREATE VIEW [dbo].[IMS_Rectify_V]
AS
SELECT a.RectifyNo, a.CreateDate, a.DeptNo, d.CHName AS DeptName, c.Amt, a.BillSts, 
      (SELECT StsName FROM BillStatus f WHERE a.BillSts = f.BillSts AND f.BillType='IMSA0') AS StsName, 
      a.AuditID, e.EmployeeName AS Auditer, a.AuditDate, a.CreatorID, b.EmployeeName AS Creator, 
      a.PrintNum, a.PrinterID,p.EmployeeName AS Printer, a.PFlag, a.Remarks, a.CheckBox
FROM dbo.IMS_Rectify a LEFT OUTER JOIN
      dbo.BDM_Employee p ON a.PrinterID = p.EmployeeID LEFT OUTER JOIN
      dbo.BDM_DeptCode_V d ON a.DeptNo = d.CodeID LEFT OUTER JOIN
      dbo.BDM_Employee b ON a.CreatorID = b.EmployeeID LEFT OUTER JOIN
      dbo.BDM_Employee e ON a.AuditID = e.EmployeeID LEFT OUTER JOIN
      (SELECT RectifyNo, SUM(Amt) AS Amt
       FROM IMS_RectifyDtl
       GROUP BY RectifyNo) c ON a.RectifyNo = c.RectifyNo
go

