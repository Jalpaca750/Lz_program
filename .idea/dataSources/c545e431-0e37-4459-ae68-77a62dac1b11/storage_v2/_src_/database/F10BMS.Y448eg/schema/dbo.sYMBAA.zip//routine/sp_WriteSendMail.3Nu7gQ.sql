/****** Object:  StoredProcedure [dbo].[sp_WriteSendMail]    Script Date: 05/04/2014 16:09:25 ******/
CREATE Proc [dbo].[sp_WriteSendMail]
(	
	@BillNo varchar(20),
	@Mail_Title varchar(100),
	@Mail_Message ntext,
	@Mail_Address varchar(80)
)
As
Begin	
INSERT INTO Web_SendMail(BillNo,Mail_Title,Mail_Message,Mail_Address,Mail_Status,CreateDate)
Values(@BillNo,@Mail_Title,@Mail_Message,@Mail_Address,0,GetDate())
END
go

