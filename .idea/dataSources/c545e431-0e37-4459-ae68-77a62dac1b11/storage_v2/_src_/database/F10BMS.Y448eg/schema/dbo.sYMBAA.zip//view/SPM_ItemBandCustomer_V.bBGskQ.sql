CREATE VIEW dbo.SPM_ItemBandCustomer_V
AS
SELECT a.ItemBandNo, a.CustID, c.CustNo, c.CustName
FROM dbo.SPM_ItemBandCustomer a INNER JOIN
      dbo.BAS_Customer_V c ON a.CustID = c.CustID
go

