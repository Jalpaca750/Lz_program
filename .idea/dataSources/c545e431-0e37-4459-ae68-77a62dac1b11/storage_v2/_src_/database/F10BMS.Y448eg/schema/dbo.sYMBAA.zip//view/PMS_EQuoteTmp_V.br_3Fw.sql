--询价单临时表
CREATE VIEW dbo.PMS_EQuoteTmp_V
--with encryption
AS
SELECT a.BillNo, a.ItemID, b.ItemNo, b.ItemName, b.ItemSpec, b.ClassName, 
      b.LabelName, b.UnitName, a.Qty, a.PPrice, a.Amt,b.PPrice as Price,b.SafePPrice
FROM dbo.PMS_EQUOTETMP a INNER JOIN
      dbo.BDM_ITEMINFO_V b ON a.ItemID = b.ItemID


go

