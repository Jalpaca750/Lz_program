
/*==============================================================*/
/* View: BDM_EmployeeLine_V                                     */
/*==============================================================*/
create view BDM_EmployeeLine_V as
SELECT a.EmployeeId,a.LineID,b.CodeNo AS LineCode,b.CHName AS LineName,a.SPFlag,
    CASE a.SPFlag WHEN 0 THEN '采购分组' ELSE '销售分组' END AS spFlagDesc
FROM BDM_EmployeeLine a
    INNER JOIN BDM_Code b ON a.LineID=b.CodeID
go

