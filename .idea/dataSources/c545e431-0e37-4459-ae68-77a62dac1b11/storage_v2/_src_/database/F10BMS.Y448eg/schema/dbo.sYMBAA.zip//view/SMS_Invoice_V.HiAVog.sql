CREATE VIEW [dbo].[SMS_Invoice_V]
AS
SELECT a.InvoiceID, a.InvoiceNo, a.CreateDate, a.DeptNo, e.CHName AS DeptName, 
      a.CustID, b.CustNo, b.CustName, b.NameSpell, a.SendAddr, 
      b.CustType, b.TypeName, b.MemberID, b.Member, b.AreaCode, b.AreaName, b.PopedomID, 
      b.PopedomName, a.SalesID, f.EmployeeName AS Sales, b.KindName, b.TradeName, 
      a.LinkMan,a.Phone, b.Faxes, a.IType, d.CHName AS ITName, a.Invoice, a.PayMode, a.IAmt, 
      a.DAmt, a.PAmt, ISNULL(a.IAmt, 0) - ISNULL(a.PAmt, 0) AS RemAmt, a.BackDate, 
      a.BackerID, j.EmployeeName AS Backer, a.BillSts, a.PrintNum,a.PFlag, a.CAmt,
      (SELECT StsName FROM BillStatus k WHERE a.BillSts=k.BillSts And k.BillType='SMS90') AS StsName, 
      a.RedFlag,CASE a.RedFlag WHEN -1 THEN '红字' WHEN 0 THEN '蓝字' WHEN 1 THEN '冲红' END AS RedInvoice,
      a.PDate, i.FAmt, i.PayAmt, a.AuditDate, a.AuditID, h.EmployeeName AS Auditer, 
      a.CreatorID, c.EmployeeName AS Creator, a.Remarks, a.CheckBox, 
      a.CreateDate AS InvoiceDate, Isnull(b.ADays,30)+Isnull(t.ADays,0) AS ADays,
      a.PrinterID,p.EmployeeName AS Printer,a.SignName,a.ARDate,a.SendBill,
      a.CarNumberSts,a.CarNumberDate,a.DepartId,dt.CHName AS DepartName
FROM dbo.SMS_Invoice a 
    LEFT JOIN dbo.BDM_Employee j ON a.BackerID = j.EmployeeID 
    LEFT JOIN dbo.BDM_Employee h ON a.AuditID = h.EmployeeID 
    LEFT JOIN dbo.BDM_Employee f ON a.SalesID = f.EmployeeID 
    LEFT JOIN dbo.BDM_DeptCode_V e ON a.DeptNo = e.CodeID 
    LEFT JOIN dbo.BAS_Customer_V b ON a.CustID = b.CustID 
    LEFT JOIN dbo.BDM_InvoiceType_V d ON a.IType = d.CodeID 
    LEFT JOIN dbo.BDM_Employee c ON a.CreatorID = c.EmployeeID 
    LEFT JOIN dbo.BDM_DeptCode_V dt ON a.DepartId = dt.CodeID 
    LEFT JOIN (SELECT InvoiceID, SUM(FAmt) AS FAmt, SUM(PayAmt) AS PayAmt
               FROM dbo.SMS_PaymentDtl
               GROUP BY InvoiceID) i ON a.InvoiceID = i.InvoiceID 
    LEFT JOIN dbo.BDM_Employee p ON a.PrinterID=p.EmployeeID 
    LEFT JOIN (SELECT CustID,SUM(Adays) AS Adays 
	           FROM BDM_CustCredit 
	           WHERE CONVERT(varchar(10),GetDate(),120)<=convert(varchar(10),InvalidDate,120) 
	           GROUP BY CustID) t ON a.CustID=t.CustID
go

