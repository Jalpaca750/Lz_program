--销售机会阶段统计
--2007.11.20
--2008.05.10修改
--Devil.H
--参数
--	@Year:年份
--	@Month:月份
--	@Flag	
--说明：销售机会阶段统计
--作者：Devil.H
--创建：2007.11.21
--参数：	
--	@Flag:为前台设计
--select * from dbo.uf_AnalSAL1A('2000-01-01','2010-01-01','','',0)
CREATE  Function dbo.uf_AnalSAL1A
(
	@StartDate char(10)='2000-01-01',
	@EndDate char(10)='2000-01-01',
	@Cust varchar(50)='',
	@OpportName varchar(50)='',
	@Flag bit=0
)
Returns @uTable Table(
	Seq bigint,
	XSJD varchar(10),
	XSJDHJ decimal(18,6)
)
--with encryption
As
Begin
	Insert Into @uTable(Seq,XSJD,XSJDHJ)Values(1,'计划接触',0)
	Insert Into @uTable(Seq,XSJD,XSJDHJ)Values(2,'初步接触',0)
	Insert Into @uTable(Seq,XSJD,XSJDHJ)Values(3,'立项评估',0)
	Insert Into @uTable(Seq,XSJD,XSJDHJ)Values(4,'需要分析',0)
	Insert Into @uTable(Seq,XSJD,XSJDHJ)Values(5,'方案制定',0)
	Insert Into @uTable(Seq,XSJD,XSJDHJ)Values(6,'招标竞标',0)
	Insert Into @uTable(Seq,XSJD,XSJDHJ)Values(7,'商务谈判',0)
	Insert Into @uTable(Seq,XSJD,XSJDHJ)Values(8,'合约签定',0)

	Update a Set a.XSJDHJ=b.xsjdHJ From @uTable a,(select xsjd,count(opportID) as xsjdHJ from Sales_Opport_V 
		where CreateDate Between @StartDate And @EndDate And CustName like @Cust And OpportName like @OpportName  group by xsjd) b
	Where a.XSJD=b.XSJD	
	return
End




go

