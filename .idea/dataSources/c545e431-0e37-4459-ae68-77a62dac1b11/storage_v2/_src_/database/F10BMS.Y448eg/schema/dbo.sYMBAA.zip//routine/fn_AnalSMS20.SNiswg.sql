
--说明：大类排名
--作者：Devil.H
--创建：2010.06.29
--参数：
--	@StartDate:起始日期
--	@EndDate:截至日期
--	@CorpNo:公司
--	@DeptNo:分部
--	@Flag  :标识
CREATE FUNCTION dbo.fn_AnalSMS20
(
	@StartDate VARCHAR(10)='0000-01-01',
	@EndDate VARCHAR(10)='9999-12-31',
	@CorpNo VARCHAR(2)='',
	@DeptNo VARCHAR(20)='',
	@Flag BIT=0
)
RETURNS TABLE
AS
RETURN (
	SELECT ClassID,ISNULL(ClassName,'未定义大类商品') AS ClassName,
		SUM(SellQty) AS SellQty,SUM(SellAmt) AS SellAmt,SUM(RebateAmt) AS RebateAmt,
        SUM(PlatformFee) AS PlatformFee,SUM(RealAmt) AS RealAmt 
	FROM fn_AnalSMS1A(@StartDate,@EndDate,@CorpNo,@DeptNo,'','',@Flag)
	GROUP BY ClassID,ClassName
)
go

